

# Generated at 2022-06-24 09:35:56.466864
# Unit test for function trange
def test_trange():
    from .std import format_interval, _time, sleep

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm


# Generated at 2022-06-24 09:36:07.885081
# Unit test for function trange
def test_trange():
    """Run this using ``python -m tqdm.auto``"""
    from os import getpid
    from time import sleep

    for i in trange(4, desc="1st loop"):
        for j in trange(5, desc="nested loop", leave=False):
            for k in trange(50, desc="nested-2 loop", leave=False):
                sleep(0.01)

    pid = getpid()
    try:
        import resource
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    except ImportError:
        import psutil
        p = psutil.Process(pid)
        rss = p.memory_info().rss
    print("pid=%s, memory use: %s (kb)" % (pid, rss))

# Generated at 2022-06-24 09:36:17.783529
# Unit test for function trange
def test_trange():
    """
    Tests whether trange is a shortcut to tqdm(range()).
    """
    # pylint: disable=protected-access
    class MockClass(tqdm):
        """
        Mocking class to have result of tqdm() call.
        """
        def __init__(self, iterable, **kwargs):
            super(MockClass, self).__init__(iterable, **kwargs)
            self.result = list(iterable)

    tqdm_ = MockClass
    for iterable in [[], list(range(1024)), tuple(range(1234)), (i for i in range(345))]:
        for kwargs in [{}, {"desc": "blah"}]:
            assert trange(len(iterable), **kwargs).result == iterable

# Generated at 2022-06-24 09:36:26.997805
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test trange()"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .gui import trange
        from .notebook import trange
        from .gui import tqdm
        from .notebook import tqdm

    for _tqdm in [trange, tqdm]:
        lst = list(_tqdm(range(4), desc='foobar'))
        assert len(lst) == 4
        assert lst == list(range(4))
        assert lst[-1] == 3

        lst = list(_tqdm(range(4), total=4, desc='foobar'))
        assert len(lst) == 4
        assert lst == list(range(4))
        assert l

# Generated at 2022-06-24 09:36:35.636856
# Unit test for function trange
def test_trange():
    """Test for `trange` function"""
    from .std import tqdm
    from .std import trange
    from .tests import common as td
    from .utils import _range

    with td. screensize():
        lst = [trange(3), tqdm(range(3)), trange(3, desc='Trange')]
        for i in tqdm([0, 1, 2]):
            lst.append(trange(3))
        for _ in trange(1):
            lst.append(trange(3))

# Generated at 2022-06-24 09:36:42.574983
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import sys
    import time
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import trange as notebook_trange
        from .asyncio import tqdm as asyncio_tqdm
        from .std import tqdm as std_tqdm
    for i in trange(2, desc='1st loop'):
        assert i == 0
        for j in trange(3, 2, desc='2nd loop'):
            assert j == 2
    assert trange(1, desc='1st loop')._desc == '1st loop'

# Generated at 2022-06-24 09:36:46.160260
# Unit test for function trange
def test_trange():
    """
    Tests whether function `trange` works as advertised.
    """
    try:
        list(trange(0))
    except TypeError:
        raise TypeError("trange(0) raised TypeError")

    try:
        for _ in trange(0):  # iterator
            break
    except TypeError:
        raise TypeError("trange(0) raised TypeError")

# Generated at 2022-06-24 09:36:49.555475
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert trange(0) == notebook_trange(0)
        assert trange(0, 1) == notebook_trange(0, 1)
        assert trange(0, 1, 2) == notebook_trange(0, 1, 2)


# Generated at 2022-06-24 09:36:52.276191
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(4):
        pass
    for _ in trange(3, 0, -1):
        pass
    for _ in trange(2, 2):
        pass
    for _ in trange(1, 3, 0.5):
        pass
    for _ in trange(4, desc='Task1'):
        pass

# Generated at 2022-06-24 09:36:53.243819
# Unit test for function trange
def test_trange():
    l = list(trange(10))
    assert l == list(range(10))

# Generated at 2022-06-24 09:36:56.855756
# Unit test for function trange
def test_trange():
    assert [[i, i] for i in trange(4, 7)] == [[4, 4], [5, 5], [6, 6]]
    assert [[i, i] for i in trange(4, 11, 2)] == [[4, 4], [6, 6], [8, 8], [10, 10]]
    assert list(trange(4, 7)) == [4, 5, 6]
    assert list(trange(4, 11, 2)) == [4, 6, 8, 10]

# Generated at 2022-06-24 09:37:03.027371
# Unit test for function trange
def test_trange():
    # pylint: disable=protected-access
    assert tqdm(range(3))._instances  # pylint: disable=pointless-statement

    t0 = trange(3)
    assert t0._instances  # pylint: disable=pointless-statement

    assert t0 == [0, 1, 2]
    assert t0._instances

# Generated at 2022-06-24 09:37:07.323915
# Unit test for function trange
def test_trange():
    """Tests of function trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]
    with tqdm(total=1) as t:
        assert t.total == 1

# Generated at 2022-06-24 09:37:09.379970
# Unit test for function trange
def test_trange():
    """Test #54"""
    assert list(trange(10, 100, 30)) == list(range(10, 100, 30))

# Generated at 2022-06-24 09:37:17.899911
# Unit test for function trange
def test_trange():
    import sys
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        try:
            import IPython
        except ImportError:  # pragma: no cover
            notebook_module = None
        else:
            notebook_module = getattr(
                getattr(IPython, 'get_ipython', lambda: None)(),
                'kernel', None)
        if notebook_module is not None:
            warnings.warn("Jupyter notebook detected. tqdm "
                          "autonotebook outro will be disabled.",
                          TqdmExperimentalWarning)
        else:
            warnings.warn("Jupyter notebook not detected. tqdm "
                          "autonotebook outro will be enabled.",
                          TqdmExperimentalWarning)
        from .std import tqdm

# Generated at 2022-06-24 09:37:28.709003
# Unit test for function trange
def test_trange():
    try:
        from io import StringIO  # Python 3
    except ImportError:
        from sys import version_info, stdout

        if version_info[0] < 3:  # Python 2, chr() does not take unicodes in Py2
            from cStringIO import StringIO  # type: ignore

            stdout = StringIO()
        else:  # Python 3, chr() takes unicodes in Py3
            from io import StringIO  # type: ignore


# Generated at 2022-06-24 09:37:32.043133
# Unit test for function trange
def test_trange():
    assert tqdm(range(10)).__class__ is tqdm
    assert trange(10).__class__ is tqdm


if __name__ == "__main__":
    test_trange()
    print("All tests passed")

# Generated at 2022-06-24 09:37:41.859005
# Unit test for function trange
def test_trange():
    "Test trange works correctly"
    from sys import version_info
    from contextlib import contextmanager

    try:
        from contextlib import ExitStack
    except ImportError:  # py27 compat
        from contextlib2 import ExitStack

    @contextmanager
    def nostdout(flag=None):
        "Context manager: no stdout"
        import sys
        import os
        fd = sys.stdout.fileno()
        flag_stdout = os.isatty(fd)
        with ExitStack() as stack:
            if flag is None:  # disable
                stack.enter_context(open(os.devnull, "w"))
            elif flag is True:  # enable
                stack.close()
            else:  # toggle
                stack.enter_context(nostdout(not flag_stdout))


# Generated at 2022-06-24 09:37:52.775634
# Unit test for function trange
def test_trange():
    kwargs = {"desc": "wget aa", "bar_format": "xxx{desc}yyy", "ascii": True,
              "postfix": {"wget": "zzz", "aa": "bbb"}}
    with tqdm(desc="wget aa", bar_format="xxx{desc}yyy", ascii=True,
              postfix={"wget": "zzz", "aa": "bbb"}) as t:
        assert t == tqdm(**kwargs)
        assert t == trange(**kwargs)
        assert t == tqdm(range(0), **kwargs)
        assert t == trange(0, **kwargs)
        assert t == tqdm(range(1), **kwargs)
        assert t == trange(1, **kwargs)


# Generated at 2022-06-24 09:37:56.786099
# Unit test for function trange
def test_trange():
    list(trange(3))
    assert not any(
        isinstance(x, list) for x in trange(3, desc="testing", leave=False)
    )
    assert not any(isinstance(x, str) for x in trange(3))

# Generated at 2022-06-24 09:38:04.385413
# Unit test for function trange
def test_trange():
    """Test trange()"""
    for _ in trange(10, desc='Loop'):
        pass
    for _ in trange(10, desc='Loop', leave=True):
        pass
    with trange(10, desc='Loop') as t:
        for i in t:
            if i == 5:
                break
    assert t.n == 6
    assert t.r_n == 4
    assert t.r_total == 4
    assert t.r_total_tm is not None



# Generated at 2022-06-24 09:38:13.979633
# Unit test for function trange
def test_trange():
    """Tests that function `trange` runs"""
    for _ in trange(10):
        pass
    for _ in trange(10, desc="desc"):  # test desc
        pass
    for _ in trange(10, unit="bytes"):  # test unit
        pass
    for _ in trange(10, unit_scale=True):  # test unit_scale
        pass
    for _ in trange(10, unit_divisor=1024):  # test unit_divisor
        pass
    for _ in trange(10, miniters=1, mininterval=0.1):  # test mininterval
        pass
    for _ in trange(10, smoothing=1):  # test smoothing
        pass

# Generated at 2022-06-24 09:38:16.530470
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # pylint: disable=unused-variable
    for i in trange(10):
        pass

# Generated at 2022-06-24 09:38:20.147264
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    from .autonotebook import tnrange
    with tnrange(4) as t:
        for i in t:
            assert i == next(t)

# Generated at 2022-06-24 09:38:26.078268
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    from .std import tqdm

    # just make sure it exists
    with trange(10) as t:
        for _ in t:
            pass

    # make sure the trange(0) error is correct
    with tqdm.external_write_mode():
        # pylint: disable=no-value-for-parameter
        with tqdm.assert_raises(ValueError):
            trange(0)

# Generated at 2022-06-24 09:38:37.830592
# Unit test for function trange
def test_trange():
    """Test for trange function"""
    from .std import tqdm
    try:
        for _ in trange(5, disable=True):
            pass
    except BaseException:
        raise AssertionError("trange failed when disable=True")
    if tqdm != asyncio_tqdm:  # Python < 3.6
        try:
            for _ in trange(5, disable=None):
                pass
        except BaseException:
            raise AssertionError("trange failed when disable=None")

    def _raise_exception():
        raise keyboardinterrupt

    if str(trange(0).__iter__())[:18] != '<generator object ':
        raise AssertionError("trange does not return generator")

# Generated at 2022-06-24 09:38:48.225010
# Unit test for function trange
def test_trange():
    """Test trange() coroutines that are not closed"""
    if sys.version_info[:2] < (3, 6):
        return

    import asyncio
    count = 0
    async def wait_for_tqdm_close(x):
        nonlocal count
        async for _ in trange(x):
            # https://github.com/tqdm/tqdm/issues/445
            # https://github.com/tqdm/tqdm/issues/496
            # the .update() function returns a reference to the object
            # and can be used to chain calls,
            # eg. .update().set_description()
            tqdm.update().set_description(_)
            count += 1
            await asyncio.sleep(0.05)


# Generated at 2022-06-24 09:38:59.662009
# Unit test for function trange
def test_trange():  # pragma: no cover
    try:
        from tqdm.utils import _term_move_up
    except ImportError:
        _term_move_up = None

    if _term_move_up is None:
        return
    from datetime import datetime
    from tqdm import tqdm
    from time import sleep

    def fib(n):
        a, b = 0, 1
        for i in tqdm(range(n), desc='outer'):
            sleep(0.01)
            for j in trange(n, desc='inner'):
                sleep(0.001)
                a, b = b, a + b
        return b

    start = datetime.now()
    fib(10)
    print(datetime.now() - start)
    # wait for nested progress bars to close
   

# Generated at 2022-06-24 09:39:03.200675
# Unit test for function trange
def test_trange():
    """Test function trange"""
    list(trange(3))
    list(trange(3, 1))
    list(trange(3, 3))
    list(trange(3, 2, -1))
    list(trange(int(3e6)))
    return


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:39:14.189954
# Unit test for function trange
def test_trange():
    import time
    from .std import FormatCustomText
    from .utils import _supports_unicode, _range

    # Simple `trange` test
    for _ in trange(3, desc='Trange test: '):
        time.sleep(0.1)
    for _ in trange(3, desc='Trange test: ', leave=True):
        time.sleep(0.1)

    # Test as `range` function
    for i in trange(*_range(3)):
        if i in [1, 2]:
            time.sleep(0.1)
    for i in trange(*_range(0)):
        raise AssertionError  # pragma: no cover

# Generated at 2022-06-24 09:39:24.465169
# Unit test for function trange
def test_trange():
    from .std import format_sizeof
    from .utils import get_bar_desc
    from .utils import get_miniters
    from .utils import mininterval
    from .utils import miniters
    from .utils import format_interval
    import gc
    import io
    import os
    import time
    import sys

    # Prepare test
    io_max_len = io.DEFAULT_BUFFER_SIZE
    old_mininterval = mininterval
    # On Windows, time.sleep() can take up to ~19ms,
    # thus we must use an higher value
    mininterval = max(0.1, mininterval)

    # Unit test

# Generated at 2022-06-24 09:39:35.343020
# Unit test for function trange
def test_trange():
    """
    Test for trange
    """
    from .std import tqdm
    from .utils import _term_move_up
    with tqdm(disable=True) as t:
        assert trange(3) == tqdm(range(3))
        assert str(trange(3)) == str(tqdm(range(3)))
        assert repr(trange(3)) == repr(tqdm(range(3)))

        t.close()

        if t.file.isatty():
            # If a file is a TTY, then the return value of
            # trange is a tqdm instance
            assert isinstance(trange(3), tqdm)
            # Test that the TTY is not broken
            # The following commands don't work in a pipe on Windows
            t.write('test')
           

# Generated at 2022-06-24 09:39:38.353710
# Unit test for function trange
def test_trange():
    """
    Test for `trange()` function.
    """
    from .tests import trange_test
    trange_test()



# Generated at 2022-06-24 09:39:43.171270
# Unit test for function trange
def test_trange():
    """Test function for trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2, 3)) == [2]
    assert list(trange(2, 4, 2)) == [2]
    assert list(trange(10, 1, -1)) == [10, 9, 8, 7, 6, 5, 4, 3, 2]
    assert list(trange(10, 1, -1, desc='desc', total=8)) == \
        [10, 9, 8, 7, 6, 5, 4, 3]

# Generated at 2022-06-24 09:39:45.969587
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`
    """
    results = []
    for i in trange(3, 1, -1):
        results.append(i)
    assert results == [3, 2, 1]

# Generated at 2022-06-24 09:39:47.482963
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .tests.tests_tqdm import pretest_posttest
    with pretest_posttest():
        list(trange(3))

# Generated at 2022-06-24 09:39:50.062146
# Unit test for function trange
def test_trange():
    """
    $ python -m tqdm.auto
    """
    for _ in trange(10, desc='desc', leave=True):
        pass

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:39:51.756085
# Unit test for function trange
def test_trange():
    """Tests trange"""
    list(trange(3))


# Generated at 2022-06-24 09:39:53.940148
# Unit test for function trange
def test_trange():
    """Tests for function trange"""
    for i in trange(4):
        assert i in range(4)

# Generated at 2022-06-24 09:39:56.684059
# Unit test for function trange
def test_trange():
    """Test for `trange`."""
    with tqdm(leave=False, total=2) as pbar:
        assert len(list(pbar)) == 2

# Generated at 2022-06-24 09:39:58.035315
# Unit test for function trange
def test_trange():
    for _ in trange(5, desc='trange'):
        pass

# Generated at 2022-06-24 09:40:00.605948
# Unit test for function trange
def test_trange():
    """Mock range returning list of iterable"""
    for _trange in (notebook_trange, trange):
        assert list(_trange(10)) == list(range(10))

# Generated at 2022-06-24 09:40:01.656714
# Unit test for function trange
def test_trange():
    """Test the function trange"""
    trange(5)

# Generated at 2022-06-24 09:40:12.405479
# Unit test for function trange
def test_trange():
    from .autonotebook import trange as real_trange
    from .asyncio import trange as asyncio_trange

    def _test_trange(trange, real_trange):
        assert isinstance(trange(5), real_trange(5))
        assert isinstance(trange(5), asyncio_trange(5))

    if sys.version_info[:2] < (3, 6):
        _test_trange(trange, real_trange)
    else:
        import asyncio

# Generated at 2022-06-24 09:40:16.325763
# Unit test for function trange
def test_trange():
    import unittest

    class Tests(unittest.TestCase):
        def test(self):
            """Test function trange"""
            t = trange(2)
            self.assertEqual(t, range(2))
            self.assertEqual(t, list(tqdm(range(2))))
            self.assertEqual(type(t), type(tqdm(range(2))))

    unittest.main(argv=[''], verbosity=2, exit=False)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-24 09:40:25.869150
# Unit test for function trange
def test_trange():
    """Tests ``trange()`` (really just sanity-checks against ``tqdm()``)."""
    from .std import tqdm
    from .utils import bytes
    from .utils import console_to_str

    # Test single element
    for x in [
        trange(1),
        trange(1, desc="desc", leave=True),
        trange(1, total=1),
        trange(1, position=0),
        trange(1, file=sys.stdout, desc="desc"),
        trange(1, dynamic_ncols=True, desc="desc"),
        trange(1, smoothing=0),
        trange(1, bar_format="{l_bar}"),
    ]:
        assert isinstance(x, tqdm)
        assert next(x) == 0


# Generated at 2022-06-24 09:40:35.346295
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert trange(1)
    assert trange(1, 1)
    assert trange(1, 1, 1)
    trange(10, desc="default")
    trange(10, desc="auto", leave=False)
    trange(10, desc="auto", dynamic_ncols=True)
    trange(10, desc="auto", mininterval=0.1)
    trange(10, desc="auto", mininterval=0.1, ascii=True)
    for bar_format in ['{l_bar}', '{n}/{total_fmt} [{elapsed}<{remaining}]']:
        trange(10, bar_format=bar_format, desc="custom")

# Generated at 2022-06-24 09:40:43.858496
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unittest for `trange`"""
    from .gui import tqdm
    from .utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in trange(10):
            pbar.update()
            # Equivalent to `pbar.update(1)`
    with tqdm(unit="B", unit_scale=True, unit_divisor=1024) as pbar:
        for i in trange(32):
            # Update and simulate a download with `sleep(0.01)`
            pbar.update(1024 * 16)  # 100% progress
            # Equivalent to `pbar.update(1024 * 16)`
            # Equivalent to `pbar.update(1024 * 16, 1024 * 16)`
            #

# Generated at 2022-06-24 09:40:47.414068
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    L = list()
    for _ in trange(10):
        L.append(1)
    assert L == [1] * 10
    for _ in trange(8, 10):
        L.append(1)
    assert L == [1] * 10 + [1] * 2

# Generated at 2022-06-24 09:40:54.315255
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Small unit test for function trange"""
    for _ in trange(4):
        for _ in trange(4, desc="(inner loop)", leave=False):
            for _ in trange(4, desc="(centre loop)", leave=False):
                for _ in trange(4, desc="(outer loop)", leave=False):
                    pass
            print("end of centre loop")
        print("end of inner loop")
    print("end of outer loop")
    print("\n*** Now with position ***\n")

# Generated at 2022-06-24 09:41:02.779888
# Unit test for function trange
def test_trange():  # pragma: no cover
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        import ipywidgets
        import tqdm as notebook_tqdm
        import tqdm._tqdm_notebook as _tqdm_notebook
        assert trange(0) == notebook_tqdm.trange(0)  # pylint: disable=E1101
        assert trange(3) == tqdm(range(3))
        assert trange(3) == _tqdm_notebook.tqdm(range(3))  # pylint: disable=E1101
        assert isinstance(trange(3, disable=True)._nested_tqdm, ipywidgets.widgets.widget_int.IntProgress)



# Generated at 2022-06-24 09:41:12.184553
# Unit test for function trange
def test_trange():
    """Test trange(...)"""
    from .utils import _supports_unicode
    # pylint: disable=import-outside-toplevel
    from .gui import tqdm as gui_tqdm

    __test__ = not any([
        __name__ == "__main__",
        sys.argv[0].endswith("pytest"),
        "pytest" in sys.argv[0],
        "__pypy__" in sys.builtin_module_names,
    ])  # unit test

    total = 100 if __test__ else 10
    if _supports_unicode():
        for _ in trange(total):
            _ += 1
    for _ in pytest.raises(TypeError):
        trange(total, file=sys.stdout)

# Generated at 2022-06-24 09:41:15.583976
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    for _ in trange(10):
        pass
    for _ in trange(10, 10):
        pass
    for _ in trange(10, 10, 10):
        pass

# Generated at 2022-06-24 09:41:20.468024
# Unit test for function trange
def test_trange():
    """$ python -m tqdm.auto --test-trange"""
    from .tqdm import trange
    from .utils import _term_move_up

    with trange(10) as t:
        for i in t:
            if i == 5:
                break
            t.set_description("training")
            t.set_postfix(loss=i * i, gen=i + 1)
        t.set_description("training complete")
        t.set_postfix(loss='n/a', gen=i + 1)
        _term_move_up()

    with trange(10) as t:
        for i in t:
            if i == 5:
                break
            t.set_description("training")
            t.set_postfix(loss=i * i, gen=i + 1)


# Generated at 2022-06-24 09:41:22.130503
# Unit test for function trange
def test_trange():
    """Test trange function"""
    for _ in trange(4):
        pass


# Generated at 2022-06-24 09:41:33.997633
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .gui import tqdm_gui
    for _tqdm in [tqdm, tqdm_gui]:
        list(map(str, _tqdm(trange(5)))) == ['0', '1', '2', '3', '4']
        assert list(map(str, _tqdm(trange(5)))) == ['0', '1', '2', '3', '4']
        assert list(map(str, _tqdm(trange(1, 7)))) == ['1', '2', '3', '4', '5', '6']
        assert list(map(str, _tqdm(trange(1, 11, 2)))) == ['1', '3', '5', '7', '9']

# Generated at 2022-06-24 09:41:39.099555
# Unit test for function trange
def test_trange():
    """Test routine for trange"""
    data = list(trange(3))
    data = list(trange(3, 2))
    data = list(trange(3, 2, 1))
    data = list(trange(2, 3))
    data = list(trange(2, 3, 1))
    data = list(trange(3, 2, -1))
    data = list(trange(2, 3, -1))
    data = list(trange(3, 2, 1, unit="a", ascii=True))
    data = list(trange(3, 2, 1, ascii=True))
    try:
        data = list(trange(3, 2, 0))
        assert(False)
    except ValueError:
        pass


# Generated at 2022-06-24 09:41:43.706916
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(0)) == []
    assert list(trange(10, 2, -3)) == list(range(10, 2, -3))


# Generated at 2022-06-24 09:41:46.213032
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    assert list(trange(5)) == list(notebook_trange(5))
    assert list(trange(5)) == list(range(5))

# Generated at 2022-06-24 09:41:50.835426
# Unit test for function trange
def test_trange():
    """Simple sanity check."""
    from .utils import _term_move_up

    for _ in trange(3, desc='0'):
        for _ in trange(4, desc='1'):
            for _ in trange(5, desc='2'):
                print('.', end='')
            print()
        print()
    # Move cursor back to line 4
    print(_term_move_up() + _term_move_up())


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:42:01.189402
# Unit test for function trange
def test_trange():
    """Tests that the trange function works"""
    import re

    def in_notebook():
        try:
            shell = get_ipython().__class__.__name__
            if (shell == "ZMQInteractiveShell"):  # Jupyter notebook or qtconsole?
                return True
            elif (shell == "TerminalInteractiveShell"):  # Terminal running IPython?
                return False
            else:
                return False  # Other type (?)
        except NameError:
            return False  # Probably standard Python interpreter

    max_t = 8
    if not in_notebook():
        max_t = 10

# Generated at 2022-06-24 09:42:04.495334
# Unit test for function trange
def test_trange():
    """
    Tests that trange(...) is equivalent to tqdm(range(...))
    """

# Generated at 2022-06-24 09:42:12.891211
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    from pytest import raises
    # Default range(10)
    assert list(trange()) == list(range(10))
    # Range with arguments
    assert list(trange(15, 25, 2)) == list(range(15, 25, 2))
    assert list(trange(25, 15, -2)) == list(range(25, 15, -2))
    # Check for consistency with tqdm function
    assert list(trange()) == list(tqdm())
    assert list(trange(15, 25, 2)) == list(tqdm(range(15, 25, 2)))
    assert list(trange(25, 15, -2)) == list(tqdm(range(25, 15, -2)))
    # Check for errors

# Generated at 2022-06-24 09:42:19.944939
# Unit test for function trange
def test_trange():
    """Tests tqdm.auto.trange"""
    for _range in [
        list(range(0)),
        [],
        [0],
        list(range(10)),
        list(range(-10, 10)),
        list(range(10)),
        list(range(-10, 10)),
    ]:
        try:
            for _i in trange(len(_range)):
                assert _range[_i] == _i, "%r != %r" % (_range[_i], _i)
        except Exception as _e:
            raise AssertionError("Failure while testing _range == %r" % (_range,)) from _e

if __name__ == "__main__":
    sys.exit(test_trange())

# Generated at 2022-06-24 09:42:28.132655
# Unit test for function trange
def test_trange():
    " Unit test for trange "
    from ._utils import _range
    assert _range(3, 0, -1) == list(trange(3, 0, -1))

    try:
        import asyncio.coroutines
        if sys.version_info[:2] >= (3, 6):
            from .asyncio import tqdm_asyncio as asyncio_tqdm
            assert tqdm == asyncio_tqdm
            assert _range(3, 0, -1) == list(trange(3, 0, -1))
    except ImportError:
        pass

# Generated at 2022-06-24 09:42:29.213964
# Unit test for function trange
def test_trange():
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-24 09:42:31.986430
# Unit test for function trange
def test_trange():
    """Test that trange function works

    The function works by checking that the length of the range and the number
    of iterations are equal.
    """
    range_len = 5
    for _ in trange(range_len):
        pass
    assert _ + 1 == range_len

# Generated at 2022-06-24 09:42:33.858462
# Unit test for function trange
def test_trange():
    """Test function trange for tqdm.auto"""
    for _ in trange(3):
        pass

# Generated at 2022-06-24 09:42:40.319584
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from nose.tools import raises
    from inspect import isfunction

    assert isfunction(trange)
    # assert trange(4).__next__() == 0
    for _ in trange(4, desc='Testing function trange'):
        pass
    for _ in trange(4, desc='Testing function trange', leave=True):
        pass
    with raises(TypeError):
        trange(4, position=1)
    with raises(TypeError):
        trange(4, ascii=1)

# Generated at 2022-06-24 09:42:44.734398
# Unit test for function trange
def test_trange():
    with tqdm(total=1) as t:
        t.update(0)
        for i in trange(10, desc='desc', leave=False):
            assert t.n == i
            t.update()


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-24 09:42:53.279356
# Unit test for function trange
def test_trange():
    """
    Tests `trange`
    """
    from .std import tqdm
    from .asyncio import tqdm as asynciotqdm

    for n in trange(3):
        assert n in [0, 1, 2]
    for n in trange(3):
        assert n in [0, 1, 2]
        break
    for n in trange(3, desc="trange", unit="t"):
        assert n in [0, 1, 2]
    for n in tqdm(range(3), desc="tqdm"):
        assert n in [0, 1, 2]
    for n in asynciotqdm(range(3), desc="asynciotqdm"):
        assert n in [0, 1, 2]

# Generated at 2022-06-24 09:42:55.397844
# Unit test for function trange
def test_trange():
    """Run function trange"""
    assert list(tqdm(range(10))) == list(range(10))



# Generated at 2022-06-24 09:43:01.985324
# Unit test for function trange
def test_trange():
    """
    Test that trange forwards arguments to tqdm.
    """
    tqdm_args = [0, 1, 2, 3]
    trange_args = {"total": 4}
    # noinspection PyUnusedLocal
    def mock_tqdm(*args, **kwargs):
        """Mock tqdm that checks args and kwargs"""
        assert kwargs == trange_args
        assert list(args) == tqdm_args
    tqdm.tqdm = mock_tqdm
    trange(*tqdm_args, **trange_args)

# Generated at 2022-06-24 09:43:08.457362
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import trange as __std_trange, tqdm as __std_tqdm
    from .asyncio import tqdm as __asyncio_tqdm

    assert tqdm.__name__ in (__std_tqdm.__name__, __asyncio_tqdm.__name__)
    assert trange.__name__ == __std_trange.__name__

# Generated at 2022-06-24 09:43:15.401576
# Unit test for function trange
def test_trange():
    """Test for trange"""
    import sys
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        if sys.version_info[0] < 3:
            from itertools import izip_longest as zip_longest
        else:
            from itertools import zip_longest

        for a, b in zip_longest(trange(3), [0, 1, 2]):
            assert a == b



# Generated at 2022-06-24 09:43:23.441147
# Unit test for function trange
def test_trange():
    """ Test function trange """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .std import tqdm as std_tqdm
        from .autonotebook import tqdm as notebook_tqdm

    exp_mro = (
        "<class 'tqdm.auto.trange'>" if notebook_tqdm != std_tqdm
        else "<class 'tqdm.asyncio.tqdm'>"
    )

    def _test(tr, mro):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            from .std import tqdm as std_tqdm

        assert isinstance(tr, trange)
        assert repr(type(tr))

# Generated at 2022-06-24 09:43:33.967628
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .utils import _version_check
    from .std import TqdmExperimentalWarning, TqdmDeprecationWarning
    from .asyncio import tqdm as asyncio_tqdm
    from .std import tqdm as std_tqdm
    from .autonotebook import tqdm as notebook_tqdm

    legacy = _version_check(sys.version_info, "trange", (3, 6)) < ((3, 6),)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)

        assert trange(10)[-1] == 9
        assert trange(10)[:3] == [0, 1, 2]


# Generated at 2022-06-24 09:43:34.702688
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(3):
        pass

# Generated at 2022-06-24 09:43:37.870670
# Unit test for function trange
def test_trange():
    """Smoke test"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 2)) == [1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 4, 2)) == [1, 3]
    assert list(trange(4, 1, -2)) == [4, 2]

# Generated at 2022-06-24 09:43:42.494348
# Unit test for function trange
def test_trange():
    from .std import tqdm_deprecate

    with tqdm_deprecate.nogui():
        assert list(trange(3, desc="Test trange")) == [0, 1, 2]
        assert list(trange(3, 4, desc="Test trange")) == [3]

# Generated at 2022-06-24 09:43:51.452431
# Unit test for function trange
def test_trange():
    "Unit test for trange"
    import sys

    for _ in trange(3, desc='Unicode', ascii=True):
        _
    for _ in trange(2, desc="bytes".encode("ascii"), ascii=True):
        _

    # checks that `desc` is actually displayed
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        for i in trange(10, desc="desc"):
            assert i != 3, "desc not displayed"

    # checks that `desc` is actually displayed
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        for i in trange(10, desc=u"desc"):
            assert i != 3, "desc not displayed"

   

# Generated at 2022-06-24 09:43:57.411044
# Unit test for function trange
def test_trange():
    from nose import tools as nt
    nt.assert_equal(list(trange(3)), list(range(3)))
    with nt.assert_raises(TypeError):
        trange(3, 2)
    nt.assert_equal(list(trange(3, 2, -1)), list(range(3, 2, -1)))

# Generated at 2022-06-24 09:44:00.817186
# Unit test for function trange
def test_trange():
    """Test ``trange``."""
    from collections import Counter
    list_ = list(trange(10))
    assert list_ == list(range(10))
    assert Counter(map(type, list_)) == Counter([int])

# Generated at 2022-06-24 09:44:05.319049
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    list(tqdm(trange(10)))
    list(tqdm(trange(2, 10)))
    list(tqdm(trange(2, 10, 2)))



# Generated at 2022-06-24 09:44:13.665775
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass
    for _ in trange(4, desc='test'):
        pass
    for _ in trange(4, leave=True):
        pass
    for _ in trange(4, total=6):
        pass
    for _ in trange(4, total=6, desc='test'):
        pass
    for _ in trange(4, total=6, leave=True):
        pass
    for _ in trange(4, total=6, miniters=2):
        pass
    for _ in trange(4, total=6, miniters=2, desc='test'):
        pass
    for _ in trange(4, total=6, miniters=2, leave=True):
        pass

# Generated at 2022-06-24 09:44:23.291808
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from ._utils import _range
    assert list(trange(3)) == list(_range(3))
    assert list(trange(3, 3)) == list(_range(3, 3))
    assert list(trange(3, 3, 3)) == list(_range(3, 3, 3))
    assert list(trange(3, 1, -1)) == list(_range(3, 1, -1))
    assert list(trange(3, -1, -1)) == list(_range(3, -1, -1))
    assert list(trange(3, -1, -3)) == list(_range(3, -1, -3))
    assert list(trange(3, 1, -3)) == list(_range(3, 1, -3))

# Generated at 2022-06-24 09:44:31.107059
# Unit test for function trange
def test_trange():
    """Test trange()"""
    from .tests import coverage

    total = 100
    progress = trange(total)
    assert progress.total == total
    for _ in progress:
        pass
    progress.close()

    progress = trange(total, desc='Test')
    assert progress.total == total
    assert progress.desc == 'Test'
    for _ in progress:
        pass
    progress.close()

    cov = coverage()
    if cov:
        cov.stop()
        cov.save()
        cov.html_report()
        cov.xml_report()
        cov.report()
        cov.erase()

# Generated at 2022-06-24 09:44:34.818722
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange`.
    """
    from .tqdm_gui import tqdm
    from time import sleep

    with tqdm(total=3) as pbar:
        for _ in trange(3):
            sleep(0.01)
            pbar.update()



# Generated at 2022-06-24 09:44:38.589604
# Unit test for function trange
def test_trange():  # pylint: disable=missing-docstring
    from .std import CheckUpdateEveryIter

    total = 10
    with CheckUpdateEveryIter(total) as cu:
        for _ in trange(total, ascii=True, ncols=150, desc="Progress"):
            cu.iter_complete()

    total = 10
    with CheckUpdateEveryIter(total) as cu:
        for _ in trange(total, ascii=True, ncols=150, desc="Progress"):
            cu.ncols = 100
            cu.iter_complete()

# Generated at 2022-06-24 09:44:44.237006
# Unit test for function trange
def test_trange():
    """
    Tests if trange is equivalent to tqdm(range(...)).

    Running `python -m tqdm.auto` from a terminal.
    """
    import time
    from .auto import trange, tqdm
    for _ in trange(5):
        time.sleep(0.1)
    print()
    for _ in tqdm(range(10)):
        time.sleep(0.1)
    print()


# Generated at 2022-06-24 09:44:47.596430
# Unit test for function trange
def test_trange():
    from .tqdm import trange
    from time import sleep
    for _ in trange(4, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', leave=False):
            for _ in trange(50):
                sleep(0.01)

# Generated at 2022-06-24 09:44:56.127059
# Unit test for function trange
def test_trange():
    for _ in trange(3):
        assert True
    for _ in trange(10, 0):
        assert True
    for _ in trange(10, 3):
        assert True
    for _ in trange(10, 3, -1):
        assert True
    for _ in trange(10, 3, 2):
        assert True
    for _ in trange(10, 3, -2):
        assert True
    for _ in trange(10, 3, 2, None):
        assert True


if __name__ == '__main__':
    """
    In case this file is run directly as main, run tests.
    """
    import doctest
    doctest.testmod()
    test_trange()

# Generated at 2022-06-24 09:45:01.095301
# Unit test for function trange
def test_trange():  # pragma: no cover
    # Check manually and not via `__main__` (coverage bug)
    import sys
    from tqdm.auto import tqdm, trange

    previous_value = tqdm._instances.value  # pylint: disable=protected-access
    for _ in trange(10):
        sys.stderr.write('.')
    assert tqdm._instances.value == previous_value  # pylint: disable=protected-access
    print()

if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-24 09:45:06.701544
# Unit test for function trange
def test_trange():
    """
    From the documentation:

    >>> for i in trange(20, disable=None):
    ...     pass
    """
    import sys
    import time
    from .utils import format_sizeof
    from .std import tqdm

    text = None
    for _ in range(2):
        if text is not None:
            time.sleep(0.5)
        for i in trange(20, disable=None):
            if text is None:
                text = str(tqdm)
            # ensure it's a trange bar
            assert text == str(tqdm)
            assert 'desc' not in tqdm.format_dict
            assert 'ncols' not in tqdm.format_dict

            tqdm.set_description("Loading...")
            tqdm.set_postfix_str

# Generated at 2022-06-24 09:45:09.538074
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(5)) == [0, 1, 2, 3, 4]
    assert list(trange(5, step=2)) == [0, 2, 4]
    assert list(trange(5, 0, -1)) == [5, 4, 3, 2, 1]

# Generated at 2022-06-24 09:45:19.744042
# Unit test for function trange
def test_trange():
    with warnings.catch_warnings():
        # Disable python 3.7 deprecation warnings
        warnings.simplefilter("ignore")
        from unittest import TestCase, mock
        from unittest.mock import patch

        class Testsubclass(TestCase):
            def setUp(self):
                self.maxDiff = None  # long messages

            @patch("time.sleep", return_value=None)
            def test_trange(self, _):
                with patch("sys.stderr", new=mock.MagicMock()) as fake_stderr:
                    trange(0, 1)

                expected_stderr = """\x1b[?25l    \x1b[?25h\n"""

# Generated at 2022-06-24 09:45:28.954223
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import trange
    for _ in trange(10):
        pass
    for _ in trange(10, 0):
        pass
    for _ in trange(10, 0, -1):
        pass
    for _ in trange(10, 0, -1, leave=False):
        pass
    for _ in trange(10, 0, -1, desc="test_range", unit="it"):
        pass
    for _ in trange(10, 0, -1, desc="test_range", unit="it",
                    disable=None):
        pass

# Generated at 2022-06-24 09:45:31.803995
# Unit test for function trange
def test_trange():
    """Basic sanity check"""
    import time
    # pylint: disable=unused-variable
    t0 = time.time()
    for i in trange(10):
        time.sleep(0.1)
    t = time.time() - t0

    assert round(t, 6) == 1.0, "trange(10) evaluation too slow"

# Generated at 2022-06-24 09:45:33.669524
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    for n in trange(3):
        pass


# Generated at 2022-06-24 09:45:36.303908
# Unit test for function trange
def test_trange():
    """Test function trange"""
    lst = list(trange(10))
    assert lst == list(range(10))

# Generated at 2022-06-24 09:45:44.304335
# Unit test for function trange
def test_trange():
    """Test `tqdm.auto.trange`."""
    from .std import trange
    for args in [
        [],
        [10],
        [10, 2],
        [10, 2, 3],
        [10, 2, 3, 2],
    ]:
        for a in [1, 2, 3]:
            # tqdm.auto.trange
            r_auto = trange(*args, **{str(a): a})
            r_std = tuple(x * a for x in args)
            assert r_auto == r_std
    for a in [1, 2, 3]:
        # tqdm.auto.trange
        r_auto = trange(**{str(a): a})

# Generated at 2022-06-24 09:45:51.728288
# Unit test for function trange
def test_trange():
    """Test trange on Python2.7, 3.6, 3.7"""
    list(trange(0))
    assert list(trange(10)) == list(range(10))
    assert list(trange(1, 2)) == list(range(1, 2))
    assert list(trange(1, 5, 2)) == list(range(1, 5, 2))
    assert list(trange(5, step=3)) == list(range(5, step=3))
    assert list(trange(5, 2, step=3)) == list(range(5, 2, step=3))