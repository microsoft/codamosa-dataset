

# Generated at 2022-06-22 04:43:14.896051
# Unit test for function trange
def test_trange():
    """
    Test trange function
    """
    assert sum(trange(10)) == 45
    assert list(trange(2, 3)) == [2]
    assert list(trange(2, 3, 2)) == [2]
    assert list(trange(2, 2)) == []
    assert list(trange(0)) == []
    assert list(trange(-3, 3, 2)) == [-3, -1, 1]
    assert sum(trange(0, 10, 2)) == sum(range(0, 10, 2))
    assert tqdm(trange(1, 3)).__next__() == 1
    assert tqdm(trange(1, 3), 'abcd').__next__() == 1
    assert tqdm(trange(1, 3), ascii='def').__next__()

# Generated at 2022-06-22 04:43:17.048548
# Unit test for function trange
def test_trange():
    """Test trange()"""
    assert tqdm(range(10)) == trange(10)

# Generated at 2022-06-22 04:43:28.834327
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .utils import WeakSet

    assert tqdm is not None

    class TqdmTypeMock(tqdm):  # pylint: disable=abstract-method
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.seq = args[0]

    TqdmTypeMock.__bases__ = (WeakSet,)
    tqdm_instances = TqdmTypeMock()

    trange(10, desc="desc", disable=False)
    assert len(tqdm_instances) == 1
    assert tqdm_instances.args[0] is range(10)

    trange(0)
    assert len(tqdm_instances) == 2
    assert t

# Generated at 2022-06-22 04:43:36.698320
# Unit test for function trange
def test_trange():
    """ Verifies the trange function """
    # Test case for trange
    exp_list = list(range(10))
    for case in (list(trange(10)), list(trange(0))):
        assert case == exp_list

    exp_list = list(range(10, 0, -1))
    for case in (list(trange(10, 0, -1)), list(trange(0))):
        assert case == exp_list

# Generated at 2022-06-22 04:43:42.068679
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .auto import trange
    from .std import tqdm
    assert trange == tqdm.__wrapped__
    assert tqdm.default_miniters == 10
    assert tqdm.__all__ == ['tqdm', 'trange']
    try:
        n = 0
        for _ in trange(0, leave=True, mininterval=0.1):
            n += 1
            if n == 100:
                break
    except Exception as e:
        raise (e)

# Generated at 2022-06-22 04:43:52.359029
# Unit test for function trange
def test_trange():
    from .utils import format_sizeof
    import time
    import platform
    import os

    print("Python version:", platform.python_version())
    print("tqdm version:",
          ".".join([str(x) for x in __import__("tqdm").tqdm.__version__]))
    print("Python location:", os.path.dirname(sys.executable))
    print("Python encoding:", sys.getdefaultencoding())
    print("Platform:", sys.platform)

    tqdm.monitor_interval = 0

    with tqdm.external_write_mode():
        r = trange(10)
        for _ in r:
            time.sleep(0.1)

    # Basic usage

# Generated at 2022-06-22 04:44:01.429026
# Unit test for function trange
def test_trange():
    from .std import trange

    class TqdmNoAscii(_tqdm):
        def format_meter(self, n, total, elapsed):
            return "test"

    t = TqdmNoAscii(total=10)
    _ = list(t(range(10)))

    t = TqdmNoAscii(total=10, ascii=True)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        _ = list(t(range(10)))

# Generated at 2022-06-22 04:44:10.053661
# Unit test for function trange
def test_trange():
    """Test for the trange function."""
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(0, 4, 2)) == [0, 2]
    assert list(trange(0, 5, 2)) == [0, 2, 4]
    assert list(trange(0, 2, 0.1)) == [0.0, 0.1, 0.2, 0.3, 0.4, 0.5,
                                       0.6, 0.7, 0.8, 0.9, 1.0, 1.1,
                                       1.2, 1.3, 1.4, 1.5, 1.6, 1.7,
                                       1.8, 1.9]

# Generated at 2022-06-22 04:44:14.504749
# Unit test for function trange
def test_trange():
    """Runs `trange` test"""
    obj = trange(3, 4)
    _ = list(obj)
    # Test for equality with the manual test
    try:
        obj = notebook_trange(3, 4)
    except:
        pass
    else:
        assert list(obj) == list(trange(3, 4))

# Generated at 2022-06-22 04:44:17.499210
# Unit test for function trange
def test_trange():
    """Unit test"""
    res = list(trange(10, desc='test'))
    assert res == list(range(10))