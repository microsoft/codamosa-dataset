

# Generated at 2022-06-22 04:43:07.600684
# Unit test for function trange
def test_trange():
    """
    Test for function `tqdm.auto.trange`.
    """
    it = trange(0)

    assert isinstance(it, tqdm)
    it.__next__()
    assert it.close() is None

# Generated at 2022-06-22 04:43:16.373477
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    assert list(trange(0)) == []
    assert list(trange(2)) == [0, 1]
    assert list(trange(0, 2)) == [0, 1]
    assert list(trange(2)) == list(range(2))
    assert list(trange(0, 2, 1)) == list(range(0, 2, 1))
    assert list(trange(0, 2, 1, None, None, True, None, 1, 'ascii')) \
        == list(range(0, 2, 1))

# Generated at 2022-06-22 04:43:18.656754
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass
    for _ in trange(4):
        pass

# Generated at 2022-06-22 04:43:22.715957
# Unit test for function trange
def test_trange():
    tr = trange(3, 4, 7j, bar_format="{l_bar}{bar}{r_bar}")
    for _ in tr:
        tr.set_description("Test")
        pass
    assert str(tr)
    del tr
    assert not tr

# Generated at 2022-06-22 04:43:34.479841
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    from .std import get_effective_n
    from .std import format_interval as fi
    from .std import format_meter as fm


# Generated at 2022-06-22 04:43:43.267194
# Unit test for function trange
def test_trange():
    from .utils import _supports_unicode
    iteration = 1000
    with trange(iteration) as t:
        for _ in t:
            pass

    assert(t.n == iteration)

    with trange(iteration, mininterval=0.1) as t:
        for _ in t:
            pass

    with trange(iteration, mininterval=-1) as t:
        for _ in t:
            pass
        assert(t._miniters == 1)  # pylint: disable=protected-access

    if not _supports_unicode():  # pragma: no cover
        with trange(iteration) as t:
            for _ in t:
                pass

        with trange(0) as t:
            for _ in t:
                pass


# Generated at 2022-06-22 04:43:46.351232
# Unit test for function trange
def test_trange():
    """Test for class trange on python3.6+"""
    from .std import tqdm
    from .std import trange

    assert trange(3) == tqdm(range(3))

# Generated at 2022-06-22 04:43:51.484109
# Unit test for function trange
def test_trange():
    for _ in trange(0):
        pass
    for _ in trange(1):
        pass
    for _ in trange(3):
        pass
    for _ in trange(3, 0, -1):
        pass
    for _ in trange(3, 0, -2):
        pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:44:00.610909
# Unit test for function trange
def test_trange():
    """
    Tests whether `trange` outputs the correct range.
    """
    from .utils import format_sizeof

    # Numbers from 1 to 10^5 (1 to 100 k)
    start = 1
    stop = 10 ** 5
    step = 1

    for i in trange(start, stop, step):
        assert start <= i < stop, \
            'trange(start, stop, step) failed from 1 to 100 k'
        if i >= stop - 1:
            print(format_sizeof(i))  # (optional) to display the last value

# Generated at 2022-06-22 04:44:03.264435
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    from .autonotebook import trange
    for _ in trange(1):
        pass

