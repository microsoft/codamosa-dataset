

# Generated at 2022-06-22 04:43:06.910823
# Unit test for function trange
def test_trange():
    """
    Tests whether function `trange` shortcut works.
    """
    from .std import tqdm
    assert tqdm(range(10)) == trange(10)



# Generated at 2022-06-22 04:43:18.705232
# Unit test for function trange
def test_trange():
    """Run `trange` for a simple test"""
    from .std import TqdmTypeError
    from .std import tnrange

    # Test trange
    assert (list(trange(1)) == list(tqdm(range(1))))
    assert (list(trange(1, 2)) == list(tqdm(range(1, 2))))
    assert (list(trange(1, 2, 3)) == list(tqdm(range(1, 2, 3))))

    # Test non-integer min & max
    assert (list(trange(1.0, 2.0, 0.5)) == list(tqdm(range(1, 2))))
    assert (list(trange(1.0, 2.0, 0.7)) == list(tqdm([1, 2])))

# Generated at 2022-06-22 04:43:22.292841
# Unit test for function trange
def test_trange():
    """
    Test :func:`trange` function
    """
    from tqdm.auto import trange

    i = 0
    for _ in trange(10):
        i += 1
    assert i == 10



# Generated at 2022-06-22 04:43:25.694109
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange`"""
    import time
    for _ in trange(10):
        time.sleep(0.1)



# Generated at 2022-06-22 04:43:38.079547
# Unit test for function trange
def test_trange():
    """
    Test for trange()
    """
    from random import shuffle

    l = list(range(100))
    shuffle(l)
    for i, c in enumerate(trange(10), 1):
        assert l[i * 10] == c
    for i, c in enumerate(trange(10, 50), 1):
        assert l[i * 10 + 40] == c
    for i, c in enumerate(trange(10, 50, 3), 1):
        assert l[i * 3 + 40] == c
    for i, c in enumerate(trange(10, -10, -3), 1):
        assert l[10 - i * 3] == c
    for i, c in enumerate(trange(100, 0, -3), 1):
        assert l[100 - i * 3] == c

# Generated at 2022-06-22 04:43:50.706769
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import os
    import time
    from .utils import _screen_size_wrapper
    from .gui import tqdm_gui

    if os.name == 'nt':
        width = _screen_size_wrapper().columns
    else:
        width = min(80, _screen_size_wrapper().columns)

    close_bar = not bool(int(os.getenv('TQDM_DISABLE_CLOSE_ON_FINISH', 0)))

# Generated at 2022-06-22 04:44:02.952745
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    All forms of trange should be tested, with and without a `leave` argument.
    """
    with notebook_tqdm(total=0) as pbar:
        assert pbar.n == 0
        assert pbar.total == 0
        assert pbar.leave
    with notebook_tqdm(total=0, leave=False) as pbar:
        assert pbar.n == 0
        assert pbar.total == 0
        assert not pbar.leave
    for leave in [True, False]:
        for total in [0, 100]:
            for kwargs in [{}, {"leave": leave}]:
                with notebook_tqdm(total=total, **kwargs) as pbar:  # pylint: disable=unused-variable
                    pass

# Generated at 2022-06-22 04:44:14.889144
# Unit test for function trange
def test_trange():
    from .std import tqdm
    from .utils import _term_move_up
    assert trange(0) == tqdm(range(0))
    pbar = trange(10, leave=True)
    assert pbar == tqdm(range(10), leave=True)
    pbar.close()
    # Test leave
    for i in tqdm(range(2), leave=True):
        print()  # add a line break
        for _ in tqdm(range(10), leave=True):
            pass
    out, err = capsys.readouterr()
    out = '\n'.join(out.splitlines()[1:])  # strip first line
    assert out + err == '\n' + _term_move_up() + '\r' * 10

# Generated at 2022-06-22 04:44:27.295493
# Unit test for function trange
def test_trange():
    """
    Smoke test for function trange
    """
    import os
    import sys
    import tempfile
    from io import StringIO

    for _ in trange(2, file=sys.stdout):
        pass

    with StringIO() as f:
        for _ in trange(2, file=f):
            pass
        x = f.getvalue()
    assert x == "\r  0%|          | 0/2 [00:00<?, ?it/s]\r100%|##########| 2/2 [00:00<00:00, 26.04it/s]\n"
    del f, x

    with StringIO() as f:
        for _ in trange(2, file=f, ncols=80):
            pass
        x = f.getvalue()

# Generated at 2022-06-22 04:44:32.373528
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Calling function trange with the same arguments as __call__
    """
    trange(0)
    trange(2, 1)
    trange(1, 2, 1, 0.01)
    trange(1, 2, 1, 0.01, None, None, False, None, False)
    trange(0, bar_format="abc{l_bar}def{bar}ghi")