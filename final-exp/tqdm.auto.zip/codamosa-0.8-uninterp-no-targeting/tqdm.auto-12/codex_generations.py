

# Generated at 2022-06-22 04:43:13.062018
# Unit test for function trange
def test_trange():
    '''Test function trange'''
    from .tqdm_gui import tgrange
    from .utils import _term_move_up
    for i in trange(4, desc='trange', leave=False):
        for _ in trange(3, desc='loop', leave=False):
            continue
    for i in tgrange(4, desc='trange', leave=False):
        for _ in tgrange(3, desc='loop', leave=False):
            continue
    for _ in trange(2, desc='justify', leave=False):
        pass
    sys.stderr.write(_term_move_up())

# Generated at 2022-06-22 04:43:24.937510
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function trange.
    """
    from ._tqdm_test import with_setup, pretest, posttest, _range

    @with_setup(pretest, posttest)
    def inner_test():
        """
        Unit test for function trange.
        """
        # list
        assert list(trange(3)) == [0, 1, 2]
        assert list(trange(1, 3)) == [1, 2]
        assert list(trange(1, 3, 2)) == [1]
        assert list(trange(3, 1)) == []
        assert list(trange(3, 1, -1)) == [3, 2]
        assert list(trange(3, 1, -2)) == [3]

# Generated at 2022-06-22 04:43:33.878053
# Unit test for function trange
def test_trange():
    """
    Simple test for `tqdm.auto.trange`.
    """
    from .utils import format_interval
    from .std import tqdm
    from time import sleep
    with tqdm(total=10) as fpbar:
        for i in trange(10):
            sleep(.1)
            fpbar.update()
    assert fpbar.n == 10
    t = format_interval(fpbar.n / fpbar.total_time)
    assert fpbar.desc.startswith("10/10")
    assert fpbar.desc.endswith("[" + t + "<")

# Generated at 2022-06-22 04:43:42.996125
# Unit test for function trange
def test_trange():
    """ Test function trange """
    from numbers import Number

    # 'desc' argument
    ret = trange(10, desc="desc1")
    assert len(ret) == 10
    assert ret.desc == "desc1"
    assert isinstance(ret, type(tqdm([])))

    # 'desc' argument with bar_format
    ret = trange(10, bar_format="{desc}", desc="desc1")
    assert len(ret) == 10
    assert ret.desc == "desc1"
    assert ret.bar_format == "{desc}"
    assert isinstance(ret, type(tqdm([])))

    # end
    assert isinstance(ret.n, Number)
    assert isinstance(ret.total, Number)
    assert ret.n == ret.total == 10

    # pos

# Generated at 2022-06-22 04:43:44.781597
# Unit test for function trange
def test_trange():
    """Unit test for function trange"""
    list(trange(5, desc="I'm a range!"))

# Generated at 2022-06-22 04:43:54.922726
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function `trange`.
    """
    from itertools import repeat, chain
    from numpy import mod, arange
    from numpy.random import normal

    # unittest
    assert list(trange(3, 100, 7, 0.01, 1)) == list(range(3, 100, 7))
    assert list(trange(3, 100, 7, 0.01, -1)) == list(reversed(range(3, 100, 7)))
    myrange = trange(10, -2, -0.001)  # pylint: disable=no-member
    assert list(tqdm(myrange)) == list(range(10, -2, -1))  # pylint: disable=no-member

# Generated at 2022-06-22 04:44:03.138857
# Unit test for function trange
def test_trange():
    from .std import TqdmDeprecationWarning
    import sys
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmDeprecationWarning)
        if sys.version_info[0] == 2:
            from itertools import izip as zip_
        else:
            from builtins import zip as zip_

        for i in trange(10, ncols=50):
            pass

# Generated at 2022-06-22 04:44:14.890774
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange:
    """
    from .std import FakeTqdmFile, tqdm
    from .utils import format_sizeof
    from .misc import _supports_unicode

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        out = FakeTqdmFile()
        trange(2, file=out)
        assert "\r" not in out.getvalue(), out.getvalue()
        trange(3, file=out, leave=True)
        assert "\r" in out.getvalue(), out.getvalue()

    # multi-line
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        out = FakeTqdmFile()
        tqdm

# Generated at 2022-06-22 04:44:23.779717
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Unit test for function trange"""
    # pylint: disable=C0103,W0612
    from .std import tqdm  # noqa
    list(tqdm(range(10)))
    list(tqdm(range(10), total=7))
    list(tqdm(range(10), mininterval=0.01, miniters=1, maxinterval=0.02))
    for _ in trange(4):
        for _ in trange(3):
            for _ in trange(6):
                pass

# Generated at 2022-06-22 04:44:27.026312
# Unit test for function trange
def test_trange():
    """Tests for function trange"""
    # Test that trange works in each environment
    trange(10)

if __name__ == '__main__':
    test_trange()