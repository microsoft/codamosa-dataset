

# Generated at 2022-06-22 04:43:14.981361
# Unit test for function trange
def test_trange():
    """test_trange"""
    from .utils import FormatCustomText, format_sizeof
    for _ in trange(10):
        pass

    for i in trange(10):
        assert i == i

    for i in trange(10, 30):
        assert i == i

    for i in trange(10, 30, 5):
        assert i == i

    with warnings.catch_warnings(record=True) as _ws:
        warnings.simplefilter("always")
        for i in trange(100, 10, -10):
            assert i == i
        assert len(_ws) == 0

    for i in trange(100, 10, -10, desc="dec") + trange(100, 10, -10, desc="dec", leave=False):
        assert i == i


# Generated at 2022-06-22 04:43:27.170403
# Unit test for function trange
def test_trange():
    from .std import tqdm
    from .std import _range as range

    sum, old_range = 0, range
    try:
        range = lambda *i, **kw: list(old_range(*i, **kw))
        for _ in trange(2):
            for i in trange(1, 5):
                sum += i
                if i == 3:
                    raise Exception
    finally:
        range = old_range

    assert sum == 7, sum
    assert tqdm.write.__self__.fp.getvalue().count("%|/") == 2, \
        tqdm.write.__self__.fp.getvalue().count("%|/")

# Generated at 2022-06-22 04:43:30.835445
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from .auto import trange
    from .std import tqdm

    for _ in trange(10):
        pass

    for _ in tqdm(range(10)):
        pass

# Generated at 2022-06-22 04:43:38.286053
# Unit test for function trange
def test_trange():
    """Test module function trange"""
    import tempfile
    with tempfile.TemporaryFile() as f:
        n = 100
        trange(n, file=f)
    from .tqdm import trange  # pylint: disable=reimported
    assert trange(n) == list(range(n))
    assert trange(n, desc="foo", leave=True) == list(range(n))

# Generated at 2022-06-22 04:43:41.416273
# Unit test for function trange
def test_trange():
    """Tests `from tqdm.auto import trange`"""
    list(trange(10))

# Generated at 2022-06-22 04:43:52.314998
# Unit test for function trange
def test_trange():
    """
    >>> trange(0)
    []
    >>> trange(1)
    [0]
    >>> trange(2)
    [0, 1]
    """
    # pylint: disable=pointless-statement,expression-not-assigned
    [i for i in trange(0)]  # Check for non-interactive
    [i for i in trange(1)]  # Check for non-interactive
    [i for i in trange(2)]  # Check for non-interactive
    [i for i in trange(3, 10)]  # Check for non-interactive
    [i for i in trange(5, 10, 2)]  # Check for non-interactive
    list(trange(5, 10, -2))  # Check for non-interactive (should return empty)
   

# Generated at 2022-06-22 04:44:04.341543
# Unit test for function trange
def test_trange():
    from .std import trange
    import io
    from .utils import _decode_preferred_encoding

    # Test if basic trange works
    with io.StringIO() as file:
        for _ in trange(3, file=file):
            pass

# Generated at 2022-06-22 04:44:15.045781
# Unit test for function trange
def test_trange():
    """Test function trange"""
    # Test notebook trange
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    filename = os.path.join(temp_dir, 'test_trange_notebook_tqdm.ipynb')

# Generated at 2022-06-22 04:44:25.574259
# Unit test for function trange
def test_trange():
    """
    Tests that trange works equivalently to tqdm(range(...)).
    """
    try:
        import numpy as np
    except ImportError:
        np = None

    def f():
        for _ in range(100):
            yield 1
    for x in (range(100), f(), np.arange(100) if np else range(100)):
        rng = trange(100, leave=False)
        rng2 = tqdm(x, leave=False)
        for i, (j, k) in enumerate(zip(rng, rng2)):
            assert i == j == k, "trange failed at {0}".format(i)

# Generated at 2022-06-22 04:44:28.189510
# Unit test for function trange
def test_trange():
    "Run trange unit test"
    for attr in __all__:
        globals()[attr]()

if __name__ == "__main__":
    test_trange()