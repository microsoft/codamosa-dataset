

# Generated at 2022-06-22 04:43:06.861284
# Unit test for function trange
def test_trange():
    l1 = list(range(10))
    l2 = list(trange(10))
    assert l1 == l2


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:14.337478
# Unit test for function trange
def test_trange():
    """`trange` should be a shortcut for `tqdm(range(*args), **kwargs)`"""
    from .std import trange as std_trange

    import sys
    if sys.version_info[:2] < (3, 6):
        from .autonotebook import trange as notebook_trange
        assert trange == notebook_trange
    else:
        from .asyncio import trange as asyncio_trange
        assert trange == asyncio_trange



# Generated at 2022-06-22 04:43:15.033870
# Unit test for function trange
def test_trange():
    """
    >>> test_trange()
    """
    assert trange(3) == [0, 1, 2]

# Generated at 2022-06-22 04:43:20.082417
# Unit test for function trange
def test_trange():
    """Test that trange forwards everything to tqdm"""
    with tqdm(unit="", smoothing=0, leave=False, disable=False) as pbar:
        assert pbar is trange(2, 3, 4, unit="", smoothing=0,
                              leave=False, disable=False)

# Generated at 2022-06-22 04:43:31.222153
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import _supports_unicode

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",
                                message='Attempting to set identical left==right')
        # Checking just `trange` should suffice, as it is just a wrapper
        # for `tqdm(xrange(10), ...)` and we're testing `tqdm`'s
        # automatic range construction
        assert list(trange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        assert list(trange(0)) == []

# Generated at 2022-06-22 04:43:36.817279
# Unit test for function trange
def test_trange():
    """
    Simple test to check if the output is the same as range
    """
    from tqdm.auto import trange
    import pytest
    out = list(trange(10))
    ref = list(range(10))
    assert out == ref

# Generated at 2022-06-22 04:43:39.807320
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    import time
    for i in trange(4, leave=True):
        for _ in trange(1000000):
            pass
        time.sleep(0.01)

# Generated at 2022-06-22 04:43:51.928931
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    import time
    from .std import tqdm

    trange = tqdm.trange

    list(tqdm([1], ncols=0, disable=None))
    list(tqdm([1], ncols=0, mininterval=0.1, disable=None))
    list(tqdm([1], ncols=0, disable=True, mininterval=0))
    list(tqdm([1], ncols=0, disable=True, mininterval=0.1))
    list(tqdm([1], ncols=0, disable=False, mininterval=0.1))

    assert '\r' not in str(tqdm(ncols=None, disable=True))

# Generated at 2022-06-22 04:44:04.088271
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    from nose.tools import assert_equal
    from sys import version_info

    if version_info[0] >= 3:
        from unittest.mock import patch
    else:
        from mock import patch

    with patch("sys.stdout", new=None):  # disable printing
        for _ in trange(4):
            pass
    with patch("sys.stdout", new=None):  # disable printing
        for _ in trange(10, 4):
            pass
    with patch("sys.stdout", new=None):  # disable printing
        for _ in trange(10, 3, -2):
            pass

# Generated at 2022-06-22 04:44:14.968128
# Unit test for function trange
def test_trange():
    """Test for trange"""
    try:  # pragma: no cover
        import numpy as np
    except ImportError:  # pragma: no cover
        return
    try:  # pragma: no cover
        from pytest import approx
    except ImportError:  # pragma: no cover
        try:  # pragma: no cover
            from unittest import mock
        except ImportError:  # pragma: no cover
            return
        else:  # pragma: no cover
            approx = mock.MagicMock()  # pylint: disable=invalid-name
