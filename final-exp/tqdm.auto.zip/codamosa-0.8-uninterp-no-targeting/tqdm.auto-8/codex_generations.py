

# Generated at 2022-06-22 04:43:09.812453
# Unit test for function trange
def test_trange():
    """Test trange function."""
    with tqdm(total=0) as nb:
        assert nb.total == 0
        nb.update(1)
        assert nb.n == 1

    # Ensure that trange accepts kwargs
    list(trange(10, desc="test trange"))


# unit test module
if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 04:43:21.329429
# Unit test for function trange
def test_trange():
    """
    Tests that trange works equivalently to tqdm(range())
    """
    # Test with 1 argument
    assert list(trange(5)) == list(tqdm(range(5), desc="1-arg"))

    # Test with 1 argument and custom `desc`
    assert list(trange(5, desc="mydesc")) == list(tqdm(range(5), desc="mydesc"))

    # Test with 2 arguments
    assert list(trange(3, 5)) == list(tqdm(range(3, 5), desc="2-arg"))

    # Test with 3 arguments
    assert list(trange(2, 5, 2)) == list(tqdm(range(2, 5, 2), desc="3-arg"))

    # Test with 1 argument and a custom callback

# Generated at 2022-06-22 04:43:25.362030
# Unit test for function trange
def test_trange():
    """Unit tests for `tqdm.auto.trange`."""
    trange(3)
    trange(10)
    trange(10, 0, -1)
    trange(10, 3)

# Generated at 2022-06-22 04:43:29.994335
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange` function.
    """
    from .utils import FormatStdin
    with FormatStdin('\r'):
        # pylint: disable=unused-variable
        for _ in trange(3, desc='A', mininterval=0.1, file=sys.stderr):
            pass

# Generated at 2022-06-22 04:43:41.248857
# Unit test for function trange
def test_trange():
    from .gui import tqdm
    from .utils import _range

    with tqdm(total=None) as pbar:
        for _ in trange(1000, desc="1st loop", leave=False,
                        bar_format="{l_bar}{bar}|"):
            pbar.update(10)
        for _ in trange(10, desc="2nd loop", leave=False,
                        bar_format="{l_bar}{bar}|"):
            pbar.update(1)
        # Check hold off
        for _ in trange(10, desc="loop", leave=False, mininterval=0.01,
                        bar_format="{l_bar}{bar}|"):
            pbar.update()

# Generated at 2022-06-22 04:43:46.256279
# Unit test for function trange
def test_trange():
    """Tests for trange and tqdm."""
    for _ in tqdm(range(2)):
        for __ in trange(3, desc='1st loop', leave=False):
            for ___ in trange(100, desc='2nd loop'):
                pass

# Generated at 2022-06-22 04:43:58.203003
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import format_interval
    import time

    # Test decorator
    @tqdm.func_wrapper
    def wrapped_range(*args, **kwargs):
        return list(range(*args, **kwargs))

    # Test function
    def wrapped_range2(*args, **kwargs):
        return list(range(*args, **kwargs))

    wrapped_range2 = tqdm.func_wrapper(wrapped_range2)

    for _ in tqdm(range(5), desc='outer', leave=False):
        for _ in trange(10000, desc='trange', leave=False):
            for _ in wrapped_range(10000, desc='func_wrapper', leave=False):
                time.sleep(0.0001)


# Generated at 2022-06-22 04:44:01.672821
# Unit test for function trange
def test_trange():
    """Test for `tqdm.auto.trange()`"""
    for i in trange(4):
        pass
    with tqdm(total=4) as t:
        for i in range(4):
            t.update()

# Generated at 2022-06-22 04:44:10.235575
# Unit test for function trange
def test_trange():
    "Test trange function"
    from .std import tqdm as std_tqdm
    from .gui import tqdm as gui_tqdm
    from .utils import _term_move_up
    from .utils import _range

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        for tqdm_cls in (std_tqdm, gui_tqdm):
            for _range in (range, _range):
                total = 4
                with tqdm_cls(total=total) as pbar:
                    for _ in trange(total):
                        pbar.update()
                    assert _range(total) == pbar.n


# Generated at 2022-06-22 04:44:18.102029
# Unit test for function trange
def test_trange():
    """
    Tests `trange`
    """
    from .std import PY3, range

    if PY3:
        range = range
    else:
        range = xrange

    assert list(trange(5)) == list(range(5))
    assert list(trange(5, 10)) == list(range(5, 10))
    assert list(trange(5, 10, 2)) == list(range(5, 10, 2))
    assert list(trange(5, 10, 2, desc='desc')) == list(range(5, 10, 2))
    assert list(trange(5, 10, 2, leave=True)) == list(range(5, 10, 2))
    assert list(trange(5, 10, 2, initial=2)) == list(range(5, 10, 2))

#