

# Generated at 2022-06-22 04:43:00.675089
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .tests import common_tests

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .autonotebook import tqdm as notebook_tqdm
        from .autonotebook import trange as notebook_trange
    from .asyncio import tqdm as asyncio_tqdm
    from .std import tqdm as std_tqdm

    # Test trange with all tqdms
    for tqdm_ in (notebook_tqdm, std_tqdm, asyncio_tqdm):
        common_tests.test_tqdm_init(trange, tqdm_)

    # Test trange twice
    common_tests.test_tqdm_init(trange)

# Generated at 2022-06-22 04:43:06.063505
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    Coverage: 100%
    """
    list(trange(10))
    list(trange(10, desc="Test trange"))
    assert "10it" in str(trange(10))
    assert "Test trange" in str(trange(10, desc="Test trange"))
    assert "10loop" in str(trange(10, unit="loop"))
    assert "test_trange.py" in str(trange(10, unit="loop",
                                          unit_scale=False))


# For python2 compat, ignore flake8 F821 undefined name
# flake8: noqa = F821

# Generated at 2022-06-22 04:43:07.114973
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass

# Generated at 2022-06-22 04:43:10.067330
# Unit test for function trange
def test_trange():
    from .utils import _term_move_up
    from .gui import tqdm

    with tqdm(range(10), miniters=2, mininterval=0) as pbar:
        for _ in pbar:
            _term_move_up()


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:14.540665
# Unit test for function trange
def test_trange():
    """Tests trange with no output"""
    trange(1)
    trange(1, 1)
    trange(sys.maxsize, sys.maxsize + 1)
    trange(1, 1, 1)
    trange(0, 1, 1)


# Generated at 2022-06-22 04:43:19.547067
# Unit test for function trange
def test_trange():
    """Test trange(n)"""
    for n in [1, 1 << 8, 1 << 16, 1 << 32]:
        for unit in [1, 1 << 8, 1 << 16, 1 << 32, 1 << 64]:
            assert sum(trange(n, unit=unit)) == n - 1

# Generated at 2022-06-22 04:43:22.632009
# Unit test for function trange
def test_trange():
    from ._utils import _screen_shape as s
    from .autonotebook import trange as notebook_trange

    for _ in notebook_trange(5):
        for _ in trange(5):
            pass

# Generated at 2022-06-22 04:43:33.373418
# Unit test for function trange
def test_trange():
    """
    Test for `tqdm.auto.trange`
    """
    import pytest  # pylint: disable=import-outside-toplevel
    try:
        a = trange(10)
        assert len(a) == 10
    except TypeError:  # Python3.5
        pytest.skip("trange not fully functional on Python3.5")
    assert list(a) == list(range(10))

    a = trange(10, 0, -1)
    assert len(a) == 10
    assert list(a) == list(range(10, 0, -1))
    a = trange(5)
    assert len(a) == 5
    assert list(a) == list(range(5))

# Generated at 2022-06-22 04:43:36.798029
# Unit test for function trange
def test_trange():
    """ Unit test for trange """
    assert sum(trange(100)) == sum(range(100))

# Generated at 2022-06-22 04:43:39.144486
# Unit test for function trange
def test_trange():
    """Tests trange"""
    # Disable tqdm
    with tqdm(disable=True) as _t:
        list(trange(10))


# Generated at 2022-06-22 04:43:52.228680
# Unit test for function trange
def test_trange():
    """
    Tests for `tqdm.auto.trange`.
    """
    # basic
    assert list(trange(10)) == list(range(10))
    # desc
    assert list(trange(10, desc="desc")) == list(range(10))
    # total
    assert list(trange(10, total=100)) == list(range(10))
    # initial
    assert list(trange(10, initial=100)) == list(range(100, 110))
    # position
    assert list(trange(10, initial=100, position=2)) == list(range(100, 110))
    # leave
    assert list(trange(10, leave=False)) == list(range(10))
    assert list(trange(10, leave=True)) == list(range(10))
    # smoothing

# Generated at 2022-06-22 04:43:55.789832
# Unit test for function trange
def test_trange():
    """Test the function trange()"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]
    assert list(trange(2)) == [0, 1]

# Generated at 2022-06-22 04:44:01.256513
# Unit test for function trange
def test_trange():
    with tqdm(range(4)) as t:
        for i in t:  # type: ignore
            if i == 2:  # pragma: no cover
                break
        else:
            raise Exception('FAIL: Range not iterable')  # pragma: no cover

# Generated at 2022-06-22 04:44:02.287333
# Unit test for function trange
def test_trange():
    """Test for trange"""

# Generated at 2022-06-22 04:44:06.571326
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    list(trange(10))
    list(trange(10, leave=True))
    list(tqdm(range(10), leave=True))
    list(tqdm(range(10), ascii=True))
    list(tqdm(range(10), ascii=True, leave=True))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:44:16.356845
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    list(trange(10))
    list(trange(10, 0))
    list(trange(10, -10))
    list(trange(0, 10))
    list(trange(0, 10, 2))
    list(trange(10, 0, -2))
    list(trange(0, 10, 2.0))
    list(trange(10, 0, -2.0))
    list(trange(0, 10, -2.0))
    list(trange(0, 10, -2.01))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        list(trange(0, -10, 2.01))


if __name__ == "__main__":
    test_trange

# Generated at 2022-06-22 04:44:28.490809
# Unit test for function trange
def test_trange():
    from .utils import _range

    for i in trange(_range(10)):
        pass
    for i in trange(_range(10), desc="desc"):
        pass
    for i in trange(_range(10), desc="desc", leave=False):
        pass
    for i in trange(10, desc="desc", leave=False):
        pass
    for i in trange(10, desc="desc", leave=True):
        pass
    for i in trange(10, desc="desc", ascii=True, mininterval=0.1,
                    maxinterval=1, miniters=1, smoothing=0):
        pass

# Generated at 2022-06-22 04:44:30.398499
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(10, desc='foo')) == list(range(10))


# Generated at 2022-06-22 04:44:33.837898
# Unit test for function trange
def test_trange():
    """Test for trange() shortcut method."""
    from .std import tqdm
    from .utils import _range

    with tqdm(_range(10)) as t:
        for i in t:  # pylint: disable=unused-variable
            pass



# Generated at 2022-06-22 04:44:44.963291
# Unit test for function trange
def test_trange():
    """
    Unit test for function ``trange``.
    """
    from .std import _supports_unicode

    for i in tqdm(range(1)):
        pass

    if _supports_unicode():
        for i in trange(3, desc='Unicode', ascii=False):
            pass

        for i in trange(3, desc=u'Unicode', ascii=False):
            pass

        for i in trange(3, desc=b'ASCII', ascii=True):
            pass

        for i in trange(3, desc='Unicode', ascii=True):
            pass

if __name__ == "__main__":
    test_trange()