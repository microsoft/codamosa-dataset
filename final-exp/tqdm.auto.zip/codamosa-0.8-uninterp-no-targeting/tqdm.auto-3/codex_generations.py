

# Generated at 2022-06-22 04:43:14.042612
# Unit test for function trange
def test_trange():
    from .std import tqdm
    import time
    import os

    try:
        with tqdm(total=48, desc="foobar") as pbar:
            for i in range(48):
                time.sleep(0.1)
                pbar.update(1)
    except (KeyboardInterrupt, SystemExit):
        try:
            # Cleanup lines in terminal
            pbar.refresh()
            time.sleep(1)
            pbar.close()
        except TypeError:
            pass
        raise

    assert not os.system(sys.executable + " -m tqdm._tqdm")

# Generated at 2022-06-22 04:43:17.342103
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange

    >>> from tqdm.auto import trange
    >>> from time import sleep
    >>> for i in trange(3, desc='1st loop'):
    ...     sleep(0.1)
    ...     for j in trange(50, desc='2nd loop', leave=False):
    ...         sleep(0.01)
    1st loop: 100%|██████████| 3/3 [00:02<00:00,  1.03it/s]
    1st loop: 100%|██████████| 3/3 [00:02<00:00,  1.03it/s]
    1st loop: 100%|██████████| 3/3 [00:02<00:00,  1.03it/s]
    """
    pass

# Generated at 2022-06-22 04:43:19.696140
# Unit test for function trange
def test_trange():
    trange(10)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:25.218693
# Unit test for function trange
def test_trange():
    """Test case for `tqdm.trange`"""
    from .std import tqdm
    from .utils import UnicodeIO

    with UnicodeIO() as io:
        for _ in trange(10, file=io):
            pass
        assert io.getvalue() == u"10it [00:00, ?it/s]"

# Generated at 2022-06-22 04:43:31.827855
# Unit test for function trange
def test_trange():
    """Test trange."""
    import subprocess

    def _trange_eq(n, *args, **kwargs):
        assert tuple(trange(n, *args, **kwargs)) == tuple(range(n))
        assert tuple(trange(n, *args, **kwargs)) == tuple(tqdm(range(n),
                                                               *args, **kwargs))
        assert tuple(trange(n, ascii=True, *args, **kwargs)) == tuple(
            tqdm(range(n), ascii=True, *args, **kwargs))

    _trange_eq(10)
    _trange_eq(10, 1)
    _trange_eq(10, 1, 2)
    _trange_eq(5, 1, 7)
    _trange_

# Generated at 2022-06-22 04:43:42.039957
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange()`.
    """
    from ._utils import _range
    with warnings.catch_warnings():
        # Python2.6 raises deprecation warning during unit test
        # and possibly PyPy
        warnings.filterwarnings('ignore', category=DeprecationWarning)

        def check(start, stop, total):
            """
            Checks that `tqdm(range(start, stop))`
            iterates exactly `stop-start` times.
            """
            for _ in trange(start, stop):
                total += 1
            assert total == stop

        check(0, 10, 0)
        check(1, 11, 1)

        for _ in trange(5):
            pass
        assert _ == 4

# Generated at 2022-06-22 04:43:47.878944
# Unit test for function trange
def test_trange():
    """
    Unit tests for `tqdm.trange`.
    """
    from .std import verify_positional_args

    # unit test 1
    # test for function trange
    for _ in trange(4, 10, 3):
        assert True
    # unit test 2
    # test for function trange
    verify_positional_args(trange, (1, 2, 3))
    assert True

# Generated at 2022-06-22 04:43:49.632695
# Unit test for function trange
def test_trange():
    "Smoke test for trange"
    for _ in trange(0):
        raise ValueError()

# Generated at 2022-06-22 04:43:51.656502
# Unit test for function trange
def test_trange():
    """
    Unit test function for the function `tqdm.auto.trange`.
    """
    assert sum(trange(10)) == 45

# Generated at 2022-06-22 04:44:03.866873
# Unit test for function trange
def test_trange():
    "Test trange"
    assert list(trange(100)) == list(range(100))
    assert list(trange(0)) == list(range(0))
    assert list(trange(1)) == list(range(1))
    assert list(trange(1, 100)) == list(range(1, 100))
    assert list(trange(0, 0)) == list(range(0, 0))
    assert list(trange(10, 20)) == list(range(10, 20))
    assert list(trange(10, 20, 2)) == list(range(10, 20, 2))
    assert list(trange(10, 20, -1)) == list(range(10, 20, -1))
    assert list(trange(20, 10, -1)) == list(range(20, 10, -1))

# Generated at 2022-06-22 04:44:10.459380
# Unit test for function trange
def test_trange():
    """Unit test for trange"""
    assert list(trange(3)) == list(tqdm(range(3)))
    assert list(trange(3, desc="Test trange")) == \
        list(tqdm(range(3), desc="Test trange"))


# Util tests

# Generated at 2022-06-22 04:44:18.186428
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    from .autonotebook import trange  # pylint: disable=redefined-outer-name

    for i in trange(2):
        assert i in [0, 1]
        for j in trange(2, leave=False):
            assert j in [0, 1]
    print("\nOK")

    # Regression test for trange with nested loops
    # https://github.com/tqdm/tqdm/issues/360
    for i in trange(5, desc="outer loop"):
        for j in trange(5, desc="inner loop", leave=False):
            pass
    print("\nOK")

    # Regression test for trange with nested loops (2)
    I, J = 2, 3

# Generated at 2022-06-22 04:44:23.551146
# Unit test for function trange
def test_trange():
    """Smoke test for `tqdm.auto.trange`"""
    # Test both inputs...
    assert (list(trange(3)) == list(tqdm(range(3))))
    assert (list(trange(1, 5)) == list(tqdm(range(1, 5))))

# Generated at 2022-06-22 04:44:28.406257
# Unit test for function trange
def test_trange():
    pbar = trange(10)
    assert pbar.miniters == 1
    pbar = trange(10, miniters=1, desc="D", leave=True)
    assert pbar.miniters == 1
    assert pbar.desc == "D"
    assert pbar.leave

# Generated at 2022-06-22 04:44:30.315213
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        assert next(t) == 0
        assert sum(1 for _ in t) == 9

# Generated at 2022-06-22 04:44:39.335729
# Unit test for function trange
def test_trange():
    try:
        xrange
    except NameError:
        xrange = range  # python3

    with tqdm(total=3) as pbar:
        assert len(list(pbar)) == 3

    for _ in trange(1, 0, -1):
        pass

    for _ in trange(10, unit="", leave=False):
        pass

    for i in trange(3, desc="trange", leave=False):
        assert i == 0
        for _ in trange(1, desc="inner-trange", leave=True):
            pass

    wi

# Generated at 2022-06-22 04:44:46.958907
# Unit test for function trange
def test_trange():
    assert list(trange(0)) == []
    assert list(trange(0, 5)) == [0, 1, 2, 3, 4]
    assert list(trange(5, 0)) == []
    assert list(trange(5, 0, -1)) == [5, 4, 3, 2, 1]
    assert list(trange(5, 10)) == [5, 6, 7, 8, 9]
    assert list(trange(5, 10, 2)) == [5, 7, 9]
    assert list(trange(10, 5, -2)) == [10, 8, 6]

# Generated at 2022-06-22 04:44:52.103787
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange().
    """
    from .autonotebook import trange as notebook_trange
    from .asyncio import trange as asyncio_trange

    assert trange(10) == notebook_trange(10) == asyncio_trange(10)
    assert isinstance(trange(10), notebook_trange)

# Generated at 2022-06-22 04:44:54.957777
# Unit test for function trange
def test_trange():
    """Test for function trange"""
    from .std import trange

    for i in trange(3, desc='Iteration'):
        pass

# Generated at 2022-06-22 04:45:00.093498
# Unit test for function trange
def test_trange():
    """Test auto.trange (just calls tqdm(range(*args), **kwargs))"""
    from .std import tqdm
    from .utils import _range
    for i in trange(_range[0], _range[1], _range[2]):
        assert i == tqdm(range(_range[0], _range[1], _range[2])).next()