

# Generated at 2022-06-22 04:43:00.545802
# Unit test for function trange
def test_trange():
    """Test for trange"""
    assert list(trange(5)) == list(range(5))

    assert list(trange(5, 2)) == list(range(5, 2))

    assert list(trange(5, 2, -1)) == list(range(5, 2, -1))

    assert list(trange(5, 2, -1, 3)) == list(range(5, 2, -1))

    assert list(trange(0, 21, 2, leave=False)) == list(range(0, 21, 2))

    assert list(trange(5, leave=False)) == list(range(5))

    assert list(trange(5, 2, leave=False)) == list(range(5, 2))


# Generated at 2022-06-22 04:43:02.224585
# Unit test for function trange
def test_trange():
    from .autonotebook import trange as notebook_trange
    assert trange(0) == notebook_trange(0)

# Generated at 2022-06-22 04:43:13.304223
# Unit test for function trange
def test_trange():
    from tqdm.contrib._ncursed_tester import _ncursed_test
    # pylint: disable=protected-access
    for _ in trange(3):
        for _ in notebook_trange(3):
            for _ in tqdm.std._trange(3):
                for _ in asyncio_tqdm._trange(3):
                    _ncursed_test(tqdm, lambda: None)
                    _ncursed_test(notebook_tqdm, lambda: None)
                    _ncursed_test(tqdm.std, lambda: None)
                    _ncursed_test(asyncio_tqdm, lambda: None)


# Generated at 2022-06-22 04:43:25.172557
# Unit test for function trange
def test_trange():
    """ test trange """
    from time import sleep
    from .std import tqdm as _tqdm
    from .std import trange as _trange
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        for func in (tqdm, trange):
            # Test 1
            lst = []
            for i in func(3):
                sleep(.1)
                lst.append(i)
            assert lst == [0, 1, 2]
            # Test 2
            lst = []
            for i in func(3, desc='Custom desc', leave=None):
                sleep(.1)
                lst.append(i)
            assert lst == [0, 1, 2]
            # Test 3
            lst = []

# Generated at 2022-06-22 04:43:31.837634
# Unit test for function trange
def test_trange():
    from .gui import trange
    from .gui import tqdm
    import sys
    import time

    def _test(n, total, leave, position, **kwargs):
        with tqdm(total=total, leave=leave, position=position, **kwargs) as pbar:
            for i in trange(n, leave=leave, position=position, **kwargs):
                assert(i == pbar.n)  # test for trange internal counter
                time.sleep(0.01)
                if (i + 1) % 3 == 0:
                    pbar.update(3)  # test for manual update

    try:  # Test gui
        _test(10, 10, False, False)
    except AssertionError:
        pass  # ok

# Generated at 2022-06-22 04:43:42.261696
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    #range object must be passed to use positionals
    for __i, _i in zip(trange(10), range(10)):
        pass
    #ranges must be passed as positional
    for __i, _i in zip(trange(10, 0, -1), range(10, 0, -1)):
        pass
    #only in keyword form
    for __i, _i in zip(trange(start=10, stop=0, step=-1),
                       range(10, 0, -1)):
        pass
    #positionals are ignored if keyword is passed
    for __i, _i in zip(trange(10, start=0, stop=-1, step=-1),
                       range(0, -1, -1)):
        pass
    #

# Generated at 2022-06-22 04:43:52.642482
# Unit test for function trange
def test_trange():
    """Test trange function"""
    from .utils import _range

    # Simple tests
    assert list(trange(3)) == [0, 1, 2]
    assert list(trange(3, 7)) == [3, 4, 5, 6]
    assert list(trange(3, 10, 2)) == [3, 5, 7, 9]
    assert list(trange('3, 10, 2')) == [3, 5, 7, 9]
    assert list(trange('3, 10, 2', ascii=True)) == [3, 5, 7, 9]
    assert list(trange('3k, 10k, 2k', unit='B')) == [3, 5, 7, 9]

# Generated at 2022-06-22 04:44:04.515079
# Unit test for function trange
def test_trange():
    "Unit tests for function :func:`tqdm.auto.trange`"
    from .std import sys_info
    from .std import format_sizeof
    from .std import TimeSensitivePopen
    import tempfile

    tfs = tempfile.NamedTemporaryFile()

    limits = [
        (100, 200), (100, 200, 30), (100, 0, 20),
        (0, 200, 30), (0, 0, 20)
    ]

# Generated at 2022-06-22 04:44:15.159339
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    from .utils import _range

    assert list(trange(3)) == list(_range(3))
    assert list(trange(3, 1)) == list(_range(3, 1))
    assert list(trange(3, 1, -1)) == list(_range(3, 1, -1))
    assert list(trange(3, 1, 1)) == list(_range(3, 1, 1))
    assert list(trange(3, 0, -1)) == list(_range(3, 0, -1))
    assert list(trange(0, 3, 1)) == list(_range(0, 3, 1))
    assert list(trange(3, 0, -1, 1)) == list(_range(3, 0, -1, 1))

# Generated at 2022-06-22 04:44:27.347675
# Unit test for function trange
def test_trange():
    """ Tests trange using a dummy tqdm """
    with_tqdm = list(trange(10))
    class dummy_tqdm(tqdm):
        def __init__(self, *args, **kwargs):
            self.iterable = args[0]
            self.results = []
            self.len = kwargs.get('total')
            if not self.len:
                self.len = len(self.iterable)
            super(dummy_tqdm, self).__init__(*args, **kwargs)
        def __iter__(self):
            for x in self.iterable:
                self.results.append(x)
                yield x
    without_tqdm = list(tqdm(range(10), total=10, desc='test', dynamic_ncols=True))