

# Generated at 2022-06-22 04:43:10.008999
# Unit test for function trange
def test_trange():
    """Test for trange"""
    from .std import trange

    trange(10, desc='Bla', leave=True,
           bar_format='{percentage:3.0f}%')
    trange(10, leave=False)

    with trange(10) as t:
        for _ in t:
            continue
        t.close()

# Generated at 2022-06-22 04:43:20.377479
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """

    from .std import tqdm

    for a, b, c in [
        ((), {}, ()),
        ((1,), {}, (0,)),
        ((1, 2), {}, (0, 2)),
        ((None,), {'miniters': 1}, (0, 1)),
        ((None,), {'miniters': 1, 'desc': 'foo'}, (0, 1)),
        ((None,), {'miniters': 1, 'desc': 'foo', 'bar': 'baz'}, (0, 1)),
    ]:
        assert trange(*a, **b) == tqdm(range(*c), **b)

# Generated at 2022-06-22 04:43:24.742610
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Test trange is same as tqdm(range())
    assert len(list(trange(10))) == 10
    assert len(list(tqdm(range(10)))) == 10

# Generated at 2022-06-22 04:43:28.653872
# Unit test for function trange
def test_trange():
    assert list(trange(10)) == list(range(10))
    assert list(trange(9, -1)) == list(range(9, -1))
    assert list(trange(10, 0, -1)) == list(range(10, 0, -1))

# Generated at 2022-06-22 04:43:40.294418
# Unit test for function trange
def test_trange():
    """Tests `tqdm.auto.trange()` functionality."""
    import pandas as pd
    import pandas.util.testing as pdt
    import numpy as np

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from .std import tqdm as backw_tqdm

    for i in trange(0):
        pass
    assert i == 0
    for i in trange(10, 15):
        assert i < 15
    assert i == 14
    for i in trange(1, 10, 2):
        assert i % 2
    assert i == 9
    for i in trange(10, 1, -2):
        assert i % 2
    assert i == 3


# Generated at 2022-06-22 04:43:45.108619
# Unit test for function trange
def test_trange():
    """Test trange"""
    # pylint: disable=unnecessary-pass
    ires = trange(1, 11)
    pass


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:55.246678
# Unit test for function trange
def test_trange():
    """Test trange"""
    from .utils import format_sizeof
    from .std import FormatSizeof  # pylint: disable=no-name-in-module

    fsize = FormatSizeof(print_sizeof=False)


# Generated at 2022-06-22 04:44:00.033496
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass
    for _ in trange(4, 1, -1):
        pass
    for _ in trange(4, -1, -1):
        pass



# Generated at 2022-06-22 04:44:01.900212
# Unit test for function trange
def test_trange():
    """
    Test for trange function
    """
    assert list(trange(3)) == list(range(3))

# Generated at 2022-06-22 04:44:14.678234
# Unit test for function trange
def test_trange():
    silent = tqdm(range(10))
    silent.close()
    for _ in trange(10):
        pass
    for _ in trange(10, ascii=True):
        pass
    for _ in trange(10, desc="desc"):
        pass
    for _ in trange(10, desc="desc", ascii=True):
        pass
    for _ in trange(10, desc="desc", leave=False):
        pass
    for _ in trange(10, desc="desc", leave=False, ascii=True):
        pass
    for _ in trange(10, desc="desc", leave=False, ascii=True):
        pass
    for _ in tqdm(range(10), desc="desc", ascii=True):
        pass