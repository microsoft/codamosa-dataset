

# Generated at 2022-06-22 04:43:04.707575
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

# Generated at 2022-06-22 04:43:06.204437
# Unit test for function trange
def test_trange():
    assert list(trange(3)) == [0, 1, 2]

# Generated at 2022-06-22 04:43:09.427166
# Unit test for function trange
def test_trange():
    """Test that trange is blocking."""
    import time

    st = time.time()
    _ = [i for i in trange(100, desc='fake')]
    assert time.time() - st > 1

# Generated at 2022-06-22 04:43:16.902717
# Unit test for function trange
def test_trange():
    """Test that trange is consistent with tqdm on a few examples."""
    assert tqdm(range(10)) == trange(10)
    assert tqdm(range(10), ncols=60) == trange(10, ncols=60)
    assert tqdm(range(10), ascii=True) == trange(10, ascii=True)
    assert tqdm(range(10), desc="Foobar") == trange(10, desc="Foobar")

# Generated at 2022-06-22 04:43:28.701193
# Unit test for function trange
def test_trange():
    """
    Tests `tqdm.auto.trange` function.
    """
    # Test trange as iterator
    for item in trange(0):
        assert False  # Should never be reached
    assert isinstance(trange(0, 1), tqdm)
    for item in trange(3):
        assert item < 3
    for item_len, item in enumerate(trange(3, 2)):
        assert item_len == 0
        assert item == 2
    # Test trange as function
    assert isinstance(trange(0, 1), tqdm)
    assert list(trange(0, 3)) == [0, 1, 2]
    assert list(trange(3, 2)) == [2]

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:36.945653
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # Initialise class tqdm
    tqdm.write("test")
    trange(10)
    trange(10, desc="test")
    trange(10, desc="test", miniters=1)
    trange(10, position=2)
    trange(10, dynamic_ncols=True)
    list(trange(10))
    trange(10, file=sys.stderr)

# Generated at 2022-06-22 04:43:43.573910
# Unit test for function trange
def test_trange():
    from .compatibility import IS_WIN
    from .std import tqdm as std_tqdm
    for t in [tqdm, std_tqdm]:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            with t(Disable=True) as tt:
                assert list(tt) == []
            with t(range(10)) as tt:
                assert list(tt) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
            with t(range(10), miniters=5, mininterval=0) as tt:
                for _ in tt:
                    if IS_WIN:
                        assert tt.n == 5
                    tt.update(5)
                assert tt.n == 10

# Generated at 2022-06-22 04:43:44.592740
# Unit test for function trange
def test_trange():
    for i in trange(3):
        pass

# Generated at 2022-06-22 04:43:49.140515
# Unit test for function trange
def test_trange():
    from .std import get_instances
    from .std import tqdm
    t = trange(10)
    
    # remove newly created tqdm instances
    open_tqdms = get_instances()
    tqdm._instances.clear()
    tqdm._instances.update(open_tqdms)

# Generated at 2022-06-22 04:43:53.774658
# Unit test for function trange
def test_trange():
    from .std import trange
    assert trange(1).__next__() == 0
    assert sum(trange(5)) == 10
    assert list(trange(5, 10)) == list(range(5, 10))
    assert list(trange(5, 100, 10)) == list(range(5, 100, 10))