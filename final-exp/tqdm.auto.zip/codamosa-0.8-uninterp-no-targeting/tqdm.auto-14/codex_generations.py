

# Generated at 2022-06-22 04:43:08.556040
# Unit test for function trange
def test_trange():
    """Test trange"""
    # noinspection PyProtectedMember
    assert [i for i in trange(5)] == [i for i in notebook_trange(5)]
    assert all([i == j for i, j in zip(trange(5), notebook_trange(5))])

# Generated at 2022-06-22 04:43:11.266537
# Unit test for function trange
def test_trange():
    with tqdm(total=10, disable=None) as pbar:
        for i in trange(10):
            pbar.update()



# Generated at 2022-06-22 04:43:22.962624
# Unit test for function trange
def test_trange():
    """Test function trange"""
    from .std import tqdm

    def ky():
        """Test function trange with yield"""
        for i in trange(10):
            yield i
            if i == 8:
                global myiter  # pylint: disable=global-statement
                myiter = trange(10)
                for j in myiter:
                    pass

    def kd():
        """Test function trange with return"""
        for i in trange(10):
            if i == 8:
                global myiter  # pylint: disable=global-statement
                myiter = trange(10)
                for j in myiter:
                    pass
            yield i

    # pylint: disable=no-member
    tqdm.write('test iter-with-yield')
    myiter = ky

# Generated at 2022-06-22 04:43:30.036934
# Unit test for function trange
def test_trange():
    """
    Test function trange
    """
    assert list(trange(2)) == [0, 1]
    assert list(trange(1, 3)) == [1, 2]
    assert list(trange(1, 10, 2)) == [1, 3, 5, 7, 9]
    assert list(trange(10, 0, -1)) == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]



# Generated at 2022-06-22 04:43:34.138724
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    $ python -m tqdm.auto
    """
    from .auto import trange
    tr = trange(1000, file=sys.stderr)
    for _ in tr:
        pass

# Generated at 2022-06-22 04:43:43.106381
# Unit test for function trange
def test_trange():
    """
    Unit test for function `trange`.
    """
    import numpy
    from .std import tqdm
    from .utils import FormatCustomText, no_unclosed_fd_in_subprocess

    assert trange(10) == tqdm(range(10))
    assert no_unclosed_fd_in_subprocess(
        trange,
        10,
        bar_format=FormatCustomText("{postfix}")) == no_unclosed_fd_in_subprocess(
            tqdm,
            range(10),
            bar_format=FormatCustomText("{postfix}"))
    # Loop-check

# Generated at 2022-06-22 04:43:49.633675
# Unit test for function trange
def test_trange():  # pragma: no cover
    # Basic test for function trange
    for _ in trange(10):
        pass

    # Test for using trange in list comprehension
    [_ for _ in trange(10)]

    # Test for using trange in dict comprehension
    {_: _ for _ in trange(10)}

    # Test for using trange in set comprehension
    {_ for _ in trange(10)}

    # Test for using trange in generator expression
    (_ for _ in trange(10))



# Generated at 2022-06-22 04:44:01.720910
# Unit test for function trange
def test_trange():
    import sys
    tt = trange(10, leave=False)
    assert isinstance(tt, tqdm)
    if sys.version_info[:2] > (3, 6):
        tt = trange(10, leave=True)
        assert isinstance(tt, tqdm)

    # test `desc`
    tt = trange(10, desc="Desc")
    assert tt.desc == "Desc"
    # This is a test:
    tt = trange(10, desc="This is a test")
    assert tt.desc == "This is a test"
    # ... Test:
    tt = trange(10, desc="... Test")
    assert tt.desc == "... Test"
    # ... Test:
    tt = trange(10, desc="... Test:")


# Generated at 2022-06-22 04:44:05.793430
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(4)) == list(notebook_trange(4))
    assert list(trange(4)) == list(range(4))
    assert list(trange(0)) == list(notebook_trange(0))
    assert list(trange(0)) == list(range(0))



# Generated at 2022-06-22 04:44:08.486973
# Unit test for function trange
def test_trange():
    """Test function trange"""
    assert list(trange(0)) == []
    assert list(trange(1)) == [0]

