

# Generated at 2022-06-22 04:43:16.953067
# Unit test for function trange
def test_trange():
    rng = trange(5)
    assert next(rng) == 0
    assert next(rng) == 1
    assert next(rng) == 2
    assert next(rng) == 3
    assert next(rng) == 4
    # with total
    rng = trange(5, 5, 1)
    assert next(rng) == 5
    assert next(rng) == 6
    assert next(rng) == 7
    assert next(rng) == 8
    assert next(rng) == 9
    # with initial
    rng = trange(-2, 3, 1)
    assert next(rng) == -2
    assert next(rng) == -1
    assert next(rng) == 0
    assert next(rng) == 1
    assert next(rng) == 2

# Generated at 2022-06-22 04:43:23.335288
# Unit test for function trange
def test_trange():
    """Test trange function"""
    import sys

    if sys.version_info < (3, 6):
        # Nothing to do
        return

    from time import sleep

    async def async_main(t):
        for _ in trange(3):
            sleep(t)

    import asyncio
    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_main(0.1))

# Generated at 2022-06-22 04:43:28.970885
# Unit test for function trange
def test_trange():
    for i in trange(4, desc='i = '):
        for j in trange(4, desc='j = ', leave=False):
            for k in trange(4, desc='k = ', leave=False):
                pass

# Main script
if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:40.510664
# Unit test for function trange
def test_trange():
    """Test 'trange' function"""
    from nose.tools import (assert_raises,
                            assert_raises_regex)
    from .utils import _range

    total = 8
    mininterval = 0.1
    miniters = 1
    mininterval *= 1e-3 / miniters  # Use some fraction of miniters to make
                                    # sure mininterval doesn't interfere

# Generated at 2022-06-22 04:43:45.658551
# Unit test for function trange
def test_trange():
    """Test that trange is working correctly."""
    trange(0)
    trange(1)
    for _ in trange(1):
        pass
    for _ in trange(2):
        for _ in trange(1):
            pass

# Generated at 2022-06-22 04:43:47.782775
# Unit test for function trange
def test_trange():
    """Test trange function"""
    for _ in trange(4):
        pass

# Unit tests for class tqdm

# Generated at 2022-06-22 04:43:59.749028
# Unit test for function trange
def test_trange():
    """
    Test that `trange` yields the same values as the built-in `range`
    """
    # Test that we get the same thing
    for i in trange(10):
        assert i == i
    # Test that we get the same thing in reverse
    for i in trange(10, 0, -1):
        assert i == 10 - i
    # Test with a progress bar item_len argument
    for i in trange(10, desc='My Range', unit='i', item_len=10):
        assert i == i
    # Test with a progress bar total argument

# Generated at 2022-06-22 04:44:07.661236
# Unit test for function trange
def test_trange():
    """Test function for auto trange"""
    for _ in trange(4, file=sys.stdout):
        pass
    for _ in trange(4, file=sys.stdout, desc="desc", leave=False):
        pass
    for _ in trange(4, file=sys.stdout, desc="desc", leave=True):
        pass
    for _ in trange(4, file=sys.stdout, desc="desc", position=1):
        pass
    for _ in trange(4, file=sys.stdout, desc="desc", miniters=1):
        pass
    for _ in trange(4, file=sys.stdout, desc="desc", mininterval=0):
        pass

# Generated at 2022-06-22 04:44:15.577969
# Unit test for function trange
def test_trange():
    """Test of 'trange'"""
    from .std import format_interval
    assert isinstance(format_interval(1), str)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert sum(trange(27)) == 351
        assert sum(trange(0)) == 0
        assert sum(trange(-5)) == 0
        assert sum(trange(-5, 0)) == 0
        assert sum(trange(5, -5)) == 0
        assert sum(trange(5, 0)) == 10


test_trange()



# Generated at 2022-06-22 04:44:21.976850
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    list(trange(10))
    list(trange(10, desc="A simple trange"))
    try:
        list(trange(10, position=0))
    except TypeError:
        pass
    else:
        raise Exception("position arg should not be accepted in trange")



# Generated at 2022-06-22 04:44:24.652514
# Unit test for function trange
def test_trange():
    for _ in trange(5):
        pass

# Generated at 2022-06-22 04:44:35.032047
# Unit test for function trange
def test_trange():
    """
    Tests that `trange` function and `tqdm` class produce the same results
    """
    # `trange` function
    assert list(trange(3)) == list(range(3))
    assert list(trange(3, desc="Custom Desc")) == list(range(3))
    assert list(trange(3, 1)) == list(range(3, 1))

    # `tqdm` class (with `tqdm.__class__ == tqdm`)
    assert list(tqdm(range(3))) == list(range(3))
    assert list(tqdm(range(3), desc="Custom Desc")) == list(range(3))
    assert list(tqdm(range(3), 1)) == list(range(3))

# Generated at 2022-06-22 04:44:41.158777
# Unit test for function trange
def test_trange():
    """Test for trange"""
    try:
        import numpy
        assert len(list(trange(numpy.asarray(10)))) == 10
    except ImportError:
        pass

    assert len(list(trange(10))) == 10

testmod = type("testmod", (object,), dict(testmod=test_trange))()

# Generated at 2022-06-22 04:44:51.015964
# Unit test for function trange
def test_trange():
    "Test the function trange"
    from .std import _range
    from .std import _trange
    from .std import _tqdm_gui
    from .std import _tqdm
    from .gui import tqdm_gui

    def test_xrange():
        """Test xrange"""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            range_ = _range(5)
        return range_(_tqdm)

    def test_range():
        """Test range"""
        range_ = _trange(5)
        return range_(_tqdm)

    def test_xrange_gui():
        """Test xrange_gui"""
        range_ = _range(5)
        return range_(tqdm_gui)


# Generated at 2022-06-22 04:44:54.020392
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(10)) == list(range(10))

# Generated at 2022-06-22 04:45:01.542773
# Unit test for function trange
def test_trange():
    """ Test function trange """
    # Test trange with notebook
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        assert len([i for i in trange(10)]) == 10
        assert len([i for i in trange(10, 0, -1)]) == 10
        assert trange(10).__class__ is notebook_trange(10).__class__
        assert trange.__doc__ == notebook_trange.__doc__


# Generated at 2022-06-22 04:45:03.522848
# Unit test for function trange
def test_trange():
    """Smoke test for function trange"""
    assert isinstance(trange(1), list)

# Generated at 2022-06-22 04:45:08.896830
# Unit test for function trange
def test_trange():
    """Test for function trange
    """
    for i in trange(5, desc='Function trange'):
        assert i == i

if __name__ == "__main__":
    """Run doctest on module
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 04:45:14.125510
# Unit test for function trange
def test_trange():
    """Test trange()"""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            for _ in notebook_trange(10):
                pass
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
            for _ in trange(10):
                pass
    except BaseException:
        raise
    else:
        pass
    finally:
        pass

# Generated at 2022-06-22 04:45:17.991288
# Unit test for function trange
def test_trange():
    """Test trange"""
    assert list(trange(5)) == list(range(5))
    assert list(trange(1, 7, 2)) == [1, 3, 5]
    assert list(trange(7, 0, -2)) == [7, 5, 3, 1]
    assert list(trange(3, 0)) == []