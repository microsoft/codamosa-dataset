

# Generated at 2022-06-22 04:43:05.811543
# Unit test for function trange
def test_trange():  # pragma: no cover
    from .std import tqdm

    # Test against tqdm explicitly
    for i in trange(4, leave=False):
        assert i == list(tqdm(range(4), leave=False))[i]
        assert i == list(trange(4, leave=False))[i]
        assert i == list(trange(4, leave=False))[i]
        assert i == list(tqdm(range(4), leave=False))[i]

    # Test basic functionality
    bar = trange(3, leave=True)
    assert len(bar) == 3 and bar.miniters == 1
    assert sum(1 for _ in trange(10)) == 10
    assert sum(1 for _ in trange(10)) == 10

    # Test miniters

# Generated at 2022-06-22 04:43:09.478091
# Unit test for function trange
def test_trange():  # pragma: no cover
    """
    Unit test for function `trange`
    """
    try:
        from tqdm import trange
    except Exception:
        return
    for _ in trange(4):
        pass

# Generated at 2022-06-22 04:43:20.280723
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    with tqdm(total=2, disable=None) as t:
        t.update()
        assert t.n == 1
        t.update()
        assert t.n == 2
        assert t.total == 2
    nums = trange(5)
    assert len(list(nums)) == 5
    nums = trange(5, desc='trange')
    assert len(list(nums)) == 5
    for _ in tqdm(range(5)):
        pass
    for _ in tqdm(range(5), desc='tqdm'):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_trange()

# Generated at 2022-06-22 04:43:23.378542
# Unit test for function trange
def test_trange():
    """Test function trange()"""
    assert list(range(2)) == list(
        trange(2)
    ), "trange(2) should be equal to range(2)"



# Generated at 2022-06-22 04:43:27.128168
# Unit test for function trange
def test_trange():
    """Test trange function"""
    t_sum = 0
    for _ in trange(5):
        t_sum += 1
    assert t_sum == 5



# Generated at 2022-06-22 04:43:39.067843
# Unit test for function trange
def test_trange():
    """Test trange function"""
    list(trange(3))
    assert trange(0).__iter__() is trange(0).__iter__()
    pbar = trange(3, desc='1st loop')
    assert len(pbar) == 3 and list(pbar) == [0, 1, 2]
    pbar = trange(1, 3, desc='2nd loop')
    assert len(pbar) == 2 and list(pbar) == [1, 2]
    pbar = trange(4, 1, -1, desc='3rd loop')
    assert len(pbar) == 3 and list(pbar) == [4, 3, 2]
    pbar = trange(0, 3, 2, desc='4th loop')
    assert len(pbar) == 2 and list(pbar)

# Generated at 2022-06-22 04:43:51.269031
# Unit test for function trange
def test_trange():
    """
    Unit test for `tqdm.auto.trange`.
    """
    from .autonotebook import tqdm as tqdm_nb
    from .asyncio import tqdm as tqdm_asyncio

    assert notebook_trange(3) == list(trange(3))
    assert notebook_tqdm(range(3)) == tqdm(range(3))

    if sys.version_info <= (3, 6):
        assert tqdm_nb == tqdm_asyncio
        assert tqdm_nb == tqdm

    else:
        assert tqdm_nb != tqdm_asyncio
        assert tqdm_nb != tqdm
        assert tqdm_asyncio != tqdm

# Generated at 2022-06-22 04:44:00.753627
# Unit test for function trange
def test_trange():
    """ Run unit tests for trange """
    from unittest import TestCase, main
    import time
    range_iter = trange(4, leave=True)
    for _ in range_iter:
        time.sleep(0.1)
        range_iter.set_description("Test!")
    class TestRange(TestCase):
        """ Test trange """
        def test_range(self):
            """ Test range output """
            self.assertEqual(list(trange(4)), list(range(4)))
    main(argv=[''], verbosity=2, exit=False)

# Generated at 2022-06-22 04:44:08.139518
# Unit test for function trange
def test_trange():
    """Test function `trange`."""
    from .gui import tgrange
    from ._utils import _term_move_up
    from .utils import _range
    import os
    import re
    import tempfile
    import time
    import unittest

    class AutoTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.file = None
            if os.name == "nt":
                tempfile_name = "tqdm_tempfile.txt"
            else:
                tempfile_name = "/tmp/tqdm_tempfile.txt"
            cls.file = tempfile.NamedTemporaryFile(
                prefix="tqdm_test_", suffix=tempfile_name, delete=False
            )
            cls.out = cls.file

# Generated at 2022-06-22 04:44:15.614699
# Unit test for function trange
def test_trange():
    """ Test function "trange" """
    from .utils import BufferIO
    with BufferIO() as s:
        trange(3, desc="x", file=s, ncols=1)
    assert s.getvalue().split("\r") == \
        ['  0%|          | 0/3 [00:00<?, ?it/s]',
         'x57%|#########8| 2/3 [00:00<00:00, 20.00it/s]',
         'x100%|##########| 3/3 [00:00<00:00, 35.00it/s]']