

# Generated at 2022-06-22 04:43:06.359207
# Unit test for function trange
def test_trange():  # pragma: no cover
    """Test unit for trange()"""
    list(trange(3))


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:18.157784
# Unit test for function trange
def test_trange():
    """
    Tests `trange`.
    """
    from .std import trange
    import threading
    from time import sleep

    assert list(trange(3)) == list(range(3))
    assert list(trange(3, 1)) == list(range(3, 1))
    assert list(trange(1, 3)) == list(range(1, 3))
    assert list(trange(1, 3, -1)) == list(range(1, 3, -1))
    assert list(trange(3, 1, -1)) == list(range(3, 1, -1))
    assert list(trange(1, 3, 1)) == list(range(1, 3, 1))
    assert list(trange(3, 1, 1)) == list(range(3, 1, 1))


# Generated at 2022-06-22 04:43:24.038165
# Unit test for function trange
def test_trange():
    from ._utils import _range
    from ._tqdm import trange as _trange

    for n in (0, 1, 2):
        for desc in (None, "desc"):
            for total in (None, 0, 1, 2):
                for mininterval in (None, 0, 1):
                    for miniters in (None, 1):
                        for ncols in (None, 10, 80):
                            for leave in (None, True, False):
                                for ascii in (None, True, False):
                                    r = _trange(n, desc, total=total,
                                                mininterval=mininterval,
                                                miniters=miniters, ncols=ncols,
                                                leave=leave, ascii=ascii)

# Generated at 2022-06-22 04:43:28.964476
# Unit test for function trange
def test_trange():
    """ Unit test for function trange """
    import time
    import sys

    if sys.version_info[0] == 2:
        # Check if trange is callable
        list(trange(3))
    else:
        # Check if trange is a coroutine / asyncio generator
        list(tqdm(trange(3)))

    with tqdm(total=100) as pbar:
        for i in trange(10):
            pbar.update(10)
            time.sleep(0.01)

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-22 04:43:40.508513
# Unit test for function trange
def test_trange():
    "Unit test for function trange"

    def has_trange_in_stack(stack):
        return any(('tqdm/auto.py', 'trange') in (s[0], s[2])
                   and s[3].startswith('trange')
                   for s in stack)


# Generated at 2022-06-22 04:43:43.585510
# Unit test for function trange
def test_trange():
    """Test for trange"""
    for _ in trange(4):
        pass

# Generated at 2022-06-22 04:43:44.969156
# Unit test for function trange
def test_trange():
    with trange(0) as _:
        pass

# Generated at 2022-06-22 04:43:47.976618
# Unit test for function trange
def test_trange():
    """Test function trange"""
    trange(10)
    import sys
    if sys.version_info[:2] >= (3, 6):
        trange(10, io=sys.stdout.buffer)

# Generated at 2022-06-22 04:43:59.942596
# Unit test for function trange
def test_trange():
    from pytest import mark  # pylint: disable=import-error
    import time
    import numpy as np

    start_time = time.time()
    for _ in trange(3, desc='1st loop'):
        # Print using tqdm class method .write()
        tqdm.write("done loop 1 of 3")
        time.sleep(0.1)

    loop2_time = time.time()
    for _ in trange(5, desc='2nd loop', leave=False):
        # Print using tqdm class method .write()
        tqdm.write("done loop 2 of 5")
        time.sleep(0.3)

    # Creating nested loops

# Generated at 2022-06-22 04:44:02.758335
# Unit test for function trange
def test_trange():
    """Simple unit test for trange"""
    import pytest
    trange(3, 0, -1)
    assert pytest.raises(TypeError, lambda: trange("foo"))