

# Generated at 2022-06-26 09:07:02.551128
# Unit test for function trange
def test_trange():
    var_0 = trange()


if __name__ == '__main__':
    test_case_0()
    test_trange()

# Generated at 2022-06-26 09:07:09.020080
# Unit test for function trange
def test_trange():
    assert not (trange(1) == trange(0))
    assert not (trange(2) == trange(3))
    assert trange(1) == trange(1)
    assert trange(1) == trange(1,1)
    assert trange(0,2) == trange(0,2,1)
    assert trange(0,0) == trange(0,0,1)

# Generated at 2022-06-26 09:07:10.172127
# Unit test for function trange
def test_trange():
    pass
    # assert trange() == 0


# Generated at 2022-06-26 09:07:21.631105
# Unit test for function trange
def test_trange():
    assert trange(10)
    assert trange(10)

# Blocker:
# def test_case_2():
#     var_0 = trange()

# Blocker:
# def test_case_3():
#     var_0 = trange()

# Blocker:
# def test_case_4():
#     var_0 = trange()

# Blocker:
# def test_case_5():
#     var_0 = trange()

# Blocker:
# def test_case_6():
#     var_0 = trange()

# Blocker:
# def test_case_7():
#     var_0 = trange()

# Blocker:
# def test_case_8():
#     var_0 = trange()

# Blocker:
# def

# Generated at 2022-06-26 09:07:24.589306
# Unit test for function trange
def test_trange():
    assert trange() == tqdm(range())



# Generated at 2022-06-26 09:07:25.782017
# Unit test for function trange
def test_trange():
    assert test_case_0() is None

# Generated at 2022-06-26 09:07:31.389208
# Unit test for function trange
def test_trange():
    import sys
    from tqdm.auto import trange
    from tqdm.utils import _term_move_up

    if sys.version_info < (3, 6):
        assert trange is notebook_trange
    else:  # Python3.6+
        assert trange is tqdm
        assert _term_move_up is _term_move_up

# Generated at 2022-06-26 09:07:38.781466
# Unit test for function trange
def test_trange():
    """Unit test for function trange."""
    warnings.simplefilter('ignore')
    import gc
    import os
    import sys
    try:
        sys.argv.remove('--help')
    except ValueError:
        pass
    except:
        raise

    # Testing with output redirected to devnull
    from io import StringIO
    from contextlib import contextmanager
    import filecmp
    @contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = StringIO()
        yield
        sys.stdout = save_stdout
    class capture(object):
        # Context manager for capturing stdout/stderr
        def __enter__(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            sys.std

# Generated at 2022-06-26 09:07:40.082031
# Unit test for function trange
def test_trange():
    var_1 = trange()



# Generated at 2022-06-26 09:07:49.665561
# Unit test for function trange
def test_trange():
    print("Testing trange()")

    from tqdm import tqdm
    from tqdm.auto import tqdm as tauto
    from tqdm.auto import trange as trange_auto
    for cls in (tqdm, tauto, trange_auto):
        with cls(100) as l:
            l.update(10)
            l.set_postfix_str('New text')
            l.update(20)
            l.set_postfix_str('Overwriting text')
            l.update(30)
            l.set_postfix_str('')
            l.update(40)
            l.close()
            l.update(50)
        with cls(100, miniters=0) as l:
            l.set_postfix_str('New text')
