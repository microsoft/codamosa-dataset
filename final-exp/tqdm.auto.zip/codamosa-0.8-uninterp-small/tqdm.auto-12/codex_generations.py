

# Generated at 2022-06-26 09:06:58.643823
# Unit test for function trange
def test_trange():
    # check that output is ordered
    assert list(tqdm(range(3))) == [0, 1, 2]
    # check that auto range works
    assert list(tqdm()) == []
    assert list(trange(3)) == [0, 1, 2]


# Generated at 2022-06-26 09:07:01.149255
# Unit test for function trange
def test_trange():
    tqdm.write("Test case 0")
    test_case_0()
    tqdm.write("Success: function trange")

# Main function for unit test

# Generated at 2022-06-26 09:07:06.739156
# Unit test for function trange
def test_trange():
    trange(3,3)
    trange(3)
    trange(3,3,3)
    trange(3,3,1)
    trange(3,2,2)
    trange(3,-2,2)


# Generated at 2022-06-26 09:07:20.264900
# Unit test for function trange
def test_trange():
    from tqdm import tqdm, auto
    from random import random
    from time import sleep
    for i in trange(10, desc='1st loop'):
        for j in auto.tqdm(range(5),
                           desc='2nd loop',
                           leave=False):
            for k in auto.tqdm(range(100), leave=False):
                sleep(0.01)
    print('end')

    assert len([i for i in trange(10)]) == 10
    assert len(list(trange(10, desc='test'))) == 10
    assert len(list(trange(10, ascii=True))) == 10


# Generated at 2022-06-26 09:07:21.454402
# Unit test for function trange
def test_trange():

    test_case_0()
    return True



# Generated at 2022-06-26 09:07:34.054348
# Unit test for function trange
def test_trange():
    import tqdm
    import collections
    class Tqdm(collections.Sequence):

        def __init__(self, iterable=None, desc=None, total=None, leave=False, file=sys.stderr,
                     ncols=0, mininterval=0.1, maxinterval=10.0, miniters=None, ascii=None,
                     disable=None, unit='it', unit_scale=False, dynamic_ncols=False,
                     smoothing=0.3, bar_format=None, initial=0, position=None, postfix=None,
                     unit_divisor=1000, gui=False, **kwargs):
            self.iterable = iterable
            self.desc = desc
            self.total = total
            self.leave = leave
            self.file = file

# Generated at 2022-06-26 09:07:38.099989
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange.
    """
    # Check that it throws expected errors
    if 1:
        error_thrown = False
        try:
            var_0 = trange()
        except:
            error_thrown = True
        assert error_thrown

    # Basic usage
    if 1:
        # (generate parentheses, commas, and spaces)
        var_0 = trange()

    # Execute function
    test_case_0()

# Generated at 2022-06-26 09:07:42.505463
# Unit test for function trange
def test_trange():
    var_0 = trange()
    var_1 = trange(100)
    var_1 = trange(100, desc = 'main')
    var_2 = trange(100, desc = 'main', leave = True)


# Generated at 2022-06-26 09:07:50.321139
# Unit test for function trange
def test_trange():
    assert len(tqdm(range(10))) == 10
    assert list(tqdm(range(10))) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert list(tqdm([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert len(tqdm(range(10), ncols=25)) == 10
    assert list(tqdm(range(10), ncols=25)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-26 09:07:52.618226
# Unit test for function trange
def test_trange():
    assert(__name__ == '__main__')


if __name__ == '__main__':
    test_case_0()