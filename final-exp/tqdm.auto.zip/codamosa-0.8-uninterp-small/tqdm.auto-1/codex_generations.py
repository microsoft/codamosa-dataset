

# Generated at 2022-06-26 09:07:08.696879
# Unit test for function trange
def test_trange():
    arg1 = []
    arg2 = {}
    arg3 = [1]
    arg4 = [0, 10]
    arg5 = [0, 10, 1]
    arg6 = [0, 10, 2]

    trange(arg1)
    trange(arg2)
    trange(arg3)
    trange(arg4)
    trange(arg5)
    trange(arg6)

if __name__ == "__main__":
    test_case_0()
    test_trange()

# Generated at 2022-06-26 09:07:13.346336
# Unit test for function trange
def test_trange():
    # source: https://github.com/tqdm/tqdm/issues/484
    from tqdm.auto import trange
    from time import sleep

    lst = ['a', 'b', 'c']
    for i in trange(len(lst)):
        lst[i] += 'x'
        sleep(1)
    assert lst == ['ax', 'bx', 'cx']


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-26 09:07:22.372260
# Unit test for function trange
def test_trange():
    # Testing only in case of auto
    try:
        from tqdm import tqdm_gui
    except (ImportError, ModuleNotFoundError):
        pass
    else:
        raise RuntimeError("`tqdm.auto` should not depend on `tqdm.gui`")

    from tqdm import __version__ as tqdm_version

    # Testing only in case of auto
    if __name__ == "__main__":
        module_name = __name__
        tqdm_version = __version__
    else:
        import os
        import sys

        module_name = os.path.relpath(sys.modules["tqdm.auto"].__file__, ".")
        # module_name = __file__.rsplit("/", 1)[1]

# Generated at 2022-06-26 09:07:24.578214
# Unit test for function trange
def test_trange():
    var_0 = trange()


# Generated at 2022-06-26 09:07:25.109408
# Unit test for function trange
def test_trange():
    assert trange()


# Generated at 2022-06-26 09:07:30.002144
# Unit test for function trange
def test_trange():

    # Define variables
    var_0 = None

    # Setup the call to the wrapped function
    with patch('builtins.print', create=True) as mock_print:
        var_0 = trange()

    # Check the results of calling the wrapped function
    assert var_0 == None


# Generated at 2022-06-26 09:07:32.606511
# Unit test for function trange
def test_trange():
    trange()

if __name__ == "__main__":
    test_case_0()
    test_trange()

# Generated at 2022-06-26 09:07:36.815981
# Unit test for function trange
def test_trange():
    assert type(trange()) == tqdm
    assert type(trange(10)) == tqdm
    assert type(trange(1, 10)) == tqdm
    assert type(trange(1, 10, 2)) == tqdm
    assert type(tqdm(range(10), leave=True)) == tqdm
    return True

print("Testing function trange")
print(test_trange())

# Generated at 2022-06-26 09:07:39.114097
# Unit test for function trange
def test_trange():

    # 1. Call function as trange() and check return value is correct
    assert trange() == range()



# Generated at 2022-06-26 09:07:45.874589
# Unit test for function trange
def test_trange():

    # tqdm warnings
    print("TqdmExperimentalWarning is expected! (See #2649)")
    var_1 = tqdm.__version__
    # tqdm StdErr
    print("tqdm:   Test Case 0: Subprocess")
    var_2 = trange()

    assert var_1 == '4.47.0'
    assert var_2 == var_0