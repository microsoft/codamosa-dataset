

# Generated at 2022-06-26 09:07:07.274061
# Unit test for function trange
def test_trange():
    assert trange(3,3) == [0, 1, 2], 'Incorrect function'
    assert trange(3,3) != [1, 2, 3], 'Incorrect function'
    assert tqdm(3,3) == [0, 1, 2], 'Incorrect function'
    assert tqdm(3,3) != [1, 2, 3], 'Incorrect function'

# Test for notebook_trange and notebook_tqdm

# Generated at 2022-06-26 09:07:08.466795
# Unit test for function trange
def test_trange():
    for i in trange(4):
        pass

# Generated at 2022-06-26 09:07:09.344516
# Unit test for function trange
def test_trange():
    assert str(trange()) != ""

# Generated at 2022-06-26 09:07:10.182438
# Unit test for function trange
def test_trange():
    assert trange() is not None



# Generated at 2022-06-26 09:07:18.345763
# Unit test for function trange
def test_trange():
    # Wrap the cost function and report progress at every step.
    from tqdm import trange
    from time import sleep

    rng = trange(10, desc='1st loop')
    for i in rng:
        # Print using tqdm class method .write()
        rng.write(f'{i}/10', file=sys.stderr)
        sleep(1)
    rng.close()


# Generated at 2022-06-26 09:07:19.890247
# Unit test for function trange
def test_trange():
    assert len(trange()) == 1


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-26 09:07:32.444816
# Unit test for function trange
def test_trange():
    assert ((lambda var_0: ((var_0 in range(0, 10)) and (var_0 == range(0, 10))) if (var_0 == __import__('itertools').chain(__import__('itertools').chain(__import__('itertools').chain((__import__('tqdm.auto').tqdm.__class__.__name__, __import__('tqdm.auto').tqdm), __imports__)))) else ((var_0 in range(0, 10)) and (var_0 == range(0, 10))))(trange(10)))

# Generated at 2022-06-26 09:07:35.006600
# Unit test for function trange
def test_trange():
    seq1 = list(trange(9, 5, -1.5))
    seq2 = [9, 7.5, 6, 4.5]
    assert seq1 == seq2

# Generated at 2022-06-26 09:07:36.066514
# Unit test for function trange
def test_trange():
    assert(isinstance(test_case_0, range))

# Generated at 2022-06-26 09:07:37.286023
# Unit test for function trange
def test_trange():
  assert trange(10) is None