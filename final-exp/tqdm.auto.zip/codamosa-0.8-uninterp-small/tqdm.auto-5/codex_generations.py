

# Generated at 2022-06-26 09:07:00.526728
# Unit test for function trange
def test_trange():
    assert callable(trange), "Function `trange` not defined"


if __name__ == "__main__":
    a = 5
    b = 10

    print(trange(a, b, 2))
    print(sum(trange(a, b, 2)))

# Generated at 2022-06-26 09:07:11.773238
# Unit test for function trange
def test_trange():
    var_0 = trange()
    var_1 = trange()
    var_2 = trange()
    var_3 = trange()
    var_4 = trange(0)
    var_5 = trange(0)
    var_6 = trange(0)
    var_7 = trange(0)
    var_8 = trange(0, 1)
    var_9 = trange(0, 1)
    var_10 = trange(0, 1)
    var_11 = trange(0, 1)
    var_12 = trange(0, 1, 1)
    var_13 = trange(0, 1, 1)
    var_14 = trange(0, 1, 1)
    var_15 = trange(0, 1, 1)
    var_16 = trange

# Generated at 2022-06-26 09:07:14.869114
# Unit test for function trange
def test_trange():
    assert (hasattr(trange(), '_tqdm_gui'))



# Generated at 2022-06-26 09:07:19.428725
# Unit test for function trange
def test_trange():
    from .std import tqdm
    assert trange is tqdm.trange  # pylint: disable=comparison-with-callable
    assert tqdm.auto.trange is tqdm.trange  # pylint: disable=comparison-with-callable


# Generated at 2022-06-26 09:07:26.262451
# Unit test for function trange
def test_trange():
    print()
    if isinstance(tqdm(tuple()),tuple):
        print("trange(0) is successful")
    else:
        print("trange(0) FAIL")

    if isinstance(tqdm(list()),list):
        print("trange(0) is successful")
    else:
        print("trange(0) FAIL")


# Generated at 2022-06-26 09:07:34.512450
# Unit test for function trange
def test_trange():
    def tqdm_tee(*args, **kwargs):
        return tqdm(*args, **kwargs)

    assert len(list(tqdm_tee(trange(0), file=sys.stderr))) == 0
    assert len(list(tqdm_tee(trange(1), file=sys.stderr))) == 1
    assert len(list(tqdm_tee(trange(2), file=sys.stderr))) == 2
    assert len(list(tqdm_tee(trange(3), file=sys.stderr))) == 3

# Generated at 2022-06-26 09:07:35.510869
# Unit test for function trange
def test_trange():
    assert callable(trange)

test_trange()

# Generated at 2022-06-26 09:07:37.465794
# Unit test for function trange
def test_trange():
    assert str(type(test_case_0())) == "<class 'tqdm._tqdm_notebook.tqdm_notebook'>"


# Generated at 2022-06-26 09:07:41.447742
# Unit test for function trange
def test_trange():
    trange(1)
    return trange(1)


if __name__ == "__main__":
    trange(1)
    test_case_0()

# Generated at 2022-06-26 09:07:49.901928
# Unit test for function trange
def test_trange():
    assert trange([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert trange([1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37]) == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37]

# Generated at 2022-06-26 09:07:57.213579
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=TqdmExperimentalWarning)
        from tqdm.autonotebook import trange as notebook_trange

    assert notebook_trange() == trange()


# Generated at 2022-06-26 09:08:01.636875
# Unit test for function trange
def test_trange():
    trange(1)
    trange(1, 19)
    trange(1, 19, 2)
    trange(1, 19, 2, 4)
    trange()


# Generated at 2022-06-26 09:08:03.844499
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), notebook_trange)


# Generated at 2022-06-26 09:08:05.422974
# Unit test for function trange
def test_trange():
    test_case_0()


if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-26 09:08:11.859040
# Unit test for function trange
def test_trange():
    var_name = trange()
    assert isinstance(var_name, NotebookWrap)
    assert var_name._range_len == 1
    assert var_name._desc == ''
    var_name = trange(3)
    assert isinstance(var_name, NotebookWrap)
    assert var_name._range_len == 1
    assert var_name._desc == ''
    var_name = trange(4,4)
    assert isinstance(var_name, range)
    assert list(var_name) == []
    var_name = trange(4,4,2)
    assert isinstance(var_name, range)
    assert list(var_name) == []
    var_name = trange(4,8)
    assert isinstance(var_name, NotebookWrap)
    assert var

# Generated at 2022-06-26 09:08:14.330164
# Unit test for function trange
def test_trange():
    with pytest.raises(TypeError) as e:
        test_case_0()
    assert str(e.value) == "trange() missing 1 required positional argument: 'n'"

# Generated at 2022-06-26 09:08:16.796985
# Unit test for function trange
def test_trange():
    try:
        assert callable(trange())
    except Exception:
        raise AssertionError

# Generated at 2022-06-26 09:08:23.034962
# Unit test for function trange
def test_trange():
    from .std import tqdm
    from .std import trange
    from .std import TqdmExperimentalWarning
    assert trange == tqdm
    with warnings.catch_warnings():
        for warning in TqdmExperimentalWarning:
            warnings.simplefilter(
                'ignore', category=testing)
        testing = trange()
    # assert testing.assertRaises(TqdmExperimentalWarning)
    # assert trange.assertRaises(TqdmExperimentalWarning)
    # assert tqdm.assertRaises(TqdmExperimentalWarning)


# Generated at 2022-06-26 09:08:34.188815
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    See https://docs.python.org/3/library/unittest.html
    """

    # Define the class TestCase
    class TestCase(unittest.TestCase):
        """
        Defines : class:`TestCase <TestCase>` for function `trange`.
        """

        # Setup for the test
        def setUp(self):
            """
            Setup for the test
            """
            try:
                # Try to delete the file
                os.remove("temp.txt")
            except:
                # Do nothing
                pass

        # Function to test `trange`
        def test_trange(self):
            """
            Test function `trange`.
            """
            # Retrieve the current git branch

# Generated at 2022-06-26 09:08:36.877800
# Unit test for function trange
def test_trange():
    # default case
    var_2 = trange()
    # int case
    var_1 = trange(100)
    assert var_1
    assert var_2



# Generated at 2022-06-26 09:08:41.089681
# Unit test for function trange
def test_trange():
    assert trange(3) == notebook_trange(3)


# Generated at 2022-06-26 09:08:42.908086
# Unit test for function trange
def test_trange():

    # Tests for proper unit test coverage
    assert var_0, "Need to define var_0 for test_trange"

# Generated at 2022-06-26 09:08:46.385208
# Unit test for function trange
def test_trange():
    assert hasattr(trange, '__call__')
    assert hasattr(trange, '__name__')
    test_case_0()


# Generated at 2022-06-26 09:08:57.906478
# Unit test for function trange
def test_trange():
    # print("\nRunning test for tqdm.auto trange")
    # Unit test for the trange function
    # args_1: (range), kwargs_2: {}, expectation_3: Range(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    # setup_4:
    # print("\nUnit test for function \"trange\" with arguments: range")
    # test_case_5
    var_1 = range(10)
    # expectation_6: Range(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    # var_2 = <class 'range'>
    assert str(type(var_1)) == "<class 'range'>"
    # setup_7:
    # test_case_8
    var_2 = trange()

# Generated at 2022-06-26 09:08:58.699634
# Unit test for function trange
def test_trange():
    assert trange != notebook_trange

# Generated at 2022-06-26 09:09:09.402878
# Unit test for function trange
def test_trange():
    test_case_0()
    # unit test for trange
    import os
    import sys
    import re
    import subprocess
    import filecmp
    import pip
    import shutil

    print("Testing trange")
    failed_tests = []
    # Determine the root directory of the Git repository.
    root_dir = subprocess.check_output("git rev-parse --show-toplevel", shell=True).decode("utf-8").strip()

    # Install the package.
    os.chdir(root_dir)
    pip.main(["install", "."])

    # Run the test suite.
    os.chdir("tests")
    test_command = "pytest -vs --color=yes " \
                   "--tb=short " \
                   "--junitxml=test_report.xml "

# Generated at 2022-06-26 09:09:19.466371
# Unit test for function trange
def test_trange():
    """
    Unit test for trange
    """
    import tempfile
    import os
    filen = tempfile.gettempdir() + os.sep + 'test_trange.log'
    rv = 0
    try:
        f = open(filen, 'w')
        f.write(('\n'.join([str(var_0) for var_0 in test_case_0()])))
    except Exception as e:
        print('Error in test case 0: ' + str(e))
        rv += 1
    finally:
        try:
            f.close()
        except:
            pass
    try:
        os.remove(filen)
    except:
        pass
    return rv


# Generated at 2022-06-26 09:09:21.402521
# Unit test for function trange
def test_trange():
    for i in trange(10):
        continue


# Generated at 2022-06-26 09:09:22.643626
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), tqdm)


# Generated at 2022-06-26 09:09:27.967543
# Unit test for function trange
def test_trange():
    """
    Tests that whether the trange function works properly

    Parameters
    ----------
    None

    Raises
    ------
    AssertionError if test fails

    Returns
    ----------
    None
    """
    output = trange()
    assert trange() == output, f"Expected output to be {output}, but it was {trange()}"
    assert trange(), "Expected this test to return True"


# Generated at 2022-06-26 09:09:36.186854
# Unit test for function trange
def test_trange():

    for _ in trange(10):
        pass


# Generated at 2022-06-26 09:09:40.672480
# Unit test for function trange
def test_trange():
    """
    Ensures that tqdm can be used to iterate over a range of values
    """
    var_1 = trange(5)

    assert list(var_1) == list(range(5))


# Generated at 2022-06-26 09:09:43.654623
# Unit test for function trange
def test_trange():
    var_0 = trange(0)
    var_1 = trange(1)
    var_2 = trange(2)
    var_3 = trange(3)
    var_4 = trange(4)
    var_5 = trange(5)



# Generated at 2022-06-26 09:09:46.686259
# Unit test for function trange
def test_trange():
    """
    Unit test for function trange
    """
    # sample test
    test_case_0()


# Generated at 2022-06-26 09:09:49.139448
# Unit test for function trange
def test_trange():
    """Function `trange` is defined."""
    assert callable(trange)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 09:09:56.252962
# Unit test for function trange
def test_trange():
    assert isinstance(trange(1), tqdm)
    assert isinstance(trange(1, 2), tqdm)
    assert isinstance(trange(1, 2, 3), tqdm)
    assert isinstance(trange(1, bar_format="{l_bar}"), tqdm)
    assert isinstance(trange(1, bar_format="{l_bar}", mininterval=0.5), tqdm)
    assert isinstance(trange(1, bar_format="{l_bar}", mininterval=0.5, smoothing=0.3), tqdm)
    assert isinstance(trange(1, bar_format="{l_bar}", mininterval=0.5, smoothing=0.3, maxinterval=0.9), tqdm)

# Generated at 2022-06-26 09:09:57.671031
# Unit test for function trange
def test_trange():
    with pytest.raises(TypeError):
        trange()

# Generated at 2022-06-26 09:10:09.053414
# Unit test for function trange
def test_trange():
    # Test case 1
    var_0 = trange([])
    assert var_0.__class__.__name__ == "_trange_cls_gen"

    # Test case 2
    var_0 = trange([], 1)
    assert var_0.__class__.__name__ == "_trange_cls_gen"

    # Test case 3
    var_0 = trange([], 1, 2)
    assert var_0.__class__.__name__ == "_trange_cls_gen"

    # Test case 4
    var_0 = trange([], 1, 2, 3)
    assert var_0.__class__.__name__ == "_trange_cls_gen"

    # Test case 5
    var_0 = trange([], 1, 2, 3, 4)
    assert var

# Generated at 2022-06-26 09:10:11.662652
# Unit test for function trange
def test_trange():
    # State that trange returns a tqdm generator
    assert isinstance(trange(), tqdm)


# Generated at 2022-06-26 09:10:13.183418
# Unit test for function trange
def test_trange():

    # Call function trange
    var_0 = trange()

# Generated at 2022-06-26 09:10:27.074109
# Unit test for function trange
def test_trange():
    with trange(10) as var_1:
        pass
    


# Generated at 2022-06-26 09:10:28.577017
# Unit test for function trange
def test_trange():
    assert(trange() != None)


# Generated at 2022-06-26 09:10:30.819360
# Unit test for function trange
def test_trange():
    from .std import trange

    # See #548
    for i in trange(100, desc="test"):
        pass



# Generated at 2022-06-26 09:10:40.100638
# Unit test for function trange
def test_trange():
    # Test with 0 args.
    test_case_0()

    # Test with multiple args.
    var_0 = trange(0, var_0, 0, 0)
    var_1 = trange(0, 0, var_0)
    var_2 = trange(var_0, 0, 0)
    var_3 = trange(var_0, var_1, var_2)
    var_4 = trange(var_2, var_0, var_1)
    var_5 = trange(var_1, var_2, var_0)
    var_6 = trange(var_1, var_0, var_2)
    var_7 = trange(var_2, var_1, var_0)

# Generated at 2022-06-26 09:10:44.385063
# Unit test for function trange
def test_trange():
    # Case 0
    # Case 0 (Check Type)
    if not isinstance(test_case_0(), _tqdm.tqdm):
        raise TypeError("trange does not return a tqdm instance")

if __name__ == "__main__":
    test_trange()

# Generated at 2022-06-26 09:10:50.282162
# Unit test for function trange
def test_trange():
    import io
    import sys
    import unittest
    from contextlib import redirect_stdout

    class TestTrange(unittest.TestCase):
        def test_case_0(self):
            capturedOutput = io.StringIO()
            with redirect_stdout(capturedOutput):
                test_case_0()

    # Do the tests
    unittest.main()

# Generated at 2022-06-26 09:10:54.650700
# Unit test for function trange
def test_trange():
    """
    This is a unit test for 'trange', a wrapper for 'tqdm.auto.tqdm' to work with
    'range' inputs by default.
    """
    # Test case 0: no args
    test_case_0()

# Generated at 2022-06-26 09:10:56.461667
# Unit test for function trange
def test_trange():
    var_0 = trange()
    assert var_0 == var_0


# Generated at 2022-06-26 09:10:57.276089
# Unit test for function trange
def test_trange():
    test_case_0()



# Generated at 2022-06-26 09:11:00.492433
# Unit test for function trange
def test_trange():
    # Setup
    t0 = trange(15)
    t1 = trange()

    # Exercise
    None

    # Verify
    assert t0.total == 15
    assert t1.total == 0

    # Cleanup
    t0.close()
    t1.close()



# Generated at 2022-06-26 09:11:29.667055
# Unit test for function trange
def test_trange():
    assert callable(trange)
    var_0 = trange()
    var_1 = trange(int())
    var_2 = trange(int(), int())
    var_3 = trange(int(), int(), int())


# Generated at 2022-06-26 09:11:30.586511
# Unit test for function trange
def test_trange():
    var_0 = trange()

# Generated at 2022-06-26 09:11:32.962734
# Unit test for function trange
def test_trange():
    # empty_test_case
    # construct object
    obj = trange()


# Generated at 2022-06-26 09:11:36.545524
# Unit test for function trange
def test_trange():
    from tqdm import tqdm, trange
    list_0 = list(range(10))
    list_1 = list(tqdm(list_0))
    list_2 = list(trange(10))
    assert list_2 == list_1


# Generated at 2022-06-26 09:11:37.637530
# Unit test for function trange
def test_trange():
    trange(10)



# Generated at 2022-06-26 09:11:39.335607
# Unit test for function trange
def test_trange():
    assert 0 == 0, 'Test case 0 failed'


# Generated at 2022-06-26 09:11:42.510968
# Unit test for function trange
def test_trange():
    """
    Verify if all elements in the iterator are in the range of [0, 10]
    """
    var_1 = trange(10)
    for i in var_1:
        assert i in range(10)


# Generated at 2022-06-26 09:11:52.953493
# Unit test for function trange
def test_trange():
    import inspect
    import sys
    from .auto import trange
    # Test positional args
    # Test keyword args

# Generated at 2022-06-26 09:11:54.861955
# Unit test for function trange
def test_trange():
    try:
        _ = trange()
    except:
        raise AssertionError("Function is not callable")
    return True


# Generated at 2022-06-26 09:11:58.695213
# Unit test for function trange
def test_trange():
    for i in trange(4):
        for j in trange(4):
            for k in trange(4):
                assert k**2 > i**2 + y**2

