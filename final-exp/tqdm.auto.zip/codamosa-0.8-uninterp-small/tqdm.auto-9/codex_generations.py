

# Generated at 2022-06-26 09:06:59.248373
# Unit test for function trange
def test_trange():
    var_0 = trange()

# Generated at 2022-06-26 09:07:00.610563
# Unit test for function trange
def test_trange():
    from tqdm import trange
    var_0 = trange()

# Generated at 2022-06-26 09:07:04.539734
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), tqdm)
    assert isinstance(trange(), notebook_tqdm)

# Checking if trange() is trange

# Generated at 2022-06-26 09:07:05.835972
# Unit test for function trange
def test_trange():
    test_case_0()

# Generated at 2022-06-26 09:07:14.066053
# Unit test for function trange
def test_trange():
    try:
        assert isinstance(trange(), tqdm)
    except Exception as e:
        print("Exception raised: ", e)
        assert False


# Generated at 2022-06-26 09:07:15.478856
# Unit test for function trange
def test_trange():
    assert_equals(type(trange()), tqdm)


# Generated at 2022-06-26 09:07:17.531810
# Unit test for function trange
def test_trange():
    var_1 = trange()
    # assert var_1 == expected


# Generated at 2022-06-26 09:07:19.150796
# Unit test for function trange
def test_trange():
    var1 = trange()
    assert var1 != None, "trange() returned None"


# Generated at 2022-06-26 09:07:20.044831
# Unit test for function trange
def test_trange():
    assert trange() == trange()
##

# Generated at 2022-06-26 09:07:21.208967
# Unit test for function trange
def test_trange():
    for i in trange(10):
        pass


# Generated at 2022-06-26 09:07:26.506887
# Unit test for function trange
def test_trange():
    # Set up test values
    exp_res = []

    out_res = trange().read()

    assert(exp_res == out_res)


# Generated at 2022-06-26 09:07:29.618228
# Unit test for function trange
def test_trange():
    for _ in trange(4):
        pass

if __name__ == "__main__":
    test_trange()
    test_case_0()

# Generated at 2022-06-26 09:07:31.098631
# Unit test for function trange
def test_trange():
    data = list(range(5))
    assert trange(5) == data

# Generated at 2022-06-26 09:07:32.839990
# Unit test for function trange
def test_trange():
    assert test_case_0() is not TracerWarning

test_trange()

# Generated at 2022-06-26 09:07:33.705406
# Unit test for function trange
def test_trange():
    test_case_0()



# Generated at 2022-06-26 09:07:34.971148
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), notebook_trange)


# Generated at 2022-06-26 09:07:36.969369
# Unit test for function trange
def test_trange():
    var_0 = trange(0)
    assert var_0 == 0

# Generated at 2022-06-26 09:07:41.858106
# Unit test for function trange
def test_trange():
    char_0 = []
    with trange(5) as var_0:
        for var_1 in var_0:
            char_0.append(var_1)
    assert char_0 == list(range(5))



# Generated at 2022-06-26 09:07:46.525566
# Unit test for function trange
def test_trange():
    from tqdm import auto

    # Call function trange
    # Check if function call has been executed
    tqdm = auto.tqdm
    assert tqdm == auto.tqdm

    trange = auto.trange
    assert trange == auto.trange


# Generated at 2022-06-26 09:07:47.904795
# Unit test for function trange
def test_trange():
    assert trange(0, 1, 0.01) == tqdm(range(0, 1, 0.01))