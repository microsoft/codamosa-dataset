

# Generated at 2022-06-26 09:06:56.701959
# Unit test for function trange
def test_trange():
    assert type(trange()) == type(tqdm())



# Generated at 2022-06-26 09:06:57.916418
# Unit test for function trange
def test_trange():
    assert trange, 'Error: function(trange) not found'



# Generated at 2022-06-26 09:06:59.199509
# Unit test for function trange
def test_trange():
    assert trange() == None


# Generated at 2022-06-26 09:07:09.589460
# Unit test for function trange
def test_trange():
    # Initialise
    var_0 = trange() # temp_0 holds range(10)

    # Check temp_0 is tqdm instance
    assert( isinstance(var_0, tqdm) )
    # Check temp_0 has not been updated yet
    assert( var_0.n != 0 )

    # Update temp_0
    for i in var_0:
        # If we are here, the test has passed.
        break

    # Check temp_0 was updated
    assert( var_0.n == 0 )

if __name__ == '__main__':
    test_case_0()
    test_trange()

# Generated at 2022-06-26 09:07:11.424114
# Unit test for function trange
def test_trange():
    with trange(10) as t:
        assert len(t) == 10

# Generated at 2022-06-26 09:07:14.012505
# Unit test for function trange
def test_trange():
    assert 2 == len(trange())


# Generated at 2022-06-26 09:07:15.434078
# Unit test for function trange
def test_trange():
    # no parameters
    assert trange() is not None


# Generated at 2022-06-26 09:07:19.310374
# Unit test for function trange
def test_trange():
    var_0 = trange(4)
    # Iter
    for elem_1 in var_0:
        pass


if __name__ == "__main__":
    test_case_0()
    test_trange()

# Generated at 2022-06-26 09:07:31.431111
# Unit test for function trange
def test_trange():
    #for i in trange(10, desc='1st loop', bar_format="{l_bar}{bar:20}{r_bar}"):
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                pass

if __name__ == '__main__':
    import argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument("-case0", help="test case_0", type=bool,
			action="store", dest="case0", default=False)

# Generated at 2022-06-26 09:07:36.596503
# Unit test for function trange
def test_trange():
    num_1 = 5
    num_2 = 10
    num_3 = 0
    ret_0 = trange(num_1, num_2)
    for var_0 in ret_0:
        num_3 += 1
        if num_3 == 5:
            assert var_0 == 4

    for var_0 in ret_0:
        num_3 += 1
        if num_3 == 10:
            assert var_0 == 9
