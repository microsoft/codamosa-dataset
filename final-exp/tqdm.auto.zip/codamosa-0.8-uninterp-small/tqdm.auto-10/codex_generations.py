

# Generated at 2022-06-26 09:07:03.521802
# Unit test for function trange
def test_trange():
    from .utils import _suppress_stdout

    with _suppress_stdout():
        trange()
        trange(10)
        trange(3, 10)
        trange(3, 10, 2)
        trange(3, 10, 2, None, None, False, None)
        trange(3, 10, 2, None, None, True, None)
        trange(3, 10, 2, None, None, True, None, None, None, "Progress! ")
        trange(3, 10, 2, None, None, True, None, None, None, "Progress! ",
               dynamic_ncols=True)
        trange(3, 10, 2, None, None, True, None, None, None, "Progress! ",
               ascii=True)

# Generated at 2022-06-26 09:07:12.909615
# Unit test for function trange
def test_trange():
    var_1 = list(trange(10))
    assert len(var_1) == 10
    assert var_1 == list(range(10))

    var_2 = list(trange(10, 0))
    assert len(var_2) == 10
    assert var_2 == list(range(10, 0))

    var_3 = list(trange(10, 0, -1))
    assert len(var_3) == 10
    assert var_3 == list(range(10, 0, -1))

    var_4 = list(trange(10, 2, -1))
    assert len(var_4) == 8
    assert var_4 == list(range(10, 2, -1))

    var_5 = list(trange(10, 2))
    assert len(var_5) == 8
   

# Generated at 2022-06-26 09:07:17.439517
# Unit test for function trange
def test_trange():
    # Demonstrate trange
    for i in trange(10):
        print(i)

    # Demonstrate wrapping of trange
    for i in tqdm(trange(10)):
        print(i)


# Generated at 2022-06-26 09:07:18.419294
# Unit test for function trange
def test_trange():
    if True:
        test_case_0()


# Generated at 2022-06-26 09:07:25.274574
# Unit test for function trange
def test_trange():
    from datetime import datetime
    import time
    from tqdm.auto import trange
    if sys.version_info[:2] < (3, 6):
        before = datetime.now()
        for i in trange(1000):
            time.sleep(0.01)
        after = datetime.now()
        assert after - before > datetime(year=1, month=1, day=1)
    else:
        import asyncio
        before = datetime.now()
        loop = asyncio.get_running_loop()
        async def range_sleeper():
            for i in trange(1000):
                await asyncio.sleep(0.01)
        loop.run_until_complete(range_sleeper())
        after = datetime.now()

# Generated at 2022-06-26 09:07:26.408773
# Unit test for function trange
def test_trange():
    assert type(trange()) is tqdm

# Generated at 2022-06-26 09:07:28.329694
# Unit test for function trange
def test_trange():
    for _ in trange(10):
        pass


# Generated at 2022-06-26 09:07:30.436562
# Unit test for function trange
def test_trange():
    assert len(trange()) == 1
    assert len(trange(4)) == 4
    assert sum(trange(4)) == 6



# Generated at 2022-06-26 09:07:33.736630
# Unit test for function trange
def test_trange():
    assert (trange().__class__ == tqdm().__class__)
    assert (trange(1, 2, 3, 4, 5).__class__ == tqdm().__class__)

# Generated at 2022-06-26 09:07:34.970820
# Unit test for function trange
def test_trange():
    assert isinstance(trange(),tqdm)

test_trange()