

# Generated at 2022-06-26 09:07:00.610766
# Unit test for function trange
def test_trange():
    assert hasattr(trange(), '_instances')

# Generated at 2022-06-26 09:07:02.749012
# Unit test for function trange
def test_trange():
    assert(test_case_0()),'test case trange 0 failed'


# Generated at 2022-06-26 09:07:06.825823
# Unit test for function trange
def test_trange():
    from tqdm.auto import tqdm
    from tqdm import trange
    with tqdm(total=2) as pbar:
        for i in trange(2):
            pbar.update()

# Generated at 2022-06-26 09:07:12.407936
# Unit test for function trange
def test_trange():
    try:
        trange()
    except:
        print(False)



# Generated at 2022-06-26 09:07:20.115720
# Unit test for function trange
def test_trange():
    assert trange() == tqdm()
    assert trange(5) == tqdm(5)
    assert trange(5, 5) == tqdm(5, 5)
    assert trange(5, 5, 1) == tqdm(5, 5, 1)
    assert trange(0, 5, 1) == tqdm(0, 5, 1)
    assert trange(0, 5, 1, leave=True) == tqdm(0, 5, 1, leave=True)


# Generated at 2022-06-26 09:07:21.619331
# Unit test for function trange
def test_trange():
    assert hasattr(trange(), '__iter__'), "trange is not a iterator"


# Generated at 2022-06-26 09:07:25.544535
# Unit test for function trange
def test_trange():
    # assert func_0(arg_0) == expected_0
    assert True

if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-26 09:07:29.190351
# Unit test for function trange
def test_trange():

    x = trange(10)
    try:
        next(x)
    except Exception as e:
        assert isinstance(e, StopIteration)
        assert str(e) == 'GeneratorExit'


# Generated at 2022-06-26 09:07:30.136621
# Unit test for function trange
def test_trange():
    assert trange()

# Test case 1

# Generated at 2022-06-26 09:07:32.405577
# Unit test for function trange
def test_trange():
    assert tqdm == notebook_tqdm
    assert trange == notebook_trange
