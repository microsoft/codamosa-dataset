

# Generated at 2022-06-26 09:06:59.586827
# Unit test for function trange
def test_trange():
    trange()


# Generated at 2022-06-26 09:07:00.868818
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), notebook_tqdm) == True


# Generated at 2022-06-26 09:07:03.100390
# Unit test for function trange
def test_trange():
    assert isinstance(trange(), tqdm)



# Generated at 2022-06-26 09:07:04.539263
# Unit test for function trange
def test_trange():
    trange()



# Generated at 2022-06-26 09:07:05.835471
# Unit test for function trange
def test_trange():
    var_1 = trange()


# Generated at 2022-06-26 09:07:12.270378
# Unit test for function trange
def test_trange():
    for i in trange(10):
        for j in trange(10):
            pass


# Generated at 2022-06-26 09:07:17.720709
# Unit test for function trange
def test_trange():
    from .auto import trange
    from .autonotebook import trange as notebook_trange
    from .asyncio import trange as asyncio_trange
    if notebook_trange != asyncio_trange:
        assert trange == notebook_trange

# Generated at 2022-06-26 09:07:21.078753
# Unit test for function trange
def test_trange():
    var_0 = None
    var_1 = 0
    test_case_0()
    test_trange()
    trange()
    tqdm()
    assert var_0 == var_1, "Expected {}, got {}".format(var_1, var_0)

# Generated at 2022-06-26 09:07:24.270553
# Unit test for function trange
def test_trange():
    # execute function trange
    result = trange()

    # compare result against expected output
    assert result == 0



# Generated at 2022-06-26 09:07:30.437751
# Unit test for function trange
def test_trange():
    from .asyncio import tqdm as asyncio_tqdm
    from .autonotebook import tqdm as notebook_tqdm
    from .std import tqdm as std_tqdm
    if notebook_tqdm != std_tqdm:
        assert trange() == notebook_tqdm(range())
    else:
        assert trange() == asyncio_tqdm(range())