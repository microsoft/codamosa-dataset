

# Generated at 2022-06-26 09:06:57.695408
# Unit test for function trange
def test_trange():
    from tqdm import trange
    from tqdm import tqdm
    assert list(trange(10)) == list(tqdm(range(10)))



# Generated at 2022-06-26 09:07:02.895179
# Unit test for function trange
def test_trange():
    from .asyncio import tqdm as asyncio_tqdm

    output = sys.stdout
    x = [asyncio_tqdm.format_meter(i, 6, 5, 31, 30)
         for i in range(32)]
    for i in trange(32):
        assert (asyncio_tqdm.format_meter(i, 6, 5, 31, 30) == x[i])
    output.write("\n")



# Generated at 2022-06-26 09:07:10.641239
# Unit test for function trange
def test_trange():
    from .std import tqdm as std_tqdm
    from .asyncio import tqdm as asyncio_tqdm

    assert sys.version_info[:2] > (3, 5) or trange is notebook_trange
    assert sys.version_info[:2] < (3, 6) or trange is std_tqdm

    if sys.version_info[:2] > (3, 5):
        assert asyncio_tqdm(range(10)) == std_tqdm(range(10))
        assert trange is tqdm

# Generated at 2022-06-26 09:07:15.761468
# Unit test for function trange
def test_trange():
    lst = list(trange(5))
    assert lst == [0, 1, 2, 3, 4]
    lst = list(trange(5, 10))
    assert lst == list(range(5, 10))

# Generated at 2022-06-26 09:07:17.438399
# Unit test for function trange
def test_trange():
    var_0 = None


# Generated at 2022-06-26 09:07:29.038413
# Unit test for function trange
def test_trange():
    var_0 = trange()
    var_1 = trange()
    var_2 = trange()
    var_3 = trange()
    var_4 = trange()
    var_5 = trange()
    var_6 = trange()
    var_7 = trange()
    var_8 = trange()
    var_9 = trange()
    var_10 = trange()
    var_11 = trange()
    var_12 = trange()
    var_13 = trange()
    var_14 = trange()
    var_15 = trange()
    var_16 = trange()
    var_17 = trange()
    var_18 = trange()
    var_19 = trange()
    var_20 = trange()
    var_21 = trange()
   

# Generated at 2022-06-26 09:07:37.502078
# Unit test for function trange
def test_trange():
    var_0 = trange()
    assert isinstance(var_0, tqdm)
    assert var_0._instances is not None
    var_1 = trange(10)
    assert isinstance(var_1, tqdm)
    assert var_1._instances is not None
    assert var_1.total == 10
    assert var_1.unit == "it"
    var_2 = trange(10, desc="bar")
    assert isinstance(var_2, tqdm)
    assert var_2._instances is not None
    assert var_2.total == 10
    assert var_2.desc == "bar"
    var_3 = trange(0, 10, 2)
    assert isinstance(var_3, tqdm)
    assert var_3._instances is not None
   

# Generated at 2022-06-26 09:07:39.514277
# Unit test for function trange
def test_trange():
    assert isinstance(trange(5), list)



# Generated at 2022-06-26 09:07:49.455213
# Unit test for function trange
def test_trange():
    # Create loop
    for _ in range(100):
        # Create dummy instance
        var_0 = trange()
        assert var_0 is not None
        # Create dummy instance
        var_1 = trange()
        assert var_1 is not None
        # Create dummy instance
        var_2 = trange()
        assert var_2 is not None
        # Create dummy instance
        var_3 = trange()
        assert var_3 is not None
        # Create dummy instance
        var_4 = trange()
        assert var_4 is not None
        # Create dummy instance
        var_5 = trange()
        assert var_5 is not None
        # Create dummy instance
        var_6 = trange()
        assert var_6 is not None
        # Create dummy instance
        var_7 = trange()

# Generated at 2022-06-26 09:08:00.590404
# Unit test for function trange
def test_trange():
    # Example case 0
    try:
        var_0 = trange()
    except:
        # Exception was raised, verify that it is a tqdm.TqdmException
        assert False, "Error raised unexpectedly"

    # Example case 1
    try:
        var_1 = trange(3)
    except:
        # Exception was raised, verify that it is a tqdm.TqdmException
        assert False, "Error raised unexpectedly"

    # Example case 2
    try:
        var_2 = trange(2, 100, 2)
    except:
        # Exception was raised, verify that it is a tqdm.TqdmException
        assert False, "Error raised unexpectedly"

    # Example case 3