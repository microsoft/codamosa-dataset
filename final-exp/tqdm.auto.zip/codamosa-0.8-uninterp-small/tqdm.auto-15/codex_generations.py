

# Generated at 2022-06-26 09:06:58.057186
# Unit test for function trange
def test_trange():
    trange()

# Generated at 2022-06-26 09:06:59.681351
# Unit test for function trange
def test_trange():
    assert trange() != tqdm()



# Generated at 2022-06-26 09:07:00.904276
# Unit test for function trange
def test_trange():
    assert(trange()) == tqdm()



# Generated at 2022-06-26 09:07:04.406104
# Unit test for function trange
def test_trange():
    assert trange() is not None, "Function `trange` is not implemented"


if __name__ == '__main__':
    test_trange()

# Generated at 2022-06-26 09:07:13.266655
# Unit test for function trange
def test_trange():
    var_0 = trange()
    assert type(var_0) == tqdm
    assert var_0.n == 100
    var_0 = trange(2)
    assert var_0.n == 2
    assert var_0.total == 2
    var_0 = trange(3, 10)
    assert var_0.n == 7
    assert var_0.total == 7
    var_0 = trange(1, 2, 3)
    assert var_0.n == 1
    assert var_0.total == 1
    var_0 = trange(100, 500, 3)
    assert var_0.n == 166
    assert var_0.total == 166
    var_0 = trange(3, 1000, 100)
    assert var_0.n == 99

# Generated at 2022-06-26 09:07:14.119543
# Unit test for function trange
def test_trange():
    assert trange()

# Generated at 2022-06-26 09:07:20.411312
# Unit test for function trange
def test_trange():
    import unittest.mock
    var_0 = unittest.mock.Mock()
    try:
        test_case_0()
    except:
        var_0.throw.exception = var_0.throw.exception
        raise
    if not var_0.throw.exception:
        raise AssertionError("No exception was raised")
    var_0.throw.assert_called_once_with(AssertionError,
                                        "No exception was raised")

# Generated at 2022-06-26 09:07:21.900850
# Unit test for function trange
def test_trange():
    trange()
    assert not False

# Main function that calls all unit tests and outputs the results

# Generated at 2022-06-26 09:07:24.942851
# Unit test for function trange
def test_trange():
    var_0 = trange()
    assert var_0 == tqdm()


# Generated at 2022-06-26 09:07:27.559517
# Unit test for function trange
def test_trange():
    # default arguments
    assert not test_case_0()

if __name__ == "__main__":
    test_trange()