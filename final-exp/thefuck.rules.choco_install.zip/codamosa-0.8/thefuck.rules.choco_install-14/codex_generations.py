

# Generated at 2022-06-12 10:57:50.958563
# Unit test for function match
def test_match():
    assert match(Command(script='choco install chocolatey', output='Installing the following packages:'))
    assert match(Command(script='cinst chocolatey', output='Installing the following packages:'))
    assert match(Command(script='choco install chocolatey.someotherthing', output='Installing the following packages:'))
    assert match(Command(script='choco install chocolatey.utils.extension', output='Installing the following packages:'))
    assert match(Command(script='choco install -y chocolatey.utils.extension', output='Installing the following packages:'))
    assert match(Command(script='choco install -force chocolatey.utils.extension', output='Installing the following packages:'))
    assert match(Command(script='cinst -y chocolatey.utils.extension', output='Installing the following packages:'))
    assert match

# Generated at 2022-06-12 10:57:55.921693
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install foo")
    assert get_new_command(command) == ["choco", "install", "foo.install"]
    command = Command("cinst foo")
    assert get_new_command(command) == ["cinst", "foo.install"]
    command = Command("choco list foo")
    assert get_new_command(command) == []

# Generated at 2022-06-12 10:57:59.173740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco install git") == "choco install git.install"
    assert get_new_command("cinst git") == "cinst git.install"

# Generated at 2022-06-12 10:58:07.963258
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (get_new_command(Command('choco install git',
                                    "Installing the following packages:\n"
                                    "git v2.8.0.20160229.1 by Microsoft Open Technologies, Inc.\n"
                                    "GET https://chocolatey.org/api/v2/package/git/2.8.0.20160229.1",
                                    ""))
            == "choco install git.install")

# Generated at 2022-06-12 10:58:09.582891
# Unit test for function match
def test_match():
    assert match(Command("choco install chocolatey"))
    assert match(Command("cinst git"))
    assert not match(Command("choco upgrade chocolatey"))

# Generated at 2022-06-12 10:58:12.181492
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install python')
    assert get_new_command(command) == 'choco install python.install'

# Generated at 2022-06-12 10:58:15.984271
# Unit test for function match
def test_match():
    output = (
        """Installing the following packages:
chocolatey
By installing you accept licenses for the packages.""")
    assert match(Command("choco install chocolatey", output=output))
    assert match(Command("cinst chocolatey", output=output))



# Generated at 2022-06-12 10:58:20.617503
# Unit test for function match
def test_match():
    assert match(Command("choco install notepadplusplus", "Installing the following packages:\nnotepadplusplus"))
    assert match(Command("cinst notepadplusplus", "Installing the following packages:\nnotepadplusplus"))
    assert not match(Command("choco install notepadplusplus", "Installing the following packages:\nnotepadplusplus"))


# Generated at 2022-06-12 10:58:27.494608
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cinst googlechrome', '')) == 'cinst googlechrome.install'
    assert get_new_command(Command('cinst googlechrome --version=1.1.1', '')) == 'cinst googlechrome.install --version=1.1.1'
    assert get_new_command(Command('cinst googlechrome --params="/InstallLocation:C:\Chrome"', '')) == 'cinst googlechrome.install --params="/InstallLocation:C:\Chrome"'
    assert get_new_command(Command('cinst googlechrome --params="/InstallLocation:C:\Chrome --version=1.1.1"', '')) == 'cinst googlechrome.install --params="/InstallLocation:C:\Chrome --version=1.1.1"'

# Generated at 2022-06-12 10:58:30.172576
# Unit test for function match
def test_match():
    assert match(Command("choco install git"))
    assert match(Command("cinst git"))
    assert match(Command("choco install")) is False


# Generated at 2022-06-12 10:58:37.283151
# Unit test for function match
def test_match():
    assert match(Command(script='choco install gpg4win'))
    assert match(Command(script='cinst gpg4win'))



# Generated at 2022-06-12 10:58:44.713207
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install chocolatey")
    assert get_new_command(command) == "choco install chocolatey.install"
    command = Command("choco install -y chocolatey")
    assert get_new_command(command) == "choco install -y chocolatey.install"
    command = Command("cinst chocolatey")
    assert get_new_command(command) == "cinst chocolatey.install"
    # Should not break on a command without a package name
    command = Command("cinst")
    assert get_new_command(command) is None

# Generated at 2022-06-12 10:58:53.725751
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install dk")) == "choco install dk.install"
    assert get_new_command(Command("cinst dk")) == "cinst dk.install"
    assert get_new_command(Command("cinst")) == []
    assert get_new_command(Command("cinst -y dk")) == "cinst -y dk.install"
    assert get_new_command(Command("cinst -x dk")) == "cinst -x dk.install"
    assert get_new_command(Command("choco install -y dk")) == "choco install -y dk.install"
    assert get_new_command(Command("choco install -x dk")) == "choco install -x dk.install"

# Generated at 2022-06-12 10:58:58.418776
# Unit test for function match
def test_match():
    assert match(Command('choco install python', 'Installing the following packages:\npython.install'))
    assert match(Command('cinst python', 'Installing the following packages:\npython.install'))
    assert not match(Command('choco install python', 'Installing the followi'))


# Generated at 2022-06-12 10:59:00.977772
# Unit test for function match
def test_match():
    assert match(Command("cinst chocolatey.extension"))
    assert match(Command("choco install chocolatey.extension"))
    assert not match(Command("choco upgrade chocolatey.extension"))



# Generated at 2022-06-12 10:59:10.356078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chrome")) == "choco install chrome.install"
    assert get_new_command(Command("cinst chrome")) == "cinst chrome.install"
    assert get_new_command(Command("choco install -y googlechrome")) == "choco install -y googlechrome.install"
    assert get_new_command(Command("choco install -y googlechrome --source='https://www.google.com/'")) == "choco install -y googlechrome.install --source='https://www.google.com/'"

# Generated at 2022-06-12 10:59:15.043131
# Unit test for function match
def test_match():
    print(match(Command("choco install test", "", "Installing the following packages:\ntest")))
    print(match(Command("choco install test different", "", "Installing the following packages:\ntest\ndifferent")))
    print(match(Command("cinst test", "", "Installing the following packages:\ntest")))
    print(match(Command("cinst test different", "", "Installing the following packages:\ntest\ndifferent")))



# Generated at 2022-06-12 10:59:25.336183
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install notepadplusplus', '')) == 'choco install notepadplusplus.install'
    assert get_new_command(Command('choco '
                                   'install notepadplusplus.install',
                                   '')) == 'choco install notepadplusplus.install.install'
    assert get_new_command(Command('cinst notepadplusplus', '')) == 'cinst notepadplusplus.install'
    assert get_new_command(Command('choco install notepadplusplus '
                                   '-y',
                                   '')) == 'choco install notepadplusplus.install -y'
    assert get_new_command(Command('choco install "notepad++"', '')) == 'choco install "notepad++".install'

# Generated at 2022-06-12 10:59:28.796458
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install iexplore', '')) == 'choco install iexplore.install'
    assert get_new_command(Command('cinst iexplore', '')) == 'cinst iexplore.install'

# Generated at 2022-06-12 10:59:32.043919
# Unit test for function get_new_command
def test_get_new_command():
    script = "choco install foo"
    output = 'Installing the following packages:'
    command = Command(script, output)
    if enabled_by_default:
        assert get_new_command(command) == "choco install foo.install"

# Generated at 2022-06-12 10:59:45.080673
# Unit test for function get_new_command
def test_get_new_command():
    # Test with script that matches
    command_matched = Command("choco install chocolatey", "")
    assert get_new_command(command_matched) == "choco install chocolatey.install"
    # Test without script that matches
    command_unmatched = Command("choco update chocolatey", "")
    assert get_new_command(command_unmatched) == []

# Generated at 2022-06-12 10:59:55.826812
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install -y package", "", "Installing the following packages:\n  package\nThe package was not installed because a package by that name already exists on the system.\n")
    assert get_new_command(command) == "choco install -y package.install"
    command = Command("cinst -y package", "", "Installing the following packages:\n  package\nThe package was not installed because a package by that name already exists on the system.\n")
    assert get_new_command(command) == "cinst -y package.install"
    command = Command("choco install -y package --version=2.0.0", "", "Installing the following packages:\n  package\nThe package was not installed because a package by that name already exists on the system.\n")

# Generated at 2022-06-12 11:00:00.849491
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install git", "", "", "")) == "choco install git.install"
    assert get_new_command(Command("cinst git", "", "", "")) == "cinst git.install"
    assert (
        get_new_command(Command("cinst git -params value", "", "", "")) == "cinst git.install -params value"
    )
    assert get_new_command(Command("cinst git.install", "", "", "")) == []

# Generated at 2022-06-12 11:00:07.259008
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco install chocolatey") == "choco install chocolatey.install"
    assert get_new_command("choco install chocolatey.extension") == "choco install chocolatey.extension.install"
    assert get_new_command("choco install chocolatey.extension --ignore-dependencies") == "choco install chocolatey.extension.install --ignore-dependencies"
    assert get_new_command("cinst chocolatey.extension --ignore-dependencies --version 1.1.3") == "cinst chocolatey.extension.install --ignore-dependencies --version 1.1.3"
    assert get_new_command("cinst -y chocolatey.extension --ignore-dependencies") == "cinst -y chocolatey.extension.install --ignore-dependencies"
    assert get_new_

# Generated at 2022-06-12 11:00:10.182585
# Unit test for function match
def test_match():
    assert match(Command('choco install nodejs.install',
        stderr='Installing the following packages:'))
    assert match(Command('cinst nodejs.install',
        stderr='Installing the following packages:'))



# Generated at 2022-06-12 11:00:15.574968
# Unit test for function match
def test_match():
    """
    Test if function match correctly matches when package is not installed
    """
    # match command when package not specified
    command = Command("choco install",
                      "Installing the following packages:",
                      "choco install")
    assert match(command)
    command = Command("cinst notepadplusplus",
                      "Installing the following packages:",
                      "cinst notepadplusplus")
    assert match(command)



# Generated at 2022-06-12 11:00:22.759264
# Unit test for function match
def test_match():
    assert match(Command("choco install package"))
    assert match(Command("cinst package"))
    assert match(Command("choco install package -y"))
    assert match(Command("cinst package -y"))
    assert match(Command("choco install package.install -y"))
    assert not match(Command("cinst package.install -y"))
    assert not match(Command("cinst"))
    assert not match(Command("choco"))
    assert not match(Command("cinst -? package"))


# Generated at 2022-06-12 11:00:29.066046
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('cinst truthy') == 'cinst truthy.install'
    assert get_new_command('cinst -source "https://www.myget.org/F/magic/" "Magic.Chocolatey"') == 'cinst -source "https://www.myget.org/F/magic/" "Magic.Chocolatey.install"'
    assert get_new_command('cinst ruby -version 2.3.3') == 'cinst ruby -version 2.3.3.install'

# Generated at 2022-06-12 11:00:32.477125
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         "Installing the following packages:\n"
                         "chocolatey on the remote machine\n"
                         "The package was installed\n"
                         "chocolatey v0.10.11"))



# Generated at 2022-06-12 11:00:43.172437
# Unit test for function match
def test_match():
    from thefuck.types import Command

    # Test command that matches.
    assert match(Command('cinst chocolatey',
        output='Installing the following packages:\r\nchocolatey v0.9.9.11\r\nThe package was successfully installed.\r\n'))
    assert match(Command('choco install chocolatey',
        output='Chocolatey v0.9.9.11\r\nInstalling the following packages:\r\nchocolatey\r\n By installing you accept licenses for the packages.'))

    # Test command that does not match.
    assert not match(Command('choco install cornedbeef',
        output='Chocolatey v0.9.9.11\r\nInstalling the following packages:\r\nchocolatey\r\n By installing you accept licenses for the packages.'))




# Generated at 2022-06-12 11:01:04.140357
# Unit test for function match
def test_match():
    for script in ["choco install git"]:
        command = Command(script, "Installing the following packages:")
        assert match(command)

    for script in ["cinst git"]:
        command = Command(script, "Installing the following packages:")
        assert match(command)

    for script in ["choco install -y git"]:
        command = Command(script, "Installing the following packages:")
        assert match(command)

# Generated at 2022-06-12 11:01:11.555429
# Unit test for function get_new_command
def test_get_new_command():
    assert (
        get_new_command(Command("choco install git", "choco install git"))
        == "choco install git.install"
    )

    assert (
        get_new_command(Command("cinst git", "cinst git"))
        == "cinst git.install"
    )

    assert (
        get_new_command(Command("choco install git -y", "choco install git -y"))
        == "choco install git.install -y"
    )

    assert (
        get_new_command(Command("cinst git -y", "cinst git -y"))
        == "cinst git.install -y"
    )


# Generated at 2022-06-12 11:01:14.346888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install puts')) == 'choco install puts.install'
    assert get_new_command(Command('cinst puts')) == 'cinst puts.install'

# Generated at 2022-06-12 11:01:18.773585
# Unit test for function match
def test_match():
    assert match(Command('choco install package'))
    assert match(Command('cinst package'))
    assert not match(Command('choco install package -y'))
    assert not match(Command('cinst package -y'))
    assert not match(Command('choco install chocolatey'))
    assert not match(Command('cinst chocolatey'))



# Generated at 2022-06-12 11:01:20.291503
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install pkg', "Installing the following packages:\npkg")) == 'choco install pkg.install'

# Generated at 2022-06-12 11:01:28.120476
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('choco install foo bar', '')) == 'choco install foo.install bar'
    assert get_new_command(Command('cinst foo bar', '')) == 'cinst foo.install'
    assert get_new_command(Command('cinst -y git', '')) == 'cinst -y git.install'
    assert get_new_command(Command('cinst git', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install -y git', '')) == 'choco install -y git.install'
    assert get_new_command(Command('cinst git -y', '')) == 'cinst git -y'

# Generated at 2022-06-12 11:01:37.140472
# Unit test for function get_new_command
def test_get_new_command():
    # Test where we are installing a single package
    single_package = Command("sudo choco install git", "")
    assert get_new_command(single_package) == "sudo choco install git.install"
    # Test where we are installing multiple packages
    multi_package = Command("sudo choco install git cmake", "")
    assert get_new_command(multi_package) == "sudo choco install git.install cmake"
    # Test where we are installing multiple packages with a version
    multi_package_version = Command(
        "sudo choco install git cmake -version 2020.01.1 -y", ""
    )
    assert get_new_command(multi_package_version) == (
        "sudo choco install git.install cmake -version 2020.01.1 -y"
    )
    # Test where we are installing

# Generated at 2022-06-12 11:01:46.845286
# Unit test for function match
def test_match():
    assert match(Command('choco install'))
    assert match(Command('cinst asdf'))
    assert match(Command('choco install asdf'))
    assert not match(Command('choco update asdf'))
    assert match(Command('choco install -y asdf'))
    assert not match(Command('choco install -ya asdf'))
    assert not match(Command('choco install -x64 asdf'))
    assert not match(Command('choco install -source asdf'))
    assert not match(Command('choco install -version asdf'))
    assert match(Command('choco install -y -version asdf'))
    assert match(Command('choco install -source -version asdf asdf'))
    assert match(Command('choco install -source -version=2 asdf asdf'))


# Generated at 2022-06-12 11:01:54.780768
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('choco install googlechrome') == 'choco install googlechrome.install'
    assert get_new_command('cinst googlechrome') == 'cinst googlechrome.install'
    assert get_new_command('choco install googlechrome -f') == 'choco install googlechrome.install -f'
    assert get_new_command('choco install googlechrome -source http://chocolatey.org/api/v2') == 'choco install googlechrome.install -source'
    assert get_new_command('choco install -source http://chocolatey.org/api/v2 googlechrome') == 'choco install -source http://chocolatey.org/api/v2 googlechrome.install'

# Generated at 2022-06-12 11:01:56.607416
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey'))
    assert not match(Command('choco upgrade'))
    assert not match(Command('kyu install choco'))

# Generated at 2022-06-12 11:02:34.568149
# Unit test for function match
def test_match():
    """
    It should return true if:
        - command starts with 'choco install'
        - command contains 'cinst'
        - output contains 'Installing the following packages'
    It should return false if:
        - command does not start with 'choco install'
        - command does not contain 'cinst'
        - output does not contain 'Installing the following packages'
    """

    from thefuck.rules.choco_install_with_dot_install import match

    command = Command('choco install something',
                     'Installing the following packages:\nsomething\nSuccess')
    assert match(command) is True

    command = Command('cinst something',
                     'Installing the following packages:\nsomething\nSuccess')
    assert match(command) is True


# Generated at 2022-06-12 11:02:36.323461
# Unit test for function match
def test_match():
    assert match(Command("choco install -y packagename", "", "packagename")).output == "packagename"



# Generated at 2022-06-12 11:02:38.111761
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('choco install slack', ''))
    assert new_command == 'choco install slack.install'

# Generated at 2022-06-12 11:02:47.411453
# Unit test for function match
def test_match():
    assert match(Command(script="choco install foo",
                         output="Installing the following packages:\r\nfoo"))
    assert match(Command(script=r"cinst 'foo bar'",
                         output="Installing the following packages:\r\nfoo bar"))
    assert match(Command(script=r"cinst 'foo bar'",
                         output="Installing the following packages:\r\nfoo"))
    assert not match(Command(script="choco uninstall foo",
                             output="Uninstalling the following packages:\r\nfoo"))
    assert not match(Command(script=r"cinst 'foo bar'",
                             output="Uninstalling the following packages:\r\nfoo"))
    assert not match(Command(script="choco install foo",
                             output="Installing the following packages:\r\nbar"))
    # Test for

# Generated at 2022-06-12 11:02:53.711858
# Unit test for function match
def test_match():
    assert match(Command('choco install gg51'))
    assert match(Command('cinst gg51'))
    assert match(Command('sudo choco install gg51'))
    assert match(Command('sudo cinst gg51'))
    assert not match(Command('choco uninstall gg51'))


# Generated at 2022-06-12 11:02:58.628159
# Unit test for function match
def test_match():
    assert match(Command("choco install test"))
    assert match(Command("cinst test"))
    assert not match(Command("choco install test", "Installed test (1.0.0) to C:\\test"))
    assert not match(Command("cinst test", "Installed test (1.0.0) to C:\\test"))



# Generated at 2022-06-12 11:03:01.773331
# Unit test for function match
def test_match():
    assert match(Command("choco install pkg1 pkg2 pkg3",
                         "Installing the following packages:\r\n  pkg1\r\n pkg2\r\n pkg3"))



# Generated at 2022-06-12 11:03:04.194953
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('choco install git') == 'choco install git.install'
    assert get_new_command('cinst git') == 'cinst git.install'

# Generated at 2022-06-12 11:03:06.480056
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command("install", "cinst.exe text")
    assert "cinst text.install" == get_new_command(cmd)[0]

# Generated at 2022-06-12 11:03:14.648831
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install test')
    assert get_new_command(command) == 'choco install test.install'
    command = Command('cinst test')
    assert get_new_command(command) == 'cinst test.install'
    command = Command('choco install test -o')
    assert get_new_command(command) == 'choco install test.install -o'
    command = Command('choco install test -o -o')
    assert get_new_command(command) == 'choco install test.install -o -o'
    command = Command('choco install test -o -o -o -o')
    assert get_new_command(command) == 'choco install test.install -o -o -o -o'
    command = Command('choco install test -o --force')
    assert get

# Generated at 2022-06-12 11:04:21.647631
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("""choco install git""", """Chocolatey v0.10.11
Installing the following packages:
git""")

    assert get_new_command(command) == """choco install git.install"""

# Generated at 2022-06-12 11:04:23.964536
# Unit test for function match
def test_match():
    assert match(Command('choco install appium'))
    assert match(Command('choco install appium.install'))
    assert match(Command('cinst appium'))



# Generated at 2022-06-12 11:04:27.377751
# Unit test for function match
def test_match():
    assert match(Command('choco install foo',
                         'Installing the following packages:'))
    assert match(Command('cinst foo',
                         'Installing the following packages:'))
    assert not match(Command('choco install foo', ''))
    assert not match(Command('choco install foo', stderr='Installing the following packages:'))


# Generated at 2022-06-12 11:04:35.139868
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command("cinst -y powerline-shell")
    command2 = Command("choco install python -y")
    command3 = Command("choco install powerline-shell -y")
    command4 = Command("cinst powerline-shell -y")

    assert (
        get_new_command(command1)
        == "cinst -y powerline-shell.install"
    )  # Get the right command
    assert get_new_command(command2) == "choco install python.install -y"
    assert get_new_command(command3) == "choco install powerline-shell.install -y"
    assert get_new_command(command4) == "cinst powerline-shell.install -y"

    command5 = Command("cinst -y python pip")

# Generated at 2022-06-12 11:04:42.867172
# Unit test for function match
def test_match():
    assert match(Command('choco install cmder', '', 'Installing the following packages:\ncmder'))
    assert not match(Command('choco install cmder', '', 'cmder is already installed.'))
    assert match(Command('cinst cmder', '', 'Installing the following packages:'))
    assert not match(Command('cinst cmder', '', 'cmder is already installed.'))
    assert not match(Command('choco install cmder', '', 'Installing the following packages:\ncmder'))
    assert match(Command('cinst cmder', '', 'Installing the following packages:\ncmder'))


# Generated at 2022-06-12 11:04:44.796092
# Unit test for function get_new_command
def test_get_new_command():
    assert (
        get_new_command(Command("choco install chocolatey", "", "", 0)) == "chocolatey.install"
    )

# Generated at 2022-06-12 11:04:53.977673
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('choco install python'))) == 'choco install python.install'
    assert (get_new_command(Command('cinst python'))) == 'cinst python.install'
    assert (get_new_command(Command('cinst python.install'))) == []
    assert (get_new_command(Command('choco install python -y'))) == 'choco install python.install -y'
    assert (get_new_command(Command('choco install python -params'))) == 'choco install python.install -params'
    assert (get_new_command(Command('choco install opencv -params="-pre"'))) == 'choco install opencv.install -params="-pre"'

# Generated at 2022-06-12 11:04:57.957692
# Unit test for function match
def test_match():
    output = "Installing the following packages:\n\nchocolatey-core.extension 1.3.3 [Approved]\n"
    returned = match(Command(script='choco install chocolatey-core.extension -y', output=output))
    assert returned


# Generated at 2022-06-12 11:05:06.560668
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install package", "", "")) == "choco install package.install"
    assert get_new_command(Command("cinst package", "", "")) == "cinst package.install"
    assert get_new_command(
        Command("choco install package -y -source https://.....", "", "")) == "choco install package.install -y -source https://....."
    assert get_new_command(Command("choco install -y package", "", "")) == "choco install -y package.install"
    assert get_new_command(Command("cinst -y package", "", "")) == "cinst -y package.install"

# Generated at 2022-06-12 11:05:14.457239
# Unit test for function match
def test_match():
    from thefuck.rules import match
    from thefuck.types import Command

    assert match(Command('choco install firefox',
            'Chocolatey v0.10.8',
            'Installing the following packages:',
            '',
            'firefox',
            'By installing you accept licenses for the packages.',
            'Progress: Downloading Firefox 38.0.1... 100%'))
    assert not match(Command('choco install firefox',
            'The following packages were not installed:',
            'firefox : A package with this name already exists: Firefox',
            ''))

