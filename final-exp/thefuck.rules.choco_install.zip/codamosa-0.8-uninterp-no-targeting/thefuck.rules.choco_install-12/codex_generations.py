

# Generated at 2022-06-22 01:12:26.401977
# Unit test for function get_new_command
def test_get_new_command():

    command = Command('cinst -y chocolatey', 'Installing the following packages:\n', 'chocolatey (0.10.8)')
    new_command = get_new_command(command)
    assert new_command == 'cinst -y chocolatey.install'

# Generated at 2022-06-22 01:12:29.519221
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install git")) == 'choco install git.install'
    assert get_new_command(Command("cinst git")) == 'cinst git.install'
    assert "git" not in get_new_command(Command("cinst --force git"))

# Generated at 2022-06-22 01:12:37.040825
# Unit test for function match
def test_match():
    # Check that the function correctly identifies a command that exists in chocolatey
    assert bool(match(Command("choco install git"))) == True
    # Check that the function doesn't identify a non-existing command
    assert bool(match(Command("choco lorem ipsum"))) == False
    # Check that the function doesn't identify a command in another app
    assert bool(match(Command("sudo apt install -y git"))) == False



# Generated at 2022-06-22 01:12:40.641066
# Unit test for function match
def test_match():
    assert match(Command('choco install thing',
                  output='Installing the following packages:\r\nthing - To install:\r\n...'))
    assert match(Command('cinst thing',
                  output='Installing the following packages:\r\nthing - To install:\r\n...'))


# Generated at 2022-06-22 01:12:45.789271
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('cinst chocolatey', "Installing the following packages:\r\nchocolatey")
    assert get_new_command(command) == 'cinst chocolatey.install'

    command = Command('choco install python -y', "Installing the following packages:\r\npython")
    assert get_new_command(command) == 'choco install python.install -y'

# Generated at 2022-06-22 01:12:57.857317
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('choco install somesoftware',
                                     stderr='Installing the following packages:')) == 'choco install somesoftware.install'
    assert get_new_command(Command('cinst somesoftware',
                                     stderr='Installing the following packages:')) == 'cinst somesoftware.install'
    assert get_new_command(Command('choco install somesoftware -s',
                                     stderr='Installing the following packages:')) == 'choco install somesoftware.install -s'
    assert get_new_command(Command('cinst somesoftware -s',
                                     stderr='Installing the following packages:')) == 'cinst somesoftware.install -s'
    assert get_new_

# Generated at 2022-06-22 01:13:06.083025
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco install git").endswith("git.install")
    assert get_new_command("cinst googlechrome").endswith("googlechrome.install")
    assert get_new_command("choco install -y googlechrome").endswith("googlechrome.install")
    assert get_new_command("cinst -y googlechrome").endswith("googlechrome.install")
    assert get_new_command(
        "choco install -source chocolatey googlechrome"
    ).endswith("googlechrome.install")


# Generated at 2022-06-22 01:13:16.266462
# Unit test for function get_new_command
def test_get_new_command():
    from textwrap import dedent
    from thefuck.rules.chocolatey_install import get_new_command


# Generated at 2022-06-22 01:13:19.200398
# Unit test for function match
def test_match():
    command = Command(script="choco install monkey")
    assert match(command)
    command = Command(script="cinst monkeys")
    assert match(command)


# Generated at 2022-06-22 01:13:31.577692
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cinst notepad++")) == "cinst notepad++.install"
    assert get_new_command(Command("cinst notepad++ -version 1.2.3")) == "cinst notepad++.install -version 1.2.3"
    assert get_new_command(Command("choco install notepad++")) == "choco install notepad++.install"
    assert get_new_command(Command("choco install notepad++ -version 1.2.3")) == "choco install notepad++.install -version 1.2.3"
    assert get_new_command(Command("choco install -y notepad++")) == "choco install -y notepad++.install"
    assert get_new_command(Command("choco install -y notepad++ -version 1.2.3"))

# Generated at 2022-06-22 01:13:45.572666
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install candy.bar')
    assert get_new_command(command) == 'choco install candy.bar.install'
    command = Command('cinst candy.bar')
    assert get_new_command(command) == 'cinst candy.bar.install'
    command = Command('choco install candy.bar.install')
    assert get_new_command(command) == []
    command = Command('choco install candy.bar --ignored')
    assert get_new_command(command) == 'choco install candy.bar.install --ignored'
    command = Command('choco install candy.bar=1.2.3.4')
    assert get_new_command(command) == 'choco install candy.bar=1.2.3.4'

# Generated at 2022-06-22 01:13:48.240615
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install notepadplusplus", "")
    assert get_new_command(command) == "choco install notepadplusplus.install"

# Generated at 2022-06-22 01:13:53.387821
# Unit test for function match
def test_match():
    # Test true case
    command = types.Command('choco install chocolatey', "Installing the following packages:\nchocolatey")
    assert match(command)

    # Test false case
    command = types.Command("choco list", "Installing the following packages:\n\nchocolatey")
    assert not match(command)

# Generated at 2022-06-22 01:13:57.964337
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install ruby -y', '')
    assert get_new_command(command) == 'choco install ruby.install -y'
    command = Command('cinst ruby', '')
    assert get_new_command(command) == 'cinst ruby.install'

# Generated at 2022-06-22 01:14:01.394690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco install git") == "choco install git.install"
    assert get_new_command("cinst git") == "cinst git.install"

# Generated at 2022-06-22 01:14:03.260557
# Unit test for function get_new_command
def test_get_new_command():
    import unittest
    from tests.utils import Command


# Generated at 2022-06-22 01:14:05.040999
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cinst firewall')) == 'cinst firewall.install'

# Generated at 2022-06-22 01:14:17.024027
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command('choco install chrome', 'some bleh blah blah blah Installing the following packages: '
                                                'chrome some more bleh blah blah blah')
    new_command_1 = get_new_command(command_1)
    assert new_command_1 == 'choco install chrome.install'

    command_2 = Command('cinst chrome -y', 'some bleh blah blah blah Installing the following packages: '
                                           'chrome some more bleh blah blah blah')
    new_command_2 = get_new_command(command_2)
    assert new_command_2 == 'cinst chrome.install -y'

    command_3 = Command('cinst chrome', 'some bleh blah blah blah Installing the following packages: '
                                        'chrome some more bleh blah blah blah')
    new_command_3

# Generated at 2022-06-22 01:14:18.698819
# Unit test for function get_new_command

# Generated at 2022-06-22 01:14:21.389655
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install notepadplusplus", "")) == "choco install notepadplusplus.install"

# Generated at 2022-06-22 01:14:32.762373
# Unit test for function match
def test_match():
    assert match(Command('choco install package', None))
    assert not match(Command('choco install', None))
    assert match(Command('cinst package', None))
    assert not match(Command('cinst', None))


# Generated at 2022-06-22 01:14:41.842198
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('cinst foo', '', '')) == \
        'cinst foo.install'
    assert get_new_command(Command('choco install foo', '', '')) == \
        'choco install foo.install'
    assert get_new_command(Command('cinst foo bar', '', '')) == \
        'cinst foo.install bar'
    assert get_new_command(Command('choco install foo -bar', '', '')) == \
        'choco install foo.install -bar'

# Generated at 2022-06-22 01:14:49.736237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install package')) == 'choco install package.install'
    assert get_new_command(Command('cinst package')) == 'cinst package.install'
    assert get_new_command(Command('choco install package --foo')) == 'choco install package.install --foo'
    assert get_new_command(Command('cinst package --foo')) == 'cinst package.install --foo'
    assert get_new_command(Command('choco install package -fd')) == 'choco install package.install -fd'
    assert get_new_command(Command('cinst package -fd')) == 'cinst package.install -fd'
    assert get_new_command(Command('choco install package -source="foo"')) == 'choco install package.install -source="foo"'

# Generated at 2022-06-22 01:14:52.014340
# Unit test for function match
def test_match():
    script = 'choco install test'
    command = Command(script, 'Installing the following packages: test')
    output = match(command)
    assert bool(output)



# Generated at 2022-06-22 01:15:01.927632
# Unit test for function match
def test_match():
    assert match(Command("choco install git.ed",
        "Chocolatey v0.10.1\nInstalling the following packages:\n"
        "git.ed\nBy installing you accept "
        "licenses for the packages.",
        ""))
    assert match(Command("cinst git.ed",
        "Chocolatey v0.10.1\nInstalling the following packages:\n"
        "git.ed\nBy installing you accept "
        "licenses for the packages.",
        ""))
    assert not match(Command("choco install git.ed",
        "Chocolatey v0.10.1\nInstalling the following packages:\n"
        "git.ed\n",
        ""))



# Generated at 2022-06-22 01:15:06.156792
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install System.Net.Http -y')) == 'choco install System.Net.Http.install -y'
    assert get_new_command(Command('cinst System.Net.Http -y')) == 'cinst System.Net.Http.install -y'

# Generated at 2022-06-22 01:15:08.643878
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('choco install git', '', '', '', ''))
    assert new_command == 'choco install git.install'

# Generated at 2022-06-22 01:15:12.229765
# Unit test for function match
def test_match():

    # Ignoring choco install
    assert match(Command('choco install something'))
    assert not match(Command('choco install'))

    # Ignoring cinst
    assert match(Command('cinst something'))



# Generated at 2022-06-22 01:15:16.034024
# Unit test for function match
def test_match():
    assert match(Command('choco install atom', '', 0))
    assert match(Command('cinst atom', '', 0))
    assert not match(Command('choco upgrade atom', '', 0))



# Generated at 2022-06-22 01:15:18.629785
# Unit test for function match
def test_match():
    assert match(Command('choco install foo'))
    assert match(Command('cinst foo'))
    assert not match(Command('choco install'))
    

# Generated at 2022-06-22 01:15:34.967713
# Unit test for function match
def test_match():
    assert match(Command('choco install nodejs'))


# Generated at 2022-06-22 01:15:36.863040
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cinst python")) == "cinst python.install"
    asse

# Generated at 2022-06-22 01:15:48.679071
# Unit test for function match
def test_match():
    import mock

# Generated at 2022-06-22 01:15:53.573141
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install firefox', '', 'Installing the following packages:\r\n  firefox')) == 'choco install firefox.install'
    assert get_new_command(Command('cinst firefox', '', 'Installing the following packages:\r\n  firefox')) == 'cinst firefox.install'

# Generated at 2022-06-22 01:15:57.593465
# Unit test for function match
def test_match():
    assert match(Command('choco install f.install', '', 'Installing the following packages:\nf.install'))
    assert match(Command('choco install f.install', '', 'Installing the following packages:\n.\nf.install'))
    assert match(Command('cinst f.install', '', 'Installing the following packages:\nf.install'))
    assert match(Command('cinst f.install', '', 'Installing the following packages:\n.\nf.install'))
    assert not match(Command('choco install f.install', '', 'Experimental Installing the following packages:\nf.install'))
    assert not match(Command('choco install f.install', '', 'Installing the following packages:\n.\n.\nf.install'))

# Generated at 2022-06-22 01:16:04.502950
# Unit test for function match
def test_match():
    assert match(Command(script="choco install chocolatey",
                         output="Installing the following packages:"))
    assert match(Command(script="cinst chocolatey",
                         output="Installing the following packages:"))
    assert match(Command(script="choco install chocolatey -y",
                         output="Installing the following packages:"))
    assert match(Command(script="choco install",
                         output="Installing the following packages:"))
    assert match(Command(script="cinst",
                         output="Installing the following packages:"))
    assert not match(Command(script="choco install chocolatey -y",
                         output="Installing the following packages:",
                         stderr="Chocolatey v0.10.15"))

# Generated at 2022-06-22 01:16:08.491612
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("cinst asdf")
    assert get_new_command(command) == "cinst asdf.install"

    command = Command("cinst asdf --bin")
    assert get_new_command(command) == "cinst asdf.install --bin"

    command = Command("cinst asdf. --bin")
    assert get_new_command(command) == "cinst asdf.install --bin"

    command = Command("cinst asdf asdf. --bin")
    assert get_new_command(command) == "cinst asdf asdf.install --bin"

# Generated at 2022-06-22 01:16:18.722579
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('choco install chocolatey', 'Installing the following packages')) ==
            'choco install chocolatey.install')
    assert (get_new_command(Command('choco install choco', 'Installing the following packages')) ==
            'choco install choco.install')
    assert (get_new_command(Command('choco install choco -y', 'Installing the following packages')) ==
            'choco install choco.install -y')
    assert (get_new_command(Command('choco install -y choco', 'Installing the following packages')) ==
            'choco install -y choco.install')

# Generated at 2022-06-22 01:16:25.689804
# Unit test for function match
def test_match():
    command = Command('cinst foo -y', 'Installing the following packages:')
    assert match(command)

    command = Command('choco install foo -y', 'Installing the following packages:')
    assert match(command)

    command = Command('cinst http://foo.com -y', 'Installing the following packages:')
    assert match(command)

    command = Command('cinst foo', 'foo not found')
    assert not match(command)

# Generated at 2022-06-22 01:16:36.718734
# Unit test for function match
def test_match():
    output = u'''
Installing the following packages:
package1
package2
By installing you accept licenses for the packages.
'''
    assert match(Command('choco install package1 package2', output=output))
    assert not match(Command('choco install package1 package2', output=''))
    assert not match(Command('choco install package1 package2', output=u'''
Installing the following packages:
package1
package2
By installing you accept licenses for the packages.
'''))
    assert not match(Command('choco install package1 package2', output=u'''
Installing the following packages:
package1
package2
By installing you accept licenses for the packages.
Installing package1...
'''))


# Generated at 2022-06-22 01:17:15.190539
# Unit test for function match
def test_match():
    # Windows test
    if which("choco") or which("cinst"):
        command = Command('choco install test', stderr='Installing the following packages:',
                          script='choco install test')
        assert match(command)

    # Linux test
    if not which("choco") and not which("cinst"):
        command = Command('sudo gem install test',
                          stderr="ERROR: Could not find a valid gem 'test' (>= 0), here is why:",
                          script='sudo gem install test')
        assert not match(command)



# Generated at 2022-06-22 01:17:23.149610
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco install 7zip") == "choco install 7zip.install"
    assert get_new_command("choco install virtualbox --version 5.1.12") == "choco install virtualbox.install --version 5.1.12"
    assert get_new_command("cinst 7zip") == "cinst 7zip.install"
    assert get_new_command("cinst virtualbox --version 5.1.12") == "cinst virtualbox.install --version 5.1.12"



# Generated at 2022-06-22 01:17:28.851985
# Unit test for function match
def test_match():
    assert match(Command("choco install test", "", "Installing the following packages\n  Test"))
    assert match(Command("cinst test", "", "Installing the following packages\n  Test"))
    assert not match(Command("test install test", "", "Installing the following packages\n  Test"))
    assert not match(Command("cinst", "", ""))


# Generated at 2022-06-22 01:17:33.474242
# Unit test for function match
def test_match():
    assert match(Command("choco install cinst", "Installing the following packages:"))
    assert match(Command("cinst cinst.install -y", ""))
    assert not match(Command("choco install cinst -y", "Installing the following packages:"))



# Generated at 2022-06-22 01:17:40.101894
# Unit test for function match
def test_match():
    assert match(Command('choco install chrome',
        output = 'Installing the following packages:\ngooglechrome\n'))
    assert match(Command('cinst chrome',
        output = 'Installing the following packages:\ngooglechrome\n'))
    assert not match(Command('choco install googlechrome',
        output = 'Installing the following packages:\ngooglechrome\n'))
    assert not match(Command('choco install googlechrome',
        output = 'Installing the following packages:\nchrome\n'))
    assert not match(Command('cinst googlechrome',
        output = 'Installing the following packages:\nchrome\n'))


# Generated at 2022-06-22 01:17:49.301248
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install python", "")
    assert get_new_command(command) == "choco install python.install"
    command2 = Command("cinst python", "")
    assert get_new_command(command2) == "cinst python.install"
    command3 = Command("cinst -y python", "")
    assert get_new_command(command3) == "cinst -y python.install"
    command4 = Command("cinst python -y", "")
    assert get_new_command(command4) == "cinst python.install -y"
    command5 = Command("cinst one two", "")
    assert get_new_command(command5) == "cinst one.install two"

# Generated at 2022-06-22 01:17:56.233483
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("cinst git")) == "cinst git.install"
    assert get_new_command(Command("cinst git -y")) == "cinst git.install -y"
    assert get_new_command(Command("cinst git.install")) == "cinst git.install.install"
    assert get_new_command(Command("cinst git -params")) == "cinst git -params"

# Generated at 2022-06-22 01:18:02.448210
# Unit test for function get_new_command
def test_get_new_command():
    command_from_choco = Command('choco install some-package', '', '')
    command_from_cinst = Command('cinst some-package', '', '')
    assert get_new_command(command_from_choco) == "choco install some-package.install"
    assert get_new_command(command_from_cinst) == "cinst some-package.install"

# Generated at 2022-06-22 01:18:10.530491
# Unit test for function match
def test_match():
    assert (
        match(Command("choco install chocolatey", "chocolatey is already installed"))
    )
    assert (
        match(Command("cinst chocolatey", "chocolatey is already installed"))
    )
    assert (
            match(Command("cinst chocolatey", "chocolatey 0.10.15 already installed"))
    )
    assert (
        match(Command("cinst chocolatey", "chocolatey is already installed"))
    )
    assert not match(Command("choco install chocolatey", ""))
    assert not match(Command("cinst chocolatey", ""))



# Generated at 2022-06-22 01:18:12.507419
# Unit test for function match
def test_match():
    assert match(Command("choco install git -y"))
    assert not match(Command("choco install git -y --force"))

# Generated at 2022-06-22 01:19:18.891198
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cinst f.lux')) == 'cinst f.lux.install'
    assert get_new_command(Command('choco install f.lux')) == 'choco install f.lux.install'
    # Empty string since command is invalid
    assert get_new_command(Command('cinst -y f.lux')) == ''
    assert get_new_command(Command('cinst chocolatey')) == 'cinst chocolatey.install'
    assert get_new_command(Command('cinst -source=somesource chocolatey')) == 'cinst -source=somesource chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey')) == 'choco install -y chocolatey.install'

# Generated at 2022-06-22 01:19:21.128810
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='cinst vlc',
                      output='Installing the following packages',
                      stderr='',
                      env={})
    assert get_new_command(command) == 'cinst vlc.install'

# Generated at 2022-06-22 01:19:29.182087
# Unit test for function match
def test_match():
    """ Test if match() works as intended. """
    from thefuck.rules.choco import match
    from thefuck.types import Command
    script = "choco install git"
    output = "Chocolatey v0.10.11\nInstalling the following packages:\n\n" \
             "git.install already installed. Skipping..."
    assert match(Command(script, output, "/usr/bin/bash")) is True
    assert match(Command(script, "", "/usr/bin/bash")) is False



# Generated at 2022-06-22 01:19:35.224359
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install nodejs', '/bin',
                                   'Installing the following packages: nodejs\n')) == 'choco install nodejs.install'
    assert get_new_command(Command('choco install -version 2 -y nodejs', '/bin',
                                   'Installing the following packages: nodejs\n')) == 'choco install -version 2 -y nodejs.install'
    assert get_new_command(Command('choco install', '/bin',
                                   'Installing the following packages: nodejs\n')) == 'choco install nodejs.install'

# Generated at 2022-06-22 01:19:47.068795
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('cinst pkg', '', '')) == 'cinst pkg.install'
    assert get_new_command(Command('cinst pkg -y', '', '')) == 'cinst pkg.install -y'
    assert get_new_command(Command('cinst pkg --yes', '', '')) == 'cinst pkg.install --yes'
    assert get_new_command(Command('cinst -y pkg', '', '')) == 'cinst -y pkg.install'
    assert get_new_command(Command('cinst --yes pkg', '', '')) == 'cinst --yes pkg.install'

# Generated at 2022-06-22 01:19:52.338912
# Unit test for function match
def test_match():
    assert(match(Command('choco install python', '')) is True)
    assert(match(Command('cinst python', '')) is True)
    assert(match(Command('choco install python', 'Installing the following packages:')) is True)
    assert(match(Command('choco install python', 'Installing package python')) is False)



# Generated at 2022-06-22 01:19:57.079376
# Unit test for function match
def test_match():
    assert match(Command(script="choco install microsoft-build-tools",
                         output="Installing the following packages:"))
    assert match(Command(script="cinst vscode",
                         output="Installing the following packages:"))



# Generated at 2022-06-22 01:20:05.145518
# Unit test for function match
def test_match():
    command = Command('choco install notepadplusplus',
        'NotepadPlusPlus.install v6.5.6 [Approved]\nThe following packages will be installed:\n'
        'notepadplusplus notepadPlusPlus.install 6.5.6 [Approved]\n'
        'Total download size: 5.3 MB\nContinue? (Y/N): ')
    assert match(command)
    command = Command('cinst notepadplusplus',
        'NotepadPlusPlus.install v6.5.6 [Approved]\nThe following packages will be installed:\n'
        'notepadplusplus notepadPlusPlus.install 6.5.6 [Approved]\n'
        'Total download size: 5.3 MB\nContinue? (Y/N): ')
    assert match(command)


# Generated at 2022-06-22 01:20:07.683573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('cinst googlechrome', '', '', '', '')) == 'cinst googlechrome.install'
    assert get_new_command(Command('cinst googlechrome.install', '', '', '', '')) == 'cinst googlechrome.install.install'
    assert get_new_command(Command('choco install googlechrome --params="--foo=bar"', '', '', '', '')) == 'choco install googlechrome.install --params="--foo=bar"'

# Generated at 2022-06-22 01:20:13.650441
# Unit test for function match
def test_match():
    # Should match
    assert match(Command('choco install package', '', ''))
    assert match(Command('cinst package', '', ''))

    # Should not match
    assert not match(Command('choco install', '', ''))
    assert not match(Command('cinst', '', ''))
    assert not match(Command('choco package', '', ''))



# Generated at 2022-06-22 01:22:17.912133
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', 'chocolatey v0.9.9.11', None))
    assert match(Command('cinst chocolatey', 'chocolatey v0.9.9.11', None))



# Generated at 2022-06-22 01:22:25.726766
# Unit test for function get_new_command
def test_get_new_command():
    """
    test_get_new_command verifies that the output of get_new_command is the expected output
    :return:
    """
    from thefuck.rules.chocolatey_install_misspelled import get_new_command, Command

    assert get_new_command(Command('choco install python3.1',
                                   'Chocolatey v0.10.13'
                                   'Installing the following packages:'
                                   '  python'
                                   'python not installed.'
                                   'The package was not found with the source(s) listed.',
                                   'choco', 'install', 'python3.1')) == 'choco install python3.1.install'