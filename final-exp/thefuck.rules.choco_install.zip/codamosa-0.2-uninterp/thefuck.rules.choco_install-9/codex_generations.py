

# Generated at 2022-06-18 07:28:57.762573
# Unit test for function match

# Generated at 2022-06-18 07:29:08.174823
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install -y git', '')) == 'choco install -y git.install'
    assert get_new_command(Command('cinst -y git', '')) == 'cinst -y git.install'
    assert get_new_command(Command('choco install -y git -source https://chocolatey.org/api/v2', '')) == 'choco install -y git.install -source https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:29:18.248898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install -y git', '')) == 'choco install -y git.install'
    assert get_new_command(Command('cinst -y git', '')) == 'cinst -y git.install'
    assert get_new_command(Command('choco install -y git.install', '')) == 'choco install -y git.install'
    assert get_new_command(Command('cinst -y git.install', '')) == 'cinst -y git.install'

# Generated at 2022-06-18 07:29:23.166142
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:29:34.068893
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'By installing you accept licenses for the packages.'))
    assert match(Command('cinst chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'By installing you accept licenses for the packages.'))
    assert not match(Command('choco install chocolatey',
                             'Installing the following packages:\n'
                             'chocolatey on the current system\n'
                             'By installing you accept licenses for the packages.\n'
                             'chocolatey v0.10.8\n'
                             'Installing chocolatey on the current system\n'
                             'The package was successfully installed.'))

# Generated at 2022-06-18 07:29:38.358661
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'By installing you accept licenses for the packages.'))
    assert match(Command('cinst chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'By installing you accept licenses for the packages.'))
    assert not match(Command('choco install chocolatey', ''))
    assert not match(Command('cinst chocolatey', ''))



# Generated at 2022-06-18 07:29:43.996525
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', ''))


# Generated at 2022-06-18 07:29:47.612070
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 1, None))
    assert match(Command('cinst chocolatey', '', '', 1, None))
    assert not match(Command('choco install chocolatey', '', '', 1, None))
    assert not match(Command('cinst chocolatey', '', '', 1, None))


# Generated at 2022-06-18 07:29:58.047830
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install python', '')) == 'choco install python.install'
    assert get_new_command(Command('cinst python', '')) == 'cinst python.install'
    assert get_new_command(Command('choco install python -y', '')) == 'choco install python.install -y'
    assert get_new_command(Command('cinst python -y', '')) == 'cinst python.install -y'
    assert get_new_command(Command('choco install python -y --version=3.6.0', '')) == 'choco install python.install -y --version=3.6.0'

# Generated at 2022-06-18 07:30:01.762083
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', ''))


# Generated at 2022-06-18 07:30:14.959819
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))



# Generated at 2022-06-18 07:30:20.172986
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:30:25.213416
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:30:29.257809
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', ''))
    assert match(Command('cinst chocolatey', ''))
    assert not match(Command('choco install chocolatey', 'Installing the following packages'))
    assert not match(Command('cinst chocolatey', 'Installing the following packages'))


# Generated at 2022-06-18 07:30:34.502268
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', '', ''))



# Generated at 2022-06-18 07:30:45.660697
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey", "", "")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey", "", "")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey", "", "")) == "choco install -y chocolatey.install"
    assert get_new_command(Command("cinst -y chocolatey", "", "")) == "cinst -y chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey -source https://chocolatey.org/api/v2/", "", "")) == "choco install -y chocolatey.install -source https://chocolatey.org/api/v2/"
    assert get_new_command

# Generated at 2022-06-18 07:30:55.753936
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install chocolatey', '')
    assert get_new_command(command) == 'choco install chocolatey.install'

    command = Command('choco install chocolatey -y', '')
    assert get_new_command(command) == 'choco install chocolatey.install -y'

    command = Command('cinst chocolatey', '')
    assert get_new_command(command) == 'cinst chocolatey.install'

    command = Command('cinst chocolatey -y', '')
    assert get_new_command(command) == 'cinst chocolatey.install -y'

    command = Command('cinst chocolatey -y -source https://chocolatey.org/api/v2', '')

# Generated at 2022-06-18 07:31:05.832975
# Unit test for function match
def test_match():
    assert match(Command('choco install', '', 'Installing the following packages:\n'
                                            'chocolatey 0.10.8\n'
                                            'By installing you accept licenses for the packages.'))
    assert match(Command('cinst', '', 'Installing the following packages:\n'
                                       'chocolatey 0.10.8\n'
                                       'By installing you accept licenses for the packages.'))

# Generated at 2022-06-18 07:31:13.386424
# Unit test for function match
def test_match():
    assert match(Command('choco install foo', '', '', '', '', ''))
    assert match(Command('cinst foo', '', '', '', '', ''))
    assert not match(Command('choco uninstall foo', '', '', '', '', ''))
    assert not match(Command('cuninst foo', '', '', '', '', ''))
    assert not match(Command('choco install foo', '', '', '', '', ''))
    assert not match(Command('cinst foo', '', '', '', '', ''))


# Generated at 2022-06-18 07:31:23.750019
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install foo', '', '')) == 'choco install foo.install'
    assert get_new_command(Command('cinst foo', '', '')) == 'cinst foo.install'
    assert get_new_command(Command('choco install foo -y', '', '')) == 'choco install foo.install -y'
    assert get_new_command(Command('cinst foo -y', '', '')) == 'cinst foo.install -y'
    assert get_new_command(Command('choco install foo -y --force', '', '')) == 'choco install foo.install -y --force'
    assert get_new_command(Command('cinst foo -y --force', '', '')) == 'cinst foo.install -y --force'
    assert get_new_command

# Generated at 2022-06-18 07:31:45.563917
# Unit test for function match
def test_match():
    assert match(Command("choco install chocolatey", "", "Installing the following packages:"))
    assert match(Command("cinst chocolatey", "", "Installing the following packages:"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages: chocolatey"))
    assert not match(Command("cinst chocolatey", "", "Installing the following packages: chocolatey"))


# Generated at 2022-06-18 07:31:49.783519
# Unit test for function match
def test_match():
    assert match(Command("choco install", "", "Installing the following packages"))
    assert match(Command("cinst", "", "Installing the following packages"))
    assert not match(Command("choco install", "", "Installing the following packages:"))
    assert not match(Command("cinst", "", "Installing the following packages:"))


# Generated at 2022-06-18 07:31:57.321227
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey", "", "")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey", "", "")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey", "", "")) == "choco install -y chocolatey.install"
    assert get_new_command(Command("cinst -y chocolatey", "", "")) == "cinst -y chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey -s https://chocolatey.org/api/v2", "", "")) == "choco install -y chocolatey.install -s https://chocolatey.org/api/v2"

# Generated at 2022-06-18 07:32:02.138166
# Unit test for function match
def test_match():
    assert match(Command("choco install chocolatey", "", "Installing the following packages:\nchocolatey"))
    assert match(Command("cinst chocolatey", "", "Installing the following packages:\nchocolatey"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages:\nchocolatey\n"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages:\nchocolatey\n"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages:\nchocolatey\n"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages:\nchocolatey\n"))

# Generated at 2022-06-18 07:32:13.137021
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install chocolatey")
    assert get_new_command(command) == "choco install chocolatey.install"
    command = Command("cinst chocolatey")
    assert get_new_command(command) == "cinst chocolatey.install"
    command = Command("choco install chocolatey -y")
    assert get_new_command(command) == "choco install chocolatey.install -y"
    command = Command("cinst chocolatey -y")
    assert get_new_command(command) == "cinst chocolatey.install -y"
    command = Command("choco install chocolatey -y --params='/InstallDir:C:\\Chocolatey'")
    assert get_new_command(command) == "choco install chocolatey.install -y --params='/InstallDir:C:\\Chocolatey'"

# Generated at 2022-06-18 07:32:22.668083
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:',
                         'chocolatey v0.10.15'))
    assert match(Command('cinst chocolatey',
                         'Installing the following packages:',
                         'chocolatey v0.10.15'))
    assert not match(Command('choco install chocolatey',
                             'Installing the following packages:',
                             'chocolatey v0.10.15',
                             'The package was not found with the source(s) listed.'))
    assert not match(Command('choco install chocolatey',
                             'Installing the following packages:',
                             'chocolatey v0.10.15',
                             'Successfully installed \'chocolatey\'!'))

# Generated at 2022-06-18 07:32:33.167547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('cinst chocolatey -y --force', '')) == 'cinst chocolatey.install -y --force'
    assert get_new_command

# Generated at 2022-06-18 07:32:41.858036
# Unit test for function match
def test_match():
    assert match(Command('choco install git', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git', '', 'Installing the following packages:\ngit'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('cinst git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('cinst git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\ngit\n'))

# Generated at 2022-06-18 07:32:47.032554
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:32:57.104600
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -source https://chocolatey.org/api/v2/', '')) == 'choco install chocolatey.install -y -source https://chocolatey.org/api/v2/'

# Generated at 2022-06-18 07:33:37.533511
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', ''))


# Generated at 2022-06-18 07:33:42.271245
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:33:50.097415
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey.extension', '')) == 'choco install chocolatey.extension.install'
    assert get_new_command(Command('choco install chocolatey.extension -y', '')) == 'choco install chocolatey.extension.install -y'
    assert get_new_command(Command('cinst chocolatey.extension', '')) == 'cinst chocolatey.extension.install'
    assert get

# Generated at 2022-06-18 07:34:00.897208
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey -y', '', '', 0, None))
    assert match(Command('cinst chocolatey -y --force', '', '', 0, None))
    assert match(Command('cinst chocolatey -y --force --params="--params"', '', '', 0, None))
    assert match(Command('cinst chocolatey -y --force --params="--params" --source="source"', '', '', 0, None))
    assert match(Command('cinst chocolatey -y --force --params="--params" --source="source" --version="1.0.0"', '', '', 0, None))

# Generated at 2022-06-18 07:34:09.548740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey")) == "choco install -y chocolatey.install"
    assert get_new_command(Command("cinst -y chocolatey")) == "cinst -y chocolatey.install"
    assert get_new_command(Command("choco install -y chocolatey.extension")) == "choco install -y chocolatey.extension.install"
    assert get_new_command(Command("cinst -y chocolatey.extension")) == "cinst -y chocolatey.extension.install"

# Generated at 2022-06-18 07:34:14.304238
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert not match(Command('choco uninstall chocolatey', '', '', '', '', ''))
    assert not match(Command('cuninst chocolatey', '', '', '', '', ''))



# Generated at 2022-06-18 07:34:22.381443
# Unit test for function match
def test_match():
    assert match(Command('choco install git', '', 'Installing the following packages:\n'
                                                 'git v2.22.0.windows.1 [Approved]\n'
                                                 'git package files install completed. Performing other installation steps.'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\n'
                                                      'git v2.22.0.windows.1 [Approved]\n'
                                                      'git package files install completed. Performing other installation steps.\n'
                                                      'The install of git was successful.'))

# Generated at 2022-06-18 07:34:26.843506
# Unit test for function match
def test_match():
    assert match(Command("choco install chocolatey", "", "Installing the following packages:"))
    assert match(Command("cinst chocolatey", "", "Installing the following packages:"))
    assert not match(Command("choco install chocolatey", "", "Installing the following packages"))
    assert not match(Command("cinst chocolatey", "", "Installing the following packages"))


# Generated at 2022-06-18 07:34:35.795580
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -s "C:\\temp"', '')) == 'choco install chocolatey.install -y -s "C:\\temp"'

# Generated at 2022-06-18 07:34:41.695889
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system.'))
    assert match(Command('cinst chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system.'))
    assert not match(Command('choco install chocolatey',
                             'Installing the following packages:\n'
                             'chocolatey on the current system.'))
    assert not match(Command('cinst chocolatey',
                             'Installing the following packages:\n'
                             'chocolatey on the current system.'))


# Generated at 2022-06-18 07:36:20.407720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --params="--params"', '')) == 'choco install chocolatey.install -y --params="--params"'
    assert get_new_command(Command('choco install chocolatey -y --params="--params" --version=1.2.3', '')) == 'choco install chocolatey.install -y --params="--params" --version=1.2.3'
    assert get_new

# Generated at 2022-06-18 07:36:28.197529
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install git -y', '')) == 'choco install git.install -y'
    assert get_new_command(Command('cinst git -y', '')) == 'cinst git.install -y'
    assert get_new_command(Command('choco install git.install', '')) == 'choco install git.install.install'
    assert get_new_command(Command('cinst git.install', '')) == 'cinst git.install.install'

# Generated at 2022-06-18 07:36:36.532515
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --params="--version=0.10.8"', '')) == 'choco install chocolatey.install -y --params="--version=0.10.8"'

# Generated at 2022-06-18 07:36:45.100485
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', 'Installing the following packages:\nchocolatey 0.10.15'))
    assert match(Command('cinst chocolatey', '', 'Installing the following packages:\nchocolatey 0.10.15'))
    assert not match(Command('choco install chocolatey', '', 'Installing the following packages:\nchocolatey 0.10.15\nchocolatey.extension 1.3.3'))
    assert not match(Command('cinst chocolatey', '', 'Installing the following packages:\nchocolatey 0.10.15\nchocolatey.extension 1.3.3'))

# Generated at 2022-06-18 07:36:54.836269
# Unit test for function match
def test_match():
    assert match(Command('choco install foo', '', '', '', '', ''))
    assert match(Command('cinst foo', '', '', '', '', ''))
    assert match(Command('choco install foo -y', '', '', '', '', ''))
    assert match(Command('cinst foo -y', '', '', '', '', ''))
    assert match(Command('choco install foo -y --force', '', '', '', '', ''))
    assert match(Command('cinst foo -y --force', '', '', '', '', ''))
    assert match(Command('choco install foo -y --force --version=1.2.3', '', '', '', '', ''))

# Generated at 2022-06-18 07:37:02.810980
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('choco install chocolatey -y --force --version=1.2.3', '')) == 'choco install chocolatey.install -y --force --version=1.2.3'

# Generated at 2022-06-18 07:37:10.948338
# Unit test for function match
def test_match():
    assert match(Command('choco install notepadplusplus', '', 'Installing the following packages:\nnotepadplusplus'))
    assert match(Command('cinst notepadplusplus', '', 'Installing the following packages:\nnotepadplusplus'))
    assert not match(Command('choco install notepadplusplus', '', 'Installing the following packages:\nnotepadplusplus\nnotepadplusplus.install'))
    assert not match(Command('cinst notepadplusplus', '', 'Installing the following packages:\nnotepadplusplus\nnotepadplusplus.install'))
    assert not match(Command('choco install notepadplusplus', '', 'Installing the following packages:\nnotepadplusplus\nnotepadplusplus.install'))

# Generated at 2022-06-18 07:37:20.749296
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('choco install chocolatey', '', '', 0)
    assert get_new_command(command) == 'choco install chocolatey.install'
    command = Command('cinst chocolatey', '', '', 0)
    assert get_new_command(command) == 'cinst chocolatey.install'
    command = Command('choco install chocolatey -y', '', '', 0)
    assert get_new_command(command) == 'choco install chocolatey.install -y'
    command = Command('choco install chocolatey -y -source=https://chocolatey.org/api/v2', '', '', 0)
    assert get_new_command(command) == 'choco install chocolatey.install -y -source=https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:37:25.356036
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:37:34.993729
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('choco install git', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install git -y', '')) == 'choco install git.install -y'
    assert get_new_command(Command('cinst git -y', '')) == 'cinst git.install -y'
    assert get_new_command(Command('choco install git -y -source=https://chocolatey.org/api/v2', '')) == 'choco install git.install -y -source=https://chocolatey.org/api/v2'