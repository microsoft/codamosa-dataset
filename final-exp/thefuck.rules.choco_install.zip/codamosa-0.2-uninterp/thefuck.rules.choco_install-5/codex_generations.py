

# Generated at 2022-06-18 07:28:57.333296
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey", "")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey", "")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install chocolatey -y", "")) == "choco install chocolatey.install -y"
    assert get_new_command(Command("cinst chocolatey -y", "")) == "cinst chocolatey.install -y"
    assert get_new_command(Command("choco install chocolatey -y --force", "")) == "choco install chocolatey.install -y --force"
    assert get_new_command(Command("cinst chocolatey -y --force", "")) == "cinst chocolatey.install -y --force"
    assert get_new_command

# Generated at 2022-06-18 07:29:08.089625
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -source=https://chocolatey.org/api/v2', '')) == 'choco install chocolatey.install -y -source=https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:29:18.177341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('cinst chocolatey -y --force', '')) == 'cinst chocolatey.install -y --force'
    assert get_new_command

# Generated at 2022-06-18 07:29:26.585998
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey.extension', '')) == 'choco install -y chocolatey.extension.install'
    assert get_new_command(Command('cinst -y chocolatey.extension', '')) == 'cinst -y chocolatey.extension.install'
    assert get

# Generated at 2022-06-18 07:29:37.084480
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -s "C:\\Temp"', '')) == 'choco install chocolatey.install -y -s "C:\\Temp"'
    assert get_new_command(Command('choco install chocolatey -y -s "C:\\Temp" -version 1.2.3', '')) == 'choco install chocolatey.install -y -s "C:\\Temp" -version 1.2.3'

# Generated at 2022-06-18 07:29:47.249942
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('choco install chocolatey -y --force --version=1.2.3', '')) == 'choco install chocolatey.install -y --force --version=1.2.3'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'

# Generated at 2022-06-18 07:29:57.703274
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey.extension', '')) == 'choco install -y chocolatey.extension.install'
    assert get_new_command(Command('cinst -y chocolatey.extension', '')) == 'cinst -y chocolatey.extension.install'
    assert get

# Generated at 2022-06-18 07:30:03.790446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -source="https://chocolatey.org/api/v2/"', '')) == 'choco install chocolatey.install -y -source="https://chocolatey.org/api/v2/"'

# Generated at 2022-06-18 07:30:08.413502
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', '', ''))


# Generated at 2022-06-18 07:30:13.969747
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '', '')) == 'cinst git.install'
    assert get_new_command(Command('choco install -y git', '', '')) == 'choco install -y git.install'
    assert get_new_command(Command('cinst -y git', '', '')) == 'cinst -y git.install'
    assert get_new_command(Command('choco install -y git.install', '', '')) == 'choco install -y git.install.install'
    assert get_new_command(Command('cinst -y git.install', '', '')) == 'cinst -y git.install.install'
    assert get_new_command

# Generated at 2022-06-18 07:30:31.370331
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --params="--params"', '')) == 'choco install chocolatey.install -y --params="--params"'

# Generated at 2022-06-18 07:30:39.971328
# Unit test for function match
def test_match():
    assert match(Command('choco install git', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git', '', 'Installing the following packages:\ngit'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('cinst git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('choco install git', '', 'Installing the following packages:\ngit\n'))
    assert not match(Command('cinst git', '', 'Installing the following packages:\ngit\n'))


# Generated at 2022-06-18 07:30:50.538237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('cinst chocolatey -y --force', '')) == 'cinst chocolatey.install -y --force'
    assert get_new_command

# Generated at 2022-06-18 07:31:01.236937
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey -source https://chocolatey.org/api/v2', '')) == 'choco install -y chocolatey.install -source https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:31:11.553413
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -s "C:\\ProgramData\\chocolatey\\lib"', '')) == 'choco install chocolatey.install -y -s "C:\\ProgramData\\chocolatey\\lib"'

# Generated at 2022-06-18 07:31:16.433328
# Unit test for function match
def test_match():
    assert match(Command('choco install python', '', '', '', '', ''))
    assert match(Command('cinst python', '', '', '', '', ''))
    assert not match(Command('choco install python', '', '', '', '', ''))
    assert not match(Command('cinst python', '', '', '', '', ''))


# Generated at 2022-06-18 07:31:26.349562
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install foo', '', '')) == 'choco install foo.install'
    assert get_new_command(Command('cinst foo', '', '')) == 'cinst foo.install'
    assert get_new_command(Command('choco install -y foo', '', '')) == 'choco install -y foo.install'
    assert get_new_command(Command('choco install foo -y', '', '')) == 'choco install foo.install -y'
    assert get_new_command(Command('choco install foo -y --force', '', '')) == 'choco install foo.install -y --force'
    assert get_new_command(Command('choco install foo --force -y', '', '')) == 'choco install foo.install --force -y'
    assert get

# Generated at 2022-06-18 07:31:32.257767
# Unit test for function match
def test_match():
    assert match(Command('choco install git', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git -y', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git -y --force', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git -y --force --source="https://chocolatey.org/api/v2/"', '', 'Installing the following packages:\ngit'))
    assert match(Command('cinst git -y --force --source="https://chocolatey.org/api/v2/" --version="2.21.0"', '', 'Installing the following packages:\ngit'))

# Generated at 2022-06-18 07:31:42.825956
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey -source https://chocolatey.org/api/v2', '', '')) == 'choco install -y chocolatey.install -source https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:31:51.410131
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '', '', '', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '', '', '', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '', '', '', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey.extension', '', '', '', '')) == 'cinst -y chocolatey.extension.install'

# Generated at 2022-06-18 07:32:18.945858
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:',
                         'chocolatey v0.10.15',
                         'The package was installed successfully.',
                         '',
                         'chocolatey v0.10.15',
                         '',
                         'Chocolatey installed 1/1 packages. 0 packages failed.',
                         'See the log for details (C:\\ProgramData\\chocolatey\\logs\\chocolatey.log).',
                         '',
                         'Failures',
                         ' - None',
                         '',
                         '',
                         'Chocolatey installed 1/1 packages. 0 packages failed.',
                         'See the log for details (C:\\ProgramData\\chocolatey\\logs\\chocolatey.log).'))

# Generated at 2022-06-18 07:32:25.728191
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey -source https://chocolatey.org/api/v2', '')) == 'choco install -y chocolatey.install -source https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:32:35.098551
# Unit test for function match

# Generated at 2022-06-18 07:32:43.317351
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey -y', '', '', '', '', ''))
    assert match(Command('cinst chocolatey -y -s', '', '', '', '', ''))
    assert match(Command('cinst chocolatey -y -s -f', '', '', '', '', ''))
    assert match(Command('cinst chocolatey -y -s -f -v', '', '', '', '', ''))
    assert match(Command('cinst chocolatey -y -s -f -v -x', '', '', '', '', ''))

# Generated at 2022-06-18 07:32:47.767440
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', ''))
    assert match(Command('cinst chocolatey', '', ''))
    assert not match(Command('choco install chocolatey', '', 'Installing the following packages'))
    assert not match(Command('cinst chocolatey', '', 'Installing the following packages'))


# Generated at 2022-06-18 07:32:57.709246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y --force', '')) == 'choco install chocolatey.install -y --force'
    assert get_new_command(Command('cinst chocolatey -y --force', '')) == 'cinst chocolatey.install -y --force'
    assert get_new_command

# Generated at 2022-06-18 07:33:04.855750
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install python', '')) == 'choco install python.install'
    assert get_new_command(Command('cinst python', '')) == 'cinst python.install'
    assert get_new_command(Command('cinst python -y', '')) == 'cinst python.install -y'
    assert get_new_command(Command('cinst python -y --source=somesource', '')) == 'cinst python.install -y --source=somesource'

# Generated at 2022-06-18 07:33:13.677359
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey.extension', '')) == 'cinst -y chocolatey.extension.install'
    assert get_new_command(Command('cinst -y chocolatey.extension.1.2.3', '')) == 'cinst -y chocolatey.extension.1.2.3.install'

# Generated at 2022-06-18 07:33:24.661191
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install chocolatey -y', '')) == 'choco install chocolatey.install -y'
    assert get_new_command(Command('cinst chocolatey -y', '')) == 'cinst chocolatey.install -y'
    assert get_new_command(Command('choco install chocolatey -y -s "C:\ProgramData\chocolatey\bin"', '')) == 'choco install chocolatey.install -y -s "C:\ProgramData\chocolatey\bin"'

# Generated at 2022-06-18 07:33:35.224128
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey -source https://chocolatey.org/api/v2/', '')) == 'choco install -y chocolatey.install -source https://chocolatey.org/api/v2/'

# Generated at 2022-06-18 07:34:12.893275
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', '', ''))


# Generated at 2022-06-18 07:34:16.491264
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', ''))
    assert match(Command('cinst chocolatey', '', ''))
    assert not match(Command('choco install chocolatey', '', 'Installing the following packages:'))
    assert not match(Command('cinst chocolatey', '', 'Installing the following packages:'))


# Generated at 2022-06-18 07:34:19.992662
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 1, None))
    assert match(Command('cinst chocolatey', '', '', 1, None))
    assert not match(Command('choco install chocolatey', '', '', 1, None))
    assert not match(Command('cinst chocolatey', '', '', 1, None))



# Generated at 2022-06-18 07:34:23.854933
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', ''))
    assert match(Command('cinst chocolatey', ''))
    assert not match(Command('choco install chocolatey', 'Installing the following packages:'))
    assert not match(Command('cinst chocolatey', 'Installing the following packages:'))


# Generated at 2022-06-18 07:34:33.083618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey", "")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey", "")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install chocolatey -y", "")) == "choco install chocolatey.install -y"
    assert get_new_command(Command("cinst chocolatey -y", "")) == "cinst chocolatey.install -y"
    assert get_new_command(Command("choco install chocolatey -y --params", "")) == "choco install chocolatey.install -y --params"
    assert get_new_command(Command("cinst chocolatey -y --params", "")) == "cinst chocolatey.install -y --params"
    assert get_new_command

# Generated at 2022-06-18 07:34:37.104995
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 1, None))
    assert match(Command('cinst chocolatey', '', '', 1, None))
    assert not match(Command('choco install chocolatey', '', '', 1, None))
    assert not match(Command('cinst chocolatey', '', '', 1, None))



# Generated at 2022-06-18 07:34:40.865640
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', 'Installing the following packages', ''))
    assert match(Command('cinst chocolatey', '', 'Installing the following packages', ''))
    assert not match(Command('choco install chocolatey', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', ''))


# Generated at 2022-06-18 07:34:44.224060
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', 0, None))
    assert match(Command('cinst chocolatey', '', '', 0, None))
    assert not match(Command('choco install chocolatey', '', '', 0, None))
    assert not match(Command('cinst chocolatey', '', '', 0, None))


# Generated at 2022-06-18 07:34:52.488194
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '', '', '', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '', '', '', '')) == 'cinst git.install'
    assert get_new_command(Command('cinst -y git', '', '', '', '')) == 'cinst -y git.install'
    assert get_new_command(Command('cinst -y git.install', '', '', '', '')) == 'cinst -y git.install.install'
    assert get_new_command(Command('cinst -y git.install.install', '', '', '', '')) == 'cinst -y git.install.install.install'

# Generated at 2022-06-18 07:35:01.805070
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey -source https://chocolatey.org/api/v2', '')) == 'choco install -y chocolatey.install -source https://chocolatey.org/api/v2'

# Generated at 2022-06-18 07:36:38.345068
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', ''))
    assert match(Command('cinst chocolatey', ''))
    assert not match(Command('choco uninstall chocolatey', ''))
    assert not match(Command('cuninst chocolatey', ''))
    assert not match(Command('choco install chocolatey', 'Installing the following packages:'))
    assert not match(Command('cinst chocolatey', 'Installing the following packages:'))



# Generated at 2022-06-18 07:36:47.816182
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'The package was installed successfully.'))
    assert match(Command('cinst chocolatey',
                         'Installing the following packages:\n'
                         'chocolatey on the current system\n'
                         'The package was installed successfully.'))
    assert not match(Command('choco install chocolatey',
                             'Installing the following packages:\n'
                             'chocolatey on the current system\n'
                             'The package was installed successfully.'))
    assert not match(Command('cinst chocolatey',
                             'Installing the following packages:\n'
                             'chocolatey on the current system\n'
                             'The package was installed successfully.'))


# Generated at 2022-06-18 07:36:52.646756
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', ''))


# Generated at 2022-06-18 07:37:01.022052
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install python', '')) == 'choco install python.install'
    assert get_new_command(Command('cinst python', '')) == 'cinst python.install'
    assert get_new_command(Command('cinst python -y', '')) == 'cinst python.install -y'
    assert get_new_command(Command('cinst python -y --force', '')) == 'cinst python.install -y --force'
    assert get_new_command(Command('cinst python -y --force --version=3.7.4', '')) == 'cinst python.install -y --force --version=3.7.4'

# Generated at 2022-06-18 07:37:08.917259
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("choco install chocolatey", "")) == "choco install chocolatey.install"
    assert get_new_command(Command("cinst chocolatey", "")) == "cinst chocolatey.install"
    assert get_new_command(Command("choco install chocolatey -y", "")) == "choco install chocolatey.install -y"
    assert get_new_command(Command("cinst chocolatey -y", "")) == "cinst chocolatey.install -y"
    assert get_new_command(Command("choco install chocolatey -y --force", "")) == "choco install chocolatey.install -y --force"
    assert get_new_command(Command("cinst chocolatey -y --force", "")) == "cinst chocolatey.install -y --force"
    assert get_new_command

# Generated at 2022-06-18 07:37:13.269125
# Unit test for function match
def test_match():
    assert match(Command('choco install chocolatey', '', '', '', '', ''))
    assert match(Command('cinst chocolatey', '', '', '', '', ''))
    assert not match(Command('choco install chocolatey', '', '', '', '', ''))
    assert not match(Command('cinst chocolatey', '', '', '', '', ''))


# Generated at 2022-06-18 07:37:23.736133
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install python', '')) == 'choco install python.install'
    assert get_new_command(Command('cinst python', '')) == 'cinst python.install'
    assert get_new_command(Command('cinst python -y', '')) == 'cinst python.install -y'
    assert get_new_command(Command('cinst python -y --force', '')) == 'cinst python.install -y --force'
    assert get_new_command(Command('cinst python -y --force --version=3.7.3', '')) == 'cinst python.install -y --force --version=3.7.3'

# Generated at 2022-06-18 07:37:33.735954
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("choco install chocolatey", "")
    assert get_new_command(command) == "choco install chocolatey.install"
    command = Command("cinst chocolatey", "")
    assert get_new_command(command) == "cinst chocolatey.install"
    command = Command("choco install chocolatey -y", "")
    assert get_new_command(command) == "choco install chocolatey.install -y"
    command = Command("cinst chocolatey -y", "")
    assert get_new_command(command) == "cinst chocolatey.install -y"
    command = Command("choco install chocolatey -y -source https://chocolatey.org/api/v2", "")

# Generated at 2022-06-18 07:37:42.297025
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install git', '', '', '', '', '')) == 'choco install git.install'
    assert get_new_command(Command('cinst git', '', '', '', '', '')) == 'cinst git.install'
    assert get_new_command(Command('cinst git -y', '', '', '', '', '')) == 'cinst git.install -y'
    assert get_new_command(Command('cinst git -y --version=2.16.2', '', '', '', '', '')) == 'cinst git.install -y --version=2.16.2'

# Generated at 2022-06-18 07:37:51.040644
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('choco install chocolatey', '')) == 'choco install chocolatey.install'
    assert get_new_command(Command('cinst chocolatey', '')) == 'cinst chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey', '')) == 'choco install -y chocolatey.install'
    assert get_new_command(Command('cinst -y chocolatey', '')) == 'cinst -y chocolatey.install'
    assert get_new_command(Command('choco install -y chocolatey.extension', '')) == 'choco install -y chocolatey.extension.install'
    assert get_new_command(Command('cinst -y chocolatey.extension', '')) == 'cinst -y chocolatey.extension.install'
    assert get