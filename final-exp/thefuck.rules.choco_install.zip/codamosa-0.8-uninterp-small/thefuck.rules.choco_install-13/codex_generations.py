

# Generated at 2022-06-26 05:35:46.504943
# Unit test for function match
def test_match():
    int_0 = 2
    var_0 = match(int_0)


# Generated at 2022-06-26 05:35:48.803293
# Unit test for function match
def test_match():
    # No assert is needed because this function is triggered when "choco install" is invoked
    pass


# Generated at 2022-06-26 05:35:51.615385
# Unit test for function match
def test_match():
    script = 'choco install chocolatey'
    output = 'Installing the following packages:'
    command = Command(script=script, output=output)
    assert match(command)



# Generated at 2022-06-26 05:35:53.113386
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = 2
    var_0 = get_new_command(int_0)
    #assert var_0 == False


# Generated at 2022-06-26 05:35:57.324644
# Unit test for function match
def test_match():
    var_0 = Command('choco install')
    var_0.did_fail = True
    var_0.output = 'Installing the following packages:'
    var_1 = Command('choco install it')
    var_1.did_fail = True
    var_1.output = 'Installing the following packages:'
    var_2 = Command('choco install')
    var_2.did_fail = True
    var_2.output = 'Installing it'
    var_3 = Command('choco install it')
    var_3.did_fail = True
    var_3.output = 'Installing it'
    var_4 = Command('cinst it')
    var_4.did_fail = True
    var_4.output = 'Installing the following packages:'
    var_5 = Command('cinst')


# Generated at 2022-06-26 05:36:00.091716
# Unit test for function get_new_command
def test_get_new_command():
    command =  Command("choco install -y python")
    result = get_new_command(command)
    assert result == 'choco install -y python.install'

# Generated at 2022-06-26 05:36:02.933270
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = 2
    var_0 = get_new_command(int_0)
    assert var_0 == []



# Generated at 2022-06-26 05:36:10.630296
# Unit test for function match
def test_match():
    assert match(Command('choco install stuff', '')), 'choco install stuff -> True'
    assert not match(Command('choco notinstall stuff', '')), 'choco notinstall stuff -> False'
    assert match(Command('choco install stuff', 'Installing the following packages:\nstuff')), 'choco install stuff -> True'
    assert not match(Command('choco install stuff', 'Installing the following packages:\nstuff\nstuff')), 'choco install stuff -> False'
    assert match(Command('choco install stuff', 'Installing the following packages:\nstuff\nstuff\n')), 'choco install stuff -> True'
    assert not match(Command('choco install stuff', 'Installing the following packages:\nstuff\nstuff\nstuff')), 'choco install stuff -> False'

# Generated at 2022-06-26 05:36:12.481336
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 05:36:17.786734
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = 1
    var_0 = get_new_command(int_0)
#
#
#
#
#
#

# Generated at 2022-06-26 05:36:24.891355
# Unit test for function match
def test_match():
    assert match('choco install -y test') == False
    assert match('cinst test') == True
    assert match('choco install wget') == True


# Generated at 2022-06-26 05:36:27.940551
# Unit test for function match
def test_match():
    str_0 = 'KcgRbXhrc0'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:36:30.883567
# Unit test for function match
def test_match():
    assert match('start') == False
    assert match('start choco install') == True
    assert match('start cinst') == False
    assert match('start cinst foo') == True
    assert match('start choco async') == False


# Generated at 2022-06-26 05:36:36.775980
# Unit test for function match
def test_match():
    var_0 = 'choco install C:\\Users\\lzx20\\Desktop\\dnsr'
    var_0 = Command(var_0)
    var_0.script = 'choco install C:\\Users\\lzx20\\Desktop\\dnsr'
    var_0.script_parts = var_0.script.split()
    var_0.output = 'Installing the following packages:'
    var_0.output_lines = var_0.output.split('\n')
    var_0 = match(var_0)
    assert var_0 == True


# Generated at 2022-06-26 05:36:40.149023
# Unit test for function match
def test_match():

   assert match("install something") is True,"test_match"
   assert match("cinst something") is True,"test_match"



# Generated at 2022-06-26 05:36:44.085341
# Unit test for function match
def test_match():

    str_0 = "choco install test"
    str_1 = "choco install test"
    var_0 = match(str_0)
    var_1 = match(str_1)
    assert var_0 == var_1


# Generated at 2022-06-26 05:36:50.635802
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'choco install spell 0.9.6'
    var_0 = get_new_command(str_0)
    str_1 = 'choco install spell 0.9.6'
    var_1 = get_new_command(str_1)
    str_2 = 'choco install spell 0.9.6'
    var_2 = get_new_command(str_2)
    assert var_0 == 'choco install spell.install 0.9.6'
    assert var_1 == 'choco install spell.install 0.9.6'
    assert var_2 == 'choco install spell.install 0.9.6'

# Generated at 2022-06-26 05:36:51.450011
# Unit test for function match
def test_match():
    assert match == 'choco install'


# Generated at 2022-06-26 05:36:52.570406
# Unit test for function match
def test_match():
    assert 'cinst -y nuget.commandline' == match

# Generated at 2022-06-26 05:37:02.493623
# Unit test for function get_new_command
def test_get_new_command():
    assert 'choco.install' == get_new_command(['choco', 'install', 'chocolatey'])
    assert 'choco.install' == get_new_command(['choco.exe', 'install', 'chocolatey'])
    assert 'cinst.install' == get_new_command(['cinst', 'chocolatey'])
    assert 'cinst.install' == get_new_command(['cinst', 'chocolatey.install'])
    assert 'cinst.install' == get_new_command(['cinst', 'chocolatey', '-Version', '0.9.9.8'])
    assert 'cinst.install' == get_new_command(['cinst', 'chocolatey', '-pre'])

# Generated at 2022-06-26 05:37:19.103367
# Unit test for function match
def test_match():
    assert match('A3L_') == False
    assert match('choco install q3l-test') == True
    assert match("cinst q3l-test") == True
    assert match("cinst 'q3l-test") == True
    assert match("cinst 'q3l-test'") == True
    assert match("cinst \"q3l-test\"") == True
    assert match("cinst -source 'q3l-test'") == True
    assert match("cinst -source=\"q3l-test\"") == True
    assert match("cinst -source=q3l-test") == True
    assert match("choco uninstall q3l-test") == False
    assert match("cuninst q3l-test") == False


# Generated at 2022-06-26 05:37:20.896267
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'Kf5d5'
    var_0 = get_new_command(str_0)
    assert var_0 is False

# Generated at 2022-06-26 05:37:23.986024
# Unit test for function get_new_command
def test_get_new_command():
    with mock.patch('thefuck.rules.chocolatey.enabled_by_default',
                    enabled_by_default):
        with mock.patch('thefuck.rules.chocolatey.get_new_command',
                        side_effect=get_new_command) as new_command:
            assert new_command('').called

# Generated at 2022-06-26 05:37:37.225682
# Unit test for function get_new_command
def test_get_new_command():
    assert "choco install foo -y" == get_new_command('choco install foo -y')
    assert "choco install foo.install -y" == get_new_command('choco install foo -y && Installing the following packages:')
    assert "choco install foo.install -y" == get_new_command('choco install foo && Installing the following packages:')
    assert "choco install foo.install -y" == get_new_command('choco install foo && Installing the following packages')
    assert "choco install foo.install -y" == get_new_command('choco install foo && Installing the following packages\r\n')
    assert "choco install foo.install -y" == get_new_command('choco install foo && Installing the following packages\n')


# Generated at 2022-06-26 05:37:48.629402
# Unit test for function get_new_command
def test_get_new_command():
    # AssertionError: Expected '', not ['']
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')
    assert (get_new_command('Q3L_') == '')

# Generated at 2022-06-26 05:37:57.203486
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'choco install foo bar baz'
    str_1 = ['choco', 'install', 'foo', 'bar', 'baz']
    str_2 = 'choco install foo bar baz'
    str_3 = 'choco install foo bar baz'
    int_1 = 1
    int_2 = 3
    int_3 = 0
    # Invoking get_new_command with arguments (str) str_0
    var_0 = get_new_command(str_0)
    # Asserting the bitsize of (str) var_0 with expected value (int) int_1
    assert (bitsize(var_0) == int_1)
    # Asserting var_0 equals to str_1
    assert (var_0 == str_1)
    # Invoking get_new_command

# Generated at 2022-06-26 05:37:59.224564
# Unit test for function match
def test_match():
    str_0 = 'aZ6'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:38:04.103158
# Unit test for function get_new_command
def test_get_new_command():
    #Cases:
    str_0 = 'Q3L_'
    assert get_new_command(str_0) == ['Q3L_.install']

    str_1 = 'bq3v'
    assert get_new_command(str_1) == ['bq3v.install']

# ~~~


# Generated at 2022-06-26 05:38:05.958726
# Unit test for function match
def test_match():
    str_0 = 'choco install --pre test'
    var_0 = match(str_0)
    assert not var_0


# Generated at 2022-06-26 05:38:07.865337
# Unit test for function match
def test_match():
    str_0 = '$sGtBG[h0z'
    str_1 = 'Q3L_'


# Generated at 2022-06-26 05:38:20.776748
# Unit test for function match
def test_match():
    assert match("choco install consolez") == True


# Generated at 2022-06-26 05:38:23.689891
# Unit test for function match
def test_match():
    str_0 = 'cinst -Source "c:\packages" chocolate'
    var_0 = match(str_0)
    assert var_0 == True


# Generated at 2022-06-26 05:38:26.184447
# Unit test for function get_new_command
def test_get_new_command():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 05:38:30.699857
# Unit test for function match
def test_match():
    assert match is not None


# Generated at 2022-06-26 05:38:32.157214
# Unit test for function match
def test_match():
    assert match(str_0) == bool_0

# Test call: match

# Generated at 2022-06-26 05:38:42.744389
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('choco install -y ') == [])
    assert (get_new_command('cinst -y') == [])
    assert (get_new_command('choco install -y 7zip.install') == [])
    assert (get_new_command('choco install -y 7zip') == 'choco install -y 7zip.install')
    assert (get_new_command('cinst 7zip') == 'cinst 7zip.install')
    assert (get_new_command('cinst 7zip.install -y') == [])

# Generated at 2022-06-26 05:38:44.996503
# Unit test for function get_new_command
def test_get_new_command():
	str_0 = 'J3/o'
	var_1 = get_new_command(str_0)
	assert str_0 == 'J3/o'
	assert var_1 == '.J3/o.install'

# Generated at 2022-06-26 05:38:54.832705
# Unit test for function get_new_command
def test_get_new_command():
    from scripts.fuck import Command

    str_0 = 'choco install 1nvalid'
    str_1 = 'cinst 1nvalid'

    from scripts.fuck import Command
    import mock

    assert get_new_command(Command(str_0, mock.mock_open(read_data=str_0 + '\n' + '').return_value, '')) == 'choco install 1nvalid.install'
    assert get_new_command(Command(str_1, mock.mock_open(read_data=str_1 + '\n' + '').return_value, '')) == 'cinst 1nvalid.install'

# Generated at 2022-06-26 05:38:55.984332
# Unit test for function match
def test_match():
    assert True


# Generated at 2022-06-26 05:39:02.980620
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = True
    str_0 = '+@F;'
    var_0 = get_new_command(str_0)
    assert var_0 == "choco install my.package.install", "Expected \"choco install my.package.install\", but got " + var_0
    var_0 = False
    str_0 = ':BX9'
    var_0 = get_new_command(str_0)
    assert var_0 == "choco install my.package.install", "Expected \"choco install my.package.install\", but got " + var_0
    var_0 = False
    str_0 = 'BHF@'
    var_0 = get_new_command(str_0)

# Generated at 2022-06-26 05:39:33.342028
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'choco install notepadplusplus git'
    var_0 = get_new_command(str_0)

    str_0 = 'cinst notepadplusplus.install git.install'
    var_0 = get_new_command(str_0)


# Generated at 2022-06-26 05:39:39.030664
# Unit test for function match
def test_match():
    print("Testing match")
    str_0 = 'j4v_'
    var_0 = for_app(str_0, "cinst")
    print(var_0)


# Generated at 2022-06-26 05:39:43.121800
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(str_0) == str_0.replace(var_0, var_0 + ".install")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:39:46.662640
# Unit test for function match
def test_match():
    str_0 = 'choco install s'
    var_0 = ""

    out_0 = match(str_0)
    assert out_0 == False



# Generated at 2022-06-26 05:39:48.184016
# Unit test for function get_new_command
def test_get_new_command():
    assert not var_0 
    pass




# Generated at 2022-06-26 05:39:49.117870
# Unit test for function match
def test_match():
    assert match('') is False

# Generated at 2022-06-26 05:39:51.049590
# Unit test for function match
def test_match():
    assert match('') == True

# Generated at 2022-06-26 05:39:55.089081
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = '1'
    var_0 = get_new_command(str_0)



# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------

# Generated at 2022-06-26 05:40:01.811616
# Unit test for function match
def test_match():
    assert match('choco install gmq3l')
    assert match('cinst gmq3l')
    assert match('cinst')
    assert not match('choco install')
    assert not match('choco install -y')
    assert not match('choco install -y gmq3l')
    assert not match('choco uninstall')
    assert not match('choco uninstall -y')
    assert not match('choco uninstall -y gmq3l')
    assert not match('cinst -y')
    assert not match('cinst -y gmq3l')


# Generated at 2022-06-26 05:40:03.088548
# Unit test for function match
def test_match():
    assert match(str_0)

# Generated at 2022-06-26 05:40:56.267037
# Unit test for function match
def test_match():
    str_1 = 'command choco install'
    var_1 = for_app("choco", "cinst")(match(str_1))
    assert var_1 == True


# Generated at 2022-06-26 05:41:05.800087
# Unit test for function match
def test_match():
    assert match('choco install Q3L_') == True
    assert match('cinst Q3L_') == True
    assert match('choco install Q3L_ --version 2.2.1.1') == True
    assert match('cinst Q3L_ --version 2.2.1.1') == True
    assert match('choco install Q3L_ -version 2.2.1.1') == True
    assert match('cinst Q3L_ -version 2.2.1.1') == True
    assert match('choco install Q3L_ /version 2.2.1.1') == True
    assert match('cinst Q3L_ /version 2.2.1.1') == True
    assert match('choco install Q3L_ --pre') == True

# Generated at 2022-06-26 05:41:08.495126
# Unit test for function match
def test_match():
    str_0 = 'Q3L_'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:41:17.834591
# Unit test for function match
def test_match():
    assert match("choco install googlechrome")
    assert match("cinst googlechrome")
    assert match("choco install googlechrome -y")
    assert match("cinst googlechrome -y")
    assert match("choco install microsoft-build-tools --installargs 'ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1'")
    assert match("cinst microsoft-build-tools --installargs 'ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1'")
    assert match("choco install microsoft-build-tools  -y --installargs 'ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1'")

# Generated at 2022-06-26 05:41:19.462222
# Unit test for function get_new_command
def test_get_new_command():
    # Assert that get_new_command(str) returns str
    assert get_new_command('Q3L_') == 'Q3L_.install'

# Generated at 2022-06-26 05:41:25.509527
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'lJYvSUF'
    var_0 = get_new_command(str_0)
    assert(var_0 == 'lJYvSUF' + '.install')

# Generated at 2022-06-26 05:41:27.870610
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:41:28.887412
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(0) == 0

# Generated at 2022-06-26 05:41:33.464958
# Unit test for function match
def test_match():
    assert (False) == match('Q3L_')
    assert (False) == match('Q3L_')


# Generated at 2022-06-26 05:41:34.788702
# Unit test for function get_new_command
def test_get_new_command():
    assert 'wine' == get_new_command('choco install wine')

# Generated at 2022-06-26 05:43:46.504614
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'choco install notepadplusplus'
    var_0 = get_new_command(str_0)

    assert(var_0 == 'choco install notepadplusplus.install')

    str_1 = 'cinst notepadplusplus'
    var_1 = get_new_command(str_1)

    assert(var_1 == 'cinst notepadplusplus.install')

    str_2 = 'choco install -d -y notepadplusplus'
    var_2 = get_new_command(str_2)

    assert(var_2 == 'choco install -d -y notepadplusplus.install')

    str_3 = 'cinst -d -y notepadplusplus'
    var_3 = get_new_command(str_3)


# Generated at 2022-06-26 05:43:49.782640
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'Q3L_'
    var_0 = get_new_command(str_0)

# Generated at 2022-06-26 05:43:52.809068
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)
    # Example 1
    str_0 = 'choco install chocolatey'
    var_0 = get_new_command(str_0)
    assert var_0 == 'choco install chocolatey.install'

# Generated at 2022-06-26 05:43:56.864214
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('Q3L_') == 'Q3L_.install')
    assert (get_new_command('Q5H_') == 'Q5H_.install')
    assert (get_new_command('9BM_') == '9BM_.install')

# Generated at 2022-06-26 05:44:04.981864
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'DwLs-tKuWRy'
    var_1 = get_new_command(var_0)
    print(var_1)


# Generated at 2022-06-26 05:44:12.272386
# Unit test for function get_new_command
def test_get_new_command():
    assert str_0 == get_new_command(str_0) == [], "test case 0 failed."
    assert str_1 == get_new_command(str_1) == [], "test case 1 failed."
    assert str_2 == get_new_command(str_2) == [], "test case 2 failed."
    assert str_3 == get_new_command(str_3) == [], "test case 3 failed."
    assert str_4 == get_new_command(str_4) == [], "test case 4 failed."
    assert str_5 == get_new_command(str_5) == [], "test case 5 failed."
    assert str_6 == get_new_command(str_6) == [], "test case 6 failed."

# Generated at 2022-06-26 05:44:13.992424
# Unit test for function match
def test_match():
    assert match('choco install Q3L') == True
    assert match('choco install Q3L') != False



# Generated at 2022-06-26 05:44:22.522084
# Unit test for function match
def test_match():
    # This is the case when the function returns False
    var_1 = match("choco install")
    assert var_1 == False
    # This is the case when the function returns True
    var_2 = match("choco install test")
    assert var_2 == True
    # This is the case when the function returns True
    var_3 = match("cinst test")
    assert var_3 == True


# Generated at 2022-06-26 05:44:32.922348
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("choco") == "choco"
    assert get_new_command("choco notepadplusplus") == "choco notepadplusplus.install"
    assert get_new_command("cinst notepadplusplus") == "cinst notepadplusplus.install"
    assert get_new_command("cinst -y notepadplusplus") == "cinst -y notepadplusplus.install"
    assert get_new_command("cinst notepadplusplus -y") == "cinst notepadplusplus -y"
    assert get_new_command("choco install notepadplusplus") == "choco install notepadplusplus.install"
    assert get_new_command("choco install notepadplusplus -y") == "choco install notepadplusplus -y"

# Generated at 2022-06-26 05:44:34.007049
# Unit test for function get_new_command
def test_get_new_command():
    assert str(get_new_command) == 'Q3L_'
