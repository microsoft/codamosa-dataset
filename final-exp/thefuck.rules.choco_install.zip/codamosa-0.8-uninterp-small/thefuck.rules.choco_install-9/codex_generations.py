

# Generated at 2022-06-26 05:35:57.203951
# Unit test for function get_new_command

# Generated at 2022-06-26 05:36:00.846251
# Unit test for function get_new_command
def test_get_new_command():

    # Test 1
    s = """choco install PackageName"""
    set_0 = Command(script=s)
    var_0 = get_new_command(set_0)
    assert var_0 == "choco install PackageName.install"

# Generated at 2022-06-26 05:36:09.789675
# Unit test for function match
def test_match():
    # Test 1 - "choco install <pkg>"
    command = Command(script="choco install <pkg>", output = "Installing the following packages:\n<pkg>")
    assert match(command)
    # Test 2 - "cinst <pkg>"
    command = Command(script="cinst <pkg>", output = "Installing the following packages:\n<pkg>")
    assert match(command)
    # Test 3 - "cinst -f --ignore-package-exit-codes <pkg> <pkg>"
    command = Command(script="cinst -f --ignore-package-exit-codes <pkg> <pkg>", output = "Installing the following packages:\n<pkg>")
    assert match(command)
    # Test 4 - "choco install <pkg> -y --params='/SelectVSCodeUserSideload' --version 1

# Generated at 2022-06-26 05:36:15.764121
# Unit test for function match
def test_match():
    set_0 = None
    set_1 = None
    set_2 = None
    set_3 = None
    var_0 = match(set_0)
    var_1 = match(set_1)
    var_2 = match(set_2)
    var_3 = match(set_3)
    assert var_0 != var_1 != var_2 != var_3 != None


# Generated at 2022-06-26 05:36:18.522024
# Unit test for function get_new_command

# Generated at 2022-06-26 05:36:23.088245
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = Command('choco install')
    var_0.script = 'choco install'
    var_0.script_parts = ['choco', 'install']
    var_0.output = 'Installing the following packages:'
    set_0 = var_0
    set_1 = ('choco install'.replace('choco', 'choco.install'),)
    assert set_1 == get_new_command(set_0)

# Generated at 2022-06-26 05:36:27.980592
# Unit test for function get_new_command
def test_get_new_command():
    set_1 = None
    var_1 = get_new_command(set_1)
    var_2 = get_new_command(set_1)
    var_3 = get_new_command(set_1)
    assert var_1 == var_2 is var_3



# Generated at 2022-06-26 05:36:29.151436
# Unit test for function match
def test_match():
    assert for_app("choco", "cinst") in globals()


# Generated at 2022-06-26 05:36:35.947428
# Unit test for function get_new_command
def test_get_new_command():
    # Simulate execution of `choco install` command in tester and return output
    set_0 = type(
        "CommandObject",
        (object,),
        {
            "script": 'choco install 7zip',
            "script_parts": ['choco', 'install', '7zip'],
            "output": """Installing the following packages:
  7zip""",
        },
    )
    var_0 = get_new_command(set_0)
    assert type(var_0) is str
    assert var_0 == 'choco install 7zip.install'



# Generated at 2022-06-26 05:36:36.705912
# Unit test for function match
def test_match():
    assert match(set_0)


# Generated at 2022-06-26 05:36:44.968766
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'choco install PackageName'
    obj_0 = Command(str_0)

    str_1 = 'PackageName.install'
    obj_1 = get_new_command(obj_0)

    if not obj_1 == str_1:
        raise AssertionError("get_new_command function failed:\n")
    return True

# Generated at 2022-06-26 05:36:46.450672
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(test_case_0) == 'choco install PackageName.install'

# Generated at 2022-06-26 05:36:52.098148
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(test_case_0) == 'choco install PackageName.install'

# Generated at 2022-06-26 05:36:53.119813
# Unit test for function match
def test_match():
    assert not match(test_case_0())


# Generated at 2022-06-26 05:36:55.712105
# Unit test for function match
def test_match():
    command = Command(script=str_0,output=str_1)
    assert match(command) == True


# Generated at 2022-06-26 05:36:57.732989
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(test_case_0) == 'choco install PackageName.install'

# Generated at 2022-06-26 05:37:04.570332
# Unit test for function match
def test_match():
    str_0 = 'choco install PackageName'
    str_1 = 'choco install PackageName '
    str_2 = 'choco install PackageName -source '
    str_3 = 'choco install PackageName -source https://'
    str_4 = 'choco install PackageName someotherparameters'
    str_5 = 'cinst PackageName'
    assert match(str_0) == false
    assert match(str_1) == false
    assert match(str_2) == false
    assert match(str_3) == false
    assert match(str_4) == false
    assert match(str_5) == false
    return

test_match()


# Generated at 2022-06-26 05:37:05.590455
# Unit test for function match
def test_match():
    result = match(get_new_command(test_case_0()))

    assert result == []


# Generated at 2022-06-26 05:37:06.730107
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 05:37:08.783383
# Unit test for function get_new_command
def test_get_new_command():
    test_case_0_result = test_case_0()
    assert test_case_0_result == 'choco install PackageName.install'

# Generated at 2022-06-26 05:37:13.793304
# Unit test for function get_new_command
def test_get_new_command():
    command = get_new_command()
    assert command == 'choco install package_name'


# Generated at 2022-06-26 05:37:14.666054
# Unit test for function match
def test_match():
    assert match(None)


# Generated at 2022-06-26 05:37:17.586335
# Unit test for function match
def test_match():
    script = "choco install chocolatey"
    output = "Installing the following packages: chocolatey"
    command = Command(script, output)
    assert not match(command)

# Generated at 2022-06-26 05:37:20.469162
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = Command('cinst eval')
    var_0 = get_new_command(set_0)
    assert var_0 == 'cinst eval.install'



# Generated at 2022-06-26 05:37:22.191060
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = None
    var_0 = get_new_command(set_0)
    assert var_0 == []


# Generated at 2022-06-26 05:37:26.739576
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = None
    var_0 = get_new_command(set_0)


# Generated at 2022-06-26 05:37:33.545577
# Unit test for function match
def test_match():
    assert match(set_0) == False
    assert match(set_1) == False
    assert match(set_2) == False
    assert match(set_3) == False
    assert match(set_4) == False
    assert match(set_5) == False
    assert match(set_6) == False
    assert match(set_7) == False
    assert match(set_8) == False
    assert match(set_9) == False
    assert match(set_10) == False
    assert match(set_11) == False
    assert match(set_12) == False
    assert match(set_13) == False
    assert match(set_14) == False
    assert match(set_15) == False
    assert match(set_16) == False
    assert match(set_17) == False
   

# Generated at 2022-06-26 05:37:43.659403
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = mock.Mock(script="choco install elm")
    var_0 = get_new_command(set_0)
    assert var_0 == "choco install elm.install"
    set_1 = mock.Mock(script="cinst elm")
    var_1 = get_new_command(set_1)
    assert var_1 == "cinst elm.install"
    set_2 = mock.Mock(script="choco install -y git")
    var_2 = get_new_command(set_2)
    assert var_2 == "choco install -y git.install"
    set_3 = mock.Mock(script="cinst -y git")
    var_3 = get_new_command(set_3)

# Generated at 2022-06-26 05:37:45.437789
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)


# Generated at 2022-06-26 05:37:48.588414
# Unit test for function match
def test_match():
    var_1 = None
    var_2 = match(var_1)
    assert var_2 == "Sorry, the default provider 'chocolatey' may not be installed or is not available."

# Generated at 2022-06-26 05:38:06.136323
# Unit test for function match
def test_match():
    var_0 = None
    sess = None
    set_0 = False
    var_1 = for_app(var_0, sess)(set_0)
    assert var_1
    var_0 = None
    sess = None
    for var_4 in range(12):
        var_0 = var_4
        var_1 = for_app(var_0, sess)(set_0)
        assert var_1
    var_0 = None
    sess = None
    set_0 = False
    var_1 = for_app(var_0, sess)(set_0)
    assert var_1
    var_0 = None
    sess = None
    for var_4 in range(28):
        var_0 = var_4

# Generated at 2022-06-26 05:38:07.650034
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)



# Generated at 2022-06-26 05:38:09.312494
# Unit test for function match
def test_match():
    assert match(command=Mock(script=(), output=(), script_parts=()))


# Generated at 2022-06-26 05:38:10.616632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(set_0) == cmd_0


# Generated at 2022-06-26 05:38:12.065900
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('choco install') == 'choco install.install'

# Generated at 2022-06-26 05:38:14.580780
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = None
    var_1 = match(set_0)


# Generated at 2022-06-26 05:38:19.870709
# Unit test for function get_new_command
def test_get_new_command():

    assert "choco install chocolatey.install" == get_new_command(
        Command('chocolatey install chocolatey', '', '', 0)
    )

    assert "cinst chocolatey.install" == get_new_command(
        Command('cinst chocolatey', '', '', 0)
    )

    assert "choco install chocolatey.install" == get_new_command(
        Command('choco install chocolatey', '', '', 0)
    )

# Generated at 2022-06-26 05:38:31.656087
# Unit test for function match
def test_match():
    # test for match function
    # set_0 = None
    # var_0 = get_new_command(set_0)
    # def test_case_0():
    #     set_0 = None
    #     var_0 = get_new_command(set_0)
    set_0 = Command.from_str('choco install git', '', '')
    var_0 = match(set_0)
    set_1 = Command.from_str('cinst git', '', '')
    var_1 = match(set_1)
    set_2 = Command.from_str('choco install chromium', '', '')
    var_2 = match(set_2)
    set_3 = Command.from_str('cinst chromium', '', '')

# Generated at 2022-06-26 05:38:36.655559
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)
    return var_0


# Generated at 2022-06-26 05:38:44.178394
# Unit test for function get_new_command
def test_get_new_command():
    set_1 = Command("choco install chocolatey", "")
    var_1 = get_new_command(set_1)
    assert var_1 == "choco install chocolatey.install"

    set_2 = Command("cinst chocolatey", "")
    var_2 = get_new_command(set_2)
    assert var_2 == "cinst chocolatey.install"

    set_3 = Command("choco install -y chocolatey", "")
    var_3 = get_new_command(set_3)
    assert var_3 == "choco install -y chocolatey.install"

# Generated at 2022-06-26 05:39:02.975106
# Unit test for function get_new_command
def test_get_new_command():
    assertion_failed_message = "A test for function get_new_command has failed"

    test_classes = [
        # TestCase_0
        [
            'choco install odbc',
            'choco install odbc.install'
        ]
    ]

    test_functions = [
        test_get_new_command_0,
        test_get_new_command_1,
        test_get_new_command_2,
        test_get_new_command_3,
        test_get_new_command_4,
        test_get_new_command_5
    ]

    for i in range(6):
        set_0 = test_classes[0][i]
        var_0 = get_new_command(set_0)

# Generated at 2022-06-26 05:39:12.414163
# Unit test for function match
def test_match():
    set_1 = Mock(
        script='choco install',
        script_parts=['choco', 'install'],
        output='Installing the following packages:',
    )
    var_1 = match(set_1)

    set_2 = Mock(
        script='cinst',
        script_parts=['cinst'],
        output='Installing the following packages:',
    )
    var_2 = match(set_2)

    set_3 = Mock(
        script='choco install',
        script_parts=['choco', 'install'],
        output='',
    )
    var_3 = match(set_3)

    set_4 = Mock(
        script='cinst',
        script_parts=['cinst'],
        output='',
    )

# Generated at 2022-06-26 05:39:16.304392
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command(script='''choco install mars''', stdout='''
Installing the following packages:
  mars
By installing you accept licenses for the packages.

The package(s) come(s) from a package source that is not marked as trusted.
Are you sure you want to install software from 'chocolatey'?
[Yes] [No]
No

Installation cancelled.''')
    assert get_new_command(cmd) == 'choco install mars.install'



# Generated at 2022-06-26 05:39:27.941813
# Unit test for function match
def test_match():
    set_0 = Command("choco install GoogleChrome", "Installing the following packages:\r\n\r\nGoogleChrome.install By installing you accept licenses for the packages.", "")
    var_0 = (set_0.script.startswith('choco install') or 'cinst' in set_0.script_parts)
    var_1 = ("Installing the following packages" in set_0.output)
    var_2 = match(set_0)

    set_1 = Command("cinst googlechrome", "Installing the following packages:\r\n\r\nGoogleChrome By installing you accept licenses for the packages.\r\nChocolatey v0.10.3", "")

# Generated at 2022-06-26 05:39:35.374331
# Unit test for function get_new_command
def test_get_new_command():
    set_1 = MagicMock(spec=Command)
    type(set_1).app_alias = PropertyMock(return_value = MagicMock(spec=str))
    type(set_1)._script = PropertyMock(return_value=MagicMock(spec=str))
    type(set_1).script_parts = PropertyMock(return_value=MagicMock(spec=list))
    type(set_1).output = PropertyMock(return_value=MagicMock(spec=str))
    var_1 = get_new_command(set_1)
    assert var_1 == []

# Generated at 2022-06-26 05:39:37.151669
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.chocolatey_force_install import get_new_command
    assert get_new_command(None) == []

# Generated at 2022-06-26 05:39:39.267339
# Unit test for function get_new_command
def test_get_new_command():
    old_command='choco install chocolatey'
    new_command='install chocolatey'
    assert get_new_command(old_command)==new_command

# Generated at 2022-06-26 05:39:41.052801
# Unit test for function match
def test_match():
    var_1 = None
    set_1 = f'choco install git'


# Generated at 2022-06-26 05:39:48.976176
# Unit test for function get_new_command
def test_get_new_command():

    # Case 0
    set_0 = None
    var_0 = get_new_command(set_0)
    assert var_0 is None, var_0

    # Case 1
    set_1 = Command(script="choco install 5", output="")
    var_1 = get_new_command(set_1)
    assert var_1 == "choco 5.install", var_1

    # Case 2
    set_2 = Command(script="choco install 5 install", output="")
    var_2 = get_new_command(set_2)
    assert var_2 == "choco 5.install install", var_2

    # Case 3
    set_3 = Command(script="choco \t\tinstall 5 install", output="")
    var_3 = get_new_command(set_3)
   

# Generated at 2022-06-26 05:39:54.192713
# Unit test for function match
def test_match():
    set_1 = Command()
    set_1.script_parts = ["cinst", "7zip.install"]
    var_1 = match(set_1)
    assert var_1 == True


# Generated at 2022-06-26 05:40:20.187586
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = None
    var_0 = get_new_command(set_0)

# Generated at 2022-06-26 05:40:22.422701
# Unit test for function match
def test_match():
    assert match("-d cinst -r cinst") == False



# Generated at 2022-06-26 05:40:25.869032
# Unit test for function get_new_command
def test_get_new_command():
    try:
        assert (test_case_0())
    except:
        print("Test Case 0:", test_case_0())
        return 0
    return 1


# Generated at 2022-06-26 05:40:26.339209
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-26 05:40:31.030833
# Unit test for function get_new_command
def test_get_new_command():
    set_1 = Command()
    set_1.script = 'choco install vscode'
    set_1.script_parts = {'choco', 'install', 'vscode'}
    set_1.output = None
    var_1 = get_new_command(set_1)
    assert var_1 == 'choco install vscode.install'


# Generated at 2022-06-26 05:40:32.714585
# Unit test for function match
def test_match():
    set_0 = for_app("choco", "cinst")
    var_0 = match(set_0)


# Generated at 2022-06-26 05:40:38.206613
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)
    set_1 = None
    var_1 = match(set_1)
    set_2 = None
    var_2 = match(set_2)
    set_3 = None
    var_3 = match(set_3)
    set_4 = None
    var_4 = match(set_4)
    set_5 = None
    var_5 = match(set_5)
    set_6 = None
    var_6 = match(set_6)
    set_7 = None
    var_7 = match(set_7)

# Generated at 2022-06-26 05:40:45.658430
# Unit test for function match
def test_match():
    set_1 = Command(script = "choco install pip", output = "Installing the following packages : pip")
    var_1 = match(set_1)
    assert var_1 == True

    set_2 = Command(script = "cinst pip", output = "Installing the following packages : pip")
    var_2 = match(set_2)
    assert var_2 == True

    set_3 = Command(script = "choco install pip", output = "Installing package 'pip' ... ")
    var_3 = match(set_3)
    assert var_3 == False

    set_4 = Command(script = "cinst pip", output = "Installing package 'pip' ... ")
    var_4 = match(set_4)
    assert var_4 == False


# Generated at 2022-06-26 05:40:49.337166
# Unit test for function get_new_command
def test_get_new_command():
    with pytest.raises(TypeError):
        set_0 = None
        var_0 = get_new_command(set_0)


# Generated at 2022-06-26 05:41:01.232864
# Unit test for function match
def test_match():
    assert match(Command(script="choco install chocolatey",
        output="Chocolatey v0.10.8\r\nInstalling the following packages:\r\nchocolatey\r\nBy installing you accept the license for each package.\r\nchocolatey v0.10.8 [Approved]\r\n",
        stderr="",
        code=0))
    assert not match(Command(script="choco install chocolatey",
        output="Chocolatey v0.10.8\r\nInstalling the following packages:\r\nchocolatey\r\nBy installing you accept the license for each package.\r\nchocolatey v0.10.8 [Approved]\r\n",
        stderr="",
        code=0))

# Generated at 2022-06-26 05:41:55.770155
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(ForAppCommand(script='choco install boop', output='Installing the following packages:\nboop chocolatey 1.0.0\n')) == "choco install boop.install"

# Generated at 2022-06-26 05:41:58.847719
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)
    assert var_0 == False



# Generated at 2022-06-26 05:42:05.740447
# Unit test for function match
def test_match():
    command = (
        Command("choco install chocolatey", "Installing the following packages:\r\nchocolatey (0.10.2)\r\n\r\nThe package chocolatey wants to run 'chocolateyInstall.ps1'.\r\nNote: If you don't run this script, the installation will fail.\r\nNote: To confirm automatically next time, use '-y' or consider:\r\nchoco feature enable -n allowGlobalConfirmation\r\n\r\nDo you want to run the script?([Y]es/[N]o/[P]rint): Y")
    )

    var_0 = match(command)
    print("Test: ", var_0)
    assert var_0 == True


# Generated at 2022-06-26 05:42:09.334981
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = None
    var_0 = get_new_command(set_0)
    set_1 = None
    var_0 = get_new_command(set_1)

# Generated at 2022-06-26 05:42:10.478049
# Unit test for function get_new_command
def test_get_new_command():
    # var_0 get_new_command set_0
    test_case_0()

# Generated at 2022-06-26 05:42:16.879950
# Unit test for function get_new_command
def test_get_new_command():
    set_1 = None
    var_0 = get_new_command(set_1)
    assert var_0 == "choco install godot.install"
    set_2 = None
    var_0 = get_new_command(set_2)
    assert var_0 == "cinst vscode.install"
    set_3 = None
    var_0 = get_new_command(set_3)
    assert var_0 == "cinst vscode.install"
    set_4 = None
    var_0 = get_new_command(set_4)
    assert var_0 == "choco install godot.install"

# Generated at 2022-06-26 05:42:18.780414
# Unit test for function match
def test_match():
    set_0 = None
    var_0 = match(set_0)
    set_1 = None
    var_1 = match(set_1)

# Generated at 2022-06-26 05:42:19.840820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command == get_new_command


# Generated at 2022-06-26 05:42:28.982642
# Unit test for function get_new_command
def test_get_new_command():
    case_0 = None
    var_0 = get_new_command(case_0)
    assert var_0 == []

    case_1 = Script('choco install chocolatey', '', 1)
    var_1 = get_new_command(case_1)
    assert var_1 == ['choco install chocolatey.install']

    case_2 = Script('choco install chocolatey', '', 1)
    var_2 = get_new_command(case_2)
    assert var_2 == ['choco install chocolatey.install']

    case_3 = Script('cinst chocolatey', '', 1)
    var_3 = get_new_command(case_3)
    assert var_3 == ['cinst chocolatey.install']

    case_4 = Script('cinst chocolatey', '', 1)
    var_

# Generated at 2022-06-26 05:42:30.555039
# Unit test for function match
def test_match():
    assert match(set_0)
    # AssertionError: None


# Generated at 2022-06-26 05:44:48.953665
# Unit test for function get_new_command
def test_get_new_command():
    # Set 1
    set_1 = "cinst chocolatey"
    var_1 = get_new_command(set_1)
    assert var_1 == 'cinst chocolatey.install'
    # Set 2
    set_2 = "cinst -y chocolatey"
    var_2 = get_new_command(set_2)
    assert var_2 == 'cinst -y chocolatey.install'
    # Set 3
    set_3 = "cinst -y"
    var_3 = get_new_command(set_3)
    assert var_3 == "cinst -y"
    # Set 4
    set_4 = "cinst -y chocolatey"
    var_4 = get_new_command(set_4)
    assert var_4 == 'cinst -y chocolatey.install'
   

# Generated at 2022-06-26 05:44:50.713495
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)
    assert isinstance(get_new_command(set_0), str)
# Function to test match function

# Generated at 2022-06-26 05:44:57.986787
# Unit test for function match
def test_match():
    set_0 = None
    set_1 = None
    set_2 = None
    set_3 = None
    set_4 = None
    set_5 = None
    set_6 = None
    set_7 = None
    set_8 = None
    set_9 = None
    set_10 = None
    set_11 = None
    set_12 = None

    var_0 = match(set_0)
    var_1 = match(set_1)

# Generated at 2022-06-26 05:44:59.026917
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(set_0) == var_0


# Generated at 2022-06-26 05:45:04.156490
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("cinst someprog") == "cinst someprog.install"
    assert get_new_command("cinst -y someprog") == "cinst -y someprog.install"
    assert get_new_command("cinst someprog -y") == "cinst someprog.install -y"
    assert get_new_command("cinst someprog -source http://foo.com/") == "cinst someprog.install -source http://foo.com/"
    assert get_new_command("cinst someprog -source http://foo.com/ -y") == "cinst someprog.install -source http://foo.com/ -y"

# Generated at 2022-06-26 05:45:05.764904
# Unit test for function get_new_command
def test_get_new_command():
    assert True == get_new_command("choco install test")
    assert False == get_new_command("cinst test")


# Generated at 2022-06-26 05:45:13.938577
# Unit test for function match
def test_match():
    var_0 = None
    set_0 = """Installing the following packages:
cinst
By installing you accept licenses for the packages.
chocolatey 0.10.8

python 2.7"""
    var_1 = True
    var_2 = 'cinst'
    var_3 = [var_2]
    var_4 = (var_1, var_3)
    var_5 = enabled_by_default
    var_6 = (var_4, var_5)
    var_7 = 'cinst python 2.7'
    assert (var_0, set_0) == var_6



# Generated at 2022-06-26 05:45:17.670482
# Unit test for function match
def test_match():
    var_0 = None
    expected_0 = None
    actual_0 = match(var_0)
    assert actual_0 == expected_0


# Generated at 2022-06-26 05:45:20.412633
# Unit test for function match
def test_match():
    set_0 = Command(script="choco,install,fake_package",
                    output="Installing the following packages:")
    var_0 = match(set_0)
    assert var_0 == True
    
    

# Generated at 2022-06-26 05:45:24.346283
# Unit test for function match
def test_match():
    a = str('choco install')
    b = str('cinst')
    c = str('Installing the following packages')
    assert match(a,b,c)
