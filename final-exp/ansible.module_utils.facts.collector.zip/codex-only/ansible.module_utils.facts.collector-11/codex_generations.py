

# Generated at 2022-06-22 22:43:27.234938
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import defaultdict
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import systemd

    # create a simplified map of 'collector name' to 'collector class'
    all_fact_subsets = defaultdict(list)

    all_fact_subsets['distribution'].append(network.NetworkCollector)
    all_fact_subsets['distribution'].append(systemd.SystemdCollector)

    all_fact_subsets['all'].append(network.NetworkCollector)
    all_fact_subsets['all'].append(systemd.SystemdCollector)

    # test that collectors exist in the map
    assert network.NetworkCollector in all_fact_subsets['distribution']
    assert systemd.System

# Generated at 2022-06-22 22:43:33.258678
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'all': ['a', 'b', 'c'], 'd': ['d', 'e'],
                        'x': ['x', 'y'], 'y': ['y', 'z']}
    assert set(resolve_requires(['a', 'x', 'd'], all_fact_subsets)) == set(['a', 'x', 'd', 'e'])
    assert set(resolve_requires(['a', 'x', 'z'], all_fact_subsets)) == set(['a', 'x', 'y', 'z'])



# Generated at 2022-06-22 22:43:36.710310
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    bfc = BaseFactCollector()
    collected_facts = {'distribution':'debian'}
    assert bfc.collect_with_namespace(collected_facts) == {'distribution':'debian'}



# Generated at 2022-06-22 22:43:45.329520
# Unit test for function build_dep_data
def test_build_dep_data():
    # build simple dep map:
    # test_collector_1 requires test_collector_2
    # test_collector_3 requires test_collector_3 and test_collector_2
    #
    # Should see:
    # dep_map = {
    #    'test_collector_1': {'test_collector_2'},
    #    'test_collector_2': set(),
    #    'test_collector_3': {'test_collector_2'}
    # }
    class TestCollector1(BaseFactCollector):
        name = 'test_collector_1'
        required_facts = ['test_collector_2']

    class TestCollector2(BaseFactCollector):
        name = 'test_collector_2'
        required_facts = []


# Generated at 2022-06-22 22:43:53.502902
# Unit test for function tsort
def test_tsort():
    data = {
        1: [],
        2: [],
        3: [],
        4: [1],
        5: [2],
        6: [4, 5],
        7: [2, 3],
        8: [6, 7],
        }
    sorted_list = tsort(data)
    expected = [
        (1, []),
        (2, []),
        (3, []),
        (4, [1]),
        (5, [2]),
        (6, [4, 5]),
        (7, [2, 3]),
        (8, [6, 7]),
        ]
    assert sorted_list == expected


# Generated at 2022-06-22 22:44:05.124906
# Unit test for function find_collectors_for_platform

# Generated at 2022-06-22 22:44:07.383133
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(1)
    except CollectorNotFoundError as e:
        assert str(e) == "1"



# Generated at 2022-06-22 22:44:09.417859
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # TODO/MAYBE: add tests for cases where namespace is not None
    pass



# Generated at 2022-06-22 22:44:13.503759
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bs = BaseFactCollector()
    assert bs.name is None
    assert bs.collectors == []
    assert bs.namespace is None

    bs = BaseFactCollector(None, None)
    assert bs.name is None
    assert bs.collectors == []
    assert bs.namespace is None



# Generated at 2022-06-22 22:44:15.492062
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps('test')
    assert str(exc) == 'test'


# Generated at 2022-06-22 22:44:18.184857
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('collector')
    except CollectorNotFoundError as e:
        assert 'collector' == e.message



# Generated at 2022-06-22 22:44:26.497897
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'foo'
        required_facts = {'bar'}

        def collect(self):
            return {}
    collector_names = ('foo',)
    all_fact_subsets = {'foo': (TestCollector,)}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert set(dep_map['foo']) == set(('bar',))



# Generated at 2022-06-22 22:44:28.536035
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    collected_facts = {}
    assert fc.collect(collected_facts) == {}



# Generated at 2022-06-22 22:44:38.527623
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class SomeCollector1(BaseFactCollector):
        _fact_ids = set(['_fact_ids'])
        name = 'some_collector1'
        _platform = 'some_platform1'
    class SomeCollector2(BaseFactCollector):
        _fact_ids = set(['_fact_ids'])
        name = 'some_collector2'
        _platform = 'some_platform2'
    class SomeCollector3(BaseFactCollector):
        _fact_ids = set(['_fact_ids'])
        name = 'some_collector3'
        _platform = 'some_platform1'
        required_facts = set(['some_collector2'])

    all_collector_classes = [SomeCollector1, SomeCollector2, SomeCollector3]

    test_platform_

# Generated at 2022-06-22 22:44:44.676946
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': object(), 'b': object()}
    new_names = resolve_requires(set(['a']), all_fact_subsets)
    assert new_names == set(['a'])

    with pytest.raises(UnresolvedFactDep):
        resolve_requires(set(['x']), all_fact_subsets)



# Generated at 2022-06-22 22:44:57.679195
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'redhat': [1, 2, 3],
        'aix_patch': [4, 5, 6],
        'lsb_release': [7, 8, 9],
    }
    assert resolve_requires(set(['redhat', 'aix_patch']), all_fact_subsets) == set(['redhat', 'aix_patch'])
    assert resolve_requires(set(['redhat', 'aix_patch', 'windows']), all_fact_subsets) == set(['redhat', 'aix_patch'])
    assert resolve_requires(set(['redhat', 'aix_patch', 'lsb_release']), all_fact_subsets) == set(['redhat', 'aix_patch', 'lsb_release'])



# Generated at 2022-06-22 22:45:06.762550
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    def assert_in(val, seq):
        assert val in seq, "%r not in %r" % (val, seq)

    def assert_not_in(val, seq):
        assert val not in seq, "%r in %r" % (val, seq)

    class FakeCollector(BaseFactCollector):
        _fact_ids = ['fake']
        name = 'fake'
        required_facts = set()

    class FakeCollector2(BaseFactCollector):
        _fact_ids = ['fake2']
        name = 'fake2'
        required_facts = {'fake'}

    assert_in(FakeCollector, collector_classes_from_gather_subset([FakeCollector], ['all']))

# Generated at 2022-06-22 22:45:10.627764
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    x = BaseFactCollector(None,None)
    x.collect_with_namespace()



# Generated at 2022-06-22 22:45:13.221296
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as e:
        pass


# Generated at 2022-06-22 22:45:25.064672
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class BaseCollector(BaseFactCollector):
        _fact_ids = ['a', 'b']
        name = 'base_fact'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class CollectorA(BaseCollector):
        _fact_ids = ['a']
        name = 'a_fact'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class CollectorB(BaseCollector):
        _fact_ids = ['b']
        name = 'b_fact'
        required_facts = set(['a', 'c'])

        def collect(self, module=None, collected_facts=None):
            return {}

    class CollectorC(BaseCollector):
        _fact

# Generated at 2022-06-22 22:45:34.269935
# Unit test for function tsort
def test_tsort():
    assert tsort({1: (2, 3), 2: (3, 4), 3: (4, 5)}) == [(1, (2, 3)), (3, (4, 5)), (2, (3, 4))]
    assert tsort({1: (2, 3)}) == [(1, (2, 3))]
    assert tsort({1: ()}) == [(1, ())]
    assert tsort({1: (2, 3), 2: (3, 4), 3: (4, 5), 5: (3,)}) == [(1, (2, 3)), (2, (3, 4)), (3, (4, 5)), (5, (3,))]


# Generated at 2022-06-22 22:45:44.955553
# Unit test for function resolve_requires
def test_resolve_requires():
    # initial test
    expected_result = set(['date_time', 'pkg_mgr'])
    all_fact_subsets = {
        'date_time': [],
        'pkg_mgr': [],
    }
    unresolved = ['date_time', 'pkg_mgr']
    result = resolve_requires(unresolved, all_fact_subsets)
    assert result == expected_result

    # second test
    expected_result = set(['date_time', 'namespace'])
    unresolved = ['date_time', 'namespace']
    all_fact_subsets = {
        'date_time': [],
        'namespace': [],
    }
    result = resolve_requires(unresolved, all_fact_subsets)
    assert result == expected_result

    # test raising of exceptions


# Generated at 2022-06-22 22:45:56.651283
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = {
        'hardware': frozenset(['devices', 'dmi'])
    }
    if get_collector_names(gather_subset=['all'],
                           valid_subsets=frozenset(['all', 'hardware', 'devices', 'dmi']),
                           aliases_map=aliases_map,
                           minimal_gather_subset=frozenset(['all'])) != frozenset(['all']):
        raise AssertionError("test failed")

# Generated at 2022-06-22 22:46:03.559923
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['hardware'], {'hardware': [FakeCollector('hardware')]}) == {'hardware': set()}
    assert build_dep_data(['hardware'], {'hardware': [FakeCollector('hardware', ['network'])]}) == {'hardware': {'network'}}
    assert build_dep_data(['hardware', 'network', 'package'], {'hardware': [FakeCollector('hardware', ['network'])], 'network': [FakeCollector('network', ['package'])]}) == {'hardware': {'network'}, 'network': {'package'}, 'package': set()}



# Generated at 2022-06-22 22:46:05.910816
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert True
# ############# BaseFactCollector ###############


# ############# ANSIBULLFACTCOLLECTOR ###############


# Generated at 2022-06-22 22:46:13.187057
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    pass

    # trivial test case:
    # test default return value of collect()
    # fact_collector = BaseFactCollector()
    # result = fact_collector.collect()
    # assert len(result) == 0

    # test default return value (with a different namespace object)
    # namespace = facts.default_namespace()
    # fact_collector = BaseFactCollector(namespace=namespace)
    # result = fact_collector.collect()
    # assert len(result) == 0



# Generated at 2022-06-22 22:46:19.636651
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector():
        _fact_ids = set()
        name = 'blah'

    class Collector2():
        _fact_ids = set(['a', 'b'])
        name = 'blah2'

    result = build_fact_id_to_collector_map([Collector, Collector2])

    assert result[0] == {'blah': [Collector], 'a': [Collector2], 'b': [Collector2], 'blah2': [Collector2]}
    assert result[1] == {'blah': set(), 'blah2': set(['a', 'b'])}



# Generated at 2022-06-22 22:46:20.777118
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('hello')
    assert str(e) == 'hello'


# Generated at 2022-06-22 22:46:21.420765
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('test')



# Generated at 2022-06-22 22:46:23.869930
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('bar')
    except CollectorNotFoundError as err:
        assert str(err) == "bar"
# End of unit test for constructor of class CollectorNotFoundError



# Generated at 2022-06-22 22:46:27.152118
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Test CycleFoundInFactDeps constructor'''
    err = CycleFoundInFactDeps('foo')
    assert err.args == ('foo',)
# end test_CycleFoundInFactDeps



# Generated at 2022-06-22 22:46:30.220769
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    class Foo(BaseFactCollector):
        name = 'foo'
        required_facts = set()

    f = Foo()
    assert f.collect_with_namespace() == {}





# Generated at 2022-06-22 22:46:33.538185
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("foo")
    except CollectorNotFoundError as e:
        assert e.args[0] == "foo"



# Generated at 2022-06-22 22:46:43.520026
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    tfact = TestCollector()

    collected_facts = tfact.collect_with_namespace()
    assert collected_facts == {'foo': 'bar'}

    collected_facts = tfact.collect_with_namespace(module=True)
    assert collected_facts == {'foo': 'bar'}

    collected_facts = tfact.collect_with_namespace(collected_facts={'boo': 'far'})
    assert collected_facts == {'foo': 'bar'}

    collected_facts = tfact.collect_with_namespace(module=True, collected_facts={'boo': 'far'})

# Generated at 2022-06-22 22:46:46.188594
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''
    Unit test that ensures that we can define a CollectorNotFoundError
    '''
    err = CollectorNotFoundError('Key')
    assert repr(err) == "CollectorNotFoundError('Key')"



# Generated at 2022-06-22 22:46:57.674564
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector(BaseFactCollector):
        name = "fake_collector"
        _fact_ids = {'fake_collected_fact'}
        _platform = "Fake"

    fake_collector = FakeCollector()

    # Test for the case of no matching platform
    with pytest.raises(CollectorNotFoundError):
        find_collectors_for_platform(
            {fake_collector},
            [
                {'system': 'NotFake', 'release': '1.0'},
                {'system': 'NotFake', 'release': '1.1'}
            ]
        )

    # Test for the case of one matching platform
   

# Generated at 2022-06-22 22:47:01.047779
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('minimal', 'interfaces', 'routes', 'all', 'redhat'),
                               gather_subset=['!minimal', 'redhat'],
                               minimal_gather_subset=('minimal',),
                               aliases_map=defaultdict(set, hardware=['devices', 'dmi']),
                               platform_info={'system': 'Linux'}) == {'redhat', 'interfaces', 'routes'}



# Generated at 2022-06-22 22:47:11.938231
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = ['C', 'D']

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = ['C', 'E', 'F']

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = ['G']

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = ['G', 'H']

    collector_objects = [
        CollectorA,
        CollectorB,
        CollectorC,
        CollectorD,
    ]

    requested_facts = ['A', 'B']


# Generated at 2022-06-22 22:47:16.660203
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class test_class(BaseFactCollector):
        name = 'TEST_CLASS'
        def collect(self, module=None, collected_facts=None):
            return collected_facts
    obj = test_class()
    #obj.collect_with_namespace()



# Generated at 2022-06-22 22:47:28.145303
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import TimedGarbageCollectionFactCollector
    from ansible.module_utils.facts import DistroFactCollector
    from ansible.module_utils.facts import PathsFactCollector
    from ansible.module_utils.facts import TimezoneFactCollector
    from ansible.module_utils.facts import UsersFactCollector
    from ansible.module_utils.facts import LocalUsersFactCollector
    from ansible.module_utils.facts import VirtualFactCollector
    from ansible.module_utils.facts import LocalIpFactCollector
    from ansible.module_utils.facts import LocalInterfacesFactCollector
    from ansible.module_utils.facts import HardwareFactCollector
    from ansible.module_utils.facts import DMIHardwareFactCollector

# Generated at 2022-06-22 22:47:40.919788
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class FakeCollector(BaseFactCollector):
        _fact_ids = ['test_1', 'test_2']

    class FakeCollector2(BaseFactCollector):
        _fact_ids = ['test_3', 'test_4']

    all_collector_classes = [FakeCollector, FakeCollector2]

    selected_collector_classes = collector_classes_from_gather_subset(all_collector_classes=all_collector_classes,
                                                                      valid_subsets=frozenset(('test_1', 'test_2', 'test_3', 'test_4')),
                                                                      minimal_gather_subset=frozenset(('test_1',)),
                                                                      gather_subset=['test_1'])


# Generated at 2022-06-22 22:47:48.584108
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fact_collector = BaseFactCollector()
    assert fact_collector.name is None
    assert fact_collector.required_facts == set()
    assert fact_collector.fact_ids == set([None])
    assert fact_collector.collectors == []
    assert fact_collector.namespace is None
    assert fact_collector._transforms_dict_keys('testing') is None
test_BaseFactCollector()


# Unit tests for method 'collect_with_namespace'

# Generated at 2022-06-22 22:47:57.738634
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test that if multiple collectors with the same name,
    # only the first is selected
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        name = 'collector1'
    # Test that if multiple collectors with the same name,
    # and one is excluded, don't select the excluded one
    class Collector3(BaseFactCollector):
        name = 'collector3'
    class Collector4(BaseFactCollector):
        name = 'collector3'
    # Test that all selected
    class Collector5(BaseFactCollector):
        name = 'collector5'
    # Test that collectors from a single set are selected
    class Collector6(BaseFactCollector):
        name = 'collector6'

# Generated at 2022-06-22 22:48:10.642283
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # test case where there are no collectors
    all_fact_subsets = defaultdict(list)
    assert select_collector_classes(['fake'], all_fact_subsets) == []

    # test case where there is one collector
    all_fact_subsets['fake'].append(BaseFactCollector)
    assert select_collector_classes(['fake'], all_fact_subsets) == [BaseFactCollector]

    # test case where there is two collectors
    class Fake2Collector(BaseFactCollector):
        name = 'fake2'
    all_fact_subsets['fake2'].append(Fake2Collector)
    assert set(select_collector_classes(['fake'], all_fact_subsets)) == set([BaseFactCollector])

# Generated at 2022-06-22 22:48:14.740087
# Unit test for function build_dep_data
def test_build_dep_data():
    # input
    collector_names = ['ansible_os_family']
    #mock
    class collector:
        required_facts = []
    all_fact_subsets = {'ansible_os_family':[collector()]}
    # test
    assert build_dep_data(collector_names,all_fact_subsets) == defaultdict(set, {'ansible_os_family': set()})


# Generated at 2022-06-22 22:48:17.703423
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with raises(UnresolvedFactDep):
        raise UnresolvedFactDep('foo')


# Generated at 2022-06-22 22:48:28.470018
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # test gather_subset 'all', 'min'
    assert collector_classes_from_gather_subset(gather_subset=['all']) == []
    assert collector_classes_from_gather_subset(gather_subset=['min']) == []

    # test gather_subset '!all', 'network'
    assert collector_classes_from_gather_subset(gather_subset=['!all', 'network']) == []

    # test gather_subset '!all', 'network', '!network'
    with pytest.raises(TypeError) as excinfo:
        collector_classes_from_gather_subset(gather_subset=['!all', 'network', '!network'])
    assert 'Bad subset' in str(excinfo.value)

# Generated at 2022-06-22 22:48:40.123909
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.system.linux
    import ansible.module_utils.facts.system.freebsd
    import ansible.module_utils.facts.system.darwin
    import ansible.module_utils.facts.system.generic
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.hardware


# Generated at 2022-06-22 22:48:51.579307
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.platform.posix import PlatformPosixCollector
    from ansible.module_utils.facts.collector.platform.bsd import PlatformBsdCollector
    # Prepare compatibility platform
    compat_platform = {
        'system': 'Darwin'
    }
    # Prepare all collectors
    all_collector_classes = [PlatformPosixCollector,
                             PlatformBsdCollector]
    # Perform testing
    found_collectors = find_collectors_for_platform(all_collector_classes, (compat_platform,))
    assert len(found_collectors) == 1
    assert found_collectors[0] is PlatformBsdCollector
    # Cleanup
    del all_collector_classes
    del compat_platform
    del found_collectors


# Generated at 2022-06-22 22:48:54.311050
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    u = UnresolvedFactDep('foo', ['bar'])
    assert str(u) == "Unresolved dependency 'foo' for facts ['bar']"


# Generated at 2022-06-22 22:49:02.973732
# Unit test for function get_collector_names
def test_get_collector_names():
    # Include all collectors
    ret = get_collector_names()
    assert ret

    # Include all collectors, explicitly
    ret = get_collector_names(gather_subset=['all'])
    assert ret

    # Include all collectors, except 'network' alias
    ret = get_collector_names(gather_subset=['!network'])
    assert ret
    assert 'network' not in ret
    assert 'devices' not in ret

    # Include all collectors, except 'network' alias, explicitly
    ret = get_collector_names(gather_subset=['!network', 'network'])
    assert ret
    assert 'network' not in ret
    assert 'devices' not in ret

    # Include all collectors, except 'network' alias and all negative subsets

# Generated at 2022-06-22 22:49:13.597788
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi'])
    aliases_map['network'].update(['interfaces'])

    assert get_collector_names(
        valid_subsets=frozenset(['hardware', 'interfaces']),
        minimal_gather_subset=frozenset(['hardware', 'interfaces']),
        aliases_map=aliases_map) == frozenset(['hardware', 'interfaces'])


# Generated at 2022-06-22 22:49:16.194052
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    err = UnresolvedFactDep(['first_message', 'second_message'])
    assert err.args == ('first_message', 'second_message')



# Generated at 2022-06-22 22:49:17.572900
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps()
    assert e.args == ()



# Generated at 2022-06-22 22:49:21.159793
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    '''Verifies that UnresolvedFactDep is constructed as expected'''
    ufd = UnresolvedFactDep('a', 'b', 'c')
    assert "UnresolvedFactDep('c', 'a', 'b')" == repr(ufd)
    assert "c fact collector has an unresolved dependency on a fact collector b." == str(ufd)


# Generated at 2022-06-22 22:49:33.650037
# Unit test for function resolve_requires
def test_resolve_requires():
    # build baseline all_fact_subsets to test against
    all_fact_subsets = {}
    all_fact_subsets['foo'] = [object(), object()]
    all_fact_subsets['bar'] = [object()]
    all_fact_subsets['baz'] = [object(), object(), object()]

    # test with a combination of names that can be resolved
    unresolved_requires = set(['foo', 'baz', 'bar'])
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == unresolved_requires

    # test with a name that can't be resolved
    unresolved_requires = set(['foo', 'bar', 'zot'])

# Generated at 2022-06-22 22:49:37.285003
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    '''Unit test for constructor of class BaseFactCollector'''
    class Collector(BaseFactCollector):
        name = 'test_collector'

    collector = Collector(collectors=[])
    assert collector.name is not None



# Generated at 2022-06-22 22:49:47.244377
# Unit test for function resolve_requires
def test_resolve_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = {'B'}
    class B(BaseFactCollector):
        name = 'B'
        required_facts = {'C'}
    class C(BaseFactCollector):
        name = 'C'
        required_facts = {}
    class D(BaseFactCollector):
        name = 'D'
        required_facts = {'C'}
    class E(BaseFactCollector):
        name = 'E'
        required_facts = {}

    all_fact_subsets = {
        'A': [A],
        'B': [B],
        'C': [C],
        'D': [D],
        'E': [E]
    }


# Generated at 2022-06-22 22:49:57.133095
# Unit test for function build_dep_data
def test_build_dep_data():
    class TestCollector(BaseFactCollector):
        name = 'something'
        required_facts = set(('req1', 'req2'))
    class TestCollector2(TestCollector):
        pass
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['something'].append(TestCollector)
    all_fact_subsets['something'].append(TestCollector2)
    all_fact_subsets['req1'].append(TestCollector)
    all_fact_subsets['req2'].append(TestCollector)
    assert build_dep_data(('something',), all_fact_subsets) == {'something': {'req1', 'req2'}}



# Generated at 2022-06-22 22:50:06.447232
# Unit test for function tsort
def test_tsort():
    """Test tsort function

    There are four tests in this function:

    - test_empty_dep_map:
      Checks if tsort returns empty list when given empty dep_map.
    - test_single_node_dep_map:
      Checks if tsort returns a single node dep_map (e.g. dep_map = {'node': []}) properly
    - test_acyclic_dep_map:
      Checks if tsort returns an acyclic dep_map properly
    - test_cyclic_dep_map:
      Checks if tsort throws CycleFoundError when given cyclic dep_map
    """
    def test_empty_dep_map():
        dep_map = {}
        assert tsort(dep_map) == []


# Generated at 2022-06-22 22:50:11.785696
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Start with a class that matches with everything
    class PlatformMatch1(BaseFactCollector):
        _platform = 'Generic'
        name = 'match_all'
    class PlatformMatch2(BaseFactCollector):
        _platform = 'Linux'
        name = 'match_linux'
    class PlatformMatch3(BaseFactCollector):
        _platform = 'Darwin'
        name = 'match_darwin'

    # Test matching with collect everyone
    compat_plats = [
        {'system': 'Generic'},
        {'system': 'Linux'},
        {'system': 'Darwin'},
        {'system': 'FreeBSD'},
    ]

    all_collector_classes = [PlatformMatch1, PlatformMatch2, PlatformMatch3]

# Generated at 2022-06-22 22:50:21.866538
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # returns all hardware info
    hardware_collectors = collector_classes_from_gather_subset(gather_subset='hardware')
    # returns all the facts
    all_collectors = collector_classes_from_gather_subset(gather_subset='all')

    # returns just the network facts
    network_collectors = collector_classes_from_gather_subset(gather_subset=['network'])

    # returns the network facts and facts from all the hardware related collectors
    network_and_hardware = collector_classes_from_gather_subset(gather_subset=['network', 'hardware'])

    # returns the network facts and facts from all the hardware related collectors,
    # but not the other info included in 'all'
    network_and_hardware = collector_classes_from_

# Generated at 2022-06-22 22:50:25.709299
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector_name = 'fred'
    err = CollectorNotFoundError(collector_name)
    assert str(err) == "No collector '%s' found" % collector_name
# End unit test for constructor of class CollectorNotFoundError



# Generated at 2022-06-22 22:50:31.541496
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    f = BaseFactCollector()
    assert f.collectors == []
    assert f.namespace is None
    assert f.fact_ids == set([f.name])
    assert f.fact_ids == set(['GenericCollector'])

    f = BaseFactCollector(namespace=dict(transform=lambda x: x))
    assert f.namespace is not None
    assert f.namespace.transform('a') == 'a'
    assert f.collect() == {}



# Generated at 2022-06-22 22:50:43.910173
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import pci_collector
    from ansible.module_utils.facts import selinux_collector
    from ansible.module_utils.facts import virtual_collector

    def _get_all_collector_classes():
        return [
            ansible_collector.AnsibleCollector,
            pci_collector.PCICollector,
            selinux_collector.SELinuxCollector,
            virtual_collector.VirtualCollector
        ]

    test_dir = tempfile.mkdtemp()

    # Use the AnsibleCollector because it has a platform match

# Generated at 2022-06-22 22:50:47.944371
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("collector")
    except CollectorNotFoundError as e:
        assert "collector not found" in str(e)
        assert "collector" in str(e)



# Generated at 2022-06-22 22:50:49.288925
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    assert True is True



# Generated at 2022-06-22 22:51:01.565560
# Unit test for function get_collector_names
def test_get_collector_names():
    # result is a set, order is not important
    # Tests that "!hardware" excludes all FactCollectors in 'hardware'
    # and "!hardware,network" excludes all FactCollectors in 'hardware' and excludes
    # all FactCollectors in 'network', even though 'hardware' is an alias for 'devices'
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['network', 'all']),
        aliases_map=defaultdict(set, hardware=set(['devices'])),
        gather_subset=['!hardware']) == frozenset(['network'])


# Generated at 2022-06-22 22:51:09.623305
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'cc1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'cc2'
        required_facts = set(['cc1'])

    class TestCollector3(BaseFactCollector):
        name = 'cc3'
        required_facts = set(['cc1'])

    class TestCollector4(BaseFactCollector):
        name = 'cc4'
        required_facts = set(['cc3'])

    class TestCollector5(BaseFactCollector):
        name = 'cc5'
        required_facts = set(['cc2', 'cc4', 'cc6'])

    class TestCollector6(BaseFactCollector):
        name = 'cc6'

# Generated at 2022-06-22 22:51:11.799593
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps("message")
    assert err.args[0] == "message"



# Generated at 2022-06-22 22:51:22.574616
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils._text import to_bytes, to_text
    class TestCollector1(BaseFactCollector):
        name = 'test1'

        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test1'])
        _platform = 'Generic'

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test1'])
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test2', 'test3'])
        _platform = 'Generic'


# Generated at 2022-06-22 22:51:28.292142
# Unit test for function tsort
def test_tsort():
    unsorted_map = {
        'a': {'d'},
        'b': {'d'},
        'c': {'b'},
        'd': {'e'},
        'e': set()
    }

    expected = [
        ('a', {'d'}),
        ('b', {'d'}),
        ('c', {'b'}),
        ('d', {'e'}),
        ('e', set())
    ]
    assert tsort(unsorted_map) == expected



# Generated at 2022-06-22 22:51:35.741745
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes([], {}) == []
    assert select_collector_classes(['a'], {'a': [1]}) == [1]
    assert select_collector_classes(['a'], {'a': [1, 2]}) == [1, 2]
    assert select_collector_classes(['a'], {'a': [1, 1]}) == [1]
    assert select_collector_classes(['a', 'a'], {'a': [1]}) == [1]
    assert select_collector_classes(['a', 'b'], {'a': [1], 'b': [2]}) == [1, 2]

# Generated at 2022-06-22 22:51:39.001382
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError("key", "message")
    assert c.args == ('key', 'message')
    assert c.key == 'key'
    assert c.message == 'message'



# Generated at 2022-06-22 22:51:47.203963
# Unit test for function tsort
def test_tsort():
    import pytest
    dep_map = {'a': set(['b', 'c']), 'b': set([]), 'c': set(['b']), 'd': set(['b', 'c', 'd'])}
    sorted = tsort(dep_map)
    assert sorted == [('b', set([])), ('c', set(['b'])), ('a', set(['b', 'c']))]
    filtered = [x for x in sorted if x[0] not in ['b', 'c']]
    assert filtered == [('a', set(['b', 'c']))]



# Generated at 2022-06-22 22:51:56.830846
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test_collector1'
        _fact_ids = ['test_id1', 'test_id2']

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = ['test_id2', 'test_id3']

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _fact_ids = ['test_id3', 'test_id4']

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'
        _fact_ids = ['test_id4', 'test_id5']


# Generated at 2022-06-22 22:51:59.645148
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    # Act
    err = CollectorNotFoundError("collector_name")

    # Assert
    assert "collector_name" in err.args[0]



# Generated at 2022-06-22 22:52:09.711369
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # test with no collected fact
    ff = BaseFactCollector()
    fact_dict = ff.collect()
    assert isinstance(fact_dict, dict)
    assert len(fact_dict) == 0

    # test with collected fact
    fact_dict = {'foo': 'bar'}
    ff = BaseFactCollector()
    new_dict = ff.collect(collected_facts=fact_dict)
    assert isinstance(fact_dict, dict)
    assert len(fact_dict) == 1
    assert fact_dict == {'foo': 'bar'}
    assert new_dict == {}



# Generated at 2022-06-22 22:52:11.816632
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exception = CycleFoundInFactDeps()
    assert isinstance(exception, CycleFoundInFactDeps)



# Generated at 2022-06-22 22:52:19.681117
# Unit test for function tsort
def test_tsort():
    test_graph_input = {
        'A': set(['B']),
        'B': set(['C', 'D']),
        'C': set(['D']),
        'E': set()
    }

    test_graph_output = [
        ('E', set()),
        ('D', set()),
        ('C', set(['D'])),
        ('B', set(['C', 'D'])),
        ('A', set(['B']))
    ]

    assert tsort(test_graph_input) == test_graph_output
# Unit test function tsort



# Generated at 2022-06-22 22:52:23.096468
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    '''Verify that UnresolvedFactDep is a subclass of ValueError'''

    # Verify that UnresolvedFactDep is a subclass of ValueError
    assert issubclass(UnresolvedFactDep, ValueError)


# Generated at 2022-06-22 22:52:29.822812
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts import collector

    class CustomCollector(BaseFactCollector):
        name = 'custom_collector'

    collectors = [CustomCollector()]
    fact_collector = collector.get_collector(collectors=collectors)
    fact_collector.collect()
    assert fact_collector.collected_facts['custom_collector'] == {}


# Generated at 2022-06-22 22:52:37.413451
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c', 'd', 'e']
    all_fact_subsets = {'a': [], 'b':[], 'c':[], 'd':[], 'e':[]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set(), 'd': set(), 'e': set()}
    # create some deps
    all_fact_subsets['a'] = [object(), object()]
    all_fact_subsets['b'] = [object()]
    all_fact_subsets['d'] = [object()]
    for collector in all_fact_subsets['a']:
        collector.required_facts = ['d']

# Generated at 2022-06-22 22:52:45.521228
# Unit test for function get_collector_names
def test_get_collector_names():
    res = get_collector_names(valid_subsets=frozenset(('min', 'all', 'a', 'b', 'c')),
                              minimal_gather_subset=frozenset(('min',)),
                              gather_subset=['b', '!c'])
    assert(res == frozenset(['min', 'a', 'b'])), 'Expected "min", "a", "b". Got %s' % res

    res = get_collector_names(valid_subsets=frozenset(('min', 'all', 'a', 'b', 'c')),
                              minimal_gather_subset=frozenset(('min',)),
                              gather_subset=['b', '!c', 'a'])

# Generated at 2022-06-22 22:52:55.098155
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible_collections.community.general.plugins.module_utils.facts.collectors
    all_collector_classes = ansible_collections.community.general.plugins.module_utils.facts.collectors.collectors.values()
    # Test for all linux platforms(linux, linux2)
    for compat_platform in ('linux', 'linux2'):
        found_collectors = find_collectors_for_platform(all_collector_classes, (compat_platform,))
        assert found_collectors
    # Test for unsupported platform
    found_collectors = find_collectors_for_platform(all_collector_classes, ('unsupported_os',))
    assert not found_collectors



# Generated at 2022-06-22 22:53:02.353872
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    o = BaseFactCollector()
    collected_facts = {}
    facts_dict = o.collect(collected_facts=collected_facts)
    module_mock = {'params': {}}

    # Test the return value and that collected_facts isn't modified
    assert facts_dict == {}
    assert collected_facts == {}

    # Test that we can pass in a module
    o.collect(module=module_mock, collected_facts=collected_facts)



# Generated at 2022-06-22 22:53:14.000816
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test with collector names having no dependency
    assert set(select_collector_classes(['parser', 'network'],
                                        {'parser': [type('parser', (object,), {})()],
                                         'network': [type('network', (object,), {})()]}
                                        )
               ) == set([type('parser', (object,), {})(), type('network', (object,), {})()])

    # Test with collector names with no dependency (reverse order)

# Generated at 2022-06-22 22:53:23.423313
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    # Test cases for validating the dep_map
    # When a collector is added, the name of the collector should be added to the key in dep_map
    # #
    # The value for the key should be a set of dependencies that the collector depends on.
    dep_map['name1'] = {'dep1', 'dep2', 'dep3'}
    dep_map['name2'] = {'dep4', 'dep5'}

    assert dep_map['name1'] == {'dep1', 'dep2', 'dep3'}
    assert dep_map['name2'] == {'dep4', 'dep5'}
    return True

