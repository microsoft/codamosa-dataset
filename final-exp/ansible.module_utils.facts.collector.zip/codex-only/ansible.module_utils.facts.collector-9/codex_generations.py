

# Generated at 2022-06-22 22:43:27.381732
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import textwrap
    # Test output of function build_fact_id_to_collector_map
    # Only testing part of the output
    expected_output = textwrap.dedent("""\
    {'system': [<class 'ansible.module_utils.facts.system.collectors.Linux.Linux'>,
                <class 'ansible.module_utils.facts.system.collectors.posix.posix']>],
     'distribution': [<class 'ansible.module_utils.facts.system.collectors.Linux.Linux'>, <class 'ansible.module_utils.facts.system.collectors.posix.posix']>],
     'manufacturer': [<class 'ansible.module_utils.facts.system.collectors.posix.posix'>]}""")

    collector_classes = frozenset

# Generated at 2022-06-22 22:43:28.871956
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test')
    assert 'test' in str(e)


# Generated at 2022-06-22 22:43:39.415497
# Unit test for function get_collector_names
def test_get_collector_names():
    from ansible.module_utils.facts.network.base import NetworkCollector, NetworkLegacyFactCollector, NetworkInterfaceFactCollector

    # Test with defaults
    actual = get_collector_names()
    assert actual == get_collector_names(NetworkCollector.valid_subsets, NetworkCollector.minimal_gather_subset, ['all']), actual

    # Test with a valid subset
    actual = get_collector_names(gather_subset=['network'])
    assert actual == get_collector_names(NetworkCollector.valid_subsets, NetworkCollector.minimal_gather_subset, ['network']), actual

    # Test with an invalid subset

# Generated at 2022-06-22 22:43:47.308718
# Unit test for function get_collector_names
def test_get_collector_names():
    # Make a minimal set of facts and aliases to simulate
    # a non-trivial set of facts and aliases
    # Not all of these aliases and fact collectors exist,
    # but we're trying to make a test case that would prove
    # that the get_collector_names() correctly handles
    # various cases of gather_subset and aliases
    valid_subsets = frozenset(['all', 'network', 'hardware', 'storage', 'virtual',
                               'identity', 'system', 'facter', 'ohai', 'puppet',
                               'custom', 'augeas', 'images', 'dmi'])
    minimal_gather_subsets = frozenset(['all', 'network', 'hardware', 'storage',
                                        'virtual', 'identity', 'system',
                                        'images', 'dmi'])

# Generated at 2022-06-22 22:43:53.059887
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'] = ['FakeCollectorA', 'FakeCollectorB']
    all_fact_subsets['b'] = ['FakeCollectorC']
    all_fact_subsets['c'] = ['FakeCollectorD']
    all_fact_subsets['d'] = ['FakeCollectorE']
    all_fact_subsets['e'] = ['FakeCollectorF']

    class FakeCollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['c'])
    class FakeCollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['e'])
    class FakeCollectorC(BaseFactCollector):
        name = 'c'

# Generated at 2022-06-22 22:44:01.094888
# Unit test for function build_dep_data
def test_build_dep_data():
    from copy import copy
    from collections import defaultdict
    collector_names = {'foo', 'bar'}
    all_fact_subsets = defaultdict(set)
    class Foo:
        def __init__(self):
            self.required_facts = {'baz'}
    class Bar:
        def __init__(self):
            self.required_facts = {'baz'}
    all_fact_subsets['foo'].add(Foo())
    all_fact_subsets['bar'].add(Bar())
    assert(build_dep_data(collector_names, all_fact_subsets) == {'bar': set(['baz']), 'foo': set(['baz'])})
    collector_names = {'foo', 'bar'}
    all_fact_subsets = defaultdict

# Generated at 2022-06-22 22:44:03.273431
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    Fails, but appears to be due to a different function
    '''
    pass



# Generated at 2022-06-22 22:44:14.432411
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class DummyCollector(BaseFactCollector):
        _fact_ids = set(['cache', 'pci'])
        name = 'dummy'

    class AnotherDummy(BaseFactCollector):
        _fact_ids = set(['another_dummy'])
        name = 'another_dummy'

    all_collectors = [DummyCollector, AnotherDummy]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors)
    assert len(fact_id_to_collector_map) == 5
    assert 'cache' in fact_id_to_collector_map
    assert 'pci' in fact_id_to_collector_map
    assert 'another_dummy' in fact_id_to_collector_

# Generated at 2022-06-22 22:44:16.961268
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps()
    assert err.args == ()



# Generated at 2022-06-22 22:44:19.280123
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    module = None
    collected_facts = None
    assert obj.collect(module, collected_facts) == {}



# Generated at 2022-06-22 22:44:26.191988
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from namespaces import Prefix
    from collections import defaultdict
    from ansible.module_utils.facts import get_collector_class

    class ArchCollector(BaseFactCollector):
        fact_ids = ['hardware', 'architecture']

    class MyCollector(BaseFactCollector):
        name = 'my_collector'
        fact_ids = ['my_var']
        required_facts = ['hardware', 'architecture']

    class My2Collector(BaseFactCollector):
        name = 'my2_collector'
        fact_ids = ['my2_var']
        required_facts = ['hardware', 'architecture']

    ArchCollector.name = 'architecture'

    namespace = Prefix('prefixed_')

    prefix_architecture_collector = get_collector_class

# Generated at 2022-06-22 22:44:31.315320
# Unit test for function get_collector_names
def test_get_collector_names():
    # Tests:
    #  - reject invalid gather subset entries
    #  - aliases are expanded
    #  - 'all' is expanded
    #  - 'min' is expanded
    #  - positive and negative filters in the same gather subset
    #    are handled properly (both order and uniqueness)
    #  - subset names are not expanded when they follow a '!'

    # Set up some aliases
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(['devices', 'dmi'])
    aliases_map['system'] = frozenset(['distribution', 'osfamily'])

    # We do not use __file__ because this code runs in a different python process

# Generated at 2022-06-22 22:44:38.032974
# Unit test for function tsort
def test_tsort():
    class TestException(Exception):
        pass

    try:
        tsort({'a': {'b'}, 'b': {'c'}, 'c': {'a'}})
        raise TestException("expected CycleFoundInFactDeps")
    except CycleFoundInFactDeps:
        pass

    assert tsort({'a': {'b'}, 'b': {}, 'c': {}}) == [('b', set()), ('c', set()), ('a', {'b'})]



# Generated at 2022-06-22 22:44:48.742190
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import copy
    collectors_for_platform = [copy.copy(collector_class)
                               for collector_class
                               in FACT_COLLECTION_FUNCTIONS]
    for collector_class in collectors_for_platform:
        collector_class.platform_match = lambda x: collector_class

    result = build_fact_id_to_collector_map(collectors_for_platform)
    assert len(result) == 2
    id_to_collector_map, aliases_map = result

    # there should be a mapping for each collector name
    for collector_class in collectors_for_platform:
        assert collector_class in id_to_collector_map[collector_class.name]
        assert collector_class in id_to_collector_map[collector_class.name + '_2']

    #

# Generated at 2022-06-22 22:45:00.384200
# Unit test for function tsort
def test_tsort():
    """Assert that tsort properly sorts elements of a graph"""
    # trivial graph
    graph = {'a': set(), 'b': set(), 'c': set()}
    expected = [('a', set()), ('b', set()), ('c', set())]
    assert tsort(graph) == expected

    # single edge
    graph = {'a': {'b'}, 'b': set()}
    expected = [('b', set()), ('a', {'b'})]
    assert tsort(graph) == expected

    # diamond
    graph = {'a': {'b'}, 'b': {'c', 'd'}, 'c': set(), 'd': set()}

# Generated at 2022-06-22 22:45:10.496252
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(object):
        _fact_ids = set(['foo', 'bar'])
        name = 'baz'

    class Collector2(object):
        _fact_ids = set(['foo'])
        name = 'baz2'
    class Collector3(object):
        _fact_ids = set()
        name = 'baz3'

    class Collector4(object):
        _fact_ids = set(['baz4a', 'baz4b'])
        name = 'baz4'

    class Collector5(object):
        _fact_ids = set(['bar'])
        name = 'baz5'


# Generated at 2022-06-22 22:45:22.663205
# Unit test for function get_collector_names
def test_get_collector_names():
    class MockVarsModule:
        # gather_subset = ['all']
        # gather_subset = ['!all']
        # gather_subset = ['all', '!min']
        # gather_subset = ['!network']
        gather_subset = ['network', '!dns']
        gather_subset = ['network', '!dns']
        # gather_subset = ['all', '!network']

    valid_subsets = frozenset(['all', 'network', 'min', 'hardware', 'dns', 'devices', 'virtual'])

    minimal_gather_subsets = frozenset(['min'])


# Generated at 2022-06-22 22:45:31.768083
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'b'
        required_facts = set()
    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()

    a = A(namespace=None)
    assert a.fact_ids == set(['a'])
    assert a.collectors == []
    assert a.namespace == None

    b = B(collectors=[a])
    assert b.fact_ids == set(['a', 'b'])
    assert b.collectors == [a]
    assert b.namespace == None

    c = C(collectors=[a, b], namespace=None)

# Generated at 2022-06-22 22:45:43.791230
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    passed = True
    from ansible.module_utils.facts.my_test.my_test_ns1 import MyTestCollector1 as MyTestCollector1ns1
    from ansible.module_utils.facts.my_test.my_test_ns2 import MyTestCollector1 as MyTestCollector1ns2
    test_modules = {'platform': 'Generic', 'role': 'no_role'}
    c = MyTestCollector1ns1()

    facts = {'my_test_key1': 'my_test_key1_value'}
    test_1_1 = c.collect_with_namespace(module=test_modules, collected_facts=facts)
    # TODO: This should be a proper Mocking framework such as pytest-mock

# Generated at 2022-06-22 22:45:46.749099
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.name is None
    assert fc.required_facts == set()
    assert fc.fact_ids == set([None])


# Generated at 2022-06-22 22:45:51.882590
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.hardware import Hardware

    def get_fact_ids(cls):
        if not hasattr(cls, 'fact_ids'):
            return []
        return list(cls.fact_ids)

    def get_required_facts(cls):
        if not hasattr(cls, 'required_facts'):
            return []
        return list(cls.required_facts)

    def get_fact_ids_from_names(names):
        ids = set()
        for name in names:
            for cls in Hardware.__subclasses__():
                if hasattr(cls, 'name') and cls.name == name:
                    ids.update(get_fact_ids(cls))
        return ids

    # all posible hardware fact names
    all_

# Generated at 2022-06-22 22:45:55.135065
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collector = BaseFactCollector()
    result = collector.collect()
    assert result == {}, "Expected {}, got {}".format({}, result)



# Generated at 2022-06-22 22:46:02.297263
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        name = 'test_collector1'
        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _platform = 'Generic'

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _platform = 'Generic'

    # setup test data
    all_collector_classes = [TestCollector1, TestCollector2, TestCollector3]
    compat_platforms = [
        {'system': 'Linux'},
        {'system': 'Generic'}
    ]

    # find collectors for the platform
    result = find_collectors_for_platform(all_collector_classes, compat_platforms)

    # compare the results

# Generated at 2022-06-22 22:46:10.219212
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    ''' test for method collect_with_namespace of class BaseFactCollector '''
    from ansible.module_utils.facts.namespace import Namespace
    collector = BaseFactCollector(namespace=Namespace(prefix='test_'))
    facts = {'test_architecture': 'x86_64',
             'test_virtualization_role': 'guest',
             'test_virtualization_type': 'kvm'}

    assert collector.collect_with_namespace() == facts



# Generated at 2022-06-22 22:46:11.181697
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.facts import BaseFactCollector
    assert BaseFactCollector().collect() == {}

# Generated at 2022-06-22 22:46:22.053111
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['test', 'network', 'test2'])
    minimal_gather_subset = frozenset(['test2'])
    gather_subset = ['all']
    aliases_map = defaultdict(set)
    aliases_map['test'] = ['testlong']

    assert (get_collector_names(valid_subsets=valid_subsets,
                       minimal_gather_subset=minimal_gather_subset,
                       gather_subset=gather_subset,
                       aliases_map=aliases_map)) == {'network', 'test', 'test2'}

    gather_subset = ['!test2']

# Generated at 2022-06-22 22:46:28.500921
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['foo', 'bar'], {'foo': [], 'bar': []})
    assert dep_map == defaultdict(set, {'foo': set(), 'bar': set()})
    dep_map = build_dep_data(['foo'], {'foo': [MockFactCollector('foo', requires=['bar', 'baz'])]})
    assert dep_map == defaultdict(set, {'foo': set(['bar', 'baz'])})



# Generated at 2022-06-22 22:46:36.866296
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Empty all_collector_classes with empty platform_match should return empty set
    assert find_collectors_for_platform(set(), [None]) == set()

    # all_collector_classes with a mock class
    class MockCollector:
        @staticmethod
        def platform_match(platform_info):
            return None

    assert find_collectors_for_platform(set([MockCollector]), [None]) == set()

    # MockCollector matching with platform_info
    class MockCollector2:
        @staticmethod
        def platform_match(platform_info):
            return MockCollector2

    assert find_collectors_for_platform(set([MockCollector2]), [{'system': 'Generic'}]) == set([MockCollector2])



# Generated at 2022-06-22 22:46:42.434762
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with timeout.timeout(0.01):
        try:
            raise UnresolvedFactDep(1, 2)
        except UnresolvedFactDep as e:
            assert repr(e) == "UnresolvedFactDep(1, 2)"
            assert e.args == (1, 2)
            assert str(e) == "Fact collector 2 requires fact collector 1"



# Generated at 2022-06-22 22:46:46.365074
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts.collectors import all_collectors
    selected_collector_classes = collector_classes_from_gather_subset(all_collector_classes=all_collectors,
                                                                     valid_subsets=None,
                                                                     minimal_gather_subset=None,
                                                                     gather_subset=None,
                                                                     gather_timeout=None,
                                                                     platform_info=None)

    assert len(selected_collector_classes) > 0
    assert not find_unresolved_requires(all_collector_classes, all_collectors)
    assert not find_unresolved_requires(selected_collector_classes, all_collectors)



# Generated at 2022-06-22 22:46:51.157339
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep({'enabled_collectors': ['notset']})
    except UnresolvedFactDep as ex:
        assert isinstance(ex, ValueError)
        assert 'notset' in str(ex)



# Generated at 2022-06-22 22:47:01.898741
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # define BaseFactCollector subclass and register
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = name, 'a1'

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = name, 'b1'

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = name, 'c1'

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = ['a', 'b']
        _fact_ids = name, 'd1'

    # build all_fact_subsets for tests

# Generated at 2022-06-22 22:47:05.494014
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''Unit test for constructor of class CollectorNotFoundError

    Args:
        msg: exception message
    '''
    msg = "Collector for name 'foo' was not found"
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as ex:
        assert str(ex) == msg



# Generated at 2022-06-22 22:47:15.460434
# Unit test for function resolve_requires
def test_resolve_requires():
    fact_id_to_collector_map = {'a': [], 'b': [], 'c': []}
    if resolve_requires(['a', 'b'], fact_id_to_collector_map) != set(['a', 'b']):
        raise AssertionError("resolve_requires failed")

    if resolve_requires(['a', 'b', 'c', 'd'], fact_id_to_collector_map) != set(['a', 'b', 'c']):
        raise AssertionError("resolve_requires failed")

    try:
        resolve_requires(['a', 'b', 'd'], fact_id_to_collector_map)
        raise AssertionError("resolve_requires failed")
    except UnresolvedFactDep:
        pass

    return True



# Generated at 2022-06-22 22:47:19.277713
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    import pytest
    b = BaseFactCollector()
    assert b.platform_match({'system': 'Generic'})

    with pytest.raises(AttributeError):
        b.platform_match({'system': 'Linux'})


# Generated at 2022-06-22 22:47:30.169470
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.dmi

    platform_info = {'system': 'Linux', 'distribution': 'RedHat'}
    all_collector_classes = (ansible.module_utils.facts.collectors.base.BaseFactCollector,
                             ansible.module_utils.facts.collectors.system.SystemCollector,
                             ansible.module_utils.facts.collectors.dmi.DMICollector,
                             )
    compat_platforms = [platform_info]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

# Generated at 2022-06-22 22:47:42.183837
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # This is a reference to the AnsibleModule class defined in ansible.module_utils.basic
    # and is used to generate mock AnsibleModule instances in our unit tests
    class AnsibleModule():
        def __init__(self, **kwargs):
            self.params = kwargs['params']
            self.fail_json = kwargs['fail_json']

    # Create a mock AnsibleModule instance
    ansible_module = AnsibleModule(
        params={'gather_subset': 'all', 'gather_timeout': 30, 'gather_subset': 'all', 'filter': '*'},
        fail_json=({'msg': "Collector not found for 'name': 'test'"})
    )

    # Create a mock system_info dictionary that includes the platform
    # needed for the given all_collector

# Generated at 2022-06-22 22:47:48.291628
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        # On Python 3.6, exception parameters are automatically converted to
        # str() in the repr()
        raise CycleFoundInFactDeps(CycleFoundInFactDeps("teststring"))
    except Exception as e:
        assert repr(e) == "CycleFoundInFactDeps('CycleFoundInFactDeps(\\'teststring\\')')"



# Generated at 2022-06-22 22:47:57.500064
# Unit test for function select_collector_classes
def test_select_collector_classes():
    named_collector_classes = {
        'a': [1],
        'b': [2],
        'c': [3, 4],
    }

    test_cases = [
        ('case_1', ['a'], [1]),
        ('case_2', ['a', 'b'], [1, 2]),
        ('case_3', ['a', 'b', 'c'], [1, 2, 3, 4]),
        ('case_4', ['a', 'c'], [1, 3, 4]),
        ('case_4', ['c', 'a'], [3, 4, 1]),
        ('case_5', ['c'], [3, 4]),
    ]


# Generated at 2022-06-22 22:47:58.478173
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass

# Generated at 2022-06-22 22:48:02.287846
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError()
    except CollectorNotFoundError:
        pass

_FACT_COLLECTORS = []



# Generated at 2022-06-22 22:48:12.713535
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    stub_namespace = StubNamespace()
    stub_collectors = StubCollector()
    stub_collected_facts = StubCollectedFacts()
    stub_module = StubModule()
    base_fact_collector = BaseFactCollector(namespace=stub_namespace,
                                            collectors=stub_collectors)
    base_fact_collector.collect_with_namespace(module=stub_module,
                                               collected_facts=stub_collected_facts)
    assert stub_module.method_calls == ['BaseFactCollector.collect', 'BaseFactCollector._transform_dict_keys']
    assert stub_collectors.method_calls == ['BaseFactCollector.collect']
    assert stub_collected_facts.method_calls == ['BaseFactCollector.collect']
    assert stub

# Generated at 2022-06-22 22:48:25.358001
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('min', 'all', 'some1', 'some2'))
    minimal_gather_subset = 'min'

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=None) == frozenset(('min', 'some1', 'some2'))

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=['all']) == frozenset(('min', 'some1', 'some2'))


# Generated at 2022-06-22 22:48:37.821199
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    class TestCollector1(BaseFactCollector):
        _platform = 'test_platform_1'
        name = 'test1'
    class TestCollector2(BaseFactCollector):
        _platform = 'test_platform_2'
        name = 'test2'
    class TestCollector3(BaseFactCollector):
        _platform = 'test_platform_2'
        name = 'test3'
    class TestCollector4(BaseFactCollector):
        _platform = 'test_platform_3'
        name = 'test4'
    class TestCollector5(BaseFactCollector):
        _platform = 'test_platform_3'
        name = 'test5'

    class UnknownPlatform:
        def get(self, key, default=None):
            return default

    unknown_platform = Unknown

# Generated at 2022-06-22 22:48:40.121825
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector_not_found_error = CollectorNotFoundError()
    assert collector_not_found_error == KeyError()



# Generated at 2022-06-22 22:48:51.624403
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    class CollectorA(BaseNetworkCollector):
        name = 'collector_a'
        required_facts = set(('b', 'c'))
    class CollectorB(BaseNetworkCollector):
        name = 'collector_b'
        required_facts = set(('c'))
    from ansible.module_utils.facts import network
    all_collector_classes = (CollectorA, CollectorB)
    all_fact_subsets = network.build_fact_subsets(all_collector_classes)
    all_fact_subsets = {k: tuple(v) for k, v in all_fact_subsets.items()}

    collector_names = set(('collector_a', 'collector_b'))
    expected_dep

# Generated at 2022-06-22 22:48:54.714572
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Create a temporary instance for testing its method
    baseFactCollector = BaseFactCollector()

    # Call method collect() and verify it returns a dict
    assert(isinstance(baseFactCollector.collect(), dict))



# Generated at 2022-06-22 22:49:03.248273
# Unit test for function tsort
def test_tsort():

    # Acyclic, test sorting
    deps_map = {'x': {'y'},
                'y': {'z'},
                'z': {}}

    expected_result = [('z', set()), ('y', {'z'}), ('x', {'y'})]
    assert tsort(deps_map) == expected_result

    # Acyclic, test sorting
    deps_map = {'x': {'y'},
                'y': {'z'},
                'z': {'a'},
                'a': {'b'},
                'b': {}}

    expected_result = [('b', set()), ('a', {'b'}), ('z', {'a'}), ('y', {'z'}), ('x', {'y'})]


# Generated at 2022-06-22 22:49:10.425202
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge
    fc = BaseFactCollector()
    module = None
    collected_facts = dict()
    assert fc.collect(module, collected_facts) == {}
    collected_facts = dict(facts_dict=dict(key0='abc'))
    dict_merge(module, collected_facts)
    assert fc.collect(module, collected_facts) == {}



# Generated at 2022-06-22 22:49:16.945643
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
    BaseFactCollector._fact_ids.add('test_id')
    assert set(TestCollector.fact_ids) == set(['test_id', 'test_collector'])
    assert TestCollector.fact_ids == TestCollector._fact_ids.union(set(['test_collector']))



# Generated at 2022-06-22 22:49:24.714835
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['arch', 'domain', 'fqdn_ip4', 'fqdn_short', 'machine_id', 'os_family', 'os_name', 'os_version', 'uptime', 'virtualization', 'virtualization_role']
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['arch'].append(BaseFactCollector)
    all_fact_subsets['arch'].append(BaseFactCollector)
    all_fact_subsets['domain'].append(BaseFactCollector)
    all_fact_subsets['domain'].append(BaseFactCollector)
    all_fact_subsets['fqdn_ip4'].append(BaseFactCollector)
    all_fact_subsets['fqdn_ip4'].append(BaseFactCollector)


# Generated at 2022-06-22 22:49:25.695847
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector.__init__(BaseFactCollector, [], None) is None


# Generated at 2022-06-22 22:49:29.042276
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('This is a test error')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'This is a test error'



# Generated at 2022-06-22 22:49:39.586251
# Unit test for function tsort
def test_tsort():
    def test_cycle():
        # data from https://en.wikipedia.org/wiki/Topological_sorting#Depth-first_search
        # except that the cycle is reversed for effect
        d = {
            5: (11, 8),
            7: (11, 8),
            3: (8, 10),
            11: (2, 9, 10),
            8: (9,),
            2: (9,),
            9: (10,),
            10: (2, 3, 9),
        }
        tsort(d)

# Generated at 2022-06-22 22:49:48.492721
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class FakeCollector:
        platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors or []

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls.platform:
                return cls

    class FakeCollectorA(FakeCollector):
        platform = 'Generic'
        name = 'fake_a'
        required_facts = set()

    class FakeCollectorB(FakeCollector):
        platform = 'Generic'
        name = 'fake_b'
        required_facts = set()

    class FakeCollectorC(FakeCollector):
        platform = 'Generic'
        name = 'fake_c'
        required

# Generated at 2022-06-22 22:49:49.537963
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('CollectorNotFoundError')


# Generated at 2022-06-22 22:50:00.598776
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)

    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set()

    class CollectorX(BaseFactCollector):
        name = 'X'
        required_facts = set()

    class CollectorY(BaseFactCollector):
        name = 'Y'
        required_facts = set(['B'])

    class CollectorZ(BaseFactCollector):
        name

# Generated at 2022-06-22 22:50:09.154700
# Unit test for function tsort
def test_tsort():
    data = {'a': {'b'},
            'b': {'c'},
            'c': set()}
    assert tsort(data) == [('c', set()), ('b', {'c'}), ('a', {'b'})]

    # this is a diamond
    data = {'a': {'b', 'c'},
            'b': {'d'},
            'c': {'d'},
            'd': {},
            }
    assert tsort(data) == [('d', set()), ('b', {'d'}), ('c', {'d'}), ('a', {'b', 'c'})]


# Generated at 2022-06-22 22:50:12.528287
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    instance = UnresolvedFactDep("foo", "bar", "baz")
    assert isinstance(instance, UnresolvedFactDep)



# Generated at 2022-06-22 22:50:22.258709
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # test case 1: select_collector_classes with _fact_ids with two high level collector_classes
    test_case_1 = {'_fact_ids': {'fact_collection'}, 'name': 'collector_classes_name'}
    # test case 2: select_collector_classes with _fact_ids with only one high level collector_classes
    test_case_2 = {'_fact_ids': {'fact_collection'}, 'name': 'collector_classes_name'}
    # test case 3: select_collector_classes with _fact_ids with two high level collector_classes
    test_case_3 = {'_fact_ids': {'fact_collection'}, 'name': 'collector_classes_name'}
    # test case 4: select_collector_classes with only one high level collector_classes


# Generated at 2022-06-22 22:50:32.370691
# Unit test for function build_dep_data
def test_build_dep_data():
    class DummyCollector(BaseFactCollector):
        name = 'dummy_collector'
        required_facts = set(('foo'))

    class DummyCollector2(DummyCollector):
        name = 'dummy_collector2'
        required_facts = set(('bar', 'baz'))

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['dummy_collector'].append(DummyCollector)
    all_fact_subsets['dummy_collector2'].append(DummyCollector2)

    collector_names = ['dummy_collector', 'dummy_collector2']

    dep_data = build_dep_data(collector_names, all_fact_subsets)


# Generated at 2022-06-22 22:50:44.531852
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import os.path
    import unittest
    import sys

    test_module_path = os.path.abspath(os.path.dirname(sys.modules[__name__].__file__))

    class CollectorStub(BaseFactCollector):
        name = 'name'
        _fact_ids = ['fact_id']

    collector_class_mock = CollectorStub

    collectors_for_platform = [collector_class_mock]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    test_cases = {
        'name': [collector_class_mock],
        'fact_id': [collector_class_mock]
    }

    test_case = {}


# Generated at 2022-06-22 22:50:55.226708
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'aa'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c'])

    assert select_collector_classes(['a', 'b'], {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
    }) == [CollectorA, CollectorB]



# Generated at 2022-06-22 22:50:57.108418
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps()
    assert isinstance(err, CycleFoundInFactDeps)


# Generated at 2022-06-22 22:51:07.687480
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import pytest
    # In this case, the 'module' parameter is None and the 'collected_facts' parameter is None
    with pytest.raises(TypeError) as excinfo:
        BaseFactCollector().collect_with_namespace()
    assert 'collect() got an unexpected keyword argument' in str(excinfo.value)

    # In this case, the 'module' parameter is not None and the 'collected_facts' parameter is None
    module = object()
    with pytest.raises(TypeError) as excinfo:
        BaseFactCollector().collect_with_namespace(module)
    assert 'collect() got an unexpected keyword argument' in str(excinfo.value)

# Generated at 2022-06-22 22:51:08.674900
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    CycleFoundInFactDeps()



# Generated at 2022-06-22 22:51:15.919433
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test for invalid gather subset
    with pytest.raises(TypeError):
        get_collector_names(gather_subset=['bad-subset'])

    # Test for empty gather subset
    res = get_collector_names(gather_subset=[])
    assert res == frozenset()

    # Test gather_subset is not None
    res = get_collector_names(gather_subset=None)
    assert res == frozenset()

    # Test minimal_gather_subset
    minimal_gather_subset = frozenset(['a', 'b', 'c'])
    res = get_collector_names(minimal_gather_subset=minimal_gather_subset)
    assert res == minimal_gather_subset

    # Test minimal_gather

# Generated at 2022-06-22 22:51:26.022239
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b', 'd']),
        'b': set(['c']),
        'c': set(['d']),
        'f': set(['e']),
        'g': set(['f']),
        'h': set(['g']),
        'i': set(['h']),
        'j': set(['k', 'l']),
        'k': set(['l']),
        }
    sorted_list = tsort(dep_map)

# Generated at 2022-06-22 22:51:29.192966
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(UnresolvedFactDep):
        raise UnresolvedFactDep("unresolved_fact")
    with pytest.raises(UnresolvedFactDep):
        raise UnresolvedFactDep()


# Generated at 2022-06-22 22:51:36.352489
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class FakeBaseFactName:
        name = 'fake_base_fact_name'

    class FakeBaseFactName2(FakeBaseFactName):
        name = 'fake_base_fact_name_class2'

    class FakeBaseFactName3(FakeBaseFactName):
        name = 'fake_base_fact_name_class3'

    class FakeSubset1(FakeBaseFactName):
        name = 'fake_subset1'
        _fact_ids = [name]

    class FakeSubset2(FakeBaseFactName):
        name = 'fake_subset2'
        _fact_ids = [name]

    class FakeSubset3(FakeBaseFactName):
        name = 'fake_subset3'
        _fact_ids = [name]


# Generated at 2022-06-22 22:51:37.856647
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fact = BaseFactCollector()
    assert fact.collect() == {}


# Generated at 2022-06-22 22:51:49.593822
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['a', 'b', 'c'])
    minimal_gather_subset = frozenset(['a'])
    aliases_map = defaultdict(set)
    aliases_map['d'].update(['a', 'b'])

    assert get_collector_names(valid_subsets) == valid_subsets

    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['all']) == valid_subsets

    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['min']) == minimal_gather_subset
    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['min', 'a']) == valid_subsets
    assert get

# Generated at 2022-06-22 22:51:51.487852
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collectorNotFoundErrr = CollectorNotFoundError('test_message')
    assert collectorNotFoundErrr.args[0] == 'test_message'



# Generated at 2022-06-22 22:52:03.324845
# Unit test for function tsort
def test_tsort():
    assert tsort({'A': set(), 'B': set()}) == [('A', set()), ('B', set())]
    assert tsort({'A': {'B'}, 'B': set()}) == [('B', set()), ('A', {'B'})]
    assert tsort({'A': {'B'}, 'B': {'A'}}) == [('A', {'B'}), ('B', {'A'})]
    assert tsort({'A': {'B'}, 'B': {'C'}, 'C': {'A'}}) == [('B', {'C'}), ('C', {'A'}), ('A', {'B'})]

# Generated at 2022-06-22 22:52:06.788336
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    base_fact_collector = BaseFactCollector()
    base_fact_collector.namespace
    base_fact_collector.collectors
    base_fact_collector.fact_ids



# Generated at 2022-06-22 22:52:12.761425
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact2', 'fact3'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({Collector1, Collector2})

    assert fact_id_to_collector_map['fact1'] == [Collector1]
    assert fact_id_to_collector_map['fact2'] == [Collector1, Collector2]
    assert fact_id_to_collector_map['fact3'] == [Collector2]

# Generated at 2022-06-22 22:52:14.948876
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with timeout.raiseTimeoutError(timeout_seconds=1, check_interval=0):
        raise CycleFoundInFactDeps()


# Generated at 2022-06-22 22:52:22.989491
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class MockCollector:
        def __init__(self, name, requires):
            self.name = name
            self.required_facts = requires

    class MockCollectorSubset:
        def __init__(self):
            self.collectors = [
                MockCollector('alpha', ['beta', 'gamma']),
                MockCollector('beta', ['delta']),
                MockCollector('gamma', []),
                MockCollector('delta', ['gamma'])
            ]

        def __getitem__(self, key):
            return [collector for collector in self.collectors if collector.name == key]

    mock_subset = MockCollectorSubset()

    assert set() == find_unresolved_requires(['alpha'], mock_subset)
    assert set() == find_unresolved_requires

# Generated at 2022-06-22 22:52:33.963053
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import PrefixNamespace
    from ansible.module_utils.facts.namespace import SuffixNamespace

    fact_names = ['fact1', 'fact2']
    facts_dict = dict([(key, key) for key in fact_names])

    # Basic test - no namespace
    collector = BaseFactCollector()
    assert collector.collect_with_namespace() == facts_dict

    # Test with PrefixNamespace
    prefix = 'zzz'
    namespace = PrefixNamespace(prefix)
    collector = BaseFactCollector(namespace=namespace)
    assert collector.collect_with_namespace() == dict([(prefix + key, key) for key in fact_names])

    # Test with SuffixNamespace
    suffix = 'yyy'
    namespace = Suffix

# Generated at 2022-06-22 22:52:37.980876
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('a', 'b')
    assert e.__str__() == "Cycle found in fact dependency graph: a -> b"


# Generated at 2022-06-22 22:52:40.171030
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    assert obj.collect() == {}
    assert isinstance(obj.collect(), dict)



# Generated at 2022-06-22 22:52:52.197907
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collectors = [1, 2, 3]
    # Test _platform set
    b = BaseFactCollector()
    assert b._platform == 'Generic'

    # Test name not set
    b = BaseFactCollector()
    assert b.name is None

    # Test collectors not passed
    b = BaseFactCollector()
    assert b.collectors == []

    # Test simple constructor
    b = BaseFactCollector(collectors=collectors, namespace=None)
    assert b.collectors == collectors
    assert b.namespace == None

    # Test platform_match for module 'ansible.module_utils.facts.system.windows'
    from ansible.module_utils.facts.system.windows import WindowsFactCollector
    assert WindowsFactCollector.platform_match(dict(system='Windows')) == WindowsFactCollector
    # Test

# Generated at 2022-06-22 22:52:59.349217
# Unit test for function select_collector_classes
def test_select_collector_classes():
    seen_collector_classes = set()
    selected_collector_classes = list()

    collector_names = ['all', 'network']

    all_fact_subsets = {
        'local': [BaseFactCollector],
        'network': [BaseFactCollector, BaseFactCollector]
    }

    for collector_name in collector_names:
        collector_classes = all_fact_subsets.get(collector_name, [])
        for collector_class in collector_classes:
            if collector_class not in seen_collector_classes:
                selected_collector_classes.append(collector_class)
                seen_collector_classes.add(collector_class)

    print(selected_collector_classes)

test_select_collector_classes()


# Generated at 2022-06-22 22:53:01.164072
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    c = CycleFoundInFactDeps('Testing')
    repr(c)
    str(c)



# Generated at 2022-06-22 22:53:01.784102
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass



# Generated at 2022-06-22 22:53:13.548625
# Unit test for function resolve_requires
def test_resolve_requires():
    requires = {
        'collector_1': {'required1', 'required2'},
        'collector_2': {'required3', 'required4'},
        'required1': {'required2', 'required3'},
        'required2': {'required4', 'required5'},
        'required5': {'required6', 'required7'},
    }

    all_fact_subsets = {
        'collector_1': [],
        'collector_2': [],
        'required1': [],
        'required2': [],
        'required3': [],
        'required4': [],
        'required5': [],
    }

    collector_names = set(['collector_1', 'collector_2'])


# Generated at 2022-06-22 22:53:20.889028
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''create a fake list of collectors and check on getting the list'''
    all_collector_classes = [BaseFactCollector, ]
    compat_platforms = [{'system': 'Darwin'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    # this will break if more collectors are added to the BaseFactCollector
    assert not found_collectors

    class FakeLinuxCollector(BaseFactCollector):
        _fact_ids = {'cpu'}

        _platform = 'Linux'
        name = 'linux'
        required_facts = set()

    class FakeDarwinCollector(BaseFactCollector):
        _fact_ids = {'kernel'}

        _platform = 'Darwin'
        name = 'darwin'
        required_