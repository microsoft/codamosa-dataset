

# Generated at 2022-06-22 22:43:19.959506
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    a = BaseFactCollector()
    assert a.collect() == {}


# Generated at 2022-06-22 22:43:30.972434
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'TestCollector1'
        required_facts = {'TestCollector2'}
    class TestCollector2(BaseFactCollector):
        name = 'TestCollector2'
        required_facts = {'TestCollector3'}
    class TestCollector3(BaseFactCollector):
        name = 'TestCollector3'
        required_facts = set()

    all_fact_subsets = {
        'TestCollector1': set([TestCollector1]),
        'TestCollector2': set([TestCollector2]),
        'TestCollector3': set([TestCollector3]),
    }

    unresolved = find_unresolved_requires(['TestCollector1'], all_fact_subsets)

# Generated at 2022-06-22 22:43:32.890406
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    c = BaseFactCollector()
    assert c.collectors == []
    assert c.namespace is None
    assert c.fact_ids == set(['Generic'])



# Generated at 2022-06-22 22:43:42.363330
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    import pytest
    class TestCollector(BaseFactCollector):
        # needed to pass the test
        name = None
        def collect(self):
            return {}

    test_collector = TestCollector()

    assert test_collector.fact_ids == set([None])
    assert test_collector.required_facts == set()
    assert test_collector.collectors == []

    # Test the namespace transform
    from ansible.module_utils.facts.namespace import Namespace
    ns = Namespace('test_namespace_')
    test_collector = TestCollector(namespace=ns)
    assert test_collector.namespace == ns
    assert test_collector._transform_name('key') == 'test_namespace_key'

    # Test the auto-namespace transform
    test_collector = Test

# Generated at 2022-06-22 22:43:44.195610
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert str(e) == "foo"



# Generated at 2022-06-22 22:43:51.088535
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = {'one', 'two'}
        name = 'test'
        required_facts = set()

    class TestCollectorV2(TestCollector):
        pass

    class TestCollectorV3(TestCollector):
        pass

    class TestCollectorV4(TestCollector):
        pass

    class TestCollectorV5(TestCollector):
        pass

    class TestCollectorV6(TestCollector):
        pass

    class TestCollectorV7(TestCollector):
        pass

    class TestCollectorV8(TestCollector):
        pass

    class TestCollectorV9(TestCollector):
        pass

    class TestCollectorV10(TestCollector):
        pass


# Generated at 2022-06-22 22:44:03.090722
# Unit test for function build_dep_data
def test_build_dep_data():
    test_map={'compute' : {'ipv4'}, 'ipv4' : set(), 
              'a' : {'b'}, 'test' : {'a', 'c'}, 'b' : {'c', 'd'}, 'c' : {'d'}, 'd' : {}}
    collector_names = ['ipv4', 'a', 'test', 'b', 'c', 'd']
    all_fact_subsets = {}
    for name in collector_names:
        all_fact_subsets[name] = [None]

    class Collecter(object):
        def __init__(self, required_facts=None):
            self.required_facts = required_facts

    compute = Collecter(required_facts = set(['ipv4']))

# Generated at 2022-06-22 22:44:14.281224
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class PlatformMatchedCollector(BaseFactCollector):
        '''Simple class that always returns t/f as the value for a fact 'test_fact' '''
        _fact_ids = {'test_fact'}
        def __init__(self, test_val, *args, **kwargs):
            self.test_val = test_val
            super(PlatformMatchedCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            facts_dict = {'test_fact': self.test_val}
            return facts_dict

    # test module, which will be passed as an argument to collect_with_namespace
    mock_module = Mock(name='mock_module')

    # test Namespace object that will add a suffix to a key_name


# Generated at 2022-06-22 22:44:18.025622
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    f = BaseFactCollector()
    fact_dict = f.collect(module=None, collected_facts=None)
    assert isinstance(fact_dict, dict)

test_BaseFactCollector_collect()



# Generated at 2022-06-22 22:44:28.962760
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    unresolved = set()

    all_fact_subset = defaultdict(list)
    all_fact_subset['hardware'].append(BaseFactCollector())
    all_fact_subset['network'].append(BaseFactCollector())

    all_fact_subset['hardware'][0].required_facts = set(['network'])

    unresolved = find_unresolved_requires(['hardware'], all_fact_subset)
    assert unresolved == set()

    # network is required but not provided
    unresolved = find_unresolved_requires(['hardware', 'network'], all_fact_subset)
    assert unresolved == set()

    unresolved = find_unresolved_requires(['network'], all_fact_subset)
    assert unresolved == set()

    # hardware is required but not provided
    unresolved

# Generated at 2022-06-22 22:44:38.228880
# Unit test for function resolve_requires
def test_resolve_requires():
    collector_name = 'foo'
    all_fact_subsets = {
        'foo': [],
        'bar': [],
        'baz': [],
    }
    try:
        resolve_requires([collector_name], all_fact_subsets)
    except UnresolvedFactDep:
        raise AssertionError('%s should be in all_fact_subsets' % collector_name)

    # test that if nothing is unresolved, we get an empty set
    assert not resolve_requires([], all_fact_subsets)

    # test that we get a set back with the name if it's not a valid fact name
    assert 'qux' in resolve_requires(['qux'], all_fact_subsets)



# Generated at 2022-06-22 22:44:44.850288
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from unittest.mock import Mock

    class FakeLinuxCollector1(BaseFactCollector):
        name = 'linux1'
        _platform = 'Linux'

    class FakeLinuxCollector2(BaseFactCollector):
        name = 'linux2'
        _platform = 'Linux'

    class FakeLinuxCollector3(BaseFactCollector):
        name = 'linux3'
        _platform = 'Linux'
        required_facts = set(['linux2'])

    class FakeWindowsCollector1(BaseFactCollector):
        name = 'windows1'
        _platform = 'Windows'

    class FakeWindowsCollector2(BaseFactCollector):
        name = 'windows2'
        _platform = 'Windows'
        required_facts = set(['windows1'])


# Generated at 2022-06-22 22:44:49.349943
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import BaseFactCollector
    obj = BaseFactCollector()
    assert obj.collect_with_namespace() == {}
    assert obj.collect_with_namespace() == obj.collect()



# Generated at 2022-06-22 22:44:53.288461
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError('mykey')
    c.args[0] == 'mykey'
    assert c.args[0] == 'mykey'


# Generated at 2022-06-22 22:45:02.787066
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'B'
        required_facts = {'A'}
    class C(BaseFactCollector):
        name = 'C'
        required_facts = {'C', 'A'}
    class D(BaseFactCollector):
        name = 'D'
        required_facts = {'A', 'C'}

    all_fact_subsets = {
        'A': [A],
        'B': [B],
        'C': [C],
        'D': [D]
    }

    assert build_dep_data(['A'], all_fact_subsets) == {'A': set()}

# Generated at 2022-06-22 22:45:09.869888
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set()

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector1'])

    all_fact_subsets = {
        'collector1': [Collector1],
        'collector2': [Collector2],
    }
    collector_names = ['collector1', 'collector2']
    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map == {
        'collector1': set(),
        'collector2': {'collector1'},
    }


# Generated at 2022-06-22 22:45:21.803842
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['network', 'hardware', 'software', 'virtual'])

    # simple alias tests
    aliases_map = defaultdict(set)
    aliases_map.update({
        'virtual': frozenset(['!kernel']),
        'hardware': frozenset(['!kernel']),
        'network': frozenset(['foo']),
    })
    assert get_collector_names(gather_subset=['network', '!virtual'],
                               valid_subsets=valid_subsets,
                               aliases_map=aliases_map) == frozenset(['network', 'foo'])


# Generated at 2022-06-22 22:45:24.894970
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    msg = 'test message'
    e = UnresolvedFactDep(msg)
    assert e.__str__() == msg



# Generated at 2022-06-22 22:45:34.140907
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all','min','network','ohai','system']
    all_fact_subsets = {'all': [BaseFactCollector(),BaseFactCollector(),BaseFactCollector()],
        'min': [BaseFactCollector(),BaseFactCollector(),BaseFactCollector()],
        'network': [BaseFactCollector(),BaseFactCollector(),BaseFactCollector()],
        'ohai': [BaseFactCollector(),BaseFactCollector(),BaseFactCollector()],
        'system': [BaseFactCollector(),BaseFactCollector(),BaseFactCollector()]}
    result = build_dep_data(collector_names, all_fact_subsets)
    assert(result == defaultdict(set, {'all': set(), 'min': set(), 'network': set(), 'ohai': set(), 'system': set()}))



# Generated at 2022-06-22 22:45:44.854516
# Unit test for function get_collector_names
def test_get_collector_names():
    ansible_os_family_facts_collector = BaseFactCollector()
    ansible_distribution_facts_collector = BaseFactCollector()
    ansible_distribution_version_facts_collector = BaseFactCollector()
    ansible_python_facts_collector = BaseFactCollector()
    ansible_machine_facts_collector = BaseFactCollector()
    ansible_system_facts_collector = BaseFactCollector()
    ansible_all_facts_collector = ansible_os_family_facts_collector.fact_ids | ansible_distribution_facts_collector.fact_ids | ansible_distribution_version_facts_collector.fact_ids | ansible_python_facts_collector.fact_ids | ansible_machine_facts_collector.fact_ids | ansible_system

# Generated at 2022-06-22 22:45:49.747625
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    '''test_BaseFactCollector_collect'''
    # TODO: if this class is renamed to just FactCollector, can we simplify this?
    class Facts_Collector(BaseFactCollector):
        name = 'facts'

    fc = Facts_Collector()
    assert fc.collect() == {}



# Generated at 2022-06-22 22:45:52.688917
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # this test will not pass because you need to override collect in a derived class
    fact_collector = BaseFactCollector()
    fact_collector.collect()



# Generated at 2022-06-22 22:45:56.165496
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("Test Failed")
    except UnresolvedFactDep:
        pass
    except BaseException as e:
        assert False, e.args[0]



# Generated at 2022-06-22 22:46:00.873638
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible_collections.ansible.misc.plugins.module_utils.facts.collector.generic_fact_collector import GenericFactCollector
    fact_collector = BaseFactCollector(collectors=[], namespace=None)
    module = Mock()
    collected_facts = None
    result = fact_collector.collect_with_namespace(module=module, collected_facts=collected_facts)
    assert isinstance(result, dict)


# Generated at 2022-06-22 22:46:01.491049
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    pass


# Generated at 2022-06-22 22:46:04.502231
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    fact_collector = BaseFactCollector()
    fact_collector.collect_with_namespace()



# Generated at 2022-06-22 22:46:15.923541
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        def __init__(self, namespace=None):
            super(TestCollector, self).__init__(namespace=namespace)

        def collect(self, module=None, collected_facts=None):
            return {'key': 'value', 'a': 'b'}

    namespace = Namespace()
    collector = TestCollector(namespace)

    facts = collector.collect_with_namespace()

    assert facts['key'] == 'value'
    assert facts['a'] == 'b'

    # now check the namespace transforms
    namespace = Namespace(prefix='my_', suffix='_thing')
    collector = TestCollector(namespace)

    facts = collector.collect_with_namespace()

    assert facts['my_key_thing'] == 'value'
    assert facts

# Generated at 2022-06-22 22:46:18.273733
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError()
    except CollectorNotFoundError as e:
        repr(e)
        str(e)



# Generated at 2022-06-22 22:46:21.489642
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  import pytest 
  import sys 
  import types 
  import copy 

  BaseFactCollector_test = BaseFactCollector()
  with pytest.raises(Exception): BaseFactCollector_test.collect()


# Generated at 2022-06-22 22:46:31.359132
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        name = 'unit_test1'

        @classmethod
        def platform_match(cls, platform_info):
            # will match any platform
            return cls

    class TestCollector2(BaseFactCollector):
        name = 'unit_test2'

        @classmethod
        def platform_match(cls, platform_info):
            # will match only when platform name is 'test'
            if platform_info.get('system', None) == 'test':
                return cls
            return None

    class TestCollector3(BaseFactCollector):
        name = 'unit_test3'


# Generated at 2022-06-22 22:46:38.656095
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        name = 'testcollector1'
        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        name = 'testcollector2'
        _platform = 'Linux'

    class TestCollector3(BaseFactCollector):
        name = 'testcollector3'
        _platform = 'FreeBSD'

    class TestCollector4(BaseFactCollector):
        name = 'testcollector4'
        _platform = 'Generic'

    class TestCollector5(BaseFactCollector):
        name = 'testcollector5'
        _platform = 'Linux'

    class TestCollector6(BaseFactCollector):
        name = 'testcollector6'
        _platform = 'Linux'


# Generated at 2022-06-22 22:46:48.672182
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import ansible.module_utils.facts.system.base as facts_base
    class CollectFacts(facts_base.BaseFactCollector):
        name = 'collect_facts'
        _fact_ids = ['new_fact_id', 'old_fact_id']
        def collect(self, module=None, collected_facts=None):
            return {'facts': 'facts'}

    class CollectFacts2(facts_base.BaseFactCollector):
        name = 'collect_facts2'
        _fact_ids = ['new_fact_id', 'old_fact_id']
        def collect(self, module=None, collected_facts=None):
            return {'facts2': 'facts2'}

    class CollectFacts3(facts_base.BaseFactCollector):
        name = 'collect_facts3'
       

# Generated at 2022-06-22 22:46:53.576121
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'

    collector = TestCollector()
    facts = collector.collect_with_namespace()

    assert facts == {}


# Generated at 2022-06-22 22:47:04.095927
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Return a dict containing facts about the system.
    kwargs = dict(module=None, collected_facts=None)
    assert BaseFactCollector(**kwargs).collect_with_namespace() == {}
    assert BaseFactCollector(collectors=None, namespace=None, **kwargs).collect_with_namespace() == {}
    assert BaseFactCollector(collectors=[], namespace=None, **kwargs).collect_with_namespace() == {}
    assert BaseFactCollector(collectors=[], namespace=[], **kwargs).collect_with_namespace() == {}
    assert BaseFactCollector(collectors=[], namespace=(), **kwargs).collect_with_namespace() == {}



# Generated at 2022-06-22 22:47:14.549478
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''test function find_unresolved_requires'''

    # Make made up objects to make list comprehension work.
    # requires_facts returns a set of names
    # name is the collector name
    # _fact_ids is a set of facts that the collector provides
    FakeCollector = type('FakeCollector', (object, ), dict(name=None, _fact_ids=None, required_facts=None))

    def make_fake_collector(name, provides, requires):
        provides = set(provides)
        requires = set(requires)
        return FakeCollector(name=name,
                             _fact_ids=provides,
                             required_facts=requires)


# Generated at 2022-06-22 22:47:17.204765
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-22 22:47:19.125618
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    response = obj.collect()
    assert response == {}


# Generated at 2022-06-22 22:47:30.056983
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object],
        'b': [object],
        'c': [object],
        'd': [object],
        'e': [object],
        'f': [object],
    }

    class A:
        required_facts = set(['b', 'e', 'f'])

    class B:
        required_facts = set(['c', 'd'])

    class C:
        required_facts = set(['a'])

    class D:
        required_facts = set(['f'])

    all_fact_subsets['a'] = [A]
    all_fact_subsets['b'] = [B]
    all_fact_subsets['c'] = [C]
    all_fact_subsets['d'] = [D]
   

# Generated at 2022-06-22 22:47:42.111333
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    '''Tests that the BaseFactCollector class works when subclassed, and
    the constructor handles various input properly (like not erroring on missing
    args).'''

    class DummyFactCollector(BaseFactCollector):
        name = 'dummy'

    # test that you can instantiate BaseFactCollector w/o args
    bc = BaseFactCollector()

    # test that you can instantiate BaseFactCollector with args
    collectors = ['a', 'b', 'c']
    bc = BaseFactCollector(collectors=collectors)

    # test that the required_facts set is empty
    assert bc.required_facts == set([])

    # test that the instantiated fact collector can be used
    fc = DummyFactCollector()

    # test that the required_facts set is still empty
    assert fc.required_

# Generated at 2022-06-22 22:47:50.216929
# Unit test for function build_dep_data
def test_build_dep_data():
    fact_id_to_collector_map = {'a': ['foo'], 'b': ['foo'], 'c': ['bar'], 'd': ['baz']}
    dep_map = build_dep_data(fact_id_to_collector_map.keys(), fact_id_to_collector_map)
    assert dep_map['a'] == set()
    assert dep_map['b'] == set()
    assert dep_map['c'] == set()
    assert dep_map['c'] == set()



# Generated at 2022-06-22 22:47:54.399547
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return dict(first='first', second='second')

    collector = TestCollector()
    assert collector.collect_with_namespace() == dict(first='first', second='second')



# Generated at 2022-06-22 22:47:55.197858
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import __main__ as main
    assert main.__file__



# Generated at 2022-06-22 22:48:07.944387
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from collections import defaultdict
    class GenericCollector():
        name = 'generic'
        required_facts = set()
    class CollectorA():
        name = 'a'
        required_facts = {'b'}
    class CollectorB():
        name = 'b'
        required_facts = {'c'}
    class CollectorC():
        name = 'c'
        required_facts = set()
    # One class per name
    all_fact_subsets_1 = defaultdict(list)
    all_fact_subsets_1[GenericCollector.name].append(GenericCollector)
    all_fact_subsets_1[CollectorA.name].append(CollectorA)
    all_fact_subsets_1[CollectorB.name].append(CollectorB)
    all_fact_subsets_1

# Generated at 2022-06-22 22:48:11.472457
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector().collectors == []
    assert BaseFactCollector().namespace is None
    assert BaseFactCollector().fact_ids == set([None])

    assert BaseFactCollector(namespace="test_namespace").namespace == "test_namespace"

# Base platform class.
# If other platforms have in common, add it here.

# Generated at 2022-06-22 22:48:24.147464
# Unit test for function tsort
def test_tsort():
    '''
    This test is just a sanity check for the above
    tsort function.
    '''
    from ansible.module_utils.facts import tsort


# Generated at 2022-06-22 22:48:36.507490
# Unit test for function tsort
def test_tsort():
    # This example is taken from
    # http://www.cs.jhu.edu/~langmea/resources/lecture_notes/topsort_alg.pdf

    assert tsort({
        1: [2, 3],
        2: [3, 4],
        3: [],
        4: [],
    }) == [
        (4, [3]),
        (3, []),
        (2, [3, 4]),
        (1, [2, 3]),
    ]


# Generated at 2022-06-22 22:48:46.840305
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
    class TestCollector2(BaseFactCollector):
        name = 'test2'
    class TestCollector3(TestCollector2):
        name = 'test3'
    all_collectors = [TestCollector1, TestCollector2, TestCollector3]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors)
    assert fact_id_to_collector_map == {
        'test1': [TestCollector1],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

# Generated at 2022-06-22 22:48:58.201032
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

# pylint: disable=R0903,R0913
    class TestCollectorA(BaseFactCollector):
        _fact_ids = ['testa1', 'testa2', 'testa3']
        name = 'testa'

    class TestCollectorB(BaseFactCollector):
        _fact_ids = ['testb1', 'testb2', 'testb3']
        name = 'testb'

    class TestCollectorC(BaseFactCollector):
        _fact_ids = ['testc1', 'testc2', 'testc3']
        name = 'testc'

    class TestCollectorD(BaseFactCollector):
        _fact_ids = ['testd1', 'testd2', 'testd3']
        name = 'testd'


# Generated at 2022-06-22 22:49:04.977467
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # collector_names is a list of fact subsets chosen for execution.
    collector_names = ['platform', 'other_platform']
    # all_fact_subsets is a dictionary with key as fact subsets and value as a list of
    # fact collectors which are available for the subset.
    all_fact_subsets = {
        'network' : ['network_fact_collector_1', 'network_fact_collector_2'],
        'platform' : ['platform_fact_collector_1', 'platform_fact_collector_2']}
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

    assert selected_collector_classes == ['platform_fact_collector_1', 'platform_fact_collector_2']



# Generated at 2022-06-22 22:49:13.587570
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # BaseFactCollector(namespace=None)
    # Module to be tested
    module = 'ansible.module_utils.facts.collector'
    module_obj = AnsibleModule(argument_spec={})
    module_obj.fail_json = mock_fail_json
    # Creation/initialization of the object
    test_obj = BaseFactCollector()
    # Calling the method to be tested
    result_ans = test_obj.collect_with_namespace(module=module, collected_facts=None)
    expected_ans = {}
    # Assertion of the resulting values
    assert result_ans == expected_ans



# Generated at 2022-06-22 22:49:22.515322
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''should be ok because no collision with existing fact subset name'''
    class TestCollector(BaseFactCollector):
        name = 'test'

    class TestCollector2(BaseFactCollector):
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = frozenset(['test'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = frozenset(['test3'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = frozenset(['test4', 'test2'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'

# Generated at 2022-06-22 22:49:27.152671
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():

    bfc = BaseFactCollector()
    assert bfc.name is None
    assert isinstance(bfc.required_facts, set)
    assert bfc.fact_ids == set()



# Generated at 2022-06-22 22:49:35.805516
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'] = [AFactCollector()]
    all_fact_subsets['b'] = [BFactCollector()]
    all_fact_subsets['c'] = [CFactCollector()]
    all_fact_subsets['d'] = [DFactCollector()]
    all_fact_subsets['e'] = [EFactCollector()]

    dep_map = build_dep_data(set(['e', 'd', 'c', 'b', 'a']), all_fact_subsets)
    assert set(dep_map['e']) == set(['d', 'a'])
    assert set(dep_map['d']) == set(['c', 'a'])

# Generated at 2022-06-22 22:49:46.290732
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # create map of collector_name -> class
    from ansible.module_utils.facts.collector.hardware.system_profiler import SystemProfilerFactCollector

# Generated at 2022-06-22 22:49:49.769233
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    x = UnresolvedFactDep(['a', 'b'])
    assert 'Need -a- before -b-' in str(x)
    assert 'b' in str(x)


# Generated at 2022-06-22 22:49:55.267038
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    facts_collector = BaseFactCollector()
    collected_facts = {'foo': 'bar'}
    facts_dict = facts_collector.collect(collected_facts=collected_facts)
    assert isinstance(facts_dict, dict)
    assert facts_dict == {}



# Generated at 2022-06-22 22:50:04.815716
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector, DistributionFact
    from ansible.module_utils.facts.system.distribution.debian import DebianDistribution
    from unittest.mock import Mock

    compat_platforms = [
        {'os_family': 'Debian'},
        # Generic is a catch-all, if you ask for it, then you get everything
        {'system': 'Generic'},
    ]

    # 'classmethod' is a function that is always associated with a class, but it is called
    # directly from the class, not an instance.
    #
    # see: https://docs.python.org/3/library/functions.html#classmethod
    # see: https://docs.python.org/2/library/functions.html#classmethod
    #


# Generated at 2022-06-22 22:50:10.038570
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class MockCollector(BaseFactCollector):
        def collect(self, **kwargs):
            return {'foo': 'bar'}

    mock_collector = MockCollector()
    fact_data = mock_collector.collect_with_namespace()
    assert fact_data == {'foo': 'bar'}



# Generated at 2022-06-22 22:50:21.207448
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class SomeCollector1(BaseFactCollector):
        name = 'some_collector1'
        _fact_ids = ['foo']

    class SomeCollector2(SomeCollector1):
        name = 'some_collector2'
        _fact_ids = ['foo2']

    class SomeCollector3(SomeCollector1):
        name = 'some_collector3'
        _fact_ids = ['bar']

    class SomeCollector4(BaseFactCollector):
        name = 'some_collector4'

    class SomeCollector5(BaseFactCollector):
        name = 'some_collector5'
        _fact_ids = ['foo', 'foo2', 'bar']


# Generated at 2022-06-22 22:50:31.375706
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'network': ['network'],
        'system': ['system'],
        'all': set(['all']),
    }
    assert resolve_requires(set(['network']), all_fact_subsets) == set(['network'])
    assert resolve_requires(set(['network', 'system']), all_fact_subsets) == set(['network', 'system'])
    assert resolve_requires(set(['network', 'unknown']), all_fact_subsets) == set(['network'])
    assert resolve_requires(set(['network', 'unknown', 'system']), all_fact_subsets) == set(['network', 'system'])

# Generated at 2022-06-22 22:50:35.401028
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('testCollector')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'testCollector'


# Generated at 2022-06-22 22:50:45.423529
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'a'
        _fact_ids = set()
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        _fact_ids = set()
        required_facts = set()

    class C(BaseFactCollector):
        name = 'c'
        _fact_ids = set()
        required_facts = set(['a', 'b'])

    class D(BaseFactCollector):
        name = 'd'
        _fact_ids = set()
        required_facts = set(['c'])

    class E(BaseFactCollector):
        name = 'e'
        _fact_ids = set()
        required_facts = set(['d', 'c'])

    dep_map = build_

# Generated at 2022-06-22 22:50:52.227104
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e1 = CollectorNotFoundError('foo')
    assert str(e1) == 'foo'
    e2 = CollectorNotFoundError(int(123))
    assert str(e2) == '123'
    e3 = CollectorNotFoundError(None)
    assert str(e3) == 'None'
    assert repr(e3) == 'CollectorNotFoundError(None,)'



# Generated at 2022-06-22 22:51:04.365308
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    from ansible.module_utils.facts import collector

    class TestCollector1(collector.BaseFactCollector):
        name = 'test_base'
        _platform = 'Linux'

    class TestCollector2(collector.BaseFactCollector):
        name = 'test_base_special'
        _platform = 'Linux'

    class TestCollectorNoPlatform(collector.BaseFactCollector):
        name = 'no_platform'

    class TestCollectorNoMatch(collector.BaseFactCollector):
        name = 'no_match'
        _platform = 'FreeBSD'

    all_collectors = {TestCollector1, TestCollector2, TestCollectorNoMatch, TestCollectorNoPlatform}

    # compat_platforms with exact match for TestCollector1/2 and generic match for TestCollect

# Generated at 2022-06-22 22:51:12.642382
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class MyCollector(BaseFactCollector):
        name = 'my_collector'
        def collect(self, module=None, collected_facts=None):
            return {'one': 1, 'two': 2}

    # Test with a namespace
    namespace = DictNamespace('pfx_')

    col = MyCollector(namespace=namespace)
    facts = col.collect_with_namespace()
    assert facts == {'pfx_one': 1, 'pfx_two': 2}

    # Test without a namespace
    col = MyCollector()
    facts = col.collect_with_namespace()
    assert facts == {'one': 1, 'two': 2}



# Generated at 2022-06-22 22:51:15.273802
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    try:
        BaseFactCollector()
    except Exception as e:
        assert False, 'Unexpected exception on constructor test: %s' % e



# Generated at 2022-06-22 22:51:25.674145
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest

    all_fact_subsets = {
        'a': [BaseCollectorA],
        'b': [BaseCollectorB],
        'c': [BaseCollectorC]
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['a', 'b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['a', 'c'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b', 'c'], all_fact_subsets) == set()

# Generated at 2022-06-22 22:51:28.139362
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('foo')
    except CycleFoundInFactDeps as e:
        assert 'foo' == str(e)


# Generated at 2022-06-22 22:51:35.647149
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Using a values set that has no conflicts between collectors
    # but does have aliasing and depends
    # 'hardware' collects 'devices' and 'dmi', but 'dmi' also collects 'devices'
    valid_subsets = frozenset(['all', 'software', 'hardware', 'network', 'ohai', 'facter', 'devices', 'dmi'])
    collect_name_to_class = {
        'dmi': DmiFactCollector,
        'devices': DevicesFactCollector,
        'software': SoftwareFactCollector,
        'network': NetworkFactCollector,
        'ohai': OhaiFactCollector,
        'facter': FacterFactCollector,
        'hardware': HardwareFactCollector,
    }

    # the names 'all' and 'min' are reserved
    all_collector

# Generated at 2022-06-22 22:51:40.889116
# Unit test for function get_collector_names
def test_get_collector_names():
    # 1st case: 'all' only
    gather_subset_all = ['all']
    valid_subsets_all = frozenset(['min', 'all', 'hardware', 'network'])
    minimal_gather_subset_all = frozenset(['min'])
    aliases_map_all = defaultdict(set, {'hardware': set(['devices', 'dmi'])})
    expected_all = frozenset(['min', 'hardware', 'network', 'devices', 'dmi'])

# Generated at 2022-06-22 22:51:52.203589
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    from ansible.module_utils.facts.namespace import FallbackNamespace
    from ansible.module_utils.facts.namespace import DefaultNamespace

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            facts = {
                'a': 1,
                'b': 2
            }
            return facts

    test_collector = TestCollector()
    f = test_collector.collect_with_namespace()
    h = test_collector._transform_dict_keys(f)
    assert 'a' in h
    assert 'b' in h
    assert 'test_a' not in h
    assert 'test_b' not in h


# Generated at 2022-06-22 22:52:04.082302
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = dict()
    all_fact_subsets['collector_b'] = [BaseFactCollector]
    all_fact_subsets['collector_a'] = [BaseFactCollector]
    all_fact_subsets['collector_c'] = [BaseFactCollector]
    all_fact_subsets['collector_d'] = [BaseFactCollector]

    collector_names = ['collector_b', 'collector_a', 'collector_a', 'collector_d', 'collector_a']
    expected_result = [BaseFactCollector, BaseFactCollector, BaseFactCollector]
    collector_classes = select_collector_classes(collector_names, all_fact_subsets)

# Generated at 2022-06-22 22:52:06.214106
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-22 22:52:17.848169
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # mockup a new class
    class Collector1(BaseFactCollector):
        name = "collector1"
        _platform = 'Linux'

    # mockup a new class
    class Collector2(Collector1):
        name = "collector2"
        _platform = 'FreeBSD'

    # mockup a new class
    class Collector3(BaseFactCollector):
        name = "collector3"

    # mockup a new class
    class Collector4(Collector2):
        name = "collector4"
        _platform = 'Darwin'

    # mockup a new class
    class Collector5(Collector1):
        name = "collector5"

    all_collector_classes = [Collector1, Collector2, Collector3, Collector4, Collector5]
    all_collector_classes = frozens

# Generated at 2022-06-22 22:52:29.234307
# Unit test for function tsort
def test_tsort():
    input_map = {'a': ['b'], 'b': ['c'], 'c': ['d'], 'd': ['e'], 'e': ['c'], 'f': ['a']}
    unsorted_map = input_map.copy()

    failed = False
    try:
        tsort(input_map)
    except CycleFoundInFactDeps:
        failed = True

    assert failed, "tsort should have failed because of cycle"
    assert unsorted_map == input_map, 'CycleFoundInFactDeps logic should not change input map'

    input_map = {'a': ['b'], 'b': ['c'], 'c': ['d'], 'd': ['e'], 'f': ['a']}
    unsorted_map = input_map.copy()

    sort_list = tsort

# Generated at 2022-06-22 22:52:37.130395
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # create mock collector classes and platform info
    class c1():
        _platform = 'Darwin'
        name = 'c1'
    class c2():
        _platform = 'Generic'
        name = 'c2'

    class c3():
        _platform = 'Linux'
        name = 'c3'
    class c4():
        _platform = 'Generic'
        name = 'c4'

    mock_platform_info_darwin = {
        'system': 'Darwin'
    }
    mock_platform_info_linux = {
        'system': 'Linux'
    }

    all_collector_classes = [c1, c2, c3, c4]
    compatible_platforms = [mock_platform_info_darwin]

    # find collectors for darwin platform
    found_collect

# Generated at 2022-06-22 22:52:44.277740
# Unit test for function resolve_requires
def test_resolve_requires():
    # Empty input
    assert resolve_requires(set(), {}) == set()

    # Resolved, single dep
    assert resolve_requires({'x'}, {'x': 1}) == {'x'}

    # Resolved, multiple deps
    assert resolve_requires({'x', 'y'}, {'x': 1, 'y': 2}) == {'x', 'y'}

    # Unresolved
    with pytest.raises(UnresolvedFactDep):
        resolve_requires({'x'}, {})

    # Mixed
    assert resolve_requires({'x', 'y'}, {'x': 1}) == {'x'}



# Generated at 2022-06-22 22:52:54.975344
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    import unittest
    import json

    class Collectors(object):
        def __init__(self, *args):
            self.collectors = list(args)

        def __iter__(self):
            return iter(self.collectors)

        def add(self, collector):
            self.collectors.append(collector)

    class Namespace(object):
        def __init__(self, prefix, suffix):
            self.prefix = prefix
            self.suffix = suffix

        def transform(self, name):
            return self.prefix + name + self.suffix

    class BaseFactCollectorImpl(BaseFactCollector):
        name = 'FactCollector'
        def collect(self, module=None, collected_facts=None):
            facts = dict(a=1, b=2)
            return facts


# Generated at 2022-06-22 22:53:05.459209
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        _fact_ids = set()
        name = 'fact1'
        required_facts = set(['fact3'])

    class Collector2(BaseFactCollector):
        _fact_ids = set()
        name = 'fact2'
        required_facts = set(['fact1', 'fact3'])

    class Collector3(BaseFactCollector):
        _fact_ids = set()
        name = 'fact3'
        required_facts = set()

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['fact1'].append(Collector1)
    all_fact_subsets['fact2'].append(Collector2)
    all_fact_subsets['fact3'].append(Collector3)


# Generated at 2022-06-22 22:53:15.799096
# Unit test for function tsort
def test_tsort():
    unsorted = {'foo': {'bar', 'baz'},
                'bar': {'baz', 'qux'},
                'baz': {'qux', 'corge'},
                'qux': set(),
                'corge': {'grault'},
                'grault': {'garply'},
                'garply': {'waldo'},
                'waldo': {'foo'}}
    sorted_list = tsort(unsorted)

    # make sure each item follows the order of its deps
    for node, edges in sorted_list:
        if not edges:
            continue
        for edge in edges:
            if node in unsorted.get(edge, set()):
                raise AssertionError('%s appears to be sorted before its dependency, %s' % (edge, node))



# Generated at 2022-06-22 22:53:25.409049
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'] = [FakeCollector(['a'], ['q']), FakeCollector(['a'], ['q'])]
    all_fact_subsets['b'] = [FakeCollector(['b'], ['a', 'c'])]
    all_fact_subsets['c'] = [FakeCollector(['c'], [])]
    assert build_dep_data(collector_names, all_fact_subsets) == {'a': {'q'}, 'b': {'a', 'c'}, 'c': set()}
