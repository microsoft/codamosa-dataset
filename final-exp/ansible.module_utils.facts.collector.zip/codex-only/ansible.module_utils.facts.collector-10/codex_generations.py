

# Generated at 2022-06-22 22:43:25.156886
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest

    all_fact_subsets = {'links': [], 'cmdline': []}

    # try to resolve 'links', 'cmdline'
    unresolved_requires = {'links', 'cmdline'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == {'links', 'cmdline'}

    # try to resolve 'links', 'cmdline', an unknown one
    unresolved_requires = {'links', 'cmdline', 'foo'}
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved_requires, all_fact_subsets)


# Generated at 2022-06-22 22:43:28.306541
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    f = BaseFactCollector()
    assert f.name is None
    assert f.required_facts == set()
    assert f.collectors == []
    assert f.fact_ids == set([None])


# Generated at 2022-06-22 22:43:38.941117
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    class CollectorA(BaseFactCollector):
        _fact_ids = set([
            'A_id',
        ])
        required_facts = set([])
    class CollectorB(BaseFactCollector):
        _fact_ids = set([
            'B_id',
        ])
        required_facts = set(['A_id'])
    class CollectorC(BaseFactCollector):
        _fact_ids = set([
            'C_id',
        ])
        required_facts = set(['X_id'])
    all_fact_subsets = {
        'A_id': [
            CollectorA,
        ],
        'B_id': [
            CollectorB,
        ],
        'C_id': [
            CollectorC,
        ],
    }

    assert find_unres

# Generated at 2022-06-22 22:43:43.933623
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    module = None
    namespace = None

    class TestCollector(BaseFactCollector):
        pass

    instance = TestCollector(module=module, namespace=namespace)
    assert instance.namespace is None


# Generated at 2022-06-22 22:43:53.619503
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from unittest import TestCase

    class TestCollector(BaseFactCollector):
        pass

    class TestCollector2(BaseFactCollector):
        pass

    class TestCollector3(BaseFactCollector):
        pass

    class TestCollector4(BaseFactCollector):
        pass

    TestCollector.name = 'test_name'
    TestCollector2.name = 'test_name'
    TestCollector3.name = 'test_name3'
    TestCollector4.name = 'test_name4'

    all_fact_subsets = defaultdict(set)
    all_fact_subsets[TestCollector.name].add(TestCollector)
    all_fact_subsets[TestCollector.name].add(TestCollector2)

# Generated at 2022-06-22 22:43:59.294839
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    _collectors = []
    _namespace=None
    fact_ids = set([])
    fact_ids.update(set([]))
    facts_dict = {}
    from ansible.module_utils.facts import timeout
    bfc = BaseFactCollector(collectors=_collectors, namespace=_namespace)
    # Set up parameter values
    module = None
    collected_facts = None
    actual_result = bfc.collect(module=module, collected_facts=collected_facts)
    assert actual_result == facts_dict


# Generated at 2022-06-22 22:44:10.537011
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    Test the function collector_classes_from_gather_subset
    '''
    class TestCollector(BaseFactCollector):
        name = 'test'
    class TestCollector2(BaseFactCollector):
        name = 'test2'
    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = ['test2']

    # gather all
    selected_collector_classes = collector_classes_from_gather_subset(
        all_collector_classes=[TestCollector, TestCollector2, TestCollector3],
        gather_subset=['test', 'test2', 'test3']
    )
    assert selected_collector_classes == [TestCollector, TestCollector2, TestCollector3]

    # gather test
    selected_collect

# Generated at 2022-06-22 22:44:20.905864
# Unit test for function tsort
def test_tsort():
    ''' Unit test for tsort
    '''
    unsorted_map = {'1': set(['7']),
                    '2': set(['5']),
                    '3': set(['6', '7']),
                    '4': set(['5']),
                    '5': set(['6']),
                    '6': set(['7']),
                    '7': set([])}

    sorted_list = tsort(unsorted_map)

    assert sorted_list == [('7', set([])), ('5', set(['7'])), ('6', set(['7'])), ('4', set(['5'])), ('2', set(['5'])), ('3', set(['6', '7'])), ('1', set(['7']))]

    # Test a cyclic graph
    uns

# Generated at 2022-06-22 22:44:30.971223
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector

    # Test for all collectors
    collectors_for_platform = set(collector.FACT_COLLECTOR_PLUGINS)
    assert set(build_fact_id_to_collector_map(collectors_for_platform)[0]) == set(collector.ALL_FACT_COLLECTORS)

    # Test for bareos - only 1 collector
    collectors_for_platform = set()
    collectors_for_platform.add(collector.FACT_COLLECTOR_PLUGINS[0])
    assert set(build_fact_id_to_collector_map(collectors_for_platform)[0]) == set(['bareos'])



# Generated at 2022-06-22 22:44:32.987776
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  assert BaseFactCollector().collect() == {}

# Generated at 2022-06-22 22:44:41.167238
# Unit test for function get_collector_names
def test_get_collector_names():
    # Run the unit tests for this function
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts import get_collector_names
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collectors import PlatformFactCollector

    # create data for the aliases map
    aliases_fdict = defaultdict(set)
    aliases_fdict['hardware'].update(['devices', 'dmi', 'system'])
    aliases_fdict['network'].update(['interfaces', 'default_ipv4'])

    # Tests for get_collector_names
    # test_get_collector_names_all: positive test for 'all'
    gather_subset_all = ['all']
    additional_subsets_

# Generated at 2022-06-22 22:44:50.444112
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class SampleCollectorA(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector_a'

    class SampleCollectorB(BaseFactCollector):
        _platform = 'Darwin'
        name = 'collector_b'

    class SampleCollectorC(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector_c'

    collector_a = SampleCollectorA()
    collector_b = SampleCollectorB()
    collector_c = SampleCollectorC()

    all_collector_classes = [SampleCollectorA, SampleCollectorB, SampleCollectorC]
    compat_platforms = [{'system': 'Linux'}]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

# Generated at 2022-06-22 22:45:01.327879
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collectors.linux
    import ansible.module_utils.facts.collectors.generic
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.darwin

    class FakeLinux(object):
        _platform = 'Linux'

    platform_info = dict(system='Linux', kernel='2.6.32', release='Manjaro Linux', version='Manjaro Linux', machine='x86_64', processor='x86_64')
    compat_platforms = (platform_info, )

# Generated at 2022-06-22 22:45:02.566803
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    assert type(CycleFoundInFactDeps()) is CycleFoundInFactDeps


# Generated at 2022-06-22 22:45:11.237266
# Unit test for function build_dep_data
def test_build_dep_data():
    class MyCollectorA(BaseFactCollector):
        name = 'A'
        required_facts = ['B']

    class MyCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = ['C']

    class MyCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = ['B']

    all_fact_subsets = defaultdict(list)
    all_fact_subsets[MyCollectorA.name].append(MyCollectorA)
    all_fact_subsets[MyCollectorB.name].append(MyCollectorB)
    all_fact_subsets[MyCollectorC.name].append(MyCollectorC)

    collector_names = ['A', 'B', 'C']


# Generated at 2022-06-22 22:45:23.499365
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # create requirements and dependencies graph
    class CollectorA(BaseFactCollector):
        name = 'name-a'

    class CollectorB(BaseFactCollector):
        name = 'name-b'
        required_facts = set(['name-a'])

    class CollectorC(BaseFactCollector):
        name = 'name-c'
        required_facts = set(['name-b', 'name-a'])

    class CollectorD(BaseFactCollector):
        name = 'name-d'

    class CollectorE(BaseFactCollector):
        name = 'name-e'

    class CollectorF(BaseFactCollector):
        name = 'name-f'
        required_facts = set(['name-d'])

    class CollectorG(BaseFactCollector):
        name = 'name-g'
        required_facts

# Generated at 2022-06-22 22:45:28.255539
# Unit test for function tsort
def test_tsort():
    dep_map = defaultdict(set)
    dep_map['A'] = set('B')
    dep_map['B'] = set('C')
    dep_map['C'] = set()
    sorted_list = tsort(dep_map)
    assert sorted_list == [('C', set()), ('B', set('C')), ('A', set('B'))]



# Generated at 2022-06-22 22:45:35.814618
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector import LinuxFactCollector, OpenBSDFactCollector, DarwinFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector


# Generated at 2022-06-22 22:45:45.654180
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import platform
    from ansible.module_utils.facts import collector

    class BaseFactCollector:
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

    class A(BaseFactCollector):
        name = 'A'
        _fact_ids = {
            'A',
            'AA',
        }

    class B(BaseFactCollector):
        name = 'B'
        _fact_ids = {
            'B',
            'BB',
        }

    class C(BaseFactCollector):
        name = 'C'
        _fact_ids = {
            'C',
            'CC',
        }

    class D(BaseFactCollector):
        name = 'D'

# Generated at 2022-06-22 22:45:49.354135
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(UnresolvedFactDep) as excinfo:
        raise UnresolvedFactDep("test message")
    assert str(excinfo.value) == "test message"



# Generated at 2022-06-22 22:45:59.627951
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collector
    all_collector_classes = ansible.module_utils.facts.collector.get_collector_classes(
        get_all_collector_classes=True)

    # retrieve the map, and also the aliases_map
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

    # for each fact_id, verify that it references the same collector as its primary_name
    for fact_id, collector_classes in fact_id_to_collector_map.items():
        primary_name = aliases_map.get(fact_id, None)


# Generated at 2022-06-22 22:46:11.281612
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collect1(object):
        _fact_ids = ['collect1', 'collect_dmi']
    class Collect2(object):
        _fact_ids = ['collect_dmi']

    all_fact_subsets = {'collect1': [Collect1], 'collect_dmi': [Collect2], 'all': ['none']}

    # Collect1 should be selected because it also provides collect_dmi
    result = select_collector_classes(['collect1', 'collect_dmi'], all_fact_subsets)
    assert result == [Collect1]
    # Collect2 should be selected because it's the only one providing collect_dmi
    result = select_collector_classes(['collect_dmi'], all_fact_subsets)
    assert result == [Collect2]
    # Collect1 should not be selected if it's

# Generated at 2022-06-22 22:46:16.310849
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    exc = UnresolvedFactDep('foo')
    assert str(exc) == "can't resolve fact dep(s): foo"

    exc = UnresolvedFactDep(['foo', 'bar'])
    assert str(exc) == "can't resolve fact dep(s): ['foo', 'bar']"



# Generated at 2022-06-22 22:46:19.350003
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(('missing', 'test'))
    except CollectorNotFoundError as e:
        assert e.args[0] == 'test'



# Generated at 2022-06-22 22:46:27.307971
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    gather_subset = ['min', 'aix']
    minimal_gather_subset = ['min']
    valid_subsets = frozenset(['aix', 'min', 'ohai'])

    aliases_map = defaultdict(set)
    aliases_map['aix'].update(['aix'])
    aliases_map['ohai'].update(['ohai_plugin'])

    class AixCollector(BaseFactCollector):
        _platform = 'Aix'
        name = 'aix'
        required_facts = set()

    class OhaiCollector(BaseFactCollector):
        _platform = 'Generic'
        name = 'ohai'
        required_facts = set()

    class MinCollector(BaseFactCollector):
        _platform = 'Generic'
        name = 'min'


# Generated at 2022-06-22 22:46:29.063615
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    c = BaseFactCollector()
    f = c.collect()
    assert f == {}


# Generated at 2022-06-22 22:46:37.221754
# Unit test for function tsort
def test_tsort():
    tsort_data = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        tsort(tsort_data)
        raise AssertionError('tsort did not detect a cycle')
    except CycleFoundInFactDeps:
        pass

    tsort_data = {
        'a': set(['b']),
        'b': set(),
        'c': set(['a']),
    }
    sorted_list = tsort(tsort_data)
    assert len(sorted_list) == 3
    assert ['b', 'a', 'c'] == [sorted_item[0] for sorted_item in sorted_list]



# Generated at 2022-06-22 22:46:39.542242
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    assert True is not False


# Generated at 2022-06-22 22:46:50.693145
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['a'], valid_subsets=frozenset(['a', 'b'])) == set(['a'])
    assert get_collector_names(gather_subset=['a', '!b'], valid_subsets=frozenset(['a', 'b'])) == set(['a'])
    assert get_collector_names(gather_subset=['a', '!b'], valid_subsets=frozenset(['b'])) == set(['b'])
    assert get_collector_names(gather_subset=['!b', 'a'], valid_subsets=frozenset(['b'])) == set(['b'])

# Generated at 2022-06-22 22:46:54.323070
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(123)
    except CollectorNotFoundError as e:
        assert e.args == (123,)
        assert str(e) == '123'


# Generated at 2022-06-22 22:46:55.948802
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors == []



# Generated at 2022-06-22 22:46:58.872193
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    one = UnresolvedFactDep('one')
    assert one.fact_name == 'one'



# Generated at 2022-06-22 22:47:09.833688
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector

    class MyTestCollector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'MyTestCollector1'

    class MyTestCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'MyTestCollector2'

    class MyTestCollector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'MyTestCollector3'

    class MyTestCollector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'MyTestCollector4'

    class MyTestCollector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'MyTestCollector5'

    # Register fact collectors for unit testing

# Generated at 2022-06-22 22:47:11.044874
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("test_Facts")
    except UnresolvedFactDep as e:
        s = str(e)
        assert s == "test_Facts"



# Generated at 2022-06-22 22:47:18.157881
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    import unittest
    from unittest.mock import Mock, call, patch

    class TestFactNameSpace:
        def __init__(self, transform):
            self.transform = transform

    class TestFactCollector(BaseFactCollector):
        pass

    class TestFactCollectorReturningDict(TestFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'a test fact'}

    class TestFactCollectorReturningNone(TestFactCollector):
        def collect(self, module=None, collected_facts=None):
            return None


# Generated at 2022-06-22 22:47:29.353890
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class A(BaseFactCollector):
        _fact_ids = set([
            'foo',
            'bar',
        ])
        name = 'a'

    class B(BaseFactCollector):
        _fact_ids = set([
            'bar',
            'baz',
        ])
        name = 'b'

    class C(BaseFactCollector):
        _fact_ids = set([
            'foo',
            'baz',
        ])
        name = 'c'

    class D(BaseFactCollector):
        _fact_ids = set([
            'fud',
            'dras',
        ])
        name = 'd'

    class B2(BaseFactCollector):
        _fact_ids = set([
            'foo',
            'baz',
        ])

# Generated at 2022-06-22 22:47:41.618033
# Unit test for function tsort
def test_tsort():
    # graph 1: just a straight list
    dep_map1 = dict(
        a=set(['b']),
        b=set(['c']),
        c=set(['d']),
        d=set(),
    )
    # graph 2: straight list with a loop on the end
    dep_map2 = dict(
        a=set(['b']),
        b=set(['c']),
        c=set(['d']),
        d=set(['a']),
    )
    # graph 3: multiple entries with a loop on the end

# Generated at 2022-06-22 22:47:46.350749
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fn = 'an_unresolved_fact_name'
    fg = 'an_unresolved_fact_group'
    e = UnresolvedFactDep(fn, fg)
    assert e.fact_name == fn
    assert e.fact_group == fg



# Generated at 2022-06-22 22:47:56.062644
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_all_fact_subsets(dict(), 'all', [])
    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'virtual'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'virtual', 'system'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'virtual', 'system', 'distribution'], all_fact_subsets) == set()

    test_no_system = 'network'
    assert find_unresolved_requires([test_no_system], all_fact_subsets) == set()

    test

# Generated at 2022-06-22 22:48:09.151011
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    """
    Unit test for constructor of class UnresolvedFactDep.
    """
    def _test_UnresolvedFactDep(fact_name, expected_message):
        try:
            raise UnresolvedFactDep(fact_name)
        except UnresolvedFactDep as ex:
            assert str(ex) == expected_message
        else:
            assert False, "UnresolvedFactDep not raised"

    tests = [
        ('foo', 'UnresolvedFactDep("foo")'),
        ('bar baz', 'UnresolvedFactDep("bar baz")'),
        ('qux', 'UnresolvedFactDep("qux")'),
    ]

    for test in tests:
        yield _test_UnresolvedFactDep, test[0], test[1]



# Generated at 2022-06-22 22:48:09.679975
# Unit test for function build_dep_data
def test_build_dep_data():
    pass



# Generated at 2022-06-22 22:48:16.403306
# Unit test for function resolve_requires
def test_resolve_requires():
    # set up all_fact_subsets
    all_collector_classes = [FactCollectorA, FactCollectorB, FactCollectorC, FactCollectorD]
    all_fact_subsets = defaultdict(list)
    for cls in all_collector_classes:
        all_fact_subsets[cls.name].append(cls)
        for fact_id in cls._fact_ids:
            all_fact_subsets[fact_id].append(cls)

    # case: no unresolved requires, no new requires
    assert not resolve_requires([], all_fact_subsets) != []

    # case: no unresolved requires, but new requires
    assert resolve_requires(set(['a']), all_fact_subsets) == set(['a'])

# Generated at 2022-06-22 22:48:22.296827
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test the various gather_subset combinations
    assert get_collector_names(gather_subset=None, valid_subsets=['hardware'], minimal_gather_subset=['hardware']) == frozenset(['hardware'])
    assert get_collector_names(gather_subset=['!min'], valid_subsets=['hardware'], minimal_gather_subset=['hardware']) == frozenset(['hardware'])
    assert get_collector_names(gather_subset=['!all'], valid_subsets=['hardware'], minimal_gather_subset=['hardware']) == frozenset(['hardware'])

# Generated at 2022-06-22 22:48:33.107436
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class DummyCollector:
        def __init__(self, name):
            self.name = name

    base = DummyCollector('base')
    base2 = DummyCollector('base')
    derived = DummyCollector('derived')
    derived2 = DummyCollector('derived')

    assert base != base2
    assert base != derived
    assert derived != derived2

    fact_id_to_collector_map = {
        'base': [base, base2],
        'derived': [derived, derived2],
    }

    result = select_collector_classes(['derived', 'base'], fact_id_to_collector_map)
    assert len(result) == 3
    assert base in result
    assert base2 in result
    assert derived in result



# Generated at 2022-06-22 22:48:37.682560
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector

    fact_collector = collector.BaseFactCollector()

    assert fact_collector.collectors == []
    assert fact_collector.namespace is None
    assert fact_collector.fact_ids == set([None])


# Generated at 2022-06-22 22:48:44.923986
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import tests.data.gather.mock_collectors as mock_collectors

    # Test: all collectors should be returned for 'all'
    collector_classes = collector_classes_from_gather_subset([mock_collectors.A,
                                                              mock_collectors.B,
                                                              mock_collectors.C],
                                                             gather_subset=['all'])
    assert collector_classes == [mock_collectors.A, mock_collectors.B, mock_collectors.C], 'all'

    # Test: nothing should be returned for 'all' except 'min'

# Generated at 2022-06-22 22:48:57.149287
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(
        ['a', 'b', 'c'],
        {
            'a': [object],
            'b': [object],
            'c': [object]
        }
    )
    assert dep_map == defaultdict(set, {
        'a': set(),
        'b': set(),
        'c': set()
    })

    class CollectorA(object):
        required_facts = ['c']
    class CollectorB(object):
        required_facts = ['a']
    class CollectorC(object):
        required_facts = ['b']


# Generated at 2022-06-22 22:49:04.452247
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('all', 'network'), gather_subset=['all']) == ('all', 'network')
    assert get_collector_names(valid_subsets=('all', 'network'), gather_subset=['!network']) == ('all',)
    assert get_collector_names(valid_subsets=('all', 'network'), gather_subset=['!network', 'network']) == ('all', 'network')
    assert get_collector_names(valid_subsets=('all', 'network'), gather_subset=[]) == ('all', 'network')
    assert get_collector_names(valid_subsets=('all', 'network'), gather_subset=['!all']) == ('network',)


# Generated at 2022-06-22 22:49:08.047629
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("msg")
    except CollectorNotFoundError as e:
        assert isinstance(e, KeyError)
        assert e.args[0] == "msg"



# Generated at 2022-06-22 22:49:17.950374
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_all_fact_subsets = {'a': [object()], 'b': [object()]}

    assert find_unresolved_requires(['a'], test_all_fact_subsets) == set()
    assert find_unresolved_requires(['a', 'b'], test_all_fact_subsets) == set()

    test_all_fact_subsets['c'] = [object()]
    assert find_unresolved_requires(['a', 'c'], test_all_fact_subsets) == set(['c'])
    assert find_unresolved_requires(['a', 'b', 'c'], test_all_fact_subsets) == set(['b', 'c'])


# Generated at 2022-06-22 22:49:23.157133
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # populate the collected_facts dict
    collected_facts_dict = dict()
    collected_facts_dict['mykey'] = 'myvalue'
    # create a dummy class that inherits BaseFactCollector
    class mytest_collector(BaseFactCollector):
        pass
    mytest_collector = mytest_collector()
    # create a dummy module
    module = dict()
    # test that the dictionary collect_with_namespace returns is equal to collected_facts_dict
    assert mytest_collector.collect_with_namespace(module=module, collected_facts=collected_facts_dict) == collected_facts_dict

# Generated at 2022-06-22 22:49:27.002517
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    c = BaseFactCollector()
    assert c.namespace == None
    assert c.collectors == []
    assert c.fact_ids == set([c.name])



# Generated at 2022-06-22 22:49:29.670035
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    ''' Unit test for constructor of class CycleFoundInFactDeps '''
    cycle = CycleFoundInFactDeps()
    assert isinstance(cycle, CycleFoundInFactDeps)


# Generated at 2022-06-22 22:49:40.106952
# Unit test for function tsort
def test_tsort():
    test_dep_map = {'a': ['b', 'c'], 'c': ['b']}
    assert tsort(test_dep_map) == [('a', {'b', 'c'}), ('c', {'b'})]

    test_dep_map = {'a': ['b', 'c'], 'c': ['b', 'd']}
    assert tsort(test_dep_map) == [('a', {'b', 'c'}), ('d', set()), ('c', {'b'})]

    test_dep_map = {'a': ['b'], 'b': ['a']}

# Generated at 2022-06-22 22:49:48.734257
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Test1(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b'])
        name = 'test1'
    class Test2(BaseFactCollector):
        _fact_ids = frozenset(['c', 'd', 'e'])
        name = 'test2'

    collectors = [Test1, Test2]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)

    assert set(fact_id_to_collector_map['test1']) == set([Test1])
    assert set(fact_id_to_collector_map['test2']) == set([Test2])
    assert set(fact_id_to_collector_map['a']) == set([Test1])
   

# Generated at 2022-06-22 22:49:59.587758
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    # Testing a subclass of BaseFactCollector without namespace attribute
    class WithoutNamespace(BaseFactCollector):
        name = "without_namespace"

        def collect(self, module=None, collected_facts=None):
            return {'test_key': 'test_value'}

    with_namespace = WithoutNamespace()
    facts_dict = with_namespace.collect_with_namespace()
    assert facts_dict == {"test_key": "test_value"}

    # Testing a subclass of BaseFactCollector with namespace attribute
    class WithNamespace(BaseFactCollector):
        name = "with_namespace"

        def collect(self, module=None, collected_facts=None):
            return {'test_key': 'test_value'}


# Generated at 2022-06-22 22:50:08.395122
# Unit test for function get_collector_names
def test_get_collector_names():
    assert {'a', 'c', 'd'} == get_collector_names(
        valid_subsets=frozenset(['a', 'b', 'c', 'd']),
        minimal_gather_subset=frozenset(['a']),
        gather_subset=['!a', '!b', 'c', 'd'])

    assert {'b', 'c', 'd'} == get_collector_names(
        valid_subsets=frozenset(['a', 'b', 'c', 'd']),
        minimal_gather_subset=frozenset(['a']),
        gather_subset=['min', '!b', 'c', 'd'])


# Generated at 2022-06-22 22:50:16.736415
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': [], 'b': []}
    new_names = resolve_requires(['a', 'c'], all_fact_subsets)
    assert new_names == {'a'}

    all_fact_subsets = {'a': [], 'b': []}
    with pytest.raises(UnresolvedFactDep):
        new_names = resolve_requires(['c'], all_fact_subsets)



# Generated at 2022-06-22 22:50:23.917234
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    my_collector_list = [collectors.AIXFactCollector]
    my_platform_list = [{'system': 'AIX'}]
    # create a list of all classes in collectors.
    my_all_collector_classes = []
    for name in dir(collectors):
        if not name.endswith("FactCollector"):
            continue
        my_all_collector_classes.append(getattr(collectors, name))
    my_collectors = find_collectors_for_platform(my_all_collector_classes,
                                                 my_platform_list)
    assert my_collectors == set([collectors.AIXFactCollector])



# Generated at 2022-06-22 22:50:25.446980
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    dir(BaseFactCollector)
    BaseFactCollector()



# Generated at 2022-06-22 22:50:34.154548
# Unit test for function resolve_requires
def test_resolve_requires():
    class_map = {}
    all_fact_subsets = defaultdict(list)

    def mk_collector(name, requires=None):
        cls = type('Collector', (BaseFactCollector,),
                   {'name': name, 'required_facts': requires})
        class_map[name] = cls
        all_fact_subsets[name].append(cls)
        return cls

    # create these collectors:
    #                                                    +-----+
    #                                                    |  D  |
    #                                                    +--+--+
    #                                                       ^
    #                                                       |
    #      +-----+                                           |
    #      |  A  |                                           |
    #      +--+--+                                           |
    #         ^                                              |
    #         |                                

# Generated at 2022-06-22 22:50:44.906830
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        required_facts = ('a', 'b')

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        required_facts = ('c',)

    all_fact_subsets = {
        'test': [TestCollector],
        'test2': [TestCollector2],
    }

    collector_names = ('test', 'test2')

    dep_data = build_dep_data(collector_names, all_fact_subsets)

    assert dep_data['test'] == set(['a', 'b'])
    assert dep_data['test2'] == set(['c'])



# Generated at 2022-06-22 22:50:57.451681
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets=('hardware', 'network')
    minimal_gather_subset=('hardware',)
    aliases_map=defaultdict(set, {'hardware': 'devices,dmi'})

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=('hardware',),
                               aliases_map=aliases_map) == {'hardware'}

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=('!hardware',),
                               aliases_map=aliases_map) == {'network'}

    assert get

# Generated at 2022-06-22 22:51:07.980060
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Check behaviour of method collect_with_namespace when `collect` returns
    # None
    module = None
    collected_facts = None
    collector = BaseFactCollector()
    res = collector.collect_with_namespace(module, collected_facts)
    assert res == {}

    # Check behaviour of method collect_with_namespace when `collect` returns
    # something other than None
    module = None
    collected_facts = None
    collector = BaseFactCollector()
    collector.collect = lambda module=None, collected_facts=None: ["foo", "bar"]
    res = collector.collect_with_namespace(module, collected_facts)
    assert res == ["foo", "bar"]

# Generated at 2022-06-22 22:51:10.989413
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    c = CycleFoundInFactDeps('c')
    assert type(c) is CycleFoundInFactDeps
    assert str(c) == 'c'


# Generated at 2022-06-22 22:51:21.970392
# Unit test for function tsort
def test_tsort():
    import random

    all_tests = []

    tests_with_cycles = [
        ('a', ('b', 'd')),
        ('e', ('a', 'c')),
        ('d', ('b', 'c')),
        ('c', ('a', 'd')),
        ('b', ('c', 'e')),
    ]
    all_tests.append(tests_with_cycles)

    tests_with_no_cycles = [
        ('b', ('a', 'e')),
        ('e', ('d', 'c')),
        ('c', ('a', 'b')),
        ('d', ('b', 'c')),
        ('a', ('d', 'e')),
    ]
    all_tests.append(tests_with_no_cycles)


# Generated at 2022-06-22 22:51:30.129083
# Unit test for function resolve_requires
def test_resolve_requires():
    # Test that a resolve requires works with a single dependency
    all_fact_subsets = {'ansible_os_family': [], 'ansible_lsb': []}

    collector_names = {'ansible_os_family'}
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved_requires == {'ansible_lsb'}

    resolved_requires = resolve_requires(unresolved_requires, all_fact_subsets)
    assert resolved_requires == {'ansible_lsb'}

    collected_names = collector_names.union(resolved_requires)
    assert collected_names == {'ansible_os_family', 'ansible_lsb'}

    # Test that resolve_requires works with multiple levels of dependency
    all_fact_

# Generated at 2022-06-22 22:51:42.432753
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    class BaseFactCollector_test():
        _fact_ids = set()

        _platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors or []
            self.namespace = namespace
            self.fact_ids = set([self.name])
            self.fact_ids.update(self._fact_ids)

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

        def _transform_name(self, key_name):
            if self.namespace:
                return self.namespace.transform(key_name)
            return key_name


# Generated at 2022-06-22 22:51:45.346910
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    x = CollectorNotFoundError('foo')
    assert str(x) == 'Collector foo not found'
    assert repr(x) == 'CollectorNotFoundError(\'foo\')'



# Generated at 2022-06-22 22:51:55.656118
# Unit test for function get_collector_names
def test_get_collector_names():
    '''test_get_collector_names'''
    # new behavior: 'all' includes all the valid subsets
    # and 'min' (a new subset) includes the minimal subsets
    # 'all' is the default subset, so if it's not specified explicitly
    # and you have gathers like '!min', you have an empty set.
    assert get_collector_names(valid_subsets=frozenset(['a', 'b', 'c']),
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                               gather_subset=['hardware']) == frozenset(['hardware', 'devices', 'dmi'])

# Generated at 2022-06-22 22:51:59.463797
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():  # pylint: disable=invalid-name
    '''Tests __init__ of class CollectorNotFoundError'''

    collector = CollectorNotFoundError("missing_collector")
    assert collector.message == collector.args[0]


# Generated at 2022-06-22 22:52:12.340712
# Unit test for function get_collector_names
def test_get_collector_names():
    import pytest
    # Not using set literals to ensure python2.6 compat
    valid_subsets = frozenset(['network', 'foo'])
    minimal_gather_subset = frozenset(['bar'])
    aliases_map = defaultdict(set)
    aliases_map.update({'hardware': {'devices', 'dmi'}})

    expected = frozenset(['bar', 'foo'])
    result = get_collector_names(valid_subsets=valid_subsets,
                                 minimal_gather_subset=minimal_gather_subset,
                                 gather_subset = [],
                                 aliases_map=aliases_map)
    assert result == expected

    expected = frozenset(['bar', 'foo'])

# Generated at 2022-06-22 22:52:14.849290
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'test'



# Generated at 2022-06-22 22:52:22.941155
# Unit test for function tsort
def test_tsort():
    # Function to convert input to a more useful form
    def tsort_input_convert(inp):
        dep_map = {}
        for k, v in inp.items():
            dep_map[k] = set(v)
        return dep_map

    # list of tuples of (input, expected output)

# Generated at 2022-06-22 22:52:33.926743
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.virtual import Virtual
    from ansible.module_utils.facts.collector.services import Services
    from ansible.module_utils.facts.collector.system import System
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.collector.distribution import Distribution
    from ansible.module_utils.facts.collector.config import Config


# Generated at 2022-06-22 22:52:44.370676
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test function to find_unresolved_requires'''
    class TestCollector(BaseFactCollector):
        # pylint: disable=missing-docstring
        name = 'testcollector'
        required_facts = set(['req1'])

    collector1 = TestCollector()
    collector2 = TestCollector()
    collector3 = TestCollector()
    all_fact_subsets = {'collector1': [collector1],
                        'collector3': [collector3],
                        'collector2': [collector2],
                        'collector4': [collector3]}

    collector_names = ['collector1', 'collector2', 'collector3']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    collector_

# Generated at 2022-06-22 22:52:55.053809
# Unit test for function get_collector_names
def test_get_collector_names():
    import types

    aliases_map = {'hardware': {'bios', 'dmi', 'devices'}}
    gather_subset = ['!network', 'hardware']
    result = get_collector_names(
        aliases_map=aliases_map,
        gather_subset=gather_subset,
        valid_subsets=frozenset(['network', 'hardware', 'virtual', 'min']),
        minimal_gather_subset=frozenset(['dmi']),
    )
    assert isinstance(result, set)
    assert result == {'hardware', 'dmi'}

    aliases_map = {}
    gather_subset = ['!network', 'min']

# Generated at 2022-06-22 22:52:56.570797
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert isinstance(BaseFactCollector(), BaseFactCollector)


# Generated at 2022-06-22 22:52:58.020161
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    pass



# Generated at 2022-06-22 22:53:07.066130
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'A': [CollectorSubclass],
        'B': [CollectorSubclass],
        'C': [CollectorSubclass],
        'D': [CollectorSubclass],
        'E': [CollectorSubclass],
        'F': [CollectorSubclass],
    }
    assert set(find_unresolved_requires(['A', 'B'], all_fact_subsets)) == set()

    class CollectorRequiresUnknownSubset(CollectorSubclass):
        name = 'A'
        required_facts = {'Z'}

    all_fact_subsets['A'] = [CollectorRequiresUnknownSubset]
    assert set(find_unresolved_requires(['A'], all_fact_subsets)) == set(['Z'])


# Generated at 2022-06-22 22:53:16.622314
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector4'

    plat_info = {'system': 'Linux'}
    plat_info_generic = {'system': 'Generic'}
    plat_info_windows = {'system': 'Windows'}
    all_collector_classes = [Collector1, Collector2, Collector3, Collector4]
    compat_platforms = [plat_info]


# Generated at 2022-06-22 22:53:26.697411
# Unit test for function get_collector_names
def test_get_collector_names():

    # Trivial
    assert get_collector_names() == set(['all'])
    assert get_collector_names(gather_subset=['all']) == set(['all'])
    assert get_collector_names(gather_subset=['network']) == set(['network'])
    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['all'])) == set(['all'])
    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['network'])) == set(['network'])