

# Generated at 2022-06-22 22:43:27.692116
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A_collector(BaseFactCollector):
        name = 'A1'
        _fact_ids = set(['A1', 'A1_1', 'A1_2'])

    class B_collector(BaseFactCollector):
        name = 'B1'
        _fact_ids = set(['B1', 'B1_1', 'B1_2'])

    class C_collector(BaseFactCollector):
        name = 'C1'
        _fact_ids = set(['C1', 'C1_1', 'C1_2'])

    test_collectors = [A_collector, B_collector, C_collector]

    test_platform_info = {'system': 'Linux'}

# Generated at 2022-06-22 22:43:35.169348
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['fips', 'fqdn']
    all_fact_subsets = {
        'fips': [FipsCollector, FipsCollectorAlternative],
        'fqdn': [FqdnCollector],
        'real_fqdn': [RealFqdnCollector],
        'a': [FactACollector],
        'd': [FactDCollector],
        'b': [FactBCollector],
        'c': [FactCCollector],
    }

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    collector_names = ['real_fqdn']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['fqdn'])

    collector_names

# Generated at 2022-06-22 22:43:47.311530
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [AllFoo],
                        'b': [AllBar],
                        'c': [AllBaz],
                        'd': [AllDoe],
                        'e': [AllHoo],
                        'f': [AllFoo]}

    class AllGood(BaseFactCollector):
        name = 'all_good'
        required_facts = set()

    class AllBad(BaseFactCollector):
        name = 'all_bad'
        required_facts = ['all_missing']

    assert not find_unresolved_requires(['all_good'], all_fact_subsets)
    assert find_unresolved_requires(['all_bad'], all_fact_subsets) == set(['all_missing'])

# Generated at 2022-06-22 22:43:57.386689
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        _fact_ids = frozenset(['a'])
        name = 'a'

    class B(BaseFactCollector):
        _fact_ids = frozenset(['b'])
        name = 'b'

    class C(BaseFactCollector):
        _fact_ids = frozenset(['c1', 'c2', 'c3'])
        name = 'c'

    class D(BaseFactCollector):
        _fact_ids = frozenset(['d1', 'd2'])
        name = 'd'

    class NoPlatformMatch(BaseFactCollector):
        _fact_ids = frozenset(['a'])
        name = 'a'
        @classmethod
        def platform_match(cls, platform_info):
            return None



# Generated at 2022-06-22 22:44:08.750726
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # create a bunch of class objects that are instances of BaseFactCollector,
    # each with a unique name.
    all_collectors = [BaseFactCollector() for _ in range(10)]
    for collector in all_collectors:
        collector.name = collector.__class__.__name__

    # add a class instance of BaseFactCollector that exists twice
    dup_collector = BaseFactCollector()
    dup_collector.name = 'dup_collector'
    all_collectors.extend([dup_collector, dup_collector])


# Generated at 2022-06-22 22:44:19.205795
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _platform = 'linux'
        name = 'test_collector'

    collector_classes = [TestCollector]

    # Test the linux case
    plat = {'system': platform.system(), 'release': platform.dist()[1], 'machine': platform.machine()}
    compat_platforms = [plat]
    result_collectors = find_collectors_for_platform(collector_classes, compat_platforms)
    assert [TestCollector.name] == [x.name for x in result_collectors]

    # Test the non-linux case
    plat['system'] = 'Darwin'
    compat_platforms = [plat]
    result_collectors = find_collectors_for_platform(collector_classes, compat_platforms)

# Generated at 2022-06-22 22:44:20.746477
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd = UnresolvedFactDep('error')
    assert ufd.args == ('error',)



# Generated at 2022-06-22 22:44:25.813332
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    class MockCollectorNotFoundError(CollectorNotFoundError):
        pass

    e = MockCollectorNotFoundError("foo")
    assert(str(e) == "foo")
    assert(repr(e) == "MockCollectorNotFoundError(foo)")



# Generated at 2022-06-22 22:44:36.151969
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts import collector

    class FakeCollector(BaseFactCollector):
        name = 'fake'

        def collect(self, module=None, collected_facts=None):
            return {'a': '1', 'b': '2', 'c': '3'}

    bc = FakeCollector()

    # Test without namespace
    result = bc.collect_with_namespace()
    assert result == {'a': '1', 'b': '2', 'c': '3'}

    # Test with namespace
    class TestNamespace:
        def transform(self, key):
            return 'fake_%s' % key

    ns = TestNamespace()
    bc = FakeCollector(namespace=ns)
    result = bc

# Generated at 2022-06-22 22:44:38.395579
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    assert UnresolvedFactDep('test').message == 'test'



# Generated at 2022-06-22 22:44:46.489240
# Unit test for function tsort
def test_tsort():
    assert tsort({
        'a': {'b', 'c'},
        'b': {'c', 'd'},
        'c': set(),
        'd': {'e'},
        'e': {'c', 'b'},
    }) == [
        ('c', set()),
        ('d', {'e'}),
        ('e', {'c', 'b'}),
        ('a', {'b', 'c'}),
        ('b', {'c', 'd'}),
    ]



# Generated at 2022-06-22 22:44:53.034016
# Unit test for function get_collector_names
def test_get_collector_names():
    # pylint: disable=unused-variable
    def test(gather_subset, valid_subsets, minimal_gather_subset, aliases_map, expected_result, platform_info=None):
        '''simple unit test for get_collector_names'''
        result = sorted(get_collector_names(gather_subset=gather_subset,
                                            valid_subsets=valid_subsets,
                                            minimal_gather_subset=minimal_gather_subset,
                                            aliases_map=aliases_map,
                                            platform_info=platform_info))
        assert result == expected_result, 'FAILED: gather_subset=%s\nexpected=%s\nactual=%s' % (gather_subset, expected_result, result)



# Generated at 2022-06-22 22:45:02.641952
# Unit test for function tsort
def test_tsort():
    # based on the example from http://en.wikipedia.org/wiki/Topological_sorting
    input_graph_map = {
        '5': set(['11']),
        '7': set(['11', '8']),
        '3': set(['8', '10']),
        '11': set(['2', '9', '10']),
        '8': set(['9']),
        '2': set([]),
        '9': set([]),
        '10': set([]),
    }


# Generated at 2022-06-22 22:45:10.140812
# Unit test for function select_collector_classes
def test_select_collector_classes():
    '''Tests that select_collector_classes handles fact collector subsets correctly.'''

    from ansible.constants import FACT_SUBSET

    fact_id_to_collector_map = {
        'network': [object(), object()],
        'network_storage': [object()],
    }

    all_fact_subsets = {
        FACT_SUBSET['network']: fact_id_to_collector_map['network'],
        FACT_SUBSET['network_storage']: fact_id_to_collector_map['network_storage'],
    }

    # test all defined subsets
    collector_names = [FACT_SUBSET['network'], FACT_SUBSET['network_storage']]

# Generated at 2022-06-22 22:45:22.278535
# Unit test for function tsort
def test_tsort():
    # graph is acyclic
    dep = {'a': set(['b', 'e']),
           'c': set(['b', 'e']),
           'b': set(['f', 'e']),
           'f': set([]),
           'e': set([])}

    sorted_list = tsort(dep)
    assert sorted_list == [('e', set([])), ('f', set([])), ('b', {'e', 'f'}), ('a', {'b', 'e'}), ('c', {'b', 'e'})]

    # empty dep graph
    dep = {}
    assert tsort(dep) == []

    # graph with single node
    dep = {'a': set([])}
    assert tsort(dep) == [('a', set([]))]


# Generated at 2022-06-22 22:45:22.913127
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    pass


# Generated at 2022-06-22 22:45:33.192519
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = {'a1'}
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = {'b1'}
        name = 'b'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({CollectorA, CollectorB})

    assert fact_id_to_collector_map['a'][0] == CollectorA
    assert fact_id_to_collector_map['a1'][0] == CollectorA
    assert fact_id_to_collector_map['b'][0] == CollectorB
    assert fact_id_to_collector_map['b1'][0] == CollectorB


# Generated at 2022-06-22 22:45:44.397147
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    def check_platforms(expected_collectors, *compat_platforms):
        expected_collector_names = set([c.name for c in expected_collectors])
        found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
        found_collector_names = set([c.name for c in found_collectors])

        if found_collector_names != expected_collector_names:
            print("Expected: %s\n Got: %s" % (expected_collector_names, found_collector_names))
            return 1
        return 0

    class DummyCollector(BaseFactCollector):
        _fact_ids = set(['dummy'])
        name = 'dummy'

# Generated at 2022-06-22 22:45:50.558441
# Unit test for function tsort
def test_tsort():
    # is acyclic
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(),
    }
    sorted_list = tsort(dep_map)
    sorted_list_names = [x[0] for x in sorted_list]
    assert 'a' in sorted_list_names
    assert 'b' in sorted_list_names
    assert 'c' in sorted_list_names

    # is cyclic
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }

# Generated at 2022-06-22 22:45:54.649341
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with empty collector names, should return empty list
    assert find_unresolved_requires(set(), {}) == set()

    # create some collectors: A with no requires, B which requires A, C that requires B
    class A(BaseFactCollector):
        name = 'A'
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    # create a fact_subsets that has A, B, and C (but not D)
    fact_subsets = defaultdict(list)
    fact_subsets['A'].append(A)
    fact_subsets['B'].append(B)
    fact_subsets['C'].append

# Generated at 2022-06-22 22:45:59.542336
# Unit test for function build_dep_data

# Generated at 2022-06-22 22:46:11.283867
# Unit test for function tsort
def test_tsort():
    assert tsort({1: [2]}) == [(1, set([2])), (2, set())]
    assert tsort({1: [2], 2: [3]}) == [(1, set([2])), (2, set([3])), (3, set())]

    # Acyclic graph:
    graph = {
        1: [2, 3, 4],
        2: [4, 5],
        3: [5],
        4: [],
        5: [6],
        6: [],
    }

    # Node 1 always comes first
    assert tsort(graph)[0][0] == 1

    graph = {
        1: [2],
        2: [3],
        3: [1],
    }

# Generated at 2022-06-22 22:46:15.395170
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bc = BaseFactCollector()
    assert bc.name is None, 'name should be None'
    assert bc.collectors == [], 'collectors should be []'
    assert bc.namespace is None, 'namespace should be None'



# Generated at 2022-06-22 22:46:24.855881
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import defaultdict
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    all_fact_subsets = defaultdict(list)
    seen_collector_classes = set()
    collector_classes = []
    collector_classes.append(PlatformFactCollector)
    collector_classes.append(NetworkFactCollector)
    collector_classes.append(PlatformFactCollector)

    for collector_class in collector_classes:
        if collector_class not in seen_collector_classes:
            all_fact_subsets[collector_class.name].append(collector_class)
            seen_collector_classes.add(collector_class)


# Generated at 2022-06-22 22:46:33.928034
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector_without_collectors = BaseFactCollector()
    assert collector_without_collectors.collectors == []
    assert collector_without_collectors.fact_ids == set(['Generic'])
    assert collector_without_collectors.name == 'Generic'
    assert collector_without_collectors.required_facts == set()

    collector_with_collectors = BaseFactCollector(['this', 'that', 'other'])
    assert collector_with_collectors.collectors == ['this', 'that', 'other']

    assert collector_with_collectors.fact_ids == set(['Generic'])
    assert collector_with_collectors.name == 'Generic'
    assert collector_with_collectors.required_facts == set()



# Generated at 2022-06-22 22:46:43.916933
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class DummyFactCollector1(BaseFactCollector):
        pass

    class DummyFactCollector2(BaseFactCollector):
        name = 'test'
        _fact_ids = {'id1', 'id2'}
        required_facts = {'required1', 'required2'}

    class DummyFactCollector3(DummyFactCollector1):
        name = 'test3'
        required_facts = {'required3'}

    class DummyFactCollector4(DummyFactCollector2):
        name = 'test4'
        required_facts = {'required4'}

    # Test 1: BaseFactCollector
    facts_collector = BaseFactCollector()
    assert facts_collector.fact_ids == set()
    assert facts_collector.required_facts == set()

    #

# Generated at 2022-06-22 22:46:47.402753
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector_registry
    collector_data = build_dep_data(['all'], collector_registry)
    assert collector_data['all'] == set()
    assert collector_data['dns'] == set()
    assert collector_data['kernel'] == set()



# Generated at 2022-06-22 22:46:53.064367
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    try:
        import pkg_resources
    except ImportError:
        pkg_resources = None

    if pkg_resources:
        import ansible.plugins.loader

        plugin_pkg = 'ansible.plugins'
        plugin_pkg_list = list(pkg_resources.iter_entry_points('ansible.plugins'))
        plugin_pkgs = [x.name for x in plugin_pkg_list]

        plugin_pkgs.insert(0, 'ansible.plugins.builtin')
        plugin_pkgs.insert(0, 'ansible.plugins.core')
        plugin_pkgs.insert(0, 'ansible.plugins.cache')

        valid_subsets = set(['all', 'facter', 'ohai', 'hardware', 'network'])

# Generated at 2022-06-22 22:47:04.526808
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets={}
    collector_names=set()

    # test empty values
    result = select_collector_classes(collector_names, all_fact_subsets)
    assert set(result) == set()

    # test
    class Facta(BaseFactCollector):
        _fact_ids = {'y', 'b', 'a'}
        name = 'a'
    class Factb(BaseFactCollector):
        _fact_ids = {'z', 'b', 'a'}
        name = 'a'
    class Factc(BaseFactCollector):
        _fact_ids = {'b', 'a'}
        name = 'a'
    class Factd(BaseFactCollector):
        _fact_ids = {'b', 'a'}
        name = 'b'


# Generated at 2022-06-22 22:47:14.927054
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''Unit test for the collector_classes_from_gather_subset function'''
    from ansible.module_utils.facts import collectors

    all_fact_subsets, aliases_map = build_fact_id_to_collector_map(collectors)
    all_valid_subsets = frozenset(all_fact_subsets.keys())
    collector_classes = collector_classes_from_gather_subset(
        all_collector_classes=collectors,
        valid_subsets=all_valid_subsets,
        minimal_gather_subset=frozenset(('selinux',)),
        gather_subset=['all'],
        platform_info={'system': platform.system()},
        gather_timeout=10
    )
    assert collector_classes



# Generated at 2022-06-22 22:47:27.216224
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        CollectorProdA1,
        CollectorProdB1,
        CollectorDevA1,
        CollectorDevB1,
        CollectorGeneric1,
        CollectorGeneric2,
    ]
    platform_info = {'system': 'linux'}
    compat_platforms = [platform_info, {}]
    assert set(find_collectors_for_platform(all_collector_classes, compat_platforms)) == {
        CollectorProdA1,
        CollectorProdB1,
        CollectorDevA1,
        CollectorDevB1,
        CollectorGeneric1,
        CollectorGeneric2,
    }
    platform_info = {'system': 'Prod'}
    compat_platforms = [platform_info, {}]

# Generated at 2022-06-22 22:47:34.233317
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    all_fact_subsets = {'A': [],
                        'B': [],
                        'C': []}
    unresolved_requires = {'C'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == {'C'}

    unresolved_requires = {'B', 'C', 'D'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == {'B', 'C'}

    unresolved_requires = {'A', 'D'}
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved_requires, all_fact_subsets)



# Generated at 2022-06-22 22:47:37.624873
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    """Unit test for method collect_with_namespace of class BaseFactCollector"""
    # TODO: implement the test
    pass



# Generated at 2022-06-22 22:47:49.124339
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'foo': [], 'bar': []}

    new_names = resolve_requires(['foo'], all_fact_subsets)
    assert new_names == {'foo'}

    new_names = resolve_requires(['foo', 'bar'], all_fact_subsets)
    assert new_names == {'foo', 'bar'}

    new_names = resolve_requires(['foo', 'bzz'], all_fact_subsets)
    assert new_names == {'foo'}

    new_names = resolve_requires(['foo', 'bzz'], all_fact_subsets)
    assert new_names == {'foo'}

    new_names = resolve_requires(['bzz'], all_fact_subsets)
    assert new_names == set()

    all

# Generated at 2022-06-22 22:47:58.118868
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
        required_facts = ['a']
    class C(BaseFactCollector):
        name = 'c'
    class D(BaseFactCollector):
        name = 'd'
        required_facts = ['b', 'c']
    class E(BaseFactCollector):
        name = 'e'
        required_facts = ['f']
    collectors = {'a': [A, ], 'b': [B, ], 'c': [C, ], 'd': [D, ], 'e': [E, ], }

# Generated at 2022-06-22 22:48:02.287210
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps(['a', 'b', 'c'])
    assert exc.args == (['a', 'b', 'c'],)


# Generated at 2022-06-22 22:48:12.743352
# Unit test for function tsort
def test_tsort():
    def get_test_deps():
        return {
            'A': set(['B', 'C']),
            'B': set(['C', 'D']),
            'C': set(),
            'D': set(['B']),
        }

    def test_dep_map(dep_map):
        sorted_nodes = tsort(dep_map)
        for node, _ in sorted_nodes:
            for dep_node, dep_edges in sorted_nodes:
                if node in dep_edges:
                    raise ValueError('%s is dependent on %s in result %s' % (node, dep_node, sorted_nodes))

    test_dep_map(get_test_deps())

# Generated at 2022-06-22 22:48:22.387422
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'all': ['foo', 'bar', 'baz'],
    }
    unresolved = ['all', 'other']
    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == set(['all'])

    all_fact_subsets = {
        'all': ['foo', 'bar', 'baz'],
    }
    unresolved = ['other']
    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert not new_names



# Generated at 2022-06-22 22:48:24.296272
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('some_collector')
    except CollectorNotFoundError as e:
        assert 'some_collector' in str(e)



# Generated at 2022-06-22 22:48:32.179713
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # test good case
    class GoodLinuxCollector(BaseFactCollector):
        name = 'good'
        _fact_ids = {'good'}
        _platform = 'Linux'

    # test same name defined twice
    class BadLinuxCollector(BaseFactCollector):
        name = 'bad'
        _fact_ids = {'baddup'}
        _platform = 'Linux'

    # test same fact_id defined twice
    class BadDupLinuxCollector(BaseFactCollector):
        name = 'baddup'
        _fact_ids = {'bad', 'baddup'}
        _platform = 'Linux'

    platform_info = {'system': 'Linux'}


# Generated at 2022-06-22 22:48:37.182158
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert issubclass(BaseFactCollector, object)
    fc_base = BaseFactCollector(namespace="None")
    assert fc_base.namespace == "None"
    assert fc_base.fact_ids == set(['base_collector'])
    assert fc_base.collectors == []


# Generated at 2022-06-22 22:48:43.501972
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import fact_collector

    all_fact_subsets = fact_collector._get_all_fact_subsets()
    collector_names = all_fact_subsets.keys()
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    for k, v in dep_map.items():
        print(k, v)



# Generated at 2022-06-22 22:48:51.055835
# Unit test for function tsort

# Generated at 2022-06-22 22:49:01.570902
# Unit test for function tsort
def test_tsort():
    print("test_tsort")
    tsort_test_data = {
        'a': set(['b', 'd']),
        'b': set(['c', 'd']),
        'c': set(['d']),
        'd': set([]),
        'e': set(['b'])
    }
    try:
        tsort(tsort_test_data)
    except CycleFoundInFactDeps as e:
        print(e)
        assert False
    except KeyError as e:
        print(e)
        assert False

    tsort_test_data['b'].add('e')
    try:
        tsort(tsort_test_data)
    except CycleFoundInFactDeps as e:
        print(e)

# Generated at 2022-06-22 22:49:10.958784
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # setup the object to test
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    all_fact_subsets = collector.build_fact_id_to_collector_map(collector.find_collectors_for_platform(collector.collector_classes(), [platform.uname()]))
    collector_names = {'distribution'}
    # run the test
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    # verify
    assert len(unresolved) == 0
    assert 'machine_id' in unresolved



# Generated at 2022-06-22 22:49:21.425552
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import textwrap

    class Collector1(BaseFactCollector):
        name = "col1"
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = "col2"
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = "col3"
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = "col4"
        _fact_ids = set()

    collectors_for_platform = [Collector1, Collector2, Collector3, Collector4]


# Generated at 2022-06-22 22:49:33.734076
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.hardware.hw_memory import HardwareMemoryFactCollector
    from ansible.module_utils.facts.collector.hardware.hw_cpu import HardwareCPUFactCollector
    from ansible.module_utils.facts.collector.network.network_all import NetworkAllFactCollector

    def make_deps_from_fact_names(names):
        return set(names)

    collectors_for_platform = [HardwareMemoryFactCollector, HardwareCPUFactCollector, NetworkAllFactCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert HardwareMemoryFactCollector.name in fact_id_to_collector_map
    assert HardwareCPUFactCollector.name in fact

# Generated at 2022-06-22 22:49:44.641211
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Mocking the following classes only
    class EmptyCollectorClass:
        name = None
        # This fact collector is platform specific
        _platform = ''
        # This class is a sub class of the BaseFactCollector
        def __init__(self, collectors=None, namespace=None):
            pass

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    class DerivedCollectorClass(EmptyCollectorClass):
        _platform = 'Generic'
        name = 'derived'

    class CollectorClass(EmptyCollectorClass):
        _platform = 'Generic'
        name = 'CollectorClass'

    class DerivedClass(EmptyCollectorClass):
        _platform = 'Derived'
        name

# Generated at 2022-06-22 22:49:55.229397
# Unit test for function build_dep_data
def test_build_dep_data():
    '''
    This function unit tests build_dep_data()
    '''
    class DepCollector(BaseFactCollector):
        '''This is a fake fact class for testing build_dep_data()'''
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            '''Base class for things that collect facts.

            'collectors' is an optional list of other FactCollectors for composing.'''
            self.collectors = collectors or []

            # self.namespace is a object with a 'transform' method that transforms
            # the name to indicate the namespace (ie, adds a prefix or suffix).
            self.namespace = namespace

            self.fact_ids = set([self.name])
           

# Generated at 2022-06-22 22:50:00.989877
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector(namespace='myfacts')
    assert collector.namespace == 'myfacts'


# TODO/MAYBE: make a fact_ids property and remove the 'fact_ids' instance variable
# TODO/MAYBE: add a 'all_fact_ids' instance variable that just returns fact_ids from all collectors
# TODO/MAYBE: add a 'get_fact_by_id' and '_get_fact_by_id' method?


# Generated at 2022-06-22 22:50:09.421947
# Unit test for function tsort
def test_tsort():
    dep_map = {'c': set(), 'a': set(['c']), 'b': set(['c']), 'd': set(['a', 'b'])}
    tsort(dep_map)
    dep_map = {'c': set(), 'a': set(['c']), 'b': set(['c']), 'd': set(['a', 'b']), 'e': set(['f']), 'f': set(['e'])}
    try:
        tsort(dep_map)
        assert False
    except CycleFoundInFactDeps:
        pass

    # test order
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set()}
    sorted_list = tsort(dep_map)


# Generated at 2022-06-22 22:50:13.127827
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps:
        pass

#
# Main Facts class for gathering facts using multiple methods
#

# Generated at 2022-06-22 22:50:17.423188
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # arguments
    module = None
    collected_facts = None
    # test
    bfc = BaseFactCollector()
    result = bfc.collect_with_namespace(module, collected_facts)
    # validation
    assert result == {}



# Generated at 2022-06-22 22:50:20.570544
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert str(e) == 'test'
    else:
        assert False, 'should have thrown'

# Unit test

# Generated at 2022-06-22 22:50:28.911021
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bfa = BaseFactCollector()
    assert bfa.fact_ids == set(['BaseFactCollector'])
    assert bfa.fact_ids == bfa._fact_ids
    assert isinstance(bfa.collectors, list)
    assert isinstance(bfa.namespace, type(None))

    bfa = BaseFactCollector(collectors=[])
    assert bfa.fact_ids == set(['BaseFactCollector'])
    assert bfa.fact_ids == bfa._fact_ids
    assert isinstance(bfa.collectors, list)
    assert isinstance(bfa.namespace, type(None))



# Generated at 2022-06-22 22:50:31.858006
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Check CycleFoundInFactDeps constructor'''
    try:
        raise CycleFoundInFactDeps('This is a test')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'This is a test'



# Generated at 2022-06-22 22:50:44.181782
# Unit test for function resolve_requires
def test_resolve_requires():
    class Collector1(BaseFactCollector):
        pass

    class Collector2(BaseFactCollector):
        pass
    Collector2.required_facts = {'collector1'}

    class Collector3(BaseFactCollector):
        pass

    all_collectors = [Collector1, Collector2, Collector3]

    all_fact_subsets = defaultdict(list)
    for collector_class in all_collectors:
        all_fact_subsets[collector_class.name].append(collector_class)
        for fact_id in collector_class._fact_ids:
            all_fact_subsets[fact_id].append(collector_class)

    unresolved = {'collector1', 'collector2'}
    assert set(resolve_requires(unresolved, all_fact_subsets)) == unresolved



# Generated at 2022-06-22 22:50:51.865977
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector is not None, "BaseFactCollector class is not defined"
    assert BaseFactCollector._fact_ids is not None, "BaseFactCollector._fact_ids is not defined"
    assert BaseFactCollector.name is not None, "BaseFactCollector.name is not defined"
    assert BaseFactCollector.required_facts is not None, "BaseFactCollector.required_facts is not defined"


# Generated at 2022-06-22 22:50:59.831568
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires(set(), {}) == set()
    assert resolve_requires(set(), {'a': ['b']}) == set()
    assert resolve_requires(set(['a']), {'a': ['b']}) == set(['a'])
    assert resolve_requires(set(['a', 'b']), {'a': ['b']}) == set(['a', 'b'])
    assert resolve_requires(set(['b']), {'a': ['b']}) == set()



# Generated at 2022-06-22 22:51:02.861427
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'sysctl': ['sysctl'], 'systemd': ['systemd']}
    unresolved_requires = set(['systemd'])
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == set(['systemd'])
    assert 'sysctl' not in new_names



# Generated at 2022-06-22 22:51:04.885078
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with pytest.raises(CycleFoundInFactDeps):
        raise CycleFoundInFactDeps()


# Generated at 2022-06-22 22:51:07.776560
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    f = UnresolvedFactDep('hi', 'there')
    assert f.args[0] == "Unresolved dependency in fact 'hi' on 'there'"



# Generated at 2022-06-22 22:51:15.392370
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = set()
        name = 'A'

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['B', 'C'])
        name = 'B'

    class CollectorC(BaseFactCollector):
        _fact_ids = set()
        name = 'C'

    platform_info = {'distribution': 'ubuntu', 'system': 'Generic'}

    all_collector_classes = (CollectorA, CollectorB, CollectorC)
    collectors_for_platform = find_collectors_for_platform(all_collector_classes, [platform_info])

    computed = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-22 22:51:25.761363
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    # Simple case with no unresolved requires
    names = ['a', 'b', 'c']
    all_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    unresolved = find_unresolved_requires(names, all_subsets)
    assert not unresolved

    # A subset with no collectors
    with pytest.raises(CollectorNotFoundError):
        find_unresolved_requires(['a', 'z'], all_subsets)

    # A subset with an unresolved require
    names = ['a', 'b', 'c']
    all_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    unresolved = find_

# Generated at 2022-06-22 22:51:34.086231
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    from collections import defaultdict
    # collector_names are the names we asked for, all_fact_subsets is a map of
    # what all the names we could ask for, and what they require.
    all_fact_subsets = {
        'foo': [object()],
        'bar': [object()],
        'boo': [object()],
    }

    unresolved = {'baz'}

    # baz not in all_fact_subsets
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved, all_fact_subsets)

    failed = []
    failed.append('baz')
    failed.sort()


# Generated at 2022-06-22 22:51:39.233339
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        name = 'test1'
        _platform = 'Linux'

    class Collector2(BaseFactCollector):
        name = 'test2'
        _platform = 'Generic'

    class Collector3(BaseFactCollector):
        name = 'test3'
        _platform = 'FreeBSD'

    class Collector4(BaseFactCollector):
        name = 'test4'
        _platform = 'Generic'

    platform_info = {'system': 'Linux'}

    test_collectors = find_collectors_for_platform([Collector1, Collector2, Collector3, Collector4], [platform_info])
    assert test_collectors == {Collector1, Collector2}



# Generated at 2022-06-22 22:51:41.027143
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError("foo")
    assert c.args[0] == 'foo'


# Generated at 2022-06-22 22:51:52.327563
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.namespace import PrefixNamespace

    class TestCollector(BaseFactCollector):
        """A class for testing the BaseFactCollector methods."""
        name = 'test'
        _fact_ids = {'a_key'}

        def collect(self, module=None, collected_facts=None):
            fact_dict = {}
            fact_dict['a_key'] = 'a_value'

            return fact_dict

    namespace = PrefixNamespace('test_', '_test')
    test_collector = TestCollector(namespace=namespace)
    # test_collector's namespace is PrefixNamespace('test_', '_test')
    test_facts = test_collector.collect_with_namespace

# Generated at 2022-06-22 22:51:59.296271
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # Initialize the arguments
    collector_args = {}
    collector_args['collectors'] = None
    collector_args['namespace'] = None
    # creates a BaseFactCollector instance
    ansible_base_fact_collector_instance = BaseFactCollector(**collector_args)
    # checks if the created instance is an instance of BaseFactCollector
    assert(isinstance(ansible_base_fact_collector_instance, BaseFactCollector))


# Generated at 2022-06-22 22:52:12.080038
# Unit test for function get_collector_names
def test_get_collector_names():
    def assert_names(names, valid_subsets=None,
                     minimal_gather_subset=None,
                     gather_subset=None,
                     aliases_map=None,
                     platform_info=None):
        valid_subsets = valid_subsets or ('all', 'network')
        valid_subsets = frozenset(valid_subsets)
        minimal_gather_subset = minimal_gather_subset or ('system',)
        minimal_gather_subset = frozenset(minimal_gather_subset)
        aliases_map = aliases_map or defaultdict(set)
        names = frozenset(names)

# Generated at 2022-06-22 22:52:17.616830
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = dict(
        fact1=[collector_class(required_facts=['fact2'])],
        fact2=[collector_class(required_facts=[])],
    )
    collector_names = ['fact1', 'fact2']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()


# Generated at 2022-06-22 22:52:28.981595
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'collector_1': [
            type('collector_1_class_1', (object,), dict(required_facts=['collector_2']))
        ],
        'collector_2': [
            type('collector_2_class_1', (object,), dict(required_facts=['collector_3']))
        ],
        'collector_3': [
            type('collector_3_class_1', (object,), dict(required_facts=['collector_1']))
        ]
    }

    collector_names = {'collector_1', 'collector_2', 'collector_3'}

    dep_map = build_dep_data(collector_names, all_fact_subsets)


# Generated at 2022-06-22 22:52:37.021294
# Unit test for function resolve_requires
def test_resolve_requires():
    valid_subsets = frozenset(('network', 'hardware', 'dmi'))
    all_fact_subsets = dict()
    all_fact_subsets['network'] = ('network')
    all_fact_subsets['hardware'] = ('hardware', 'dmi')

    unresolved_requires = {'network', 'hardware'}
    try:
        resolve_requires(unresolved_requires, all_fact_subsets)
    except UnresolvedFactDep:
        pass
    else:
        raise AssertionError('Expected UnresolvedFactDep')

    unresolved_requires = {'network'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == {'network'}


# Generated at 2022-06-22 22:52:43.716308
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import namespace_manager
    from ansible.module_utils.facts import timeout

    # Check if it returns an empty dict
    obj = BaseFactCollector()
    result = obj.collect_with_namespace()
    assert result == {}

    # Check if it returns an empty dict
    namespace_obj = namespace_manager.BaseNamespace()
    obj = BaseFactCollector(namespace=namespace_obj)
    result = obj.collect_with_namespace()
    assert result == {}



# Generated at 2022-06-22 22:52:46.937540
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("foo")
    except UnresolvedFactDep as e:
        assert "foo" == e.args[0]
        return
    assert False



# Generated at 2022-06-22 22:52:48.944400
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(ValueError):
        raise UnresolvedFactDep('message')



# Generated at 2022-06-22 22:52:57.693257
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'a': [A],
        'b': [B, C],
        'c': [D, E, F],
        'd': [G],
        'e': [H, I],
        'f': [J, K],
    }

    # test all
    collector_names = set(['a', 'b', 'c', 'd', 'e', 'f'])
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [A, B, C, D, E, F, G, H, I, J, K]

    # test subset
    collector_names = set(['a', 'b'])

# Generated at 2022-06-22 22:53:03.042698
# Unit test for function tsort
def test_tsort():
    # Test 1: simple graph
    graph = {'collector-2': set(['collector-1']),
             'collector-3': set(['collector-1']),
             'collector-4': set(['collector-3']),
             'collector-1': set([])}
    sorted_list = tsort(graph)
    assert sorted_list == [('collector-1', set([])),
                           ('collector-2', set(['collector-1'])),
                           ('collector-3', set(['collector-1'])),
                           ('collector-4', set(['collector-3']))], 'Simple graph did not sort into correct order'

    # Test 2: cycle graph

# Generated at 2022-06-22 22:53:11.757232
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['test_collector','test_collector2']
    all_fact_subsets = {'test_collector':['test_req1','test_req2'],'test_collector2':['test_req2']}
    dep_map = build_dep_data(collector_names,all_fact_subsets)
    assert dep_map['test_collector'] == set(['test_req1','test_req2'])
    assert dep_map['test_collector2'] == set(['test_req2'])


# Generated at 2022-06-22 22:53:19.847044
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = ('id1',)
        name = 't1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = ('id2',)
        name = 't2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = ('id3',)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        [TestCollector1, TestCollector2, TestCollector3])

    # A collector with no name is not added to the map
    assert 't3' not in fact_id_to_collector_map
    assert 't3' not in aliases_map

    # All listed fact_ids are in the map
    assert fact