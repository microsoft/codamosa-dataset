

# Generated at 2022-06-22 22:43:29.218866
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollectorA(BaseFactCollector):
        name = 'TestCollectorA'
        _fact_ids = ['TestCollectorA']

        # no requires

    class TestCollectorB(BaseFactCollector):
        name = 'TestCollectorB'
        _fact_ids = ['TestCollectorB']
        required_facts = ['TestCollectorA']

    class TestCollectorC(BaseFactCollector):
        name = 'TestCollectorC'
        _fact_ids = ['TestCollectorC']
        required_facts = ['TestCollectorB', 'TestCollectorD']

    class TestCollectorD(BaseFactCollector):
        name = 'TestCollectorD'
        _fact_ids = ['TestCollectorD']
        required_facts = ['TestCollectorA']


# Generated at 2022-06-22 22:43:38.723321
# Unit test for function tsort
def test_tsort():
    dep_map = {'A': {'B', 'C'},
               'B': {'C', 'E'},
               'C': {'D', 'E'},
               'D': set(),
               'E': {'F'}}

    dep_map['F'] = {'F'}

    sorted_list = tsort(dep_map)
    assert sorted_list == [('F', {'F'}),
                           ('E', {'F'}),
                           ('D', set()),
                           ('C', {'D', 'E'}),
                           ('B', {'C', 'E'}),
                           ('A', {'B', 'C'})]



# Generated at 2022-06-22 22:43:42.382330
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    baseFactCollector = BaseFactCollector()
    assert baseFactCollector.collect_with_namespace() == {}


# Generated at 2022-06-22 22:43:51.607530
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class CollectAlien(BaseFactCollector):
        name = 'alien'
        _fact_ids = {'dude', 'abides'}

    class CollectHippie(BaseFactCollector):
        name = 'hippie'
        _fact_ids = {'freak', 'retired', 'bearded'}

    class CollectDude(BaseFactCollector):
        name = 'dude'
        _fact_ids = {'freak', 'retired', 'bearded'}

    class CollectDudeAbides(BaseFactCollector):
        name = 'dude_abides'
        _fact_ids = {'abides'}

    # We have 3 collectors with 4 aliases

# Generated at 2022-06-22 22:43:58.077098
# Unit test for function get_collector_names
def test_get_collector_names():
    s = get_collector_names(gather_subset=('all', '!hardware'), valid_subsets=frozenset(['all', 'network', 'storage', 'hardware']),
                            aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}))
    assert s == frozenset(['all', 'min', '!hardware'])



# Generated at 2022-06-22 22:44:09.364884
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {}
    all_fact_subsets['a'] = [_TestFactCollector('a', deps=set(['c']))]
    all_fact_subsets['b'] = [_TestFactCollector('b', deps=set(['d']))]
    all_fact_subsets['c'] = [_TestFactCollector('c', deps=set())]
    all_fact_subsets['d'] = [_TestFactCollector('d', deps=set())]
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': {'c'}, 'b': {'d'}, 'c': set(), 'd': set()}

# Generated at 2022-06-22 22:44:19.666230
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Initializing the class for testing
    a = BaseFactCollector(collectors=None, namespace=None)
    # Handling the case when the module is not specified
    assert a.collect_with_namespace(collected_facts=None) == {}, "The output is not as expected"
    # Handling the case when the collected_facts is not specified
    assert a.collect_with_namespace(module=None) == {}, "The output is not as expected"
    # Handling the case when both the parameters are not specified
    assert a.collect_with_namespace() == {}, "The output is not as expected"

    # Handling the case when the collected_facts is a dict
    expected_dict = {"key1": "value1", "key2": "value2"}

# Generated at 2022-06-22 22:44:22.926758
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors == []
    assert fc.namespace is None


# Generated at 2022-06-22 22:44:33.571963
# Unit test for function build_dep_data
def test_build_dep_data():
    import json
    import yaml

# Generated at 2022-06-22 22:44:35.921791
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    cnfe = CollectorNotFoundError("foo")
    if 'foo' not in str(cnfe):
        raise Exception("Unit test for CollectorNotFoundError failed!")



# Generated at 2022-06-22 22:44:43.388455
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.plugins.loader import fact_loader

    fcts = fact_loader.get_fact_collector_classes()
    for fct in fcts:
        collectors = [fcts[fct]]
        x = fcts[fct](collectors=collectors)
        assert x.collectors == collectors
        assert isinstance(x, BaseFactCollector)



# Generated at 2022-06-22 22:44:48.884661
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    all_collector_classes = (CollectorA,
                             CollectorB,
                             CollectorC,
                             CollectorD,
                             CollectorE)

    minimal_gather_subset = ['min']

    platform_info = {'system': 'Generic'}

    valid_subsets = ['min', 'a', 'b', 'c', 'd', 'e']
    gather_subset = ['a', 'd', 'e']

    expected_selected_collector_classes = [CollectorD, CollectorE, CollectorA]


# Generated at 2022-06-22 22:44:59.458629
# Unit test for function tsort
def test_tsort():
    TEST_DATA = {
        "main.1": set([
            "main.2"
        ]),
        "main.2": set([
            "main.3",
            "main.5"
        ]),
        "main.3": set(),
        "main.4": set([
            "main.3"
        ]),
        "main.5": set([
            "main.4"
        ]),
    }
    correct_order = [
        'main.3',
        'main.4',
        'main.5',
        'main.2',
        'main.1',
    ]
    assert tsort(TEST_DATA) == correct_order



# Generated at 2022-06-22 22:45:09.525272
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # TODO: refactor
    test_collector_class = type('test_collector_class', (BaseFactCollector,), {})
    test_collector_class2 = type('test_collector_class2', (BaseFactCollector,), {})

    all_fact_subsets = {
        'collector1': [test_collector_class, test_collector_class2],
        'collector2': [test_collector_class, test_collector_class2],
    }

    collector_names = ['collector1', 'collector2']

    collector_classes = select_collector_classes(collector_names, all_fact_subsets)

    assert collector_classes == [test_collector_class, test_collector_class2]



# Generated at 2022-06-22 22:45:21.718603
# Unit test for function get_collector_names
def test_get_collector_names():
    # all - nothing excluded
    gather_subset_1 = ['all']
    valid_subsets_1 = frozenset(['a', 'b', 'c'])
    minimal_gather_subset_1 = frozenset(['x'])
    aliases_map_1 = defaultdict(set)
    result = get_collector_names(valid_subsets_1,
                                 minimal_gather_subset_1,
                                 gather_subset_1,
                                 aliases_map_1)
    assert set(['a', 'b', 'c', 'x']) == result

    # all - nothing excluded, with minimal set of empty set
    gather_subset_2 = ['all']
    valid_subsets_2 = frozenset(['a', 'b', 'c'])
    minimal_gather

# Generated at 2022-06-22 22:45:32.340569
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class FakeCollector(BaseFactCollector):
        name = 'fake'
        required_facts = set(['fake'])

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None

    all_collector_classes = [FakeCollector]

    platform_info = dict(platform.uname()._asdict())
    compat_platforms = [platform_info]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert found_collectors, "no collectors could be found"
    assert isinstance(found_collectors, set)
    assert len(found_collectors) == 1

# Generated at 2022-06-22 22:45:34.361300
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # To test collect method
    return 0, '', {}


# Generated at 2022-06-22 22:45:40.949077
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    expected_result = {'base_fact_collector_required_facts':
                           {'base_fact_collector_required_facts': set()}}

    collected_facts = BaseFactCollector()
    result = collected_facts.collect(collected_facts={})

    assert result == expected_result


# TODO: re-write this as classmethods

# Generated at 2022-06-22 22:45:43.556374
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    assert isinstance(CollectorNotFoundError('foo'), KeyError)
    assert str(CollectorNotFoundError('foo')) == "Collector 'foo' not found"


# Generated at 2022-06-22 22:45:55.406474
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import (BaseFactCollector)
    from ansible.module_utils.facts.collector.network import (NetworkCollector)

    class A(BaseFactCollector):
        required_facts = set()
        name = 'A'
    class B(BaseFactCollector):
        required_facts = {'A'}
        name = 'B'
    class C(BaseFactCollector):
        required_facts = set()
        name = 'C'
    class D(BaseFactCollector):
        required_facts = {'A'}
        name = 'D'
    class E(BaseFactCollector):
        required_facts = {'A', 'B'}
        name = 'E'


# Generated at 2022-06-22 22:46:01.187765
# Unit test for function tsort
def test_tsort():
    # all tests for tsort, including the bad one, are adapted from
    # https://rosettacode.org/wiki/Topological_sort#Python
    #
    # the test data and the good results are from that page.
    test_deps = [
        ('a', 'b'), ('b', 'c'), ('b', 'd'), ('d', 'e'), ('a', 'f'), ('f', 'c'),
        ('k', 'i'), ('i', 'j'),
        ('x', 'y'), ('y', 'z'), ('z', 'x'),
        ('a', 'x'), ('r', 'b'), ('r', 'e'),
        ('a', 'i')
    ]

    test_dep_map = defaultdict(set)

# Generated at 2022-06-22 22:46:13.236836
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollectorClass1(BaseFactCollector):
        _fact_ids = {'test1', 'test2'}
        name = 'somename'

    class TestCollectorClass2(BaseFactCollector):
        _fact_ids = {'test3', 'test4'}
        name = 'anothername'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        {TestCollectorClass1, TestCollectorClass2})

    assert 'somename' in fact_id_to_collector_map
    assert 'anothername' in fact_id_to_collector_map
    assert TestCollectorClass1 in fact_id_to_collector_map['somename']
    assert TestCollectorClass2 in fact_id_to_

# Generated at 2022-06-22 22:46:15.667982
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collector = BaseFactCollector()
    collected_facts = None
    assert collector.collect(module=None, collected_facts=collected_facts) == {}, '''The collector.collect() method of BaseFactCollector class should return a {} when no arguments are passed to it.'''




# Generated at 2022-06-22 22:46:20.087291
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # TODO:
    #   1. create a BaseFactCollector object
    #   2. call method collect_with_namespace
    #   3. verify that the call worked and the object was modified as expected
    # raise Exception("unimplemented test case")
    pass



# Generated at 2022-06-22 22:46:21.202009
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(ValueError):
        raise UnresolvedFactDep("foo")


# Generated at 2022-06-22 22:46:30.915007
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        minimal_gather_subset=['min'],
        gather_subset=['!all'],
    ) == set(['min'])

    assert get_collector_names(
        minimal_gather_subset=['min'],
        gather_subset=['!all', '!network'],
    ) == set(['min'])

    assert get_collector_names(
        minimal_gather_subset=['min'],
        gather_subset=['!all', 'network'],
    ) == set(['network', 'min'])


# Generated at 2022-06-22 22:46:34.006545
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd = UnresolvedFactDep('test_unresolved_fact_dep')
    assert ufd.args == ('test_unresolved_fact_dep',)



# Generated at 2022-06-22 22:46:35.441708
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd = UnresolvedFactDep('foo')

    assert 'foo' in str(ufd)



# Generated at 2022-06-22 22:46:38.535357
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collect = BaseFactCollector.collect
    ret = collect()
    assert ret == {}
# test_BaseFactCollector_collect



# Generated at 2022-06-22 22:46:48.623490
# Unit test for function tsort
def test_tsort():
    unsorted_map = {
        'foo': set(['root']),
        'root': set([]),
        'bar': set(['foo']),
        't': set(['root']),
        'cycle1': set(['cycle2']),
        'cycle2': set(['cycle1']),
    }

    # no cycle, should work
    assert tsort(unsorted_map) == [
        ('root', set()),
        ('foo', set(['root'])),
        ('bar', set(['foo'])),
        ('t', set(['root'])),
        ('cycle1', set(['cycle2'])),
        ('cycle2', set(['cycle1'])),
    ]

    # cycle detected
    unsorted_map['cycle3'] = set(['cycle1'])
   

# Generated at 2022-06-22 22:46:53.518113
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.system.platform.linux import LinuxFactCollector
    from ansible.module_utils.facts.system.distribution.darwin import DarwinFactCollector
    from ansible.module_utils.facts.system.distribution.freebsd import FreeBSDFactCollector
    a_deps = set(["a", "b", "c"])
    b_deps = set(["d", "e", "f"])
    c_deps = set(["g", "h", "i"])
    d_deps = set(["j", "k", "l"])
    e_deps = set(["m", "n", "o"])

# Generated at 2022-06-22 22:46:59.423381
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.collector.system import GenericFactCollector
    
    test_module = {}
    new_facts = {}
    cfc = GenericFactCollector()
    test_dict = cfc.collect(test_module, new_facts)
    
    assert test_dict == {}



# Generated at 2022-06-22 22:47:02.570414
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Ensure CycleFoundInFactDeps constructor has no arguments'''
    try:
        raise CycleFoundInFactDeps('argument')
    except CycleFoundInFactDeps as e:
        assert e.args == tuple()


# Generated at 2022-06-22 22:47:13.400571
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['collector1', 'collector2'], {}) == \
        defaultdict(set, {
            'collector1': set(),
            'collector2': set()
        })
    assert build_dep_data(['collector1', 'collector2'], {'collector1': {}, 'collector2': {}}) == \
        defaultdict(set, {
            'collector1': set(),
            'collector2': set()
        })

# Generated at 2022-06-22 22:47:17.059385
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    params = ['invalid_fact', 'collector_a']
    try:
        raise UnresolvedFactDep(*params)
    except UnresolvedFactDep as exception:
        assert exception.args == params



# Generated at 2022-06-22 22:47:28.493899
# Unit test for function tsort
def test_tsort():
    # from http://www.bitformation.com/art/python_tsort.html
    # (not actually a useful dep graph for facts, just for testing)
    g = [('a', ('b', 'f')),
         ('b', ('c', 'e')),
         ('c', ()),
         ('d', ('a', 'f')),
         ('e', ('f',)),
         ('f', ()),
         ]

    assert tsort(dict(g)) == [('c', ()),
                              ('a', ('b', 'f')),
                              ('b', ('c', 'e')),
                              ('e', ('f',)),
                              ('f', ()),
                              ('d', ('a', 'f')),
                              ]

    # test a cycle

# Generated at 2022-06-22 22:47:31.631773
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps('foo', 'bar')
    assert str(err) == 'foo depends on bar'



# Generated at 2022-06-22 22:47:42.770430
# Unit test for function tsort
def test_tsort():
    dep_map = {'a': set(['b']),
               'b': set(['d']),
               'c': set(['d']),
               'd': set(['g']),
               'e': set(['a', 'h']),
               'f': set(['e']),
               'g': set(['f']),
               'h': set(['b']),
               }

    result = tsort(dep_map)

# Generated at 2022-06-22 22:47:44.261674
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    CycleFoundInFactDeps()



# Generated at 2022-06-22 22:47:51.297181
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': [],
        'b': [],
        'c': [],
        'd': [],
        'x': [],
        'y': [],
        'z': [],
    }
    unresolved = set(['b', 'x', 'y', 'z'])
    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == set(['b', 'x', 'y'])



# Generated at 2022-06-22 22:47:59.374807
# Unit test for function select_collector_classes
def test_select_collector_classes():
    ''' Test the select_collector_classes helper function '''
    class TestCollector(BaseFactCollector):
        _fact_ids = frozenset(['foo', 'bar'])
        name = 'test'

    class TestCollector1(TestCollector):
        pass

    class TestCollector2(TestCollector):
        pass

    all_fact_subsets = {'test': [TestCollector1, TestCollector2]}
    collector_names = ['test', 'foo', 'bar']
    selected_collectors = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collectors) == 2
    assert TestCollector1 in selected_collectors
    assert TestCollector2 in selected_collectors



# Generated at 2022-06-22 22:48:11.756150
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    for fact_id in collector.FACT_SUBSETS:
        for fact_class in fact_id[1]:
            fact_class.name = fact_class.__name__
    data = build_dep_data(fact_id[0], fact_id[1])
    assert data['dmi'].issuperset({'_platform_subset_dmi'})
    assert data['all'].issuperset({'all_restricted'})
    assert data['mounts'].issuperset({'file_systems'})
    assert data['dns'].issuperset({'domain'})
    assert data['devices'].issuperset({'system'})
    assert data['all_restricted'].issuperset({'local'})
   

# Generated at 2022-06-22 22:48:24.236558
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.default import DefaultCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    SystemCollector._platform = 'Linux'
    NetworkCollector._platform = 'Linux'
    DefaultCollector._platform = 'Linux'

    PlatformInfo = dict
    platform_info = PlatformInfo(system=platform.system())

    collector_names = ['default', 'dmi', 'network', 'ohai', 'system']

    all_fact_subsets = defaultdict(list)
    for collector_name in collector_names:
        matching_collectors = find_collectors_for_platform([SystemCollector, NetworkCollector, DefaultCollector],
                                                            [platform_info])

# Generated at 2022-06-22 22:48:36.609092
# Unit test for function tsort
def test_tsort():
    collector1 = BaseFactCollector()
    collector1.required_facts = set(["fact1", "fact2"])
    collector1.name = 'one'

    collector2 = BaseFactCollector()
    collector2.required_facts = set(["fact1"])
    collector2.name = 'two'

    collector3 = BaseFactCollector()
    collector3.required_facts = set(["fact2"])
    collector3.name = 'three'

    collector4 = BaseFactCollector()
    collector4.required_facts = set(["fact3"])
    collector4.name = 'four'

    collector5 = BaseFactCollector()
    collector5.required_facts = set(["fact3"])
    collector5.name = 'five'

    collector6 = BaseFactCollector()
    collector6.required

# Generated at 2022-06-22 22:48:40.022134
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collectors = None
    namespace = None

    basefactcollector = BaseFactCollector(collectors, namespace)
    module = None
    collected_facts = None

    assert basefactcollector.collect(module, collected_facts) == {}



# Generated at 2022-06-22 22:48:49.302712
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'Collector1'
        _fact_ids = set('fact_id1'.split())

        def collect(self, collected_facts=None, module=None):
            return {}

    class Collector2(BaseFactCollector):
        name = 'Collector2'
        _fact_ids = set('fact_id2'.split())

        def collect(self, collected_facts=None, module=None):
            return {}

    expected = {
        'Collector1': [Collector1],
        'Collector2': [Collector2],
        'fact_id1': [Collector1],
        'fact_id2': [Collector2],
    }

    found_fact_id_to_collector_map, aliases_map = build_fact_id_to_collect

# Generated at 2022-06-22 22:48:58.821918
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    # for now, we just test that the method does not error
    class FC(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {}

    fc = FC()
    fc.collect_with_namespace()

    # test when namespace is None
    fc = FC(namespace=None)
    assert(fc.collect_with_namespace() == {})

    # test when namespace is used
    class N(object):
        def transform(self, k):
            return 'transformed:' + k

    fc = FC(namespace=N())
    assert(fc.collect_with_namespace() == {'transformed:empty': ''})



# Generated at 2022-06-22 22:49:03.960492
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['b']
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector],
        }
    all_fact_subsets['a'][0].required_facts = set(['b'])
    all_fact_subsets['b'][0].required_facts = set(['c'])

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['c'])



# Generated at 2022-06-22 22:49:12.359950
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {}
    # start from specific platform, then try generic
    all_collector_classes = [TestCollector]
    compat_platforms = [{'system': 'Generic'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    # make sure we found our collector
    assert found_collectors.pop().name == 'test'



# Generated at 2022-06-22 22:49:21.909677
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = ('a1', 'a2')

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = ('b1', 'b2')

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = ('c1', 'c2')

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = ('d1', 'd2')

    all_fact_subsets = {
        'A': [CollectorA, CollectorA],
        'B': [CollectorB],
        'C': [CollectorC, CollectorC],
        'D': [CollectorD, CollectorD],
    }


# Generated at 2022-06-22 22:49:26.501602
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector_name = 'not_found_collector'
    exc = CollectorNotFoundError(collector_name)
    assert exc.args[0] == collector_name



# Generated at 2022-06-22 22:49:31.590315
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': 1, 'b': 2, 'c': 3}
    unresolved = ['a', 'b', 'c', 'd']
    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == set(['a', 'b', 'c'])
    assert 'd' not in new_names



# Generated at 2022-06-22 22:49:42.730517
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class DummyCollector(BaseFactCollector):
        name = 'all'

    class DummyCollector2(BaseFactCollector):
        name = 'test'

    class DummyCollector3(BaseFactCollector):
        name = 'min'

    class DummyCollector4(BaseFactCollector):
        name = 'test_collector_3'
        required_facts = ['min']

    class DummyCollector5(BaseFactCollector):
        name = 'test_collector_4'
        required_facts = ['min', 'test_collector_3']

    class DummyCollector6(BaseFactCollector):
        name = 'test_collector_5'
        required_facts = ['min', 'test_collector_4']

    class DummyCollector7(BaseFactCollector):
        name

# Generated at 2022-06-22 22:49:48.841345
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import default_collectors
    names = 'hardware', 'network'
    all_fact_subsets = {n: [c for c in default_collectors
                            if not c.name.startswith('_') and
                               n in c._fact_ids]
                        for n in names}
    collector_names = ('hardware', 'network')
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['hardware'] == set(['network'])
    assert dep_map['network'] == set()



# Generated at 2022-06-22 22:49:50.169917
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with raises(KeyError):
        raise CollectorNotFoundError('test')



# Generated at 2022-06-22 22:50:01.034588
# Unit test for function get_collector_names
def test_get_collector_names():
    facts = ['devices', 'dmi', 'hardware', 'kernel', 'system']
    min_facts = ['system']
    valid_subsets = set(facts + min_facts)
    minimal_gather_subset = set(min_facts)
    if platform.system() == 'Linux':
        valid_subsets.add('distribution')
        valid_subsets.add('cmdline')
        minimal_gather_subset.add('distribution')
    elif platform.system() == 'SunOS':
        valid_subsets.add('pkg')
    elif platform.system() == 'Darwin':
        pass
    elif platform.system() == 'FreeBSD':
        pass
    elif platform.system() == 'OpenBSD':
        pass


# Generated at 2022-06-22 22:50:09.451112
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = set(['collector_a', 'collector_b', 'collector_c'])

    class CollectorA(BaseFactCollector):
        _fact_ids = set(['fact', 'fact_a'])
        name = 'collector_a'
        required_facts = set(['fact_c'])

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['fact_b'])
        name = 'collector_b'
        required_facts = set()

    class CollectorC(BaseFactCollector):
        _fact_ids = set(['fact_c'])
        name = 'collector_c'
        required_facts = set()


# Generated at 2022-06-22 22:50:19.806664
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import ansible.module_utils.facts.hardware.darwin
    import ansible.module_utils.facts.network.ios

    all_fact_subsets = defaultdict(list)

    all_fact_subsets['hardware'].append(ansible.module_utils.facts.hardware.darwin.DarwinHardware)
    all_fact_subsets['network'].append(ansible.module_utils.facts.network.ios.IosHardware)

    selected_collector_classes = select_collector_classes(['hardware'], all_fact_subsets)

    assert selected_collector_classes == [ansible.module_utils.facts.hardware.darwin.DarwinHardware]


# Generated at 2022-06-22 22:50:22.129238
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(1,2,3)
    except CollectorNotFoundError as e:
        assert (1,2,3) == e.args



# Generated at 2022-06-22 22:50:32.225584
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import default_collectors

    all_fact_subsets = build_fact_id_to_collector_map(default_collectors)

    # happy path, no requires
    assert find_unresolved_requires(['all'], all_fact_subsets) == set()

    # collector not found
    assert find_unresolved_requires(['all', 'potato'], all_fact_subsets) == set(['potato'])

    # issue in collector
    class RequiresBogus(BaseFactCollector):
        required_facts = ['potato']

    class FactCollectorWithBogusRequires(BaseFactCollector):
        _fact_ids = ['bogus_requires']
        required_facts = ['bogus']

    all_fact_subsets = build_fact_

# Generated at 2022-06-22 22:50:44.463360
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.platform import Darwin, Linux
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector.network import Network

    all_collector_classes = [Darwin, Linux, Network]
    collector_names = set([cls.name for cls in all_collector_classes])

    all_fact_subsets = {}
    for collector_class in all_collector_classes:
        name = collector_class.name
        all_fact_subsets.setdefault(name, set()).add(collector_class)

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map['network'] == set(['platform'])
    assert dep_map['platform'] == set()

# Generated at 2022-06-22 22:50:50.862847
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # pylint: disable=unused-argument
    # The unused argument is 'self' for the __init__ method

    try:
        raise CycleFoundInFactDeps('thing')
    except CycleFoundInFactDeps as exc:
        assert(exc.message == 'thing')
    else:
        assert(False)


# Generated at 2022-06-22 22:50:57.110256
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': 'b', 'b': 'c', 'c': 'd'}
    new_names = resolve_requires(['a', 'b', 'c'], all_fact_subsets)
    if new_names != ['a', 'b', 'c', 'd']:
        raise AssertionError('resolve_requires did not follow dependency tree to get d from a')



# Generated at 2022-06-22 22:51:08.849761
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    all_collector_classes = [FakeCollector, FakeCollector2]
    all_facts = frozenset([c.name for c in all_collector_classes])
    aliases_map = defaultdict(set)
    fact_id_to_collector_map, _aliases_map = build_fact_id_to_collector_map(all_collector_classes)
    aliases_map.update(_aliases_map)

    assert all_facts == frozenset(fact_id_to_collector_map.keys())
    assert not aliases_map

    assert fact_id_to_collector_map['FakeCollector'] == [FakeCollector]
    assert fact_id_to_collector_map['FakeCollector2'] == [FakeCollector2]

    # now try with aliases
    _fact_id_

# Generated at 2022-06-22 22:51:14.390383
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    """ test_BaseFactCollector: test constructor for class BaseFactCollector """
    NF = BaseFactCollector()
    assert len(NF.fact_ids) == 1
    assert NF.fact_ids == set(['Generic'])
    assert type(NF.collectors) is list
    assert len(NF.collectors) == 0


# Generated at 2022-06-22 22:51:24.911450
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # A mockup of the all_fact_subsets dict
    all_fact_subsets = {
        'collector_a': [
            FakeCollector('collector_a', ['collector_b', 'collector_c']),
        ],
        'collector_b': [
            FakeCollector('collector_b', ['collector_c']),
        ],
        'collector_c': [
            FakeCollector('collector_c', []),
        ]
    }

    # Given a "normal" case, expect no unresolved requires.
    collector_names = ['collector_c', 'collector_b', 'collector_a']
    assert set() == find_unresolved_requires(collector_names, all_fact_subsets)

    # Given a collector name that is missing, expect it to be unresolved

# Generated at 2022-06-22 22:51:33.471963
# Unit test for function get_collector_names
def test_get_collector_names():
    # This test is not yet complete
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!min']) == frozenset(['all'])

    assert get_collector_names(gather_subset=['!foo']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['foo']) == frozenset(['foo'])

# Generated at 2022-06-22 22:51:44.645969
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('dmi', 'network', 'network_resources'))
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(('dmi',))
    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['!network_resources']) == frozenset(('dmi', 'network'))
    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['!network', '!network_resources']) == frozenset(('dmi',))
    # test the lookup when gathering a subset named 'min'

# Generated at 2022-06-22 22:51:55.398383
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import collector, namespace_manager

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    # If namespace is not set, unmodified facts should be returned
    test_collector = TestCollector()
    collected_facts = {'a': 'A'}
    collected_facts_copy = collected_facts.copy()
    facts_dict = test_collector.collect_with_namespace(collected_facts=collected_facts_copy)
    assert facts_dict == collected_facts, 'collect_with_namespace did not return expected facts'
    assert collected_facts_copy == collected_facts, 'collect_with_namespace modified original facts'

    # If namespace is set and key

# Generated at 2022-06-22 22:52:06.060489
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import random
    import unittest

    import os

    from ansible_collections.community.tests.unit.compat.mock import patch
    from ansible_collections.community.tests.unit.compat.mock import Mock
    from ansible_collections.community.tests.unit.compat.mock import mock_open

    # Given a list of collector names, return a list of mock collectors that
    # have the same names
    def make_collector_list(collector_names):
        collector_list = []
        for cname in collector_names:
            x = Mock()
            x.name = cname

            collector_list.append(x)
        return collector_list

    # given a list of mock collectors, return a fact_subset dict that has the collectors
    # indexed by name

# Generated at 2022-06-22 22:52:11.404689
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('test')
    except UnresolvedFactDep as e:
        assert str(e) == 'test'
    # Empty message should not raise an exception
    try:
        raise UnresolvedFactDep()
    except UnresolvedFactDep as e:
        assert str(e) == ''



# Generated at 2022-06-22 22:52:17.120690
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    cycle = ['A', 'B']

    try:
        raise CycleFoundInFactDeps(cycle)
    except CycleFoundInFactDeps as e:
        assert e.cycle == cycle
        assert repr(e) == 'CycleFoundInFactDeps(cycle=%s)' % cycle
        assert str(e) == 'Cycle found in fact dependency graph: %s' % cycle



# Generated at 2022-06-22 22:52:28.878281
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestCollector(BaseFactCollector):
        name = 'primary'
        _fact_ids = set(['primary', 'alias1', 'alias2'])

    class TestCollector2(BaseFactCollector):
        name = 'primary2'
        _fact_ids = set(['primary2', 'alias1', 'alias3'])

    class TestCollector3(BaseFactCollector):
        name = 'primary3'
        _fact_ids = set(['primary3', 'alias1', 'alias4'])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['primary'] = [TestCollector]
    all_fact_subsets['primary2'] = [TestCollector2]
    all_fact_subsets['primary3'] = [TestCollector3]

# Generated at 2022-06-22 22:52:36.965443
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import RedHat
    from ansible.module_utils.facts.system.distribution import SuSE

    all_collector_classes = [RedHat, SuSE]
    for a_class in all_collector_classes:
        a_class._fact_ids = a_class._fact_ids.union({'platform_Linux'})

    all_fact_subsets = cache.collector_classes_to_fact_subsets(all_collector_classes)
    collector_names = {'platform_Linux', 'RedHat'}


# Generated at 2022-06-22 22:52:45.317316
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest

    # data for tests defined as a dict of dicts:
    #   {
    #     'test_name': {
    #       'all_facts': set of all possible facts
    #       'test_cases': {
    #          'test_case_name': {
    #            'desc': 'description of test case'
    #            'collector_names': set(['eth0', 'ipv4', ...])
    #            'unresolved_require': set(['eth0', 'ipv4', ...])
    #          }
    #        }
    #     }
    #   }

# Generated at 2022-06-22 22:52:52.635309
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import timeout_factory

    timeout_class = timeout_factory()

    timeout_obj = timeout_class(10, 0, True)

    module_obj = object()

    collected_facts_obj = object()

    base_fact_collector_obj = BaseFactCollector()

    assert base_fact_collector_obj.collect_with_namespace(module_obj, collected_facts_obj) == {}


# Generated at 2022-06-22 22:52:56.500480
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    x = BaseFactCollector(namespace = 'xyz')
    x.collect = lambda module, collected_facts: {'hello':'world'}
    assert x.collect_with_namespace() == {'xyz_hello':'world'}, 'BaseFactCollector.collect_with_namespace does not transform fact names!'

# Generated at 2022-06-22 22:53:06.279212
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.utils import timeout
    from time import time
    from time import sleep
    obj = BaseFactCollector()
    assert 'test' not in dir(obj)
    obj.test = 'test'
    assert 'test' in dir(obj)
    obj = BaseFactCollector()
    obj.name = None
    assert 'test' not in dir(obj)
    obj.test = 'test'
    assert 'test' in dir(obj)
    obj = BaseFactCollector()
    obj.name = 'test'
    assert 'test' not in dir(obj)
    obj.test = 'test'
    assert 'test' in dir(obj)
    obj = BaseFactCollector()

# Generated at 2022-06-22 22:53:16.309772
# Unit test for function tsort
def test_tsort():
    dep_map = {}
    dep_map['A'] = set(['C'])
    dep_map['B'] = set(['C'])
    dep_map['C'] = set()
    sorted_list = tsort(dep_map)
    assert sorted_list == [('C', set()), ('B', set(['C'])), ('A', set(['C']))]

    dep_map = {}
    dep_map['A'] = set()
    dep_map['B'] = set()
    dep_map['C'] = set()
    sorted_list = tsort(dep_map)
    assert sorted_list == [('A', set()), ('B', set()), ('C', set())]

    dep_map = {}
    dep_map['A'] = set(['B'])
    dep_

# Generated at 2022-06-22 22:53:17.738416
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert hasattr(BaseFactCollector, '_fact_ids')



# Generated at 2022-06-22 22:53:25.108472
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': [None], 'b': [None]}
    assert resolve_requires({'a', 'b'}, all_fact_subsets) == {'a', 'b'}
    assert resolve_requires({'a', 'b', 'c'}, all_fact_subsets) == {'a', 'b'}
    try:
        resolve_requires({'c'}, all_fact_subsets)
        assert False
    except UnresolvedFactDep:
        pass

