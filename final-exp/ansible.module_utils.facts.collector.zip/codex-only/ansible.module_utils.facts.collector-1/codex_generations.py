

# Generated at 2022-06-22 22:43:25.977140
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    def make_collector_class(name):
        class C(BaseFactCollector):
            _fact_ids = set()
            required_facts = set()
            _platform = 'Generic'
            name = name
        return C()
    def make_collector_class_old(name, fact_id=None):
        if fact_id is None:
            fact_id = name
        class C(BaseFactCollector):
            _fact_ids = set([fact_id])
            required_facts = set()
            _platform = 'Generic'
            name = name
        return C()


# Generated at 2022-06-22 22:43:32.501533
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    import logging
    import random
    from pytest import approx

    class BaseFactCollector :
        def __init__(self, module=None) :
            self.module = module
            self.logger = logging.getLogger(module.params['ansible_name'])
            self.results = {
                'ansible_facts': {},
                'warnings': [],
                'errors': []
            }
        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            return facts_dict
    bfc = BaseFactCollector()
    assert bfc.collect() == {}



# Generated at 2022-06-22 22:43:38.353437
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['a', 'test'])

    assert build_fact_id_to_collector_map([TestCollector]) == ({
        'test': [TestCollector],
        'a': [TestCollector]},
        defaultdict(set, {'test': {'a', 'test'}})
    )



# Generated at 2022-06-22 22:43:45.473287
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Given
    fact_collector = BaseFactCollector()
    fact_collector.name = "sample_name"
    facts_dict = {'a': 'A', 'b': 'B'}
    # When
    actual_facts_dict = fact_collector.collect_with_namespace(collected_facts=facts_dict)
    # Then
    assert actual_facts_dict == facts_dict



# Generated at 2022-06-22 22:43:50.728573
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'all': 'all',
        'network': 'network',
        'facter': 'facter',
        'ohai': 'ohai'}
    all_collector_classes = set()
    collector_names = ['network', 'facter', 'ohai']
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
    resolve_requires(unresolved_requires, all_fact_subsets)



# Generated at 2022-06-22 22:43:56.848675
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # Because doctest is a strange thing, I need __str__ to be defined
    class MyException(CycleFoundInFactDeps):
        def __str__(self):
            return super(MyException, self).__str__()

    e = MyException(42, 'a', 'b', 'c')
    assert str(e) == repr([42, 'a', 'b', 'c'])
    assert repr(e.args) == repr([42, 'a', 'b', 'c'])


# Generated at 2022-06-22 22:44:01.134216
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("This is a test", "one", "two", "three")
    except UnresolvedFactDep as e:
        assert e.args == ("This is a test", "one", "two", "three")



# Generated at 2022-06-22 22:44:02.837044
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fact = BaseFactCollector()
    assert fact.collect() == {}



# Generated at 2022-06-22 22:44:14.092676
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': ['c', 'd'], 'b': ['c', 'd'], 'c': ['d'], 'd': [], 'e': ['f'], 'f': []}

    unresolved_requires = set(['a', 'b', 'c', 'd', 'e'])
    result = resolve_requires(unresolved_requires, all_fact_subsets)
    assert result == set(['a', 'b', 'c', 'd'])

    unresolved_requires = set(['c', 'd'])
    result = resolve_requires(unresolved_requires, all_fact_subsets)
    assert result == set(['c', 'd'])

    unresolved_requires = set(['b', 'e'])

# Generated at 2022-06-22 22:44:23.569599
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.collector.keys import KeysFactCollector
    from ansible.module_utils.facts.collector.fileglob import FileglobFactCollector
    from ansible.module_utils.facts.collector.mounts import MountsFactCollector

    collectors_for_platform = set()
    collectors_for_platform.add(KeysFactCollector)
    collectors_for_platform.add(FileglobFactCollector)
    collectors_for_platform.add(MountsFactCollector)

    # Test normal operation
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert fact_id_to_collector_map

# Generated at 2022-06-22 22:44:34.091998
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class DummyCollectorClass1:
        name = 'collector_class_1'
        required_facts = frozenset({'alpha'})

    class DummyCollectorClass2:
        name = 'collector_class_2'
        required_facts = frozenset({'bravo'})

    class DummyCollectorClass3:
        name = 'collector_class_3'
        required_facts = frozenset({'alpha', 'charlie'})

    class DummyCollectorClass4:
        name = 'collector_class_4'
        required_facts = frozenset({'bravo', 'delta'})


# Generated at 2022-06-22 22:44:41.977101
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.collector.os_family import OsFamilyFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector

    # test namespace = None
    fc = BaseFactCollector()
    base_facts = fc.collect_with_namespace()
    assert base_facts == {}

    # test namespace.transform()
    ns = Namespace('prefix_')
    fc = BaseFactCollector(namespace=ns)

# Generated at 2022-06-22 22:44:45.921100
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['foo', 'bar']
    all_fact_subsets = {
        'foo': [FakeCollector('foo', ['bar'])],
        'bar': [FakeCollector('bar', ['baz'])],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['foo'] == set(['bar'])
    assert dep_map['bar'] == set(['baz'])



# Generated at 2022-06-22 22:44:58.283925
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from . import collectors
    from . import get_all_collectors

    all_collectors = get_all_collectors()

    selected_collectors = collector_classes_from_gather_subset(all_collector_classes=all_collectors,
                                                               valid_subsets=frozenset(('network',)),
                                                               minimal_gather_subset=frozenset(('all',)),
                                                               gather_subset=['network'],
                                                               gather_timeout=10,
                                                               platform_info={'system': 'Linux'})

    assert(len(selected_collectors) == 1)
    assert(selected_collectors[0] == collectors.LinuxNetworkCollector)

# Generated at 2022-06-22 22:45:01.321300
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        pass
    obj = TestCollector()
    result = obj.collect_with_namespace()
    assert result == {}



# Generated at 2022-06-22 22:45:02.268011
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass



# Generated at 2022-06-22 22:45:05.584646
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    module = object()
    collected_facts = object()
    assert obj.collect(module=module, collected_facts=collected_facts) == {}

# Generated at 2022-06-22 22:45:12.930956
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.platform import LinuxFactCollector
    from ansible.module_utils.facts.collector.generic import GenericFactCollector
    from ansible.module_utils.facts.collector.facter import FacterCollector

    #
    # Test1 : Entry point for all linux based systems
    #
    platform_info = dict(system='Linux')

    compat_platforms = [platform_info]

    # Known collectors
    all_collector_classes = [
        LinuxFactCollector,
        GenericFactCollector,
        FacterCollector,
    ]

    # Find collectors
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)


# Generated at 2022-06-22 22:45:15.107365
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    an_instance = CollectorNotFoundError()
    assert an_instance is not None



# Generated at 2022-06-22 22:45:25.716288
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import all_fact_subsets
    test_names = ['all', 'my_thing']
    assert find_unresolved_requires(test_names, all_fact_subsets) == set()

    test_names = ['my_thing']
    assert find_unresolved_requires(test_names, all_fact_subsets) == set(['all'])

    test_names = ['all', 'my_thing']
    my_thing_class = all_fact_subsets['my_thing'][0]
    my_thing_class.required_facts.add('my_other_thing')
    assert find_unresolved_requires(test_names, all_fact_subsets) == set(['my_other_thing'])



# Generated at 2022-06-22 22:45:33.669234
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        e = CycleFoundInFactDeps()
        assert e.args[0] == 'Cycle found in fact deps'
    except Exception as e:
        assert False, type(e)

    try:
        e = CycleFoundInFactDeps('foo')
        assert e.args[0] == 'foo'
    except Exception as e:
        assert False, type(e)
    try:
        e = CycleFoundInFactDeps('foo', 'bar')
        assert e.args[0] == 'foo'
        assert e.args[1] == 'bar'
    except Exception as e:
        assert False, type(e)



# Generated at 2022-06-22 22:45:35.741763
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    bc = BaseFactCollector()
    bc.collect_with_namespace(collected_facts=None)


# Generated at 2022-06-22 22:45:38.715725
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exception = CycleFoundInFactDeps()
    assert isinstance(exception, CycleFoundInFactDeps)


# Generated at 2022-06-22 22:45:46.554895
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.hardware.dmi import DmiFactCollector
    from ansible.module_utils.facts.hardware.lsbinventory import LsbinventoryFactCollector
    from ansible.module_utils.facts.system.os import OsFactCollector
    list_of_fact_objects = set([DmiFactCollector, LsbinventoryFactCollector, OsFactCollector])
    names = get_collector_names(['all'], set())
    class_of_collectors = build_dep_data(names, list_of_fact_objects)
    assert 'memory' in class_of_collectors.keys()
    assert 'lsbinventory' in class_of_collectors.keys()
    assert 'os' in class_of_collectors.keys()

# Generated at 2022-06-22 22:45:58.117992
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from .solaris import Collector as SolarisCollector
    from .facter import Collector as FactCollectionCollector
    from .aix import Collector as AixCollector
    from .netbsd import Collector as NetbsdCollector
    from .freebsd import Collector as FreeBSDCollector
    from .openbsd import Collector as OpenbsdCollector

    class MockCollector(BaseFactCollector):
        pass

    class RedHatCollector(MockCollector):
        name = 'redhat'

    class DebianCollector(MockCollector):
        name = 'debian'

    class SunosCollector(MockCollector):
        name = 'sunos'

    class OpenbsdCollector(MockCollector):
        name = 'openbsd'


# Generated at 2022-06-22 22:45:58.629603
# Unit test for function select_collector_classes
def test_select_collector_classes():
    pass



# Generated at 2022-06-22 22:46:01.031801
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    import pytest
    with pytest.raises(ValueError) as exc_info:
        raise UnresolvedFactDep(["A", "B", "C"])
    assert "A B C" in str(exc_info.value)


# Generated at 2022-06-22 22:46:13.035598
# Unit test for function resolve_requires
def test_resolve_requires():
    unresolved_fact_name_to_required_facts_map = {'a': {'b', 'c'},
                                                  'b': {'e'},
                                                  'c': {'d'},
                                                  'd': {'e'}}
    all_fact_subsets = {}
    for fact_name, fact_subset in unresolved_fact_name_to_required_facts_map.items():
        all_fact_subsets[fact_name] = [MockFactCollector(fact_name, fact_subset)]

    unresolved_requires = ['a']
    required_facts = set()
    for collector_name in unresolved_requires:
        required_facts.update(_get_requires_by_collector_name(collector_name, all_fact_subsets))


# Generated at 2022-06-22 22:46:14.242477
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    raise CollectorNotFoundError('some_collector')


# Generated at 2022-06-22 22:46:24.428837
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    def MockCollectorClass(base_class, name, fact_ids):
        # build a mock class since class isnt subscriptable in python2
        class_dict = {'_fact_ids':fact_ids, 'name':name}
        return type(name, (base_class,), class_dict)

    Collector = MockCollectorClass(BaseFactCollector, 'Collector', ['fact_id', 'fact_id2'])
    Collector2 = MockCollectorClass(BaseFactCollector, 'Collector2', ['fact_id2', 'fact_id3'])
    Collector3 = MockCollectorClass(BaseFactCollector, 'Collector3', ['fact_id4'])

    class_list = [Collector, Collector2, Collector3]

# Generated at 2022-06-22 22:46:27.024471
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps()
    assert isinstance(e, CycleFoundInFactDeps)
    assert isinstance(e, Exception)



# Generated at 2022-06-22 22:46:36.067017
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        _fact_ids = frozenset({'a'})
        required_facts = frozenset({'b'})

    class CollectorB(BaseFactCollector):
        _fact_ids = frozenset({'b'})
        required_facts = frozenset()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
    }

    unresolved = find_unresolved_requires(['a'], all_fact_subsets)
    assert unresolved == set(['b'])

    unresolved = find_unresolved_requires(['a', 'b'], all_fact_subsets)
    assert unresolved == set()

# Generated at 2022-06-22 22:46:47.076108
# Unit test for function tsort
def test_tsort():
    def tsort_data():
        return [
            ({'A': set(['B', 'C']), 'B': set(['D']), 'C': set(['D'])},
             [('D', set()), ('B', set(['D'])), ('C', set(['D'])), ('A', set(['B', 'C']))]),
            ({'A': set(['B']), 'B': set(['C']), 'C': set(['D'])},
             [('D', set()), ('C', set(['D'])), ('B', set(['C'])), ('A', set(['B']))])
        ]

    good_thing = False
    did_exception = False


# Generated at 2022-06-22 22:46:49.934161
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    a = BaseFactCollector()
    b = a.collect()
    # test for empty dictionary
    assert b == {}



# Generated at 2022-06-22 22:46:57.646817
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            facts_dict = {'fact1': 1, 'fact2': 2}
            return facts_dict

    # Use default namespace
    test_collector = TestFactCollector()
    collected_facts = test_collector.collect_with_namespace()
    assert collected_facts == {'fact1': 1, 'fact2': 2}

    class TestNamespace:
        def __init__(self, prefix):
            self.prefix = prefix

        def transform(self, key_name):
            return '%s%s' % (self.prefix, key_name)

    # Use namespace
    test_namespace = TestNamespace('test_prefix')

# Generated at 2022-06-22 22:47:09.348280
# Unit test for function get_collector_names
def test_get_collector_names():

    valid_subsets = frozenset(('all', 'hardware', 'network'))

    minimal_gather_subset = frozenset(('min', '!network'))

    platform_info = {
        'system': 'Linux'
    }

    # Test gather_subset=all
    gather_subset = ['all']
    aliases_map = defaultdict(set)
    aliases_map['network'] = ('device', 'interface')
    expected_subsets = frozenset(('hardware', 'network', 'device', 'interface'))

# Generated at 2022-06-22 22:47:21.460454
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Verify that we can find which collectors have unsatisfied requirements'''

    class FactCollectorA(BaseFactCollector):
        name = 'A'

    class FactCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = frozenset(['A'])

    class FactCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = frozenset(['A', 'B'])

    class FactCollectorD(BaseFactCollector):
        name = 'D'
        required_facts = frozenset(['E'])

    class FactCollectorE(BaseFactCollector):
        name = 'E'
        required_facts = frozenset(['F'])

    class FactCollectorF(BaseFactCollector):
        name = 'F'


# Generated at 2022-06-22 22:47:24.297820
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    collected_facts = {}
    actual_result = BaseFactCollector.collect_with_namespace(collected_facts=collected_facts)
    assert actual_result == {}



# Generated at 2022-06-22 22:47:33.228423
# Unit test for function get_collector_names
def test_get_collector_names():
    fake_valid_subsets = frozenset(['all', 'network'])
    fake_min_subsets = frozenset(['min'])
    fake_aliases_map = {'hardware': frozenset(['devices', 'dmi'])}

    fake_gather_subset = []
    assert get_collector_names(valid_subsets=fake_valid_subsets,
                               minimal_gather_subset=fake_min_subsets,
                               gather_subset=fake_gather_subset,
                               aliases_map=fake_aliases_map) == frozenset(['min'])

    fake_gather_subset = ['all']

# Generated at 2022-06-22 22:47:41.923020
# Unit test for function tsort
def test_tsort():
    tsort_tests = [
        ({'a': set(['b', 'c']),
          'b': set(['c']),
          'c': set(),
          },
         [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]
        )
    ]

    for data_in, expected_result in tsort_tests:
        if tsort(data_in) != expected_result:
            raise AssertionError('tsort_tests failed. data=%s expected="%s"' % (data_in, expected_result))



# Generated at 2022-06-22 22:47:53.276329
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collectors import (
        DEFAULT_SUBSET,
        Hardware,
        Network,
    )

    # valid_collector_names, seen_fact_ids, selected_fact_ids,
    # selected_collector_names
    valid_collector_names = {
        'hardware': Hardware,
        'network': Network,
    }

    all_fact_subsets = {
        'all': [Hardware],
        'hardware': [Hardware],
        'network': [Hardware, Network],
        'min': [],
        'dummy': [],
    }

    seen_collector_names = set()

    # test: empty list
    selected_collector_classes = select_collector_classes([], all_fact_subsets)
    assert not selected_collector

# Generated at 2022-06-22 22:48:00.784351
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(ValueError) as excinfo:
        raise UnresolvedFactDep('my message')
    assert 'my message' in str(excinfo.value)


# use a dict to make sure that it is simple to update and keep deps
# in sync.

# Generated at 2022-06-22 22:48:12.183517
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
  from json import loads
  from ansible.module_utils.facts.collectors.base import BaseFactCollector
  bfc = BaseFactCollector()
  namespaces_data_file = "./test/unittests/namespaces_data.json"
  with open(namespaces_data_file) as fh:
    namespaces_data = loads(fh.read())
  for d in namespaces_data:
    try:
      d['expected_result'] = eval(d['expected_result'])
    except:
      d['expected_result'] = d['expected_result']
  for d in namespaces_data:
    result = bfc._transform_dict_keys(d['data_dict'])

# Generated at 2022-06-22 22:48:24.764995
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes(['a', 'b', 'c'], {'a': [1], 'b': [2], 'c': [3]}) == [1, 2, 3]
    assert select_collector_classes(['b', 'a', 'c'], {'a': [1], 'b': [2], 'c': [3]}) == [2, 1, 3]
    assert select_collector_classes(['b', 'a', 'a'], {'a': [1], 'b': [2], 'c': [3]}) == [2, 1]
    assert select_collector_classes(['b', 'a', 'a'], {'a': [1, 4], 'b': [2], 'c': [3]}) == [2, 1, 4]
    assert select_collector_

# Generated at 2022-06-22 22:48:28.018346
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("foo")
    except ValueError as e:
        assert "foo" in e.__str__()



# Generated at 2022-06-22 22:48:39.568911
# Unit test for function build_dep_data
def test_build_dep_data():
    class MockCollectorA(BaseFactCollector):
        _fact_ids = ['a']
        name = 'a'
        required_facts = ['b']
    class MockCollectorB(BaseFactCollector):
        _fact_ids = ['b']
        name = 'b'
        required_facts = ['c']
    class MockCollectorC(BaseFactCollector):
        _fact_ids = ['c']
        name = 'c'
        required_facts = set()
    class MockCollectorD(BaseFactCollector):
        _fact_ids = ['d']
        name = 'd'
        required_facts = set()


# Generated at 2022-06-22 22:48:49.089362
# Unit test for function get_collector_names
def test_get_collector_names():
    assert(get_collector_names(gather_subset=['network']) == set(['network']))
    assert(get_collector_names(gather_subset=['network'], minimal_gather_subset=['network']) == set(['network']))
    assert(get_collector_names(gather_subset=['network'], minimal_gather_subset=['system']) == set(['network']))
    assert(get_collector_names(gather_subset=['!network'], minimal_gather_subset=['network']) == set([]))
    assert(get_collector_names(gather_subset=['!network']) == set([]))

# Generated at 2022-06-22 22:48:59.617221
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Linux32(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux32'

    class Linux64(Linux32):
        name = 'linux64'

    class DarwinWhileDrunk(BaseFactCollector):
        _platform = 'Darwin'
        name = 'drunkdarwin'

    class Sunshine(BaseFactCollector):
        _platform = 'Sunshine'
        name = 'sunshine'

    class Windows(BaseFactCollector):
        _platform = 'Windows'
        name = 'windows'

    class Generic(BaseFactCollector):
        name = 'generic'

    class GenericThatRequiresLinux(BaseFactCollector):
        name = 'generic_linux_required'
        required_facts = set(['os'])

# Generated at 2022-06-22 22:49:11.768082
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test gather subset 'all'
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network', 'hardware'])

    # Test gather subset 'min'
    assert get_collector_names(gather_subset=['min'],
                               valid_subsets=frozenset(['hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network'])

    # Test gather subset which includes the minimal gather subset

# Generated at 2022-06-22 22:49:14.583316
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # TODO: write a unit test that exercises collector_classes_fro
    pass



# Generated at 2022-06-22 22:49:23.219314
# Unit test for function resolve_requires
def test_resolve_requires():
    unresolved = {'a'}
    all_fact_subsets = {'a': []}

    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == {'a'}

    unresolved = {'a'}
    all_fact_subsets = {}

    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == set()

    unresolved = {'a'}
    all_fact_subsets = {'b': []}

    new_names = resolve_requires(unresolved, all_fact_subsets)
    assert new_names == set()

    unresolved = {'a', 'b'}
    all_fact_subsets = {'b': []}


# Generated at 2022-06-22 22:49:34.227533
# Unit test for function collector_classes_from_gather_subset

# Generated at 2022-06-22 22:49:45.137592
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        name = 'c1'
        required_facts = set(('a', 'b', 'e'))

    class Collector2(BaseFactCollector):
        name = 'c2'
        required_facts = set(('a', 'b'))

    class Collector3(BaseFactCollector):
        name = 'c3'
        required_facts = set(('b', 'd'))

    class Collector4(BaseFactCollector):
        name = 'c4'
        required_facts = set(('d', 'e'))

    class Collector5(BaseFactCollector):
        name = 'c5'
        required_facts = set()

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['c1'].append(Collector1)


# Generated at 2022-06-22 22:49:55.531551
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    # Testing with 2 collectors with 1 dependency between them
    all_fact_subsets = {'a': set(collector.BaseFactCollector), 'b': set(collector.BaseFactCollector), 'c': set(collector.BaseFactCollector)}
    all_fact_subsets['a'].__class__.required_facts = {'b'}
    all_fact_subsets['b'].__class__.required_facts = {'c'}
    collector_names = ['a', 'b', 'c']

    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert 'a' in dep_map, 'Collector "a" not found'

# Generated at 2022-06-22 22:50:05.389866
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'testcollector'
        _fact_ids = {'foo', 'bar'}

    collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector])
    assert collector_map['testcollector'] == [TestCollector]
    assert collector_map['foo'] == [TestCollector]
    assert collector_map['bar'] == [TestCollector]



# Generated at 2022-06-22 22:50:11.213518
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import remove_default_spec

  device_output = '''
'''
  parsed_output = '''
'''
  module = ''


  # Try to fail the arguments specifications
  argument_spec = dict(
    foo=dict(type='str'),
  )
  remove_default_spec(argument_spec)
  start_time = datetime.now().replace(microsecond=0)
  try:
    BaseFactCollector(argument_spec)
  except SystemExit:
    end_time = datetime.now().replace(microsecond=0)
    assert False, "Missing required arguments specification"

  # Test the facts output

# Generated at 2022-06-22 22:50:13.376146
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # pylint: disable=no-self-use
    CycleFoundInFactDeps()


# Generated at 2022-06-22 22:50:22.705537
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils._text import to_bytes

    class TestBaseFactCollector(BaseFactCollector):
        pass

    class TestPlatformFactCollector(TestBaseFactCollector):
        _fact_ids = {'fact_id_%s' % i for i in (1,2,3)}

        _platform = 'Platform'
        name = 'name'
        required_facts = set()

    TestPlatformFactCollector_1 = TestPlatformFactCollector

    TestPlatformFactCollector_2 = TestPlatformFactCollector
    TestPlatformFactCollector_2.name = 'another_name'

    TestFactCollector_1 = TestBaseFactCollector
    TestFactCollector_1.name = 'name'

# Generated at 2022-06-22 22:50:25.918110
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('CollectorNotFoundError 1')
    except CollectorNotFoundError as e:
        assert str(e) == 'CollectorNotFoundError 1'



# Generated at 2022-06-22 22:50:27.756134
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    obj = CycleFoundInFactDeps('test')
    assert obj.args == ('test',)



# Generated at 2022-06-22 22:50:35.281123
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['f1', 'f2', 'f3', 'f4', 'f5']

    def _get_requires_by_collector_name(collector_name):
        if collector_name == 'f2':
            return ['f3']
        if collector_name == 'f4':
            return ['f5']
        return []

    unresolved = find_unresolved_requires(
        collector_names,
        _get_requires_by_collector_name
    )

    assert len(unresolved) == 0

    unresolved = find_unresolved_requires(
        ['f2', 'f3', 'f5'],
        _get_requires_by_collector_name
    )

    assert len(unresolved) == 0


# Generated at 2022-06-22 22:50:45.398865
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'foo': ['bar'], 'bar': [], 'baz': ['foo']}
    assert resolve_requires(['baz'], all_fact_subsets) == set(['bar', 'foo', 'baz'])
    assert resolve_requires(['baz', 'foo'], all_fact_subsets) == set(['bar', 'foo', 'baz'])

    try:
        resolve_requires(['baz', 'missing'], all_fact_subsets)
        raise AssertionError('Should have raised an exception')
    except UnresolvedFactDep:
        # expected
        pass

    assert resolve_requires(['baz', 'missing', 'foo'], all_fact_subsets) == set(['bar', 'foo', 'baz'])

# Generated at 2022-06-22 22:50:57.811787
# Unit test for function resolve_requires
def test_resolve_requires():
    # prepare the all_fact_subsets for the test
    all_fact_subsets = {
        'a': [],
        'b': [],
    }

    # Test empty requires
    unresolved_requires = set()
    resolved = resolve_requires(unresolved_requires, all_fact_subsets)
    assert resolved == set()

    # Test simple resolve that are in all_fact_subsets
    unresolved_requires = {'a'}
    resolved = resolve_requires(unresolved_requires, all_fact_subsets)
    assert resolved == unresolved_requires

    # Test multiple require that are in all_fact_subsets
    unresolved_requires = {'a', 'b'}
    resolved = resolve_requires(unresolved_requires, all_fact_subsets)
    assert resolved == unresolved_requires

    # Test

# Generated at 2022-06-22 22:51:09.410877
# Unit test for function tsort
def test_tsort():
    unsorted_deps = {'collector1': set(['collector2']),
                     'collector2': set(['collector3']),
                     'collector3': set(['collector4']),
                     'collector4': set(['collector1'])}

    try:
        tsort(unsorted_deps)
        assert False, 'Expected a CycleFoundInFactDeps exception, got nothing'
    except CycleFoundInFactDeps:
        pass

    unsorted_deps = {'collector1': set(['collector2']), 
                     'collector2': set(['collector3']),
                     'collector3': set(['collector4']),
                     'collector4': set(['collector5']),
                     'collector5': set([])}

    sorted_dep

# Generated at 2022-06-22 22:51:15.615108
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''Test that a CollectorNotFoundError can be constructed

    As this is a subclass of dict, we call the dict constructor with the
    appropriate paramters to test that we can raise a
    CollectorNotFoundError.
    '''
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert e.args[0] == "Collector not found: 'foo'"



# Generated at 2022-06-22 22:51:17.032543
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert BaseFactCollector().collect() == {}

# Generated at 2022-06-22 22:51:27.320778
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorClass(BaseFactCollector):
        _fact_ids = set()

        _platform = None
        name = None
        required_facts = set()

    class DarwinCollectorClass(CollectorClass):
        _platform = 'Darwin'
        name = 'darwin'
    class LinuxCollectorClass(CollectorClass):
        _platform = 'Linux'
        name = 'linux'
    class GenericCollectorClass(CollectorClass):
        _platform = None
        name = 'generic'

    darwin_platform_info = {'system': 'Darwin'}
    linux_platform_info = {'system': 'Linux'}
    freebsd_platform_info = {'system': 'FreeBSD'}

    all_collector_classes = [DarwinCollectorClass, LinuxCollectorClass, GenericCollectorClass]

# Generated at 2022-06-22 22:51:31.656455
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    module = dict(name='test_module')
    fact_name = 'test_fact'
    unresolved_fact_name = 'unresolved_test_fact'
    try:
        raise UnresolvedFactDep(module, fact_name, unresolved_fact_name)
    except UnresolvedFactDep as e:
        assert e.module == module
        assert e.fact_name == fact_name
        assert e.unresolved_fact_name == unresolved_fact_name


# Generated at 2022-06-22 22:51:36.345901
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep()
    except UnresolvedFactDep as e:
        assert str(e) == 'Unresolved fact dependency'



# Generated at 2022-06-22 22:51:39.145054
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('myfoo')
    except CollectorNotFoundError as e:
        assert str(e) == "Collector 'myfoo' not found."



# Generated at 2022-06-22 22:51:50.633691
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.default import DefaultFactCollector
    all_fact_subsets = {'test1': [DefaultFactCollector]}
    all_fact_subsets['test1'][0].required_facts = {'test2'}
    collector_names = ['test1']

    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'test2'}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'test2'}
    assert find_unresolved_requires(['not_a_collector'], all_fact_subsets) == {'not_a_collector'}

# Generated at 2022-06-22 22:52:02.162403
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.facts import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    class TestCollector1(BaseFactCollector):
        name = 'test_collect_1'

    class TestCollector2(BaseFactCollector):
        name = 'test_collect_2'

    class TestCollector3(BaseFactCollector):
        name = 'test_collect_2'



# Generated at 2022-06-22 22:52:14.159825
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from six import add_metaclass
    from types import MethodType
    from ansible.module_utils.facts.utils.get_collectors import get_fact_collector_class


    # Helper classes for testing find_unresolved_requires
    @add_metaclass(get_fact_collector_class)
    class TestCollectorA():
        name = 'a'
        required_facts = set(['b'])

    @add_metaclass(get_fact_collector_class)
    class TestCollectorB():
        name = 'b'

    @add_metaclass(get_fact_collector_class)
    class TestCollectorC():
        name = 'c'
        required_facts = set(['b'])


# Generated at 2022-06-22 22:52:17.320744
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test_key')
    except CollectorNotFoundError as e:
        assert str(e) == 'test_key'



# Generated at 2022-06-22 22:52:28.931843
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector, CollectorNotFoundError

    class FakeCollector(BaseFactCollector):
        _fact_ids = set()
        name = 'fake'
        required_facts = set()

    class FakeCollectorWithDep(BaseFactCollector):
        _fact_ids = set()
        name = 'fake_dep'
        required_facts = {'fake', 'fake_dep'}

    class FakeCollectorWithDep2(BaseFactCollector):
        _fact_ids = set()
        name = 'fake_dep2'
        required_facts = {'fake', 'fake_dep', 'fake_dep2'}

    class FakeCollectorWithDep3(BaseFactCollector):
        _fact_ids = set()

# Generated at 2022-06-22 22:52:30.739749
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.name is None
    assert fc.required_facts == set()
    assert fc.fact_ids == set([None])


# Generated at 2022-06-22 22:52:42.674347
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorWithOneFact(BaseFactCollector):
        name = 'the_fact'
        required_facts = set()
        _fact_ids = set(['the_other_fact'])

    class CollectorWithTwoFacts(BaseFactCollector):
        name = 'two_facts'
        required_facts = set()
        _fact_ids = set(['fact_one', 'fact_two'])

    collectors = [
        CollectorWithOneFact,
        CollectorWithTwoFacts
    ]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    assert len(fact_id_to_collector_map) == 5
    assert len(aliases_map) == 2

    assert 'the_fact' in aliases_map

# Generated at 2022-06-22 22:52:45.475363
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class MyFact(BaseFactCollector):
        name = 'myfact'

    fact = MyFact()
    assert fact.name == 'myfact'
    assert fact.fact_ids == {'myfact'}



# Generated at 2022-06-22 22:52:52.433436
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    print()
    print("Test collect_with_namespace")
    print("===========================")
    class MyCollector(BaseFactCollector):
        name = 'somecol'
        def collect(self, module=None, collected_facts=None):
            facts_dict = {'some': 'value'}
            return facts_dict

    collector_inst = MyCollector()
    print(collector_inst.collect_with_namespace())
    print()

# Generated at 2022-06-22 22:52:59.727698
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class DummyCollector(BaseFactCollector):
        name = 'dummy'

    dc = DummyCollector()
    assert 'dummy' in dc.fact_ids
    return dc


# Generated at 2022-06-22 22:53:02.998514
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector
    assert BaseFactCollector == collector.BaseFactCollector

# use helpers.py for the other unit tests

# TODO: rename this to 'get_fact_collector_list'

# Generated at 2022-06-22 22:53:14.592023
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # collector_names and all_fact_subsets are defined in 'find_unresolved_requires'
    # need to mock them up here to test the function.
    # the following is the mapping of collector_names to requires.
    # the function returns all requires that are not in collector_names.
    all_fact_subsets = {
        'A': ['A1', 'A2'],
        'B': ['B1', 'B2'],
        'C': ['C1', 'C2']
    }

    # we have mock up three sets of collector_names to test different cases:
    # 1. collector_names does not contain any requires
    # 2. collector_names does not contain all requires
    # 3. collector_names contains all requires
    collector_names1 = ['A', 'B', 'C']
    collector_names

# Generated at 2022-06-22 22:53:21.288773
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector_1': [
        ],
        'collector_2': [
        ],
        'collector_3': [
        ],
        'collector_4': [
        ],
    }

    # collector_1 requires collector_2, so we should return collector_2
    all_fact_subsets['collector_1'].append(collector_mock(['collector_2']))
    unresolved = find_unresolved_requires(['collector_1'], all_fact_subsets)
    assert unresolved == {'collector_2'}

    # collector_1 requires collector_2, but we request both, so this should work
    all_fact_subsets['collector_1'].append(collector_mock(['collector_2']))
   