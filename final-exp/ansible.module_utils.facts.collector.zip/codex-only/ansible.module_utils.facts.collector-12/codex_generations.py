

# Generated at 2022-06-22 22:43:21.380162
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TmpCollector(BaseFactCollector):
        _fact_ids = set(['final_id'])
        required_facts = set(['initial_id'])

    a = TmpCollector()

    assert 'final_id' in a.fact_ids
    assert 'initial_id' in a.fact_ids


# Generated at 2022-06-22 22:43:32.233829
# Unit test for function tsort

# Generated at 2022-06-22 22:43:34.506444
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    try:
        BaseFactCollector()
    except TypeError:
        assert False, "BaseFactCollector() constructor can't be called"
#



# Generated at 2022-06-22 22:43:46.536316
# Unit test for function tsort
def test_tsort():
    test_input = defaultdict(set)
    test_input['a'] = set(['b'])
    test_input['b'] = set(['c'])
    test_input['c'] = set()
    assert tsort(test_input) == [
        ('c', set()),
        ('b', set(['c'])),
        ('a', set(['b']))
    ]

    test_input['x'] = set(['y'])
    test_input['y'] = set(['z'])
    test_input['z'] = set(['x'])
    try:
        tsort(test_input)
        assert False, 'expected CycleFoundInFactDeps exception'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-22 22:43:49.332514
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector()
    assert collector.collectors == []
    assert collector.namespace is None



# Generated at 2022-06-22 22:43:53.397396
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fact_collector = BaseFactCollector()
    assert fact_collector.namespace is None
    assert fact_collector.collectors == []
    # fact_ids is a set containing the name
    assert fact_collector.fact_ids == {'BaseFactCollector'}


# Generated at 2022-06-22 22:43:56.394756
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps('A', 'B')

    assert type(exc) == CycleFoundInFactDeps
    assert str(exc) == 'Cycle found in metadata\nA depends on B\nB depends on A'


# Generated at 2022-06-22 22:44:02.637774
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
    # test with no namespace
    test_collector = TestCollector()
    assert test_collector.collect_with_namespace() == {}
    # test with namespace
    test_collector = TestCollector(namespace=Namespace(prefix='test'))
    assert test_collector.collect_with_namespace() == {}
    facts_dict = {'fact1': 'value1'}
    assert test_collector.collect_with_namespace(collected_facts=facts_dict) == {'test_fact1': 'value1'}



# Generated at 2022-06-22 22:44:06.779402
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class do_nothing(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            pass

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    compat_platforms = [platform.uname()]
    # this list is a list of classes. Not instances of classes
    all_collector_classes = [do_nothing]

    # this tests with just 1 class. So it should return just that 1 class.
    platform_match = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert do_nothing in platform_match
    assert len(platform_match) == 1

    # add

# Generated at 2022-06-22 22:44:17.927818
# Unit test for function tsort
def test_tsort():
    # no dependencies
    dep_map = {
        'a': set(),
        'b': set(),
        'c': set(),
        'd': set(),
        'e': set(),
        'f': set(),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list[0][0] == 'a'
    assert len(sorted_list) == len(dep_map.keys())
    for node, edges in sorted_list:
        for edge in edges:
            assert node != edge

    # some with no deps, some with deps including self, mixed deps

# Generated at 2022-06-22 22:44:23.023108
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collectors = [dict, list, dict]
    compat_platforms = ['asdfasdf', 'asdfasdf', 'asdfasdf']

    assert find_collectors_for_platform(all_collectors, compat_platforms) == set([dict, list, dict])



# Generated at 2022-06-22 22:44:28.821740
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class FakeCollector1(BaseFactCollector):
        _platform = 'Fake1'
        name = 'fake1'

    class FakeCollector2(BaseFactCollector):
        _platform = 'Fake1'
        name = 'fake1_extra'

    FakeCollector3 = BaseFactCollector
    FakeCollector3.name = 'fake3'

    all_collector_classes = [FakeCollector1, FakeCollector2, FakeCollector3]

    platform_info = dict(system='Fake1')

    # we have 2 Fake1 collectors and 1 generic collector
    found_collectors_count = len(find_collectors_for_platform(all_collector_classes, [platform_info]))
    assert found_collectors_count == 3, "Collectors not returned correctly"

    # make sure we get the same amount of

# Generated at 2022-06-22 22:44:38.773459
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Make sure all facts classes are present
    assert 'arp' in all_facts_subsets
    assert 'netstat' in all_facts_subsets
    assert 'ip_facts' in all_facts_subsets
    assert 'interfaces' in all_facts_subsets
    assert 'mounts' in all_facts_subsets
    assert 'dns' in all_facts_subsets
    assert 'default_ipv4' in all_facts_subsets
    assert 'default_ipv6' in all_facts_subsets
    assert 'fqdn' in all_facts_subsets
    assert 'hostname' in all_facts_subsets
    assert 'domain' in all_facts_subsets
    assert 'lsb' in all_facts_subsets
    assert 'pkg_mgr' in all_facts_subsets

# Generated at 2022-06-22 22:44:44.856594
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts.collectors import ansible_collector
    f = BaseFactCollector(collectors=[ansible_collector])
    assert isinstance(f, BaseFactCollector)
    assert f.collectors == [ansible_collector]
    assert f.fact_ids == set(['ansible_local'])
    del f



# Generated at 2022-06-22 22:44:52.160340
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1'}

        def collect(self, module=None, collected_facts=None):
            pass

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test3'}

        def collect(self, module=None, collected_facts=None):
            pass

    class TestCollector3(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4'}

        def collect(self, module=None, collected_facts=None):
            pass

    class TestCollector4(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-22 22:44:59.417636
# Unit test for function get_collector_names

# Generated at 2022-06-22 22:45:04.575849
# Unit test for function tsort
def test_tsort():
    deps = {'a': set(['b', 'c']), 'b': set(['c']), 'c': set(['d']), 'd': set(['a'])}
    try:
        tsort(deps)
        assert False
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-22 22:45:05.960967
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert BaseFactCollector().collect() == {}


# Generated at 2022-06-22 22:45:08.284003
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector(collectors=[], namespace="").namespace == ""
    assert BaseFactCollector(collectors=[], namespace=None).namespace == None


# Generated at 2022-06-22 22:45:11.981583
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    bfc = BaseFactCollector()
    assert isinstance(bfc.collect(), dict)


# Generated at 2022-06-22 22:45:16.794017
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(ValueError) as excinfo:
        raise UnresolvedFactDep('arg1', 'arg2')

    assert str(excinfo.value) == "UnresolvedFactDep('arg1', 'arg2')"



# Generated at 2022-06-22 22:45:23.763084
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    def collect(self, module=None, collected_facts=None):
        return {'foo': 'bar'}

    collector = BaseFactCollector()
    collector.collect = collect
    collector.namespace = None
    assert collector.collect_with_namespace() == {'foo': 'bar'}

    collector.namespace = lambda x: '%s_suffix' % x
    assert collector.collect_with_namespace() == {'foo_suffix': 'bar'}



# Generated at 2022-06-22 22:45:31.663716
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # no params
    x = UnresolvedFactDep()
    assert x.fact_name is None
    assert x.collector_name is None

    # missing fact name
    x = UnresolvedFactDep('bar')
    assert x.fact_name is None
    assert x.collector_name == 'bar'

    # missing collector name
    x = UnresolvedFactDep(fact_name='foo')
    assert x.fact_name == 'foo'
    assert x.collector_name is None

    # both
    x = UnresolvedFactDep('foo', collector_name='bar')
    assert x.fact_name == 'foo'
    assert x.collector_name == 'bar'



# Generated at 2022-06-22 22:45:37.767357
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        name = 'test_a'
        _platform = 'test_platform'

    class CollectorB(BaseFactCollector):
        name = 'test_b'
        _platform = 'test_platform'

    class CollectorC(BaseFactCollector):
        name = 'test_c'
        _platform = 'test_platform'

    class CollectorD(BaseFactCollector):
        name = 'test_d'
        _platform = 'test_platform_weighted_25'

    class CollectorE(BaseFactCollector):
        name = 'test_e'
        _platform = 'test_platform_weighted_50'

    class CollectorF(BaseFactCollector):
        name = 'test_f'
        _platform = 'test_platform_weighted_75'

    all_collect

# Generated at 2022-06-22 22:45:49.083166
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):

        _fact_ids = {'id1', 'id2'}

    class Collector2(BaseFactCollector):

        _fact_ids = {'id3', 'id4'}

    class Collector3(BaseFactCollector):

        _fact_ids = {'id5', 'id6'}
        name = 'collector3'

    class Collector4(BaseFactCollector):

        _fact_ids = {'id7', 'id8'}
        name = 'collector4'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({Collector1, Collector2, Collector3, Collector4})
    assert fact_id_to_collector_map['id1'] == [Collector1]
    assert fact

# Generated at 2022-06-22 22:45:54.110911
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Test constructor for class CycleFoundInFactDeps

    This method tests the constructor of class CycleFoundInFactDeps.
    '''
    try:
        raise CycleFoundInFactDeps('Foo')
    except CycleFoundInFactDeps as exc:
        assert exc.args[0] == 'Foo'


# Generated at 2022-06-22 22:45:57.044770
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as e:
        assert isinstance(e, CycleFoundInFactDeps)


# Generated at 2022-06-22 22:46:06.102623
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import sys
    import os

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from ansible.module_utils.facts.collector.all import AllFactCollector

    collector_classes = [AllFactCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_classes)

    # test that each collector is in the map
    for collector_class in collector_classes:
        for fact_id in collector_class.fact_ids:
            assert fact_id in fact_id_to_collector_map
            assert fact_id_to_collector_map[fact_id][0] is collector_class

    # test that each alias

# Generated at 2022-06-22 22:46:12.933588
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    """ Unit test for constructor of class UnresolvedFactDep"""
    # pylint: disable=redefined-outer-name
    fact = 'foo'
    required_by = 'bar'
    error = UnresolvedFactDep(fact, required_by)
    assert error.args[0] is fact
    assert error.args[1] is required_by
    assert str(error) == "resolving 'foo' requires 'bar', but 'bar' is not available"



# Generated at 2022-06-22 22:46:17.129097
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # create and register two fact collectors
    class One(BaseFactCollector):
        name = 'one'
        required_facts = set()

    class Two(BaseFactCollector):
        name = 'two'
        required_facts = set(['one'])

    all_collector_classes = [One, Two]

    valid_subsets = frozenset(['one', 'two'])

    minimal_gather_subset = frozenset()

    gather_subset = ['all']

    aliases_map = defaultdict(set)

    platform_info = {'system': platform.system()}


# Generated at 2022-06-22 22:46:26.012548
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['foo']) == set(['foo'])
    assert get_collector_names(['foo'], gather_subset=['bar']) == set()

    assert get_collector_names(['foo'], gather_subset=['!bar']) == set(['foo'])
    assert get_collector_names(['foo'], gather_subset=['!min']) == set(['foo'])
    assert get_collector_names(['foo'], gather_subset=['!all']) == set(['foo'])
    assert get_collector_names(['foo'], gather_subset=['!foo']) == set()


# Generated at 2022-06-22 22:46:28.496848
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    exception = UnresolvedFactDep('a', 'b')
    assert str(exception) == "fact a requires fact b to be collected, which requires fact a"



# Generated at 2022-06-22 22:46:30.455211
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with pytest.raises(KeyError):
        raise CollectorNotFoundError('Name of collector')


# Generated at 2022-06-22 22:46:41.426569
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.hardware import HardwareFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector

    collectors_for_platform = [HardwareFactCollector, NetworkFactCollector, PkgMgrFactCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map.keys() == {'hardware', 'network', 'pkg_mgr'}
    assert fact_id_to_collector_map['hardware'] == [NetworkFactCollector, HardwareFactCollector]
    assert fact_

# Generated at 2022-06-22 22:46:43.743680
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector()

    assert collector.fact_ids is not None
    assert collector.collectors is not None


# Generated at 2022-06-22 22:46:51.031432
# Unit test for function get_collector_names

# Generated at 2022-06-22 22:46:53.574951
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fdep = UnresolvedFactDep('foo')
    assert fdep.args[0] == 'foo'



# Generated at 2022-06-22 22:47:05.223246
# Unit test for function select_collector_classes
def test_select_collector_classes():
    test_all_fact_subsets = {
        'all': {CollectorA, CollectorB},
        'network': {CollectorB},
        'hardware': {CollectorA},
    }

    # Test with "all"
    collector_names = ['all']
    # We expect to get same results whether we list the names or the classes
    selected_collector_classes = select_collector_classes(collector_names, test_all_fact_subsets)
    assert len(selected_collector_classes) == 2
    assert CollectorA in selected_collector_classes
    assert CollectorB in selected_collector_classes

    # Test with "network"
    collector_names = ['network']
    selected_collector_classes = select_collector_classes(collector_names, test_all_fact_subsets)
   

# Generated at 2022-06-22 22:47:08.022885
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''Unit test for construction of class CollectorNotFoundError'''
    CollectorNotFoundError('Testing')


# Generated at 2022-06-22 22:47:13.477967
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.collector import BaseFactCollector
    from mock import patch, Mock, MagicMock
    facts_dict = Mock()
    testObj = BaseFactCollector()
    if testObj.collect(collected_facts = facts_dict) == facts_dict:
        print('True')
    else:
        print('False')   

# Generated at 2022-06-22 22:47:19.789647
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    names = set(['name1', 'name2', 'name3'])
    for collector_name in names:
        dep_map = build_dep_data(names, collector.all_fact_subsets)
        assert(len(dep_map[collector_name]) == 0)
        assert(len(dep_map) == 3)



# Generated at 2022-06-22 22:47:30.497135
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['dmi', 'devices'])
    minimal_gather_subset = frozenset(['dmi'])
    aliases_map = defaultdict(set, {'hardware': ['devices', 'dmi']})

    # Test with gather_subset = ['all']
    gather_subset = ['all']
    additional_subsets = get_collector_names(valid_subsets=valid_subsets,
                                             minimal_gather_subset=minimal_gather_subset,
                                             gather_subset=gather_subset,
                                             aliases_map=aliases_map)
    # Expected result is valid_subsets without minimal_gather_subset
    expected_subsets = valid_subsets - minimal_gather_subset
    assert additional

# Generated at 2022-06-22 22:47:42.183704
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import timeout
    import unittest
    import sys
    import json
    class test_BaseFactCollector(unittest.TestCase):
        def setUp(self):
            self.fact_collector =  BaseFactCollector()

# Generated at 2022-06-22 22:47:53.557006
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector

    test_collector_classes = [
        collector.TestCollector,
        collector.TestCollector2
    ]

    linux_fact = {
        'system': 'Linux',
        'distribution': 'Debian',
        'distribution_major_version': '9',
    }
    freebsd_fact = {
        'system': 'FreeBSD',
        'distribution': 'FreeBSD',
        'distribution_major_version': '11',
    }
    found_collectors = []
    found_collectors.extend(find_collectors_for_platform(
        all_collector_classes=test_collector_classes,
        compat_platforms=[
            linux_fact,
            freebsd_fact,
        ]
    ))

# Generated at 2022-06-22 22:48:05.528228
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''
    Test function build_fact_id_to_collector_map
    '''
    class TestFact:
        '''
        Test class
        '''
        _fact_ids = set(['test1', 'test2', 'test3'])
        name = 'test'

    class TestFact2:
        '''
        Test class 2
        '''
        _fact_ids = set(['test2', 'test4'])
        name = 'test2'

    all_collector_classes = [TestFact, TestFact2]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

    assert fact_id_to_collector_map['test'][0] == TestFact
    assert fact_id_

# Generated at 2022-06-22 22:48:15.673438
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # pylint: disable=too-many-locals
    test_classes = []

    class TestClass1(BaseFactCollector):
        requires_facts = set(['a'])
        name = 'test3'

    class TestClass2(BaseFactCollector):
        requires_facts = set(['test3'])
        name = 'test2'

    class TestClass3(BaseFactCollector):
        requires_facts = set(['test2'])
        name = 'test1'

    class TestClass4(BaseFactCollector):
        requires_facts = set(['test2'])
        name = 'test1'
        _platform = 'Linux'

    class TestClass5(BaseFactCollector):
        requires_facts = set(['test1', 'test2'])
        name = 'test4'
       

# Generated at 2022-06-22 22:48:19.228024
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    test_0 = BaseFactCollector()
    assert test_0.collect(module=None, collected_facts=None) == {}
    return True



# Generated at 2022-06-22 22:48:29.241448
# Unit test for function build_dep_data
def test_build_dep_data():
    test_cases = [{
        'result': {
            'a': {'b'},
            'b': {'c'}
        },
        'fact_classes': [
            {'name': 'a', 'required_facts': ['b']},
            {'name': 'b', 'required_facts': ['c']}
        ]
    }]

    def Collector(dict_):
        return type('Collector',
                    (BaseFactCollector,),
                    {k: v for k, v in dict_.items()})

    for tc in test_cases:
        expected = tc['result']
        all_fact_subsets = {
            klass['name']: [Collector(klass)]
            for klass in tc['fact_classes']}

        collector_names = list(expected.keys())


# Generated at 2022-06-22 22:48:38.288953
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector()
    assert isinstance(collector.fact_ids, set)
    assert len(collector.fact_ids) == 1

    # by default, it adds the name of the class to the set
    assert collector.name in collector.fact_ids

    my_collector = BaseFactCollector('foo')
    assert len(my_collector.collectors) == 1
    assert my_collector.collectors == 'foo'
    assert len(my_collector.fact_ids) == 1
    assert my_collector.name in my_collector.fact_ids



# Generated at 2022-06-22 22:48:38.939248
# Unit test for function select_collector_classes
def test_select_collector_classes():
    pass



# Generated at 2022-06-22 22:48:48.675598
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # No transform
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import LinuxDistributionFactCollector
    # Namespace is a transforming namespace and does not affect the name of the fact
    namespace = Namespace(lambda key_name: key_name, 'linux_distribution_')
    # Create a instance of the LinuxDistributionFactCollector with namespace
    linux_dist = LinuxDistributionFactCollector(namespace=namespace)
    # Get facts
    facts = linux_dist.collect_with_namespace()
    # Check if the result is a dict with a key 'linux_distribution' and the value is a dict with a key 'name'

# Generated at 2022-06-22 22:48:59.312984
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # Mockup of the class BaseFactCollector
    class BaseFactCollector(object):
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors or []
            self.namespace = namespace
            self.fact_ids = set([self.name])
            self.fact_ids.update(self._fact_ids)

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    # Mockup of class UbuntuCollector
    class UbuntuCollector(BaseFactCollector):
        _platform = 'Linux'

# Generated at 2022-06-22 22:49:07.259448
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.config_file import ConfigFileFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.ip_interfaces import (
        IpInterfacesFactCollector,
    )

   

# Generated at 2022-06-22 22:49:09.716301
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():

    bfc = BaseFactCollector()

    assert isinstance(bfc, BaseFactCollector)

# Deps are a map from the collectors required to the collectors that require them

# Generated at 2022-06-22 22:49:16.548237
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires(set(['one']), {'one': True}) == set(['one'])
    assert resolve_requires(set(['one', 'two']), {'one': True}) == set(['one'])
    assert resolve_requires(set(['one', 'two', 'three']), {'one': True, 'two': True}) == set(['one', 'two'])
    assert resolve_requires(set(['one', 'two', 'three']), {}) == set()



# Generated at 2022-06-22 22:49:24.447880
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import FACT_CACHE_TIMEOUT
    from ansible.module_utils.facts import default_collectors

    key = 'test_BaseFactCollector_collect_with_namespace'
    process_cache = defaultdict(dict)

    # create a Collector
    class MyCollector(BaseFactCollector):
        name = 'test_BaseFactCollector_collect_with_namespace'
        _fact_ids = set([name])

        def collect(self, module=None, collected_facts=None):
            return {'key': 'value'}

    test_collector = MyCollector()

    # test collect_with_namespace with a Namespace object

# Generated at 2022-06-22 22:49:34.563981
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''
        test if the correct collector class is returned for each platform.

        Define a class named TestCollector and write the desired
        platform_match behaviour for the same.
    '''
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'generic'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    compat_platforms = [{'system': 'Darwin'}, {'system': 'Linux'}]
    all_collector_classes = [TestCollector]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 1
    assert TestCollector

# Generated at 2022-06-22 22:49:45.482745
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    @add_platform_to_collector_classes([
        {'system': 'Linux', 'release': '2.2.26-14.7'},
        {'system': 'Darwin', 'release': 'Darwin Kernel Version 14.0.0: Fri'
                                       ' Sep 19 00:26:44 PDT 2014; root:xnu-2782.1.97~2'
                                       '/RELEASE_X86_64'}
    ])

    class BoringTestCollector(BaseFactCollector):
        name = 'test_name'

    class DepTestCollector(BaseFactCollector):
        name = 'dep_test_name'
        required_facts = ['test_name']

    class PlatformSpecificTestCollector(BaseFactCollector):
        name = 'platform_specific_test_name'

# Generated at 2022-06-22 22:49:51.435616
# Unit test for function tsort
def test_tsort():
    bad_map = {'b': {'a'}, 'c': {'b'}, 'a': {'c'}}
    good_map = {'b': {'a'}, 'a': {'c'}, 'c': set()}

    try:
        tsort(bad_map)
    except CycleFoundInFactDeps:
        pass
    else:
        raise AssertionError

    tsort(good_map)
    assert good_map == good_map



# Generated at 2022-06-22 22:49:58.255743
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'B': [None, None],
        'C': [None, None],
        'D': [None, None],
        'E': [None, None],
        }
    unresolved = set(['A', 'D', 'E'])
    resolved = resolve_requires(unresolved, all_fact_subsets)
    assert resolved == set(['D', 'E'])



# Generated at 2022-06-22 22:50:07.434232
# Unit test for function tsort
def test_tsort():
    dep_list = [('t1', 't2'),
               ('t2', 't3'),
               ('t3', 't4'),
               ('t4', 't5'),
               ('t5', 't6'),
               ('t6', 't7'),
               ('t7', 't5'),
               ('t8', 't9'),
               ('t9', 't10'),
               ('t10', 't7'),
               ('t11', 't12'),
               ('t12', 't13'),
               ('t13', 't14'),
               ('t14', 't15'),
               ('t15', 't16'),
               ('t16', 't17'),
               ('t17', 't18'),
               ('t18', 't19')]

    dep_map = defaultdict(set)

# Generated at 2022-06-22 22:50:19.893324
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    class A(BaseFactCollector):
        name='a'
        _fact_ids = set(['a'])
    class B(BaseFactCollector):
        name='b'
        _fact_ids = set(['b'])
        required_facts = set(['c', 'd'])
    class C(BaseFactCollector):
        name='c'
        _fact_ids = set(['c'])
        required_facts = set(['a'])
    class D(BaseFactCollector):
        name='d'
        _fact_ids = set(['d'])
        required_facts = set(['a'])
    class G(BaseFactCollector):
        name='g'
        _fact_ids = set(['g'])

# Generated at 2022-06-22 22:50:29.898460
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['A', 'B', 'C']
    all_fact_subsets = {
            'A': [DummyClass('A', ['B']), DummyClass('A', ['C', 'B'])],
            'B': [DummyClass('B', ['C']), DummyClass('B', ['A'])],
            'C': [DummyClass('C', ['A', 'B'])],
            }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['A'] == set(['B', 'C'])
    assert dep_map['B'] == set(['C', 'A'])
    assert dep_map['C'] == set(['A', 'B'])



# Generated at 2022-06-22 22:50:42.278566
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import platform
    import sys
    class Foo(BaseFactCollector):
        _fact_ids = frozenset()
        name = 'foo'
        required_facts = frozenset()
        _platform = 'Mock'
        @classmethod
        def platform_match(cls, platform_info):
            platform_info['system'] = cls._platform
            if platform_info['system'] == cls._platform:
                return True
    class Bar(BaseFactCollector):
        _fact_ids = frozenset()
        name = 'bar'
        required_facts = frozenset()
        # NOTE: do not set _platform

    class Baz(BaseFactCollector):
        _fact_ids = frozenset()
        name = 'baz'
        required_facts = frozenset()

# Generated at 2022-06-22 22:50:49.345406
# Unit test for function resolve_requires
def test_resolve_requires():
    # Test case 1
    all_fact_subsets = {'lspci': [], 'lsblk': [], 'systemd': [], 'virtual': [], 'osx': [], 'dmi': [], 'pkgmgr': [], 'devices': [], 'lsusb': []}
    unresolved_requires = set(['lspci', 'lsblk', 'systemd', 'virtual', 'osx', 'dmi', 'pkgmgr', 'devices', 'lsusb'])
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set(['lspci', 'lsblk', 'systemd', 'virtual', 'osx', 'dmi', 'pkgmgr', 'devices', 'lsusb'])

    # Test case 2

# Generated at 2022-06-22 22:51:01.616278
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('one', 'two'),
                               minimal_gather_subset=('minimal',),
                               gather_subset=['one', '!two'],
                               aliases_map={'group': {'one', 'two'}}) == {'minimal', 'one'}
    assert get_collector_names(valid_subsets=('one', 'two'),
                               minimal_gather_subset=('minimal',),
                               gather_subset=['!group'],
                               aliases_map={'group': {'one', 'two'}}) == {'minimal', 'two'}

# Generated at 2022-06-22 22:51:11.705759
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorBasic(BaseFactCollector):
        name = 'basic'
        _fact_ids = ['basic', 'basic.subset']

    class CollectorOther(BaseFactCollector):
        name = 'other'
        _fact_ids = ['other', 'other.subset']

    class CollectorEmpty(BaseFactCollector):
        name = 'empty'
        _fact_ids = []

    # basic test with 2 collectors
    collectors = (CollectorBasic, CollectorOther)
    fact_id_to_collector_map, aliases_map = \
        build_fact_id_to_collector_map(collectors)

    assert len(fact_id_to_collector_map) == 5
    assert len(aliases_map) == 2

    # verify aliases map

# Generated at 2022-06-22 22:51:16.301602
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    BASE = BaseFactCollector()
    expected = {}
    result = BASE.collect()
    assert result == expected
    assert BASE.fact_ids == {'Generic'}
    assert BASE.collectors == []
    assert BASE.namespace is None
    assert BASE.required_facts == set()


# Generated at 2022-06-22 22:51:19.762759
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError("A", "B", "C")
    assert "A" == e.args[0]
    assert "B" == e.args[1]
    assert "C" == e.args[2]



# Generated at 2022-06-22 22:51:29.779148
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class TestCollector1(BaseFactCollector):
        name = 'test_collector1'
        _fact_ids = frozenset(['test_fact1'])

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = frozenset(['test_fact2', 'test_fact3'])

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _fact_ids = frozenset(['test_fact4', 'test_fact5'])

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'
        _fact_ids = frozenset(['test_fact5', 'test_fact6'])


# Generated at 2022-06-22 22:51:32.009484
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    '''
    >>> bc = BaseFactCollector()
    >>> bc.namespace
    >>> bc.name is None
    True
    '''
    pass

#
# Collectors that have no other dependencies, just python stdlib.
#

# TODO: split this out into separate classes

# Generated at 2022-06-22 22:51:44.194225
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import default

    original_already_seen_collectors = default.already_seen_collectors
    default.already_seen_collectors = set()


# Generated at 2022-06-22 22:51:54.991271
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import fact_collector
    collector_class = type(
        'CollectorT',
        (fact_collector.BaseFactCollector,),
        {
            'name': 'TestCollector',
            '_fact_ids': ('test1',),
            '_platform': 'Linux',
            'required_facts': ('facts_module',)
        }
    )
    expected_id_to_collector_map = {'TestCollector': [collector_class], 'test1': [collector_class]}
    expected_aliases_map = {'TestCollector': {'test1'}}
    id_to_collector_map, aliases_map = build_fact_id_to_collector_map((collector_class,))
    assert id_to_collector_map

# Generated at 2022-06-22 22:51:59.723407
# Unit test for function get_collector_names
def test_get_collector_names():
    # no gather_subset, return valid_subset plus 'min'
    valid_subsets = frozenset(['foo', 'bar'])
    minimal_gather_subset = frozenset(['min'])
    aliases_map = defaultdict(set)
    assert get_collector_names(valid_subsets, minimal_gather_subset, None, aliases_map) == frozenset(['foo', 'bar', 'min'])

    # gather_subset is 'all', return all subsets
    assert get_collector_names(valid_subsets, minimal_gather_subset, ['all'], aliases_map) == frozenset(['foo', 'bar'])

    # gather_subset is '!foo'

# Generated at 2022-06-22 22:52:12.584185
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'c': [MockCollector(['a', 'b'])],
        'b': [MockCollector(['a'])],
        'a': [MockCollector([])],
    }

    def test_order(order, expect_unresolved=set()):
        result = find_unresolved_requires(order, all_fact_subsets)
        assert result == expect_unresolved, 'Invalid unresolved result'

    test_order(['a', 'b', 'c'])
    test_order(['c', 'b', 'a'])

    test_order(['a', 'b'], expect_unresolved={'c'})
    test_order(['c', 'a'], expect_unresolved={'b'})


# Generated at 2022-06-22 22:52:15.146740
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    my_error = UnresolvedFactDep('a', 'b')
    assert "'a' is required by 'b' but was not found in available facts" in str(my_error)


# Generated at 2022-06-22 22:52:23.082145
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class DummyHostnameCollector(BaseFactCollector):
        name = 'hostname'
        _fact_ids = set(['hostname'])

    class DummyInterfacesCollector(BaseFactCollector):
        name = 'interfaces'
        _fact_ids = set(['interfaces', 'network'])

    class DummyPlatformCollector(BaseFactCollector):
        name = 'platform'
        _fact_ids = set(['platform'])

    class DummyPlatformBaseCollector(BaseFactCollector):
        name = 'platform_base'
        _fact_ids = set(['platform_base'])

    collectors_for_platform = [
        DummyHostnameCollector,
        DummyInterfacesCollector,
        DummyPlatformCollector,
        DummyPlatformBaseCollector,
    ]
    expected

# Generated at 2022-06-22 22:52:34.034612
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector as collector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.system.distribution as distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import ansible.module_utils.facts.system.distribution as distribution
    from ansible.module_utils.facts.system.distribution import DistroNameToVersion
    import ansible.module_utils.facts.system.distribution as distribution
    from ansible.module_utils.facts.system.distribution import Distro

# Generated at 2022-06-22 22:52:44.459740
# Unit test for function tsort
def test_tsort():
    sorted_list = [('node7', {'node5'}), ('node5', {'node2', 'node1'}), ('node1', {'node0'}), ('node2', {'node0'}), ('node0', set())]
    found = tsort({
        'node7': {'node5'},
        'node5': {'node2', 'node1'},
        'node1': {'node0'},
        'node2': {'node0'},
        'node0': set(),
    })
    assert found == sorted_list

    assert tsort({'node1': set(), 'node0': set()}) == [('node1', set()), ('node0', set())]


# Generated at 2022-06-22 22:52:55.132892
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'redhat': [RedHatFactCollector],
        'debian': [DebianFactCollector],
        'network': [NetworkFactCollector, NetworkFactCollector2]
    }

    selected_collector_classes = select_collector_classes(
        collector_names=['redhat', 'network'],
        all_fact_subsets=all_fact_subsets
    )

    # order matters
    assert selected_collector_classes == [RedHatFactCollector, NetworkFactCollector, NetworkFactCollector2]

    selected_collector_classes = select_collector_classes(
        collector_names=['redhat', 'debian', 'network'],
        all_fact_subsets=all_fact_subsets
    )

    # order matters
    assert selected_collector_

# Generated at 2022-06-22 22:53:05.303073
# Unit test for function tsort
def test_tsort():
    assert tsort([]) == []

    assert tsort({'a': set(), 'b': {'a'}}) == [('a', set()), ('b', {'a'})]

    assert tsort({'a': {'b'}, 'b': {'c'}, 'c': {'d'}, 'd': set()}) == [('d', set()),
                                                                       ('c', {'d'}),
                                                                       ('b', {'c'}),
                                                                       ('a', {'b'})]

    try:
        tsort({'a': set(), 'b': {'a', 'b'}})
    except CycleFoundInFactDeps:
        pass
    else:
        raise Exception("Expected an exception")



# Generated at 2022-06-22 22:53:15.640946
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FakeCollector1(BaseFactCollector):
        _fact_ids = ['foo', 'bar']

    class FakeCollector2(BaseFactCollector):
        _fact_ids = ['shazbot', 'nanu']

    class FakeCollector3(BaseFactCollector):
        _fact_ids = ['snack', 'attack', 'foo']

    class FakeCollector4(BaseFactCollector):
        _fact_ids = ['foo']

    class FakeCollector5(BaseFactCollector):
        _fact_ids = ['foo', 'bar']

    all_collector_classes = (FakeCollector1, FakeCollector2, FakeCollector3, FakeCollector4, FakeCollector5)
