

# Generated at 2022-06-22 22:43:17.802188
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('invalid_key')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'invalid_key'



# Generated at 2022-06-22 22:43:18.683964
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass


# Generated at 2022-06-22 22:43:22.042400
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps(['A', 'B', 'C'])
    assert "Cycle found in fact dependencies: A, B, C" == str(e)



# Generated at 2022-06-22 22:43:32.807353
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import PrefixingNamespace
    from ansible.module_utils.facts.collector.test.test_base import DummyFactCollector

    module = True
    collected_facts = {}

    # Test with namespace
    namespace = PrefixingNamespace('prefix')
    collector = DummyFactCollector(namespace=namespace)
    collected_facts = collector.collect_with_namespace(module=module, collected_facts=collected_facts)
    assert collected_facts == {'prefix_fact': True}

    # Test without namespace
    namespace = None
    collector = DummyFactCollector(namespace=namespace)
    collected_facts = collector.collect_with_namespace(module=module, collected_facts=collected_facts)

# Generated at 2022-06-22 22:43:34.254973
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    result = BaseFactCollector()
    assert result


# Generated at 2022-06-22 22:43:38.401784
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import network

    found_collectors = []
    found_collectors.extend(find_collectors_for_platform([network.NetworkCollector], [{'system': 'Darwin'}]))
    assert(network.NetworkCollector in found_collectors)



# Generated at 2022-06-22 22:43:49.438154
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import Collector
    # collector to collect nothing
    class NullCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {}
    class NamespaceFoo(object):
        def transform(self, key_name):
            return 'Foo_' + key_name

    collected_facts = {}
    # test that the returned value is empty in case of an empty list of collectors
    null_collector_list = Collector()
    assert null_collector_list.collect_with_namespace() == {}
    # test that the returned value is empty in case of an empty list of collectors
    # and the namespace is 'Foo'
    null_collector_list = Collector()

# Generated at 2022-06-22 22:43:58.503286
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    collect_class_A = type('CollectorA', (BaseFactCollector,), dict(
                            name='collector_a',
                            _fact_ids=set(['foo', 'bar']),
                            _platform='Linux'))
    collect_class_B = type('CollectorB', (BaseFactCollector,), dict(
                            name='collector_b',
                            _fact_ids=set(['baz']),
                            _platform='Linux'))


    all_collector_classes = frozenset([collect_class_A, collect_class_B])

    class TestPlatform:
        system = 'Linux'
        release = 'test_release'
        distro = TestPlatform
        distro_release = TestPlatform

    platform_info = TestPlatform()

    found_collectors = find_collectors

# Generated at 2022-06-22 22:44:09.776514
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from . import base
    from . import windows

    all_fact_subsets = {
        'base': [base.BaseFactCollector],
        'hardware': [base.HardwareFactCollector],
        'network': [base.NetworkFactCollector],
    }

    unresolved = find_unresolved_requires(['base'], all_fact_subsets)
    assert not unresolved

    unresolved = find_unresolved_requires(['network'], all_fact_subsets)
    assert unresolved == {'base'}

    unresolved = find_unresolved_requires(['hardware'], all_fact_subsets)
    assert unresolved == {'base'}


# Generated at 2022-06-22 22:44:20.200315
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.software

    collectors = [ansible.module_utils.facts.collectors.base.BaseLinuxFactCollector,
                  ansible.module_utils.facts.collectors.network.NetworkFactCollector,
                  ansible.module_utils.facts.collectors.hardware.HardwareCollector,
                  ansible.module_utils.facts.collectors.virtual.VirtualCollector]


# Generated at 2022-06-22 22:44:31.372312
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.platform import MacOS, Linux, NetBSD, OpenBSD

    import pytest


# Generated at 2022-06-22 22:44:32.704900
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    err = UnresolvedFactDep('foo')
    assert str(err) == 'foo'



# Generated at 2022-06-22 22:44:40.958156
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    """Test constructor and methods of class BaseFactCollector"""
    bfc = BaseFactCollector()
    assert(bfc.collectors == [])
    assert(bfc.collect({}) == {})
    assert(bfc.collect_with_namespace({}) == {})
    assert(isinstance(bfc.namespace, type(None)))
    assert(bfc.fact_ids == set([bfc.name]))
    assert(bfc.fact_ids == set([None]))

    bfc = BaseFactCollector(namespace=None)
    assert(bfc.namespace is None)
    bfc = BaseFactCollector(namespace='None')
    assert(bfc.namespace == 'None')
    bfc = BaseFactCollector(namespace='x')

# Generated at 2022-06-22 22:44:50.328037
# Unit test for function get_collector_names
def test_get_collector_names():
    gather_subset = ['all', 'network', '!facter']
    valid_subsets = frozenset(['all', 'network', 'facter'])

    assert get_collector_names(valid_subsets, gather_subset=gather_subset) == frozenset(['network'])

    gather_subset = ['network', '!facter']
    assert get_collector_names(valid_subsets, gather_subset=gather_subset) == frozenset(['network'])

    gather_subset = ['!all', '!network', '!facter']
    assert get_collector_names(valid_subsets, gather_subset=gather_subset) == frozenset([])

    gather_subset = ['min', '!all', '!network', '!facter']

# Generated at 2022-06-22 22:45:01.305931
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.hardware.linux as hardware_linux
    import ansible.module_utils.facts.network.linux as network_linux
    import ansible.module_utils.facts.system.linux as system_linux

    # create a bunch of fake facts collectors for this test
    class CollectorLinux(BaseFactCollector):
        _platform = 'Linux'
        name = 'debian'
        required_facts = set(('key1',))

    class CollectorLinuxUbuntu(BaseFactCollector):
        _platform = 'Linux'
        name = 'ubuntu'
        required_facts = set(('key1',))

    class CollectorLinuxRedhat(BaseFactCollector):
        _platform = 'Linux'
        name = 'redhat'
        required_facts = set(('key2',))


# Generated at 2022-06-22 22:45:05.182966
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class NoopCollector(BaseFactCollector):
        name = 'noop'
        def collect(self, module=None, collected_facts=None):
            return {}
    assert NoopCollector._platform == 'Generic'



# Generated at 2022-06-22 22:45:06.940939
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except KeyError as e:
        assert str(e) == "Collector with name 'test' not found"


# Generated at 2022-06-22 22:45:11.836982
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collect = {}

    print('\nTest method collect of BaseFactCollector class')
    bfc = BaseFactCollector()
    assert isinstance(bfc.collect(collected_facts=collect), dict)



# Generated at 2022-06-22 22:45:17.464781
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('notfound')
    except Exception as err:
        assert isinstance(err, CollectorNotFoundError), err
        assert err.args[0] == 'notfound'
    else:
        raise AssertionError('CollectorNotFoundError not raised')



# Generated at 2022-06-22 22:45:19.951877
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    x = UnresolvedFactDep('test_UnresolvedFactDep')
    assert x.message == 'test_UnresolvedFactDep'


# Generated at 2022-06-22 22:45:29.943927
# Unit test for function select_collector_classes
def test_select_collector_classes():
    '''Test select_collector_classes()'''
    from ansible.module_utils.facts import collector
    class TestCollector(BaseFactCollector):
        name = 'test_collector'

    assert TestCollector not in select_collector_classes(['test_collector'], {})

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test_collector'].append(TestCollector)
    assert TestCollector in select_collector_classes(['test_collector'], all_fact_subsets)
    assert TestCollector not in select_collector_classes([], all_fact_subsets)

    # now test that it doesn't repeat itself

# Generated at 2022-06-22 22:45:34.725571
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class MyPlatform(BaseFactCollector):
        _fact_ids = set(['myfact'])
        name = 'myplatform'
        required_facts = set(['required1', 'required2'])

    fact_collector = MyPlatform()
    assert fact_collector.fact_ids == set(['required1', 'required2', 'myfact'])
    assert fact_collector.required_facts == set(['required1', 'required2'])



# Generated at 2022-06-22 22:45:42.057840
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(set(['a', 'b']), dict(
        a=[BaseFactCollector(name='a', required_facts=('b', 'c'))],
        b=[BaseFactCollector(name='b', required_facts=('a', 'b'))]))
    assert dep_map['a'] == set(['b', 'c'])
    assert dep_map['b'] == set(['a', 'b'])



# Generated at 2022-06-22 22:45:45.771087
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('A', 'B')
    except CycleFoundInFactDeps as exc:
        assert str(exc) == "Cycle in fact deps: A -> B -> A"


# Generated at 2022-06-22 22:45:57.386741
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class SomeCollector(BaseFactCollector):
        _fact_ids = set(['some_fact', 'some_other_fact'])

    class OtherCollector(BaseFactCollector):
        _fact_ids = set(['other_fact', 'other_other_fact'])

    collectors_for_platform = find_collectors_for_platform([SomeCollector, OtherCollector], ['Generic'])

    # no need to validate the structure of the dicts, just make sure it doesn't
    # explode.
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert 'some_fact' in fact_id_to_collector_map
    assert len(fact_id_to_collector_map) == 4

    assert set

# Generated at 2022-06-22 22:46:06.900193
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'one'
        def collect(self, module=None, collected_facts=None):
            return {}

    class Collector2(BaseFactCollector):
        name = 'one'
        def collect(self, module=None, collected_facts=None):
            return {}

    all_fact_subsets = defaultdict(list)
    all_fact_subsets[Collector1.name].append(Collector1)
    all_fact_subsets[Collector2.name].append(Collector2)

    selected_collectors = select_collector_classes(['one'], all_fact_subsets)
    assert len(selected_collectors) == 1

    selected_collectors = select_collector_classes(['one', 'one'], all_fact_subsets)


# Generated at 2022-06-22 22:46:18.324062
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import os
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.s390x.hw import S390XHwFactCollector
    from ansible.module_utils.facts.s390x.lpar import S390XLparFactCollector
    from ansible.module_utils.facts.s390x.misc import S390XMiscFactCollector


# Generated at 2022-06-22 22:46:26.685166
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['hardware'])
    minimal_gather_subset = frozenset(['network'])
    gather_subset = ['network', '!hardware']

    aliases_map = defaultdict(set)
    aliases_map['hardware'].add('devices')
    aliases_map['os'].add('software')
    aliases_map['os'].add('selinux')
    aliases_map['os'].add('kernel')

    assert get_collector_names(valid_subsets, minimal_gather_subset,
                               gather_subset, aliases_map) == frozenset(['network'])

    gather_subset = ['hardware', '!network']


# Generated at 2022-06-22 22:46:35.782474
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    ''' Verify that the constructor of class BaseFactCollector works.

        Note: The constructor works as expected as long as children classes
              are defined and initialized properly. Children classes should
              define a name, and this name is used as part of the fact_ids
              collection. The internal namespace is defined by the namespace
              parameter, which is used to change the key names in a dictionary
              returned by the collect method.

        Note: the _transform_dict_keys method is used only to transform the
              keys of the dictionary returned by the collect method. This method
              does not change the name of the fact_ids.
    '''

    # collector_a, collector_b and collector_c are examples of children classes
    # Define these classes

    # Example of children class with defined name, required facts and that
    # collects a single fact "fact1"

# Generated at 2022-06-22 22:46:42.642433
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils._text import to_bytes

    f = BaseFactCollector()
    assert f is not None
    assert f.platform == platform.system()
    assert isinstance(f.name, (type(None), str))
    assert to_bytes(f.namespace) == to_bytes(None)
    assert f.fact_ids == set()
    assert f._fact_ids == set()
    assert set(f.collectors) == set()



# Generated at 2022-06-22 22:46:44.162224
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    y = UnresolvedFactDep('x')
    assert 'x' in str(y)



# Generated at 2022-06-22 22:46:45.516927
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    CycleFoundInFactDeps()
    CycleFoundInFactDeps('foo')



# Generated at 2022-06-22 22:46:47.327457
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(ValueError):
        UnresolvedFactDep()



# Generated at 2022-06-22 22:46:51.158617
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors == []
    assert fc.namespace is None
    assert fc.fact_ids == {None}



# Generated at 2022-06-22 22:46:51.829797
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    pass



# Generated at 2022-06-22 22:46:56.223065
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('foo', 'bar')
    except UnresolvedFactDep as e:
        assert str(e) == "Unresolved fact 'foo' depends on fact 'bar'"
        assert e.fact == 'foo'
        assert e.depends_on == 'bar'



# Generated at 2022-06-22 22:47:08.174042
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector(BaseFactCollector):
        _fact_ids = set(['one', 'two', 'three'])

        name = 'test_fact_collector'

    test_collector_list = [TestFactCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(test_collector_list)

    assert 'test_fact_collector' in fact_id_to_collector_map
    assert 'test_fact_collector' in aliases_map
    assert 'one' in fact_id_to_collector_map
    assert 'one' in aliases_map
    assert 'two' in fact_id_to_collector_map
    assert 'two' in aliases_map
    assert 'three' in fact_id_to_

# Generated at 2022-06-22 22:47:16.412654
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import pytest
    from collections import Counter
    class C1(BaseFactCollector):
        name = 'c1'

    class C2(BaseFactCollector):
        name = 'c2'

    class C3(BaseFactCollector):
        name = 'c3'

    all_fact_subsets = {
        'c1': [C1, C1, C1],
        'c2': [C2, C2, C2],
        'c3': [C3],
    }

    assert Counter(select_collector_classes(['c1', 'c1', 'c2', 'c3'], all_fact_subsets)) == Counter([
        C1,
        C2,
        C3
    ])



# Generated at 2022-06-22 22:47:27.924077
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # Test that if no collector names are passed, no unresolved
    # requires are found.
    collector_names = ()
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test that when a collector name has an unresolved require,
    # that unresolved require is returned by the function.
    collector_names = ('a', 'b')

    class A(object):

        required_facts = ('b',)

    all_fact_subsets['a'] = [A]


# Generated at 2022-06-22 22:47:40.747586
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # intentionally make test fail
    from ansible.module_utils.facts import collector as facts_collector
    all_collector_classes = [x for x in vars(facts_collector).values()
                             if isinstance(x, type) and issubclass(x, BaseFactCollector)]

    # test good subset
    valid_subsets = frozenset(('network', 'virtual', 'all'))
    minimal_gather_subset = frozenset(('network',))
    gather_subset = ('virtual',)

    # nothing is known about the platform here
    platform_info = {'system': 'solaris'}

    # this is what should be returned
    good_results = [
        facts_collector.NetworkFactCollector,
        facts_collector.VirtualFactCollector,
    ]

    #

# Generated at 2022-06-22 22:47:51.350849
# Unit test for function resolve_requires
def test_resolve_requires():
    '''Test of resolve_requires()'''
    all_fact_subsets = {'c': ['c1', 'c2'], 'b': ['b1', 'b2'], 'd': ['d1', 'd2']}
    test_unresolved = set(['b', 'z'])
    expected_names = set(['b'])
    assert resolve_requires(test_unresolved, all_fact_subsets) == expected_names
    test_unresolved = set(['b', 'z'])
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(test_unresolved, all_fact_subsets)

FACT_COLLECTION_TIMEOUT = 60


# Generated at 2022-06-22 22:47:55.848572
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class DummyCollector(BaseFactCollector):
        name = 'dummy'

    assert None is DummyCollector.platform_match({'system': 'Other'})

    class DummyPlatform(BaseFactCollector):
        _platform = 'DummyPlatform'
        name = 'dummy'

    assert DummyPlatform is DummyPlatform.platform_match({'system': 'DummyPlatform'})

    class DummyPlatformGeneric(BaseFactCollector):
        _platform = 'DummyPlatformGeneric'
        name = 'dummy'

    assert DummyPlatformGeneric is DummyPlatformGeneric.platform_match({'system': 'DummyPlatformGeneric'})

    class _TestFactCollector1(BaseFactCollector):
        name = '1'
        required_facts = frozenset()


# Generated at 2022-06-22 22:48:02.001183
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    assert str(UnresolvedFactDep('test1', 'test2')) == 'test1 -> test2'
    assert repr(UnresolvedFactDep('test1', 'test2')) == "<UnresolvedFactDep 'test1' -> 'test2'>"



# Generated at 2022-06-22 22:48:06.264923
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['service', 'devices'], {'devices': [DevicesCollector], 'service': [ServiceCollector]})
    assert dep_map == {'devices': {'dmi'}, 'service': {'devices'}}


# Generated at 2022-06-22 22:48:08.045960
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    assert {} == fc.collect()



# Generated at 2022-06-22 22:48:10.515477
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    msg = 'foo'
    err = CollectorNotFoundError(msg)
    assert str(err) == msg


# Generated at 2022-06-22 22:48:16.375840
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Use a made up class to represent a fact collection module
    class FactCollector:
        _platform = 'Linux'
        name = 'linux'

    # Create a platform info dict to test
    platform_info = {'system': 'Linux'}

    # Check a match is found for the Linux fact module
    assert find_collectors_for_platform({FactCollector}, [platform_info]) == {FactCollector}
    # Check no match for a non-matching platform info dict
    assert find_collectors_for_platform({FactCollector}, [{}]) == set()
    # Check no match for no platform info dict
    assert find_collectors_for_platform({FactCollector}, []) == set()



# Generated at 2022-06-22 22:48:27.579923
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # test classes
    class CollectorGeneric(BaseFactCollector):
        _platform = 'Generic'
        name = 'generic'

    class CollectorPosix(BaseFactCollector):
        _platform = 'posix'
        name = 'posix'

    class CollectorPosixNotGeneric(BaseFactCollector):
        _platform = 'posix'
        name = 'posix_not_generic'

    class CollectorMoreSpecific(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux'

    class CollectorNXOS(BaseFactCollector):
        _platform = 'Nexus'
        name = 'nxos'

    class CollectorASA(BaseFactCollector):
        _platform = 'ASA'
        name = 'asa'


# Generated at 2022-06-22 22:48:39.125366
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError()
    assert 'CollectorNotFoundError()' in repr(c)
    c = CollectorNotFoundError(msg='testing')
    assert 'testing' in repr(c)
    c = CollectorNotFoundError(msg='test %s', a='test')
    assert "test test" in repr(c)
    c = CollectorNotFoundError(msg='test %s', a='test', b='testing')
    assert "test test" in repr(c)
    assert "b='testing'" in repr(c)
    c = CollectorNotFoundError(msg='test %s', a='test', b='testing', c='tested')
    assert "test test" in repr(c)
    assert "b='testing'" in repr(c)
    assert "c='tested'" in repr(c)



# Generated at 2022-06-22 22:48:48.807715
# Unit test for function find_unresolved_requires

# Generated at 2022-06-22 22:48:55.113338
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Define class methods
    class TestFactCollector0:
        pass

    class TestFactCollector1:
        pass

    class TestFactCollector2:
        pass

    assert collector_classes_from_gather_subset(all_collector_classes=[
                                                TestFactCollector0, TestFactCollector1, TestFactCollector2]) == [TestFactCollector0, TestFactCollector1, TestFactCollector2]



# Generated at 2022-06-22 22:48:57.777216
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  bfc = BaseFactCollector()
  assert bfc.collect() == {}, "expected {}"


# Generated at 2022-06-22 22:49:02.462080
# Unit test for function resolve_requires
def test_resolve_requires():
    '''resolve_requires returns a set of requires'''
    all_fact_subsets = {
        'fact1': ['c1'],
        'fact2': ['c2']
    }
    unresolved_requires = set(['fact1', 'fact2'])
    assert resolve_requires(unresolved_requires, all_fact_subsets) == \
        set(['fact1', 'fact2'])



# Generated at 2022-06-22 22:49:13.110064
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test1'
        def collect(self, module=None, collected_facts=None):
            fact_dict = {'foo': 'bar', 'bar': 'baz'}
            return fact_dict

    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
    except ImportError:
        # Skip the test if the namespace code is not available
        return

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        def collect(self, module=None, collected_facts=None):
            fact_dict = {'foo': 'bar', 'bar': 'baz'}
            return fact_dict

    class TestCollector3(BaseFactCollector):
        name = 'test2'

# Generated at 2022-06-22 22:49:17.032981
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    ''' Test that CollectorNotFoundError's constructor works '''
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert type(e) is CollectorNotFoundError
        assert e.message == 'test'



# Generated at 2022-06-22 22:49:18.969080
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
  retrieved_facts = {}
  assert BaseFactCollector.collect_with_namespace(collected_facts=retrieved_facts) == {}


# Generated at 2022-06-22 22:49:25.004937
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.namespace import collect_facts as module_collect_facts

    # make a mock 'all_fact_subsets' that covers the needs of the test.
    # populate with some known good collectors
    collector1 = type('Collector1', (BaseFactCollector,), {'name': 'collector1'})
    collector2 = type('Collector2', (BaseFactCollector,), {'name': 'collector2'})
    collector3 = type('Collector3', (BaseFactCollector,), {'name': 'collector3', 'required_facts': ('collector2',)})


# Generated at 2022-06-22 22:49:34.689705
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''
    The following code assumes that all facts collectors will be loaded from
    ansible.module_utils.facts.collectors. The following monkeypatch will
    load all collectors as if they are loaded from find_collectors_for_platform
    '''
    def dummy_load_collectors_from_dir(*_):
        all_collector_classes = [DummyLinuxFactCollector]
        return all_collector_classes
    import ansible.module_utils.facts.collectors
    ansible.module_utils.facts.collectors.load_collectors_from_dir = dummy_load_collectors_from_dir
    # load base collector class
    from ansible.module_utils.facts.collector import BaseFactCollector
    # load find_collectors_for_platform

# Generated at 2022-06-22 22:49:45.567704
# Unit test for function get_collector_names
def test_get_collector_names():
    # Correct retrieval of collectors with all
    assert get_collector_names(gather_subset=['all']) == {'all'}
    
    # Correct retrieval of collectors with min
    assert get_collector_names(gather_subset=['all']) == {'min'}
    
    # Correct retrieval of collectors with custom subset
    assert get_collector_names(gather_subset=['custom']) == {'custom'}
    
    # Correct retrieval of collectors with negated subset
    # When negated subset is given we expect all non negated subsets
    # The negated subset is excluded from the retrieved collectors
    assert get_collector_names(gather_subset=['!dmi']) == {'all'}
    
    # Correct retrieval of collectors with negated 'all' subset
    #

# Generated at 2022-06-22 22:49:55.674781
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import platform

    class NetworkFactCollector(BaseFactCollector):
        name = 'network'
        _fact_ids = ('ipv4_interfaces', 'ipv6_interfaces')

    class DummyFactCollector(BaseFactCollector):
        name = 'dummy'
        _fact_ids = ('dummy_fact', 'dummy_fact2')

    class DummyGenericFactCollector(BaseFactCollector):
        name = 'generic-dummy'
        _fact_ids = ('generic_dummy_fact', 'generic_dummy_fact2')

    class DummyGenericFactCollector2(BaseFactCollector):
        name = 'generic-dummy2'
        _fact_ids = ('generic_dummy_fact3', 'generic_dummy_fact4')


# Generated at 2022-06-22 22:50:05.175613
# Unit test for function tsort

# Generated at 2022-06-22 22:50:06.328486
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with pytest.raises(KeyError):
        raise CollectorNotFoundError('msg')



# Generated at 2022-06-22 22:50:11.730598
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class all_collector_classes_mock:
        _platform = 'Generic'
        name = None

        def __init__(self, name, platform):
            self.name = name
            self._platform = platform

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls

    assert find_collectors_for_platform([], ['Linux']) == set()

    expected_collector_classes = [
        all_collector_classes_mock('solaris', 'Solaris'),
        all_collector_classes_mock('linux', 'Linux'),
        all_collector_classes_mock('generic', 'Generic'),
    ]


# Generated at 2022-06-22 22:50:21.801852
# Unit test for function tsort
def test_tsort():
    # test case from https://rosettacode.org/wiki/Topological_sort#Python
    unsorted_map = {
        '7': ['11'],
        '5': ['11', '8'],
        '3': ['8', '10'],
        '11': ['2', '9', '10'],
        '8': ['9'],
    }
    expected_result = [
        ('7', set(['11'])),
        ('5', set(['11', '8'])),
        ('3', set(['8', '10'])),
        ('11', set(['2', '9', '10'])),
        ('8', set(['9'])),
        ('2', set()),
        ('9', set()),
        ('10', set()),
    ]
    result

# Generated at 2022-06-22 22:50:31.624406
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    # no namespace
    fact_collector = TestCollector()
    assert fact_collector.collect_with_namespace() == {'foo': 'bar'}

    # with namespace
    fact_collector = TestCollector(
        namespace=Namespace(prefix='ansible_', suffix=''),
    )
    assert fact_collector.collect_with_namespace() == {'ansible_foo': 'bar'}

    # with namespace, but no namespace keys
    fact_collector = TestCollector()
    assert fact_collector.collect_with_namespace() == {'foo': 'bar'}



# Generated at 2022-06-22 22:50:35.236186
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    msg = 'foo'
    ufd = UnresolvedFactDep(msg)
    assert str(ufd) == msg


# Generated at 2022-06-22 22:50:43.107405
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bfc = BaseFactCollector()
    assert bfc.name is None
    assert bfc.required_facts == {}
    assert bfc.namespace is None
    assert bfc.fact_ids == {None}
    assert bfc.collect() == {}
    assert bfc.collect_with_namespace() == {}
    assert bfc._transform_name('simple name') == 'simple name'
    assert bfc._transform_dict_keys({'first': 1, 'second': 2}) == {'first': 1, 'second': 2}



# Generated at 2022-06-22 22:50:46.417082
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires(set(["test"]), {"test": ["test"]}) == set(["test"])
    assert resolve_requires(set(["test"]), {}) == set()
    assert resolve_requires(set(["test"]), {"test2": ["test2"]}) == set()



# Generated at 2022-06-22 22:50:58.514979
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    from ansible.module_utils.facts import collection
    from ansible.module_utils.facts import collector

    class A(collector.BaseFactCollector):
        # '_fact_ids' is a set of collector names this is also known as
        # None implies the collector name is the class name, in this case 'A'
        _fact_ids = None
        name = 'A'
        required_facts = frozenset(['E'])

    class B(collector.BaseFactCollector):
        _fact_ids = None
        name = 'B'
        required_facts = frozenset(['A'])

    class C(collector.BaseFactCollector):
        _fact_ids = None
        name = 'C'
        required_facts = frozenset(['B', 'A'])


# Generated at 2022-06-22 22:51:01.671708
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    inst = BaseFactCollector()
    assert isinstance(inst.collect(collected_facts=None, module=None), dict)



# Generated at 2022-06-22 22:51:11.777293
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''Test a set of collectors for a platform'''
    class TestCollector(BaseFactCollector):
        name = 'testcollector'
        _platform = 'Generic'

        def collect(self):
            return {}

    class TestCollector2(TestCollector):
        name = 'testcollector2'

    all_collector_classes = [TestCollector, TestCollector2]

    valid_subsets = frozenset(['all', '!all', 'testcollector', '!testcollector', 'testcollector2'])

    platform_info = {'system': 'Generic'}


# Generated at 2022-06-22 22:51:22.524865
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.distribution import BsdDistributionCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionCollector

    # Collectors for platform test
    collectors_for_platform = [NetworkCollector, SystemCollector, DistributionCollector,
                               BsdDistributionCollector, LinuxDistributionCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

# Generated at 2022-06-22 22:51:24.960389
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    for arg in [1, 2, "hello"]:
        try:
            raise UnresolvedFactDep(arg)
        except UnresolvedFactDep as e:
            assert e.args == (arg, )



# Generated at 2022-06-22 22:51:30.244369
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # pylint: disable=unused-variable
    # pylint: disable=missing-docstring
    # pylint: disable=bare-except
    # pylint: disable=no-member
    def test_cycle():
        try:
            raise CycleFoundInFactDeps()
        except CycleFoundInFactDeps:
            pass
        except Exception:
            assert False, 'unexpected exception'
    test_cycle()



# Generated at 2022-06-22 22:51:36.014374
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['collector1'], {'collector1': [MockClass('collector1', ['dep1', 'dep2'])]})
    assert dep_map['collector1'] == {'dep1', 'dep2'}


# Generated at 2022-06-22 22:51:44.562403
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'foo': [],
        'bar': [],
        'baz': [],
        'splat': []
    }

    assert {'foo', 'bar'} == resolve_requires({'foo', 'bar'}, all_fact_subsets)
    assert {'foo', 'bar', 'baz'} == resolve_requires({'foo', 'bar', 'baz'}, all_fact_subsets)
    try:
        resolve_requires({'foo', 'splat'}, all_fact_subsets)
        raise Exception('should have errored with UnresolvedFactDep')
    except UnresolvedFactDep:
        pass



# Generated at 2022-06-22 22:51:48.584835
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('foo')
    except CycleFoundInFactDeps as e:
        assert(str(e) == 'foo')



# Generated at 2022-06-22 22:51:56.747321
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from functools import partial
    import pytest
    from itertools import cycle

    all_fact_subsets = {'a': cycle([partial(DummyFactCollector, 'a_1'), partial(DummyFactCollector, 'a_2')]),
                        'b': cycle([partial(DummyFactCollector, 'b_1'), partial(DummyFactCollector, 'b_2'),
                                    partial(DummyFactCollector, 'b_3')]),
                        'c': cycle([partial(DummyFactCollector, 'c_1'), partial(DummyFactCollector, 'c_2')])}

    # Test case 1: duplicate names
    names = ['a', 'a', 'b']
    expected = [DummyFactCollector('a_1'), DummyFactCollector('b_1')]


# Generated at 2022-06-22 22:52:09.532994
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.system.bsd as bsd
    import ansible.module_utils.facts.system.linux as linux
    import ansible.module_utils.facts.system.solaris as solaris
    import ansible.module_utils.facts.system.smartos as smartos
    import ansible.module_utils.facts.system.windows as windows
    import ansible.module_utils.facts.system.netbsd as netbsd
    import ansible.module_utils.facts.system.hw_data as hw_data
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.facter as facter
    import ans

# Generated at 2022-06-22 22:52:19.936133
# Unit test for function select_collector_classes
def test_select_collector_classes():
    MockCollector = collections.namedtuple('MockCollector', ['_fact_ids'])
    mock_collectors = [MockCollector(set([f]) for f in ['a', 'b', 'c', 'd'])]
    mock_collector_classes = [MockCollector(set([f]) for f in ['e', 'f', 'g'])]
    subset_map = defaultdict(list)
    subset_map['a'].append(mock_collectors[0])
    subset_map['b'].append(mock_collectors[0])
    subset_map['c'].append(mock_collectors[0])
    subset_map['d'].append(mock_collectors[0])
    subset_map['e'].append(mock_collector_classes[0])


# Generated at 2022-06-22 22:52:23.870938
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    msg = "foo"
    expected_str = 'UnresolvedFactDep %s' % msg
    e = UnresolvedFactDep(msg)
    assert e.args == (msg,)
    assert str(e) == expected_str



# Generated at 2022-06-22 22:52:27.363315
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError
    except CollectorNotFoundError as e:
        assert 'is not a valid fact collector name' in str(e)



# Generated at 2022-06-22 22:52:32.629793
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts import collector
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set(['a'])}
    try:
        collector.tsort(dep_map)
    except CycleFoundInFactDeps:
        return True
    raise Exception('did not error, expected error')


# Generated at 2022-06-22 22:52:43.456958
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test_facter'
        _fact_ids = {
            'test_facter_id_1',
            'test_facter_id_2',
        }

    collector_class = TestCollector
    collectors_for_platform = set([collector_class])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert fact_id_to_collector_map['test_facter'] == [collector_class]
    assert fact_id_to_collector_map['test_facter_id_1'] == [collector_class]

# Generated at 2022-06-22 22:52:48.470210
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact_name = 'some_fact'
    dep_name = 'some_dep'
    e = UnresolvedFactDep(fact_name, dep_name)
    expected_msg = '{} failed to resolve dependency {}'.format(fact_name, dep_name)
    assert e.args[0] == expected_msg



# Generated at 2022-06-22 22:52:57.424447
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)

    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)
    all_fact_subsets['distribution'].append(object)

# Generated at 2022-06-22 22:53:03.474088
# Unit test for function tsort
def test_tsort():
    dep_map = {
        '1': set(['2', '3']),
        '2': set(['4']),
        '3': set(),
    }

    sorted_list = tsort(dep_map)

    assert sorted_list == [
        ('1', set(['2', '3'])),
        ('3', set()),
        ('2', set(['4'])),
    ]


# Generated at 2022-06-22 22:53:14.689323
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    actual = find_unresolved_requires(['a'], {
        'a': [type('collector_a', (), {'required_facts': ['b']})()],
        'b': [type('collector_b', (), {'required_facts': []})()]
    })
    expected = set(['b'])
    assert actual == expected

    actual = find_unresolved_requires(['b'], {
        'a': [type('collector_a', (), {'required_facts': []})()],
        'b': [type('collector_b', (), {'required_facts': ['a']})()]
    })
    expected = set(['a'])
    assert actual == expected


# Generated at 2022-06-22 22:53:16.337108
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    class TestFactCollector(BaseFactCollector):
        name = 'test'
    collector = TestFactCollector()
    assert collector.collect() == {}

