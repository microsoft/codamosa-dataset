

# Generated at 2022-06-22 22:43:20.634452
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-22 22:43:23.664434
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    err = UnresolvedFactDep('bad_fact_name')

    assert err.args == ('bad_fact_name', )
    assert str(err) == 'bad_fact_name'



# Generated at 2022-06-22 22:43:26.890733
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Test UnresolvedFactDep throws ValueError since it derives from ValueError
    try:
        raise UnresolvedFactDep('Test exception message')
    except ValueError:
        assert True
        return
    assert False



# Generated at 2022-06-22 22:43:28.544530
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with timeout(1, CollectorNotFoundError('collector name', ['name1', 'name2'])):
        pass



# Generated at 2022-06-22 22:43:35.719115
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import inspect
    import pytest

    class Things:
        pass

    all_fact_subsets = defaultdict(list)
    collectors = [Thing1, Thing2, Thing3, Thing4, Thing5, Thing6, Thing7]
    for coll in collectors:
        all_fact_subsets[coll.name].append(coll)

    def sort_by_name(coll):
        return coll.name

    all_fact_subsets = defaultdict(list, all_fact_subsets)

    # all collectors, unsorted
    result = select_collector_classes(set([Thing1.name, Thing2.name, Thing3.name, Thing4.name, Thing5.name, Thing6.name, Thing7.name]), all_fact_subsets)

# Generated at 2022-06-22 22:43:37.908296
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    err = UnresolvedFactDep('xxx')
    assert str(err) == "Fact 'xxx' required by another fact is not found"



# Generated at 2022-06-22 22:43:48.914080
# Unit test for function resolve_requires
def test_resolve_requires():
    unresolved_requires = sorted(['one', 'two'])
    # Test: all require facts are there
    all_fact_subsets = {
        'one': [],
        'two': [],
    }
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set(unresolved_requires)

    # Test: some require facts are missing
    all_fact_subsets = {
        'one': [],
    }
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set(['one'])

    # Test: some require facts are missing
    all_fact_subsets = {}
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set()



# Generated at 2022-06-22 22:43:50.998108
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with pytest.raises(CycleFoundInFactDeps):
        raise CycleFoundInFactDeps(['a','b','c'])



# Generated at 2022-06-22 22:43:53.502954
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector()
    assert collector.collectors == []



# Generated at 2022-06-22 22:44:01.299768
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestBaseFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test': 'ok', 'other': 'stuff'}

    class TestNamespace:
        def transform(self, key_name):
            return "{0}_TEST".format(key_name)

    class TestNamespace2:
        def transform(self, key_name):
            return "TEST_{0}".format(key_name)

    # Test with no namespace
    c = TestBaseFactCollector()
    assert c.collect_with_namespace() == {'test': 'ok', 'other': 'stuff'}

    # Test with a namespace
    c = TestBaseFactCollector(namespace=TestNamespace())

# Generated at 2022-06-22 22:44:12.644582
# Unit test for function tsort
def test_tsort():
    good_dep_map = {'a': ['b'], 'b': ['c'], 'c': []}
    bad_dep_map1 = {'a': ['b'], 'b': ['c'], 'c': ['a']}
    bad_dep_map2 = {'a': ['b'], 'b': ['c'], 'c': ['b']}

    try:
        tsort(good_dep_map)
    except CycleFoundInFactDeps:
        assert False, 'Caught CycleFoundInFactDeps for good deps'

    try:
        tsort(bad_dep_map1)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'No CycleFoundInFactDeps for bad deps'


# Generated at 2022-06-22 22:44:21.727419
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    # Expected dep_map
    expected_dep_map = {
        'a': set(),
        'b': set(['a']),
        'c': set(['d']),
        'd': set(['c']),
        'e': set(['a']),
        'f': set(['c']),
        'g': set(['b', 'a']),
        'h': set(['i', 'g']),
        'i': set(['g']),
        'j': set(['g'])
    }
    assert dep_map == expected_dep_map



# Generated at 2022-06-22 22:44:31.317099
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # Test no params
    FC = BaseFactCollector()
    assert FC.collectors == []
    assert FC.namespace is None

    # Test collectors
    FC = BaseFactCollector(collectors=['dummy'])
    assert FC.collectors == ['dummy']
    assert FC.namespace is None

    # Test namespace
    FC = BaseFactCollector(namespace='dummy')
    assert FC.collectors == []
    assert FC.namespace == 'dummy'

    # Test all params
    FC = BaseFactCollector(collectors=['dummy'], namespace='foo')
    assert FC.collectors == ['dummy']
    assert FC.namespace == 'foo'



# Generated at 2022-06-22 22:44:35.876934
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    error_msg = 'This is an error message for an UnresolvedFactDep'
    with timeout.timeout(0.1):
        try:
            raise UnresolvedFactDep(error_msg)
        except UnresolvedFactDep as ex:
            assert ex.args[0] == error_msg



# Generated at 2022-06-22 22:44:47.853068
# Unit test for function resolve_requires
def test_resolve_requires():
    # all_fact_subsets is a map of name -> list of collector classes
    all_fact_subsets = defaultdict(list)

    class FakeCollector(BaseFactCollector):
        name = 'Fake1'
        required_facts = frozenset([])

    # Create 2 collector classes with the same name
    class FakeCollector2(BaseFactCollector):
        name = 'Fake2'
        required_facts = frozenset(['Fake3'])

    class FakeCollector3(BaseFactCollector):
        name = 'Fake3'
        required_facts = frozenset([])

    all_fact_subsets['Fake1'].append(FakeCollector)
    all_fact_subsets['Fake2'].append(FakeCollector2)

# Generated at 2022-06-22 22:44:53.934773
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set, {
        'hardware': ['devices', 'dmi'],
        'system': ['env'],
        'network': ['interfaces'],
    })

    assert get_collector_names(aliases_map=aliases_map,
                               platform_info=None,
                               gather_subset=None) == set(['all'])

    assert get_collector_names(aliases_map=aliases_map,
                               platform_info=None,
                               gather_subset=[]) == set(['all'])

    assert get_collector_names(aliases_map=aliases_map,
                               platform_info=None,
                               gather_subset=['all']) == set(['all'])


# Generated at 2022-06-22 22:45:04.320530
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.collectors
    all_collector_classes = collect_all_collector_classes(ansible.module_utils.facts.collectors)

    # add the tests to this list

# Generated at 2022-06-22 22:45:12.156767
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    valid_subsets = frozenset(['all', 'facts_a', 'facts_b'])
    minimal_gather_subset = frozenset(['facts_a'])
    all_fact_subsets = {'facts_a': [FactsA, FactsB],
                        'facts_b': [FactsB]}

    # no unresolved requires
    collector_names = ['facts_a']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one unresolved require
    collector_names = ['facts_b']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set('facts_a')

    # two unresolved requires
    collector_names = ['facts_c', 'facts_d']
    assert find_unresolved

# Generated at 2022-06-22 22:45:24.446801
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collectors
    class MockCollector(BaseFactCollector):
        name = 'mock_a'
        _fact_ids = {'mock_a'}

    class MockCollector2(BaseFactCollector):
        name = 'mock_a'
        _fact_ids = {'mock_a'}

    class MockCollector3(BaseFactCollector):
        name = 'mock_b'
        _fact_ids = {'mock_b'}

    class MockCollector4(BaseFactCollector):
        name = 'mock_b'
        _fact_ids = {'mock_b'}

    def mock_find_collector_classes(all_collector_classes, compat_platforms):
        return all_collector_classes

    #

# Generated at 2022-06-22 22:45:33.743027
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': ['A'],
        'b': ['B'],
        'c': ['C'],
        'ab': ['A', 'B'],
        'bc': ['B', 'C'],
    }

    assert resolve_requires(['a', 'b'], all_fact_subsets) == set(['a', 'b'])

    # c is not found and thus not resolved
    unresolved = resolve_requires(['a', 'c'], all_fact_subsets)
    assert unresolved == set(['c'])
    # b is not found but it is resolved to 'bc'
    assert resolve_requires(['bc', 'c'], all_fact_subsets) == set(['bc', 'c'])
    # ab is resolved to both 'a' and 'b'

# Generated at 2022-06-22 22:45:41.279713
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    test_name = 'test_name'
    test_msg = 'This is a test'
    exception = UnresolvedFactDep(test_name, test_msg)
    assert exception.name == test_name, "Expected '%s' but got '%s'" % (test_name, exception.name)
    assert exception.msg == test_msg, "Expected '%s' but got '%s'" % (test_msg, exception.msg)


# Generated at 2022-06-22 22:45:51.744889
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # This is a stub of a test that would test the function
    # find_unresolved_requires(). This will test that if we require a
    # collector_names, but we do not have that collector_names, then
    # the function will return that it is still required.
    #
    # The problem is that this function is currently dependent on the
    # variable all_fact_subsets, so FIXME: I will have to add this
    # variable as an argument to get this unit test to work.
    #
    collector_names = ['a', 'b']
    all_fact_subsets = {'a': ['c']}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == ['c']



# Generated at 2022-06-22 22:45:56.830143
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collectors = [BaseFactCollector(), ]
    namespace = None
    print('Testing BaseFactCollector...')
    print()
    TestClass = BaseFactCollector(collectors, namespace)
    assert TestClass.collectors == collectors
    assert TestClass.namespace == namespace

t = test_BaseFactCollector()



# Generated at 2022-06-22 22:46:05.695099
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts.hardware import machinetype, bios, cpu
    from ansible.module_utils.facts.system import distro, os, uptime


# Generated at 2022-06-22 22:46:17.265137
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    actual = collector_classes_from_gather_subset(all_collector_classes=[MockCollector,
                                                                        MockCollector2,
                                                                        MockCollector3,
                                                                        MockCollector4,
                                                                        MockCollector5,
                                                                        ],
                                                  valid_subsets=frozenset(('all', 'min', 'mock', 'mock2', 'mock3', 'mock4')),
                                                  minimal_gather_subset=frozenset(('all', 'min', 'mock')),
                                                  gather_subset=['all'],
                                                  )

    expected = [MockCollector, MockCollector2, MockCollector3, MockCollector4, MockCollector5]
    assert actual == expected



# Generated at 2022-06-22 22:46:26.310765
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollectorA(BaseFactCollector):
        # This class collects network facts
        name = 'network'
        _fact_ids = frozenset(['ipaddress', 'interfaces'])

    class TestCollectorB(BaseFactCollector):
        # This class collects hardware facts
        name = 'hardware'
        _fact_ids = frozenset(['devices', 'dmi'])

    class TestCollectorC(BaseFactCollector):
        # This class collects DMI facts
        name = 'dmi'
        _fact_ids = frozenset(['system_vendor', 'bios_version'])

    all_collector_classes = (TestCollectorA, TestCollectorB, TestCollectorC)
    platform_info = {'system': 'Linux'}
    collectors_for_platform = find_collect

# Generated at 2022-06-22 22:46:35.483567
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    ''' Unit test for function find_unresolved_requires '''
    # Mock empty all_fact_subsets
    all_fact_subsets = {}

    # Assert empty collector_names resolve to empty
    assert not find_unresolved_requires([], all_fact_subsets)

    # Mock all_fact_subsets with two collectors: A and B
    all_fact_subsets = {
        'A': [FakeCollectorClass('A'), FakeCollectorClass('A')],
        'B': [FakeCollectorClass('B')]
    }

    # Assert collector A resolves to empty
    assert not find_unresolved_requires(['A'], all_fact_subsets)

    # Assert collector B resolves to empty

# Generated at 2022-06-22 22:46:40.535064
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    fake_collector_classes = [
        FakeCollector('all'),
        FakeCollector('min'),
        FakeCollector('hardware', requires_facts=('devices',)),
        FakeCollector('devices'),
        FakeCollector('dmi'),
        FakeCollector('network', requires_facts=('ipv4', 'ipv6', 'default_ipv4')),
        FakeCollector('ipv4', requires_facts=('default_ipv4',)),
        FakeCollector('ipv6'),
        FakeCollector('default_ipv4'),
        FakeCollector('facter'),
        FakeCollector('ohai'),
        FakeCollector('virtual', requires_facts=('facter',)),
        FakeCollector('env'),
    ]


# Generated at 2022-06-22 22:46:43.088996
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector().collect() == {}
    assert BaseFactCollector(collectors=[]).collect() == {}
    assert BaseFactCollector(collectors=[BaseFactCollector()]).collect() == {}



# Generated at 2022-06-22 22:46:47.879817
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = (TestCollector1, TestCollector2,
                             TestCollector3, TestCollector4)

    platform_compat_map = [{'system': 'Linux'},
                           {'system':'FreeBSD'}]

    assert find_collectors_for_platform(all_collector_classes,
                                        platform_compat_map) == set([TestCollector2])



# Generated at 2022-06-22 22:46:59.343268
# Unit test for function get_collector_names
def test_get_collector_names():
    # 1. minimal_gather_subset is always added
    assert 'min' in get_collector_names(gather_subset=['!'])
    assert 'min' in get_collector_names(gather_subset=['!', 'network'])
    assert 'min' in get_collector_names(gather_subset=['all'], minimal_gather_subset=['min'])
    assert 'min' not in get_collector_names(gather_subset=['!'], minimal_gather_subset=['min'])
    assert 'min' not in get_collector_names(gather_subset=['!'], minimal_gather_subset=['min'])

# Generated at 2022-06-22 22:47:07.462652
# Unit test for function get_collector_names
def test_get_collector_names():
    '''
    Test that get_collector_names returns expected results
    '''
    # gather_subset and valid_subsets should be in alphabetical order.
    # this helps with test coverage to ensure all code paths are tested
    # and to make it easier to write the tests.
    valid_subsets = frozenset(('all', 'a', 'b', 'c', 'd', 'e'))

    aliases_map = {
        'a': set(('aa', 'ab')),
        'b': set(('ba', 'bb')),
    }

    # gather_subset not in valid_subsets

# Generated at 2022-06-22 22:47:16.321209
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    from textwrap import dedent


# Generated at 2022-06-22 22:47:20.326702
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestCollector(BaseFactCollector):
        name = 'test'
        pass

    c = TestCollector()
    assert set(c.fact_ids) == set(['test']), 'Expected 1 fact id, got %s' % c.fact_ids



# Generated at 2022-06-22 22:47:21.867332
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    assert BaseFactCollector.collect_with_namespace() == {}


# Generated at 2022-06-22 22:47:27.083142
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    class DummyCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'key1': 'value1'}


    dc = DummyCollector()
    assert dc.collect_with_namespace() == {'key1': 'value1'}



# Generated at 2022-06-22 22:47:29.708810
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    resolver = 'resolver'
    dependency = 'dependency'
    exception = UnresolvedFactDep(resolver, dependency)
    assert str(exception) == 'resolver is unresolved fact dependency of dependency'



# Generated at 2022-06-22 22:47:34.864801
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [_collector_class_with_requires(('b', 'c'))],
                        'b': [_collector_class_with_requires(('c',))],
                        'c': [_collector_class_with_requires(())],
                        }
    assert build_dep_data(collector_names, all_fact_subsets) == {'a': {'b', 'c'},
                                                                'b': {'c'},
                                                                'c': set()
                                                                }



# Generated at 2022-06-22 22:47:44.021679
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    """Function "build_fact_id_to_collector_map"

     Unit test for function build_fact_id_to_collector_map
    """
    from ansible.module_utils.facts.collectors import find_collectors_for_platform
    from ansible.module_utils.facts import get_collector_class_for_platform
    from ansible.module_utils.facts.collectors import BaseFactCollector
    from parameterized import parameterized

    class TestClass(BaseFactCollector):
        name = 'test_name'
        _fact_ids = {'test_fact_id_1', 'test_fact_id_2'}

    class TestClass2(BaseFactCollector):
        name = 'test_name2'

# Generated at 2022-06-22 22:47:51.904493
# Unit test for function build_dep_data
def test_build_dep_data():
    # build dummy data
    collectors_for_platform = [FactCOLLECTORA(), FactCOLLECTORB()]
    collector_names = ['COLLECTORA', 'COLLECTORB']
    all_fact_subsets = build_fact_id_to_collector_map(collectors_for_platform)
    # run function
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    # test
    assert dep_map == {'COLLECTORA': {'COLLECTORB'}, 'COLLECTORB': set()}


# Generated at 2022-06-22 22:48:00.027413
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class BaseFactCollector(object):
        def __init__(self):
            self.namespace = Namespace()
            self._transform_name = self.namespace.transform

        def _transform_dict_keys(self, fact_dict):
            for old_key in list(fact_dict.keys()):
                new_key = self._transform_name(old_key)
                fact_dict[new_key] = fact_dict.pop(old_key)
            return fact_dict

        def collect_with_namespace(self, module=None, collected_facts=None):
            facts_dict = {'arch': 'x86_64'}
            if self.namespace:
                facts_dict = self._transform_dict_keys(facts_dict)
            return facts_dict


# Generated at 2022-06-22 22:48:06.280719
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test the function given an empty list of gathering terms
    assert collector_classes_from_gather_subset(gather_subset=None) == []

    # Test the function given a non-empty list of gathering terms
    assert collector_classes_from_gather_subset(gather_subset=['all']) != []

    # Test the function given an empty list of minimal gathering terms
    assert collector_classes_from_gather_subset(gather_subset=None, minimal_gather_subset=None) == []

    # Test the function given a non-empty list of minimal gathering terms
    assert collector_classes_from_gather_subset(gather_subset=None, minimal_gather_subset=frozenset()) != []

    # Test the function given an empty list of valid gathering subsets
   

# Generated at 2022-06-22 22:48:08.369456
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():

    # When
    raisedError = CollectorNotFoundError("test")

    # Then
    assert str(raisedError) == "test"



# Generated at 2022-06-22 22:48:10.121980
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact = UnresolvedFactDep('fact')
    assert str(fact) == "Unresolved dependency for fact 'fact'"



# Generated at 2022-06-22 22:48:16.682005
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import MIPS
    from ansible.module_utils.facts.hardware import MIPSCollector
    from ansible.module_utils.facts.linux import DMIInfo
    from ansible.module_utils.facts.composers import NamespaceFactComposer
    from ansible.module_utils.facts.composers.subset import SubsetFactComposer
    namespace = NamespaceFactComposer('namespace.')
    subset = SubsetFactComposer(['mips'])
    subset = SubsetFactComposer(['mips'])
    subset.add_composer(MIPSCollector)
    subset.add_composer(DMIInfo)

    subset = SubsetFactComposer(['mips'])

# Generated at 2022-06-22 22:48:27.794210
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.collector.fallback import FallbackCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector

    fact_ids = {
        'network': ('network',),
        'hardware': ('hardware', 'dmi', 'devices', 'system')
    }

    class FakeCollector1(FallbackCollector, NetworkCollector):
        _fact_ids = fact_ids['network']
        name = 'network'

    class FakeCollector2(FallbackCollector, HardwareCollector):
        _fact_ids = fact_ids['hardware']
        name = 'hardware'


# Generated at 2022-06-22 22:48:30.141608
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = "There is a cycle in the dependencies"
    err = CycleFoundInFactDeps(msg)
    assert msg in str(err)



# Generated at 2022-06-22 22:48:42.518902
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = {'A'}

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = {'B'}

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = {'E'}

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = {'B'}

   

# Generated at 2022-06-22 22:48:54.460706
# Unit test for function build_dep_data
def test_build_dep_data():

    class DummyCollector(BaseFactCollector):
        name = 'dummy'
        required_facts = frozenset(['required_fact'])

    class DummyCollector2(BaseFactCollector):
        name = 'dummy2'
        required_facts = frozenset(['dummy', 'required_fact'])

    class DummyWinCollector(BaseFactCollector):
        name = 'dummy_win'
        required_facts = frozenset(['required_fact'])
        _platform = 'Windows'

    class DummyWinCollector2(BaseFactCollector):
        name = 'dummy2_win'
        required_facts = frozenset(['dummy_win', 'required_fact'])
        _platform = 'Windows'


# Generated at 2022-06-22 22:49:03.100523
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import os
    import sys
    import time
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector, collector_classes_from_gather_subset
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.generic import GenericCollector
    from ansible.module_utils.facts.collector.legacy import LegacyCollector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.systemv

    # renable stdout and stderr
    import sys
   

# Generated at 2022-06-22 22:49:09.507261
# Unit test for function tsort
def test_tsort():
    tsort_input = {
        'foo': set(['bar']),
        'bar': set(['baz']),
        'baz': set(['zoo']),
        'zoo': set(['foo']),
    }
    try:
        tsort(tsort_input)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'cycle in fact deps not detected'



# Generated at 2022-06-22 22:49:19.343615
# Unit test for function resolve_requires
def test_resolve_requires():

    def build_map(names):
        all_fact_subsets = defaultdict(list)
        for name in names:
            collector_class = MockCollectorClass(name)
            all_fact_subsets[name].append(collector_class)
        return all_fact_subsets

    all_fact_subsets = build_map(['_platform_', '_python_', '_selinux_'])
    unresolved_requires = {'_selinux_'}
    resolved_requires = resolve_requires(unresolved_requires, all_fact_subsets)
    assert resolved_requires == set()

    all_fact_subsets = build_map(['_platform_', '_python_', '_selinux_'])
    unresolved_requires = {'_python_', '_platform_'}
    resolved

# Generated at 2022-06-22 22:49:32.108926
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=['network', 'minimal', 'aliased'],
        minimal_gather_subset=['minimal'],
        aliases_map=dict(base=['minimal']),
        gather_subset=[]) == frozenset(['network', 'minimal'])
    assert get_collector_names(
        valid_subsets=['network', 'minimal', 'aliased'],
        minimal_gather_subset=['minimal'],
        aliases_map=dict(base=['minimal']),
        gather_subset=['network']) == frozenset(['network'])

# Generated at 2022-06-22 22:49:36.581435
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class NewFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'new_fact': 'value'}
    collector = NewFactCollector()
    assert 'new_fact' in collector.collect()
    return


# Generated at 2022-06-22 22:49:46.818152
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.community.general.plugins.module_utils.facts import collector

    collectors = [CollectorFoo, CollectorBar]
    all_fact_subsets = {
        'foo': [CollectorFoo],
        'bar': [CollectorBar],
        'baz': [CollectorBaz],
    }
    unresolved = collector.find_unresolved_requires(['foo', 'bar', 'baz'], all_fact_subsets)
    assert sorted(unresolved) == ['baz']

    all_fact_subsets = {
        'bar': [CollectorBar],
        'baz': [CollectorBaz],
    }
    unresolved = collector.find_unresolved_requires(['bar', 'baz'], all_fact_subsets)
    assert sorted(unresolved)

# Generated at 2022-06-22 22:49:56.866906
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector

    test_class_map = {'collector1': [collector.Test1Collector, collector.Test2Collector],
                      'collector2': [collector.Test2Collector, collector.Test3Collector],
                      'collector3': [collector.Test3Collector, collector.Test1Collector],
                      'collector4': [collector.Test4Collector],
                      'collector5': [collector.Test5Collector],
                      'collector6': [collector.Test6Collector],
                      'collector7': [collector.Test7Collector]}

    # Results should only be collector1 and collector2 since it is the
    # only ones that will work with the namespace transformation

# Generated at 2022-06-22 22:50:01.585537
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = ('A', 'a')
        required_facts = ('B',)

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = ('B',)
        required_facts = ('C',)

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = ('C',)

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = ('D',)
        required_facts = ('C',)

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = ('E',)
        required_facts = ('F',)


# Generated at 2022-06-22 22:50:04.164625
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('test message')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'test message'


# Generated at 2022-06-22 22:50:06.685705
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('some message')

    assert type(e.args) == tuple
    assert len(e.args) == 1
    assert e.args[0] == 'some message'



# Generated at 2022-06-22 22:50:19.632764
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.collectors.linux


# Generated at 2022-06-22 22:50:25.988672
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = frozenset(['test1', 'test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = frozenset(['test1'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = frozenset(['test4'])


# Generated at 2022-06-22 22:50:34.409896
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'A'

    class CollectorB(BaseFactCollector):
        name = 'B'

    class CollectorC(BaseFactCollector):
        name = 'C'

    class CollectorD(BaseFactCollector):
        name = 'D'

    class CollectorB2(BaseFactCollector):
        name = 'B'

    class CollectorC2(BaseFactCollector):
        name = 'C'

    class CollectorD2(BaseFactCollector):
        name = 'D'


# Generated at 2022-06-22 22:50:40.723413
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    collector_classes = collector_classes_from_gather_subset(gather_subset=['!hardware'],
                                                             platform_info={'system': 'Linux'})

    expected = {'system', 'facter', 'network', 'env'}
    actual = [c.name for c in collector_classes]

    assert expected == set(actual)



# Generated at 2022-06-22 22:50:44.182180
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    b_fact_collector = BaseFactCollector()
    assert b_fact_collector.collectors == []
    assert b_fact_collector.namespace is None
    assert b_fact_collector.fact_ids == set([None])


# Generated at 2022-06-22 22:50:57.007069
# Unit test for function resolve_requires
def test_resolve_requires():

    # we have to have a map of class to collector name, otherwise we can't
    # instantiate the class. We'd have to look at the 'name' class attribute
    # on the class, or the Meta class.
    fact_id_to_collector_map = {
        'A': [],
        'B': [],
        'C': [],
        'D': [],
    }

    def _get_requires_by_collector_name(collector_name):
        if collector_name == 'A':
            return ['B', 'C']
        if collector_name == 'B':
            return ['D']
        if collector_name == 'C':
            return ['A']
        if collector_name == 'D':
            return ['A']
        return []

    # we have to have a map of class to collector

# Generated at 2022-06-22 22:51:08.762994
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import sys
    import json
    import importlib
    import datetime
    import unittest

    # See if we are being executed as a testcase.  If not, then execute it as a testcase
    if __name__ != '__main__':
        sys.exit(0)

    from ansible.module_utils.facts.collector import (BaseFactCollector,
                                                      find_collectors_for_platform)

    class TestFactCollector1(BaseFactCollector):
        _fact_ids = frozenset(['fact1a', 'fact1b'])

        name = 'test1'

        _platform = 'RedHat'

        def collect(self, module=None, collected_facts=None):
            return {'fact1a': 'foo',
                    'fact1b': 'bar'}


# Generated at 2022-06-22 22:51:17.182114
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    base = BaseFactCollector()
    assert base.collectors == []
    assert base.namespace is None
    assert base.fact_ids == set(['Generic'])

    base = BaseFactCollector()
    base.collectors = [1, 2, 3]
    base.namespace = 'foo'
    base.fact_ids = [1, 2, 3]

    assert base.collectors == [1, 2, 3]
    assert base.namespace == 'foo'
    assert base.fact_ids == [1, 2, 3]



# Generated at 2022-06-22 22:51:20.184538
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exception = CycleFoundInFactDeps()
    assert repr(exception) == 'CycleFoundInFactDeps()'
    assert str(exception) == 'CycleFoundInFactDeps'



# Generated at 2022-06-22 22:51:30.048364
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty subset
    assert get_collector_names() == set(['all'])

    # Test subset with no negative subset
    assert get_collector_names(gather_subset=['network']) == set(['network'])

    # Test subset with invalid subset
    try:
        get_collector_names(gather_subset=['invalid'])
    except TypeError:
        pass
    else:
        raise Exception("Invalid subset didn't raise error.")

    # Test subset with no negative subset
    assert get_collector_names(gather_subset=['network', '!invalid']) == set(['network'])

    # Test subset with no negative subset

# Generated at 2022-06-22 22:51:42.333319
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system import OpenBSD
    from ansible.module_utils.facts.system import Linux
    from ansible.module_utils.facts.system import Darwin
    from ansible.module_utils.facts.system import *
    from ansible.module_utils.facts.hardware import *

    all_collector_classes = tuple(
        [cls for name, cls in locals().items() if name.endswith('Collector')]
    )

    opbsd_platform_info = {'system': 'OpenBSD'}
    linux_platform_info = {'system': 'Linux'}
    darwin_platform_info = {'system': 'Darwin'}


# Generated at 2022-06-22 22:51:45.858235
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    expected_exception_msg = 'foo'
    error = UnresolvedFactDep(expected_exception_msg)
    actual_exception_msg = str(error)
    assert (expected_exception_msg in actual_exception_msg)



# Generated at 2022-06-22 22:51:55.859416
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class Collector1(BaseFactCollector):
        name = 'Collector1'
    col1 = Collector1()
    assert col1.name == 'Collector1'
    assert col1.fact_ids == set(['Collector1'])
    assert col1.collect() == {}

    class Collector2(BaseFactCollector):
        name = 'Collector2'
        _fact_ids = set(['Collector2-1', 'Collector2-2'])
    col2 = Collector2()
    assert col2.name == 'Collector2'
    assert col2.fact_ids == set(['Collector2', 'Collector2-1', 'Collector2-2'])

    class Collector3(BaseFactCollector):
        name = 'Collector3'
        collectors = [col2]
    col3 = Collector

# Generated at 2022-06-22 22:52:02.832785
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'A': [object()],
        'B': [object()],
        'C': [object()],
    }

    # Test basic cases
    assert len(find_unresolved_requires(['A'], all_fact_subsets)) == 0
    assert len(find_unresolved_requires(['A', 'B'], all_fact_subsets)) == 0

    # Test unresolved
    assert len(find_unresolved_requires(['C'], all_fact_subsets)) == 1



# Generated at 2022-06-22 22:52:06.959872
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('unresolved_fact1', ['foo', 'bar'])
    except UnresolvedFactDep as ex:
        assert str(ex) == 'unresolved_fact1 depends on unresolved facts: foo, bar'



# Generated at 2022-06-22 22:52:18.180610
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_yum import YumFactCollector
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_dnf import DnfFactCollector
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_zypper import ZypperFactCollector

    all_collector_classes = (
        DistributionFactCollector,
        PkgMgrFactCollector,
        YumFactCollector,
        DnfFactCollector,
        ZypperFactCollector,
    )



# Generated at 2022-06-22 22:52:26.864648
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'all': [object]}
    assert resolve_requires(unresolved_requires=set(['all']),
                            all_fact_subsets=all_fact_subsets) == set(['all'])

    assert resolve_requires(unresolved_requires=set(['network']),
                            all_fact_subsets=all_fact_subsets) == set()

    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved_requires=set(['network']),
                         all_fact_subsets=dict())



# Generated at 2022-06-22 22:52:35.914055
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Test the get_collector_names function'''
    valid_subsets = frozenset(['one', 'two', 'three'])
    minimal_gather_subset = frozenset(['one', 'two'])
    gather_subset = frozenset(['three'])
    aliases_map = defaultdict(set, {
        'one': set(['111', '222']),
        'two': set(['333'])
    })

    # test defaults
    assert get_collector_names() == frozenset(['all', 'min'])

    # test with gather_subset that is only valid subset
    assert get_collector_names(valid_subsets=valid_subsets, gather_subset=['three']) == frozenset(['three'])

    # test with gather_subset

# Generated at 2022-06-22 22:52:39.133776
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with pytest.raises(CycleFoundInFactDeps):
        raise CycleFoundInFactDeps()


# Generated at 2022-06-22 22:52:50.583623
# Unit test for function get_collector_names
def test_get_collector_names():
    fact_info = {
        'valid_subsets': frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        'minimal_gather_subset': frozenset(['all', 'network', 'hardware']),
        'aliases_map': defaultdict(set, {
            'hardware': frozenset(['devices', 'dmi'])})
    }
    # test all cases where 'min' is not mentioned, only 'all'
    case_0 = {
        'gather_subset': ['hardware', 'devices']
    }
    case_1 = {
        'gather_subset': ['network']
    }
    case_2 = {
        'gather_subset': ['!network']
    }
    # test where 'min' is mentioned,

# Generated at 2022-06-22 22:52:54.806374
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(UnresolvedFactDep) as ufde:
        raise UnresolvedFactDep('foo')
    assert isinstance(ufde.value, UnresolvedFactDep)
    assert isinstance(ufde.value, ValueError)
    assert str(ufde.value) == 'foo'



# Generated at 2022-06-22 22:53:05.343976
# Unit test for function resolve_requires
def test_resolve_requires():
    # Collect all possible facts and check if 'all' resolves to them
    all_facts = frozenset(['all'])
    assert resolve_requires(all_facts, all_facts) == all_facts

    # Collect all possible facts and check if 'all' doesn't resolves to something else.
    all_facts = frozenset(['a', 'b'])
    assert resolve_requires(all_facts, all_facts) == all_facts

    # Collect all possible facts and check if 'all' doesn't resolves to something else.
    all_facts = frozenset(['a', 'b'])
    failed = frozenset(['c', 'd'])
    assert resolve_requires(all_facts, failed) == all_facts
    assert resolve_requires(all_facts, all_facts) == all_facts

# Generated at 2022-06-22 22:53:09.862913
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'one': [], 'two': [], 'three': []}
    unresolved_requires = {'foo', 'one', 'two'}
    expected = {'one', 'two'}
    assert resolve_requires(unresolved_requires, all_fact_subsets) == expected



# Generated at 2022-06-22 22:53:19.628627
# Unit test for function select_collector_classes
def test_select_collector_classes():
    Fixture = collections.namedtuple('Fixture', 'collector_names, all_fact_subsets, expected_result')
    # Create test data
    fixture_list = list()

    collector_names = ['GenericFactCollector']
    all_fact_subsets = {'GenericFactCollector': [FakeGenericFactCollector1, FakeGenericFactCollector2]}
    expected_result = [FakeGenericFactCollector1, FakeGenericFactCollector2]
    fixture_list.append(Fixture(collector_names, all_fact_subsets, expected_result))

    for fixture in fixture_list:
        # Call the function under test
        result = select_collector_classes(fixture.collector_names, fixture.all_fact_subsets)

        assert len(result) == len(fixture.expected_result)
       