

# Generated at 2022-06-22 22:43:25.193915
# Unit test for function tsort
def test_tsort():
    dep_map = {'one': set(['two']),
               'two': set(['three']),
               'three': set(['four']),
               'four': set(['five']),
               'five': set(['one'])}

    sorted_list = [('five', set(['one'])), ('four', set(['five'])), ('three', set(['four'])), ('two', set(['three'])), ('one', set(['two']))]

    assert tsort(dep_map) == sorted_list



# Generated at 2022-06-22 22:43:30.693860
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # ensure method collect returns a dict
    base_fact_collector = BaseFactCollector()
    # raise ValueError in case module is None
    try:
        base_fact_collector.collect(collected_facts=None)
    except ValueError:
        pass
    else:
        raise ValueError("test_BaseFactCollector_collect: method collect failed to raise ValueError")


# Generated at 2022-06-22 22:43:33.907551
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('test1', 'test2')
    except UnresolvedFactDep as e:
        assert e.args == ('test1', 'test2')



# Generated at 2022-06-22 22:43:43.162141
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert BaseFactCollector.platform_match({'system': 'Linux'}) is None
    assert BaseFactCollector.platform_match({'system': 'Generic'}) is BaseFactCollector

    # BFC, by default, takes a list of other FactCollectors, but it's optional:
    bfc = BaseFactCollector()
    assert bfc.collectors == []

    # this is standard, but doesn't need to be:
    assert bfc.namespace is None

    assert bfc.fact_ids == {'Generic'}
    bfc2 = BaseFactCollector(namespace=lambda x: '_' + x)
    assert bfc2.fact_ids == {'Generic'}
    assert bfc2._transform_name('happy') == '_happy'

# Generated at 2022-06-22 22:43:53.016912
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from test.units.module_utils.facts import make_test_collector

    all_fact_subsets = {
        'a': [make_test_collector(name='a', facts={'a': 2}, requires_facts=set())],
        'b': [make_test_collector(name='b', facts={'b': 2}, requires_facts={'a'})],
        'c': [make_test_collector(name='c', facts={'c': 2}, requires_facts={'b'})],
        'd': [make_test_collector(name='d', facts={'d': 2}, requires_facts=set())],
        'e': [make_test_collector(name='e', facts={'e': 2}, requires_facts={'a', 'd'})],
    }

    # not

# Generated at 2022-06-22 22:44:01.065188
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit tests for function find_unresolved_requires

    These tests should be run with pytest -v, and pytest-xdist
    '''
    import pytest
    # all_fact_subsets = {
    #     'a': [CLASS('a', ['b'])],
    #     'b': [CLASS('b', ['c', 'd'])],
    #     'c': [CLASS('c', ['d'])],
    #     'd': [CLASS('d', [])],
    #     'e': [CLASS('e', ['a'])],
    #     'f': [CLASS('f', ['a'])],
    # }

    class CLASS:
        def __init__(self, name, requires):
            self.name = name
            self.required_facts = requires

    # all_

# Generated at 2022-06-22 22:44:03.186626
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    t = CollectorNotFoundError('test_name')
    assert 'test_name' in str(t)



# Generated at 2022-06-22 22:44:14.352475
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes(['a', 'b', 'c'], {'a': [1, 2], 'b': [3], 'c': [4, 5]}) == [1, 2, 3, 4, 5]
    assert select_collector_classes(['b', 'a', 'c'], {'a': [1, 2], 'b': [3], 'c': [4, 5]}) == [3, 1, 2, 4, 5]

    # Only include 'b' once as it is a duplicate
    assert select_collector_classes(['a', 'b', 'c', 'b'], {'a': [1, 2], 'b': [3], 'c': [4, 5]}) == [1, 2, 3, 4, 5]

    # Missing collectors are ignored
    assert select_collector_

# Generated at 2022-06-22 22:44:23.745421
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    bc = BaseFactCollector()
    bc._transform_name = MagicMock()
    bc.collect = MagicMock(return_value={'a': 1})
    res = bc.collect_with_namespace()
    assert res == {'a': 1}
    assert bc.collect.called
    assert not bc._transform_name.called

    bc._transform_name.reset_mock()
    bc.collect.reset_mock()
    bc.namespace = 'mock_namespace'
    bc.collect_with_namespace()
    assert bc._transform_name.called
    bc._transform_name.reset_mock()
    bc._transform_name.return_value = 'mock_name'
    bc.collect_with_namespace()
    assert bc._transform_name.called
    assert bc._transform

# Generated at 2022-06-22 22:44:34.252865
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class AllCollectorClasses:
        class A:
            name = 'A'
            _platform = 'A'

            @classmethod
            def platform_match(cls, platform_info):
                return 0

        class B:
            name = 'B'
            _platform = 'B'

            @classmethod
            def platform_match(cls, platform_info):
                return 1

        class C:
            name = 'C'
            _platform = 'C'

            @classmethod
            def platform_match(cls, platform_info):
                return 2


# Generated at 2022-06-22 22:44:35.922079
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact = UnresolvedFactDep('test')
    assert fact.args == ('test',)



# Generated at 2022-06-22 22:44:41.383336
# Unit test for function build_dep_data
def test_build_dep_data():
    fact_collectors = {'collector1': [BaseFactCollector(required_facts=['fact1'])]}
    deps = build_dep_data(['collector1'], fact_collectors)
    assert deps['collector1'] == {'fact1'}



# Generated at 2022-06-22 22:44:43.625598
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fact_collector1=BaseFactCollector()
    assert fact_collector1.collect() == {}


# Generated at 2022-06-22 22:44:46.961116
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    ''' CycleFoundInFactDeps constructor unit test

    unit test for constructor of class CycleFoundInFactDeps.
    '''
    exception = CycleFoundInFactDeps('foo')
    assert exception.args == ('foo',)



# Generated at 2022-06-22 22:44:59.586414
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''Unit test for function collector_classes_from_gather_subset'''


    class Collector1(BaseFactCollector):
        _fact_ids = ['c1', 'c2']
        name = 'collector1'
        required_facts = set(['c1', 'c2'])

    class Collector2(BaseFactCollector):
        _fact_ids = ['c1', 'c3']
        name = 'collector2'
        required_facts = set(['c1', 'c3'])

    class Collector3(BaseFactCollector):
        _fact_ids = ['c1', 'c2']
        name = 'collector3'
        required_facts = set(['c1', 'c2'])


# Generated at 2022-06-22 22:45:09.899604
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import default_collectors
    all_fact_subsets = default_collector_classes()

    import ansible.module_utils.facts.network.nios
    all_fact_subsets['infoblox'] = [ansible.module_utils.facts.network.nios.NiosFactCollector]

    unresolved = find_unresolved_requires(['infoblox'], all_fact_subsets)
    assert unresolved == set(['facter'])

    unresolved = find_unresolved_requires(['infoblox', 'facter'], all_fact_subsets)
    assert unresolved == set()

    unresolved = find_unresolved_requires(['facter'], all_fact_subsets)
    assert unresolved == set()


# Generated at 2022-06-22 22:45:12.746890
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    Cyc = CycleFoundInFactDeps('some message')
    assert Cyc.args == ('some message',)
    assert Cyc.message == 'some message'



# Generated at 2022-06-22 22:45:24.736557
# Unit test for function build_dep_data
def test_build_dep_data():
    class testCollector(BaseFactCollector):
        _fact_ids = frozenset(['bar'])
        _platform = 'test'
        name = 'test'

        required_facts = frozenset(['foo'])

    class fakeNamespace:
        '''Fake namespace class'''
        def transform(self, key):
            return 'fake_%s' % key
    collected_facts = {}
    collected_facts['answer'] = 42
    all_collectors = [testCollector(namespace=fakeNamespace())]
    all_fact_subsets = {}
    for collector in all_collectors:
        for fact_id in collector._fact_ids:
            all_fact_subsets[fact_id].append(collector)

# Generated at 2022-06-22 22:45:26.328497
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    assert obj.collect() == {}



# Generated at 2022-06-22 22:45:28.704321
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    instance = BaseFactCollector()
    assert isinstance(instance.collect(), dict)
# End of unit test



# Generated at 2022-06-22 22:45:29.872644
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from collections import OrderedDict
    from ansible.module_utils.basic import Ansi

# Generated at 2022-06-22 22:45:36.787942
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class FakeCollector(object):
        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    class FedoraCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'fedora'

    class SuseCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'suse'

    class RedHatCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'redhat'

    class LinuxCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux'

    all_collector_classes = [FedoraCollector, SuseCollector, RedHatCollector, LinuxCollector]

   

# Generated at 2022-06-22 22:45:46.441974
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    msg = 'foo'
    try:
        raise CollectorNotFoundError(msg)
    except CollectorNotFoundError as exc:
        assert exc.args[0] == msg


# Generated at 2022-06-22 22:45:57.917643
# Unit test for function get_collector_names
def test_get_collector_names():

    minimal_gather_subsets = frozenset(['!all', '!min'])
    valid_subsets = frozenset(['all', 'network', 'dmi', 'hardware', 'virtual'])
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(['dmi', 'virtual'])
    aliases_map['devices'] = frozenset(['dmi'])

    #
    # 'all' is only included for --gather-all-subsets=all, or
    # minimal_gather_subset includes 'all'
    #

# Generated at 2022-06-22 22:45:59.998371
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    base = BaseFactCollector()
    result = base.collect_with_namespace()
    assert result == {}

    result = base.collect_with_namespace(module=None, collected_facts=None)
    assert result == {}



# Generated at 2022-06-22 22:46:11.798536
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.collectors

    def _test_collector_classes_from_gather_subset(gather_subset=None, platform_info=None, valid_subsets=None):
        ansible.module_utils.facts.collectors.collectors = []
        collectors = ansible.module_utils.facts.collectors.collector_classes_from_gather_subset(
            all_collector_classes=ansible.module_utils.facts.collectors.collectors,
            valid_subsets=valid_subsets,
            gather_subset=gather_subset,
            platform_info=platform_info)
        return sorted([cls.name for cls in collectors])

    assert _test_collector_classes_from_gather_subset() == ['all']

   

# Generated at 2022-06-22 22:46:14.948204
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    test_collector = BaseFactCollector(namespace='Test')
    assert test_collector.namespace.transform('key') == 'Test_key'



# Generated at 2022-06-22 22:46:24.661524
# Unit test for function select_collector_classes
def test_select_collector_classes():
    CollectorA = type('CollectorA', (object,), dict(name='collector_a'))
    CollectorB = type('CollectorB', (object,), dict(name='collector_b'))
    CollectorC = type('CollectorC', (object,), dict(name='collector_c'))
    CollectorD = type('CollectorD', (object,), dict(name='collector_d'))

    all_fact_subsets = {
        'a': [CollectorA, CollectorB],
        'b': [CollectorB],
        'c': [CollectorC, CollectorD]
    }

    # test empty collector names - should return an empty list
    assert [] == select_collector_classes([], all_fact_subsets)

    # test returns all classes for each collector name, but only once

# Generated at 2022-06-22 22:46:27.280511
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    found_collectors = find_collectors_for_platform(None, [])
    assert found_collectors == set()



# Generated at 2022-06-22 22:46:29.995781
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    name = 'TheCollectorNotFoundError'
    cnf = CollectorNotFoundError(name)
    assert cnf.args == (name,)



# Generated at 2022-06-22 22:46:32.676851
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors is not None
    assert fc.collectors == list()
    assert sorted(fc.fact_ids) == list(['Generic'])


# Generated at 2022-06-22 22:46:38.996069
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Verify find_unresolved_requires returns the correct set of unresolved requires'''
    from ansible.module_utils.facts.platform.posix import collectors

    collector_names = {'dmi'}

    # Expected to return dmi as unresolved since it is not in collector_names
    expected = {'dmi'}
    result = find_unresolved_requires(collector_names, collectors.subsets)
    assert result == expected

    # Expected to return empty set since all items are in collector_names
    expected = set()
    result = find_unresolved_requires(_get_requires_by_collector_name('dmi', collectors.subsets), collectors.subsets)
    assert result == expected


# Generated at 2022-06-22 22:46:49.259737
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorX(BaseFactCollector):
        name = 'x'
    class CollectorY(BaseFactCollector):
        name = 'y'
    class CollectorZ(BaseFactCollector):
        name = 'z'
        required_facts = set(['x'])
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['y'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['x', 'y', 'z'])

    all_fact_subsets = {
        'x': [CollectorX, CollectorZ, CollectorB],
        'y': [CollectorY, CollectorA, CollectorB],
        'z': [CollectorZ, CollectorB],
    }

    result = select_collector_classes

# Generated at 2022-06-22 22:47:01.032324
# Unit test for function resolve_requires
def test_resolve_requires():

    all_fact_subsets = {
        'one': ['un', 'ein'],
        'two': ['zwei', 'deux'],
        'four': ['quatre', 'quatro', 'cuatro'],
        'null': ['nul', 'naught', 'nought'],
        'test': ['test'],
    }

    def _resolve(unresolved_requires, expected_result=None):
        resolved = resolve_requires(unresolved_requires, all_fact_subsets)
        assert (-expected_result == -resolved) or (expected_result == resolved)

    _resolve(set(['one']), {'one'})
    _resolve(set(['one', 'two']), {'one', 'two'})

# Generated at 2022-06-22 22:47:11.896627
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'Collector1'
        _fact_ids = set(['Collector1'])

    class Collector1b(BaseFactCollector):
        name = 'Collector1'
        _fact_ids = set(['Collector1b'])

    class Collector2(BaseFactCollector):
        name = 'Collector2'
        _fact_ids = set(['Collector2'])

    fact_id_to_collector_map = {}
    fact_id_to_collector_map['Collector1'] = [Collector1, Collector1b]
    fact_id_to_collector_map['Collector2'] = [Collector2]
    all_fact_subsets = defaultdict(list, fact_id_to_collector_map)

    actual_

# Generated at 2022-06-22 22:47:17.408825
# Unit test for function tsort
def test_tsort():
    assert_sorted_list = [(1, set([2, 3])), (2, set([4])), (4, set([])), (3, set([]))]
    assert tsort({1: set([2, 3]), 2: set([4]), 4: set([]), 3: set([])}) == assert_sorted_list



# Generated at 2022-06-22 22:47:26.079688
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collectors
    example_collectors = [collectors.LinuxSysctl, collectors.LinuxSelinux, collectors.LinuxDNF]
    collector_map, alias_map = build_fact_id_to_collector_map(example_collectors)
    assert 'selinux' in collector_map
    assert 'selinux' in alias_map['LinuxSelinux']
    assert 'linux_sysctl' in alias_map['LinuxSysctl']
    assert 'selinux' in alias_map['LinuxSelinux']



# Generated at 2022-06-22 22:47:33.860247
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class FakeCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar', 'a': 'b'}

    # no namespace, so should be the same
    trial_collector = FakeCollector()
    result = trial_collector.collect_with_namespace()
    assert result == {'foo': 'bar', 'a': 'b'}

    # namespace should transform the key names
    from ansible.module_utils.facts import namespace
    ns = namespace.Namespace('baz')
    trial_collector = FakeCollector(namespace=ns)
    result = trial_collector.collect_with_namespace()
    assert result == {'baz_foo': 'bar', 'baz_a': 'b'}
# done testing method collect

# Generated at 2022-06-22 22:47:36.295339
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    test = CycleFoundInFactDeps()
    assert test



# Generated at 2022-06-22 22:47:44.271446
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert len(dep_map['all']) == 0

    collector_names = ['!all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert len(dep_map['!all']) == 0

    collector_names = ['all', '!all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert len(dep_map['all']) == 0
    assert len(dep_map['!all']) == 0

    collector_names = ['network']
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-22 22:47:52.532672
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    test_collector_class = type('TestCollector', (BaseFactCollector,),
                                {
                                    '_platform': 'test_platform',
                                    'name': 'test_collector',
                                    'required_facts': {},
                                })
    all_collector_classes = set([test_collector_class])
    compat_platforms = [{'system': 'test_platform'}]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert test_collector_class in found_collectors



# Generated at 2022-06-22 22:48:00.417407
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import pytest
    from ansible.module_utils.facts import collector
    class CollectorA(collector.BaseFactCollector):
        name = 'a'
    class CollectorB(collector.BaseFactCollector):
        name = 'b'
        _fact_ids = ['b_alias']
    class CollectorB2(collector.BaseFactCollector):
        name = 'b'
        _fact_ids = ['b_different']
    class CollectorC(collector.BaseFactCollector):
        name = 'c'

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'] = [CollectorA]
    all_fact_subsets['b'] = [CollectorB, CollectorB2]
    all_fact_subsets['c'] = [CollectorC]
    all_

# Generated at 2022-06-22 22:48:12.144448
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    all_collector_classes = [DistributionFactCollector, PkgMgrFactCollector, HardwareCollector, NetworkCollector]

    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    # test basic case
    collector_names = ['network', 'distribution']

# Generated at 2022-06-22 22:48:24.988888
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.all import AllCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector

    class LocalBaseFactCollector(BaseFactCollector):
        name = None
        _platform = 'Generic'

    class TestAllCollector(LocalBaseFactCollector):
        name = 'all'

    class TestNetworkCollector(LocalBaseFactCollector):
        name = 'network'

    class TestPlatformCollector(LocalBaseFactCollector):
        name = 'platform'

    class TestEnvCollector(LocalBaseFactCollector):
        name

# Generated at 2022-06-22 22:48:37.819228
# Unit test for function build_dep_data
def test_build_dep_data():
    import sys

    class FakeCollector1(BaseFactCollector):
        name = 'fake_collector_1'
        required_facts = ['os']

    class FakeCollector2(BaseFactCollector):
        name = 'fake_collector_2'
        required_facts = ['os', 'fake_collector_1']

    collectors_for_platform, aliases_map = build_fact_id_to_collector_map(
        {FakeCollector1, FakeCollector2})

    dep_map = build_dep_data(['fake_collector_1', 'fake_collector_2'], collectors_for_platform)

    assert dep_map['fake_collector_1'] == set()
    assert dep_map['fake_collector_2'] == {'fake_collector_1', 'os'}




# Generated at 2022-06-22 22:48:47.849409
# Unit test for function select_collector_classes
def test_select_collector_classes():
    """
    Unit test for select_collector_classes
    """
    all_fact_subsets = {
        'a': [BaseFactCollector()],
        'b': [BaseFactCollector()],
        'c': [BaseFactCollector()]
    }

    assert select_collector_classes(['a'], all_fact_subsets) == [BaseFactCollector()]
    assert select_collector_classes(['a', 'b'], all_fact_subsets) == [BaseFactCollector(), BaseFactCollector()]
    assert select_collector_classes(['b', 'a'], all_fact_subsets) == [BaseFactCollector(), BaseFactCollector()]

# Generated at 2022-06-22 22:48:52.357755
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    foo_collector = BaseFactCollector()

    assert(foo_collector)
    assert(foo_collector.name is None)
    assert(foo_collector.collectors == [])
    assert(foo_collector.namespace is None)


# Generated at 2022-06-22 22:48:59.954360
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''test collector_classes_from_gather_subset'''
    args = {'all_collector_classes': None, 'valid_subsets': None,
            'minimal_gather_subset': None,
            'gather_subset': None, 'gather_timeout': None,
            'platform_info': None}

    try:
        result = collector_classes_from_gather_subset(**args)
    except Exception as err:
        pytest.fail('Error: {0}. Module function returned: {1!r}'.format(err, result))

    assert result is not None



# Generated at 2022-06-22 22:49:04.720899
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with timeout(0.1) as t:
        try:
            raise UnresolvedFactDep('blah')
        except UnresolvedFactDep as e:
            assert str(e) == 'blah'
    assert t.expired



# Generated at 2022-06-22 22:49:07.013703
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError(5)
    assert e.args == (5, )



# Generated at 2022-06-22 22:49:10.910114
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Unit test for constructor of class CycleFoundInFactDeps'''
    # pylint: disable=invalid-name
    e = CycleFoundInFactDeps()
    assert e.args == ('Tried to access facts before they were available by the fact cache.',)


# Generated at 2022-06-22 22:49:21.369214
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Ones(object):
        name = 'ones'
        _fact_ids = set(('ones', ))
    class OnesTwos(object):
        name = 'ones_twos'
        _fact_ids = set(('ones', 'twos'))
    class Twos(object):
        name = 'twos'
        _fact_ids = set(('twos', ))

    all_fact_subsets = {
        'ones': (Ones, OnesTwos),
        'ones_twos': (OnesTwos, ),
        'twos': (Twos, OnesTwos),
    }

    assert select_collector_classes(['ones'], all_fact_subsets) == [Ones, OnesTwos]
    assert select_collector_classes(['twos'], all_fact_subsets)

# Generated at 2022-06-22 22:49:33.733089
# Unit test for function select_collector_classes
def test_select_collector_classes():

    class CollectorA(BaseFactCollector):
        name = 'collector_a'
        _fact_ids = {'a1', 'a2'}

    class CollectorB(BaseFactCollector):
        name = 'collector_b'
        _fact_ids = {'b1', 'b2'}

    class CollectorC(BaseFactCollector):
        name = 'collector_c'
        _fact_ids = {'c1', 'c2'}

    class CollectorD(BaseFactCollector):
        name = 'collector_d'
        _fact_ids = {'d1', 'd2'}

    class CollectorE(BaseFactCollector):
        name = 'collector_e'
        _fact_ids = {'e1', 'e2'}


# Generated at 2022-06-22 22:49:34.689576
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('NotFound')



# Generated at 2022-06-22 22:49:45.609757
# Unit test for function build_dep_data
def test_build_dep_data():
    fact_id_to_collector_class_map = {
        'file': [BaseFactCollector],
        'dir': [BaseFactCollector],
        'platform': [BaseFactCollector],
        'system': [BaseFactCollector],
        'all': [BaseFactCollector],
        'min': [BaseFactCollector],
        'hardware': [BaseFactCollector]
    }
    dep_map = build_dep_data(fact_id_to_collector_class_map, fact_id_to_collector_class_map)
    assert dep_map == {
        'system': set(),
        'file': set(),
        'hardware': set(),
        'platform': set(),
        'min': set(),
        'all': set(),
        'dir': set()
    }
test_build

# Generated at 2022-06-22 22:49:55.721186
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector

    with CollectorNotFoundError(msg='No collector found for platform %s' % platform.system()):
        # Check for exception if no collector found for current platform
        # CollectorNotFoundError is raised if no collector found
        # for current platform
        collector.get_collector(namespace=None)

    with CollectorNotFoundError(msg='No collector found for platform %s' % platform.system()):
        # Check for exception if no collector found for 'Generic' platform
        # CollectorNotFoundError is raised if no collector found
        # for 'Generic' platform
        collector.get_collector(namespace=None, platform='Generic')

    # Instantiate BaseFactCollector
    assert BaseFactCollector()
    # Instantiate BaseFactCollector with collectors and namespace

# Generated at 2022-06-22 22:50:07.099526
# Unit test for function build_dep_data
def test_build_dep_data():
    from . import linux
    from . import network
    class FakeCollector(BaseFactCollector):
        name = 'fake'
        required_facts = set(['other'])
    fake_collector = FakeCollector
    all_subsets_map = {
        'fake': [fake_collector],
        'network': [network.NetworkCollector],
        'other': [linux.LinuxHardwareCollector]
    }
    dep_map = build_dep_data({'fake', 'network', 'other'}, all_subsets_map)
    assert dep_map['fake'] == {'other'}
    assert dep_map['network'] == set()
    assert dep_map['other'] == set()



# Generated at 2022-06-22 22:50:12.371262
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fm = BaseFactCollector()
    collected_facts = {}
    collected_facts = fm.collect(collected_facts = collected_facts)
    assert collected_facts == {}


# Generated at 2022-06-22 22:50:14.736795
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(1)
    except CollectorNotFoundError as e:
        assert e.args == (1,)



# Generated at 2022-06-22 22:50:23.461795
# Unit test for function tsort
def test_tsort():
    # small test set
    sorted_list = [(u'a', set()), (u'b', set([u'a'])), (u'c', set([u'b'])), (u'd', set([u'c']))]
    test_dep_map = {}
    for (node, edges) in sorted_list:
        test_dep_map[node] = edges

    assert sorted_list == tsort(test_dep_map)

    # linear dep_map
    test_dep_map = {u'a': set([u'b']), u'b': set([u'c']), u'c': set([u'd']), u'd': set()}
    assert sorted_list == tsort(test_dep_map)

    # deps_map with a cycle

# Generated at 2022-06-22 22:50:32.931515
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['a', 'b'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['a', 'b'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['a', 'c'])
    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['a', 'b'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['a', 'b'])


# Generated at 2022-06-22 22:50:44.788819
# Unit test for function select_collector_classes
def test_select_collector_classes():
    '''Unit test for function select_collector_classes'''

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Simulate facts by subclassing BaseFactCollector and defining the '_fact_ids' class variable
    class CollectorFacts(BaseFactCollector):
        _fact_ids = ['somefact_a', 'somefact_b', 'somefact_c']
    class CollectorFacts2(BaseFactCollector):
        _fact_ids = ['somefact_c', 'somefact_d', 'somefact_e']

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['somefact_a'].append(CollectorFacts)
    all_fact_subsets['somefact_b'].append(CollectorFacts)
    all_fact_subsets

# Generated at 2022-06-22 22:50:54.838900
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.namespace import PrefixNamespace
    test_collector = BaseFactCollector(namespace=PrefixNamespace('pre_'))
    test_facts = test_collector.collect_with_namespace()
    assert test_facts.keys() == []

    test_collector = BaseFactCollector(namespace=PrefixNamespace('pre_'))
    test_facts = test_collector.collect_with_namespace(collected_facts={'a': 'b'})
    assert test_facts == {}



# Generated at 2022-06-22 22:50:58.865212
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    collector = BaseFactCollector()
    module = AnsibleModule(argument_spec={})
    assert collector.collect_with_namespace(module=module,collected_facts=None) == {}
test_BaseFactCollector_collect_with_namespace()



# Generated at 2022-06-22 22:51:10.270170
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'collectorA': [CollectorA],
                        'collectorB': [CollectorB],
                        'collectorC': [CollectorC],
                        'collectorD': [CollectorD],
                        'collectorTest': [CollectorTest]}
    collector_names = ['collectorA', 'collectorB', 'collectorC', 'collectorD', 'collectorTest']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'collectorA': set(), 'collectorB': set(['collectorA']), 'collectorC': set(['collectorA']), 'collectorD': set(['collectorB']), 'collectorTest': set(['collectorC', 'collectorD'])}


# Generated at 2022-06-22 22:51:16.870854
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class A(BaseFactCollector):
        name = 'a'
        _fact_ids = ('a', 'b', 'c')
    class B(BaseFactCollector):
        name = 'a'
        _fact_ids = ('a', 'b', 'c')
    class C(BaseFactCollector):
        name = 'c'
        _fact_ids = ('c', 'd', 'e')
    class D(BaseFactCollector):
        name = 'c'
        _fact_ids = ('c', 'd', 'e')

    all_collectors = [A, B, C, D]

    all_fact_subsets = defaultdict(list)
    for collector in all_collectors:
        all_fact_subsets[collector.name].append(collector)

# Generated at 2022-06-22 22:51:24.746468
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    dnfe = CollectorNotFoundError('a')
    assert(str(dnfe) == 'a')
    dnfe = CollectorNotFoundError('a', 'b')
    assert(str(dnfe) == 'a: b')
    dnfe = CollectorNotFoundError('a', 'b', 'c')
    assert(str(dnfe) == 'a: b, c')
    dnfe = CollectorNotFoundError('a', 'b', 'c', 'd')
    assert(str(dnfe) == 'a: b, c, d')



# Generated at 2022-06-22 22:51:26.409925
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd = UnresolvedFactDep('foo')
    assert 'foo' in str(ufd)



# Generated at 2022-06-22 22:51:34.554890
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class CollectA(BaseFactCollector):
        name = 'a'

    class CollectB(BaseFactCollector):
        name = 'b'
        required_facts = set(('a',))

    class CollectC(BaseFactCollector):
        name = 'c'
        required_facts = set(('b',))

    class CollectD(BaseFactCollector):
        name = 'd'
        required_facts = set(('a',))

    class CollectE(BaseFactCollector):
        name = 'e'
        required_facts = set(('a',))

    # exerpt of a similar function from a 'real' facts module

# Generated at 2022-06-22 22:51:45.012138
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    unresolved_fact_dep = UnresolvedFactDep("abc")
    assert str(unresolved_fact_dep) == "abc"  # test that constructor works


# Return a dict of the fact deps
#
# The return value of this function is a dict where the key is a fact name, and the value is a list of
# fact names that, if present, should cause the key fact to be evaluated first.
#
# For example, when the key is "ansible_os_family", and the value is ["ansible_os_release"],
# the value means that the "ansible_os_family" fact should be evaluated before the "ansible_os_release" fact.
#
# For clarity, the dict is formatted as
# { <key>: [ <value> ],
#   <key>: [ <value> ],
# }
#
#

# Generated at 2022-06-22 22:51:46.987228
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    assert not fc.collect()


# Generated at 2022-06-22 22:51:50.255453
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import pytest
    from ansible.module_utils.facts.collectors.network import NetworkFactCollector

    module_mock = pytest.Mock()

    network = NetworkFactCollector(module=module_mock)
    facts = network.collect(module=module_mock)



# Generated at 2022-06-22 22:51:52.575174
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.name == None
    assert fc.collectors == []
    assert fc.namespace == None



# Generated at 2022-06-22 22:52:00.092274
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes(['non_dup', 'dup', 'dup'],
                                    {'non_dup': [object()], 'dup': [object(), object()]}) == [object(), object(), object()]
    assert select_collector_classes([], {}) == []
    assert select_collector_classes(['nonexisting'], {}) == []
    assert select_collector_classes([], {'non_dup': [object()]}) == []



# Generated at 2022-06-22 22:52:12.763614
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector_A(BaseFactCollector):
        _fact_ids = frozenset(('test_a1', 'test_a2'))
        name = 'test_a'

    class TestFactCollector_B(BaseFactCollector):
        _fact_ids = frozenset(('test_b1', 'test_b2'))
        name = 'test_b'

    class TestFactCollector_C(BaseFactCollector):
        _fact_ids = frozenset(('test_c1', 'test_c2'))
        name = 'test_c'

    class TestFactCollector_D(BaseFactCollector):
        _fact_ids = frozenset(('test_d1', 'test_d2'))
        name = 'test_d'


# Generated at 2022-06-22 22:52:20.298713
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test data
    all_collector_classes = [
        'LinuxFactCollector',
        'NetworkFactCollector',
        'GenericFactCollector'
    ]
    # Test case with valid subset with matching collector
    selected_collectors = select_collector_classes(['LinuxCollector'], all_collector_classes)
    assert selected_collectors == ['LinuxFactCollector']
    # Test case with valid subset with mismatching collector
    selected_collectors = select_collector_classes(['WindowsCollector'], all_collector_classes)
    assert selected_collectors == []


# Generated at 2022-06-22 22:52:29.081029
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestBaseFactCollector(BaseFactCollector):
        name = 'test'

    test_basefactcollector = TestBaseFactCollector()
    obj1 = {'a': 1, 'b': 2}
    obj2 = {'c': 3}
    expect = {'a': 1, 'b': 2}
    assert test_basefactcollector.collect_with_namespace(collected_facts=obj1) == expect
    assert test_basefactcollector.collect_with_namespace(collected_facts=obj2) == {}



# Generated at 2022-06-22 22:52:37.076842
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['facts_a'].append(MockFactCollector('facts_a', []))
    all_fact_subsets['facts_b'].append(MockFactCollector('facts_b', ['facts_c']))
    all_fact_subsets['facts_c'].append(MockFactCollector('facts_c', []))
    all_fact_subsets['facts_d'].append(MockFactCollector('facts_d', ['facts_a']))
    all_fact_subsets['facts_e'].append(MockFactCollector('facts_e', ['facts_z']))

    # The order of this list is important, they are inter-dependent

# Generated at 2022-06-22 22:52:40.083580
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import BaseFactCollector
    test_collector = BaseFactCollector()
    assert isinstance(test_collector, BaseFactCollector)



# Generated at 2022-06-22 22:52:44.598861
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(collector='this is a collector')
    except CollectorNotFoundError as e:
        assert e.args[0] == "No such collector: 'this is a collector'"


# Generated at 2022-06-22 22:52:55.248220
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class FakeCollector:
        name = 'fake'

        @classmethod
        def platform_match(cls, info):
            info = info.get('system', None)
            if info == 'Linux':
                return FakeCollector
            return None

    class FakeCollector_Windows(FakeCollector):
        _platform = 'Windows'

    class FakeCollector_Generic(FakeCollector):
        _platform = None

    class FakeCollector_NotMatch(FakeCollector):
        _platform = 'Network'

    all_collector_classes = [FakeCollector_Generic, FakeCollector_Windows, FakeCollector_NotMatch]

    # test with a bogus platform
    found_collectors = find_collectors_for_platform(all_collector_classes, [{'system': 'bogus'}])
    assert not found

# Generated at 2022-06-22 22:52:58.584340
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    import pytest
    with pytest.raises(ValueError):
        raise UnresolvedFactDep('my_fact')


# Generated at 2022-06-22 22:53:07.324589
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['c1'])
        _platform = 'Linux'
        name = 'c1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['c2'])
        _platform = 'Linux'
        name = 'c2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['c3'])
        _platform = 'FreeBSD'
        name = 'c3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['c4'])
        _platform = 'OpenBSD'
        name = 'c4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['c5'])
        _platform = 'Generic'


# Generated at 2022-06-22 22:53:09.497519
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    '''Unit test for method collect of class BaseFactCollector

    It is intended for testing cases for this method
    '''
    pass


# Generated at 2022-06-22 22:53:19.290114
# Unit test for function tsort

# Generated at 2022-06-22 22:53:28.413648
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # we'll use a single fake class for all tests
    class FakeCollectorClass(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()
        def __init__(self, collectors=None, namespace=None):
            super(FakeCollectorClass, self).__init__(collectors, namespace)

            self._orig_required_facts = self.required_facts

            self.required_facts = self.required_facts.copy()

            for i in range(2, len(self.name)):
                self.required_facts.add(self.name[0:i])

    all_fact_subsets = defaultdict(list)
