

# Generated at 2022-06-22 22:43:21.902129
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        # Test with a collector that is not found
        raise CollectorNotFoundError('collector_name')
    except CollectorNotFoundError as e:
        # Check that the collector name can be accessed in the exception message
        assert 'collector_name' in e.message


# Generated at 2022-06-22 22:43:32.656645
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import File, LocalIPv4, LocalIPv6

    # Test duplicate collectors
    all_fact_subsets = {'file': [File, LocalIPv4], 'ip': [LocalIPv4, LocalIPv6]}
    collector_names = ['file', 'ip']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert set(selected_collector_classes) == set([File, LocalIPv4, LocalIPv6])

    # Test with some missing collectors
    all_fact_subsets = {'file': [File, LocalIPv4], 'ip': [LocalIPv4]}
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

# Generated at 2022-06-22 22:43:35.309093
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    msg = "The fact 'A' depends on the fact 'B'"
    ufd = UnresolvedFactDep(msg)
    assert ufd.message == msg



# Generated at 2022-06-22 22:43:44.259529
# Unit test for function get_collector_names
def test_get_collector_names():
    '''
      test_get_collector_names test cases
      1. empty call
      2. all subsets
      3. min subsets
      4. specific subset
      5. !all and !min and specific subset
      6. !all and !min and !specific subset
      7. !all and !min and specific subset and !another specific subset
      8. !all, !min and all other subsets
      9. !all, !min and all other subsets except specific subset
      10. !all, !min and all other subsets except !specific subset
      11. !all, !min and all other subsets except !specific subset
          and explicit inclusion of specific subset
      12. bad subset
    '''
    import pytest
    # Case 1
    with pytest.raises(TypeError) as exception_info:
        get_

# Generated at 2022-06-22 22:43:51.119512
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class c1(BaseFactCollector):
        name = 'c1'
        required_facts = set(['c3'])

    class c2(BaseFactCollector):
        name = 'c2'
        required_facts = set(['c1'])

    class c3(BaseFactCollector):
        name = 'c3'
        required_facts = set()

    class c4(BaseFactCollector):
        name = 'c4'
        required_facts = set(['c5'])

    class c5(BaseFactCollector):
        name = 'c5'
        required_facts = set()


# Generated at 2022-06-22 22:43:54.965171
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('This is the message')
    except CycleFoundInFactDeps as err:
        assert str(err) == 'This is the message'
        assert repr(err) == 'This is the message'



# Generated at 2022-06-22 22:44:02.145940
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('abc')
    except CollectorNotFoundError as e:
        assert str(e) == "'abc'"

# dict of dicts. 1st dict key is fact module which requires another
# fact module to be called 1st. The value of the key is a dict of
# the fact modules which that fact module requires to be called first.
#
# The following code declares that fact module 'B' requires fact module 'A'
# to be called before it.
#
# {'B': {'A': True}}
#
# The following code declares that fact module 'C' requires fact module
# 'B' and 'A' to be called before it.
#
# {'C': {'B': True, 'A': True}}
#
# It is an error to have a cycle in the dependencies. For example, the

# Generated at 2022-06-22 22:44:04.922046
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('bad name')
    except CollectorNotFoundError as e:
        assert e.args[0] == "'bad name'"



# Generated at 2022-06-22 22:44:07.883339
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps('a', 'b')
    assert exc.args[0] == 'a', 'expected error message'
    assert exc.args[1] == 'b', 'expected error message'


# Generated at 2022-06-22 22:44:18.272289
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    import unittest
    import sys

    class FakeNamespace:
        def __init__(self, prefix='test_prefix_'):
            self.prefix = prefix

        def transform(self, key_name):
            '''transform a key_name with a fake prefix'''
            return '%s%s' % (self.prefix, key_name)

    class TestBaseFactCollector(BaseFactCollector):
        '''# Test class for BaseFactCollector
        '''
        name = 'test'
        _fact_ids = {'test_fact_id'}

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # 1. test_1: test collect_with_namespace with no namespace
    test_1 = TestBaseFactCollect

# Generated at 2022-06-22 22:44:24.568008
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class Collector(BaseFactCollector):
        name = 'collector'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'one': 'two'}

    assert hasattr(Collector(), 'collect')
    facts = Collector().collect()
    assert 'one' in facts
    assert facts['one'] == 'two'



# Generated at 2022-06-22 22:44:35.041171
# Unit test for function resolve_requires
def test_resolve_requires():
    import itertools
    import random

    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    def make_iter():
        return itertools.cycle(sorted(all_fact_subsets))

    for attempt in range(10):
        it = make_iter()
        required_facts_by_collector = {}
        for i in range(random.randint(0, 10) + 5):
            collector = next(it)
            num_reqs = random.randint(0, 2)
            reqs = []

# Generated at 2022-06-22 22:44:42.630212
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # NOTE: This test is designed to use 'test_collector2'
    # for testing.
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.test import test_collector2
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors import get_collector_classes

    # test_collector2 has a requires for 'test_collector2_inner'
    all_fact_subsets = {'test_collector2': test_collector2.TestSubsetCollector2.collectors,
                        'test_collector2_inner': test_collector2.TestSubsetCollector2.collector_inner
                        }


# Generated at 2022-06-22 22:44:51.084019
# Unit test for function select_collector_classes

# Generated at 2022-06-22 22:44:56.350239
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b'], {'a':[1, 2], 'b':[3]})
    assert dep_map == {'a': {1, 2}, 'b': {3}}

# Returns a topologically sorted list of nodes

# Generated at 2022-06-22 22:45:08.494373
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import pytest
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import hardware

    # Set up some test classes
    class DummyFactCollector1(BaseFactCollector):
        name = 'dummy1'

    class DummyFactCollector2(BaseFactCollector):
        name = 'dummy2'
        _fact_ids = {'dummy1'}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([DummyFactCollector1, DummyFactCollector2])

    # Test basic functionality.
    assert len(fact_id_to_collector_map) == 3
    assert len(aliases_map) == 1

    assert fact_id_to_collector_map['dummy1']

# Generated at 2022-06-22 22:45:16.416026
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map_check = defaultdict(set)
    dep_map_check['os'] = set()
    dep_map_check['memory'] = {'os'}
    dep_map_check['extras'] = {'memory'}

    class FactCollector(BaseFactCollector):
        _fact_ids = set()
        required_facts = set()

    class OSFactCollector(FactCollector):
        name = 'os'

    class MemoryFactCollector(FactCollector):
        name = 'memory'
        required_facts = {'os'}

    class ExtrasFactCollector(FactCollector):
        name = 'extras'
        required_facts = {'memory'}

    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-22 22:45:24.855067
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = {'test_collector', '1', '2', '3'}

    class Test2Collector(BaseFactCollector):
        name = 'test2_collector'
        _fact_ids = {'test2_collector', '4', '5', '6'}
        required_facts = {'test_collector'}

    # test that the fact id names are returned
    result = collector_classes_from_gather_subset(all_collector_classes=[TestCollector, Test2Collector],
                                                  gather_subset=['test_collector', 'test2_collector'])

# Generated at 2022-06-22 22:45:31.043165
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': {'foo'}, 'b': {'bar'}, 'c': {'foo', 'bar'}})
    assert len(dep_map) == 3
    assert dep_map['a'] == {'foo'}
    assert dep_map['b'] == {'bar'}
    assert dep_map['c'] == {'foo', 'bar'}



# Generated at 2022-06-22 22:45:32.945225
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collect() == {}
    assert fc.collectors == []
    assert fc.namespace is None



# Generated at 2022-06-22 22:45:43.162195
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['all', 'facter']
    collect_all = BaseFactCollector()
    collect_facter = BaseFactCollector()
    collect_fact_all = set([collect_facter, collect_all])
    all_fact_subsets = defaultdict(set)
    all_fact_subsets['all'] = collect_fact_all
    all_fact_subsets['facter'] = set([collect_facter])
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert collect_facter in selected_collector_classes
    assert collect_all not in selected_collector_classes


# Generated at 2022-06-22 22:45:54.394021
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        gather_subset=["!all"],
        valid_subsets=frozenset(['all', 'minimal']),
        minimal_gather_subset=frozenset(['minimal'])) == frozenset(['all'])
    assert get_collector_names(
        gather_subset=["!all"],
        valid_subsets=frozenset(['all', 'minimal']),
        minimal_gather_subset=frozenset(['minimal']),
        aliases_map={'foo': {'a', 'b'}}) == frozenset(['all'])

# Generated at 2022-06-22 22:45:58.610791
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # pylint: disable=protected-access
    exception = UnresolvedFactDep('a_message')
    assert exception.args == ('a_message',)
    assert exception._message == 'a_message'


# Generated at 2022-06-22 22:46:00.727968
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc1 = BaseFactCollector()
    fc2 = BaseFactCollector(collectors=[])

    assert fc1 is not None
    assert fc2 is not None


# Generated at 2022-06-22 22:46:10.171622
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(['service_mgr', 'foo_bar'], {
        'service_mgr': [object],
    }) == set(['foo_bar']), find_unresolved_requires(['service_mgr', 'foo_bar'], {
        'service_mgr': [object],
    })


# from https://github.com/laszlocph/algorithms/blob/master/toposort.py
#
# topological sort implementation from:
#  Timothy J. Roscoe and Amanda Birmingham (2010) "Cycle detection in topological sort"

# Generated at 2022-06-22 22:46:21.238401
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = ['a','b','c','d','e','f','g','h','i','j','k','l']
        name = 'test'
        required_facts = set()
        def collect(self, module=None, collected_facts=None):
            pass

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector()])
    # fact_id_to_collector_map should have length 13
    assert len(fact_id_to_collector_map) == 13
    # aliases_map should have length 1
    assert len(aliases_map) == 1
    # aliases_map['test'] should have length 12
    assert len(aliases_map['test']) == 12



# Generated at 2022-06-22 22:46:31.005507
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    import imp
    import inspect

    # attempt to load all facts modules
    # print("loading for system: %s" % platform_info['system'])
    all_collector_classes = set()
    mod_paths = [collectors.__path__[0]]

    for mod_path in mod_paths:
        for path in os.listdir(mod_path):
            if path.endswith('.py') and not path.startswith('_'):
                name = path[:-3]
                # make sure the module is useful (ie, has a 'main' function defined)
                mod = imp.find_module(name, [mod_path])
                mod = imp.load_module(name, *mod)

# Generated at 2022-06-22 22:46:34.384113
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest
    class DerivedFactCollector(BaseFactCollector):
        pass
    dfc = DerivedFactCollector()
    assert dfc.collect_with_namespace() == {}


# Generated at 2022-06-22 22:46:41.510321
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # a class with a required fact not provided
    class RequiredFactMissing(BaseFactCollector):
        name = 'required_fact_missing'
        required_facts = set(['arch'])  # arch not present in fact_ids

    # this should raise an exception because the required fact is not provided
    try:
        RequiredFactMissing()
    except UnresolvedFactDep as e:
        err = e
    assert err.args[0] == 'required_fact_missing requires arch'


# Generated at 2022-06-22 22:46:49.893928
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class BaseCollectorClass(BaseFactCollector):
        name = None

    class CollectorDep1(BaseCollectorClass):
        name = "CollectorDep1"

        def __init__(self, collectors=None, namespace=None):
            super(CollectorDep1, self).__init__(collectors, namespace)

    class CollectorDep2(BaseCollectorClass):
        name = "CollectorDep2"

        def __init__(self, collectors=None, namespace=None):
            super(CollectorDep2, self).__init__(collectors, namespace)

    class Collector1(BaseCollectorClass):
        name = "Collector1"
        _fact_ids = {"c1"}


# Generated at 2022-06-22 22:47:01.296807
# Unit test for function get_collector_names
def test_get_collector_names():
    # get_collector_names(minimal_gather_subset=[], gather_subset=[], aliases_map={}, platform_info={}) -> set([])
    assert get_collector_names(minimal_gather_subset=[], gather_subset=[], aliases_map={}, platform_info={}) == set([])

    # get_collector_names(minimal_gather_subset=[], gather_subset=['all'], aliases_map={}, platform_info={}) -> set([])
    assert get_collector_names(minimal_gather_subset=[], gather_subset=['all'], aliases_map={}, platform_info={}) == set([])

    # get_collector_names(minimal_gather_subset=[], gather_subset=['!'], aliases_map={}, platform

# Generated at 2022-06-22 22:47:03.955876
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError('foo')
    assert str(err) == "'foo'"
    assert repr(err) == "CollectorNotFoundError('foo')"



# Generated at 2022-06-22 22:47:14.431883
# Unit test for function get_collector_names
def test_get_collector_names():
    # aliases_map is a map from gather subset names to a set of
    # collectors that should be added if the subset is added.
    # For example, {'network': {'ipv4', 'ipv6', 'fqdn'}}
    # indicates that if 'network' is added to gather_subset
    # then the ipv4, ipv6, and fqdn collectors should also be added.
    aliases_map = {'hardware': {'firmware', 'dmi', 'devices'},
                   'network': {'ipv4', 'ipv6', 'fqdn'},
                   'software': {'system'}
                  }

    # valid_subsets is the list of values that can be given to gather_subset
    # things like 'all' and 'network' etc

# Generated at 2022-06-22 22:47:26.724675
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest
    import sys
    import os
    import json
    import yaml
    import re
    import copy

    class TestBaseFactCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict(hello='world')
            return facts_dict

    class TestNamespace(object):
        def __init__(self, prefix):
            '''namespace with just a prefix'''
            self.prefix = prefix

        def transform(self, key):
            return '%s_%s' % (self.prefix, key)

    def run_all_tests(collector, namespace=None, test_label='', expected_output=None):
        '''Run tests for a collector'''
        result = collector.collect_with

# Generated at 2022-06-22 22:47:28.451551
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    obj = UnresolvedFactDep('a message')
    assert str(obj) == 'a message'



# Generated at 2022-06-22 22:47:34.129730
# Unit test for function build_dep_data
def test_build_dep_data():
    try:
        import pytest
        from ansible.module_utils.facts.collectors import all_collector_classes

        # Build the dep_map.
        dep_map = build_dep_data(['all', 'hardware'], {'all': all_collector_classes,
                                                       'hardware': all_collector_classes})
        # Assert that a given collector lists only those that it depends on.
        assert dep_map['all'] == {'hardware'}
        assert dep_map['hardware'] == set()

    except ImportError:
        pytest.skip("pytest is required to run unit tests")



# Generated at 2022-06-22 22:47:43.785212
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import ALL_SUBSETS
    all_fact_subsets = dict()
    for collector_name in ALL_SUBSETS:
        all_fact_subsets[collector_name] = [type(collector_name, (object,), dict(required_facts=set()))]
    all_fact_subsets['f2'][0].required_facts.add('f3')
    all_fact_subsets['f1'][0].required_facts.add('f2')
    all_fact_subsets['f0'][0].required_facts.add('f1')
    all_fact_subsets['f0'][0].required_facts.add('f2')

# Generated at 2022-06-22 22:47:54.359501
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'network': [object(), object()],
                        'all': [object(), object()]}
    collector_names = set(all_fact_subsets.keys())
    first_collector_deps = {'hardware'}
    second_collector_deps = {'all'}
    third_collector_deps = {'dmi'}
    fourth_collector_deps = {'network'}
    first_collector_idx = 0
    second_collector_idx = 1
    third_collector_idx = 0
    fourth_collector_idx = 1


# Generated at 2022-06-22 22:48:06.932851
# Unit test for function build_dep_data
def test_build_dep_data():
    import platform
    import time
    import pytest
    from ansible.module_utils.facts.collector import build_dep_data

    class TestCollectorA(BaseFactCollector):
        name = 'TestCollectorA'
        required_facts = set()

    class TestCollectorB(BaseFactCollector):
        name = 'TestCollectorB'
        required_facts = set()

    class TestCollectorC(BaseFactCollector):
        name = 'TestCollectorC'
        required_facts = set(['TestCollectorA'])

    class TestCollectorD(BaseFactCollector):
        name = 'TestCollectorD'
        required_facts = set(['TestCollectorB', 'TestCollectorC'])


# Generated at 2022-06-22 22:48:14.933995
# Unit test for function tsort
def test_tsort():
    test_deps = {
        'a': set('b'),
        'b': set('c'),
        'c': set('e'),
        'd': set('c'),
        'e': set('f', 'g'),
        'f': set('g'),
    }
    assert tsort(test_deps) == [('f', set('g')), ('g', set()), ('c', set('e', 'g')), ('e', set('f', 'g')), ('b', set('c')), ('a', set('b')), ('d', set('c'))]
    # build on the previous dep_map, but add a cycle "a" -> "b" -> "a"
    test_deps['a'].add('a')

# Generated at 2022-06-22 22:48:19.894708
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collectors=None
    namespace=None
    basefactcollector=BaseFactCollector(collectors, namespace)
    module=None
    collected_facts=None
    basefactcollector.collect(module, collected_facts)


# Generated at 2022-06-22 22:48:29.654847
# Unit test for function tsort
def test_tsort():
    data = {1: [2, 3], 2: [4, 5], 3: [4, 5], 4: [], 5: []}
    assert [(1, [2, 3]), (2, [4, 5]), (3, [4, 5]), (4, []), (5, [])] == tsort(data)

    def validate(dep_map):
        try:
            tsort(dep_map)
        except CycleFoundInFactDeps:
            return False
        return True

    # cycles
    assert validate({1: [2], 2: [1]}) is False
    assert validate({1: [2], 2: [3], 3: [1]}) is False
    assert validate({1: [2, 3], 2: [1, 3]}) is False

    # sorting

# Generated at 2022-06-22 22:48:30.686794
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError('test')



# Generated at 2022-06-22 22:48:38.977574
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'],
                             {'a': set(), 'b': {'a'}, 'c': {'a', 'b'}})
    expected = defaultdict(set,
                           {'a': set(),
                            'b': {'a'},
                            'c': {'a', 'b'}})
    assert dep_map == expected, \
        'expected:\n%s\nbut got:\n%s' % (expected, dep_map)



# Generated at 2022-06-22 22:48:48.676239
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    def test_fact_dep(val):
        raise UnresolvedFactDep([val])

    try:
        test_fact_dep('test_val')
    except UnresolvedFactDep as e:
        if e.args[0][0] == 'test_val':
            pass
        else:
            assert False, 'returned value does not match'
        return
    except ValueError as e:
        assert False, 'incorrect exception raised'
    assert False, 'No exception raised'

    try:
        test_fact_dep(['test_val'])
    except UnresolvedFactDep as e:
        if e.args[0][0] == 'test_val':
            pass
        else:
            assert False, 'returned value does not match'
        return

# Generated at 2022-06-22 22:48:52.072988
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("test error")
    except CollectorNotFoundError as e:
        assert e.args[0].startswith('Failed to find fact collector for ')


# Generated at 2022-06-22 22:49:01.492727
# Unit test for function tsort
def test_tsort():
    sorted_names = []
    for sort_node, deps in tsort(dict(
        A=set('BCD'),
        B=set('C'),
        C=set('EF'),
        D=set('H'),
        E=set('G'),
        F=set(),
        G=set(),
        H=set('G'),
    )):
        sorted_names.append(sort_node)
    assert sorted_names == ['F', 'G', 'H', 'B', 'E', 'C', 'D', 'A']


# Generated at 2022-06-22 22:49:07.417655
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    '''BaseFactCollector.collect_with_namespace(module, collected_facts)'''
    fc = BaseFactCollector()

    fc.collect = lambda collected_facts: {'a': 'b'}

    assert fc.collect_with_namespace() == {'a': 'b'}

    fc.namespace = 'ansible_'
    fc.collect = lambda collected_facts: {'a': 'b'}
    assert fc.collect_with_namespace() == {'ansible_a': 'b'}


# TODO: move to common module_utils place

# Generated at 2022-06-22 22:49:17.652501
# Unit test for function tsort
def test_tsort():
    # build a very simple graph
    graph = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    with raises(CycleFoundInFactDeps):
        tsort(graph)

    # add some dependency chaining
    graph = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['e']),
        'e': set([]),
    }
    sorted_list = tsort(graph)
    assert len(sorted_list) == 5

    # add some dependency chaining

# Generated at 2022-06-22 22:49:24.159153
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Makes sure the constructor for CycleFoundInFactDeps works

    This test makes sure that when a CycleFoundInFactDeps is raised,
    its message matches the expected message.
    '''
    # Test cases for CycleFoundInFactDeps
    # cycle_test_inputs contains pairs of a list of collector names, and
    # an expected message that would be generated from that input.
    cycle_test_inputs = [
        (['first_collector'], 'first_collector'),
        (['first_collector', 'second_collector'], 'first_collector -> second_collector'),
        (['first_collector', 'second_collector', 'third_collector'], 'first_collector -> second_collector -> third_collector'),
    ]
    # Actually run the tests

# Generated at 2022-06-22 22:49:25.525770
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert BaseFactCollector.collect() == {}


# Generated at 2022-06-22 22:49:35.034042
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import pytest
    from ansible_collections.community.general.plugins.module_utils.facts.fact_collector_base import BaseFactCollector

    # Make a testing class
    class TestClass(BaseFactCollector):
        _fact_ids = frozenset(['one', 'two'])

    collectors_for_platform = [TestClass]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # fact_id_to_collector_map should contain the list of TestClass
    # for each of TestClass._fact_ids
    for fact_id in ['one', 'two']:
        assert fact_id_to_collector_map[fact_id][0] == TestClass

    # aliases_map should contain Test

# Generated at 2022-06-22 22:49:37.922868
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # This should not create an error
    BaseFactCollector()



# Base class for 'singleton' FactCollectors that can only be instantiated once.

# Generated at 2022-06-22 22:49:47.653973
# Unit test for function tsort
def test_tsort():
    tests = [
        (
            {1: [2, 3], 2: [4, 5], 3: [5]},
            [(1, {2, 3}), (2, {4, 5}), (3, {5})]
        ),
        (
            {1: [2, 3], 2: [3, 5], 3: [5]},
            [(1, {2, 3}), (2, {3, 5}), (3, {5})]
        ),
        (
            {1: [2], 2: [1]},
            CycleFoundInFactDeps
        )
    ]


# Generated at 2022-06-22 22:49:54.634425
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Creating instance for 'UnresolvedFactDep' class by passing string
    # 'Could not resolve fact dependency "foo" for "bar"' as argument
    timedout_error = UnresolvedFactDep('Could not resolve fact dependency '
                                      '"foo" for "bar"')

    # Checking 'timedout_error' should be instance of 'UnresolvedFactDep'
    assert isinstance(timedout_error, UnresolvedFactDep)



# Generated at 2022-06-22 22:50:04.206544
# Unit test for function build_dep_data
def test_build_dep_data():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['ansible_os_family'])
        name = 'ansible_os_family'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['ansible_distribution'])
        name = 'ansible_distribution'
        required_facts = set(['ansible_os_family'])

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['ansible_distribution_version'])
        name = 'ansible_distribution_version'
        required_facts = set(['ansible_distribution'])


# Generated at 2022-06-22 22:50:10.655632
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # collector_for_platform = set()
    # collector_for_platform.add(BaseFactCollector)
    # collector_for_platform.add(NetworkFactCollector)


    collectors_for_platform = set()
    collectors_for_platform.add(PlatformFactCollector)
    collectors_for_platform.add(NetworkFactCollector)
    collectors_for_platform.add(RoutingFactCollector)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert len(fact_id_to_collector_map) == 7 # 4 for NetworkFactCollector, 3 for PlatformFactCollector
    assert len(aliases_map) == 5
    assert "system" in aliases_map  # 2 for PlatformFactCollector


# Generated at 2022-06-22 22:50:21.475627
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # assertEqual requires <https://docs.python.org/2/library/unittest.html>
    from ansible.module_utils.facts.__init__ import FactCollector

    assertEqual = getattr(__builtin__, 'TestCase', object).assertEqual

    class Hardware(FactCollector):
        name = 'hardware'

        _fact_ids = {'devices', 'dmi'}

    class Foo(FactCollector):
        name = 'foo'

        _fact_ids = {'bar'}

        required_facts = {'hardware'}

    class Bar(Foo):
        name = 'bar'

        _fact_ids = {'baz'}

    class Baz(Foo):
        name = 'baz'

        _fact_ids = {'foo'}

        required

# Generated at 2022-06-22 22:50:31.665863
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # f1 requires f2, f3
    class Fact1(BaseFactCollector):
        name = 'f1'
        required_facts = {'f2', 'f3'}
    # f2 requires f4, f5
    class Fact2(BaseFactCollector):
        name = 'f2'
        required_facts = {'f4', 'f5'}
    # f3 requires nothing
    class Fact3(BaseFactCollector):
        name = 'f3'
        required_facts = set()

    all_fact_subsets = {
        'f1': [Fact1],
        'f2': [Fact2],
        'f3': [Fact3],
        }

    # f1 requires f2, f3
    # f2 requires f4, f5
    # f3 requires nothing
   

# Generated at 2022-06-22 22:50:44.074016
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class NetworkCollector(BaseFactCollector):
        _fact_ids = {'interfaces', 'ipv4_interfaces', 'ipv6_interfaces', 'default_ipv4'}

        name = 'network'
        required_facts = {'os_family'}

    class HardwareCollector(BaseFactCollector):
        _fact_ids = {'devices', 'dmi'}

        name = 'hardware'
        required_facts = set()

    fc_classes = [NetworkCollector, HardwareCollector]
    all_valid_subsets = frozenset(['all', 'network', 'hardware'])
    minimal_gather_subset = frozenset(['network'])

# Generated at 2022-06-22 22:50:47.291679
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestClass(BaseFactCollector):
        pass
    tc = TestClass()
    assert tc.namespace is None


# Generated at 2022-06-22 22:50:49.540199
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(UnresolvedFactDep):
        raise UnresolvedFactDep("test message")


# Generated at 2022-06-22 22:51:01.832216
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts import collector

    import datetime
    #TODO: try desc. as a str, timestamp as a tuple, test_module as a list
    test_module = {
        "start": datetime.datetime(2020, 4, 3, 7, 11, 59, 583607),
        "end": datetime.datetime(2020, 4, 3, 7, 12, 9, 532048),
        "duration": 9.948441,
        "exception": None,
        "module_name": "BaseFactCollector",
        "test_name": "test_BaseFactCollector_collect",
        "result": None
    }
    test_module["result"] = {}
    test_module["result"].update({"name": "test_BaseFactCollector_collect"})
    test

# Generated at 2022-06-22 22:51:03.834985
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    e = UnresolvedFactDep('The first argument')
    assert str(e) == 'The first argument'



# Generated at 2022-06-22 22:51:13.127753
# Unit test for function get_collector_names
def test_get_collector_names():
    # Minimal gather subset only
    result = get_collector_names(
        valid_subsets={'all', 'min'},
        minimal_gather_subset={"min"},
        gather_subset=['min'],
        aliases_map=defaultdict(set)
    )
    assert result == {"min"}

    # No subsets
    result = get_collector_names(
        valid_subsets={'all', 'min'},
        minimal_gather_subset={"min"},
        gather_subset=[],
        aliases_map=defaultdict(set)
    )
    assert result == {"min"}

    # Add all subsets

# Generated at 2022-06-22 22:51:15.710699
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as e:
        assert str(e) == ''



# Generated at 2022-06-22 22:51:21.316989
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'collector1': [object()],
                        'collector2': [object(), object()]}
    collector_names = set(all_fact_subsets)
    collector_names.add('something_else')
    result = find_unresolved_requires(collector_names, all_fact_subsets)
    assert result == set(['something_else'])


# Generated at 2022-06-22 22:51:30.010885
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class A(BaseFactCollector):
        name = 'A'
        def __init__(self, collectors=None, namespace=None):
            super(A, self).__init__(collectors=collectors, namespace=namespace)

    class B(BaseFactCollector):
        name = 'B'
        def __init__(self, collectors=None, namespace=None):
            super(B, self).__init__(collectors=collectors, namespace=namespace)

    # in python3.7,  the ordering of __dict__ is defined
    # in python3.6, the ordering of keys() is not defined, so we can't test for equality on a dict
    # instead, we test for equality on two sets of keys
    a = A([B()])
    # a.collectors is a list of BaseFactCollectors, but

# Generated at 2022-06-22 22:51:34.233780
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # pylint: disable=too-many-locals
    # tests collector_classes_from_gather_subset() function
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = {'a'}

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = {'a'}

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = {'c'}

    class CollectorCycle1(BaseFactCollector):
        name = 'cycle1'
        required_facts = {'cycle2'}

    class CollectorCycle2(BaseFactCollector):
        name = 'cycle2'


# Generated at 2022-06-22 22:51:42.480960
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors import yum_plugins

    # Test for function build_fact_id_to_collector_map
    collectors_for_platform = [yum_plugins.YumPlugins]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert 'yum_package_mgr_facts' in fact_id_to_collector_map['yum_plugins']


# Generated at 2022-06-22 22:51:44.108132
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    x = UnresolvedFactDep('foo')
    assert str(x) == 'foo'



# Generated at 2022-06-22 22:51:54.924085
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector_A(BaseFactCollector):
        name = 'A'
        _fact_ids = set(('B', 'C'))

    class Collector_B(BaseFactCollector):
        name = 'B'
        _fact_ids = set(('C',))

    class Collector_C(BaseFactCollector):
        name = 'C'
        _fact_ids = set(('D',))

    map, aliases = build_fact_id_to_collector_map(set([Collector_A, Collector_B, Collector_C]))

    assert set(map.keys()) == set(('A', 'B', 'C', 'D'))
    assert set(map['A']) == set((Collector_A,))
    assert set(map['B']) == set((Collector_A, Collector_B))

# Generated at 2022-06-22 22:52:07.574103
# Unit test for function tsort
def test_tsort():
    '''
    Create a test dep_map.
    Each key is a node, which must be a
    string. Each value is a set, which is the
    set of all nodes that the key node depends
    on.
    '''
    dep_map = defaultdict(set)
    dep_map['a'] = set(['d'])
    dep_map['b'] = set(['a'])
    dep_map['c'] = set(['a'])
    dep_map['d'] = set()
    dep_map['e'] = set(['b', 'c'])

    # Add a cycle to dep_map
    dep_map['x'] = set(['y'])
    dep_map['y'] = set(['z'])
    dep_map['z'] = set(['x'])


# Generated at 2022-06-22 22:52:18.541810
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts.network.linux import LinuxIfConfig
    from ansible.module_utils.facts.network.linux import LinuxNetwork

    # start from specific platform, then try generic
    for compat_platform in [LinuxIfConfig.platform_info, LinuxNetwork.platform_info]:
        platform_match = None
        for all_collector_class in [LinuxIfConfig, LinuxNetwork]:

            # ask the class if it is compatible with the platform info
            platform_match = all_collector_class.platform_match(compat_platform)

            if not platform_match:
                continue

            primary_name = all_collector_class.name

            # found_collectors.add(all_collector_class)

# Generated at 2022-06-22 22:52:20.051016
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    nfe = CollectorNotFoundError('test_name')
    assert nfe.args == ('test_name',)



# Generated at 2022-06-22 22:52:25.336547
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector(BaseFactCollector):
        name = 'test'

    class TestCollector2(BaseFactCollector):
        name = 'test2'

    class TestCollectorDep(BaseFactCollector):
        name = 'testdep'
        required_facts = set(['test2'])

    class TestCollectorDep2(BaseFactCollector):
        name = 'testdep2'
        required_facts = set(['testdep'])

    class TestCollectorDep3(BaseFactCollector):
        name = 'testdep3'
        required_facts = set(['testdep2'])

    class TestCollectorDep4(BaseFactCollector):
        name = 'testdep4'
        required_facts = set(['testdep2', 'test'])


# Generated at 2022-06-22 22:52:31.776832
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.system.linux import LinuxDistribution

    base_fact_collector = BaseFactCollector()
    collected_facts = {}
    collected_facts = base_fact_collector.collect_with_namespace(module = None, collected_facts=collected_facts)
    # Test if `collect_with_namespace` is implemented as expected
    assert collected_facts == {}

# Generated at 2022-06-22 22:52:35.714794
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('test string')
    except UnresolvedFactDep as exc:
        assert 'test string' in str(exc)
        assert 'UnresolvedFactDep' in str(exc)



# Generated at 2022-06-22 22:52:39.686580
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    a = BaseFactCollector()
    assert a.collectors == []
    assert a.namespace == None
    assert a.fact_ids == set([None])
    assert a._fact_ids == set()



# Generated at 2022-06-22 22:52:42.942179
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    # This should not throw an error
    CollectorNotFoundError('x')
    CollectorNotFoundError(5)
    CollectorNotFoundError(None)



# Generated at 2022-06-22 22:52:44.171625
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    assert {} == obj.collect()



# Generated at 2022-06-22 22:52:54.891627
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import get_collector

    # Setup test environment
    # TODO: Improve this test by adding a platform (like Linux)
    import platform
    platform_system = platform.system
    platform.system = lambda: 'Linux'
    class FakeModule:
        def __init__(self):
            return

        def fail_json(self, msg):
            return

    class FakeFact:
        def __init__(self):
            return

        def __getitem__(self, item):
            return 'Linux'

    import ansible.module_utils.facts.system.distribution as dists

# Generated at 2022-06-22 22:52:59.034099
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # test that we are raising the exception
    try:
        raise UnresolvedFactDep("error message")
    except UnresolvedFactDep as e:
        assert(e.args[0] == "error message")



# Generated at 2022-06-22 22:53:01.689857
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with timeout(1):
        try:
            raise UnresolvedFactDep('Test')
        except UnresolvedFactDep as e:
            assert str(e) == 'Test'



# Generated at 2022-06-22 22:53:13.408421
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import sys
    import unittest

    module_path = 'ansible.module_utils.facts.collector'
    sys.modules[module_path] = sys.modules[__name__]

    class Base1(BaseFactCollector):
        name = 'base1'
    class Base2(BaseFactCollector):
        name = 'base2'
    class Derived1(Base1):
        name = 'derived1'
    class Derived2(Base1):
        name = 'derived2'
    class Derived3(Base2):
        name = 'derived3'
    class Derived4(Derived1):
        name = 'derived4'
    class Derived5(Derived3):
        name = 'derived5'


# Generated at 2022-06-22 22:53:14.689599
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    assert True == True

# Generated at 2022-06-22 22:53:16.205418
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError("foo")
    assert(e.args[0] == "foo")



# Generated at 2022-06-22 22:53:19.075248
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with pytest.raises(CollectorNotFoundError) as execinfo:
        raise CollectorNotFoundError('bogus')
    assert 'bogus' in str(execinfo.value)

