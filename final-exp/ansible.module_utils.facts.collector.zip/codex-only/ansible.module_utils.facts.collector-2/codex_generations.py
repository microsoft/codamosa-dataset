

# Generated at 2022-06-22 22:43:25.885370
# Unit test for function build_dep_data
def test_build_dep_data():
    test_fact_subsets = {'has_dep': [BaseFactCollector], 'no_dep': [BaseFactCollector]}
    test_fact_subsets['has_dep'][0].required_facts = set(['no_dep'])
    test_fact_subsets['no_dep'][0].required_facts = set()
    test_collector_names = set(['has_dep', 'no_dep'])
    dep_data = build_dep_data(test_collector_names, test_fact_subsets)
    assert 'has_dep' in dep_data
    assert 'no_dep' in dep_data
    assert 'no_dep' in dep_data['has_dep']
    assert not dep_data['no_dep']
    # dep_data should be symmetric

# Generated at 2022-06-22 22:43:34.974561
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    platform_info = {'system': 'Linux'}
    test_collector_classes = [
        _TestLinuxFactCollector,   # nope
        _TestCollectorAlias,       # nope
        _TestGenericFactCollector, # nope
        _TestLinuxZeusCollector,   # nope
        _TestLinuxFactFooCollector, # nope
        _TestLinuxFactDerpCollector, # nope
        _TestLinuxFactFooCollector2, # nope
        _TestLinuxHardwareCollector, # YES
        _TestLinuxHardwareAliasedCollector, # YES
        _TestLinuxPlatformCollector, # YES
        ]
    for x in range(3):
        test_collector_classes.append(_TestGenericFactCollector)


# Generated at 2022-06-22 22:43:44.001186
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    _collector_classes = collector.__dict__.values()

    _all_fact_subsets = defaultdict(list)
    for _collector_class in _collector_classes:
        _all_fact_subsets[_collector_class.name].append(_collector_class)
        for _fact_id in _collector_class._fact_ids:
            _all_fact_subsets[_fact_id].append(_collector_class)

    # there should be no unresolved requires at all
    assert find_unresolved_requires(set(_all_fact_subsets), _all_fact_subsets) == set()
    # only 'base' requires 'all' and 'min' (which are not resolvable by name)

# Generated at 2022-06-22 22:43:45.404582
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    a = BaseFactCollector()
    assert a.collect_with_namespace() == {}


# Generated at 2022-06-22 22:43:54.756538
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import sys
    class CollectorClass1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['fact1', 'fact2'])
    class CollectorClass2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['fact2', 'fact3'])
    class CollectorClass3(BaseFactCollector):
        name = 'collector3'
        required_facts = set([])
    class CollectorClass4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['fact2'])


# Generated at 2022-06-22 22:44:02.057807
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Unit test. Should return True.'''
    import os
    import sys

    from ansible.module_utils.facts import collectors as collector_modules
    from ansible.module_utils.facts import utils

    collector_classes_all_names = set(x for x in dir(collector_modules) if x.endswith('Collector'))
    collector_classes_all = set()
    for collector_class_name in collector_classes_all_names:
        collector_class = getattr(collector_modules, collector_class_name)
        collector_classes_all.add(collector_class)

    all_collectors_for_platform = find_collectors_for_platform(collector_classes_all, [utils.get_platform()])

    fact_id_to_collector_map, aliases_map = build

# Generated at 2022-06-22 22:44:13.834208
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import platform
    from ansible.module_utils.facts.collector.select import build_fact_id_to_collector_map
    from ansible.module_utils.facts.collector.filesystems import FileSystemCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.default import DefaultCollector

    platform_info = dict(system='Linux')

    # find list of collectors applicable to the platform
    collectors = find_collectors_for_platform([DefaultCollector,
                                               SystemCollector, FileSystemCollector],
                                              compat_platforms=[platform_info])


# Generated at 2022-06-22 22:44:23.383100
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector

    # Mock up a valid set of collectors
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['collector1'].append(BaseCollector)
    all_fact_subsets['collector1'].append(BaseCollector)
    all_fact_subsets['collector2'].append(BaseCollector)

    # select_collector_classes should combine duplicates and return in a sorted order
    assert select_collector_classes(['collector1', 'collector1', 'collector2'], all_fact_subsets) == [BaseCollector, BaseCollector, BaseCollector]

    # select_collector_classes should not fail on empty sets
    assert select_collector_classes([], all_fact_subsets) == []




# Generated at 2022-06-22 22:44:23.988668
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    pass

# Generated at 2022-06-22 22:44:25.765548
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector = CollectorNotFoundError('test')
    assert 'test' in collector.args[0]



# Generated at 2022-06-22 22:44:27.903204
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    Method = BaseFactCollector.collect_with_namespace
    collector = BaseFactCollector()
    assert Method(collector) == {}


# Generated at 2022-06-22 22:44:38.073879
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import namespace_class
    from ansible.module_utils.facts.namespace import Prefix
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virt_type import VirtTypeCollector

    # Add some collectors
    collectors = [
        SystemCollector(),
        VirtTypeCollector()
    ]

    # No namespace
    ns_fc = BaseFactCollector(collectors=collectors)

    # Space to prefix
    ns_fc = BaseFactCollector(collectors=collectors, namespace=Prefix('ansible_'))

    # Cycle in collector

# Generated at 2022-06-22 22:44:45.455272
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    '''Unit test to make sure constructor of class UnresolvedFactDep behaves as expected'''
    # When called with no argument, will raise a TypeError
    try:
        raise UnresolvedFactDep()
    except TypeError:
        pass

    # When called with a single argument, will raise that argument
    try:
        raise UnresolvedFactDep('some_error')
    except ValueError as e:
        assert str(e) == 'some_error'


# Generated at 2022-06-22 22:44:52.477497
# Unit test for function get_collector_names

# Generated at 2022-06-22 22:44:54.336764
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('fact', 'dep')
    except UnresolvedFactDep as e:
        assert e.args[0] == 'fact'
        assert e.args[1] == 'dep'



# Generated at 2022-06-22 22:44:56.350200
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError("missing collector")
    assert str(err) == "missing collector"



# Generated at 2022-06-22 22:45:02.124013
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    all_fact_subsets = {
        'required': [object()],
        'unresolved': [object()],
        'missing': [object()]
    }
    assert set(('required', 'unresolved')), resolve_requires(set(('required', 'unresolved')), all_fact_subsets)
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(set(('required', 'missing')), all_fact_subsets)



# Generated at 2022-06-22 22:45:07.177173
# Unit test for function tsort
def test_tsort():
    # A->B->C->B
    dep_map = defaultdict(set)
    dep_map['A'].add('B')
    dep_map['B'].add('C')
    dep_map['C'].add('B')

    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        # expected
        pass



# Generated at 2022-06-22 22:45:08.410046
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    assert UnresolvedFactDep('test').args[0] == 'test'



# Generated at 2022-06-22 22:45:16.422607
# Unit test for function get_collector_names
def test_get_collector_names():
    # from ansible.module_utils.facts import get_collector_names

    valid_subsets = frozenset(['foo', 'bar', 'baz', 'qux'])
    minimal_gather_subset = frozenset(['bar'])

    def test_one(gather_subset, expected_results):
        assert get_collector_names(valid_subsets=valid_subsets,
                                   minimal_gather_subset=minimal_gather_subset,
                                   gather_subset=gather_subset) == expected_results

    test_one(['foo'], set(['foo']))
    test_one(['foo', 'bar'], set(['foo', 'bar']))

# Generated at 2022-06-22 22:45:27.423752
# Unit test for function build_dep_data
def test_build_dep_data():
    fake_collectors = {
        'A': object(),
        'B': object(),
        'C': object(),
        'D': object(),
        'E': object(),
        'F': object(),
        'G': object(),
        'H': object(),
        'I': object(),
        'J': object(),
        'K': object(),
        'L': object(),
        'M': object(),
        'N': object(),
        'O': object(),
        'P': object(),
    }

# Generated at 2022-06-22 22:45:31.815111
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['lspci']
    collector_classes = [LsPciFactCollector]
    all_fact_subsets = {'lspci': collector_classes}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert(dep_map == {'lspci': set(['dmidecode'])})


# Generated at 2022-06-22 22:45:43.830988
# Unit test for function resolve_requires
def test_resolve_requires():
    # pylint: disable=redefined-outer-name
    import pytest
    from types import SimpleNamespace

    import platform

    all_fact_subsets = dict(
        a=[SimpleNamespace(name='a', required_facts=set())],
        b=[SimpleNamespace(name='b', required_facts=set())],
        c=[SimpleNamespace(name='c', required_facts=set())],
    )

    def get_all_fact_subsets(**kwargs):
        return all_fact_subsets

    def platform_match_func(platform_info):
        if platform_info.get('system', None) == 'Linux':
            return SimpleNamespace(
                name='some_linux_platform',
                required_facts=set()
            )
        return None

    # 1. Test for all valid requires

# Generated at 2022-06-22 22:45:48.522540
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Mock instance of class BaseFactCollector, collect() is expected to return an empty dictionary
    # since the class has no implementation.
    from ansible.module_utils.facts import collector
    fact_collector = collector.BaseFactCollector()
    assert(fact_collector.collect(collected_facts={}) == {})
    assert(fact_collector.collect(collected_facts={'ansible_facts': {'os': {'name': 'Ubuntu'}}}) == {})


# Generated at 2022-06-22 22:45:54.365758
# Unit test for function build_dep_data
def test_build_dep_data():
    global collectTest
    global collectTest2
    all_fact_subsets = {'factTest' : [collectTest, collectTest2]}
    expected_deps = {'factTest': {'factTest2'}, 'factTest2': {'factTest'}}
    assert build_dep_data(('factTest', 'factTest2'), all_fact_subsets) == expected_deps



# Generated at 2022-06-22 22:45:58.506167
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Given
    unresolved_fact_dep = 'test_dep'

    # When
    error = UnresolvedFactDep(unresolved_fact_dep)

    # Then
    assert error.args[0] == '"{0}"'.format(unresolved_fact_dep)



# Generated at 2022-06-22 22:46:00.435856
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('afact')
    except CollectorNotFoundError as e:
        assert str(e) == 'Fact collector for `afact` not found'



# Generated at 2022-06-22 22:46:12.260303
# Unit test for function get_collector_names
def test_get_collector_names():
    class FakeNamespace(object):
        def __init__(self, prefix):
            self.prefix = prefix

        def transform(self, name):
            return self.prefix + '_' + name

    valid_subsets = frozenset(('all', 'hardware', 'devices', 'network', 'virtual'))
    aliases_map = defaultdict(set)

    aliases_map['hardware'].update(('devices', 'dmi'))
    aliases_map['network'].update(('interfaces', 'ipv4_addresses', 'ipv6_addresses'))

    minimal_gather_subset = frozenset(('all', 'virtual'))


# Generated at 2022-06-22 22:46:20.749346
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(set(), {}) == set()

    assert find_unresolved_requires(set(['a']), {}) == set(['a'])

    assert find_unresolved_requires(
        set(['a', 'b']),
        {'a': [FakeCollector], 'b': [FakeCollector]}) == set()

    assert find_unresolved_requires(set(['a']),
                                    {'a': [FakeCollector.with_requires(set())]}) == set()

    assert find_unresolved_requires(set(['a']),
                                    {'a': [FakeCollector.with_requires(set(['a']))]}) == set()


# Generated at 2022-06-22 22:46:28.546281
# Unit test for function tsort
def test_tsort():
    dep_map = {'1': ['2'],
               '2': ['3', '4'],
               '3': ['4'],
               '4': ['5'],
               '5': []}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('5', []), ('4', ['5']), ('3', ['4']), ('2', ['3', '4']), ('1', ['2'])]

    dep_map = {'1': ['2'],
               '2': ['1']}
    try:
        tsort(dep_map)
        assert False
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-22 22:46:37.141725
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets_no_requires = {
        'required_fact_a': [object],
        'required_fact_b': [object],
        'required_fact_c': [object]
    }
    assert find_unresolved_requires([], all_fact_subsets_no_requires) == set()
    assert find_unresolved_requires(['required_fact_a'], all_fact_subsets_no_requires) == set()
    assert find_unresolved_requires(['required_fact_b'], all_fact_subsets_no_requires) == set()


# Generated at 2022-06-22 22:46:41.127262
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # type: () -> None
    try:
        raise UnresolvedFactDep('this is a test')
    except UnresolvedFactDep as e:
        assert e.args[0] == 'this is a test'



# Generated at 2022-06-22 22:46:49.585769
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''Test case to ensure that find_collectors_for_platform() returns
    the correct set of collector classes'''

    # All known collectors
    all_collector_classes = [
        FakeCollector1,
        FakeCollector2,
        FakeCollector3,
        FakeCollector4
    ]

    # Fake data for platform info
    platform_info = {
        'system': 'Linux',
        'os_family': 'Debian',
        'distribution': 'Ubuntu',
        'distribution_version': '14.04',
        'distribution_release': 'trusty',
    }

    # Expected result for Ubuntu 14.04
    expected_result = [FakeCollector1, FakeCollector4]

    result = find_collectors_for_platform(all_collector_classes, [platform_info])

# Generated at 2022-06-22 22:47:01.147724
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all'], 'min', 'os', ['dmi']) == {'dmi'}
    assert get_collector_names(['all'], 'min', 'os', ['dmi', '!hardware']) == {'dmi'}
    assert get_collector_names(['all'], 'min', 'os', ['!hardware']) == {'os'}
    assert get_collector_names(['all'], 'min', ['!all'], ['dmi'], 'os', ['dmi']) == {}
    assert get_collector_names(['all'], 'min', ['!all'], ['dmi', '!hardware'], 'os', ['dmi']) == {}

# Generated at 2022-06-22 22:47:12.019566
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespacePrefix
    from ansible.module_utils.facts.namespace import NamespaceSuffix

    # Test Namespace
    bfc = BaseFactCollector()
    assert bfc.collect_with_namespace() == {}

    bfc.namespace = NamespacePrefix("_")
    assert bfc.collect_with_namespace() == {}

    test_fact = {"some_fact": "value1"}
    assert bfc.collect_with_namespace(collected_facts=test_fact) == {"_some_fact": "value1"}

    bfc.namespace = None
    assert bfc.collect_with_namespace(collected_facts=test_fact) == test_fact

# Generated at 2022-06-22 22:47:14.330456
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert str(e) == "foo"



# Generated at 2022-06-22 22:47:26.623417
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(minimal_gather_subset=('all', 'min')) == frozenset(('all', 'min'))
    assert get_collector_names(minimal_gather_subset=('all', 'min'), gather_subset=('all')) == frozenset(('all', 'min'))
    assert get_collector_names(minimal_gather_subset=('all', 'min'), gather_subset=('all', 'min')) == frozenset(('all', 'min'))
    assert get_collector_names(minimal_gather_subset=('all', 'min'), gather_subset=('min')) == frozenset(('all', 'min'))

# Generated at 2022-06-22 22:47:39.749992
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.executor.collector.all import AllFactCollector
    from ansible.executor.collector.network import NetworkCollector
    from ansible.executor.collector.platform import PlatformCollector
    from ansible.executor.collector.virtual import VirtualCollector

    # add a fake platform collector for 'UnknownOS'
    class UnknownPlatformCollector(PlatformCollector):
        _platform = 'UnknownOS'
    all_collector_classes = [UnknownPlatformCollector, PlatformCollector, AllFactCollector, VirtualCollector, NetworkCollector]

    # NOTE: here we use the 'all' gather subset, but it matches only
    # the name of the collector, not the "primary name" of the collector
    # ie, AllFactCollector.name == all

# Generated at 2022-06-22 22:47:51.151532
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class MyFactCollector(BaseFactCollector):
        name = 'myfactcollector'
        @classmethod
        def platform_match(cls, platform_info):
            return BaseFactCollector.platform_match(platform_info)
        def collect(self, module=None, collected_facts=None):
            facts_dict = {'test':'testing'}
            return facts_dict

    class MyNamespace(object):
        def transform(self, key_name):
            return 'my.namespace.%s' % key_name

    result = MyFactCollector(namespace=MyNamespace()).collect_with_namespace()
    assert result == {'my.namespace.test':'testing'}


# Generated at 2022-06-22 22:47:53.721883
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('Test')
    except UnresolvedFactDep:
        pass
    # else:
    #     assert False


# Generated at 2022-06-22 22:47:57.347511
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import network

    all_fact_names = {'network': [network.NetworkFactCollector]}

    collector_names = ['network']
    result = select_collector_classes(collector_names, all_fact_names)
    assert result == [network.NetworkFactCollector]



# Generated at 2022-06-22 22:47:58.457352
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    b = BaseFactCollector()
    assert b


# Generated at 2022-06-22 22:48:11.221113
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class PC1(BaseFactCollector):
        name = 'PC1'
        required_facts = set(('qwer',))

    class PC2(BaseFactCollector):
        name = 'PC2'
        required_facts = set(('qwer', 'asdf'))

    class PC3(BaseFactCollector):
        name = 'PC3'
        required_facts = set()

    all_fact_subsets = {
        # PC1
        'PC2': [
            PC2,
        ],
        # PC2
        'PC3': [
            PC3,
        ],
    }
    # Expected result

# Generated at 2022-06-22 22:48:24.103768
# Unit test for function tsort
def test_tsort():
    '''
    Test tsort works as expected
    '''
    # no cyclic deps
    assert tsort({'a': [], 'b': [], 'c': []}) == [('a', []), ('b', []), ('c', [])]
    # a single level of dep
    assert tsort({'a': ['b'], 'b': []}) == [('b', []), ('a', ['b'])]
    # a single level of dep (but backwards)
    assert tsort({'a': [], 'b': ['a']}) == [('a', []), ('b', ['a'])]
    # multiple levels of dep

# Generated at 2022-06-22 22:48:28.682614
# Unit test for function resolve_requires
def test_resolve_requires():
    assert( not resolve_requires(set(['a']), {}) )
    assert(resolve_requires(set(['a']), {'a': True}) == set(['a']))
    assert(resolve_requires(set(['a', 'b']), {'a': True}) == set(['a']))



# Generated at 2022-06-22 22:48:30.536513
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    facts = UnresolvedFactDep('test message')
    assert str(facts) == 'test message'



# Generated at 2022-06-22 22:48:33.700166
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    m = 'This is the message'
    e = UnresolvedFactDep(m)
    assert m in str(e)



# Generated at 2022-06-22 22:48:44.915905
# Unit test for function get_collector_names
def test_get_collector_names():
    minimal_subset = frozenset(['min'])
    all_subset = frozenset(['all', 1, 2, 3])
    aliases_map = defaultdict(set)
    aliases_map['alias'] = set([1, 2])
    aliases_map['alias2'] = set([3])

    minimal_subset = frozenset(['min'])
    all_subset = frozenset(['all', 1, 2, 3])
    aliases_map = defaultdict(set)
    aliases_map['alias'] = set([1, 2])
    aliases_map['alias2'] = set([3])

    # test 'all'
    module_params = {'gather_subset': ['all']}

# Generated at 2022-06-22 22:48:48.210515
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps()
    assert str(e) == 'Collectors have a circular dependency on each other'



# Generated at 2022-06-22 22:48:59.153029
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['A'])
        required_facts = set(['A'])

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['B'])
        required_facts = set(['B'])

    class CollectorCD(BaseFactCollector):
        _fact_ids = set(['C', 'D'])
        required_facts = set(['C', 'D'])

    class CollectorEF(BaseFactCollector):
        _fact_ids = set(['E', 'F'])
        required_facts = set(['E', 'F'])

    class CollectorGH(BaseFactCollector):
        _fact_ids = set(['G', 'H'])
        required_facts = set(['G', 'H'])

   

# Generated at 2022-06-22 22:49:05.943682
# Unit test for function get_collector_names
def test_get_collector_names():
    # pylint: disable=protected-access,import-error
    assert BaseFactCollector._platform == 'Generic'
    collector_names = get_collector_names(
        valid_subsets=frozenset(('packaging', 'network', 'memory', 'filesystems')),
        gather_subset=['!filesystems'],
        aliases_map=defaultdict(set, {
            'hardware': frozenset((
                'devices',
                'dmi'
            ))
        }),
    )
    assert collector_names == frozenset(('packaging', 'network', 'memory'))



# Generated at 2022-06-22 22:49:16.746377
# Unit test for function tsort
def test_tsort():
    result = []
    result.append(tsort({
        'a': set(['b', 'c']),
        'b': set(['d', 'e']),
        'c': set(['f', 'g']),
        'd': set(['e']),
    }))
    result.append(tsort({
        'a': set(['b', 'c']),
        'b': set(['d', 'e']),
        'c': set(['f', 'g']),
        'd': set(['e', 'f']),
        'e': set(['f']),
    }))


# Generated at 2022-06-22 22:49:18.996062
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with timeout.Timer(0.01):
        try:
            raise CycleFoundInFactDeps()
        except CycleFoundInFactDeps as e:
            pass


# Generated at 2022-06-22 22:49:24.602180
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': [],
        'b': [],
        'c': [],
    }
    unresolved_requires = set(['a', 'b', 'c'])
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == set(['a', 'b', 'c'])

    all_fact_subsets = {
        'a': [],
        'b': [],
        'c': [],
    }
    unresolved_requires = set(['a', 'b', 'x'])
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved_requires, all_fact_subsets)



# Generated at 2022-06-22 22:49:25.957014
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test_collector_name')
    assert str(e) == "Collector named test_collector_name not found"



# Generated at 2022-06-22 22:49:35.300524
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector1(BaseFactCollector):
        _fact_ids = ['test1']
        name = 'test1'
    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test2']
        name = 'test2'
        required_facts = set(['test1'])
    class TestCollector3(BaseFactCollector):
        _fact_ids = ['test3']
        name = 'test3'
        required_facts = set(['test1'])
    class TestCollector4(BaseFactCollector):
        _fact_ids = ['test4']
        name = 'test4'
        required_facts = set(['test2', 'test3'])

    test_collectors = [TestCollector1, TestCollector2, TestCollector3, TestCollector4]



# Generated at 2022-06-22 22:49:38.080074
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo.bar')
    except CollectorNotFoundError as e:
        assert str(e) == 'Collector foo.bar not found'



# Generated at 2022-06-22 22:49:47.742047
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class FC1(BaseFactCollector):
        name = 'fc1'
        _fact_ids = {'fc1'}

    class FC2(BaseFactCollector):
        name = 'fc2'
        _fact_ids = {'fc2_1', 'fc2_2'}

    class FC3(BaseFactCollector):
        name = 'fc3'
        _fact_ids = set()

    class FC4(BaseFactCollector):
        name = 'fc4'
        _fact_ids = {'fc4_1', 'fc4_2'}

    class FC5(BaseFactCollector):
        name = 'fc5'
        _fact_ids = {'fc4_1', 'fc4_2'}

    fact_id_to_collector_map, aliases_map = build_fact

# Generated at 2022-06-22 22:49:58.430815
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # dummy collector class
    class Collector(BaseFactCollector):
        pass

    fact_subsets = {
        # collector name: list of collector classes
        'foo': [Collector()],
        'bar': [Collector()],
        'baz': [Collector()],
        'boo': [Collector()],
        'far': [Collector()],
    }

    assert sorted(select_collector_classes(['foo'], fact_subsets)) == [Collector()]
    assert sorted(select_collector_classes(['foo', 'foo'], fact_subsets)) == [Collector()]

    # add a dup for each collector name
    for collector_name in fact_subsets.keys():
        fact_subsets[collector_name] = fact_subsets[collector_name] * 2

   

# Generated at 2022-06-22 22:50:07.541842
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class FakeCollectorClass(BaseFactCollector):
        pass

    class FakeCollectorClass2(BaseFactCollector):
        name = 'fake_collector_class_2'

        _platform = 'Linux'

    result = find_collectors_for_platform(set(), [[{'system': 'Linux'}]])
    assert result == set()

    result = find_collectors_for_platform(set(), [{'system': 'Linux'}])
    assert result == set()

    all_collector_classes = {FakeCollectorClass, FakeCollectorClass2}

    result = find_collectors_for_platform(all_collector_classes, [[{'system': 'Linux'}]])
    assert result == all_collector_classes


# Generated at 2022-06-22 22:50:19.980338
# Unit test for function tsort

# Generated at 2022-06-22 22:50:23.493592
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    module_arguments = dict()
    collected_facts = dict()
    c = BaseFactCollector()
    result = c.collect(module_arguments, collected_facts)
    assert isinstance(result, dict)


# Generated at 2022-06-22 22:50:32.962995
# Unit test for function build_dep_data
def test_build_dep_data():
    class FakeFact():
        required_facts = set()
        def __init__(self, name):
            self.name = name
    d = dict()
    d["1"] = FakeFact("1")
    d["2"] = FakeFact("2")
    d["3"] = FakeFact("3")
    dep_map = build_dep_data(collector_names=["1","2","3","4"], all_fact_subsets=d)
    assert dep_map["1"] == set()
    assert dep_map["2"] == set()
    assert dep_map["3"] == set()
    d["4"] = FakeFact("4")
    dep_map = build_dep_data(collector_names=["1","2","3","4"], all_fact_subsets=d)

# Generated at 2022-06-22 22:50:44.787939
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():


    # we'll use this in the tests below
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['A'])
        name = 'a'
        required_facts = set(['a'])
        _platform = None

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['B'])
        name = 'b'
        required_facts = set(['b'])
        _platform = None

    class CollectorC(BaseFactCollector):
        _fact_ids = set(['C'])
        name = 'c'
        required_facts = set(['c'])
        _platform = None

    class CollectorX(BaseFactCollector):
        _fact_ids = set(['X'])
        name = 'x'

# Generated at 2022-06-22 22:50:47.495842
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    bundle = CollectorNotFoundError('test')
    assert bundle.args[0] == 'test'



# Generated at 2022-06-22 22:50:59.750730
# Unit test for function get_collector_names
def test_get_collector_names():
    # Check for invalid subset
    try:
        get_collector_names(
            valid_subsets=frozenset(['network', 'fibre_channel']),
            gather_subset=['!all', 'fibre_channel']
        )
        assert False
    except TypeError:
        pass

    # Check for exclude subset with an alias
    names = get_collector_names(
        valid_subsets=frozenset(['network', 'fibre_channel']),
        aliases_map=defaultdict(set, {'network': ['ethernet', 'bond', 'team']}),
        gather_subset=['!network', 'fibre_channel']
    )
    assert names == set(['fibre_channel'])

    # Check for exclude subset with an alias

# Generated at 2022-06-22 22:51:06.409358
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Declaring object for the class BaseFactCollector
    base_collector = BaseFactCollector()
    # Declaring a dictionary
    collected_facts = {}
    # Calling the method collect_with_namespace()
    x = base_collector.collect_with_namespace(None, collected_facts)
    # Assert the condition
    assert x == {}
test_BaseFactCollector_collect_with_namespace()



# Generated at 2022-06-22 22:51:14.674842
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements

    class TestCollector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = {'fact11', 'fact12'}
        required_facts = {'collector1'}

    class TestCollector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = {'fact21', 'fact22'}
        required_facts = {'collector2'}

    class TestCollector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = {'fact31', 'fact32'}

    class TestCollector4(BaseFactCollector):
        name = 'collector4'
        _fact_

# Generated at 2022-06-22 22:51:25.137567
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'all': [1, 2, 3],
        'network': [2],
        'hardware': [3]
    }

    unresolved = find_unresolved_requires(('network',), all_fact_subsets)
    assert not unresolved

    unresolved = find_unresolved_requires(('network', 'hardware'), all_fact_subsets)
    assert not unresolved

    unresolved = find_unresolved_requires(('network', 'hardware', 'all'), all_fact_subsets)
    assert not unresolved

    unresolved = find_unresolved_requires(('network', 'hardware', 'missing'), all_fact_subsets)
    assert unresolved == set(['missing'])


# Generated at 2022-06-22 22:51:27.229693
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    obj = CycleFoundInFactDeps("fizz", "buzz")
    assert isinstance(obj, CycleFoundInFactDeps)


# Generated at 2022-06-22 22:51:35.032944
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class A(BaseFactCollector):
        _fact_ids = frozenset(["a_1", "a_2"])

    class B(BaseFactCollector):
        _fact_ids = frozenset(["b_1", "b_2", "b_3"])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a_1'] = [A]
    all_fact_subsets['a_2'] = [A]
    all_fact_subsets['b_1'] = [B]
    all_fact_subsets['b_2'] = [B]
    all_fact_subsets['b_3'] = [B]
    all_fact_subsets['ABC'] = []


# Generated at 2022-06-22 22:51:42.529498
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes(['first'], {'first': ['a', 'b']}) == ['a', 'b']
    assert select_collector_classes(['first'], {'first': ['a', 'b', 'b'], 'third': ['c']}) == ['a', 'b', 'c']
    assert select_collector_classes(['first', 'third'], {'first': ['a', 'b', 'b'], 'third': ['c']}) == ['a', 'b', 'c']



# Generated at 2022-06-22 22:51:49.009697
# Unit test for function collector_classes_from_gather_subset

# Generated at 2022-06-22 22:51:56.838928
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.default import FacterCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector

    collectors_for_platform = [FacterCollector, HardwareCollector, NetworkCollector, PkgMgrCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert len(collectors_for_platform) == 4
    assert len(fact_id_to_collector_map) == 8
    assert len(aliases_map) == 4

   

# Generated at 2022-06-22 22:52:02.959035
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    uncaught_exception = UnresolvedFactDep('some message')
    assert str(uncaught_exception) == 'some message'
    caught_exception = None
    try:
        raise UnresolvedFactDep('some message')
    except UnresolvedFactDep as exception:
        caught_exception = exception
    assert str(caught_exception) == 'some message'



# Generated at 2022-06-22 22:52:11.092716
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # test class as a base
    class BaseFactCollectorTest(BaseFactCollector):
        pass

    # empty object
    test_instance = BaseFactCollectorTest()
    assert test_instance.collect() == {}

    # test a simple object
    test_instance = BaseFactCollectorTest(namespace=None)
    assert test_instance.collect() == {}
    assert test_instance.namespace is None

    # test object with namespace
    test_instance = BaseFactCollectorTest(namespace=BaseFactCollector)
    assert test_instance.collect() == {}
    assert test_instance.namespace == BaseFactCollector

    # test object with collectors
    test_instance = BaseFactCollectorTest(collectors=['test'])
    assert test_instance.collect() == {}

# Generated at 2022-06-22 22:52:15.496215
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestCollector(BaseFactCollector):
        pass
    assert TestCollector().collectors == []
    assert TestCollector.platform_match({}).__class__ == TestCollector
    # TODO: add other tests for BaseFactCollector

#******************************************************************************
#******************************************************************************


# Generated at 2022-06-22 22:52:20.477407
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = {'a', 'b', 'c'}
    all_fact_subsets = {
        'a': [Collector1(None)],
        'b': [Collector2(None)],
        'c': [Collector3(None)]
    }
    dep_data = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-22 22:52:32.461587
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'fact1'
        _fact_ids = frozenset(['fact1_a', 'fact1_b'])
    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'fact2'
        _fact_ids = frozenset(['fact2_a', 'fact2_b'])
        required_facts = frozenset(['fact1'])
    class Collector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'fact3'
        _fact_ids = frozenset(['fact3_a', 'fact3_b'])
        required_facts = frozenset(['fact2'])

# Generated at 2022-06-22 22:52:43.304373
# Unit test for function tsort

# Generated at 2022-06-22 22:52:53.993901
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    # create a mock Collectors set
    class TestCollector(BaseFactCollector):
        # a Collector class that will always match for platform_info
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollectorA(TestCollector):
        name = 'a'
        required_facts = set(['b'])
    class TestCollectorB(TestCollector):
        name = 'b'
        required_facts = set(['c'])
    class TestCollectorC(TestCollector):
        name = 'c'
        required_facts = set(['d'])
    class TestCollectorD(TestCollector):
        name = 'd'

# Generated at 2022-06-22 22:53:04.992056
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all'], ['min'], ['min', 'network'], {'network': ['devices']}) == set(['min', 'network', 'devices'])
    assert get_collector_names(['all'], ['min'], ['!all', 'min', '!network'], {'network': ['devices']}) == set(['min'])
    assert get_collector_names(['all', 'network'], ['min'], ['!all', 'min', '!network'], {'network': ['devices']}) == set(['min'])
    assert get_collector_names(['all', 'network'], ['min'], ['min', '!network', 'custom'], {'network': ['devices']}) == set(['min', 'custom'])



# Generated at 2022-06-22 22:53:13.003002
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'fact1': [TestCollector(['test']), TestCollector(['test1'])],
                        'fact2': [TestCollector(['test'])],
                        'fact3': [TestCollector(['test2'])]}

    expected_dep_map = {'fact1': {'fact2', 'fact3'},
                        'fact2': {'fact3'}}

    dep_map = build_dep_data(['fact1', 'fact2', 'fact3'], all_fact_subsets)
    assert(expected_dep_map == dep_map)



# Generated at 2022-06-22 22:53:16.626266
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    fc = BaseFactCollector()
    # test that using namespace works
    assert fc.collect_with_namespace() == {}

    # test that using namespace works with namespace=None
    fc.namespace = None
    assert fc.collect_with_namespace() == {}

