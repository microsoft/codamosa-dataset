

# Generated at 2022-06-20 16:57:16.356001
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    found_collectors = find_collectors_for_platform(
        [BaseFactCollector],
        compat_platforms=[{'system': 'Generic'}]
    )
    assert len(found_collectors) == 1
    assert BaseFactCollector in found_collectors

    found_collectors = find_collectors_for_platform(
        [BaseFactCollector],
        compat_platforms=[{'system': 'FreeBSD'}]
    )
    assert len(found_collectors) == 0



# Generated at 2022-06-20 16:57:20.473868
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    the_error = CollectorNotFoundError('the message')
    assert the_error.args[0] == 'the message'



# Generated at 2022-06-20 16:57:30.585235
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestCollectorBase(BaseFactCollector):
        name = 'base'
        required_facts = set()

    class TestCollectorA(TestCollectorBase):
        _fact_ids = ['testa']

    class TestCollectorB(TestCollectorBase):
        _fact_ids = ['testb']

    class TestCollectorC(TestCollectorBase):
        _fact_ids = ['testa', 'testc']

    class TestCollectorD(TestCollectorBase):
        _fact_ids = ['testd']
        required_facts = set(['testa'])

    class TestCollectorE(TestCollectorBase):
        _fact_ids = ['teste']
        required_facts = set(['testb'])


# Generated at 2022-06-20 16:57:35.685429
# Unit test for function get_collector_names
def test_get_collector_names():
    # gather_subset_with_min = ['min']
    # gather_subset_with_min.extend(gather_subset)
    # for subset in gather_subset_with_min:
    valid_subsets = frozenset()
    minimal_gather_subset = frozenset()
    gather_subset = ['min', 'hardware']  # a list
    aliases_map = defaultdict(set)
    assert get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map) == set()


# Generated at 2022-06-20 16:57:40.119604
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    e = UnresolvedFactDep('test-fact-name', ['test-dep-name'])
    assert e.args == ('test-fact-name', ['test-dep-name'])


# Generated at 2022-06-20 16:57:44.151320
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test the function by providing 'all' and
    # ensure the result contains all collectors

    collector_classes = collector_classes_from_gather_subset(gather_subset=['all'])
    found_names = set()
    for collector_class in collector_classes:
        found_names.add(collector_class.name)

    expected_names = set()
    for collector_class in all_collector_classes:
        expected_names.add(collector_class.name)

    assert found_names.issuperset(expected_names)



# Generated at 2022-06-20 16:57:57.213702
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['A', 'B', 'C', 'D', 'E']
    all_fact_subsets = {
        'A': [_DepCollector(['B', 'C']), _DepCollector(['B', 'D'])],
        'B': [_DepCollector([])],
        'C': [_DepCollector(['E'])],
        'D': [_DepCollector([])],
        'E': [_DepCollector([])]
    }

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map['A'] == {'B', 'C', 'D', 'E'}
    assert dep_map['B'] == set()
    assert dep_map['C'] == {'E'}
    assert dep_

# Generated at 2022-06-20 16:58:10.945322
# Unit test for function get_collector_names
def test_get_collector_names():

    def test(gather_subset, expected_subsets):
        all_subsets = ['all', 'min', 'foo', 'bar', 'baz']
        minimal_subsets = ['min']
        aliases_map = {'bar': {'bar', 'baz'}, 'all': all_subsets}
        # gather_subset is always a list, but treat it as a string for this test
        # to make it easier on the caller
        subsets = get_collector_names(valid_subsets=frozenset(all_subsets),
                                      minimal_gather_subset=frozenset(minimal_subsets),
                                      gather_subset=gather_subset.split(','),
                                      aliases_map=aliases_map)

# Generated at 2022-06-20 16:58:23.086289
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    @classmethod
    def some_collector_class(cls, required_facts=set()):
        return type(str('some_collector_class'), (object,), {
            'required_facts': required_facts,
            'name': 'some_collector_class'
        })

    def test_find_unresolved_requires_with_params(param_collector_names, all_fact_subsets, param_unresolved):
        assert find_unresolved_requires(param_collector_names, all_fact_subsets) == param_unresolved

    data = []
    collector_name1 = 'some_collector_class'
    collector_name2 = 'some_collector_class_1'
    collector_name3 = 'some_collector_class_2'
   

# Generated at 2022-06-20 16:58:34.354116
# Unit test for function select_collector_classes
def test_select_collector_classes():
    good_collector_names = ['dmi', 'network']
    good_collector_classes = []
    for name in good_collector_names:
        class DummyCollector(BaseFactCollector):
            name = name
    good_collector_classes.append(DummyCollector)

    good_all_fact_subsets = {}
    good_all_fact_subsets['dmi'] = [DummyCollector]
    good_all_fact_subsets['network'] = [DummyCollector]

    selected = select_collector_classes(good_collector_names, good_all_fact_subsets)
    assert selected == good_collector_classes
    # One bad collector_name
    collector_names = ['good']
    collector_classes = []

# Generated at 2022-06-20 16:58:42.933357
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as err:
        assert err.args == tuple()
        assert str(err) == 'cycle found in fact deps'


# Generated at 2022-06-20 16:58:56.491850
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'A': ['A'], 'B': ['B'], 'C': ['C'], 'D': ['D'], 'E': ['E']}
    class A:
        required_facts = {'C'}
    all_fact_subsets['A'] = [A]

    class B:
        required_facts = {'C'}
    all_fact_subsets['B'] = [B]

    class C:
        required_facts = {'D'}
    all_fact_subsets['C'] = [C]

    class D:
        required_facts = {'E'}
    all_fact_subsets['D'] = [D]

    class E:
        required_facts = {'F'}
    all_fact_subsets['E'] = [E]

# Generated at 2022-06-20 16:59:01.445036
# Unit test for function collector_classes_from_gather_subset

# Generated at 2022-06-20 16:59:05.659004
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors == []
    assert fc.namespace is None
    assert not fc.fact_ids


# Syntactic sugar: allow passing a list of FactCollector classes to the FactCollector
# constructor to mean, 'instantiate all of these'.
FactCollectors = (BaseFactCollector,)



# Generated at 2022-06-20 16:59:09.879383
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    '''BaseFactCollector ctor should not require any args.
    '''
    c = BaseFactCollector()


# Generated at 2022-06-20 16:59:11.390485
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('Test')
    except UnresolvedFactDep as err:
        assert err.args[0] == 'Test'



# Generated at 2022-06-20 16:59:13.704492
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    error = CollectorNotFoundError('key')
    assert str(error) == 'key'



# Generated at 2022-06-20 16:59:17.322127
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    obj=BaseFactCollector()
    assert obj.collect_with_namespace()=={}
    

# Generated at 2022-06-20 16:59:28.899282
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Fake classes for testing

    class PackageCollector(BaseFactCollector):
        name = 'packaging'
        required_facts = set(['facter'])
        _platform = 'FreeBSD'

    class FacterCollector(BaseFactCollector):
        name = 'facter'

    class DMICollector(BaseFactCollector):
        name = 'dmi'

        required_facts = set(['facter'])

    class DMICollectorWindows(BaseFactCollector):
        name = 'dmi'
        _platform = 'Windows'

    class NetworkCollector(BaseFactCollector):
        name = 'network'

    class NetworkCollectorLinux(BaseFactCollector):
        name = 'network'
        _platform = 'Linux'

    class NetworkCollectorFreeBSD(BaseFactCollector):
        name

# Generated at 2022-06-20 16:59:40.498046
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import pytest

    class ClassA(BaseFactCollector):
        name = 'ClassA'
        required_facts = set(['foo'])

    class ClassB(BaseFactCollector):
        name = 'ClassB'
        required_facts = set(['ClassA'])

    class ClassC(BaseFactCollector):
        name = 'ClassC'
        required_facts = set(['ClassB'])

    class ClassD(BaseFactCollector):
        name = 'ClassD'
        required_facts = set(['ClassC'])

    class ClassE(BaseFactCollector):
        name = 'ClassE'
        required_facts = set(['ClassC'])

    class ClassF(BaseFactCollector):
        name = 'ClassF'
        required_facts = set(['ClassD', 'ClassE'])

# Generated at 2022-06-20 17:00:00.147604
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils.facts.cpu import CpuFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    # NOTE: these are only to test the function's logic with. We should not actually
    #       need to be importing these to test resolve_requires()
    from ansible.module_utils.facts.network import NetworkFactCollector
    from ansible.module_utils.facts.dmi import DmiFactCollector

    all_fact_subsets = {
        'virtual': [
            VirtualFactCollector
        ],
        'system': [
            SystemFactCollector
        ],
        'hardware': [
            DmiFactCollector,
        ],
    }

    # add the names of the actual collectors for

# Generated at 2022-06-20 17:00:05.808991
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    key_value = 'a'
    error_msg = 'test message'
    cnfe = CollectorNotFoundError(key_value, error_msg)
    assert cnfe.args[0] == key_value
    assert cnfe.message == error_msg



# Generated at 2022-06-20 17:00:11.187754
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert isinstance(BaseFactCollector(), BaseFactCollector)
    assert isinstance(BaseFactCollector().collect(), dict)
# end unit test

CollectorType = type


# Generated at 2022-06-20 17:00:19.955381
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import base_facts_test
    base_facts_test_path = 'ansible/module_utils/_text.py'
    base_facts_test_module = base_facts_test.__name__
    base_facts_test_name = base_facts_test.BaseFactsTest.__name__

    # These args are a subset of what is normally passed. It is
    # sufficient to test this function (see function header).
    args = [
        ['all'],
        base_facts_test.all_fact_subsets,
    ]
    test_func = (base_facts_test_name, base_facts_test_path, base_facts_test_module)

    # The contents of the file are:
    # class BaseFactsTest(BaseFactsCollector):
    #     name = 'base_facts_test'

# Generated at 2022-06-20 17:00:29.868614
# Unit test for function get_collector_names
def test_get_collector_names():

    aliases_map = defaultdict(set)

    aliases_map['hardware'] = {
        'ec2_metadata',
        'devices',
        'dmi',
        'system_profiler',
        'pkg_mgr',
        'python',
        'virtual'
    }

    # minimal_collector is always added
    minimal_collector = {
        'system',
        'virtual',
        'distribution',
        'linux_distribution'
    }

    valid_facts = {
        'system',
        'virtual',
        'distribution',
        'linux_distribution',
        'devices',
        'dmi',
        'system_profiler',
        'pkg_mgr',
        'python',
        'ec2_metadata'
    }


# Generated at 2022-06-20 17:00:38.767075
# Unit test for function tsort
def test_tsort():
    from nose.tools import assert_equal
    from itertools import permutations

    # A simple graph with no cycles
    adj_list = {
        "A": ["B", "C"],
        "B": ["D", "E", "C"],
        "C": ["F"],
        "D": [],
        "E": [],
        "F": []
    }

    assert_equal(tsort(adj_list), [
        ("D", []),
        ("E", []),
        ("F", []),
        ("C", ["F"]),
        ("B", ["D", "E", "C"]),
        ("A", ["B", "C"])
    ])


    # A graph that has a cycle

# Generated at 2022-06-20 17:00:44.558311
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    testcollector = BaseFactCollector()

    assert 'Generic' == testcollector._platform
    assert set() == testcollector.fact_ids
    assert [] == testcollector.collectors
    assert None == testcollector.namespace



# Generated at 2022-06-20 17:00:47.391675
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as exc:
        assert repr(exc) == 'CycleFoundInFactDeps()'
        assert repr(CycleFoundInFactDeps) == 'CycleFoundInFactDeps'



# Generated at 2022-06-20 17:00:58.219215
# Unit test for function tsort
def test_tsort():
    test_map = {
        'a': ['b', 'd'],
        'b': ['c'],
        'c': ['d'],
        'd': ['e'],
        'e': []
    }
    expected = [('e', []), ('d', ['e']), ('c', ['d']), ('b', ['c']), ('a', ['b', 'd'])]
    result = tsort(test_map)
    for i in range(len(result)):
        assert result[i] == expected[i]

    test_map = {
        'a': ['b', 'd', 'e'],
        'b': ['c'],
        'c': ['d'],
        'd': ['e'],
        'e': []
    }

# Generated at 2022-06-20 17:01:03.606224
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    assert build_dep_data(['platform'], {'platform': [PlatformFactCollector]}) == \
           {'platform': set()}



# Generated at 2022-06-20 17:01:21.490729
# Unit test for function build_dep_data
def test_build_dep_data():
    collectors = [
        mock.Mock(name='collectorA', required_facts=set()),
        mock.Mock(name='collectorB', required_facts=set(('collectorA',))),
        mock.Mock(name='collectorC', required_facts=set(('collectorB', 'collectorA')))
    ]
    all_fact_subsets = {
        'collectorA': set((collectors[0],)),
        'collectorB': set((collectors[1],)),
        'collectorC': set((collectors[2],))
    }
    collector_names = ('collectorC', 'collectorB', 'collectorA')
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-20 17:01:30.739383
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils.facts import collectors
    import ansible.module_utils.facts.collectors as facts_collectors
    import ansible.module_utils.facts.system as system_collectors
    import ansible.module_utils.facts.network as network_collectors
    collectors_for_platform = find_collectors_for_platform(collectors.all_collector_classes,
                                                           (platform.system(),))
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    linux_collector_names = set(fact_id_to_collector_map) - frozenset(['system', 'network'])

# Generated at 2022-06-20 17:01:40.278086
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
   from ansible.module_utils.facts import collector
   from ansible.module_utils.facts import default_collectors

   # test build_fact_id_to_collector_map
   collectors_for_platform = find_collectors_for_platform(default_collectors, [{'system': 'Darwin'}])
   fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
   # test if dict 'fact_id_to_collector_map' can get item 'test_test'
   #print(fact_id_to_collector_map.get('test_test', 1))
   assert fact_id_to_collector_map.get('test_test', 1) == 1

   # test dict 'fact_id_to

# Generated at 2022-06-20 17:01:45.648872
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''Unit test for CollectorNotFoundError'''
    try:
        raise CollectorNotFoundError('foobar')
    except CollectorNotFoundError:
        __tracebackhide__ = True
        assert True
    else:
        __tracebackhide__ = True
        assert False
    __tracebackhide__ = False



# Generated at 2022-06-20 17:01:58.468630
# Unit test for function get_collector_names

# Generated at 2022-06-20 17:02:07.056236
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_classes = [
        type(str('CollectorFoo'), (BaseFactCollector,), {'name': 'foo'}),
        type(str('CollectorBar'), (BaseFactCollector,), {'name': 'bar'})
    ]
    all_fact_subsets = defaultdict(list)
    for collector in collector_classes:
        all_fact_subsets[collector.name].append(collector)

    assert select_collector_classes(['foo'], all_fact_subsets) == [collector_classes[0]]
    assert select_collector_classes(['foo', 'bar'], all_fact_subsets) == collector_classes


# Generated at 2022-06-20 17:02:16.363284
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    def cycle_test(c, msg):
        try:
            raise CycleFoundInFactDeps(c)
        except CycleFoundInFactDeps as e:
            assert e.dep_cycle == c, msg

    cycle_test(['a', 'b'], 'no cycle')
    cycle_test(['a', 'b', 'a'], 'cycle')

    try:
        raise CycleFoundInFactDeps(None)
    except CycleFoundInFactDeps as e:
        assert e.dep_cycle == None, 'default cycle is None'


# Generated at 2022-06-20 17:02:22.040309
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fact_collector = BaseFactCollector()
    assert fact_collector
    assert fact_collector.name is None
    assert fact_collector.fact_ids == set()
    assert not fact_collector.collectors



# Generated at 2022-06-20 17:02:25.852969
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('collector_name')
    assert isinstance(e, KeyError)
    assert str(e).startswith("Collector 'collector_name' not found")



# Generated at 2022-06-20 17:02:32.972096
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestFacts(BaseFactCollector):
        name = 'testfacts'

        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            return facts_dict

    fact_collector = TestFacts()
    fact_collector.collect_with_namespace()


# Generated at 2022-06-20 17:03:23.103865
# Unit test for function get_collector_names
def test_get_collector_names():
    import pytest
    v_subsets = frozenset(('network', 'facter', 'system', 'hardware', 'virtual', 'min'))
    m_subsets = frozenset(('a', 'b', 'min'))
    aliases_map = defaultdict(set,
                              {'hardware': frozenset(('devices', 'dmi')),
                               'facter': frozenset(('facter'))})

    r = get_collector_names(v_subsets, m_subsets, ['!hardware'], aliases_map)
    assert r == set(['network', 'system', 'virtual', 'min', 'a', 'b'])

    r = get_collector_names(v_subsets, m_subsets, ['not_hardware'], aliases_map)

# Generated at 2022-06-20 17:03:30.517804
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts

# Generated at 2022-06-20 17:03:41.762346
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors.system import DistroCollector
    from ansible.module_utils.facts.collectors.test_utils import TestCollector
    from ansible.module_utils.facts.collectors.test_utils import TestAliasCollector
    from ansible.module_utils.facts.collectors.test_utils import TestNoAliasCollector

    all_for_platform = [DistroCollector, TestCollector, TestNoAliasCollector, TestAliasCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_for_platform)

    # Check length of dicts
    assert len(fact_id_to_collector_map) == len(all_for_platform) + len(TestAliasCollector._fact_ids)

# Generated at 2022-06-20 17:03:51.159894
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'default_subset': [BaseFactCollector()],
        'other_subset': [BaseFactCollector()],
    }
    assert resolve_requires(('default_subset',), all_fact_subsets) == {'default_subset'}

    unresolved = ('default_subset', 'other_subset')
    assert resolve_requires(unresolved, all_fact_subsets) == {'default_subset', 'other_subset'}

    # any unresolved raises UnresolvedFactDep error
    with pytest.raises(UnresolvedFactDep) as excinfo:
        resolve_requires(('not_there',), all_fact_subsets)
    assert 'unresolved fact dep not_there' == str(excinfo.value)

    # only unresolved raises Un

# Generated at 2022-06-20 17:03:57.096990
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector as facts_collector

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([facts_collector.Hardware])
    assert set(fact_id_to_collector_map.keys()) == set(['hardware','devices'])
    assert aliases_map['hardware'] == set(['devices'])



# Generated at 2022-06-20 17:04:09.732244
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class FC1(BaseFactCollector):
        name = 'FC1'
        _fact_ids = set(['foo', 'bar'])
        def collect(self, module=None, collected_facts=None):
            return {'foo': 3, 'bar': 'stuff'}

    class FC2(BaseFactCollector):
        name = 'FC2'
        _fact_ids = set(['baz', 'buzz'])
        def collect(self, module=None, collected_facts=None):
            return {'baz': 4, 'buzz': 'more stuff'}

    bc = BaseFactCollector([FC1(), FC2()], None)
    assert bc.fact_ids == set(['FC2', 'FC1', 'baz', 'buzz', 'foo', 'bar'])
    assert bc.collect()

# Generated at 2022-06-20 17:04:13.396067
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    import module_utils.facts
    exc = module_utils.facts.CycleFoundInFactDeps()
    assert isinstance(exc, Exception)



# Generated at 2022-06-20 17:04:23.325556
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class_names = ['a', 'b']

    class_name_to_class = {}

    for class_name in class_names:
        class_name_to_class[class_name] = MockCollector(class_name)

    actual = collector_classes_from_gather_subset(class_name_to_class.values(),
                                                  valid_subsets=frozenset(class_names),
                                                  minimal_gather_subset=frozenset(['a']),
                                                  gather_subset=['a', 'b'],
                                                  gather_timeout=60)

    assert actual == [class_name_to_class['a'], class_name_to_class['b']]


# Generated at 2022-06-20 17:04:31.584428
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    assert(BaseFactCollector.name is None)
    assert(BaseFactCollector._fact_ids == set())
    assert(BaseFactCollector.required_facts == set())
    assert(BaseFactCollector._platform == "Generic")
    assert(BaseFactCollector.platform_match(dict(system='Generic')) == BaseFactCollector)
    assert(BaseFactCollector.platform_match(dict()) is None)
    assert(BaseFactCollector.platform_match(dict(system='')) is None)
    assert(BaseFactCollector.platform_match(dict(system='NotGeneric')) is None)

    bfc = BaseFactCollector()
    assert(bfc.name is None)
    assert(bfc._fact_ids == set())
    assert(bfc.collectors == [])

# Generated at 2022-06-20 17:04:37.801294
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps(['foo', 'bar'])
    except CycleFoundInFactDeps as e:
        # Make sure the passed in names are set properly
        assert e.names == ['foo', 'bar']
        assert str(e) == "Cycle found in fact dependencies: ['foo', 'bar']"


# Generated at 2022-06-20 17:05:23.560049
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Unit test for function build_fact_id_to_collector_map

    The function maps the fact_ids to FactCollectors. Any of the aliases in the
    collector should be able to lookup the FactCollector.

    It is tested by having a dummy FactCollector with a few aliases. FactCollectors
    are identified by a name. The primary name is used for lookup as well as the aliases.
    '''
    class DummyFactCollector(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'primary'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([DummyFactCollector])


# Generated at 2022-06-20 17:05:31.903379
# Unit test for function resolve_requires
def test_resolve_requires():
    class TestCollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = set(['A'])

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['D'])
        _fact_ids = set(['B'])

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = set(['C'])

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids

# Generated at 2022-06-20 17:05:37.491584
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.collectors import command_lsb_release
    obj = BaseFactCollector()
    facts_dict = obj.collect()
    assert facts_dict == {}
    facts_dict = obj.collect(module=None)
    assert facts_dict == {}
    facts_dict = obj.collect(collected_facts=command_lsb_release.lsb_release)
    assert facts_dict == {}

# Generated at 2022-06-20 17:05:45.129762
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class a(BaseFactCollector):
        _fact_ids = ['a1']
        name = 'a'
    class b(BaseFactCollector):
        _fact_ids = ['b1']
        name = 'b'
    class c(BaseFactCollector):
        _fact_ids = ['c1', 'c2']
        name = 'c'
    class d(BaseFactCollector):
        _fact_ids = ['d1', 'd2']
        name = 'd'

    all_collector_classes = [a, b, c, d]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

    assert a in fact_id_to_collector_map['a']
    assert b in fact_

# Generated at 2022-06-20 17:05:55.008938
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    all_fact_subsets = defaultdict(list)
    all_fact_subsets[('collector',)] = ['collector']
    all_fact_subsets[('dep1',)] = ['dep1']
    all_fact_subsets[('dep2',)] = ['dep2']
    all_fact_subsets[('dep2', 'dep3')] = ['dep2', 'dep3']
    all_fact_subsets[('dep3',)] = ['dep3']
    all_fact_subsets[('dep3', 'dep4')] = ['dep3', 'dep4']
    all_fact_subsets[('dep1', 'dep2', 'dep3', 'collector')] = ['dep1', 'dep2', 'dep3', 'collector']

    # Test where unresolved requires are

# Generated at 2022-06-20 17:06:05.395887
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
    class C(BaseFactCollector):
        name = 'c'

    # create a dummy 'all_subsets' that has aliases for a
    all_subsets = defaultdict(list)
    all_subsets['a'].extend([A, B])
    all_subsets['b'].append(B)

    # names to select
    names = ['a', 'c']

    # select the ones we want
    selected = select_collector_classes(names, all_subsets)

    # we should only get A and C, as B is duplicated
    assert len(selected) == 2
    assert A in selected
    assert B not in selected
    assert C in selected



# Generated at 2022-06-20 17:06:09.672389
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with timeout(None):
        try:
            raise UnresolvedFactDep("test")
        except Exception as err:
            assert type(err) == UnresolvedFactDep



# Generated at 2022-06-20 17:06:18.532843
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = {'id_A1', 'id_A2'}
        name = 'a'
    class CollectorB(BaseFactCollector):
        _fact_ids = {'id_B1', 'id_B2'}
        name = 'b'

    platform_info = defaultdict(lambda: None, system='Linux')

    collectors = find_collectors_for_platform([CollectorA, CollectorB],
                                              [platform_info,
                                               defaultdict(lambda: None)])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)

    a_collector = list(fact_id_to_collector_map['a'])[0]

# Generated at 2022-06-20 17:06:28.123343
# Unit test for function select_collector_classes
def test_select_collector_classes():
    TestCollector1 = type('TestCollector1',
                          (BaseFactCollector,),
                          dict(name='test_collector_1',
                               _fact_ids=set()
                          ))
    TestCollector2 = type('TestCollector2',
                          (BaseFactCollector,),
                          dict(name='test_collector_2',
                               _fact_ids=set()
                          ))
    TestCollector3 = type('TestCollector3',
                          (BaseFactCollector,),
                          dict(name='test_collector_3',
                               _fact_ids=set()
                          ))


# Generated at 2022-06-20 17:06:32.276492
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('test')
    except UnresolvedFactDep as e:
        assert str(e) == 'test'
    else:
        raise Exception('UnresolvedFactDep failed for constructor')

