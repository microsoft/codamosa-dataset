

# Generated at 2022-06-20 16:57:11.358390
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from collections import defaultdict

    class Test1FactCollector(BaseFactCollector):
        name = 'test1'
        _fact_ids = frozenset(('test1',))

    class Test2FactCollector(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(('test2', 'alias2'))

    collectors_for_platform = [Test1FactCollector, Test2FactCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-20 16:57:17.467575
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    Test collector_classes_from_gather_subset
    '''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'

    all_collector_classes = [TestCollector]
    plat_info = ImmutableDict({'system': 'Linux', 'distribution': 'RedHat'})

# Generated at 2022-06-20 16:57:28.945000
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test no namespace
    fact_collector = BaseFactCollector(collectors=[])
    fact_collector.name = 'NoneName'
    assert fact_collector.collect_with_namespace() == {}

    # Test with namespace
    fact_collector = BaseFactCollector(collectors=[])
    fact_collector.name = 'NoneName'
    namespace_transform = lambda name: 'my_' + name
    fact_collector.namespace = type('', (), {'transform': namespace_transform})
    assert fact_collector.collect_with_namespace() == {'my_NoneName': {}}



# Generated at 2022-06-20 16:57:42.281306
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    BaseFactCollectorTest = type('BaseFactCollectorTest', (BaseFactCollector,), dict(name='TestCollector', required_facts=['test_info']))
    all_fact_subsets = {'test_info': [BaseFactCollectorTest]}
    collector_names = ['test_info']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'test_info': {'test_info'}}
    BaseFactCollectorTest = type('BaseFactCollectorTest', (BaseFactCollector,), dict(name='TestCollector', required_facts=['test_info', 'hardware']))
    BaseFactCollect

# Generated at 2022-06-20 16:57:48.670493
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector

    all_collectors = [collector.GenericDistributionCollector,
                      collector.GenericSystemCollector,
                      collector.HardwareCollector]

    all_fact_subsets = defaultdict(list)
    for collector in all_collectors:
        all_fact_subsets[collector.name].append(collector)
        for fact_id in collector._fact_ids:
            all_fact_subsets[fact_id].append(collector)

    assert select_collector_classes(['GenericDistributionCollector'], all_fact_subsets) == [collector.GenericDistributionCollector]

    assert select_collector_classes(['GenericSystemCollector'], all_fact_subsets) == [collector.GenericSystemCollector]

    assert select_collector_classes

# Generated at 2022-06-20 16:57:57.260287
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    dep_map['a'] = set(['b', 'c', 'd'])
    dep_map['b'] = set(['c'])
    dep_map['c'] = set(['d'])
    dep_map['d'] = set()
    assert build_dep_data(['a', 'b', 'c', 'd'], dep_map) == dep_map


# Generated at 2022-06-20 16:58:10.984567
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.linux import LinuxDmidecodeFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxDistributionFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxDistributionVersFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxHardwareFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxMountFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxNetworkFactCollector
    from ansible.module_utils.facts.collector.freebsd import FreeBsDDistributionFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

# Generated at 2022-06-20 16:58:19.000434
# Unit test for function tsort
def test_tsort():
    unsorted_map = {
        'a': {'c', 'd'},
        'b': {'d'},
        'c': {'d'},
        'd': set(),
    }
    sorted_map = tsort(unsorted_map)
    assert sorted_map == [
        ('d', set()),
        ('c', {'d'}),
        ('b', {'d'}),
        ('a', {'c', 'd'}),
    ]

    unsorted_map = {
        'a': {'b', 'c'},
        'b': {'c', 'd'},
        'c': {'d'},
        'd': {'e'},
        'e': set(),
    }
    sorted_map = tsort(unsorted_map)
   

# Generated at 2022-06-20 16:58:23.910729
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class HardwareCollector(BaseFactCollector):
        _fact_ids = set(['hardware', 'devices'])
        _platform = 'Generic'
        name = 'hardware'

    class FacterCollector(BaseFactCollector):
        _fact_ids = set(['facter', 'system'])
        _platform = 'Generic'
        name = 'facter'

    class OSCollector(BaseFactCollector):
        _fact_ids = set(['os', 'system'])
        _platform = 'Generic'
        name = 'os'

    class LinuxCollector(BaseFactCollector):
        _fact_ids = set(['linux'])
        _platform = 'Linux'
        required_facts = set(['facter'])
        name = 'linux'


# Generated at 2022-06-20 16:58:34.631112
# Unit test for function resolve_requires
def test_resolve_requires():
    # when there are no requires, we get an empty list
    unresolved_requires = set()
    all_fact_subsets = {}
    received_resolved_requires = resolve_requires(unresolved_requires, all_fact_subsets)
    assert not received_resolved_requires

    # unresolved_requires is updated with resolved_requires
    unresolved_requires = set(['test_requires'])
    all_fact_subsets = {'test_requires': ['test_require_class']}
    received_resolved_requires = resolve_requires(unresolved_requires, all_fact_subsets)
    assert set(['test_requires']) == received_resolved_requires
    assert set(['test_requires']) == unresolved_requires

    # unresolved_requires is updated with resolved_requires

# Generated at 2022-06-20 16:58:53.206648
# Unit test for function get_collector_names
def test_get_collector_names():

    valid_subsets = frozenset([
        'network',
        'hardware',
        'foo',
        'bar',
    ])

    minimal_gather_subset = frozenset(['network'])

    aliases_map = {
        'hardware': frozenset(['devices', 'dmi']),
        'min': frozenset(['network']),
    }

    class PlatformInfo:
        def __init__(self, platform, release):
            self.system = platform
            self.release = release

        def get(self, key, default=None):
            if key == 'system':
                return self.system
            if key == 'release':
                return self.release
            return default
    # SUCCESS CASES
    # 'all'

# Generated at 2022-06-20 16:59:05.398182
# Unit test for function get_collector_names
def test_get_collector_names():

    class FakeCollector(BaseFactCollector):
        name = 'myfake'
        _fact_ids = set(['myfake'])
    FakeCollector._platform = platform.system()

    assert 'myfake' in get_collector_names(valid_subsets=frozenset(['myfake']),
                                           aliases_map=defaultdict(set, {'hardware': frozenset(['myfake'])}))

    assert 'myfake' in get_collector_names(valid_subsets=frozenset(['myfake']),
                                           gather_subset=['hardware'],
                                           aliases_map=defaultdict(set, {'hardware': frozenset(['myfake'])}))


# Generated at 2022-06-20 16:59:17.641006
# Unit test for function tsort
def test_tsort():
    test_data = {}
    test_data[1] = set([3, 4])
    test_data[2] = set([3, 4])
    test_data[3] = set([4])
    test_data[4] = set([5])
    test_data[5] = set([])
    test_data[6] = set([7])

    expected = [(6, set([7])), (7, set()), (5, set()), (4, set([5])), (3, set([4])), (2, set([3, 4])), (1, set([3, 4]))]
    actual = tsort(test_data)

    assert actual == expected

    test_data[1] = set([3])
    test_data[2] = set([3])
    test_data[3]

# Generated at 2022-06-20 16:59:24.073706
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    collector = BaseFactCollector()
    module = {'ANSIBLE_FACTS': {'test1':'value1'}, 'ANSIBLE_MODULE_ARGS': {}}
    collected_facts = {}
    returned_value = collector.collect_with_namespace(module=module, collected_facts=collected_facts)
    return returned_value



# Generated at 2022-06-20 16:59:32.825330
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import pytest

    class TestCollector(BaseFactCollector):
        _fact_ids = frozenset()

        _platform = 'Linux'
        name = 'test1'
        required_facts = set()

    with pytest.raises(TypeError):
        collector_classes_from_gather_subset(all_collector_classes=[TestCollector],
                                             valid_subsets=frozenset(),
                                             gather_subset=['foo'])

    assert collector_classes_from_gather_subset(all_collector_classes=[TestCollector],
                                                valid_subsets=frozenset(),
                                                gather_subset=[]) == [TestCollector]

    # when told to gather all, we should always include the minimal gather, even if all is excluded
    assert collector_classes

# Generated at 2022-06-20 16:59:34.437089
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps("abc", "def")
    assert e.args[0] == 'abc'
    assert e.args[1] == 'def'



# Generated at 2022-06-20 16:59:47.376671
# Unit test for function resolve_requires
def test_resolve_requires():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ('test', 'test_alias')
        required_facts = ('test2', 'test_alias2')
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ('test2',)
        required_facts = ()

    all_fact_subsets = {
        'test': [TestCollector, ],
        'test2': [TestCollector2, ],
        'test_alias': [TestCollector, ],
        'test_alias2': [TestCollector, ],
    }

    new_names = resolve_requires(set(['test_alias', 'test_alias2', 'test']), all_fact_subsets)

# Generated at 2022-06-20 16:59:59.702897
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import unittest
    import sys
    import os.path
    import tempfile
    libdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    sys.path.insert(0, libdir)
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import facts as facts_module
    # Only supported on python 2.6 and higher
    if sys.hexversion < 0x2070000:
        raise unittest.SkipTest("Not supported on python 2.5 or less")

    # this is the default for ansible_facts['ansible_collector'].name
    class FakeCollector:
        name = 'fake'
        _fact_ids = ['fake1', 'fake2']
    all_

# Generated at 2022-06-20 17:00:05.329884
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # doesn't actually 'run' any fact collection, just does selection
    gather_subset = 'hardware'

    all_fact_subsets = dict(hardware=['devices', 'dmi'],
                            network=['interfaces', 'default_ipv4'],
                            virtual=['virtualization', 'lxc'],
                            ohai=['ohai'],
                            facter=['facter'],
                            all=['hardware', 'network', 'virtual', 'facter'],
                            )
    all_collector_classes = set()
    for subset in all_fact_subsets.values():
        all_collector_classes.update(subset)

    expected = frozenset(['devices', 'dmi'])

# Generated at 2022-06-20 17:00:18.595599
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'min', 'hardware']),
                               platform_info={}) == frozenset(['min'])
    assert get_collector_names(valid_subsets=frozenset(['all', 'min', 'hardware']),
                               gather_subset=['!all'],
                               platform_info={}) == frozenset(['min'])
    assert get_collector_names(valid_subsets=frozenset(['all', 'min', 'hardware']),
                               gather_subset=['!all', 'hardware'],
                               platform_info={}) == frozenset(['hardware'])

# Generated at 2022-06-20 17:00:44.932663
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest
    assert 1 == 1



# Generated at 2022-06-20 17:00:46.183009
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    cycle_found_in_fact_deps = CycleFoundInFactDeps('test')
    assert cycle_found_in_fact_deps.args == ('test',)


# Generated at 2022-06-20 17:00:48.686696
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_data = build_dep_data(['foo', 'bar'], {'foo':['a', 'b'], 'bar':['a']})
    assert 'foo' in dep_data['a']
    assert 'bar' in dep_data['a']
    assert 'foo' not in dep_data['foo']
    assert 'bar' not in dep_data['bar']



# Generated at 2022-06-20 17:00:51.078794
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert str(e) == 'foo'



# Generated at 2022-06-20 17:01:02.457174
# Unit test for function build_dep_data
def test_build_dep_data():
    # Dummy fact collector class
    class FactCollector_Test(BaseFactCollector):
        name = 'fact_collector_test'
        _fact_ids = ['id_test']

    # Dummy FactCollector instances
    collector_1 = FactCollector_Test()
    collector_2 = FactCollector_Test()
    collector_3 = FactCollector_Test()

    # Test collector lists
    # If a collector has a dependency,
    # it will be added to the list of dependent collectors of its dependency
    # Test 1: no dependency
    fact_subset = [collector_1, collector_2, collector_3]
    expected = {'id_test': set(),
                'fact_collector_test': set()}

# Generated at 2022-06-20 17:01:11.437338
# Unit test for function tsort

# Generated at 2022-06-20 17:01:20.066678
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # make a test 'FactSubsets' object, with just the classes we need
    test_subsets = defaultdict(list)
    class TestClass(BaseFactCollector):
        name = 'test_class'
        required_facts = frozenset(['required_fact'])

    test_subsets['test_class'].append(TestClass)

    # test basic case
    assert find_unresolved_requires(['test_class'], test_subsets) == set()

    # test unresolved case
    assert find_unresolved_requires([], test_subsets) == set(['required_fact'])

    # test case where multiple collectors reference the same required_fact
    class TestClass2(BaseFactCollector):
        name = 'test_class2'
        required_facts = frozenset(['required_fact'])



# Generated at 2022-06-20 17:01:28.233557
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # https://stackoverflow.com/questions/674304/python-differentiating-between-a-class-and-an-instance
    #
    # Making FactCollector have it's own metaclass let's a subclass compare
    # equal to the metaclass, which is what we need in order to test
    # find_collectors_for_platform().
    class FactCollectorType(type):
        '''Metaclass for FactCollector

        Sets some class members so that we can detect the class object
        in find_collectors_for_platform()
        '''
        pass
    class FactCollector(object):
        '''Base class for things that collect facts'''
        __metaclass__ = FactCollectorType

        _fact_ids = set()
        _platform = platform.system()
        name = None
        required

# Generated at 2022-06-20 17:01:36.650042
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['collector1', 'collector2', 'collector3']
    all_fact_subsets = {'collector1': ['class1', 'class2'],
                        'collector2': ['class1'],
                        'collector3': ['class2']}
    expected_collector_classes = ['class1', 'class2']
    collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert collector_classes == expected_collector_classes


# Generated at 2022-06-20 17:01:48.360360
# Unit test for function tsort
def test_tsort():
    assert tsort({'a': set(), 'b': set(['a']), 'c': set(['a']), 'd': set(['b', 'c']), 'e': set(['b', 'c']), 'f': set(['d', 'e'])}) == [
        ('a', set()),
        ('b', set(['a'])),
        ('c', set(['a'])),
        ('d', set(['b', 'c'])),
        ('e', set(['b', 'c'])),
        ('f', set(['d', 'e'])),
    ]


# Generated at 2022-06-20 17:02:04.268903
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('foo')
    assert str(e) == "'foo'"
    # test it works with Exception(object)
    e = CollectorNotFoundError(42)
    assert str(e) == "'42'"
    # just make sure it works with Exception()
    e = CollectorNotFoundError()
    assert str(e) == ''



# Generated at 2022-06-20 17:02:15.663608
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'foo': ['foo'],
        'bar': ['bar'],
        'biz': ['biz'],
    }
    unresolved_requires = ['foo', 'biz']
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert(new_names == set(['foo', 'biz']))
    unresolved_requires = ['foo', 'wiz']
    with pytest.raises(UnresolvedFactDep):
        resolve_requires(unresolved_requires, all_fact_subsets)



# Generated at 2022-06-20 17:02:28.645145
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = set(['foo','bar','baz'])
    mock_all_fact_subsets = defaultdict(list)
    mock_all_fact_subsets['foo'].append(MockFactCollector('foo',['bar']))
    mock_all_fact_subsets['bar'].append(MockFactCollector('bar',['baz']))
    mock_all_fact_subsets['baz'].append(MockFactCollector('baz',[]))
    dep_map = build_dep_data(collector_names,mock_all_fact_subsets)
    assert dep_map['foo'] == set(['bar'])
    assert dep_map['bar'] == set(['baz'])
    assert dep_map['baz'] == set([])


# Generated at 2022-06-20 17:02:39.516092
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'one': [_FakeClass('one', ['a', 'b']),
                _FakeClass('one', ['a', 'c'])],
        'two': [_FakeClass('two', ['b', 'c'])],
        'three': [_FakeClass('three', ['a'])],
        'four': [_FakeClass('four', ['b'])],
        'five': [_FakeClass('five', [])],
        'six': [_FakeClass('six', ['a', 'c'])],
    }
    # from pprint import pprint
    # pprint(all_fact_subsets)
    assert find_unresolved_requires(['one', 'two'], all_fact_subsets) == set()

# Generated at 2022-06-20 17:02:46.309485
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'base': []}
    unresolved_requires = ['base']
    assert resolve_requires(unresolved_requires, all_fact_subsets) == {'base'}

    all_fact_subsets = {'base': []}
    unresolved_requires = ['BASE']
    assert resolve_requires(unresolved_requires, all_fact_subsets) == {'BASE'}

    all_fact_subsets = {'base': []}
    unresolved_requires = ['base_new']
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set()



# Generated at 2022-06-20 17:02:59.283918
# Unit test for function tsort
def test_tsort():
    # In this graph, 'c' is the first one pushed to the list, as it does not depend on any other node.
    # Then 'a' gets added, since 'b' is still unsorted.
    # We then try to add 'b' wich fails since it depends on 'c' which is not sorted.
    # When we reach the end of the list, control is given back to the loop and the next iteration
    # sees that 'c' is in the sorted list, so it can add 'b' to the list.
    # When there are no more nodes to add, the sorted list is returned.
    example_deps = {
        'c': set(),
        'a': {'c'},
        'b': {'c'}
    }


# Generated at 2022-06-20 17:03:11.119375
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': [], 'b': []}

    r = resolve_requires(['a'], all_fact_subsets)
    assert r == {'a'}

    r = resolve_requires(['a', 'b'], all_fact_subsets)
    assert r == {'a', 'b'}

    with pytest.raises(UnresolvedFactDep) as e:
        resolve_requires(['a', 'c'], all_fact_subsets)
    assert e.value.args == ('unresolved fact dep c',)

    with pytest.raises(UnresolvedFactDep) as e:
        resolve_requires(['c'], all_fact_subsets)
    assert e.value.args == ('unresolved fact dep c',)


# Generated at 2022-06-20 17:03:15.695710
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestClassFactCollector(BaseFactCollector):
        name = 'testClassFactCollector'
        _platform = 'Generic'

    coll = TestClassFactCollector()

    assert coll.collect_with_namespace() == {}



# Generated at 2022-06-20 17:03:23.990506
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = defaultdict(set)
    unres = ['blah', 'foo', 'bar']
    new = resolve_requires(unres, all_fact_subsets)
    assert not new
    assert unres == ['blah', 'foo', 'bar']

    all_fact_subsets['foo'] = set()
    new = resolve_requires(unres, all_fact_subsets)
    assert new == set(['foo'])
    assert unres == ['blah', 'bar']

    all_fact_subsets['bar'] = set()
    new = resolve_requires(unres, all_fact_subsets)
    assert new == set(['foo', 'bar'])
    assert unres == ['blah']

    all_fact_subsets['blah'] = set()

# Generated at 2022-06-20 17:03:31.238752
# Unit test for function select_collector_classes
def test_select_collector_classes():
    """Test that the correct collector classes are returned.

    The data structure returned by build_fact_id_to_collector_map represents
    a way to get the collector classes that match a fact id. To ensure that
    select_collector_classes returns the correct collector classes we can
    compare the two.
    """
    # Mock necessary data
    foo_class = type('foo_class', (object,), {})
    bar_class = type('bar_class', (object,), {})
    baz_class = type('baz_class', (object,), {})
    qux_class = type('qux_class', (object,), {})

    foo_class._fact_ids = {'bar', 'baz', 'qux'}
    bar_class._fact_ids = {'bar'}
    baz_class

# Generated at 2022-06-20 17:04:25.741628
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    from .platforms import Linux, Darwin

    # minimal needs for testing
    class CollectorA(BaseFactCollector):
        name = 'a'

        _platform = 'Darwin'
        required_facts = frozenset('b')

    class CollectorB(BaseFactCollector):
        name = 'b'

        _platform = 'Darwin'
        required_facts = frozenset(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'

        _platform = 'Darwin'
        required_facts = frozenset([])

    collectors = [CollectorA, CollectorB, CollectorC]

    all_fact_subsets = {}
    for collector in collectors:
        all_fact_subsets[collector.name] = [collector]


# Generated at 2022-06-20 17:04:32.973630
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bfc = BaseFactCollector()
    assert bfc.collectors == []
    assert bfc.fact_ids == set(['Generic'])
    assert bfc.namespace is None
    assert str(bfc) == '<BaseFactCollector:Generic>'
    assert repr(bfc) == '<BaseFactCollector:Generic>'
    assert bfc._transform_dict_keys({'x': 1}) == {'x': 1}
    bfc = BaseFactCollector(namespace='n')
    assert bfc._transform_dict_keys({'x': 1}) == {'n_x': 1}
    # TODO: test collect method



# Generated at 2022-06-20 17:04:42.173500
# Unit test for function build_dep_data
def test_build_dep_data():
    # Test no collector name
    collector_names = []
    all_fact_subsets = defaultdict(set)
    all_fact_subsets['test1'] = set([1,2,3])
    all_fact_subsets['test2'] = set([2,3,4])
    assert build_dep_data(collector_names, all_fact_subsets) == {}
    # Test empty fact_subsets
    collector_names = ['test1', 'test2']
    all_fact_subsets = defaultdict(set)
    assert build_dep_data(collector_names, all_fact_subsets) == {}
    # Test add collectors into dep_map
    collector_names = ['test1', 'test2']
    all_fact_subsets = defaultdict(set)

# Generated at 2022-06-20 17:04:44.432543
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test_CollectorNotFoundError')
    except CollectorNotFoundError as e:
        assert str(e) == 'test_CollectorNotFoundError'


# Generated at 2022-06-20 17:04:53.833890
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': ['a'],
        'b': ['b'],
        'c': ['c'],
        'ab': ['ab'],
        'bc': ['bc'],
        'abc': ['abc'],
    }

    #
    # Test where there are no unresolved facts
    #
    unresolved_requires = set()
    #
    # Test where a fact depends on only other facts
    #
    unresolved_requires = {'a'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == set(['a'])

    #
    # Test where a fact depends on another fact which depends on another
    #
    unresolved_requires = {'ab'}

# Generated at 2022-06-20 17:04:58.760252
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    error_msg = 'foo'
    try:
        raise CollectorNotFoundError(error_msg)
    except CollectorNotFoundError as e:
        assert isinstance(e, KeyError)
        assert str(e) == error_msg



# Generated at 2022-06-20 17:05:11.884424
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires'''

    import unittest

    class FakeCollect1(BaseFactCollector):
        name = 'fake_fact_collector_a'
        required_facts = ['another_fake_fact_collector']
    class FakeCollect2(BaseFactCollector):
        name = 'another_fake_fact_collector'

    all_fact_subsets = {'fake_fact_collector_a': [FakeCollect1,],
                        'another_fake_fact_collector': [FakeCollect2,]}

    class FindUnresolvedRequiresTestCase(unittest.TestCase):

        def test_find_unresolved_requires(self):
            collector_names = ['fake_fact_collector_a',]

# Generated at 2022-06-20 17:05:24.682960
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.cpu import CPU
    from ansible.module_utils.facts.collector.memory import Memory
    from ansible.module_utils.facts.collector.platform import Platform

    collector_names = ('cpu', 'platform')
    all_fact_subsets = {'cpu': [CPU], 'platform': [Platform]}

    expected_dep_map = {'cpu': {'platform'}, 'platform': set()}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == expected_dep_map

    collector_names = ('cpu', 'platform', 'memory')
    all_fact_subsets = {'cpu': [CPU], 'platform': [Platform], 'memory': [Memory]}


# Generated at 2022-06-20 17:05:35.238928
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['b', 'a', 'c']
    # all_fact_subsets[name] = [CollectorClass]
    all_fact_subsets = defaultdict(list)

    class CollectorA:
        name = 'a'
        required_facts = ['b']
    class CollectorB:
        name = 'b'
    class CollectorC:
        name = 'c'
        required_facts = ['b']
    class CollectorD:
        name = 'd'

    all_fact_subsets['a'].append(CollectorA)
    all_fact_subsets['b'].append(CollectorB)
    all_fact_subsets['c'].append(CollectorC)
    all_fact_subsets['d'].append(CollectorD)
    unresolved = find_unresolved_requires

# Generated at 2022-06-20 17:05:43.303047
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['uptime'])) == frozenset(['uptime'])
    assert get_collector_names(valid_subsets=frozenset(['uptime']), gather_subset=['uptime', 'uptime']) == frozenset(['uptime'])
    assert get_collector_names(valid_subsets=frozenset(['uptime', 'hostname']), gather_subset=['hostname']) == frozenset(['hostname'])
    assert get_collector_names(valid_subsets=frozenset(['uptime', 'hostname']), gather_subset=['hostname', '!uptime']) == frozenset(['hostname'])

# Generated at 2022-06-20 17:06:33.806245
# Unit test for function tsort
def test_tsort():
    # Test input
    dep_map = {
        'd1': set(['d2', 'd3']),
        'd2': set(['d3', 'd4']),
        'd3': set(['d4']),
        'd4': set([]),
    }
    # Expected output
    sorted_list = [
        ('d4', set([])),
        ('d3', set(['d4'])),
        ('d2', set(['d3', 'd4'])),
        ('d1', set(['d2', 'd3']))
    ]
    # Test tsort
    assert tsort(dep_map) == sorted_list


# For unit testing function build_dep_data

# Generated at 2022-06-20 17:06:45.736753
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Testing class structure and setup
    class collector(BaseFactCollector):
        _platform = 'Linux'
        name = 'test1'
        required_facts = set()

    class collector_generic(BaseFactCollector):
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'test3'
        required_facts = set()

    all_collector_classes = [collector, collector_generic, collector2]

    # Testing with invalid platform
    compat_platforms = ['Windows']
    assert find_collectors_for_platform(all_collector_classes, compat_platforms) == set()

    # Testing with valid platform
    compat_platforms = ['Linux']
    assert find_collect