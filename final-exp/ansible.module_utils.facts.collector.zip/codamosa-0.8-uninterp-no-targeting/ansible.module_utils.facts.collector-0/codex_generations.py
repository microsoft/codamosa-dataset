

# Generated at 2022-06-20 16:57:06.247008
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps('foo')
    assert err.args[0] == 'foo'



# Generated at 2022-06-20 16:57:18.503630
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Create a list of TestAnsibleCollectors
    test_collector_classes = [
        TestAnsibleFactCollector(name='debian', _platform='Linux'),
        TestAnsibleFactCollector(name='redhat', _platform='Linux'),
        TestAnsibleFactCollector(name='network', _platform='Linux'),
        TestAnsibleFactCollector(name='all', required_facts=frozenset(['debian', 'network'])),
    ]

    # All valid subsets
    valid_subsets = frozenset(['debian', 'redhat', 'network', 'all'])

    # Minimal gather subset
    minimal_gather_subset = frozenset(['debian'])

    # Tested gather subset
    test_gather_subset = ['redhat', 'network', '!min']

# Generated at 2022-06-20 16:57:22.680921
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class_1 = BaseFactCollector()
    class_1.name = 'class_1'

    class_2 = BaseFactCollector()
    class_2.name = 'class_2'

    class_3 = BaseFactCollector()
    class_3.name = 'class_3'

    class_4 = BaseFactCollector()
    class_4.name = 'class_4'

    class_5 = BaseFactCollector()
    class_5.name = 'class_5'

    class_1._fact_ids.add(class_1.name)
    class_2._fact_ids.add(class_2.name)
    class_3._fact_ids.add(class_3.name)
    class_3._fact_ids.add(class_3.name + '_2')
    class_

# Generated at 2022-06-20 16:57:27.068481
# Unit test for function tsort

# Generated at 2022-06-20 16:57:40.579009
# Unit test for function get_collector_names
def test_get_collector_names():
    # create aliases_map with just one entry
    aliases_map_hardware = defaultdict(set)
    aliases_map_hardware['hardware'].update(['devices', 'dmi'])

    # create aliases_map with more entries
    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi'])
    aliases_map['network'].update(['interfaces', 'interfaces_ipv4', 'interfaces_ipv6'])
    aliases_map['packages'].update(['pkg_mgr'])

    # create poatform_info - os_family=None, system=None
    platform_info = {'system': 'None', 'os_family': 'None'}

    # create valid_subsets with all valid subsets
    valid_subsets = fro

# Generated at 2022-06-20 16:57:43.020701
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    c = BaseFactCollector()
    assert isinstance(c.collect(), dict)
    assert isinstance((c.collect(collected_facts=dict())), dict)



# Generated at 2022-06-20 16:57:48.386303
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest

    all_fact_subsets = {
        'm1': [BaseFactCollector],
        'm2': [BaseFactCollector],
    }
    all_fact_subsets['m1'][0].required_facts = ['m2']
    unresolved_requires = find_unresolved_requires(['m1'], all_fact_subsets)
    new_requires = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_requires == set(['m2'])

    with pytest.raises(UnresolvedFactDep):
        assert resolve_requires(['m3'], all_fact_subsets)



# Generated at 2022-06-20 16:58:00.420473
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset='all', minimal_gather_subset='min',
                               valid_subsets=frozenset(('all', 'min', 'fruits')),
                               aliases_map={'fruit': ['apples', 'oranges']}) == frozenset(('all', 'min', 'fruits'))

    assert get_collector_names(gather_subset='!all', minimal_gather_subset='min',
                               valid_subsets=frozenset(('all', 'min', 'fruits')),
                               aliases_map={'fruit': ['apples', 'oranges']}) == frozenset(('min'))


# Generated at 2022-06-20 16:58:04.179085
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    b = BaseFactCollector()
    assert b.collect() == {}



# Generated at 2022-06-20 16:58:12.177374
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Using a fake dictionary
    all_fact_subsets = {'a':[1], 'b':[2], 'c':[3], 'd':[4]}

    _get_requires_by_collector_name = lambda collector_name: all_fact_subsets[collector_name]

    collector_names = ['a', 'b']
    assert(find_unresolved_requires(collector_names, all_fact_subsets) == set([]))

    collector_names = ['a', 'c']
    assert(find_unresolved_requires(collector_names, all_fact_subsets) == set(['c']))



# Generated at 2022-06-20 16:58:23.180487
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # creates a test class to be used in the test
    class TestClass(BaseFactCollector):
        key = 'value'
        fact_ids = set()
    # create a test instance
    test = TestClass()
    # gets a dictionary from the instance
    dictionary = test.collect_with_namespace()
    assert dictionary == {}, "expected empty dictionary"



# Generated at 2022-06-20 16:58:34.382331
# Unit test for function get_collector_names
def test_get_collector_names():
    # test all cases of gathering defaults:
    # 1. gather_subset='all'
    # 2. gather_subset=[], which normally returns all
    # 3. gather_subset='!all', which normally returns nothing

    # test case 1
    subset_spec = ['all']
    names_to_gather = get_collector_names(gather_subset=subset_spec)
    assert set(['all']) == names_to_gather

    # test case 2
    subset_spec = []
    names_to_gather = get_collector_names(gather_subset=subset_spec)
    assert set(['all']) == names_to_gather

    # test case 3
    subset_spec = ['!all']

# Generated at 2022-06-20 16:58:45.710637
# Unit test for function find_unresolved_requires

# Generated at 2022-06-20 16:58:49.452692
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class A(BaseFactCollector):
        name = "a"
        _platform = "A"

    class B(BaseFactCollector):
        name = "b"
        _platform = "B"

    assert find_collectors_for_platform([A, B], [{'system': 'B'}]) == {B}


# Generated at 2022-06-20 16:58:50.857441
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    facts = UnresolvedFactDep('name', 'dep')
    assert facts.name == 'name'
    assert facts.dep == 'dep'



# Generated at 2022-06-20 16:58:53.732371
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError('foo')
    assert err.args[0] == 'foo'



# Generated at 2022-06-20 16:59:05.689792
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import timeout
    import json

    module = AnsibleModule(
        argument_spec=dict(),
    )

    with open('../tests/testdata/ansible_facts.json') as f:
        ansible_facts = json.load(f)

    collected_facts = ansible_facts['ansible_facts']

    fact = BaseFactCollector()

    # Ignore this exception
    try:
        fact.collect(module=module, collected_facts=collected_facts)
    except Exception:
        pass

    # Ignore this exception

# Generated at 2022-06-20 16:59:11.003859
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    """
    Test UnresolvedFactDep constructor
    """
    fact_name = "test"
    err = UnresolvedFactDep(fact_name)
    assert fact_name == err.fact_name



# Generated at 2022-06-20 16:59:19.247356
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Mock a Hashtable for use in this test
    class MockHashtable:
        def __init__(self):
            self.unresolved_requires_result = None
        def unset(self, key):
            pass
        def set(self, key, value):
            self.unresolved_requires_result = value
    # Mock a Collector class for use in this test
    class MockCollector:
        def __init__(self):
            self.required_facts = set()

    # Test collect method
    collectors = [MockCollector(), MockCollector()]
    collectors[0].required_facts = set(['a'])
    collectors[1].required_facts = set(['b'])
    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-20 16:59:26.145508
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class FakeCollector(BaseFactCollector):
        name = 'fake_collector'
        def collect(self, module=None, collected_facts=None):
            return {'fake_collector_fact': 'fake'}

    fc = FakeCollector()
    assert fc.name in fc.collect_with_namespace()


# Generated at 2022-06-20 16:59:39.140692
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test')
    assert e.args[0] == 'test'

try:
    from ansible.module_utils.facts.collector.kernel import KernelFactCollector
    HAS_KERNEL_COLLECTOR = True
except ImportError:
    HAS_KERNEL_COLLECTOR = False

if HAS_KERNEL_COLLECTOR:
    @timeout(0.5, "collector module loading took too long")
    def __require_collector(name):
        '''Ensure that collector exists'''

        if name == 'kernel':
            if not HAS_KERNEL_COLLECTOR:
                raise ImportError("Fact collector %s was requested and was not found" % name)


# Generated at 2022-06-20 16:59:48.564103
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # given
    class FakeClassOne:
        _fact_ids = set()

        _platform = 'Linux'
        name = 'fake_class_one'
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            self.collectors = collectors or []
            self.namespace = namespace

            self.fact_ids = set([self.name])
            self.fact_ids.update(self._fact_ids)

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    class FakeClassTwo:
        _fact_ids = set()

        _platform = 'Linux'
        name = 'fake_class_two'

# Generated at 2022-06-20 16:59:59.965675
# Unit test for function tsort
def test_tsort():
    # cycle:
    assert_raises(CycleFoundInFactDeps, tsort, {'b': {'a'}, 'a': {'b'}})

    # simple:
    assert tsort({'b': set(), 'a': {'b'}}) == [('b', set()), ('a', {'b'})]

    # more complex:
    assert tsort({'b': set(), 'a': {'b'}, 'c': {'a', 'b'}}) == [('b', set()), ('a', {'b'}), ('c', {'a', 'b'})]

# Generated at 2022-06-20 17:00:10.599986
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # Make a simple dummy collector derived from BaseFactCollector
    class MyCollector(BaseFactCollector):
        name = 'my_collector'
        platform = 'not_really_a_platform'
        required_facts = []
        def collect(self, module=None, collected_facts=None):
            return {'a': 1, 'b': 2}

    # Create a collector without an namespace.
    my_collector = MyCollector()
    assert my_collector, "MyCollector was not successfully created."

    # Create a collector that has a namespace.
    class MyNamespace:
        def transform(self, name):
            return 'my_namespace.' + name

    my_namespace = MyNamespace()
    my_collector_with_namespace = MyCollector(namespace=my_namespace)
   

# Generated at 2022-06-20 17:00:12.515685
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    f = BaseFactCollector()
    assert f.collect_with_namespace() == {}


# Generated at 2022-06-20 17:00:20.798917
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest

    class TestBaseFactCollector(BaseFactCollector):
        name = '__testBaseFactCollector'
        _platform = '__testBaseFactCollectorOS'
        def collect(self, module=None, collected_facts=None):
            return {
                'a': 1,
                'b': 2,
            }

    class TestNamespace:
        def transform(self, name):
            return 'test-' + name

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

    class FakeCollectors(object):
        def __init__(self):
            self.collectors = []

    class TestBaseFactCollectorTestCase(unittest.TestCase):
        def test_no_namespace(self):
            tc

# Generated at 2022-06-20 17:00:23.271635
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    f = BaseFactCollector()
    res = getattr(f, 'name', None)
    assert res is None


# Generated at 2022-06-20 17:00:25.994438
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('foo')
    except UnresolvedFactDep as e:
        assert str(e) == 'foo'



# Generated at 2022-06-20 17:00:36.155007
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.cmd import CmdFactCollector
    from ansible.module_utils.facts.collector.file import FileFactCollector

    cmd_test_fact_subsets = {'cmd': [CmdFactCollector]}
    file_test_fact_subsets = {'file': [FileFactCollector]}

    collector_names = ['cmd']
    all_fact_subsets = {}
    all_fact_subsets.update(cmd_test_fact_subsets)
    all_fact_subsets.update(file_test_fact_subsets)
    assert select_collector_classes(collector_names, all_fact_subsets)[0] == CmdFactCollector

    collector_names = ['cmd', 'file']
    all_fact_subsets = {}
    all_

# Generated at 2022-06-20 17:00:40.386158
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('an_error')
    except UnresolvedFactDep as err:
        assert isinstance(err, ValueError)



# Generated at 2022-06-20 17:00:51.910565
# Unit test for function resolve_requires
def test_resolve_requires():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = ['dep1', 'dep2']

    class DepCollector(BaseFactCollector):
        name = 'dep1'
        required_facts = ['dep2']

    class Dep2Collector(BaseFactCollector):
        name = 'dep2'
        required_facts = []

    class BadCollector(BaseFactCollector):
        name = 'bad_dep'
        required_facts = ['missing']

    all_fact_subsets = {
        'test': [TestCollector],
        'dep1': [DepCollector],
        'dep2': [Dep2Collector],
        'bad_dep': [BadCollector]
    }


# Generated at 2022-06-20 17:00:54.934337
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    message = 'test1'
    fdep = UnresolvedFactDep(message)
    assert message == str(fdep)



# Generated at 2022-06-20 17:00:56.434496
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('TEST_COLLECTOR')


# Generated at 2022-06-20 17:01:00.681373
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('bar')
    except UnresolvedFactDep as e:
        assert str(e) == 'bar'



# Generated at 2022-06-20 17:01:09.643001
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    class FactA(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b'])
        name = 'a'

    class FactB(BaseFactCollector):
        _fact_ids = frozenset(['b', 'c'])
        name = 'b'

    class FactC(BaseFactCollector):
        _fact_ids = frozenset(['c'])
        name = 'c'

    class FactD(BaseFactCollector):
        _fact_ids = frozenset(['d'])
        name = 'd'
        required_facts = frozenset(['c'])

    class FactE(BaseFactCollector):
        _fact_ids = frozenset(['e'])


# Generated at 2022-06-20 17:01:13.811087
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires({'a'}, {'a': '1'}) == {'a'}
    assert resolve_requires({'a'}, {'b': '1'}) == set()



# Generated at 2022-06-20 17:01:25.655928
# Unit test for function tsort

# Generated at 2022-06-20 17:01:38.038383
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': {'b'},
        'b': {'c'},
        'c': {'d'},
        'd': {'e'},
        'e': {'f'},
        'f': {'g'},
        'g': {'h'},
        'h': {'i'},
        'i': {'j'},
        'j': {'k'},
        'k': {'l'},
        'l': {'m'},
        'm': set(),
    }
    result = tsort(dep_map)

# Generated at 2022-06-20 17:01:40.140116
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # test class instantiation
    CycleFoundInFactDeps()


# Generated at 2022-06-20 17:01:43.379968
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    test_exception = CycleFoundInFactDeps('error_msg')
    assert test_exception.args[0] == 'error_msg'


# Generated at 2022-06-20 17:01:59.333498
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    from ansible.module_utils._text import to_native
    # The following test code is for unit test for function find_collectors_for_platform(). Since
    # it is a private function, we need to construct the test case to make sure it works as expected.
    all_collector_classes = list(collectors.iter_collector_classes())
    platform_info = dict()
    platform_info['system'] = 'Linux'
    compat_platforms = list()
    compat_platforms.append(platform_info)
    # Test 1: try to find collectors that works on Linux system.
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    names = set()

# Generated at 2022-06-20 17:02:02.451826
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd1 = UnresolvedFactDep(['col.A', 'col.B'], 'col.C')
    assert ufd1.args[0] == ['col.A', 'col.B']
    assert ufd1.args[1] == 'col.C'
    assert str(ufd1) == ('fact collection "col.C" requires fact collectors '
                         '"col.A" and "col.B" which are not gathered')



# Generated at 2022-06-20 17:02:05.909035
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        x = CollectorNotFoundError('a', 'b')
        raise RuntimeError('Got invalid CollectorNotFoundError: {0}'.format(repr(x)))
    except TypeError:
        # We expect a TypeError if we've provided a message to the constructor
        pass



# Generated at 2022-06-20 17:02:18.123633
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import unittest

    class TestCollector1(BaseFactCollector):
        name = 'primary_name'
    class TestCollector2(BaseFactCollector):
        name = 'primary_name'
        _fact_ids = set(['fact_id'])
    class TestCollector3(BaseFactCollector):
        name = 'other_primary_name'
        _fact_ids = set(['fact_id'])

    test_collectors = [TestCollector1, TestCollector2, TestCollector3]

    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(test_collectors)

# Generated at 2022-06-20 17:02:22.350476
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    obj = UnresolvedFactDep('collector_id')
    assert 'collector_id' in obj.args
    assert 'UnresolvedFactDep' in str(obj)



# Generated at 2022-06-20 17:02:31.696781
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    col1 = FauxFactCollector(name='basic', required_facts=['min'])
    col2 = FauxFactCollector(name='with_dep', required_facts=['basic', 'min'])

    col3 = FauxFactCollector(name='with_dep_other', required_facts=['basic'])
    col4 = FauxFactCollector(name='with_dep_loop', required_facts=['with_dep_loop'])

    def pretend_call():
        return (col1, col2, col3, col4), frozenset(('basic', 'with_dep', 'with_dep_other', 'with_dep_loop')), frozenset(('min',)), None, None, None

# Generated at 2022-06-20 17:02:33.848725
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector_name = 'my_collector'
    expected_msg = 'CollectorNotFoundError: my_collector'
    cnfe = CollectorNotFoundError(collector_name)
    assert str(cnfe) == expected_msg



# Generated at 2022-06-20 17:02:37.969773
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("string")
    except CollectorNotFoundError as e:
        assert str(e) == "string"
        assert type(str(e)) is str
        assert isinstance(e, KeyError)
        assert isinstance(e, Exception)



# Generated at 2022-06-20 17:02:46.310078
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # Test: initialized BaseFactCollector (no parameters)
    collector1 = BaseFactCollector()
    assert collector1.collectors == []
    assert collector1.namespace is None
    assert collector1.fact_ids == {'Generic'}

    # Test: initialized BaseFactCollector (no parameters)
    collector2 = BaseFactCollector(namespace='Namespace')
    assert collector2.collectors == []
    assert collector2.namespace == 'Namespace'
    assert collector2.fact_ids == {'Generic'}
    assert collector2._transform_name('key1') == 'Namespace_key1'

    # Test: initialized BaseFactCollector (no parameters)
    collector3 = BaseFactCollector(namespace='Namespace', collectors=[collector1, collector2])
    assert collector1 in collector3.collectors
   

# Generated at 2022-06-20 17:02:59.288569
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector(collectors=[], namespace=None)
    assert collector.name is None, "collector.name is None"
    assert collector.collectors == [], "collector.collectors == []"
    assert collector.namespace is None, "collector.namespace is None"
    assert collector.fact_ids == set([]), "collector.fact_ids == set([])"


# this is the ordering of install priority for each platform.  We will probably
# need to tweak this at some point.

# Generated at 2022-06-20 17:03:05.407140
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    obj = BaseFactCollector()
    assert obj.collect() == {}



# Generated at 2022-06-20 17:03:18.190229
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class TestCollector1(BaseFactCollector):
        pass

    class TestCollector2(BaseFactCollector):
        pass

    class TestCollector3(BaseFactCollector):
        pass

    from ansible.module_utils import facts
    import inspect
    all_collectors = inspect.getmembers(facts, inspect.isclass)
    all_collectors = [m[1] for m in all_collectors]


    class TestCollector4(BaseFactCollector):
        required_facts = frozenset(['ansible_os_family'])

    class TestCollector5(BaseFactCollector):
        required_facts = frozenset(['ansible_os_family'])

    class TestCollector6(BaseFactCollector):
        required_facts = frozenset(['ansible_test_fact'])



# Generated at 2022-06-20 17:03:29.468792
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import sys
    from contextlib import contextmanager

    from ansible.module_utils.facts import collector as fact_collector
    from ansible.module_utils.facts import ansible_collector

    @contextmanager
    def builtins_resetter():
        original_builtins = sys.modules.get('__builtin__', None)
        try:
            yield
        finally:
            if original_builtins is not None:
                sys.modules['__builtin__'] = original_builtins

    @contextmanager
    def ansible_module_imp_resetter():
        original_ansible_module_imp = fact_collector.ansible_module_imp
        try:
            yield
        finally:
            fact_collector.ansible_module_imp = original_ansible_module_imp


# Generated at 2022-06-20 17:03:35.095327
# Unit test for function tsort
def test_tsort():
    import pytest

# Generated at 2022-06-20 17:03:44.279673
# Unit test for function tsort
def test_tsort():
    # create a complete graph with n nodes
    n = 10
    unsorted_map = {}
    for i in range(n):
        unsorted_map[i] = set(range(n))
        unsorted_map[i].remove(i)

    # sort it
    sorted_list = tsort(unsorted_map)

    # make sure we got it right, and that we go through every node
    assert len(sorted_list) == n
    assert set(x[0] for x in sorted_list) == set(range(n))

    # now do it again, except make a cycle by changing one node
    unsorted_map = {}
    for i in range(n):
        unsorted_map[i] = set(range(n))
        unsorted_map[i].remove(i)

    unsorted_map

# Generated at 2022-06-20 17:03:49.917613
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    def f1(module):
        return ["f2"]

    def f2(module):
        return ["f3"]

    f_dict = {
        "f1": f1,
        "f2": f2,
        "f3": f2,
    }
    try:
        f1(f_dict)
    except UnresolvedFactDep as e:
        assert e.args[0] == "f3"
    else:
        raise AssertionError("Expected UnresolvedFactDep not raised")


# Generated at 2022-06-20 17:03:59.635040
# Unit test for function get_collector_names
def test_get_collector_names():
    gather_subset = ['!all', '!network', 'interfaces']
    valid_subsets = frozenset(['all', 'min', 'hardware', 'network', 'virtual', 'facter', 'ohai', 'interfaces'])
    minimal_gather_subset = frozenset(['all', 'min', 'hardware', 'network'])

    assert get_collector_names(
        gather_subset=gather_subset,
        valid_subsets=valid_subsets,
        minimal_gather_subset=minimal_gather_subset
    ) == frozenset(['interfaces'])



# Generated at 2022-06-20 17:04:06.418122
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    import mock
    from ansible.module_utils.facts import collector

    mock_module = mock.Mock()
    mock_collected_facts = mock.Mock()
    fc = BaseFactCollector()
    fc.collect(module=mock_module, collected_facts=mock_collected_facts)



# Generated at 2022-06-20 17:04:09.035241
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    err = UnresolvedFactDep('foo')
    assert str(err) == 'foo'



# Generated at 2022-06-20 17:04:20.567176
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [type('a', (object,), {})]}

    class b(object):
        required_facts = set('c')
    all_fact_subsets['b'] = [b]

    class c(object):
        required_facts = set()
    all_fact_subsets['c'] = [c]

    assert set(find_unresolved_requires(['a'], all_fact_subsets)) == set()
    assert set(find_unresolved_requires(['a', 'b'], all_fact_subsets)) == set('c')
    assert set(find_unresolved_requires(['a', 'b', 'c'], all_fact_subsets)) == set()



# Generated at 2022-06-20 17:04:28.275250
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Unit test for CycleFoundInFactDeps constructor'''

    test_exception = CycleFoundInFactDeps('test message')

    assert test_exception.args[0] == 'test message'


# Generated at 2022-06-20 17:04:31.150500
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # CycleFoundInFactDeps is a subclass of Exception.
    # Therefore it should be constructable.
    CycleFoundInFactDeps()



# Generated at 2022-06-20 17:04:41.545944
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyCollector(object):
        _fact_ids = ['foo', 'bar', 'baz']

    class MyOtherCollector(object):
        _fact_ids = ['foo', 'bar', 'zot']

    class MyOtherOtherCollector(object):
        _fact_ids = ['foo', 'bar', 'zing']
        name = 'zot'

    FACTS = [MyCollector, MyOtherCollector, MyOtherOtherCollector]
    results = build_fact_id_to_collector_map(FACTS)
    assert set(results[0]['foo']) == set([MyCollector, MyOtherCollector])
    assert set(results[0]['bar']) == set([MyCollector, MyOtherCollector])

# Generated at 2022-06-20 17:04:46.662495
# Unit test for function tsort
def test_tsort():
    unsorted = {
        'a': set(['b', 'f']),
        'b': set(['d']),
        'e': set(['d', 'f']),
        'f': set(['c']),
    }
    sorted = tsort(unsorted)

    assert sorted[0][0] == 'c'
    assert sorted[-1][0] == 'a'

    # add a cycle
    unsorted['g'] = set(['a'])
    try:
        tsort(unsorted)
        assert False, 'cycle should have been found'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-20 17:04:51.721908
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''unit test for find_unresolved_requires

    '''
    all_fact_subsets = defaultdict(list)
    collector_names = set()

    class test_collector_1(BaseFactCollector):
        '''require collector_2'''
        name = 'collector_1'
        required_facts = set(['collector_2'])

    class test_collector_2(BaseFactCollector):
        '''require collector_3'''
        name = 'collector_2'
        required_facts = set(['collector_3'])

    class test_collector_3(BaseFactCollector):
        '''require collector_4'''
        name = 'collector_3'
        required_facts = set(['collector_4'])


# Generated at 2022-06-20 17:04:56.175548
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class ColoringNamespace:
        def __init__(self, color):
            self.color = color

        def transform(self, name):
            return '%s_%s' % (name, self.color)

    class TestCollector(BaseFactCollector):
        name = 'Test'

        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'value1'}

    c = TestCollector(namespace=ColoringNamespace('red'))
    assert c.collect_with_namespace() == {'fact1_red': 'value1'}



# Generated at 2022-06-20 17:05:02.503925
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'awk': ['awk1', 'awk2'], 'python': ['python1', 'python2'], 'rsyslog': ['rsyslog1', 'rsyslog2']}
    collector_names = ['awk', 'python', 'rsyslog']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'awk': {}, 'python': {}, 'rsyslog': {}}
test_build_dep_data()


# Generated at 2022-06-20 17:05:12.004560
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collectors import generic, linux, other, system
    all_collector_classes = [generic.GenericFactCollector,
                             linux.LinuxFactCollector,
                             other.OtherFactCollector,
                             system.SystemFactCollector]
    compat_platforms = [{'system': 'Linux'},
                        {'system': 'Generic'}]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert len(found_collectors) == 1
    assert linux.LinuxFactCollector in found_collectors



# Generated at 2022-06-20 17:05:24.721494
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {}
    # test the single collector_classes
    all_fact_subsets['single_collector_classes_1'] = [A]
    all_fact_subsets['single_collector_classes_2'] = [B]
    all_fact_subsets['single_collector_classes_3'] = [C]
    all_fact_subsets['single_collector_classes_4'] = [D]

    # test the multiple collector_classes
    all_fact_subsets['multiple_collector_classes_1'] = [A, B]
    all_fact_subsets['multiple_collector_classes_2'] = [B, C]
    all_fact_subsets['multiple_collector_classes_3'] = [C, D]

# Generated at 2022-06-20 17:05:35.250404
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'arch': 1,
        'mem': 1,
        'baz': 1,
        'foo': 1,
        'bar': 1,
        'other': 1,
    }
    unresolved_requires = ('arch', 'foo', 'qux')
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set(['arch', 'foo'])

    all_fact_subsets = {}
    unresolved_requires = ('arch', 'foo', 'qux')
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set([])


# Generated at 2022-06-20 17:05:46.182750
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("cycle found")
    except UnresolvedFactDep as e:
        assert e.message == "cycle found"
        assert e.args == e.message



# Generated at 2022-06-20 17:05:50.154936
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Ensure we can instantiate the CycleFoundInFactDeps error class.'''

    facts_error = CycleFoundInFactDeps()
    assert(facts_error is not None)



# Generated at 2022-06-20 17:06:03.397425
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'A'
        required_facts = {'B'}
    class B(BaseFactCollector):
        name = 'B'
    class C(BaseFactCollector):
        name = 'C'
        required_facts = {'B'}
    class D(BaseFactCollector):
        name = 'D'
        required_facts = {'C'}

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['A'].append(A)
    all_fact_subsets['B'].append(B)
    all_fact_subsets['C'].append(C)
    all_fact_subsets['D'].append(D)

   

# Generated at 2022-06-20 17:06:14.414294
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    Unit test for function collector_classes_from_gather_subset

    Most of what this does is a little hard to unit test, since it relies on
    functions that have side effects. This test is mostly to ensure that the
    find_collectors_for_platform part of this function is not broken.
    '''

    test_collector_classes = ['foo', 'bar', 'baz']
    collector_classes_for_platform = collector_classes_from_gather_subset(
        all_collector_classes=test_collector_classes,
        platform_info={'system': 'Generic'}
    )

    assert collector_classes_for_platform == test_collector_classes

# Generated at 2022-06-20 17:06:24.462828
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bfc = BaseFactCollector()
    assert bfc.collectors == []
    assert bfc.namespace is None

    bfc = BaseFactCollector(namespace=FactsNamespace(prefix="ansible_"))
    assert bfc.collectors == []
    assert bfc.namespace.prefix == "ansible_"

    bfc = BaseFactCollector(namespace=FactsNamespace(suffix="_system"))
    assert bfc.collectors == []
    assert bfc.namespace.suffix == "_system"
    assert bfc.namespace.sep == "_"



# Generated at 2022-06-20 17:06:27.472615
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class MyCollector(BaseFactCollector):
        name = 'foo'
    assert MyCollector().collect_with_namespace() == {}



# Generated at 2022-06-20 17:06:29.892463
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with raises(CycleFoundInFactDeps):
        raise CycleFoundInFactDeps


# Generated at 2022-06-20 17:06:31.911740
# Unit test for function resolve_requires
def test_resolve_requires():
    import doctest

    result = doctest.testmod()
    if result.failed == 0:
        print("SUCCESS")



# Generated at 2022-06-20 17:06:45.047402
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'foo'
        _fact_ids = {'bar'}

    class TestCollectorTwo(BaseFactCollector):
        _platform = 'Linux'
        name = 'baz'
        _fact_ids = {'buzz', 'buzz2'}

    all_collectors_for_platform = {TestCollector, TestCollectorTwo}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors_for_platform)

# Generated at 2022-06-20 17:06:54.008238
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Spam(BaseFactCollector):
        name = 'Spam'
    class Eggs(BaseFactCollector):
        name = 'Eggs'
    class Ham(BaseFactCollector):
        name = 'Ham'

    all_fact_subsets = {'Spam': [Spam, Ham, Ham], 'Eggs': [Eggs, Spam], 'More': [Spam, Spam]}

    result = select_collector_classes(['Spam', 'Eggs'], all_fact_subsets)
    assert result == [Spam, Ham, Eggs, Spam]

