

# Generated at 2022-06-20 16:57:09.214070
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    all_fact_subsets = defaultdict(list)
    class CollectorA(BaseFactCollector):
        required_facts = set(['bad'])

    class CollectorB(BaseFactCollector):
        required_facts = set(['bad'])

    class CollectorC(BaseFactCollector):
        required_facts = set(['good'])

    class CollectorD(BaseFactCollector):
        required_facts = set(['good'])

    all_fact_subsets['a'].append(CollectorA)
    all_fact_subsets['b'].append(CollectorB)
    all_fact_subsets['c'].append(CollectorC)
    all_fact_subsets['d'].append(CollectorD)


# Generated at 2022-06-20 16:57:12.521824
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    def test(fact_name):
        try:
            raise UnresolvedFactDep(fact_name)
        except UnresolvedFactDep as e:
            assert e.args[0] == fact_name

    test('foo')
    test('bar')



# Generated at 2022-06-20 16:57:23.307615
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class SomeFactCollector(BaseFactCollector):
        name = 'test_collect'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'some_value'}

    class SomeFactCollectorRequiresFact(BaseFactCollector):
        name = 'test_collect_requires'
        required_facts = {'test_fact', 'some_other_fact'}

        def collect(self, module=None, collected_facts=None):
            return {'test_requires_fact': 'some_value'}

    class SomeFactCollectorRequiresFactWithCycle(BaseFactCollector):
        name = 'test_collect_requires_cycle'
        required_facts = {'test_requires_fact_in_cycle'}


# Generated at 2022-06-20 16:57:28.736178
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fact_collector = BaseFactCollector()
    assert fact_collector.name is None
    assert fact_collector.required_facts == set()
    assert fact_collector.collectors == []

    fact_collector = BaseFactCollector(collectors=['first', 'second'])
    assert fact_collector.collectors == ['first', 'second']



# Generated at 2022-06-20 16:57:33.509822
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('Test message')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'Test message'


# Generated at 2022-06-20 16:57:40.822474
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['A', 'B', 'C', 'D', 'E']
    all_fact_subsets = {'A': [1, 2], 'B': [3, 4], 'C':[5, 6], 'D':[7,8], 'E':[9,10]}
    assert build_dep_data(collector_names, all_fact_subsets) == {'A': set(), 'B': set(), 'C': set(), 'D': set(), 'E': set()}


# Generated at 2022-06-20 16:57:47.314399
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    all_fact_subsets = {
        'one': [FactCollectorClass(name='one', required_facts=set(['two', 'three']))],
        'two': [FactCollectorClass(name='two', required_facts=set(['four']))],
        'three': [FactCollectorClass(name='three', required_facts=set(['five']))],
        'four': [FactCollectorClass(name='four', required_facts=set())],
        'five': [FactCollectorClass(name='five', required_facts=set())],
        'six': [FactCollectorClass(name='six', required_facts=set())],
    }

    collector_names = set(['one', 'two', 'three', 'four', 'five', 'six'])

    assert find_unresolved

# Generated at 2022-06-20 16:58:00.113848
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import json

    from ansible.module_utils.facts import collector as facts_collector
    target_collector = 'network'
    all_fact_subsets = facts_collector.C.fact_subsets

    names = all_fact_subsets.keys()
    assert(names)

    seen_collector_classes = set()
    selected_collector_classes = []

    selected_collector_classes = select_collector_classes(names, all_fact_subsets)

    assert(len(all_fact_subsets) == len(selected_collector_classes))

    selected_collector_classes = select_collector_classes([], all_fact_subsets)
    assert(len(selected_collector_classes) == 0)

    seen_collector_classes = set()

# Generated at 2022-06-20 16:58:11.757653
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class GenericFactCollector1(BaseFactCollector):
        name = 'generic_collector1'

    class GenericFactCollector2(BaseFactCollector):
        name = 'generic_collector2'
    class GenericFactCollector3(BaseFactCollector):
        name = 'generic_collector3'

    class LinuxFactCollector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux_collector1'

    class LinuxFactCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux_collector2'

    class LinuxFactCollector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux_collector3'

    class LinuxFedoraFactCollector1(BaseFactCollector):
        _platform = 'LinuxFedora'

# Generated at 2022-06-20 16:58:23.761288
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.base import Collector
    from ansible.module_utils.facts.collectors import network
    
    test_base_fact_collector = BaseFactCollector()
    test_base_fact_collector.collect_with_namespace()
    key_name = 'interface_'
    test_base_fact_collector.namespace = Collector('test')
    old_key = 'interface_'
    new_key = 'test_interface_'
    test_base_fact_collector._transform_name(key_name)
    test_base_fact_collector._transform_dict_keys({'interface_': 'test'})

# Generated at 2022-06-20 16:58:39.048312
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector.generic import GenericFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualFactCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector

    module_mock = mock.Mock()
    def collect(self, module=None, collected_facts=None):
        return {}


# Generated at 2022-06-20 16:58:46.223617
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = set(('devices', 'dmi'))
    aliases_map['network'] = set(('interfaces', 'ipv4', 'ipv6'))
    aliases_map['software'] = set(('os', 'lsb'))
    aliases_map['virtual'] = set(('virtualization', 'facter_virtual', 'ohai_virtual'))

    # Platform facts
    PLATFORM_FACTS = frozenset(('system', 'distribution', 'distribution_major_version', 'distribution_version',
                                'os_family', 'virtualization', 'facter_virtual', 'ohai_virtual'))

    # Network facts

# Generated at 2022-06-20 16:58:53.318298
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.network.interfaces import NetworkInterfaceFactCollector

    class Test1(BaseFactCollector):
        name = 'test1'
    class Test2(BaseFactCollector):
        name = 'test2'
    class Test3(BaseFactCollector):
        name = 'test3'

    class Test4(NetworkFactCollector):
        name = 'test4'
    class Test5(NetworkInterfaceFactCollector):
        name = 'test5'

    class Test6(BaseFactCollector):
        name = 'test6'

    # test select_collector_classes, when NetworkInterfaceFactCollector is

# Generated at 2022-06-20 16:59:05.466075
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector

    class CollectorA(BaseFactCollector):
        name = 'A'

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set([CollectorA.name])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set([CollectorB.name])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set([CollectorA.name])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set([CollectorD.name])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets[CollectorA.name].append(CollectorA)
    all_fact_

# Generated at 2022-06-20 16:59:09.442925
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    test_dict = {}
    test_obj = BaseFactCollector()
    assert test_obj.collect() == {}


# Generated at 2022-06-20 16:59:18.839252
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    import itertools
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.hardware import OSXHardware
    from ansible.module_utils.facts.collector.hardware import OpenBSDHardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.network import OSXNetwork
    from ansible.module_utils.facts.collector.network import OpenBSDNetwork
    from ansible.module_utils.facts.collector.dmi import DMI
    from ansible.module_utils.facts.collector.dmi import OSXDMI
    from ansible.module_utils.facts.collector.dmi import OpenBSDDMI


# Generated at 2022-06-20 16:59:22.203598
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = 'Some message'
    e = CycleFoundInFactDeps(msg)
    assert msg == str(e)


# Generated at 2022-06-20 16:59:32.276111
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    import collections

    mock_class = collections.namedtuple('MockClass', ['name', 'required_facts'])


# Generated at 2022-06-20 16:59:36.304995
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import all_collectors, build_fact_id_to_collector_map
    f = build_fact_id_to_collector_map(all_collectors)
    assert f[0]['virtual'][0].__name__ == 'Virtual'



# Generated at 2022-06-20 16:59:48.022461
# Unit test for function get_collector_names
def test_get_collector_names():
    platform_info = dict(system='Linux')
    base_valid_subsets = frozenset(['Linux'])

    # at minimum, minimal_gather_subset always has 'all'
    minimal_gather_subset = ['all']

    # Retrieve module parameters
    gather_subset = ['all']

    collectors = get_collector_names(valid_subsets=base_valid_subsets,
                                     minimal_gather_subset=minimal_gather_subset,
                                     aliases_map=aliases_map,
                                     gather_subset=gather_subset,
                                     platform_info=platform_info)

    assert 'Linux' in collectors

    # Retrieve module parameters
    gather_subset = ['!all']

# Generated at 2022-06-20 17:00:09.050475
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestFactCollector(BaseFactCollector):
        name = 'test'

    # basic test of passing in no collectors
    f = TestFactCollector()
    assert f.collectors == []

    # test constructor with list of FactCollectors
    f2 = TestFactCollector([f])
    assert isinstance(f2, BaseFactCollector)
    assert isinstance(f2, TestFactCollector)
    assert f2.collectors == [f]

    # test of the _transform_name method
    class prefix:
        def transform(self, key_name):
            return 'prefix_' + key_name

    # with namespacing
    f3 = TestFactCollector(namespace=prefix())
    assert f3._transform_name('my_key') == 'prefix_my_key'

    # without namespacing

# Generated at 2022-06-20 17:00:19.341700
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FooFactCollector(BaseFactCollector):
        _fact_ids = ['foo_id']
        name = "foo"

    class BarFactCollector(BaseFactCollector):
        _fact_ids = ['bar_id']
        name = "bar"

    class BazFactCollector(BaseFactCollector):
        _fact_ids = ['baz_id']
        name = "baz"

    baz_fact_collector_class = BazFactCollector

    collectors_for_platform = [FooFactCollector, BarFactCollector, BazFactCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert 'foo' in fact_id_to_collector_map

# Generated at 2022-06-20 17:00:30.380901
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    We manually fake out the return values from all of the functions this calls,
    so that we can run a unit test on this.

    (this is the only way to test that this logic works, since everything is
    private to the module).

    '''
    class FixedAllValidSubsets:
        def __init__(self, value):
            self._value = value

        def __call__(self, *args, **kwargs):
            return self._value

    class FakeCollectorClass:
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

        def __init__(self, name, required_facts, platform=None):
            self.name = name
            self.required_facts = required_facts
            self._platform = platform or 'Generic'

       

# Generated at 2022-06-20 17:00:38.541828
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    unittest.TestCase()
    all_fact_subsets = {
        'all': [GetterSetter],
        'network': [NetworkCollector],
        'min': [GetterSetter, MinimalFactCollector]
    }
    # No unresolved
    collector_names = ['all', 'network', 'min']
    assert set() == find_unresolved_requires(collector_names, all_fact_subsets)
    # One unresolved
    collector_names = ['all', 'network', 'min', 'some_collector_no_one_knows_about']
    assert {'some_collector_no_one_knows_about'} == find_unresolved_requires(collector_names, all_fact_subsets)
    # Two unresolved
    # There is no fact collector with name 'no_

# Generated at 2022-06-20 17:00:50.230780
# Unit test for function get_collector_names
def test_get_collector_names():
    # pylint: disable=unsubscriptable-object
    assert get_collector_names(['first', 'second']) == set(['first', 'second'])
    assert get_collector_names(['first', 'second'], ['first']) == set(['first', 'second'])
    assert get_collector_names(['first', 'second'], ['second']) == set(['first', 'second'])
    assert get_collector_names(['first', 'second'], ['first'], ['first']) == set(['first', 'second'])
    assert get_collector_names(['first', 'second'], ['second'], ['first']) == set(['first', 'second'])

# Generated at 2022-06-20 17:01:01.779203
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset((
        'hardware', 'network', 'interfaces', 'dmi', 'devices', 'system', 'virtual', 'all', 'firmware', 'min'
    ))


# Generated at 2022-06-20 17:01:08.734003
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector
    all_subclasses = collector.get_collector_subclasses()

    # no platform info given (as it would be for a local collect)
    found_collectors = find_collectors_for_platform(
        all_subclasses,
        compat_platforms=[{}]
    )

    assert len(found_collectors) > 0

    # in case of failure, print the names of the collectors to assist debugging
    print("%s" % sorted([c.name for c in found_collectors]))



# Generated at 2022-06-20 17:01:19.057704
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'd': set(['b', 'c']),
        'c': set(['f', 'a']),
        'b': set(['a']),
    }
    assert tsort(dep_map) == [('a', set()), ('f', set()), ('b', set(['a'])), ('c', set(['f', 'a'])), ('d', set(['b', 'c']))]
    dep_map = {
        'd': set(['b', 'c']),
        'c': set(['f', 'a']),
        'b': set(['a', 'd']),
    }

# Generated at 2022-06-20 17:01:29.894757
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Define fake Collector classes
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact_id_1'])
        _platform = 'Generic'
        name = 'FakeCollector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact_id_2'])
        _platform = 'Generic'
        name = 'FakeCollector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact_id_3'])
        _platform = 'Linux'
        name = 'FakeCollector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact_id_4'])
        _platform = 'FreeBSD'
        name = 'FakeCollector4'


# Generated at 2022-06-20 17:01:32.477714
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fact_collector = BaseFactCollector()
    assert fact_collector.collectors is None
    assert fact_collector.namespace is None
    assert fact_collector.fact_ids == set([None])



# Generated at 2022-06-20 17:01:44.657727
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    """Test for the method collect of class BaseFactCollector."""
    # Create an instance of `BaseFactCollector`.
    bfc = BaseFactCollector()
    assert bfc.collect() == {}



# Generated at 2022-06-20 17:01:50.076530
# Unit test for function select_collector_classes
def test_select_collector_classes():
    cls1 = type('c1', (BaseFactCollector,), dict(name='c1', _fact_ids=['a', 'b']))
    cls2 = type('c2', (BaseFactCollector,), dict(name='c2', _fact_ids=['b', 'c']))
    cls3 = type('c3', (BaseFactCollector,), dict(name='c3', _fact_ids=['b', 'd']))

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'].append(cls1)
    all_fact_subsets['b'].append(cls1)
    all_fact_subsets['b'].append(cls2)
    all_fact_subsets['b'].append(cls3)
    all

# Generated at 2022-06-20 17:01:57.887471
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['a_dep'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['b_dep'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set()


# Generated at 2022-06-20 17:02:07.765054
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import mock
    all_collector_classes = [
        mock.MagicMock(name='first_collector1', platform_match=lambda x: 'first_collector1'),
        mock.MagicMock(name='first_collector2', platform_match=lambda x: None),
        mock.MagicMock(name='second_collector', platform_match=lambda x: 'second_collector'),
        mock.MagicMock(name='third_collector', platform_match=lambda x: 'third_collector'),
        ]
    assert find_collectors_for_platform(all_collector_classes, ['first','second','third']) == set(all_collector_classes[0:4])

# Generated at 2022-06-20 17:02:09.665431
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collector = BaseFactCollector()
    assert collector.collect({}, {}) == {}



# Generated at 2022-06-20 17:02:18.788753
# Unit test for function tsort
def test_tsort():
    assert tsort({}) == []
    assert tsort({
        'a': set()
    }) == [('a', set())]

    assert tsort({
        'a': set(),
        'b': set()
    }) == [('a', set()), ('b', set())]

    assert tsort({
        'a': set(),
        'b': set(),
        'c': set()
    }) == [('a', set()), ('b', set()), ('c', set())]

    assert tsort({
        'a': set(),
        'b': set(),
        'c': set(),
        'd': set()
    }) == [('a', set()), ('b', set()), ('c', set()), ('d', set())]


# Generated at 2022-06-20 17:02:30.055531
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()

        _platform = 'Generic'
        name = None
        required_facts = set()

    all_collectors = [TestCollector]

    compat_platforms = [
        {'system': 'Linux'},
        {'system': 'FreeBSD'},
        {'system': 'NetBSD'},
        {'system': 'OpenBSD'},
        {'system': 'Solaris'},
        {'system': 'Darwin'},
        {'system': 'Windows'},
    ]

    # case 1: find linux collector
    linux_collector_classes = find_collectors_for_platform(all_collectors, compat_platforms)
    assert len(linux_collector_classes) == 1
    assert linux_collector_classes

# Generated at 2022-06-20 17:02:35.024112
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        _fact_ids = ('collector_a',)
        # This field is needed for the test
        required_facts = ('collector_b',)
    class CollectorB(BaseFactCollector):
        _fact_ids = ('collector_b',)
    mock_fact_subsets = {'collector_a': {CollectorA}, 'collector_b': {CollectorB}}
    mock_collector_names = ('collector_a',)

    # Case 1: collector_a has an unresolved require(collector_b)
    assert find_unresolved_requires(mock_collector_names, mock_fact_subsets) == {'collector_b'}

    # Case 2: collector_a has a resolved require (collector_b)
    mock_collector

# Generated at 2022-06-20 17:02:38.500953
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    e = UnresolvedFactDep('ERROR')
    assert str(e) == 'ERROR'


# Generated at 2022-06-20 17:02:42.527805
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # test with no args
    bc = BaseFactCollector()
    assert bc.collectors == []
    assert bc.namespace == None

# test _transform_name on a None namespace

# Generated at 2022-06-20 17:03:03.219877
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # arrange
    cycled_collector = CycleFoundInFactDeps('cycle')

    # act
    expected_str = repr('cycle')

    # assert
    assert str(cycled_collector) == expected_str



# Generated at 2022-06-20 17:03:10.618998
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import collector

    # test that collect_with_namespace calls collect.
    # as a side effect, this tests that it can be called
    # without raising
    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            fact_dict = {}
            return fact_dict

    c = TestCollector()
    c.collect_with_namespace()



# Generated at 2022-06-20 17:03:21.329897
# Unit test for function build_dep_data
def test_build_dep_data():
    class collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['dep1'])
    class collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['dep2'])
    class collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()
    class collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['dep1'])
    class collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = set(['dep4'])
    class collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = set(['dep1', 'dep2'])

    all

# Generated at 2022-06-20 17:03:27.565532
# Unit test for function select_collector_classes
def test_select_collector_classes():
    a = BaseFactCollector()
    a.name = 'a'
    a._fact_ids = set(['a'])

    b = BaseFactCollector()
    b.name = 'b'
    b._fact_ids = set(['b'])

    c = BaseFactCollector()
    c.name = 'c'
    c._fact_ids = set(['c'])

    d = BaseFactCollector()
    d.name = 'd'
    d._fact_ids = set(['d'])
    d.required_facts = set(['a'])

    e = BaseFactCollector()
    e.name = 'e'
    e._fact_ids = set(['e'])
    e.required_facts = set(['d'])


# Generated at 2022-06-20 17:03:30.914229
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        '''no code'''
    except:
        assert(True)
# end of unit test for class CycleFoundInFactDeps



# Generated at 2022-06-20 17:03:33.938165
# Unit test for constructor of class CollectorNotFoundError

# Generated at 2022-06-20 17:03:36.987183
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    cycle_deps_error = CycleFoundInFactDeps('A thing', 'A thing')
    assert str(cycle_deps_error).startswith('Found cycle')



# Generated at 2022-06-20 17:03:49.591623
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collectors = [
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
    ]
    collected_samples = {
        'a': [1,1,4,4,4,4],
        'b': [0,0,0,2,2],
        'c': [3,3,3,3,3,3],
        'd': [2,2,2,2,2],
        'e': [3,3,3,3,3],
        'f': [4,4,4,4,4],
    }
    for collector in collectors:
        new_sample = collected_samples[collector]
        len_sample = len(new_sample)

# Generated at 2022-06-20 17:04:01.034280
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        required_facts = set()
        name = 'test_collector'

    class TestCollectorTwo(BaseFactCollector):
        _fact_ids = set()
        required_facts = set()
        name = 'test_collector_two'

    class TestCollectorThree(BaseFactCollector):
        _fact_ids = set(['test_collector_alias'])
        required_facts = set()
        name = 'test_collector_three'

    collector_list = [TestCollector, TestCollectorTwo, TestCollectorThree]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_list)

    assert TestCollector in fact_id_to

# Generated at 2022-06-20 17:04:08.781679
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps('msg')
    assert str(err) == 'msg'

# Each fact collector should have it's dependencies (other fact collectors)
# listed in this map. This is used to determine the order in which fact
# collectors should be called.
#
# Note: For indexing, the module class name is used, so the key must be
# a string.
FACT_DEPENDENCIES = {
    'default': [],
    'linux': ['default'],
    'system': ['default'],
    'virtual': ['default'],
    'network': ['default'],
}



# Generated at 2022-06-20 17:04:33.142422
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class LinuxFactCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux'
    class SmartosFactCollector(BaseFactCollector):
        _platform = 'SunOS'
        name = 'smartos'

    assert find_collectors_for_platform(set(), []) == set()

    found_collectors = find_collectors_for_platform(
        set([LinuxFactCollector]),
        [{'system': 'Linux'}, {'system': 'SunOS'}],
    )
    assert found_collectors == {LinuxFactCollector}
    assert found_collectors == find_collectors_for_platform(
        set([LinuxFactCollector, SmartosFactCollector]),
        [{'system': 'Linux'}, {'system': 'SunOS'}],
    )

# Generated at 2022-06-20 17:04:34.581745
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError("hi")



# Generated at 2022-06-20 17:04:41.508820
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import get_collector_class
    from ansible.module_utils.facts.collectors.generic import GenericFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkFactCollector

    found_collectors = [GenericFactCollector, NetworkFactCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(found_collectors)
    assert len(aliases_map) == 2
    assert len(fact_id_to_collector_map) == 3
    assert 'generic' in aliases_map
    assert 'network' in aliases_map
    assert 'generic' in fact_id_to_collector_map
    assert 'network' in fact_id_to_collector_map

# Generated at 2022-06-20 17:04:47.659170
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Setup
    all_fact_subsets = {'b': [BaseFactCollector], 'c': [BaseFactCollector], 'd': [BaseFactCollector]}
    collector_names_a = ['a']
    collector_names_b = ['b']
    collector_names_c = ['c']
    collector_names_d = ['d']

    # Function to set the required facts for a collector
    def set_required_facts(collector_name, required_facts):
        for collector_class in all_fact_subsets[collector_name]:
            collector_class.required_facts = required_facts
    # Test1
    # Case 1: Resolves all requires
    # Case 2: Resolves no requires
    # Case 3: Resolves only some requires

    # Case 1: Resolves all requires
    set_required_facts

# Generated at 2022-06-20 17:04:54.898181
# Unit test for function get_collector_names
def test_get_collector_names():
    is_subset = lambda x, y: set(x).issubset(y)
    # Test 1
    min_gather_subset = frozenset(('defaults',))
    valid_subsets = frozenset(('foo', 'defaults', 'bar', 'baz'))
    aliases_map = defaultdict(set, {'foo': frozenset(('foo_alt', 'baz', )),
                                    'bar': frozenset(('baz', ))})


# Generated at 2022-06-20 17:05:03.824780
# Unit test for function tsort

# Generated at 2022-06-20 17:05:09.521517
# Unit test for function build_dep_data
def test_build_dep_data():
    import mock
    class Collector:
        name = 'collector'
        required_facts = {'dep1', 'dep2'}
    assert build_dep_data({'collector'}, {'collector': {Collector}}) == {'collector': {'dep1', 'dep2'}}


# Generated at 2022-06-20 17:05:16.342589
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        e = CycleFoundInFactDeps('this is a test')
        assert e.args[0] == 'this is a test'
    except Exception as e:
        assert False, 'Expected CycleFoundInFactDeps got %s' % e.__class__

# Determine the correct processor order

# Generated at 2022-06-20 17:05:26.808335
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collectors.base

    class TestCollector1(ansible.module_utils.facts.collectors.base.BaseFactCollector):
        name = 'test1'
        _fact_ids = ('test1_1', 'test1_2')

    class TestCollector2(ansible.module_utils.facts.collectors.base.BaseFactCollector):
        name = 'test2'
        _fact_ids = ('test2_1', 'test2_2')

    class TestCollector3(ansible.module_utils.facts.collectors.base.BaseFactCollector):
        name = 'test3'
        _fact_ids = ()


# Generated at 2022-06-20 17:05:31.298669
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('a', 'b', 'c')
    except CollectorNotFoundError as e:
        assert 'a' == e.args[0]
        assert 'b' == e.args[1]
        assert 'c' == e.args[2]
