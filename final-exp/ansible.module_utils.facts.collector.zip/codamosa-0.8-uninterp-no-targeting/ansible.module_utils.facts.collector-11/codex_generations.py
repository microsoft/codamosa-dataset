

# Generated at 2022-06-20 16:57:11.322290
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # construct and assert default values
    base = BaseFactCollector()
    assert base.collectors == []
    assert base.namespace is None
    assert base.fact_ids == set([None])
    assert base._platform is 'Generic'

    # check transforms
    transformed_name = base._transform_name("foo")
    assert transformed_name == "foo"

    fact_dict = {'foo': "bar"}
    transformed_dict = base._transform_dict_keys(fact_dict)
    assert fact_dict == transformed_dict

    # test namespace, add to collections
    base.namespace = 'my_namespace'
    transformed_name = base._transform_name("foo")
    assert transformed_name == "foo_my_namespace"

    fact_dict = {'foo': "bar"}
    transformed_dict = base._

# Generated at 2022-06-20 16:57:19.927876
# Unit test for function get_collector_names

# Generated at 2022-06-20 16:57:24.476362
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Exception has a message
    err = UnresolvedFactDep('msg')
    assert err.message == 'msg'

    # Exception is a subclass of ValueError
    assert isinstance(err, ValueError)


# Generated at 2022-06-20 16:57:31.491914
# Unit test for function get_collector_names
def test_get_collector_names():
    def assert_subsets_match(valid_subsets, minimal_gather_subset, gather_subset,
                             aliases_map, expected_subsets):
        actual_subsets = get_collector_names(
            valid_subsets,
            minimal_gather_subset,
            gather_subset,
            aliases_map,
            None)
        assert actual_subsets == set(expected_subsets)

    def gen_ids(start, end):
        '''Returns a list of string ids starting with start and ending with end.'''
        ids = []
        val = start
        while val < end:
            ids.append(str(val))
            val += 1
        return ids

    def gen_subsets(start, end):
        return frozenset(gen_ids(start, end))

# Generated at 2022-06-20 16:57:43.108282
# Unit test for function tsort
def test_tsort():

    # Test tsort, which is a Topological sort algorithm
    # tsort takes a array of (node, [list of nodes it depends on]) and
    # returns a sorted list on nodes.
    # This is useful for fact collector classes, since some need to be run before
    # others, and they can specify a list of fact collectors they depend on.
    # tsort also raises an exception if given a cycle

    def run_test(dep_map, expected_tsorted):
        # Given the list of (name, [list of deps]) build the tsort
        tsort_result = tsort(dep_map)

        # convert the tsort_result to a list of only the names
        tsort_names = [item[0] for item in tsort_result]
        # compare the sorted list

# Generated at 2022-06-20 16:57:44.049439
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  result = BaseFactCollector().collect()
  assert result == {}


# Generated at 2022-06-20 16:57:48.157533
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()

    # verify .collect() returns an empty dict
    facts_dict = fc.collect()
    assert isinstance(facts_dict, dict)
    assert len(facts_dict) == 0

    # verify .collect_with_namespace() returns an empty dict
    facts_dict_nw = fc.collect_with_namespace()
    assert isinstance(facts_dict_nw, dict)
    assert len(facts_dict_nw) == 0

    return fc



# Generated at 2022-06-20 16:58:00.364275
# Unit test for function resolve_requires
def test_resolve_requires():
    unres_requir = ['a', 'b', 'c']
    fact_subsets = ['a', 'b', 'c', 'd']

    all_fact_subsets = {}
    for fact in fact_subsets:
        all_fact_subsets[fact] = fact
    assert(resolve_requires(unres_requir, all_fact_subsets) == set(fact_subsets))

    unres_requir = ['a', 'b', 'c']
    fact_subsets = ['a', 'b', 'd']

    all_fact_subsets = {}
    for fact in fact_subsets:
        all_fact_subsets[fact] = fact


# Generated at 2022-06-20 16:58:11.850177
# Unit test for function resolve_requires
def test_resolve_requires():
    # Set up a pretend all_fact_subsets
    all_fact_subsets = {
        'a': [None],
        'b': [None],
        'c': [None],
        'd': [None],
        }

    # test a good case
    assert resolve_requires(['a', 'b'], all_fact_subsets) == set(['a', 'b'])
    assert resolve_requires(['a', 'd'], all_fact_subsets) == set(['a', 'd'])
    # list has only one failure, so raises UnresolvedFactDep
    try:
        resolve_requires(['a', 'nonsense'], all_fact_subsets)
        assert False, 'should have raised'
    except UnresolvedFactDep:
        pass

    # test a mixed case

# Generated at 2022-06-20 16:58:23.796486
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import unittest
    import json
    import tempfile
    import shutil

    class MockFactCollector(BaseFactCollector):
        name = 'base'

    class MockFactCollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['b'])

    class MockFactCollectorB(BaseFactCollector):
        name = 'b'

    class MockFactCollectorC(BaseFactCollector):
        name = 'c'

    class MockFactCollectorD(BaseFactCollector):
        name = 'd'

    class MockFactCollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['a', 'b'])

    class MockFactCollectorF(BaseFactCollector):
        name = 'f'


# Generated at 2022-06-20 16:58:33.374635
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('test_UnresolvedFactDep', 'xyz')
    except UnresolvedFactDep as ex:
        assert str(ex) == "fact 'test_UnresolvedFactDep' depends on unknown fact 'xyz'"



# Generated at 2022-06-20 16:58:45.436331
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    def my_collect(module=None, collected_facts=None):
        return {}

    class MyFactCollector(BaseFactCollector):
        name = 'my_fact'
        _platform = 'Linux'

        collect = my_collect

    # test __init__
    mfc = MyFactCollector()
    assert mfc.fact_ids == set(['my_fact']), 'expected ["my_fact"] in fact_ids but found %s' % mfc.fact_ids
    assert mfc.collectors == [], 'expected empty collector list but found %s' % mfc.collectors
    assert mfc.namespace is None, 'expected no namespace, but found "%s"' % mfc.namespace

    # test _transform_name

# Generated at 2022-06-20 16:58:58.098748
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # failed in test_timeout, no namespace
    my_base_fact_collector = BaseFactCollector()
    my_facts = {'facts.bcd': {'value': 'bcd'}}
    my_module = type(module)
    my_facts_dict = my_base_fact_collector.collect(module=my_module, collected_facts=my_facts)
    my_expected_value = {'facts.bcd': {'value': 'bcd'}}
    assert my_expected_value == my_facts_dict

    # failed in test_timeout, with namespace
    my_base_fact_collector = BaseFactCollector(namespace={'namespace': 'my_namespace'})

# Generated at 2022-06-20 16:59:07.719206
# Unit test for function get_collector_names

# Generated at 2022-06-20 16:59:13.317166
# Unit test for function get_collector_names

# Generated at 2022-06-20 16:59:26.205446
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {}
    results = select_collector_classes(['min', '!min'], all_fact_subsets)
    assert results == []
    results = select_collector_classes(['min', 'min', '!min'], all_fact_subsets)
    assert results == []

    all_fact_subsets = {'min': [BaseFactCollector],
                        'foo': [BaseFactCollector]}
    results = select_collector_classes(['min', '!min'], all_fact_subsets)
    assert results == []
    results = select_collector_classes(['min', 'min'], all_fact_subsets)
    assert results == [BaseFactCollector]

# Generated at 2022-06-20 16:59:32.353910
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("Test of CollectorNotFoundError")
    except CollectorNotFoundError as e:
        pass
    except Exception as e:
        raise AssertionError("CollectorNotFoundError constructor failed to create exception")


# Generated at 2022-06-20 16:59:34.766777
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    collector_not_found_err = CollectorNotFoundError('name')
    assert collector_not_found_err.args == ('name',)



# Generated at 2022-06-20 16:59:39.355192
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('collector not found')
    except CollectorNotFoundError as e:
        pass



# Generated at 2022-06-20 16:59:48.661770
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['fake1', 'fake2', 'fake3']
    all_fact_subsets = defaultdict(list)
    collector_class1 = type('fake1_class', (BaseFactCollector, object), {'name': 'fake1'})
    all_fact_subsets['fake1'].append(collector_class1)
    collector_class2 = type('fake2_class', (BaseFactCollector, object), {'name': 'fake2'})
    all_fact_subsets['fake2'].append(collector_class2)
    collector_class3 = type('fake3_class', (BaseFactCollector, object), {'name': 'fake3'})
    all_fact_subsets['fake3'].append(collector_class3)

# Generated at 2022-06-20 17:00:17.670525
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():

    try:
        raise UnresolvedFactDep('foo')
    except Exception as e:
        assert e.args[0] == "foo"


# Generated at 2022-06-20 17:00:21.935904
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    expected = {'ansible_facts': {}}
    result = BaseFactCollector().collect()
    assert result == expected


# Generated at 2022-06-20 17:00:25.037105
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Initialize fcoll
    fcoll = BaseFactCollector()

    # Check initial state and value of method collect_with_namespace.
    assert fcoll.collect_with_namespace() == {}



# Generated at 2022-06-20 17:00:35.203400
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    ''' a simple unit test that ensures that the normal case finds the right collector classes '''
    # fech the list of existing collectors
    found_classes = set()
    for mod in [ansible_collectors, ohai_collectors, facter_collectors]:
        for collector_class in mod.collector_classes():
            found_classes.add(collector_class)

    # normal use case
    collector_classes = collector_classes_from_gather_subset(all_collector_classes=found_classes)

    # normal use case with no optional args
    collector_classes = collector_classes_from_gather_subset()

    # normal use case with subset
    collector_classes = collector_classes_from_gather_subset(gather_subset=['hardware'])

    # normal use case with subset that expands

# Generated at 2022-06-20 17:00:44.557897
# Unit test for function find_unresolved_requires

# Generated at 2022-06-20 17:00:52.061308
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from collections import namedtuple

    CompatInfo = namedtuple("CompatInfo", "os release_id")
    compat_platforms = [
        CompatInfo("Linux", "Ubuntu"),
        CompatInfo("Linux", "CentOS Linux"),
        CompatInfo("Darwin", "10.12.1")
    ]

    # define fake fact collection classes
    class BaseCollector(BaseFactCollector):
        _platform = "Linux"

    class SystemCollector(BaseCollector):
        name = "system"

    class HardwareCollector(BaseCollector):
        name = "hardware"

    class NetworkCollector(BaseCollector):
        name = "network"

    class DarwinCollector(BaseFactCollector):
        _platform = 'Darwin'
        name = "Darwin"


# Generated at 2022-06-20 17:01:03.314426
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''Unit test for function collector_classes_from_gather_subset'''

    # create a temporary mocked module
    with mock.patch.dict(sys.modules, {'ansible': mock.MagicMock(),
                                       'ansible.module_utils': mock.MagicMock(),
                                       'ansible.module_utils.facts': mock.MagicMock()}):
        from ansible.module_utils.facts import collector as facts_collector

        # create mock classes
        class MockCollector0(facts_collector.BaseFactCollector):
            name = 'mock_collector0'

        class MockCollector1(facts_collector.BaseFactCollector):
            name = 'mock_collector1'
            required_facts = frozenset(['mock_collector0'])


# Generated at 2022-06-20 17:01:11.895936
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestBaseFactCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            facts_dict['dict_key'] = 'boom!'
            return facts_dict

    # test with a namespace that removes the 'dict_' prefix
    class TestNamespace:
        def transform(self, name):
            return name.replace('dict_', '', 1)

    f1 = TestBaseFactCollector()
    f1_facts = f1.collect_with_namespace()
    assert f1_facts['dict_key'] == 'boom!'

    f2 = TestBaseFactCollector(namespace=TestNamespace())
    f2_facts = f2.collect_with_namespace()

# Generated at 2022-06-20 17:01:20.205635
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'a': [1, 2, 3],
        'b': [2, 3, 4],
    }

    collector_names = ['a']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [1, 2, 3]

    collector_names = ['a', 'b']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [1, 2, 3, 4]

    collector_names = ['a', 'b', 'a']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector

# Generated at 2022-06-20 17:01:30.771337
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''
    unittest test case for function find_collectors_for_platform
    '''

    class CollectorA(BaseFactCollector):
        pass

    class CollectorB(BaseFactCollector):
        _platform = 'Darwin'
        name = 'collectorB'

    class CollectorC(BaseFactCollector):
        _platform = 'Linux'
        name = 'collectorC'

    class CollectorD(BaseFactCollector):
        _platform = 'OpenBSD'
        name = 'collectorD'

    all_collector_classes = [CollectorA, CollectorB, CollectorC, CollectorD]

    found_collectors = find_collectors_for_platform(all_collector_classes, (dict(system='Darwin'), dict(system='Linux'), dict(system='OpenBSD')))


# Generated at 2022-06-20 17:02:01.444343
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class WindowsCollector(BaseFactCollector):
        _fact_ids = set(['windows_facts'])
        _platform = 'Windows'

    class LinuxCollector(BaseFactCollector):
        _fact_ids = set(['linux_facts'])
        _platform = 'Linux'

    class GenericCollector(BaseFactCollector):
        _fact_ids = set(['generic_facts'])
        _platform = 'Generic'

    class DefaultCollector(BaseFactCollector):
        _fact_ids = set(['default_facts'])
        _platform = 'Default'

    # no platform_info
    assert find_collectors_for_platform([WindowsCollector, GenericCollector], [{}]) == \
        set([GenericCollector])

    # no platform match

# Generated at 2022-06-20 17:02:05.339075
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector
    obj = collector.BaseFactCollector()
    assert obj
    assert obj.collectors == []
    obj = collector.BaseFactCollector(collectors=['abc'])
    assert obj.collectors == ['abc']


# Generated at 2022-06-20 17:02:17.929931
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts.collector.vendor.vmware.esxi import VMWareESXi
    from ansible.module_utils.facts.collector.vendor.hp import HPFacts
    import time
    import mock

    # Collected Facts (Dummy Class)
    class CollectedFacts:
        def __init__(self):
            self.data = {}

    # Collectors (Base Class to be tested)
    class CollectorA(BaseFactCollector):
        name = 'Collector A'
        _fact_ids = set(['Collector A Id'])

    class CollectorB(BaseFactCollector):
        name = 'Collector B'
        _fact_ids = set(['Collector B Id'])


# Generated at 2022-06-20 17:02:29.677206
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Acollector:
        required_facts = set()
        name = "ACollector"
    class Bcollector:
        required_facts = set()
        name = "BCollector"
    class Ccollector:
        required_facts = set()
        name = "CCollector"
    class Dcollector:
        required_facts = set()
        name = "DCollector"
    fact_id_to_collector_map = {
        "A": [Acollector],
        "B": [Bcollector],
        "C": [Ccollector],
        "D": [Dcollector],
    }

# Generated at 2022-06-20 17:02:30.817432
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps(['a', 'b'])
    assert e.args[0] == ['a', 'b']


# Generated at 2022-06-20 17:02:33.212854
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    c = BaseFactCollector()
    assert not hasattr(c, 'namespace')
    assert not hasattr(c, 'collectors')
    assert c.fact_ids == set(['GenericFactCollector'])


# Generated at 2022-06-20 17:02:42.781008
# Unit test for function build_dep_data
def test_build_dep_data():
    collectors=[fake_collectors[0], fake_collectors[1], fake_collectors[2], fake_collectors[3],
                fake_collectors[4], fake_collectors[5], fake_collectors[6]]
    dep_map = build_dep_data(['dummy_facts', 'dummy_facts_two', 'dummy_facts_three', 'dummy_facts_four'],
                             get_valid_subsets(collectors))
    assert len(dep_map) == 4 and dep_map['dummy_facts'] == set(['dummy_facts_two']) and \
        dep_map['dummy_facts_three'] == set(['dummy_facts_four']) and \
        dep_map['dummy_facts_four'] == set(['dummy_facts_three'])




# Generated at 2022-06-20 17:02:49.379407
# Unit test for function tsort
def test_tsort():
    class CycleFoundInFactDepsError(BaseException):
        '''Exception for cycles in deps'''

# Generated at 2022-06-20 17:02:55.070870
# Unit test for function tsort
def test_tsort():
    import pytest
    unsorted_map = {'a': set(['b', 'd']), 'b': set(['c', 'e']), 'c': set(), 'd': set(['c', 'e']), 'e': set()}
    sorted_list = tsort(unsorted_map)
    assert sorted_list == [('e', set()), ('c', set()), ('b', set(['c', 'e'])), ('d', set(['c', 'e'])), ('a', set(['b', 'd']))]
    unsorted_map_cycle = {'a': set(['b']), 'b': set(['a']),}
    with pytest.raises(CycleFoundInFactDeps):
        tsort(unsorted_map_cycle)



# Generated at 2022-06-20 17:03:00.498689
# Unit test for function build_dep_data
def test_build_dep_data():
    import ansible.module_utils.facts.collectors.hardware.s390x
    all_fact_subsets = {
        'dmi': [ansible.module_utils.facts.collectors.hardware.dmi.Dmi],
        's390x': [ansible.module_utils.facts.collectors.hardware.s390x.S390x],
    }
    # Example with no duplicates
    collector_names = set(['dmi', 's390x'])
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['dmi'] == set()
    assert dep_map['s390x'] == set()
    # Example with duplicates
    collector_names.add('dmi')
    collector_names.add('s390x')

# Generated at 2022-06-20 17:03:48.017008
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestFactCollector(BaseFactCollector):
        def collect(self,module=None,collected_facts=None):
            return {'test_fact':'test_value'}
    namespace = 'FACTS_'
    fc = TestFactCollector(namespace=namespace)
    assert fc.collect_with_namespace() == {'FACTS_test_fact': 'test_value'}



# Generated at 2022-06-20 17:04:00.357010
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    import unittest.mock as mock
    import pytest

    namespace = mock.MagicMock()

    facts = {'foo': 'bar'}

    collector = BaseFactCollector(namespace=namespace)
    collector._transform_dict_keys = mock.MagicMock(return_value=facts)
    collector.collect = mock.MagicMock(return_value=facts)

    transformed = collector.collect_with_namespace()

    assert transformed == facts
    collector.collect.assert_called_once_with()
    assert collector._transform_dict_keys.called

    # Now try when there is no namespace at all
    collector.namespace = None
    collector._transform_dict_keys.reset_mock()
    collector.collect.reset_mock()

    returned = collector.collect_with_namespace()


# Generated at 2022-06-20 17:04:02.003190
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("test error")
    except CollectorNotFoundError as e:
        if str(e) != "test error":
            raise e



# Generated at 2022-06-20 17:04:11.803202
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': 1, 'b': 2}
    resolved = resolve_requires(['c'], all_fact_subsets)
    assert len(resolved) == 0

    all_fact_subsets = {'a': 1, 'b': 2}
    resolved = resolve_requires(['a'], all_fact_subsets)
    assert len(resolved) == 1
    assert 'a' in resolved
    assert 'b' not in resolved

    all_fact_subsets = {'a': 1}
    resolved = resolve_requires(['a'], all_fact_subsets)
    assert len(resolved) == 1
    assert 'a' in resolved

    all_fact_subsets = {}
    resolved = resolve_requires(['a'], all_fact_subsets)
    assert len

# Generated at 2022-06-20 17:04:13.846596
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    f = BaseFactCollector()
    assert f.name is None


# Generated at 2022-06-20 17:04:18.468778
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert str(e) == '\'foo\''
    else:
        raise AssertionError('Expected exception to be raised')



# Generated at 2022-06-20 17:04:31.136429
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class MockCollector(BaseFactCollector):
        _fact_ids = set()
        name = 'mock'
        required_facts = set(['mock'])

    # No requires
    collector_names = set(['mock_no_requires'])
    all_fact_subsets = {
        'mock_no_requires': [MockCollector],
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Resolved requires
    collector_names = set(['mock_resolved_requires'])
    all_fact_subsets = {
        'mock_resolved_requires': [MockCollector],
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-20 17:04:35.204317
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    assert len(collector_classes_from_gather_subset(all_collector_classes=[])) == 0
    assert len(collector_classes_from_gather_subset(all_collector_classes=[BaseFactCollector])) == 1

# Generated at 2022-06-20 17:04:41.348398
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector(BaseFactCollector):
        '''A class that can be used for testing'''

        name = 'test'

        _fact_ids = ['test2']


    assert collector_classes_from_gather_subset(all_collector_classes=[TestCollector],
                                                valid_subsets=frozenset(['test']),
                                                minimal_gather_subset=frozenset(['test']),
                                                gather_subset=['!test'],
                                                platform_info={'system': 'Generic'}) == []


if __name__ == '__main__':
    test_collector_classes_from_gather_subset()

# Generated at 2022-06-20 17:04:52.693558
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['one'].append(MockCollectorClass)
    all_fact_subsets['two'].append(MockCollectorClass)
    all_fact_subsets['three'].append(MockCollectorClass)
    all_fact_subsets['four'].append(MockCollectorClass)
    all_fact_subsets['five'].append(MockCollectorClass)
    all_fact_subsets['six'].append(MockCollectorClass)
    all_fact_subsets['seven'].append(MockCollectorClass)
    all_fact_subsets['eight'].append(MockCollectorClass)
    collector_names = all_fact_subsets.keys()
    dep_map = build_dep_data

# Generated at 2022-06-20 17:06:28.166846
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector(BaseFactCollector):
        _fact_ids = {'foo'}
        name = 'foo'
        required_facts = {'bar'}


    class FakeCollector2(BaseFactCollector):
        _fact_ids = {'bar'}
        name = 'bar'
        required_facts = set()


    class FakeCollector3(BaseFactCollector):
        _fact_ids = {'baz'}
        name = 'baz'
        required_facts = set()


    collector_set = {FakeCollector, FakeCollector2, FakeCollector3}
    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(collector_set)

# Generated at 2022-06-20 17:06:28.913236
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  assert True


# Generated at 2022-06-20 17:06:30.092402
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    CycleFoundInFactDeps('Exception message expected here')


# Generated at 2022-06-20 17:06:36.920741
# Unit test for function tsort
def test_tsort():
    assert tsort({'a': ('b', 'c'), 'b': ('c',), 'c': ()}) == [
        ('c', ()),
        ('b', ('c',)),
        ('a', ('c', 'b')),
    ]
    assert tsort({'c': ('b', 'a'), 'b': ('c',), 'a': ()}) == [
        ('a', ()),
        ('b', ('c',)),
        ('c', ('b', 'a')),
    ]

    try:
        tsort({'a': ('a',)})
    except CycleFoundInFactDeps as ex:
        assert 'cycle' in ex.args[0]
    else:
        assert 'expected CycleFoundInFactDeps, got nothing.'


# Generated at 2022-06-20 17:06:42.060380
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    unresolved_fact_dep = UnresolvedFactDep(None, None)
    assert (unresolved_fact_dep.fact_name is None)
    assert (unresolved_fact_dep.dependent_fact_name is None)
