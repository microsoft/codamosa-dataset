

# Generated at 2022-06-20 16:57:11.984879
# Unit test for function get_collector_names
def test_get_collector_names():
    # Gather all
    assert get_collector_names(gather_subset=['all']) == frozenset(['min'])
    # Gather all except 'facter'
    assert get_collector_names(gather_subset=['all', '!facter']) == frozenset(['min', 'facter'])
    # Gather all except 'facter' and 'virt'
    assert get_collector_names(gather_subset=['all', '!facter', '!virt']) == frozenset(['min', 'facter', 'virt'])
    # Gather all except 'facter' and 'virt', plus 'network'

# Generated at 2022-06-20 16:57:18.810737
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Test1(BaseFactCollector):
        name = 'Test1'
        _fact_ids = set(['one', 'two'])

    class Test2(BaseFactCollector):
        name = 'Test2'
        _fact_ids = set(['two', 'three'])

    class Test3(BaseFactCollector):
        name = 'Test3'
        _fact_ids = set()

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        [Test1, Test2, Test3])

    assert 'Test1' in fact_id_to_collector_map
    assert 'Test2' in fact_id_to_collector_map
    assert 'Test3' in fact_id_to_collector_map
    assert 'one'

# Generated at 2022-06-20 16:57:26.124074
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    required_facts = {'needs_a': set(),
                      'needs_b': set(['needs_a']),
                      'needs_c': set(),
                      'needs_d': set(['needs_c', 'needs_b']),
                      'needs_e': set(),}
    all_fact_subsets = defaultdict(set, ((f, set([DummyCollector(required_facts=facts)])) for f, facts in required_facts.items()))

    assert find_unresolved_requires(['needs_a', 'needs_c', 'needs_e'], all_fact_subsets) == set()
    assert find_unresolved_requires(['needs_c', 'needs_b'], all_fact_subsets) == set(['needs_a'])

# Generated at 2022-06-20 16:57:33.447188
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['id1'])
        name = 'test1'
    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['id2'])
        name = 'test2'
    platform_info = {'system': 'Linux'}
    collectors_for_platform = find_collectors_for_platform([TestCollector, TestCollector2], [platform_info])
    # test when collectors_for_platform is empty
    assert dict() == build_fact_id_to_collector_map(set())[0]
    # test when collectors_for_platform contain collectors
    assert dict() != build_fact_id_to_collector_map(collectors_for_platform)[0]



# Generated at 2022-06-20 16:57:36.037111
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():

    try:
        raise UnresolvedFactDep('unresolved_fact1')
    except UnresolvedFactDep as e:
        assert type(e) == UnresolvedFactDep
        assert e.args[0] == 'unresolved_fact1'



# Generated at 2022-06-20 16:57:41.624478
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Arrange
    all_collector_classes = [
        (FakeCollector, {'name': 'collector_1', 'required_facts': []}),
        (FakeCollector, {'name': 'collector_2', 'required_facts': ['collector_3']}),
        (FakeCollector, {'name': 'collector_3', 'required_facts': []}),
        (FakeCollector, {'name': 'collector_4', 'required_facts': ['collector_2']})
    ]
    collectors_by_name = {collector.name: collector
                          for collector, _options in all_collector_classes}
    valid_subsets = [name for name, _collector in collectors_by_name.items()]
    minimal_gather_subset = ['collector_1']


# Generated at 2022-06-20 16:57:43.844678
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('a')
    except CollectorNotFoundError as e:
        pass



# Generated at 2022-06-20 16:57:46.339715
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('foo')
    assert str(e) == 'foo'
    assert repr(e) == "CollectorNotFoundError('foo',)"



# Generated at 2022-06-20 16:57:51.266420
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError('fact_name', 'fact_collector')
    assert err.args[0] == "fact_collector not found for fact fact_name"



# Generated at 2022-06-20 16:57:57.585651
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'testCollector'
        def collect(self, module=None, collected_facts=None):
            return {'testFacts': 'testValue'}

    testCollector = TestCollector()
    assert testCollector.collect() == {'testFacts': 'testValue'}


# Generated at 2022-06-20 16:58:06.131039
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as e:
        assert isinstance(e, CycleFoundInFactDeps)


# Generated at 2022-06-20 16:58:12.567495
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    class A(object): pass
    a = A()
    a.name = 'a'
    b = A()
    b.name = 'b'
    resolved = set([a])

    error = UnresolvedFactDep(resolved, [b])
    assert error.resolved == resolved, 'resolved set is wrong: %s' % error.resolved
    assert error.unresolved == [b], 'unresolved set is wrong: %s' % error.unresolved



# Generated at 2022-06-20 16:58:23.953733
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Verify constructor creates error message with fact names
    fact_name = 'my_fact'
    depends_on_fact_name = 'another_fact'
    unresolved_fact_dep = UnresolvedFactDep(fact_name, depends_on_fact_name)
    assert unresolved_fact_dep.args[0].startswith(
        'Fact {0} has a dependency on {1}'.format(
            fact_name, depends_on_fact_name))

    # Verify constructor creates error message with name of non-existent fact
    unresolved_fact_dep = UnresolvedFactDep(fact_name, 'non-existent-fact')
    assert unresolved_fact_dep.args[0].startswith(
        'Fact {0} has a dependency on a non-existent fact: non-existent-fact'.format(
            fact_name))


# Generated at 2022-06-20 16:58:28.443902
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # list of FactCollector classes
    all_collector_classes = [
        class_a,
        class_b,
        class_c,
    ]

    # list of FactCollectors that always run, even if gather_subset is '!all'
    minimal_gather_subsets = [
        'min',
    ]

    # list of FactCollectors we can pick from.
    valid_subsets = [
        'all',
        'hardware',
    ]

    # a dict of information about the platform on which we're gathering facts
    platform_info = {
        'system': 'Linux',
    }

    # a list of FactCollectors that we want to run
    gather_subset = [
        'all',
    ]

    # finally, the function that we want to test
    collector_classes_from

# Generated at 2022-06-20 16:58:33.820419
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    test_collectors = []
    test_namespace = None
    tfc = BaseFactCollector(collectors=test_collectors, namespace=test_namespace)
    test_module = None
    test_collected_facts = None
    result = tfc.collect(module=test_module, collected_facts=test_collected_facts)
    assert(isinstance(result, dict))
    assert(result == {})



# Generated at 2022-06-20 16:58:42.534143
# Unit test for function resolve_requires
def test_resolve_requires():
    class A(BaseFactCollector):
        required_facts = set()

    class B(BaseFactCollector):
        required_facts = set(['c'])

    class C(BaseFactCollector):
        required_facts = set()

    class D(BaseFactCollector):
        required_facts = set(['e', 'f'])

    class E(BaseFactCollector):
        required_facts = set(['f'])

    class F(BaseFactCollector):
        required_facts = set(['e', 'f'])

    all_fact_subsets = {'A': [A], 'B': [B], 'C': [C], 'D': [D], 'E': [E], 'F': [F]}

# Generated at 2022-06-20 16:58:56.418995
# Unit test for function build_dep_data
def test_build_dep_data():
    # Test collection of device facts.
    class CollectDevice(BaseFactCollector):
        name = 'device'
        required_facts = set()

    # Test collection of rpm facts.
    class CollectRpm(BaseFactCollector):
        name = 'rpm'
        required_facts = set()

    # Test collection of grub facts.
    class CollectGrub(BaseFactCollector):
        name = 'grub'
        required_facts = {'device', 'rpm'}

    # Test collection of dpkg facts.
    class CollectDpkg(BaseFactCollector):
        name = 'dpkg'
        required_facts = set()

    # Test collection of grub facts.
    class CollectGrub2(BaseFactCollector):
        name = 'grub2'
        required_facts = {'device', 'dpkg'}

# Generated at 2022-06-20 16:58:57.362572
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    error = CycleFoundInFactDeps()
    assert isinstance(error, CycleFoundInFactDeps)



# Generated at 2022-06-20 16:59:06.964753
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'foo': [object()],
        'bar': [object()],
        'baz': [object()],
        'qux': [object()],
    }
    obj1 = object()
    obj2 = object()
    obj3 = object()
    obj4 = object()
    obj1.required_facts = set(['foo', 'bar'])
    obj2.required_facts = set(['baz', 'qux'])
    obj3.required_facts = set(['qux'])
    resp = build_dep_data(['baz', 'qux'], all_fact_subsets)
    assert resp == {'baz': set(), 'qux': set()}
    all_fact_subsets['spam'] = [obj1]
    all_fact

# Generated at 2022-06-20 16:59:12.395106
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fake_collected_facts = {'gather_facts': 'fake'}

    fc = BaseFactCollector()
    assert len(fc.collect()) == 0
    assert fc.collectors == []
    assert fc.namespace is None

    fc = BaseFactCollector([], 'aprefix_')
    assert len(fc.collect()) == 0
    assert fc.collectors == []
    assert fc.namespace is not None
    assert fc.namespace.transform('something') == 'aprefix_something'

    # we're defaultdict(set) so add values to the returned collector lists
    fc = BaseFactCollector([1, 2, 3])
    fc.collectors.append('a')
    fc.collectors.append('b')
    # now make sure we can collect
   

# Generated at 2022-06-20 16:59:27.105122
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class all_collector1:
        _platform = 'Debian'
        name = 'debian_collector'

    class all_collector2:
        _platform = 'windows'
        name = 'windows_collector'

    class all_collector3:
        _platform = 'Generic'
        name = 'generic_collector'

    class all_collector4:
        _platform = 'linux'
        name = 'linux_collector'

    class all_collector5:
        _platform = 'netbsd'
        name = 'netbsd_collector'

    class compat_platform_1:
        system = 'Linux'
        release = '4.14.25-20.el7.x86_64'

    class compat_platform_2:
        system = 'Windows'
        release = '7'

# Generated at 2022-06-20 16:59:30.780646
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    fc.collect()
    assert True



# Generated at 2022-06-20 16:59:34.266648
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collectors.base as base
    class TestCollector(base.BaseFactCollector):
        name = 'test_collector'

    assert build_fact_id_to_collector_map([TestCollector]) == ({'test_collector': [TestCollector]}, defaultdict(set)), "Collector not in map as expected"


# Generated at 2022-06-20 16:59:47.315612
# Unit test for function tsort
def test_tsort():
    """Tests tsort function
        Test cases:
        1: Test a simple cycle
        2: Test a simple graph with no cycles
        3: Test a graph with multiple cycles
        4: Test previous test case 2 but with the graph inverted
        5: Test a graph with a cycle that includes every node in the graph
    """
    unordered_list = {
        1: [2],
        2: [3],
        3: [4],
        4: [5],
        5: [6],
        6: [7],
        7: [1]
    }

    try:
        tsort(unordered_list)
        assert False
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-20 16:59:56.441517
# Unit test for function build_dep_data
def test_build_dep_data():
    import ansible.module_utils.facts.collectors.system

    all_fact_subsets = {'system': [ansible.module_utils.facts.collectors.system.SystemCollector]}
    dep_map = build_dep_data(['system'], all_fact_subsets)
    assert set(dep_map['system']) == set()
    assert set(dep_map.keys()) == set(['system'])
# End unit test for function build_dep_data



# Generated at 2022-06-20 17:00:07.792497
# Unit test for function resolve_requires
def test_resolve_requires():
    requires = {
        'network': ['all', 'min'],
        'resource': ['all', 'min'],
        'cpu': ['network', 'resource'],
        'mem': ['network', 'resource'],
    }

    # test that 'network' and 'all' are resolved
    unresolved_requires = set(['network', 'all'])
    resolved = resolve_requires(unresolved_requires, requires)
    assert resolved == set(['network'])

    # test that adding 'min' gets us 'all'
    unresolved_requires = set(['network', 'min'])
    resolved = resolve_requires(unresolved_requires, requires)
    assert resolved == set(['all', 'network'])

    # test that adding 'mem' gets us 'network' and 'resource'

# Generated at 2022-06-20 17:00:18.926251
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'devices', 'foo', 'network', 'virtual'])
    aliases_map = {
        'hardware': ['devices', 'dmi'],
        'system': ['virtual'],
    }

    #
    # gather_subset=['!network']
    #
    # should gather 'network' + 'virtual' + 'devices' + 'dmi'
    # should not gather 'network'

    all_facts = get_collector_names(valid_subsets=valid_subsets,
                                    aliases_map=aliases_map)
    assert all_facts == valid_subsets


# Generated at 2022-06-20 17:00:30.333361
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''test we find all expected collectors'''
    from ansible.module_utils.facts import all_collectors

    # pylint: disable=too-few-public-methods
    class TestCollector(BaseFactCollector):
        name = 'test'

        _platform = 'test'

        required_facts = ()

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        _platform = 'test2'

        required_facts = ()

    class AlternateTestCollector(BaseFactCollector):
        name = 'alternate_test'

        required_facts = ()

        _platform = 'alternate_test'

    class BadTestCollector(BaseFactCollector):
        name = 'bad_test'

        required_facts = ()


# Generated at 2022-06-20 17:00:38.976870
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Unit test function test_build_fact_id_to_collector_map'''
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.collectors.network_collector import NetworkCollector

    class TestCollector1(BaseFactCollector):
        '''Class TestCollector1'''
        name = 'test_collector1'
        _fact_ids = set(['test_fact_id1', 'test_fact_id2'])

    class TestCollector2(BaseFactCollector):
        '''Class TestCollector2'''
        name = 'test_collector2'
        _fact_ids = set(['test_fact_id3'])

    class NetworkCollector1(NetworkCollector):
        '''Class NetworkCollector1'''

# Generated at 2022-06-20 17:00:47.391398
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'bar': [object()],
        'baz': [object()],
        'qux': [object()],
    }

    assert resolve_requires(['bar', 'mux', 'qux'], all_fact_subsets) == set(['bar', 'qux'])
    assert resolve_requires(['baz'], all_fact_subsets) == set(['baz'])

    try:
        resolve_requires(['mux', 'qux'], all_fact_subsets)
        assert False
    except UnresolvedFactDep as e:
        assert 'mux' in str(e)



# Generated at 2022-06-20 17:00:57.614868
# Unit test for function build_dep_data
def test_build_dep_data():
    import sys
    from ansible.module_utils.facts import collector
    reload(collector)

    all_fact_subsets = collector.get_collector_classes()

    collector_names = {'RedHat', 'Debian'}
    collector_deps = build_dep_data(collector_names, all_fact_subsets)
    assert collector_deps['RedHat'] == {'Generic', 'Linux'}
    assert collector_deps['Debian'] == {'Linux'}



# Generated at 2022-06-20 17:01:08.238923
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestBaseFactCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_1', 'test_fact_2'])
        name = 'TestBaseFactCollector'
        required_facts = set(['test_fact_1'])

    # Check when none of the collectors are available
    assert not TestBaseFactCollector(collectors=[]).fact_ids
    # Check when one of the collectors are available
    assert TestBaseFactCollector(collectors=[{'test_fact_1': 'test_value'}]).fact_ids == set(['TestBaseFactCollector', 'test_fact_1', 'test_fact_2'])
    # Check when two of the collectors are available

# Generated at 2022-06-20 17:01:11.930666
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError('collector', 'value')
    assert c.args[0] == 'collector'
    assert c.args[1] == 'value'



# Generated at 2022-06-20 17:01:24.553626
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("foo")
    except CollectorNotFoundError as ex:
        assert str(ex) == "foo"

_collectors_1 = defaultdict(defaultdict)

_collectors_2 = defaultdict(defaultdict)

_collectors_1['Linux']['all'].append('fact_cache')
_collectors_1['Linux']['all'].append('hardware')
_collectors_1['Linux']['all'].append('virtual')
_collectors_1['Linux']['all'].append('pkg_mgr')
_collectors_1['Linux']['all'].append('distribution')

_collectors_2['Linux']['all'].append('default')

_collectors_2['FreeBSD']['all'].append('default')

# Generated at 2022-06-20 17:01:37.655238
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    platform_info_linux = {'system': 'Linux'}
    platform_info_vmware = {'system': 'vmware'}
    platform_info_generic = {'system': None}

    class FakeFCLinux(BaseFactCollector):
        _platform = 'Linux'

    class FakeFCVmware(BaseFactCollector):
        _platform = 'vmware'

    class FakeFCGeneric(BaseFactCollector):
        _platform = 'Generic'

    class FakeFCNoMatch(BaseFactCollector):
        _platform = 'ERROR'

    all_collector_classes = [FakeFCLinux, FakeFCVmware, FakeFCNoMatch, FakeFCGeneric]

    # check nothing is returned if no platform info
    platforms = [{'system': None}]

# Generated at 2022-06-20 17:01:40.284698
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test-name')
    assert 'test-name' == e.args[0]



# Generated at 2022-06-20 17:01:42.426380
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test_key')
    except CollectorNotFoundError as ex:
        assert str(ex) == "Unknown collector 'test_key'"



# Generated at 2022-06-20 17:01:48.660815
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('network', 'virtual', 'hardware', 'dns', 'devices', 'dmi'))
    minimal_gather_subset = frozenset(('virtual',))
    aliases_map = defaultdict(set, {'hardware': (set(('devices', 'dmi')))})
    platform_info = {'system': 'Linux'}

    # Test gather_subset 'all'
    gather_subset = ['all']
    assert frozenset(get_collector_names(valid_subsets=valid_subsets,
                                         minimal_gather_subset=minimal_gather_subset,
                                         gather_subset=gather_subset,
                                         aliases_map=aliases_map,
                                         platform_info=platform_info),) == frozenset

# Generated at 2022-06-20 17:02:01.166212
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    import ansible.module_utils.facts.collector.generic
    generic = ansible.module_utils.facts.collector.generic
    import ansible.module_utils.facts.collector.linux
    linux = ansible.module_utils.facts.collector.linux

    from ansible.module_utils.facts.collector import NamespacePrefix
    namespace = NamespacePrefix('test_prefix')

    # namespaced facts
    collectors_list = [generic.Collector(), linux.Collector()]
    namespace_collector = BaseFactCollector(collectors=collectors_list, namespace=namespace)

# Generated at 2022-06-20 17:02:08.976244
# Unit test for function tsort
def test_tsort():
    dep_map = {'foo': set(['bar', 'baz']), 'bar': set(), 'baz': set(['bar'])}
    assert tsort(dep_map) == [('bar', set()), ('baz', {'bar'}), ('foo', {'bar', 'baz'})]

    dep_map = {'foo': set(['bar', 'baz']), 'bar': set(['baz']), 'baz': set()}
    assert tsort(dep_map) == [('baz', set()), ('bar', {'baz'}), ('foo', {'bar', 'baz'})]

    dep_map = {'foo': set(['bar', 'baz']), 'bar': set(['baz']), 'baz': set(['foo', 'bar'])}

# Generated at 2022-06-20 17:02:27.584319
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    tc = TestCollector()
    assert tc.collect_with_namespace() == {'foo': 'bar'}
    tc = TestCollector(namespace=AnsibleFactsNamespace())
    assert tc.collect_with_namespace() == {'ansible_facts': {'foo': 'bar'}}
    tc = TestCollector(namespace=AnsibleFactsNamespace('foo'))
    assert tc.collect_with_namespace() == {'ansible_local': {'foo': {'foo': 'bar'}}}



# Generated at 2022-06-20 17:02:39.013888
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test for single collector
    class TestCollector1(BaseFactCollector):
        name = 'testcollector1'
        _fact_ids = set(['test1'])

    collector_list = [TestCollector1]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_list)
    expected_map = {'testcollector1': [TestCollector1], 'test1': [TestCollector1]}
    assert fact_id_to_collector_map == expected_map
    expected_aliases_map = {'testcollector1': {'test1'}}
    assert aliases_map == expected_aliases_map

    # Test for multiple collectors

# Generated at 2022-06-20 17:02:40.995280
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps("foo")
    assert e.args[0] == 'foo'  # Exception.args is a tuple



# Generated at 2022-06-20 17:02:48.459316
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector as c

    class Collector1(c.BaseFactCollector):
        name = 'collector1'
        _fact_ids = frozenset(['c1'])

    class Collector2(c.BaseFactCollector):
        name = 'collector2'
        _fact_ids = frozenset(['c2'])

    class Collector3(c.BaseFactCollector):
        name = 'collector3'
        _fact_ids = frozenset(['c3a', 'c3b'])

    class Collector4(c.BaseFactCollector):
        name = 'collector4'
        _fact_ids = frozenset(['c2'])

        def platform_match(self, platform_info):
            return None


# Generated at 2022-06-20 17:02:53.220448
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # GIVEN
    fc = BaseFactCollector()
    # WHEN
    f = fc.collect_with_namespace()
    # THEN
    assert not f



# Generated at 2022-06-20 17:02:56.189206
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    obj = CollectorNotFoundError('test')
    assert obj.args == ('test',)


# Generated at 2022-06-20 17:03:00.019534
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    anerror = CollectorNotFoundError('1', '2', '3')
    assert anerror.args == ('1', '2', '3')



# Generated at 2022-06-20 17:03:11.355505
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import GenericDistribution

    compile_time_platform_info = {
        'system': 'Generic',
    }

    class MockGenericDistribution(GenericDistribution):
        '''mock for GenericDistribution

        This has all the same methods, but doesn't use platform.system to decide
        if it's compatible.'''

        _fact_ids = GenericDistribution._fact_ids
        name = GenericDistribution.name
        required_facts = GenericDistribution.required_facts

        @classmethod
        def platform_match(cls, platform_info):
            return cls


# Generated at 2022-06-20 17:03:16.290801
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    base = BaseFactCollector()
    module = None
    collected_facts = None
    facts_dict = base.collect(module,collected_facts)
    assert str(type(facts_dict)) == "<type 'dict'>"



# Generated at 2022-06-20 17:03:21.145974
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'A': [], 'B': [], 'C': []}

    # if all resolved, just return set
    assert resolve_requires({'A'}, all_fact_subsets) == {'A'}

    # if any are unresolved, raise
    with pytest.raises(UnresolvedFactDep):
        resolve_requires({'A', 'D'}, all_fact_subsets)



# Generated at 2022-06-20 17:03:31.657375
# Unit test for function tsort
def test_tsort():
    test_data = {
        'a': {'b'},
        'b': {'c', 'd'},
        'c': {'e', 'f'},
        'd': {'f', 'g'},
        'e': set(),
        'f': set(),
        'g': set(),
    }
    assert tsort(test_data) == [
        ('e', set()),
        ('f', set()),
        ('c', {'e', 'f'}),
        ('g', set()),
        ('d', {'f', 'g'}),
        ('b', {'c', 'd'}),
        ('a', {'b'})
    ]

    test_data['e'] = {'a'}

# Generated at 2022-06-20 17:03:38.323084
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep([('a', 'b'), ('b', 'c')])
    except UnresolvedFactDep as e:
        assert e.args == ([('a', 'b'), ('b', 'c')],)



# Generated at 2022-06-20 17:03:45.576694
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Using default args
    fc = BaseFactCollector.platform_match({})()
    assert fc.collect() == {}
    # Using all args
    fc = BaseFactCollector.platform_match({})()
    assert fc.collect(module={'test': 'me'}, collected_facts=['fact1', 'fact2']) == {}


# Generated at 2022-06-20 17:03:58.020326
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from copy import copy
    from ansible.module_utils.facts.collector.system.generic import GenericFactCollector

    # setup
    task = {}
    module = {}
    collected_facts = {}
    return_value = {}
    base_fact_collector = BaseFactCollector()
    base_fact_collector.collect = MagicMock(return_value=return_value)

    # test when namespace is None
    actual_result = base_fact_collector.collect_with_namespace()
    assert actual_result == return_value
    actual_result = base_fact_collector.collect_with_namespace(module)
    assert actual_result == return_value
    actual_result = base_fact_collector.collect_with_namespace(collected_facts=collected_facts)
    assert actual_result

# Generated at 2022-06-20 17:04:04.439289
# Unit test for function select_collector_classes
def test_select_collector_classes():
    BaseFactCollector1 = type('BaseFactCollector1', (BaseFactCollector,), {'name': 'BaseFactCollector1'})
    BaseFactCollector2 = type('BaseFactCollector2', (BaseFactCollector,), {'name': 'BaseFactCollector2'})
    BaseFactCollector3 = type('BaseFactCollector3', (BaseFactCollector,), {'name': 'BaseFactCollector3'})
    BaseFactCollector4 = type('BaseFactCollector4', (BaseFactCollector,), {'name': 'BaseFactCollector4'})
    BaseFactCollector5 = type('BaseFactCollector5', (BaseFactCollector,), {'name': 'BaseFactCollector5'})

# Generated at 2022-06-20 17:04:15.030636
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collectors

    all_collector_classes = tuple(collectors.all.values())

    fake_platform_info = {'system': 'Generic'}
    found_collectors = find_collectors_for_platform(all_collector_classes, [fake_platform_info])
    assert len(found_collectors) > 0
    assert 'Generic' in [c.__name__ for c in found_collectors]

    fake_platform_info = {'system': 'Linux'}
    found_collectors = find_collectors_for_platform(all_collector_classes, [fake_platform_info])
    assert 'Linux' in [c.__name__ for c in found_collectors]


# Generated at 2022-06-20 17:04:17.757572
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('a cycle exists')
    assert e.args == ('a cycle exists', )



# Generated at 2022-06-20 17:04:24.435794
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # Constructor attempts to use the supplied value in the exception message.
    # Ensure that works as expected.
    try:
        raise CycleFoundInFactDeps('this is a test')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'this is a test'



# Generated at 2022-06-20 17:04:27.650229
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collector = BaseFactCollector()
    module = None
    collected_facts = {}
    assert collector.collect(module, collected_facts) == {}



# Generated at 2022-06-20 17:04:34.463687
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test the case where a cyclic fact dependency exists
    # The expected behavior is to raise a CycleFoundInFactDeps exception
    all_fact_subsets = {
        'collector1': [],
        'collector2': []
    }
    dep_map = {
        'collector1': {'collector2'},
        'collector2': {'collector1'}
    }
    with pytest.raises(CycleFoundInFactDeps):
        tsort(dep_map)

    # Test basic cyclic fact dependency
    # We expect collector1 to be sorted first, then collector2 and collector3
    # to be sorted last (since they depend on collector1)

# Generated at 2022-06-20 17:04:42.491894
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestCollector(BaseFactCollector):
        name = 'test'
    collector = TestCollector()
    assert collector.name == 'test'


# Generated at 2022-06-20 17:04:53.159999
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = dict()
    class_mock1 = MagicMock()
    class_mock1.required_facts = set('class_mock1')
    class_mock2 = MagicMock()
    class_mock2.required_facts = set('class_mock2')
    all_fact_subsets['class_mock1']=[class_mock1]
    all_fact_subsets['class_mock2']=[class_mock2]
    dep_map = build_dep_data(['class_mock1','class_mock2'], all_fact_subsets)
    expected = {'class_mock1': set('class_mock1'), 'class_mock2': set('class_mock2')}
    assert dep_map == expected



# Generated at 2022-06-20 17:05:03.223047
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # No dep
    fact_dep = UnresolvedFactDep('fact_name')
    assert fact_dep.args == ('fact_name', '', '', '')

    # With dep names
    fact_dep = UnresolvedFactDep('fact_name', 'dep1', 'dep2', 'dep3')
    assert fact_dep.args == ('fact_name', 'dep1, dep2, dep3', 'dep1', 'dep2, dep3')

    # With unresolved dep
    fact_dep = UnresolvedFactDep('fact_name', 'dep1', 'dep2', 'dep3', 'dep4')
    assert fact_dep.args == ('fact_name', 'dep1, dep2, dep3, dep4', 'dep1', 'dep2, dep3, dep4')



# Generated at 2022-06-20 17:05:12.041629
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collectors
    collected_facts_class_names = dir(collectors)

    from ansible.module_utils.facts import collectors
    module_utils_collectors_classes = [getattr(collectors, collector_name)
                                       for collector_name
                                       in collected_facts_class_names
                                       if collector_name.endswith('Collector')]

    platform_info = {'system': 'Linux', 'distribution': 'RedHat'}
    collectors_for_platform = find_collectors_for_platform(module_utils_collectors_classes,
                                                           [platform_info,
                                                            {'system': 'Generic'}])

# Generated at 2022-06-20 17:05:14.033443
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError()
    except CollectorNotFoundError as e:
        assert str(e) == "The collector was not found."



# Generated at 2022-06-20 17:05:19.434445
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test some valid subsets
    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['hardware', 'network'])) == set(['network'])

    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['hardware', 'network'])) == set(['network'])

    assert get_collector_names(gather_subset=['network', '!hardware'],
                               valid_subsets=frozenset(['hardware', 'network'])) == set(['network'])

    # Test the error behavior

# Generated at 2022-06-20 17:05:27.561987
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'networking': [NetworkingFactCollector]
    }

    # Needs NetworkingFactCollector
    assert find_unresolved_requires(['platform'], all_fact_subsets) == set(['networking'])

    # Has NetworkingFactCollector
    assert find_unresolved_requires(['networking', 'platform'], all_fact_subsets) == set()



# Generated at 2022-06-20 17:05:31.349468
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    with pytest.raises(KeyError):
        raise CollectorNotFoundError("Testing keyerror")
    with pytest.raises(CollectorNotFoundError):
        raise CollectorNotFoundError("Testing collector not found error")


# Generated at 2022-06-20 17:05:38.708278
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    """
    Unit test for method 'collect_with_namespace' of class 'BaseFactCollector'
    """
    temp = BaseFactCollector()
    temp._fact_ids = set()
    temp._platform = 'Generic'
    temp.name = None
    temp.required_facts = set()

    module = None
    collected_facts = None
    exp_var = {}
    act_var = temp.collect_with_namespace(module, collected_facts)
    assert act_var == exp_var, "Expected {}, but got {}".format(exp_var, act_var)



# Generated at 2022-06-20 17:05:45.940233
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux'

    class Collector2(BaseFactCollector):
        _platform = 'Darwin'
        name = 'macos'

    class Collector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'generic'

    class Collector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'linux2'

    found_collectors = find_collectors_for_platform((Collector, Collector2, Collector3, Collector4),
                                                    (dict(system='Linux'), dict(system='Generic')))
    assert set(x.name for x in found_collectors) == set(('linux', 'generic'))

# Generated at 2022-06-20 17:05:52.463257
# Unit test for function build_dep_data
def test_build_dep_data():
    pass



# Generated at 2022-06-20 17:05:55.878130
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = 'Error message'
    cycle_found = CycleFoundInFactDeps(msg)
    assert cycle_found.args[0] == msg


# Generated at 2022-06-20 17:06:05.711811
# Unit test for function build_dep_data
def test_build_dep_data():

    class CollectA(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class CollectB(BaseFactCollector):
        name = 'B'
        required_facts = {'A', 'C'}

    class CollectC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectD(BaseFactCollector):
        name = 'D'
        required_facts = {'C'}

    all_fact_subsets = {
        'A': [CollectA],
        'B': [CollectB],
        'C': [CollectC],
        'D': [CollectD],
    }


# Generated at 2022-06-20 17:06:17.009642
# Unit test for function tsort
def test_tsort():
    def test_one_tsort(data, expected):
        result = tsort(data)
        assert result == expected

    data = {'a': ('b', 'c'),
            'b': ('c', 'd'),
            'c': ('d',),
            'd': ('e', 'f'),
            'e': ('f',),
            'f': ()}

    expected = [('f', ()),
                ('e', ('f',)),
                ('d', ('e', 'f')),
                ('c', ('d',)),
                ('b', ('c', 'd')),
                ('a', ('b', 'c'))]
    test_one_tsort(data, expected)


# Generated at 2022-06-20 17:06:24.880324
# Unit test for function resolve_requires
def test_resolve_requires():
    # define some fake fact definitions
    FACT = ['B', 'C', 'D']
    A_REQ = ['C', 'D']

    all_fact_subsets = {
        'A': [BaseFactCollector],
        'B': [BaseFactCollector]
    }
    unresolved_requires = set(A_REQ)

    # should add 'C' and 'D'
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set(A_REQ)

    # should add nothing
    unresolved_requires = unresolved_requires - set(A_REQ)
    assert resolve_requires(unresolved_requires, all_fact_subsets) == set()

    # should raise a UnresolvedFactDep
    unresolved_requires = set(FACT)

# Generated at 2022-06-20 17:06:34.538170
# Unit test for function build_dep_data
def test_build_dep_data():
    class collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set()

    class collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = {'collector3'}

    class collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = {'collector1'}

    class collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = {'collector1', 'collector2'}

    class collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = {'collector6'}

    class collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = {'collector7'}

   

# Generated at 2022-06-20 17:06:40.134064
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    import unittest
    self = unittest.TestCase()
    obj = BaseFactCollector()
    x = obj.collect()
    self.assertEqual(x, {})

# Generated at 2022-06-20 17:06:43.547535
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('testing')
    except CycleFoundInFactDeps as e:
        assert "Cycle found in fact collector dependencies" in str(e)
        assert "'testing'" in str(e)



# Generated at 2022-06-20 17:06:48.421425
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('foo')
    assert 'CycleFoundInFactDeps' == e.__class__.__name__
    assert 'foo' == e.args[0]
