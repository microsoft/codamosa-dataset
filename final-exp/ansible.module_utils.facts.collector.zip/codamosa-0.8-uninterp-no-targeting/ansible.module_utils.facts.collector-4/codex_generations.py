

# Generated at 2022-06-20 16:57:08.955575
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts import collector

    class FakeCollector(BaseFactCollector):
        name = 'test_set'
        _fact_ids = ('test1', 'test2')
        required_facts = ('test2', )

    collected_facts = {}

    collector_classes = collector_classes_from_gather_subset(collector_classes = [FakeCollector],
                                                             valid_subsets=set(['all', 'min', 'test_set']),
                                                             minimal_gather_subset=set(['min', 'test2']),
                                                             gather_subset=['min', 'test_set'],
                                                             platform_info=dict(system='Generic'))


# Generated at 2022-06-20 16:57:19.136485
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # similar to tests/unit/modules/system/test_facts.py:TestCollectors, but without the dependency
    # on the actual facts module.
    import ansible.module_utils.facts.collectors.platform
    import ansible.module_utils.facts.collectors.network

    # import all collectors so they register as a side-effect of import
    import ansible.module_utils.facts.collectors

    all_collector_classes = ansible.module_utils.facts.collectors.collector_classes()
    class GenericCollector(BaseFactCollector):
        name = 'generic'
        _fact_ids = {'generic_1'}
        _platform = 'Generic'

    all_collector_classes.append(GenericCollector)


# Generated at 2022-06-20 16:57:30.186220
# Unit test for function build_dep_data
def test_build_dep_data():
    class DepCollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class DepCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class DepCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    all_fact_subsets = {
        'A': [DepCollectorA],
        'B': [DepCollectorB],
        'C': [DepCollectorC],
    }

    deps = build_dep_data(set(['A', 'B', 'C']), all_fact_subsets)
    assert deps == {'A': {'B'}, 'B': {'C'}, 'C': set()}



# Generated at 2022-06-20 16:57:42.892840
# Unit test for function find_collectors_for_platform

# Generated at 2022-06-20 16:57:44.833948
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = "There is a cycle in fact collector deps"
    CycleFoundInFactDeps(msg)


# Generated at 2022-06-20 16:57:47.052678
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('foo', ['bar', 'baz'])
    CollectorNotFoundError('foo', ['bar', 'baz'], {'foo': 'bar'})


# Generated at 2022-06-20 16:57:49.918133
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': ['a.a'],
        'b': ['b.b'],
    }
    unresolved_requires = set(['a', 'b', 'c'])
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert(new_names == set(['a', 'b']))



# Generated at 2022-06-20 16:58:00.962607
# Unit test for function get_collector_names
def test_get_collector_names():
    assert 'all' == get_collector_names(valid_subsets=['hardware'],
                                        gather_subset=['hardware'])
    assert 'all' == get_collector_names(valid_subsets=['hardware'],
                                        gather_subset=['!hardware'])
    assert 'all' == get_collector_names(valid_subsets=['hardware'],
                                        gather_subset=['all'])
    assert 'all' == get_collector_names(valid_subsets=['hardware'],
                                        gather_subset=['!all'])
    assert 'all' == get_collector_names(valid_subsets=['hardware'],
                                        gather_subset=['!all', 'hardware'])
    assert 'all' == get_collector

# Generated at 2022-06-20 16:58:09.516341
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collected_facts = dict([])
    factcollector = BaseFactCollector()
    assert factcollector.collect(collected_facts=collected_facts) == {}, 'collect method of BaseFactCollector class does not work as expected'

    collected_facts = dict([('key1', 'value1')])
    factcollector = BaseFactCollector()
    assert factcollector.collect(collected_facts=collected_facts) == {}, 'collect method of BaseFactCollector class does not work as expected'



# Generated at 2022-06-20 16:58:13.991275
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = {'fake'}

    assert build_fact_id_to_collector_map([FakeCollector]) == ({'fake': [FakeCollector]}, {'fake': {'fake'}})
    assert build_fact_id_to_collector_map([]) == ({}, {})



# Generated at 2022-06-20 16:58:19.702007
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    CycleFoundInFactDeps('foo')


# Generated at 2022-06-20 16:58:33.135575
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names() == {'all'}
    assert get_collector_names(gather_subset=['network']) == {'network'}
    assert get_collector_names(gather_subset=['all', 'network']) == {'all', 'network'}
    assert get_collector_names(gather_subset=['hardware']) == {'devices', 'dmi'}
    assert get_collector_names(gather_subset=['!hardware']) == {'all'}
    assert get_collector_names(gather_subset=['!hardware', 'network', '!all']) == {'network'}
    assert get_collector_names(gather_subset=['!hardware', 'network', '!all', 'foo'])

# Generated at 2022-06-20 16:58:45.267768
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = []

    start = ['a', 'b', 'c', 'd']
    assert set(resolve_requires(start, all_fact_subsets)) == set()

    all_fact_subsets = ['a']
    assert set(resolve_requires(start, all_fact_subsets)) == set(['a'])

    all_fact_subsets = ['a', 'e', 'f']
    assert set(resolve_requires(start, all_fact_subsets)) == set(['a'])

    all_fact_subsets = ['a', 'b', 'e', 'f']
    assert set(resolve_requires(start, all_fact_subsets)) == set(['a', 'b'])


# Generated at 2022-06-20 16:58:47.903369
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    '''test BaseFactCollector'''
    c1 = BaseFactCollector()


# Generated at 2022-06-20 16:58:49.453277
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError("my_collector")
    assert e.message == "Collector not found: 'my_collector'"



# Generated at 2022-06-20 16:58:50.461379
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    msg = "something happened"
    try:
        raise CollectorNotFoundError(msg)
    except CollectorNotFoundError as exc:
        assert exc.args[0] == msg



# Generated at 2022-06-20 16:58:57.804849
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import platform
    import re
    class TestFactCollector(BaseFactCollector):
        pass
    TestFactCollector._platform = platform.system()
    platform_match = TestFactCollector.platform_match(platform_info=platform.uname_result._asdict())
    assert re.search(r'Base.*Fact.*Collector', TestFactCollector.collect_with_namespace.__module__)
    assert len(platform_match.collect_with_namespace()) is 0


# Generated at 2022-06-20 16:59:00.327621
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires(frozenset(['a', 'b']), {'a': 1}) == frozenset(['a'])
    try:
        resolve_requires(frozenset(['a', 'b']), {'a': 1, 'b': 1})
        assert False, 'should fail'
    except UnresolvedFactDep:
        assert True



# Generated at 2022-06-20 16:59:09.491375
# Unit test for function resolve_requires
def test_resolve_requires():
    # Create a test dictionary with some dependencies
    collected_fact_names = set()
    collected_fact_names.add('test_fact_one')
    collected_fact_names.add('test_fact_three')
    collected_fact_names.add('test_fact_four')
    collected_fact_names.add('test_fact_five')

    all_fact_subsets = defaultdict(list)

    test_fact1_requires = set()
    test_fact1_requires.add('test_fact_one')
    test_fact1_requires.add('test_fact_four')
    test_fact1_requires.add('test_fact_five')
    test_fact1_requires.add('test_fact_six')
    test_fact1_requires.add('test_fact_seven')
    test_fact1

# Generated at 2022-06-20 16:59:16.311337
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test with gather_subset as a string
    new_gather_subset = 'network'
    collectors_for_network_subset = collector_classes_from_gather_subset(gather_subset=new_gather_subset)
    assert collectors_for_network_subset[0].name == 'network'

    # Test with gather_subset as a list
    new_gather_subset = ['network']
    collectors_for_network_subset = collector_classes_from_gather_subset(gather_subset=new_gather_subset)
    assert collectors_for_network_subset[0].name == 'network'

    # Test with gather_subset as an empty list
    new_gather_subset = []
    collectors_for_network_subset = collector_classes

# Generated at 2022-06-20 16:59:32.399298
# Unit test for function get_collector_names
def test_get_collector_names():
    import pytest
    from collections import namedtuple

    aliases = defaultdict(set)
    aliases_map = {'hardware': set(['devices', 'dmi', 'dlparam'])}
    aliases.update(aliases_map)
    valid_subsets = frozenset(['all', 'hardware', 'network', 'software', 'virtual', 'facter'])

    test_case = namedtuple('test_case', 'gather_subset all_expected')

# Generated at 2022-06-20 16:59:42.355985
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # pylint: disable=unused-variable, superfluous-parens,too-few-public-methods,function-redefined,arguments-differ,invalid-name
    # this is for a test, so we do not need to adhere to pylint
    from ansible.module_utils.facts import _collector_classes
    collected_facts = {}
    all_collector_classes = tuple(_collector_classes.values())
    collectors_for_platform = find_collectors_for_platform(all_collector_classes,
                                                           [{'system': 'Linux'}])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # TODO: remove name from _fact_ids

# Generated at 2022-06-20 16:59:52.833847
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import sys
    if sys.version_info[:2] == (2, 6):
        return

    import pytest

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['a', 'c'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['a', 'c'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['a', 'c'])

    all_collectors = {'test': TestCollector, 'test2': TestCollector2, 'test3': TestCollector3}


# Generated at 2022-06-20 16:59:57.212148
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'A': [], 'B': [], 'C': [], 'F': [],
        'D': [], 'E': [],
    }

    assert (resolve_requires(['A', 'B', 'C', 'D'], all_fact_subsets) ==
            set(['A', 'B', 'C', 'D']))

    assert (resolve_requires(['A', 'B', 'F'], all_fact_subsets) ==
            set(['A', 'B']))

    # TODO/MAYBE: maybe should be an error instead of a failure?
    try:
        resolve_requires(['F'], all_fact_subsets)
        assert False
    except UnresolvedFactDep:
        pass



# Generated at 2022-06-20 17:00:04.322228
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    """Test case for BaseFactCollector.collect_with_namespace method"""
    obj = BaseFactCollector()
    obj._platform = 'Linux'
    obj.name = "Linux"
    obj.required_facts = set()
    obj.__init__()
    obj.platform_match('Linux')
    obj.collect_with_namespace()
    obj.collect()



# Generated at 2022-06-20 17:00:13.636991
# Unit test for function tsort
def test_tsort():
    import unittest
    class TestTSort(unittest.TestCase):
        # Examples from wikipedia: http://en.wikipedia.org/wiki/Topological_sorting#Examples

        def test_example_1(self):
            graph = {
                5: [11],
                7: [11, 8],
                3: [8, 10],
                11: [2, 9, 10],
                8: [9],
            }

            expected = [
                (3, set([8, 10])),
                (7, set([11, 8])),
                (5, set([11])),
                (11, set([2, 9, 10])),
                (8, set([9])),
            ]
            self.assertItemsEqual(tsort(graph), expected)


# Generated at 2022-06-20 17:00:21.073090
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # mockup
    class all_collector_class_01:
        _platform = 'Generic'
        name = 'general'

    class all_collector_class_02:
        _platform = 'Darwin'
        name = 'osx'

    class all_collector_class_03:
        _platform = 'FreeBSD'
        name = 'freebsd'

    class all_collector_class_04:
        _platform = 'Linux'
        name = 'linux'

    class all_collector_class_05:
        _platform = 'Linux'
        name = 'lala'

    platform_info = {'system': 'Linux', 'distribution': 'RedHat'}
    platform_info_0 = {'system': 'Windows'}

# Generated at 2022-06-20 17:00:23.407145
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact_dep = UnresolvedFactDep('disk')
    assert str(fact_dep) == 'Unresolved dependency \'disk\''



# Generated at 2022-06-20 17:00:33.917373
# Unit test for function tsort
def test_tsort():
    deps_map = {
        'node1': {'node2'},
        'node2': {'node3'},
        'node3': {'node4'},
        'node4': {'node1'},
    }

    try:
        tsort(deps_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps error'
    except CycleFoundInFactDeps:
        pass

    deps_map = {
        'node1': {'node2'},
        'node2': {'node3'},
        'node3': {'node4'},
        'node4': {'node5'},
        'node5': {},
    }

    sorted_list = tsort(deps_map)
    assert list(reversed(sorted_list))

# Generated at 2022-06-20 17:00:44.228759
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = {'c', 'min'}
    class B(BaseFactCollector):
        name = 'b'
        required_facts = {'a', 'min'}
    class C(BaseFactCollector):
        name = 'c'
        required_facts = {'a', 'b', 'min'}
    class D(BaseFactCollector):
        name = 'd'
        required_facts = {'e', 'min'}
    class E(BaseFactCollector):
        name = 'e'
        required_facts = {'c', 'min'}
    all_fact_subsets = {
        klass.name: [klass]
        for klass in [A, B, C, D, E]
    }


# Generated at 2022-06-20 17:01:00.322873
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import virtual

    collectors_for_platform = set([
        virtual.VirtualCollector,
        system.SystemCollector,
        network.NetworkCollector,
    ])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # map of fact ids to list of collector classes
    assert set(fact_id_to_collector_map) == set(['virtual', 'system', 'network'])
    assert set(fact_id_to_collector_map['virtual']) == set([virtual.VirtualCollector])
    assert set

# Generated at 2022-06-20 17:01:09.066568
# Unit test for function select_collector_classes
def test_select_collector_classes():
    platforms = [
        dict(system='Linux'),
        dict(system='Linux', distribution='RedHat'),
        dict(system='Linux', distribution='Ubuntu'),
        dict(system='FreeBSD'),
        dict(system='OpenBSD'),
        dict(system='NetBSD'),
        dict(system='SunOS'),
        dict(system='Darwin'),
        dict(system='Windows'),
        dict(system='HP-UX'),
    ]

    # TODO: this is way more complicated than it is worth.
    # TODO: also, we don't really need all these classes and instances,
    #       since we are only using the name field. We could just
    #       make the name field a class property and use them
    #       directly.

# Generated at 2022-06-20 17:01:19.152405
# Unit test for function get_collector_names
def test_get_collector_names():
    """Unit tests for function get_collector_names
    """
    # Test success with gather_subset=[]
    result = get_collector_names(gather_subset=[],
                                 valid_subsets=frozenset(['all', 'network']),
                                 minimal_gather_subset=frozenset(['min']),
                                 aliases_map=defaultdict(set),
                                 platform_info=None)
    assert result == frozenset(['all']),\
        "gather_subset=[] should produce all facts, got: %s" % result
    # Test success with gather_subset=['network']

# Generated at 2022-06-20 17:01:24.791790
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():

    e = UnresolvedFactDep(['a', 'b'])
    assert(e.args[0] == "Missing fact dependency: a, b")

    e = UnresolvedFactDep(['a'])
    assert(e.args[0] == "Missing fact dependency: a")

_fact_cache = {}


# Generated at 2022-06-20 17:01:36.425547
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(TypeError):
        UnresolvedFactDep()
    with pytest.raises(TypeError):
        UnresolvedFactDep(1)
    with pytest.raises(TypeError):
        UnresolvedFactDep(1, 2)
    with pytest.raises(TypeError):
        UnresolvedFactDep(1, 2, 3)
    UnresolvedFactDep('a', 'b', 'c')
    assert str(UnresolvedFactDep('a', 'b', 'c')) == "b depends on a, c depends on b"
    assert str(UnresolvedFactDep('a', 'b')) == "b depends on a"



# Generated at 2022-06-20 17:01:48.329199
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system.linux import LinuxFactCollector
    from ansible.module_utils.facts.system.generic import GenericFactCollector

    compat_platforms = [{
        'system': 'Linux',
        'release': '1',
    }]

    all_collector_classes = [LinuxFactCollector, GenericFactCollector]

    # find the collectors compatible with the platform we are running on
    collectors_for_platform = find_collectors_for_platform(all_collector_classes, compat_platforms)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert LinuxFactCollector in fact_id_to_collector_map['Linux']
    assert GenericFactCollector in fact_

# Generated at 2022-06-20 17:02:00.176504
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all'], valid_subsets=set(['f1', 'f2'])) == set(['f1', 'f2'])
    assert get_collector_names(gather_subset=['!f1'], valid_subsets=set(['f1', 'f2'])) == set(['f2'])
    assert get_collector_names(gather_subset=['f1'], valid_subsets=set(['f1', 'f2'])) == set(['f1'])
    assert get_collector_names(gather_subset=['!f1'], valid_subsets=set(['f1', 'f2'])) == set(['f2'])

# Generated at 2022-06-20 17:02:05.409115
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    test_obj = BaseFactCollector()
    assert isinstance(test_obj.collect_with_namespace(module=None, collected_facts=None), dict)

    test_obj = BaseFactCollector()
    assert isinstance(test_obj.collect_with_namespace(module=None, collected_facts={"test": "test"}), dict)


# Generated at 2022-06-20 17:02:10.971099
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    base_fact_collector_obj = BaseFactCollector_instance()
    base_fact_collector_obj.collect_with_namespace()



# Generated at 2022-06-20 17:02:12.852431
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test')
    assert str(e) == "'test'"



# Generated at 2022-06-20 17:02:29.357172
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4}
    requires = {'A': {'B', 'D'},
                'B': {'C'},
                'D': {'E'},
                'E': {'B'}}

    def get_requires_by_name(unresolved_requires, all_fact_subsets):
        resolved = set()
        unresolved = set()

        for collector_name in unresolved_requires:
            try:
                resolved.add(all_fact_subsets[collector_name])
            except KeyError:
                unresolved.add(collector_name)

        return resolved, unresolved


# Generated at 2022-06-20 17:02:30.674067
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    error = CollectorNotFoundError('Test fact')
    assert str(error) == "No fact collector for: Test fact"



# Generated at 2022-06-20 17:02:36.125038
# Unit test for function select_collector_classes
def test_select_collector_classes():

    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = set(['A'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = set(['B'])

    class CollectorBa(BaseFactCollector):
        name = 'Ba'
        _fact_ids = set(['Ba', 'B'])

    fact_subsets = {
        'A': [CollectorA],
        'B': [CollectorB, CollectorBa]
    }

    # test one collector, two times
    collector_names = ['A', 'A']
    assert select_collector_classes(collector_names, fact_subsets) == [CollectorA]

    # test one collector, two times
    collector_names = ['A', 'B']
   

# Generated at 2022-06-20 17:02:44.914474
# Unit test for function get_collector_names
def test_get_collector_names():
    # Build the initial setup data
    platform_info = {'system': 'Generic'}
    valid_subsets = frozenset(('foobar', 'baz'))
    minimal_gather_subset = frozenset(('baz',))
    aliases_map = {'foobar': frozenset(('f',))}

    # Test for basic functionality
    gathered_names = get_collector_names(valid_subsets=valid_subsets,
                                         minimal_gather_subset=minimal_gather_subset,
                                         aliases_map=aliases_map,
                                         platform_info=platform_info)
    assert gathered_names == frozenset(('baz',))

    # Test for the 'all' keyword

# Generated at 2022-06-20 17:02:56.484649
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    print("ik")
    import json
    import os
    import sys
    #sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    network = NetworkFactCollector()
    print(json.dumps(network.collect_with_namespace(), indent=2))



# Generated at 2022-06-20 17:02:57.988305
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError("name")



# Generated at 2022-06-20 17:03:02.560623
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError("Test")
    except CollectorNotFoundError as err:
        assert str(err) == 'Collector not found: Test'



# Generated at 2022-06-20 17:03:12.177489
# Unit test for function get_collector_names
def test_get_collector_names():
    # Verify all combinations
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    valid_subsets = frozenset(['all', 'network', 'other', 'something_else', 'test_subset'])
    minimal_subsets = frozenset(['network'])

    # Tests with 'all' or 'min' to start.
    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_subsets,
                               gather_subset=['all']) == valid_subsets
    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_subsets,
                               gather_subset=['min'])

# Generated at 2022-06-20 17:03:20.253053
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    names = ['a', 'b', 'c', 'd']
    sub = {
        'a': ['dep1', 'dep2'],
        'b': ['dep1', 'dep2'],
        'c': ['dep3'],
        'd': ['dep1', 'dep4'],
    }
    new = {}
    for k, v in sub.items():
        new[k] = set(v)
    # test to see if the two dictionaries are equal
    assert new == build_dep_data(names, sub)



# Generated at 2022-06-20 17:03:27.129775
# Unit test for function tsort
def test_tsort():
    # from https://en.wikipedia.org/wiki/Topological_sorting

    # a set of nodes for us to sort
    nodes = {
        'undershorts': ('pants', ),
        'pants': ('shoes', 'belt'),
        'jacket': ('belt', 'shirt'),
        'socks': ('shoes', ),
        'shirt': ('tie', 'belt'),
        'tie': ('jacket', ),
    }

    # build a dependency map
    dep_map = defaultdict(set)
    for node, edges in nodes.items():
        dep_map[node].update(edges)

    # tsort should return a sorted list of values

# Generated at 2022-06-20 17:03:42.210026
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector

    class MyCollector(collector.BaseFactCollector):
        name = 'my_collector'
        required_facts = ['key1']

    # Test with no namespace
    my_collector = MyCollector()
    assert my_collector.name == 'my_collector'
    assert my_collector.fact_ids == set(['my_collector'])
    assert my_collector.required_facts == set(['key1'])

    # Test with a namespace
    class MyNamespace:
        '''a fake namespace class with a transform method'''
        def transform(self, key_name):
            return key_name.upper()

    my_namespace = MyNamespace()
    with_namespace = MyCollector([], my_namespace)
   

# Generated at 2022-06-20 17:03:51.291489
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_collector_classes = [
        CollectorA,
        CollectorB,
        CollectorC,
        CollectorD,
        CollectorE,
        CollectorF,
        CollectorG,
        CollectorH,
        CollectorI,
        CollectorJ,
    ]

    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        primary_name = collector_class.name

        all_fact_subsets[primary_name].append(collector_class)

        for fact_id in collector_class._fact_ids:
            all_fact_subsets[fact_id].append(collector_class)

    # test and validate that when select_collector_classes is run, it doesn't include
    # multiple classes with the same name

# Generated at 2022-06-20 17:03:56.478439
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Test that the return value is an empty dict
    collector = BaseFactCollector()
    collected_result = collector.collect()
    assert isinstance(collected_result, dict)
    assert len(collected_result) == 0

# Unit tests for method collect_with_namespace of class BaseFactCollector

# Generated at 2022-06-20 17:03:57.630093
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collector = BaseFactCollector()
    assert collector.collect() == {}



# Generated at 2022-06-20 17:04:09.906025
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Test with a valid namespace
    namespace = Namespace('foo')
    fact_collector = BaseFactCollector(namespace=namespace)
    # BaseFactCollector.collect should return a dict and BaseFactCollector.collect_with_namespace should transform all the keys of the fact using the namespace
    assert fact_collector.collect_with_namespace() == {'foo.name': None, 'foo.fact_ids': {'name'}}
    assert fact_collector.collect_with_namespace() == fact_collector._transform_dict_keys(fact_collector.collect())

    # Test with a None namespace
    fact_collector = BaseFactCollector()
    # BaseFactCollector.collect should return a dict and BaseFactCollector.collect_with_namespace should not transform any key
    assert fact_collector.collect

# Generated at 2022-06-20 17:04:18.431527
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # function to return new/fresh instance of BaseFactCollector
    def new_BaseFactCollector():
        return BaseFactCollector()
    # test instantiation of BaseFactCollector
    obj = new_BaseFactCollector()
    assert obj
    # test BaseFactCollector.collect() method
    collected_facts = dict()
    obj.collect(collected_facts=collected_facts)
    assert collected_facts



# Generated at 2022-06-20 17:04:23.325266
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError(42)

    assert err.args == (42,)
    assert 'Unknown fact collector' in str(err)
# === END test CollectorNotFoundError ===



# Generated at 2022-06-20 17:04:31.608850
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collectors

    selected_collector_classes = collector_classes_from_gather_subset(
        all_collector_classes=collectors.all_collector_classes,
        valid_subsets=frozenset(['all', 'network', 'min', 'virtual', 'default']),
        minimal_gather_subset=frozenset(['collector_subset_examples']),
        gather_subset=['network', 'min'],
        gather_timeout=5,
        platform_info={'system': 'Generic'}
    )
    collector_names = [x.name for x in selected_collector_classes]
    assert collector_names == ['collector_subset_examples', 'network']



# Generated at 2022-06-20 17:04:40.314075
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestFactCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'a': 'A', 'b': 'B'}

    class TestNamespace:

        def transform(self, key_name):
            return key_name + '_namespaced'

    collector = TestFactCollector()
    # without a namespace
    facts = collector.collect_with_namespace()
    assert len(facts) == 2
    assert facts == {'a': 'A', 'b': 'B'}
    # with a namespace
    facts = collector.collect_with_namespace(namespace=TestNamespace())
    assert len(facts) == 2
    assert facts == {'a_namespaced': 'A', 'b_namespaced': 'B'}

# Generated at 2022-06-20 17:04:52.329913
# Unit test for function get_collector_names
def test_get_collector_names():
    # So we can use the same tests and data for Linux, Solaris and AIX
    # to test that collector names are calculated correctly for these
    # platforms

    class TestPlatform(object):
        def __init__(self, system):
            self.system = system

    if platform.system() == 'Linux':
        test_platforms = [platform.system(), None]
    else:
        test_platforms = [platform.system()]

        # Tests for Linux and Solaris (and AIX)
        test_platforms.append(TestPlatform('Linux'))
        test_platforms.append(TestPlatform('SunOS'))
        test_platforms.append(TestPlatform('AIX'))

    all_sets = ['all', 'network', 'hardware', 'virtual', 'identity']

# Generated at 2022-06-20 17:05:02.131112
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest
    all_fact_subsets = {'name': 'base'}
    result = resolve_requires(['name'], all_fact_subsets)
    assert result == set(['name'])

    result = resolve_requires(['name', 'bad'], all_fact_subsets)
    assert result == set(['name'])

    with pytest.raises(UnresolvedFactDep):
        resolve_requires(['bad'], all_fact_subsets)



# Generated at 2022-06-20 17:05:04.832854
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    c = BaseFactCollector()
    assert isinstance(c, BaseFactCollector)


# Generated at 2022-06-20 17:05:14.518008
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Define a FactCollector class to use with test
    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

    # Define a second unique FactCollector class to use with test
    class TestFactCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set()

    # Create a test set of FactCollector classes
    collectors_for_platform = set([TestFactCollector, TestFactCollector2])

    # Run the code being tested
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # Make assertions about the expected results
    assert 'test' in fact_id_to_collector_map
    assert 'test'

# Generated at 2022-06-20 17:05:26.007283
# Unit test for function build_dep_data
def test_build_dep_data():
    class TestClass(BaseFactCollector):
        name = 'test_class_1'
        required_facts = set(('test_class_2', 'test_class_3'))

    class TestClass2(BaseFactCollector):
        name = 'test_class_2'
        required_facts = set(('test_class_3',))

    class TestClass3(BaseFactCollector):
        name = 'test_class_3'

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test_class_1'].append(TestClass)
    all_fact_subsets['test_class_2'].append(TestClass2)
    all_fact_subsets['test_class_3'].append(TestClass3)


# Generated at 2022-06-20 17:05:36.449848
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import pytest
    from ansibullbot._text_compat import Text

    all_collectors = [
        _MockBaseFactCollector('min')
    ]
    minimal_gather_subset = ['min']

    # gather_subset: all
    valid_subsets = ['min', 'hardware', 'software']
    gathered_classes = collector_classes_from_gather_subset(
        all_collector_classes=all_collectors,
        minimal_gather_subset=minimal_gather_subset,
        valid_subsets=valid_subsets,
        gather_subset=['all']
    )
    assert len(gathered_classes) == 1
    assert isinstance(gathered_classes[0], _MockBaseFactCollector)
    assert gathered_classes[0].name

# Generated at 2022-06-20 17:05:39.917230
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():  # noqa
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps as e:
        assert str(e) == 'Cycle in fact collector dependencies!', str(e)



# Generated at 2022-06-20 17:05:43.085839
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-20 17:05:45.955901
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.name is None


# Generated at 2022-06-20 17:05:50.392312
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    factCollector=BaseFactCollector()
    module={}
    collected_facts={}
    facts_dict={}
    assert factCollector.collect(module=module,collected_facts=collected_facts)==facts_dict


# Generated at 2022-06-20 17:06:03.462159
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class AllCollector(BaseFactCollector):
        name = 'all'

    class GenericCollector(BaseFactCollector):
        name = 'generic'

    class HardwareCollector(BaseFactCollector):
        name = 'hardware'

    class DevicesCollector(BaseFactCollector):
        name = 'devices'
        required_facts = ['all']

    class DmiCollector(BaseFactCollector):
        _fact_ids = ('dmi', 'dmesg')
        name = 'dmi'

    class NetworkCollector(BaseFactCollector):
        name = 'network'
        required_facts = ['all']

    class NetworkGenericIpv4Collector(NetworkCollector):
        name = 'network_ipv4'


# Generated at 2022-06-20 17:06:17.562320
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import types
    import json
    import pytest
    from ansible_collections.community.general.plugins.module_utils.facts import base

    # We are using type, because unittest.mock patched BaseFactCollector.
    # https://github.com/palombo/ansible-modules-core/blob/devel/test/units/module_utils/facts/test_base.py#L32
    # It is not reproduced here, but the unittest.mock patching of BaseFactCollector
    # also patched it for any subclasses, which is not what we want.
    base.BaseFactCollector = type('BaseFactCollector', (base.BaseFactCollector,), {})
    class CollectedFacts(object):
        def __init__(self):
            self.facts = {}

# Generated at 2022-06-20 17:06:27.852192
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'testplatform'
        name = 'testcollector1'

    class Collector2(BaseFactCollector):
        _platform = 'testplatform'
        name = 'testcollector2'

    class Collector3(BaseFactCollector):
        _platform = 'testplatform2'
        name = 'testcollector3'

    class Collector4(BaseFactCollector):
        _platform = 'testplatform3'
        name = 'testcollector4'

    found_collectors = find_collectors_for_platform(
        [Collector1, Collector2, Collector3, Collector4],
        [{'system': 'testplatform'}, {'system': 'testplatform2'}]
    )

# Generated at 2022-06-20 17:06:36.650564
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # A simple class hierarchy
    #   ParentCollectorA
    #        +
    #        |
    #   ChildCollectorC
    #        +
    #        |
    #    ChildCollectorD
    #        +
    #        |
    #   ChildCollectorE
    #        +
    #        |
    #   ChildCollectorF
    #   ParentCollectorB
    class ParentCollectorA(BaseFactCollector):
        name = 'parent_collector_a'
        _fact_ids = set(['a', 'c'])
        required_facts = set(['s'])

    class ChildCollectorC(ParentCollectorA):
        name = 'child_collector_c'
        _fact_ids = set(['c'])
        required_facts = set(['a'])

   

# Generated at 2022-06-20 17:06:40.740146
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with raises(UnresolvedFactDep, match='^unresolved fact dependency: "foo"$'):
        raise UnresolvedFactDep('foo')



# Generated at 2022-06-20 17:06:47.647843
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # pylint: disable=protected-access
    # pylint: disable=no-self-use
    # pylint: disable=too-few-public-methods

    from ansible.module_utils.facts import collector

    class MockCollector1(BaseFactCollector):
        _fact_ids = set()
        name = 'mock1'
        required_facts = set()

    class MockCollector2(BaseFactCollector):
        _fact_ids = set()
        name = 'mock2'
        required_facts = {'mock1'}

    class MockCollector3(BaseFactCollector):
        _fact_ids = set()
        name = 'mock3'
        required_facts = {'mock1', 'mock2'}
