

# Generated at 2022-06-20 16:57:18.762663
# Unit test for function get_collector_names
def test_get_collector_names():
    minimal_gather_subset = frozenset({'system'})
    valid_subsets = frozenset({'minimal', 'system'})
    aliases_map = defaultdict(set, {
        'minimal': frozenset({'min', 'minimal'}),
    })
    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=['system'],
                               aliases_map=aliases_map) == frozenset({'system'})


# Generated at 2022-06-20 16:57:28.604671
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import pytest
    import importlib

    # TODO: probably expand this list
    all_collector_classes = [
        AnsibleCollector,
        AnsibleModulesCollector,
        FacterCollector,
        OhaiCollector,
        PlatformCollector,
        VirtualCollector,
    ]

    minimal_gather_subset = frozenset([
        'ansible',
        'platform',
    ])

    # TODO: expand this list

# Generated at 2022-06-20 16:57:40.288683
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['!foo'],
                               aliases_map=defaultdict(set, {'foo': {'all', 'bar', 'baz'}}),
                               valid_subsets=frozenset(('all', 'foo', 'bar', 'baz', 'quux'))) == frozenset(('quux', 'all', 'foo', 'bar', 'baz'))


##############################################################################
# the following code is used by fact collecting code from the ansible utils collection
# ansible.module_utils.facts.timeout
# and is not used by the ansible codebase directly.
##############################################################################



# Generated at 2022-06-20 16:57:43.653114
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('cycle exists')
    except CycleFoundInFactDeps as e:
        assert str(e) == 'cycle exists'



# Generated at 2022-06-20 16:57:45.809912
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('fact_collector_id')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'fact_collector_id'
        assert e.message == e.args[0]



# Generated at 2022-06-20 16:57:59.894531
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    """
    A unit test to verify that the collector_classes_from_gather_subset method
    returns the correct fact collector names when the different gather_subsets
    are passed.
    """
    class collector(BaseFactCollector):
        required_facts = set()
        _fact_ids = set()

    class network_collector(collector):
        required_facts = set()
        _fact_ids = set()

    class hardware_collector(collector):
        required_facts = set()
        _fact_ids = set()

    class all_collector(collector):
        required_facts = set()
        _fact_ids = set()

    class ohai_collector(collector):
        required_facts = set()
        _fact_ids = set()


# Generated at 2022-06-20 16:58:11.666126
# Unit test for function tsort
def test_tsort():
    # Test graph with a cycle
    graph = {
        1: set([2, 3]),
        2: set([3]),
        3: set([1])
    }
    try:
        tsort(graph)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, "CycleFoundInFactDeps was not raised for cycle"
    # Test graph without cycles
    graph = {
        1: set([2, 3]),
        2: set([3]),
        3: set([4, 7]),
        4: set([5, 6]),
        5: set([]),
        6: set([]),
        7: set([8]),
        8: set([9]),
        9: set([])
    }
    result = tsort(graph)
    result_graph = {}

# Generated at 2022-06-20 16:58:23.725436
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.legacy

    # Given

# Generated at 2022-06-20 16:58:34.606140
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class TestCollector(BaseFactCollector):
        _fact_ids = [
            'test',
            'testdep',
            'testextra',
            'testsecond',
            'testalias',
            'testalias2'
        ]
        required_facts = set([
            'testsecond',
            'testdep'
        ])
        _platform = 'Generic'
        name = 'test'

    class Test2Collector(BaseFactCollector):
        _fact_ids = [
            'testsecond'
        ]
        required_facts = set([
        ])
        _platform = 'Generic'
        name = 'test2'

    class Test3Collector(BaseFactCollector):
        _fact_ids = [
            'test3'
        ]
        required_facts = set([
            'test'
        ])

# Generated at 2022-06-20 16:58:45.845534
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import linux
    from ansible.module_utils.facts import network

    # loopback is a NetworkCollector, and
    # only has the fact_id of 'network'
    all_collector_classes = [network.NetworkCollector,
                             linux.LinuxHardwareCollector,
                             cache.CacheCollector,
                            ]

    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)
        for fact_id in collector_class._fact_ids:
            all_fact_subsets[fact_id].append(collector_class)


# Generated at 2022-06-20 16:58:59.465697
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Select all collectors without a required fact
    # TODO - add a test to select classes with required facts

    # Create a class which inherits the BaseFactCollector class
    class TestCase(BaseFactCollector):
        name = 'name'

    collected_fact_1 = TestCase()
    collected_fact_2 = TestCase()
    collected_fact_3 = TestCase()

    # From the list of collected facts, select the class 'TestCase'
    all_fact_subsets = defaultdict(list)

    all_fact_subsets['name'].append(TestCase)

    assert select_collector_classes(['name'], all_fact_subsets) == [TestCase]



# Generated at 2022-06-20 16:59:06.401120
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'test_set': [], 'test_set1': []}
    unresolved_requires = ['test_set']
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == set(['test_set'])
    unresolved_requires = ['test_set11']
    try:
        resolve_requires(unresolved_requires, all_fact_subsets)
    except UnresolvedFactDep:
        assert True



# Generated at 2022-06-20 16:59:08.503196
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    assert CollectorNotFoundError('test')



# Generated at 2022-06-20 16:59:18.548518
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import local
    all_fact_subsets = local.get_all_fact_subsets()

    assert set(['a']) == find_unresolved_requires(['a'], all_fact_subsets)
    assert set(['b']) == find_unresolved_requires(['a', 'b'], all_fact_subsets)
    assert set(['a']) == find_unresolved_requires(['b', 'a'], all_fact_subsets)
    assert set(['a']) == find_unresolved_requires(['b', 'a'], all_fact_subsets)
    assert set(['b']) == find_unresolved_requires(['a', 'c'], all_fact_subsets)

# Generated at 2022-06-20 16:59:28.228135
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'a': ['aa'],
        'b': ['bb'],
        'c': ['cc']
    }
    unresolved = set(['a', 'b'])
    resolved = resolve_requires(unresolved, all_fact_subsets)
    assert resolved == set(['a', 'b'])

    unresolved = set(['a', 'd'])
    try:
        resolved = resolve_requires(unresolved, all_fact_subsets)
    except UnresolvedFactDep as e:
        assert 'd' in str(e)



# Generated at 2022-06-20 16:59:32.017631
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = 'Failed to resolve collector dependencies.'
    err = CycleFoundInFactDeps(msg)
    assert err.args == (msg,)



# Generated at 2022-06-20 16:59:36.502507
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # No unresolved requires
    collector_names = ['all', 'linux']
    all_fact_subsets = {
        'all': [FakeCollector],
        'linux': [FakeLinuxCollector],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-20 16:59:42.191466
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    '''Test constructor of class CycleFoundInFactDeps'''
    exception = CycleFoundInFactDeps(['foo', 'bar'])
    assert exception.args[0] == ['foo', 'bar']


# Generated at 2022-06-20 16:59:49.379286
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc1 = BaseFactCollector()
    assert fc1.collectors == []
    assert fc1.namespace is None
    assert fc1.fact_ids == set([None])

    fc1 = BaseFactCollector(['c1', 'c2'], 'namespace')
    assert fc1.collectors == ['c1', 'c2']
    assert fc1.namespace == 'namespace'
    assert fc1.fact_ids == set([None])



# Generated at 2022-06-20 17:00:00.087201
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # test data
    fact_id_to_collector_map = defaultdict(list)
    aliases_map = defaultdict(set)

    class CollectorA(BaseFactCollector):
        _platform = 'Generic'
        _fact_ids = set(['a1', 'a2'])
        required_facts = set(['a3'])
    fact_id_to_collector_map['a1'].append(CollectorA)
    fact_id_to_collector_map['a2'].append(CollectorA)
    aliases_map['a1'].add('a2')

    class CollectorB(BaseFactCollector):
        _platform = 'Generic'
        _fact_ids = set(['a1', 'b2'])
    fact_id_to_collector_map['a1'].append

# Generated at 2022-06-20 17:00:22.125147
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import DummyCollector, Test1Collector, Test2Collector

    class Dummy(BaseFactCollector):
        name = 'dummy'
        required_facts = ['dummy']

        def collect(self, module=None, collected_facts=None):
            return {}

    Dummy._fact_ids.update(Dummy.required_facts)
    Dummy._fact_ids.add(Dummy.name)

    collector_names = set()
    collector_names.add('dummy')
    collector_names.add('test1')
    collector_names.add('test2')

# Generated at 2022-06-20 17:00:27.252960
# Unit test for function tsort
def test_tsort():
    input = {'a':['b','c'],
             'b':['c','d'],
             'c':[],
             'd':['e','c'],}
    assert tsort(input) == [ ('c',[]), ('b',['c','d']), ('d',['c','e']), ('a',['b','c']) ]


# Generated at 2022-06-20 17:00:37.048727
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class FactCollectorA(BaseFactCollector):
        _fact_ids = frozenset(['foo'])
        name = 'a'
        required_facts = frozenset(['B'])

    class FactCollectorB(BaseFactCollector):
        _fact_ids = frozenset(['bar'])
        name = 'b'
        required_facts = frozenset(['a'])

    class FactCollectorC(BaseFactCollector):
        _fact_ids = frozenset(['baz'])
        name = 'c'
        required_facts = frozenset(['c'])

    class FactCollectorD(BaseFactCollector):
        _fact_ids = frozenset(['qux'])
        name = 'd'
        required_facts = frozenset(['e'])

   

# Generated at 2022-06-20 17:00:49.493364
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # check for duplicate collectors are removed
    C1 = type('C1', (BaseFactCollector,), {'name': 'test1', '_fact_ids': set(['test1'])})
    C2 = type('C2', (BaseFactCollector,), {'name': 'test2', '_fact_ids': set(['test2', 'test2a'])})

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test1'].append(C1)
    all_fact_subsets['test2'].append(C2)
    all_fact_subsets['test2a'].append(C2)

    collector_names = ['test1', 'test2', 'test2a', 'test1']

# Generated at 2022-06-20 17:01:01.034939
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # No import of other collectors. Just do a basic __init__()
    from ansible.module_utils.facts.collector import BaseFactCollector
    base_fact_collector = BaseFactCollector()
    assert base_fact_collector.namespace is None
    assert base_fact_collector.collectors == []
    assert base_fact_collector.fact_ids == set(['BaseFactCollector'])

    # Check setting collectors and namespace
    from ansible.module_utils.facts.collector import BaseFactNamespace
    base_fact_namespace = BaseFactNamespace(prefix='some_prefix')
    base_fact_collector = BaseFactCollector(collectors=[base_fact_collector], namespace=base_fact_namespace)

# Generated at 2022-06-20 17:01:03.130455
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
   a = CollectorNotFoundError('test')
   assert str(a) == "CollectorNotFoundError('test')"



# Generated at 2022-06-20 17:01:06.734663
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    '''Unit test for method collect of class BaseFactCollector'''
    basefactcollector_instance = BaseFactCollector()
    returned_value = basefactcollector_instance.collect()
    assert returned_value == {}


# Generated at 2022-06-20 17:01:18.226888
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import all_collectors as all_collectors_orig
    import ansible.module_utils.facts.namespace as facts_namespace

    # we mock things that can be mocked
    all_collectors_orig['some_collector'] = all_collectors_orig['dmi'] = mock.Mock()
    all_collectors_orig['some_collector'].name = 'some_collector'
    all_collectors_orig['some_collector']._fact_ids = set()
    all_collectors_orig['some_collector'].required_facts = set(('dmi',))

    all_collectors_orig['dmi'].name = 'dmi'
    all_collectors_orig['dmi']._fact_ids = set()
    all_

# Generated at 2022-06-20 17:01:29.619189
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class SomeFact(BaseFactCollector):
        name = 'some_fact'

    class OtherFact(BaseFactCollector):
        name = 'other_fact'

    some_fact = SomeFact()
    assert some_fact.name == 'some_fact'
    assert some_fact.collect() == {}

    # check that name is set correctly, so that the constructor won't
    # silently skip and set a default name.
    def instantiate_BaseFactCollector():
        return BaseFactCollector()  # pylint: disable=no-value-for-parameter

    try:
        instantiate_BaseFactCollector()
    except ValueError as e:
        assert e.args[0].strip() == 'name is a required class attribute of a FactCollector'

    other_fact = OtherFact([some_fact])
    assert other

# Generated at 2022-06-20 17:01:35.233024
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Ensure the method returns a dictionary
    fact_collector = BaseFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)
    assert result == {}
    return result


# internal methods to ensure we have a namespace object if one was not passed

# Generated at 2022-06-20 17:01:52.227385
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with unresolved collector
    import ansible.module_utils.facts.collector.base

    class TestCollector(ansible.module_utils.facts.collector.base.BaseFactCollector):
        _fact_ids = ('test_collector',)
        required_facts = set(('required_fact',))

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test_collector'].append(TestCollector)
    unresolved = find_unresolved_requires(set(('test_collector', 'required_fact')), all_fact_subsets)
    assert 'required_fact' not in unresolved

    # Test with resolved collector
    unresolved = find_unresolved_requires(set(('test_collector',)), all_fact_subsets)

# Generated at 2022-06-20 17:01:59.022660
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    import pytest

    class DummyClass:
        def __init__(self):
            self.module = None
            self.collected_facts = None

        def collect_with_namespace(self, module=None, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts
            return {
                'test1': 'test1',
                'test2': 'test2'
            }

    dummy_class = DummyClass()
    result = dummy_class.collect_with_namespace(module='module', collected_facts='collected_facts')
    assert result == {'test1': 'test1', 'test2': 'test2'}
    assert dummy_class.module == 'module'
    assert dummy_class.collected_facts == 'collected_facts'



# Generated at 2022-06-20 17:02:08.918469
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'platform': set(),
        'distribution': {'platform'},
        'fqdn': {'hostname'},
        'hostname': {'platform'},
        'lsb': {'platform'},
        'path': set(),
    }

    test_tsorted_list = tsort(dep_map)
    expected_tsorted_list = [
        ('platform', set()),
        ('distribution', {'platform'}),
        ('path', set()),
        ('hostname', {'platform'}),
        ('fqdn', {'hostname'}),
        ('lsb', {'platform'})
    ]

    assert test_tsorted_list == expected_tsorted_list


# Generated at 2022-06-20 17:02:11.772711
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts import collector
    fc = collector.BaseFactCollector()


# Generated at 2022-06-20 17:02:19.696509
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest
    import json

    class TestCollector(BaseFactCollector):
        _platform = 'TestOS'
        name = 'test'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'testfact': 'testvalue'}

    class TestCollector2(BaseFactCollector):
        _platform = 'TestOS'
        name = 'test2'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'testfact2': 'testvalue2'}

    class TestCollector3(BaseFactCollector):
        _platform = 'TestOS'
        name = 'test3'
        required_facts = set()


# Generated at 2022-06-20 17:02:24.600268
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    '''Test CollectorNotFoundError constructor'''
    cnfe = CollectorNotFoundError('test')
    assert cnfe.args == ('test',)


# Generated at 2022-06-20 17:02:27.630630
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class MyFactCollector(BaseFactCollector):
        name = 'mycollector'

    fc = MyFactCollector()
    result = fc.collect_with_namespace()
    assert result == {'mycollector': {}}



# Generated at 2022-06-20 17:02:33.433925
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector_1'
        _fact_ids = set('fact_1', 'fact_2')

    class Collector2(BaseFactCollector):
        name = 'collector_2'
        _fact_ids = set('fact_2', 'fact_3')

    class Collector3(BaseFactCollector):
        name = 'collector_3'
        _fact_ids = set('fact_3', 'fact_4')

    collectors = [Collector1, Collector2, Collector3]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    assert len(fact_id_to_collector_map) == 7

# Generated at 2022-06-20 17:02:42.893399
# Unit test for function tsort
def test_tsort():
    # This is one graph that demonstrates the amazing properties of tsort!
    # it is a cycle (a -> b, b -> c, c -> a) where the cycle is completed with
    # a simple node (d -> e, e -> d, this is a cycle in the original graph as well)
    cycle_one = [('a', set(['b'])),
                 ('b', set(['c'])),
                 ('c', set(['a']))]

    # cycle_two is a simple graph with two cycles, this can be detected without
    # tsort by traditional algorithms.
    cycle_two = [('d', set(['e'])),
                 ('e', set(['d']))]

    # cycle_three is a cycle that has another node that has an explicit edge to
    # the last node in the cycle, this is the tricky one

# Generated at 2022-06-20 17:02:47.778657
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    '''Ensure UnresolvedFactDep behaves like ValueError'''

    def _raise(message):
        raise UnresolvedFactDep(message)

    msg = 'foo'
    try:
        _raise(msg)
    except ValueError as err:
        assert isinstance(err, ValueError)
        assert str(err) == msg
    else:
        raise AssertionError()



# Generated at 2022-06-20 17:03:22.905261
# Unit test for function tsort
def test_tsort():
    # construct a graph with a loop from
    # a -> b -> c -> d -> e -> b
    # and try and sort it
    # it should fail.
    nodes = list('abcde')
    edges = {
        'a': ('b', ),
        'b': ('c', ),
        'c': ('d', ),
        'd': ('e', ),
        'e': ('b', ),
    }

    graph = {}
    for node, successors in edges.items():
        graph[node] = set(successors)

    try:
        tsort(graph)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'expected tsort to fail to resolve a cyclic graph'



# Generated at 2022-06-20 17:03:30.328633
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'a': [BaseFactCollector], 'b': [BaseFactCollector], 'c': [BaseFactCollector], 'd': [BaseFactCollector]}
    all_fact_subsets['a'][0].required_facts = ['b']
    all_fact_subsets['b'][0].required_facts = ['c']
    all_fact_subsets['c'][0].required_facts = ['d']
    all_fact_subsets['d'][0].required_facts = ['a']
    resolved_names = {'a', 'b'}
    dep_map = build_dep_data(resolved_names, all_fact_subsets)
    assert dep_map['a'] == {'b'}
    assert dep_map['b'] == {'c'}
   

# Generated at 2022-06-20 17:03:36.792003
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible_collections.community.general.plugins.module_utils.facts import base
    facts = base.BaseFactCollector()
    assert facts.namespace == None
    assert facts.fact_ids == {None}
    assert facts.name == None
    assert facts._fact_ids == set()
    assert facts.required_facts == {None}
    assert facts.collectors == []


# Generated at 2022-06-20 17:03:41.493886
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('nope')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'nope'


# Generated at 2022-06-20 17:03:48.454945
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''Perform unit test for ansible.module_utils.facts.functions.find_collectors_for_platform'''

    class CollectorDummy(BaseFactCollector):
        _fact_ids = set()
        _platform = 'N/A'
        name = 'dummy'
        required_facts = set()

    class CollectorA(CollectorDummy):
        name = 'A'
        _platform = 'Generic'

    class CollectorB(CollectorDummy):
        name = 'B'
        _platform = 'Generic'

    class CollectorC(CollectorDummy):
        name = 'C'
        _platform = 'Linux'

    class CollectorD(CollectorDummy):
        name = 'D'
        _platform = 'Linux'

    class CollectorE(CollectorDummy):
        name = 'E'

# Generated at 2022-06-20 17:04:00.575712
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest

    class FakeClass(object):
        name = 'fake1'
        required_facts = set()

    class FakeClass2(object):
        name = 'fake2'
        required_facts = set(['fake1'])

    class FakeClass3(object):
        name = 'fake3'
        required_facts = set(['fake4'])

    fake_collector_names = ['fake1', 'fake2', 'fake3', 'fake4']

    all_fact_subsets = {
        'fake1': [FakeClass],
        'fake2': [FakeClass2],
        'fake3': [FakeClass3],
    }

    assert set(find_unresolved_requires(fake_collector_names, all_fact_subsets)) == set(['fake4'])



# Generated at 2022-06-20 17:04:04.383396
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('key')
    except KeyError as e:
        assert str(e) == "Collector 'key' not found"



# Generated at 2022-06-20 17:04:06.370975
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('foo')
    assert str(e) == 'cycle found in fact dependencies: foo'



# Generated at 2022-06-20 17:04:16.987234
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.platform.__init__ import platform_info
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # create 3 collectors, each has a requires of some other collector.
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b', 'c'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c', 'a'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()


# Generated at 2022-06-20 17:04:23.325830
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
  pass


# Generated at 2022-06-20 17:05:01.806319
# Unit test for function get_collector_names
def test_get_collector_names():
    platform_info = dict(system='Linux', python_version='2.7.5', distro=dict(name='Ubuntu', version='18.04.3', id='ubuntu', version_best='18.04.3 LTS (Bionic Beaver)'))
    valid_subsets = frozenset(('all', 'min', 'hardware', 'virtual', 'network', 'identity', 'fips'))
    minimal_gather_subset = frozenset(('min', 'hardware', 'virtual', 'network'))

    # basic tests
    assert get_collector_names(valid_subsets, minimal_gather_subset, ['all', '!min']) == \
           frozenset(['hardware', 'virtual', 'network', 'identity', 'fips'])


# Generated at 2022-06-20 17:05:13.309480
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector(BaseFactCollector):
        name = 'x'
        _platform = 'Linux'

    class Collector2(BaseFactCollector):
        name = 'y'
        _platform = 'FreeBSD'

    class Collector3(BaseFactCollector):
        name = 'z'
        _platform = 'Generic'

    all_collectors = [Collector, Collector2, Collector3]

    plat = {'system': 'Linux'}
    found = find_collectors_for_platform(all_collectors, [plat])
    assert len(found) == 1
    assert Collector in found

    plat2 = {'system': 'FreeBSD'}
    found = find_collectors_for_platform(all_collectors, [plat, plat2])
    assert len(found) == 2
    assert Collector in found
   

# Generated at 2022-06-20 17:05:24.180241
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with a simple subset of facts
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'mounts', 'dmi'])
    ) == frozenset(['network', 'hardware', 'mounts', 'dmi'])

    # Test with a collected_facts containing a subset of facts
    assert get_collector_names(
        gather_subset=['!all', 'dmi'],
        valid_subsets=frozenset(['all', 'network', 'hardware', 'mounts', 'dmi'])
    ) == frozenset(['dmi'])

    # Test with a gathered_facts containing a subset of facts
    # containing some aliases

# Generated at 2022-06-20 17:05:27.417772
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    from ansible.module_utils.facts import CollectorNotFoundError

    try:
        raise CollectorNotFoundError("Test message")
    except CollectorNotFoundError as err:
        assert 'Test message' == err.args[0]


# Generated at 2022-06-20 17:05:37.741286
# Unit test for function resolve_requires
def test_resolve_requires():

    all_fact_subsets = {
        'a': { 'class': 'A' },
        'b': { 'class': 'B' },
        'c': { 'class': 'C' },
        'd': { 'class': 'D' },
    }
    try:
        resolve_requires(['f'], all_fact_subsets)
        assert False, 'Should not get here'
    except UnresolvedFactDep:
        pass

    assert resolve_requires(['b'], all_fact_subsets) == set(['b'])
    assert resolve_requires(['b', 'f'], all_fact_subsets) == set(['b'])
    assert resolve_requires(['d', 'f'], all_fact_subsets) == set(['d'])



# Generated at 2022-06-20 17:05:38.294389
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    pass



# Generated at 2022-06-20 17:05:39.050254
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass

# Generated at 2022-06-20 17:05:42.917358
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # ok if there are no unresolved deps
    collector_classes = [
        BaseCollector1(),
        BaseCollector2(),
        BaseCollector3(),
    ]

    all_fact_subsets = build_fact_id_to_collector_map(collector_classes)
    assert len(find_unresolved_requires(['1', '3', '4', '5'], all_fact_subsets)) == 0


# cycle detection

# Generated at 2022-06-20 17:05:51.048465
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'

        def collect(self, module=None, collected_facts=None):
            return {'foo': 2, 'bar': 3}

    # Create a TestCollector instance
    test_collector = TestCollector()

    # Test collect_with_namespace()
    assert test_collector.collect_with_namespace() == {'foo': 2, 'bar': 3}



# Generated at 2022-06-20 17:06:03.717233
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'foo': [],
        'bar': [],
        'bar_foo': []
    }
    unresolved_requires = {'foo', 'bar'}
    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert(new_names == unresolved_requires)

    assert(resolve_requires({'bar_foo'}, all_fact_subsets) == {'bar_foo'})
    assert(resolve_requires({'foo', 'bar_foo'}, all_fact_subsets) == {'foo', 'bar_foo'})


# Generated at 2022-06-20 17:06:32.629501
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    d=BaseFactCollector()
    facts = {'fact': 'some_fact'}
    assert facts == d.collect_with_namespace(collected_facts=facts)


# Generated at 2022-06-20 17:06:45.412376
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(('all', 'network')), minimal_gather_subset=frozenset(('min',)), gather_subset=['all']) == frozenset(('all', 'network', 'min'))
    assert get_collector_names(valid_subsets=frozenset(('all', 'network')), minimal_gather_subset=frozenset(('min',)), gather_subset=['min']) == frozenset(('min',))
    assert get_collector_names(valid_subsets=frozenset(('all', 'network')), minimal_gather_subset=frozenset(('min',)), gather_subset=['network']) == frozenset(('network',))
    assert get_collector_