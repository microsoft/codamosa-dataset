

# Generated at 2022-06-20 16:57:09.172652
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'A': [],
        'B': [],
        'C': [],
        'D': [],
        'E': [],
        'F': [],
    }
    all_fact_subsets['A'].append(MockCollector('A', ['B', 'D']))
    all_fact_subsets['B'].append(MockCollector('B', ['E']))
    all_fact_subsets['C'].append(MockCollector('C', ['E']))
    all_fact_subsets['D'].append(MockCollector('D', ['C']))
    all_fact_subsets['E'].append(MockCollector('E', []))

# Generated at 2022-06-20 16:57:17.049168
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # 1. Test list of collector_names having duplicates
    #    In this case, duplicates are expected to be removed
    all_fact_subsets = {
        'one'   : [1, 2, 3],
        'two'   : [4, 5, 6],
        'three' : [7, 8, 9]
    }
    collector_names = ['one', 'two', 'three', 'one', 'two', 'three']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert selected_collector_classes == expected_list,\
        "The expected list of collector classes is not same as the actual list"
    # 2. Test good case

# Generated at 2022-06-20 16:57:28.338902
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts import timeout
    data = {
        'c': set(['a', 'b']),
        'b': set(['a', 'f']),
        'a': set(['f']),
        'f': set([]),
        'e': set(['f']),
        'd': set(['a', 'g']),
        'g': set([]),
    }
    result = tsort(data)
    result_names = [x[0] for x in result]
    assert result_names == ['f', 'g', 'a', 'b', 'e', 'd', 'c']



# Generated at 2022-06-20 16:57:30.340504
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    f = BaseFactCollector()
    assert f.collectors == []



# Generated at 2022-06-20 16:57:38.183769
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'a':1, 'b':2}

    c = TestCollector()
    assert c.collect_with_namespace() == {'test_a':1, 'test_b':2}



# Generated at 2022-06-20 16:57:39.626718
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps()
    assert isinstance(err, CycleFoundInFactDeps)
# end of test_CycleFoundInFactDeps()



# Generated at 2022-06-20 16:57:45.212309
# Unit test for function resolve_requires
def test_resolve_requires():
    class Namespace:
        def __init__(self, prefix, max_len):
            self.prefix = prefix
            self.max_len = max_len

        def transform(self, key):
            return '%s%s' % (self.prefix, key[:self.max_len])

    class Collector1(BaseFactCollector):
        _fact_ids = frozenset(['collector1_1', 'collector1_2'])
        name = 'collector1'
        required_facts = frozenset(['collector2_1', 'collector2_2'])

    class Collector2(BaseFactCollector):
        _fact_ids = frozenset(['collector2_1', 'collector2_2'])
        name = 'collector2'

# Generated at 2022-06-20 16:57:50.418308
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    base_fact_collector = BaseFactCollector()
    assert base_fact_collector.name == None
    assert base_fact_collector.required_facts == set()
    assert base_fact_collector.fact_ids == set([None])
    assert base_fact_collector.collectors == []

    new_collector_list = ['test']
    base_fact_collector = BaseFactCollector(new_collector_list)
    assert base_fact_collector.collectors == ['test']


# Generated at 2022-06-20 16:57:54.945427
# Unit test for function get_collector_names
def test_get_collector_names():
    nosubset = frozenset()
    minimal_subset = frozenset(['minimal', 'another'])
    all_subset = frozenset(['minimal', 'another', 'extra', 'one'])
    aliases_map = defaultdict(set, {'hardware': {'devices', 'dmi'},
                                    'software': {'os', 'packages'},
                                    'hardware.network': {'networking'}})


# Generated at 2022-06-20 16:57:57.339060
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('abc')
    assert e.args == ('abc',)



# Generated at 2022-06-20 16:58:22.687061
# Unit test for function resolve_requires
def test_resolve_requires():
    unresolved_requires = [unresolved_requires_1,
            unresolved_requires_2,
            unresolved_requires_3,
            unresolved_requires_4,
            unresolved_requires_5,
            unresolved_requires_6]
    collect_subsets_dicts = [collect_subsets_dict_1,
            collect_subsets_dict_2,
            collect_subsets_dict_3,
            collect_subsets_dict_4,
            collect_subsets_dict_5,
            collect_subsets_dict_6]

# Generated at 2022-06-20 16:58:34.206173
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    def side_effect_calling_collect_with_namespace(module, collected_facts):
        assert module == BaseFactCollector.module_to_pass
        assert collected_facts == BaseFactCollector.collected_facts_to_pass
        return None

    def side_effect_calling_collect(module, collected_facts):
        assert module == BaseFactCollector.module_to_pass
        assert collected_facts == BaseFactCollector.collected_facts_to_pass

    class FakeCollectedFacts(object):
        key_to_change = 'value'

    class FakeNamespace(object):
        def transform(self, key_name):
            return key_name + '_transformed'

    BaseFactCollector.collected_facts_to_pass = FakeCollectedFacts()
    BaseFactCollector.module_to_

# Generated at 2022-06-20 16:58:44.564558
# Unit test for function resolve_requires
def test_resolve_requires():
    fact_id_to_collector_map = {'a': 'a_collector_class',
                                'b': 'b_collector_class',
                                'c': 'c_collector_class'}
    requires = {'b': ['a'], 'c': ['b']}

    discovered = ['a', 'b', 'c']
    while True:
        unresolved = find_unresolved_requires(discovered, requires)
        if not unresolved:
            break
        new_names = resolve_requires(unresolved, fact_id_to_collector_map)
        discovered.extend(new_names)

    assert discovered == ['a', 'b', 'c']



# Generated at 2022-06-20 16:58:57.636906
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # call method without module and without collected_facts
    # expected result: dictionary with key "foo" with value "bar"
    class TestFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {"foo": "bar"}
    tc = TestFactCollector()
    result = tc.collect_with_namespace()
    assert result == {"foo": "bar"}

    # call with collected_facts
    class TestFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            assert collected_facts == {"foo": "bar"}
            return {'bar': "foo"}
    tc = TestFactCollector()
    result = tc.collect_with_namespace(collected_facts={"foo": "bar"})
    assert result

# Generated at 2022-06-20 16:59:07.062954
# Unit test for function resolve_requires
def test_resolve_requires():
    import pytest

    all_fact_subsets = {
        'collector1': [collector_class],
        'collector2': [collector_class],
        'collector3': [collector_class],
        'collector4': [collector_class],
        'collector5': [collector_class],
        'collector6': [collector_class],
        'collector7': [collector_class],
        'collector8': [collector_class],
        'collector9': [collector_class],
        'collector10': [collector_class],
        'collector11': [collector_class],
    }

    collector1 = all_fact_subsets['collector1'][0]

# Generated at 2022-06-20 16:59:07.403706
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    pass



# Generated at 2022-06-20 16:59:17.099313
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        TestClassOne,
        TestClassTwo,
    ]

    platform_info = [
        {'system': 'Generic'},
        {'system': 'Linux'},
        {'system': 'FreeBSD'},
        {'system': 'OpenBSD'},
        {'system': 'NetBSD'},
        {'system': 'Windows'},
        {'system': 'Darwin'},
        {'system': 'SunOS'},
    ]

    found_collectors = find_collectors_for_platform(all_collector_classes, platform_info)
    assert(len(found_collectors) == 2)


# Generated at 2022-06-20 16:59:26.514071
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'has_dep': [],
        'no_dep': [],
    }
    all_fact_subsets['has_dep'] = [type('Dep', (object,), {
        'required_facts': {'no_dep'},
    })]
    all_fact_subsets['no_dep'] = [type('NoDep', (object,), {
        'required_facts': set(),
    })]

    unresolved = set(['has_dep'])
    # this should add no_dep
    new_names = resolve_requires(unresolved, all_fact_subsets)

    assert new_names == {'no_dep'}


# Generated at 2022-06-20 16:59:38.729485
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import sys
    import os
    import unittest
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import get_all_fact_collectors

    # create a 'bad' platform to test with
    class BadPlatformCollector(BaseFactCollector):
        _fact_ids = set(['resource_facts'])
        _platform = 'BadPlatform'
        name = 'resource_facts'
        required_facts = set()

    # create a 'good' platform to test with
    class GoodPlatformCollector(BaseFactCollector):
        _fact_ids = set(['resource_facts'])
        _platform = 'GoodPlatform'
        name = 'resource_facts'
        required_facts = set()


# Generated at 2022-06-20 16:59:49.300148
# Unit test for function tsort
def test_tsort():
    unsorted_map = {'z': set(['a', 'b']),
                    'a': set(['b']),
                    'f': set(['b', 'c', 'd']),
                    'd': set(['x', 'f']),
                    'b': set(['c']),
                    'c': set()}

    assert tsort(unsorted_map) == [('c', set()),
                                   ('z', {'a', 'b'}),
                                   ('a', {'b'}),
                                   ('f', {'b', 'c', 'd'}),
                                   ('b', {'c'}),
                                   ('d', {'x', 'f'})]
    return



# Generated at 2022-06-20 17:00:10.982611
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['collector_a', 'collector_b'], {'collector_a': [MockCollector('collector_a', ['collector_b'])],
                                                                'collector_b': [MockCollector('collector_b', [])]})
    assert dep_map == {'collector_a': {'collector_b'}, 'collector_b': set()}


# Generated at 2022-06-20 17:00:18.790683
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.distribution import Distribution
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.collector.pip import Pip
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgr
    from ansible.module_utils.facts.collector.virtual import Virtual

    all_collector_classes = [Distribution, Network, PkgMgr, Pip, ServiceMgr, Virtual]

    collector_names_with_unresolved_requires = ['network', 'virtual']
    collector_names_without_unresolved_requires = ['full']

    all_fact_subsets = {}

# Generated at 2022-06-20 17:00:29.700166
# Unit test for function tsort
def test_tsort():
    test_deps = {
        'a': set([]),
        'b': set(['a']),
        'c': set(['a']),
        'd': set(['b', 'c', 'e']),
        'e': set(['f']),
        'f': set(['g']),
        'g': set(['h']),
        'h': set(['i']),
        'i': set(['a'])
    }

    sorted_dep_map = tsort(test_deps)

# Generated at 2022-06-20 17:00:38.732379
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class MockClass(BaseFactCollector):
        name = "test"

    class MockClass2(MockClass):
        name = "test2"

    class MockClass3(MockClass):
        name = "test3"

        required_facts = frozenset(['test2'])

    class MockClass4(MockClass):
        name = "test4"

        required_facts = frozenset(['test3'])

    class MockClass5(MockClass):
        name = "test5"

        required_facts = frozenset(['test4'])

    class MockClass6(MockClass):
        name = "test6"

        required_facts = frozenset(['test5'])

    valid_subsets = frozenset(['test'])

# Generated at 2022-06-20 17:00:50.326777
# Unit test for function tsort
def test_tsort():
    unsorted_deps = {
        'namespace_bar_foo': set(),
        'namespace_baz': set(),
        'namespace_qux_quux': {'namespace_baz'},
        'namespace_qux_corge': {'namespace_qux_quux'},
        'namespace_foo': {'namespace_qux_corge', 'namespace_bar_foo'},
        }

# Generated at 2022-06-20 17:01:01.856082
# Unit test for function tsort
def test_tsort():
    # run a bunch of times with different graphs
    for count in range(0, 100):
        # build a random graph
        dep_map = defaultdict(set)
        for factor in range(0, 10):
            for a in range(0, 10):
                for b in range(0, 10):
                    if not a == b:
                        if factor % 2 == 0:
                            dep_map[a].add(b)
                        else:
                            dep_map[b].add(a)
        # ensure no duplicate data
        for a in dep_map:
            assert a not in dep_map[a]

        # check the sort
        sorted_list = tsort(dep_map)
        found_a_dep = {}
        for node, edges in sorted_list:
            found_a_dep[node] = True


# Generated at 2022-06-20 17:01:11.023468
# Unit test for function resolve_requires
def test_resolve_requires():
    fact_id_to_collector_map = {
        'sometest': [BaseFactCollector()],
        'somedeps': [BaseFactCollector()],
    }

    all_fact_subsets = {
        'sometest': [BaseFactCollector(required_facts={'somedeps'})],
    }
    assert resolve_requires(['somedeps'], fact_id_to_collector_map) == set(['somedeps'])
    assert resolve_requires(['somedeps'], all_fact_subsets) == set(['somedeps'])
    unresolved_requires = find_unresolved_requires(['sometest'], all_fact_subsets)
    assert unresolved_requires == set(['somedeps'])

# Generated at 2022-06-20 17:01:22.581594
# Unit test for function get_collector_names
def test_get_collector_names():
    '''simple unit test for get_collector_names'''
    from ansible.module_utils.facts.collector import all_collectors
    all_collector_names = set(c.name for c in all_collectors)

    ret = get_collector_names(minimal_gather_subset=set(['hardware']))
    assert ret == set(['hardware'])

    ret = get_collector_names(minimal_gather_subset=set(['hardware']),
                              aliases_map=defaultdict(set, hardware=set(['dmi'])))
    assert ret == set(['hardware'])


# Generated at 2022-06-20 17:01:24.618240
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep("error")
    except Exception as e:
        assert str(e) == 'error'



# Generated at 2022-06-20 17:01:27.335055
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('test error')
    assert e.args == ('test error',)


# Generated at 2022-06-20 17:01:45.570660
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = set('a b c d'.split())
    all_fact_subsets = {'a': ['dep: b', 'dep: c'],
                        'b': ['dep: c'],
                        'c': [],
                        'd': []}
    res = build_dep_data(collector_names, all_fact_subsets)
    assert res['a'] == {'b', 'c'}
    assert res['b'] == {'c'}
    assert res['c'] == set()
    assert res['d'] == set()



# Generated at 2022-06-20 17:01:58.418889
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    col_a = object()
    col_b = object()
    col_c = object()
    col_d = object()
    col_e = object()

    col_a.name = 'col_a'
    col_b.name = 'col_b'
    col_c.name = 'col_c'
    col_d.name = 'col_d'
    col_e.name = 'col_e'

    col_a.required_facts = set()
    col_b.required_facts = set(['col_c'])
    col_c.required_facts = set()
    col_d.required_facts = set(['col_a', 'col_b', 'col_c'])
    col_e.required_facts = set(['col_c'])

    all_fact_sub

# Generated at 2022-06-20 17:02:08.129082
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases = defaultdict(set)
    aliases['hardware'] = frozenset(['devices', 'dmi'])
    aliases['network'] = frozenset(['interface'])

    assert get_collector_names(valid_subsets=frozenset(['network', 'hardware']),
                               gather_subset=['network'],
                               aliases=aliases) == frozenset(['network'])

    assert get_collector_names(valid_subsets=frozenset(['network', 'hardware']),
                               gather_subset=['network', '!hardware'],
                               aliases=aliases) == frozenset(['network'])


# Generated at 2022-06-20 17:02:18.878971
# Unit test for function build_dep_data
def test_build_dep_data():
    import sys
    import os
    import pytest
    from ansible.module_utils.facts import collector

    def testable_collector_classes():
        yield collector.BaseFactCollector
        yield collector.FactsCollector()
        yield collector.LinuxFactsCollector()
        yield collector.CollectorContainer()

    collector_names = set()
    all_fact_subsets = defaultdict(list)
    for collector_class in testable_collector_classes():
        collector_names.add(collector_class.name)
        all_fact_subsets[collector_class.name].append(collector_class)
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert isinstance(dep_map, dict)

# Generated at 2022-06-20 17:02:20.662055
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    lines = ['a requires b', 'b requires a']
    e = CycleFoundInFactDeps(lines)
    assert e.args == (lines, )



# Generated at 2022-06-20 17:02:23.490576
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fact_collector = BaseFactCollector()
    assert fact_collector.collect() == {}


# Generated at 2022-06-20 17:02:30.640708
# Unit test for function resolve_requires
def test_resolve_requires():
    collector_name = 'tmp'
    all_fact_subsets = {
        'proc': [BaseFactCollector], 'kernel': [BaseFactCollector], 'system': [BaseFactCollector],
        'tmp': [BaseFactCollector], 'last_log': [BaseFactCollector], 'log_size': [BaseFactCollector],
        'distribution': [BaseFactCollector], 'system_uuid': [BaseFactCollector],
    }
    unresolved_requires = {'system', 'distribution'}
    assert resolve_requires(unresolved_requires, all_fact_subsets) == {'distribution', 'system'}



# Generated at 2022-06-20 17:02:36.103760
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(["network", "os", "virtual"]),
                               minimal_gather_subset=frozenset(["network"]),
                               gather_subset=["network"],
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(["network"])

    assert get_collector_names(valid_subsets=frozenset(["network", "os", "virtual"]),
                               minimal_gather_subset=frozenset(["network"]),
                               gather_subset=["os", "virtual"],
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(["os", "virtual"])


# Generated at 2022-06-20 17:02:45.327223
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_collector_classes = [BaseFactCollector, AllFactCollector, TestCollector]
    collector_names = ['all']
    all_fact_subsets = {'all': [BaseFactCollector, AllFactCollector],
                        'AllFactCollector': [AllFactCollector],
                        'TestCollector': [TestCollector]}
    result = select_collector_classes(collector_names, all_fact_subsets)
    assert result == [BaseFactCollector, AllFactCollector]



# Generated at 2022-06-20 17:02:49.792818
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    test_message = "Unit test message"
    obj = CycleFoundInFactDeps(test_message)
    assert obj._message == test_message


# Generated at 2022-06-20 17:03:27.229610
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import unittest

    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = (name,)

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = (name,)

    class Collector3(Collector2):
        name = 'collector3'
        _fact_ids = (name,)

    class Collector4(Collector2):
        name = 'collector4'
        _fact_ids = ('collector4_1', 'collector4_2',)

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = ('collector5_1',)

    def test_collector(lst):
        fact_id_to_collector_map, aliases_map = build

# Generated at 2022-06-20 17:03:37.674948
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(collector_names = ['1','2','3','4','5'], all_fact_subsets =
        {'1':[collector1],'2':[collector2],'3':[collector3],'4':[collector4],'5':[collector5]})
    assert len(dep_map) == 5
    assert dep_map['1'] == {'2'}
    assert dep_map['2'] == {'3'}
    assert dep_map['3'] == set()
    assert dep_map['4'] == {'5'}
    assert dep_map['5'] == set()


# Generated at 2022-06-20 17:03:46.128030
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    test_platform_info = dict(system='Linux')
    test_gather_subset = []
    test_valid_subsets = ['network', 'minimal']
    test_minimal_gather_subset = []
    test_gather_timeout = None

    test_all_collector_classes = [class_obj_collector_linux, class_obj_collector_generic, class_obj_collector_network, class_obj_collector_minimal,]

    # test that no CollectorNotFoundError are thrown

# Generated at 2022-06-20 17:03:47.857563
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('somekey')
    except CollectorNotFoundError as e:
        assert str(e) == 'somekey'
    else:
        assert False



# Generated at 2022-06-20 17:03:51.900843
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('foo')
    except UnresolvedFactDep as e:
        assert str(e) == 'foo'



# Generated at 2022-06-20 17:04:01.880013
# Unit test for function tsort
def test_tsort():
    test_dict = {
        'a': set(['d']),
        'b': set(['d']),
        'c': set(['a', 'b']),
        'd': set(['c']),
    }
    try:
        sorted_list = tsort(test_dict)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, "tsort did not raise CycleFoundInFactDeps on a cyclic graph."
    sorted_list = tsort({
        'a': set(['d']),
        'b': set(['d']),
        'c': set(['a', 'b']),
    })

# Generated at 2022-06-20 17:04:11.596549
# Unit test for function build_fact_id_to_collector_map

# Generated at 2022-06-20 17:04:23.325552
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    fake_collectors = [
        FakeCollector('fake1', ('linux',)),
        FakeCollector('fake2', ('linux', 'darwin',)),
        FakeCollector('fake3', ('generic',)),
        FakeCollector('fake4', ('foo', 'bar', 'baz',)),
    ]

    linux_info = {'system': 'Linux',
                  'platform': 'linux',
                  'distribution': 'ubuntu',
                  'distribution_version': '12.04',
                  'distribution_release': 'precise',
                  'distribution_major_version': '12.04',
                  'machinearch': 'x86_64'}

    darwin_info = {'system': 'Darwin',
                   'platform': 'darwin',
                   'machinearch': 'x86_64'}



# Generated at 2022-06-20 17:04:28.797902
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Test with a single unresolved fact
    e = UnresolvedFactDep('foo')
    assert e.args == ('foo',)
    # Test with multiple unresolved facts
    e = UnresolvedFactDep('foo', 'bar', 'baz')
    assert e.args == ('foo', 'bar', 'baz')



# Generated at 2022-06-20 17:04:40.460620
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Verify that the unresolved_requires list is correct
    class TestCollectorClass1(BaseFactCollector):
        name = 'collector_class_1'
        required_facts = set()

    assert TestCollectorClass1.name == 'collector_class_1'
    assert TestCollectorClass1.required_facts == set()

    class TestCollectorClass2(BaseFactCollector):
        name = 'collector_class_2'
        required_facts = set(['collector_class_3'])

    assert TestCollectorClass2.name == 'collector_class_2'
    assert TestCollectorClass2.required_facts == set(['collector_class_3'])

    class TestCollectorClass3(BaseFactCollector):
        name = 'collector_class_3'

# Generated at 2022-06-20 17:05:52.706363
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class MockCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            self.facts_dict = {}
            return self.facts_dict

    class MockLinuxCollector(MockCollector):
        _platform = 'Linux'
    class MockDarwinCollector(MockCollector):
        _platform = 'Darwin'
    class MockWindowsCollector(MockCollector):
        _platform = 'Windows'

    all_collector_classes = [MockLinuxCollector, MockDarwinCollector, MockWindowsCollector]

    # test with a platform that matches existing collector
    compat_platforms = [({'system': 'Linux'},)]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

# Generated at 2022-06-20 17:06:00.566244
# Unit test for function resolve_requires
def test_resolve_requires():
    from .utils import make_required_facts
    from . import network
    from . import hardware

    all_fact_subsets = make_required_facts(network, hardware)

    unresolved_requires = ['!network', 'os']

    new_names = resolve_requires(unresolved_requires, all_fact_subsets)
    assert new_names == {'network'}



# Generated at 2022-06-20 17:06:11.003337
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.darwin import DarwinFactCollector
    all_collector_classes = (DistributionFactCollector, DarwinFactCollector)
    compat_platforms = [{'system': 'Darwin'}, {'system': 'Generic'}]

    assert find_collectors_for_platform(all_collector_classes,
                                        compat_platforms) == {DarwinFactCollector}



# Generated at 2022-06-20 17:06:12.150477
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    pass


# Generated at 2022-06-20 17:06:15.244978
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with timeout(0.01):
        UnresolvedFactDep('no such module')



# Generated at 2022-06-20 17:06:26.958329
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # this is a short version of valid_subsets from ansible/constants.py
    valid_subsets = {'all', 'min', 'hardware', 'network', 'virtual', 'ohai', 'facter', 'systemd', 'puppet'}
    minimal_gather_subset = {'min'}

    # default gather_subset for unit test is all
    # gather_subset = ['all']
    gather_subset = []

    collectors = []
    collectors.append(FakeCollector('foo'))

    valid_subsets.add('foo')
    minimal_gather_subset.add('foo')

    # gather_subset = ['all', 'min', 'foo']
    gather_subset = ['min', 'foo']
    valid_subsets.add('bar')
    minimal_gather_

# Generated at 2022-06-20 17:06:35.309561
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # pylint: disable=unused-variable,too-few-public-methods,no-self-use
    class A(BaseFactCollector):
        name = 'A'
        _fact_ids = {'_fs_type'}

    class B(BaseFactCollector):
        name = 'B'
        _fact_ids = {'_fs_type'}

    class A_linux(A):
        _platform = 'Linux'

    class B_linux(B):
        _platform = 'Linux'

    class A_freebsd(A):
        _platform = 'FreeBSD'

    class B_freebsd(B):
        _platform = 'FreeBSD'

    # Normal usage

# Generated at 2022-06-20 17:06:44.103573
# Unit test for function select_collector_classes
def test_select_collector_classes():
    tc1 = BaseFactCollector
    tc2 = BaseFactCollector
    tc3 = BaseFactCollector
    classes = [tc1, tc2, tc3]
    subset = {'tc1': [tc1, tc2], 'tc2': [tc2, tc3], 'tc3': [tc3, tc1]}
    fact_ids = ['tc1', 'tc2', 'tc3']
    res = select_collector_classes(fact_ids, subset)
    assert(res == classes)
