

# Generated at 2022-06-20 16:57:09.567882
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from collections import namedtuple
    is_positive = namedtuple('is_positive', 'is_positive')
    is_negative = namedtuple('is_negative', 'is_negative')
    class TestClass(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'val1', 'fact2': 'val2'}
    obj = TestClass()
    assert obj.collect_with_namespace() == {'fact1': 'val1', 'fact2': 'val2'}
    class TestClass(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'fact1': 'val1', 'fact2': 'val2'}
    obj = TestClass(namespace=is_positive)
    assert obj

# Generated at 2022-06-20 16:57:13.716757
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # Testing a method of a base class will also test it in a subclass.
    from ansible.module_utils.facts.virtual.base import BaseFactCollector as VirtualBaseFactCollector

    class TestFactCollector(VirtualBaseFactCollector):
        name = 'foo'

    test_obj = TestFactCollector()
    assert test_obj.collect() == {}



# Generated at 2022-06-20 16:57:19.070168
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    import ansible.module_utils.facts.network.linux as linux_iface
    all_fact_subsets = {
        'network': [linux_iface.LinuxIfconfig, NetworkCollector]
    }

    unresolved = find_unresolved_requires(['network'], all_fact_subsets)
    assert unresolved == set()



# Generated at 2022-06-20 16:57:22.523416
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    collected_facts = {}

    base_fact_collector = BaseFactCollector()
    facts = base_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert {} == facts



# Generated at 2022-06-20 16:57:29.570936
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class AllCollectors:
        name = 'all'
    class Linux:
        name = 'linux'
        _platform = 'Linux'
    class Linux2:
        name = 'linux2'
        _platform = 'Linux'
    class Win32:
        name = 'win32'
        _platform = 'Windows'
    class Win:
        name = 'win'
        _platform = 'Windows'
    class AIX:
        name = 'AIX'
        _platform = 'AIX'
    class AIX2:
        name = 'AIX2'
        _platform = 'AIX'


    all_collectors_classes = set([AllCollectors, Linux, Linux2, Win32, Win, AIX, AIX2])

    linux_platform_info = {'system' : 'Linux'}
    win_

# Generated at 2022-06-20 16:57:36.859250
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Create a class to inherit from BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'TestCollector'

    # The method is supposed to return a dict of facts
    d = TestCollector().collect_with_namespace()
    assert isinstance(d, dict)



# Generated at 2022-06-20 16:57:41.250361
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('Test Message')
    except CollectorNotFoundError as ex:
        assert 'Test Message' in str(ex)
        assert issubclass(ex.__class__, KeyError)



# Generated at 2022-06-20 16:57:50.359232
# Unit test for function get_collector_names
def test_get_collector_names():
    # gather_subset = ['all']
    # valid_subsets = ['foo', 'bar', 'baz', 'min', 'minimal']
    # minimal_gather_subsets = ['minimal']
    assert get_collector_names(valid_subsets=set(['foo', 'bar', 'baz', 'min', 'minimal']),
                               minimal_gather_subset=set(['minimal']),
                               gather_subset=['all']) == set(['foo', 'bar', 'baz', 'minimal'])


# Generated at 2022-06-20 16:57:52.384779
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    msg = 'Collector deps should not contain cycles'
    try:
        raise CycleFoundInFactDeps(msg)
    except CycleFoundInFactDeps as ex:
        assert msg == str(ex), 'test failed because raised exception message does not match'



# Generated at 2022-06-20 16:58:01.709771
# Unit test for function get_collector_names
def test_get_collector_names():
    # This is a direct copy of the error message from the function
    # In the future this message may change, therefore this function
    # should be updated as well.
    expected_error_message = (
        "Bad subset '%s' given to Ansible. "
        "gather_subset options allowed: all, %s" %
        ("bad_subset", ", ".join(sorted(frozenset(["a", "b", "c"]))))
    )
    # Check that a TypeError exception is raised with the expected
    # error message when an unknown subset is given
    try:
        get_collector_names(
            valid_subsets=frozenset(["a", "b", "c"]),
            gather_subset=["bad_subset"],
        )
    except TypeError as error:
        assert error

# Generated at 2022-06-20 16:58:21.474677
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        "a": [BaseFactCollector],
        "b": [BaseFactCollector],
    }

    all_fact_subsets["a"][0].name = "a"
    all_fact_subsets["a"][0].required_facts = set(["b"])

    all_fact_subsets["b"][0].name = "b"
    all_fact_subsets["b"][0].required_facts = set()

    assert set(find_unresolved_requires(["a"], all_fact_subsets)) == set(["b"])



# Generated at 2022-06-20 16:58:34.018861
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class Collector1(BaseFactCollector):
        name = 'collector_1'
    class Collector2(BaseFactCollector):
        name = 'collector_2'
        required_facts = set(['collector_1'])
    class Collector3(BaseFactCollector):
        name = 'collector_3'
    class Collector4(BaseFactCollector):
        name = 'collector_4'
        required_facts = set(['collector_3'])
    class Collector5(BaseFactCollector):
        name = 'collector_5'
        required_facts = set(['collector_2'])
    class Collector6(BaseFactCollector):
        name = 'collector_6'
        required_facts = set(['collector_5'])
    class Collector7(BaseFactCollector):
        name

# Generated at 2022-06-20 16:58:39.648730
# Unit test for function tsort
def test_tsort():
    # create a dependency graph that is a straight line
    # a -> b -> c -> d
    # and then add an edge from d -> c to create a cycle.
    dg = {
        'a': {'b'},
        'b': {'c'},
        'c': {'d'},
        'd': {'c'}
    }
    try:
        tsort(dg)
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-20 16:58:42.318191
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.collectors == []

# unit tests for method 'platform_match' in class BaseFactCollector

# Generated at 2022-06-20 16:58:56.379923
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = ['a']
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        _fact_ids = ['b', 'a']
        name = 'b'
        required_facts = set()

    class CollectorC(BaseFactCollector):
        _fact_ids = ['c']
        name = 'c'
        required_facts = set()

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([CollectorA, CollectorC, CollectorB])

    assert set(fact_id_to_collector_map.keys()) == set(['a', 'b', 'c'])

# Generated at 2022-06-20 16:59:06.629813
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # NOTE: we don't use the all_fact_subsets from ansible for this test

    # build a simple all_fact_subsets
    # each test below adds a different collector to this object
    all_fact_subsets = defaultdict(list)

    # collector 0: no requires
    all_fact_subsets['foo0'].append(_MockCollector('foo0', set()))

    # collector 1: requires 'foo0'
    all_fact_subsets['foo1'].append(_MockCollector('foo1', set(['foo0'])))

    # collector 2: requires 'foo1'
    all_fact_subsets['foo2'].append(_MockCollector('foo2', set(['foo1'])))

    # collector 3: requires 'foo0','foo1','foo2'
    all_fact_

# Generated at 2022-06-20 16:59:14.192841
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''tests that the map is built correctly'''

    class Thing1(BaseFactCollector):
        name = 'thing1'
        _fact_ids = set(('id1', 'id2'))

    class Thing2(BaseFactCollector):
        name = 'thing2'
        _fact_ids = set(('id3', 'id4'))

    class Thing3(BaseFactCollector):
        name = 'thing3'
        _fact_ids = set(('id5',))

    all_collector_classes = (Thing1, Thing2, Thing3)

    # use the same as the find_collectors_for_platform
    compat_platforms = (dict(system='Generic'),)


# Generated at 2022-06-20 16:59:15.112586
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    pass



# Generated at 2022-06-20 16:59:26.649742
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestFactCollector(BaseFactCollector):
        name = 'test_fact_collector'
        def collect(self, module=None, collected_facts=None):
            return {
                'test_fact': 'test_value',
            }

    fc = TestFactCollector()
    assert fc.collect_with_namespace() == {
        'test_fact': 'test_value',
    }

    class Test_transform_name(object):
        def transform(self, key_name):
            return 'namespace_%s' % key_name

    fc = TestFactCollector(namespace=Test_transform_name())
    assert fc.collect_with_namespace() == {
        'namespace_test_fact': 'test_value',
    }



# Generated at 2022-06-20 16:59:32.834597
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo', 'bar')
    except CollectorNotFoundError as e:
        assert str(e) == "fact collector 'foo' not found in list of available fact collectors ['bar']"



# Generated at 2022-06-20 16:59:51.913892
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import all_fact_subsets
    from ansible.module_utils.facts.system import distribution
    from ansible.module_utils.facts.system import dmi
    from ansible.module_utils.facts.system import manufacturer
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system import product_name
    from ansible.module_utils.facts.system import system

    import unittest

    class TestAnsibleFacts(unittest.TestCase):

        def test_select_collector_classes(self):
            # no options
            selected_collector_classes = select_collector_classes(
                ['all'],
                all_fact_subsets
            )


# Generated at 2022-06-20 16:59:55.483093
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    error = UnresolvedFactDep('FactName')
    assert error.fact_name == 'FactName'
    assert str(error) == 'FactName'


# Generated at 2022-06-20 16:59:59.498171
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test this')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'test this'


# Generated at 2022-06-20 17:00:06.593319
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class

    module = None
    collected_facts = {}
    # Check that correct expected result for class BaseFactCollector is returned
    collector = get_collector_class(BaseFactCollector, None)
    actual = BaseFactCollector().collect(module, collected_facts)
    assert actual == {}


# Generated at 2022-06-20 17:00:09.318554
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact_name = "foo"
    dep = "bar"
    error = UnresolvedFactDep(fact_name, dep)

    assert error.fact_name == fact_name
    assert error.fact_dep == dep


# Generated at 2022-06-20 17:00:12.484788
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    my_collector = BaseFactCollector()
    assert my_collector.collect_with_namespace() == {}


# Generated at 2022-06-20 17:00:14.470799
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert e.args[0] == 'test'


# Generated at 2022-06-20 17:00:21.895374
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class GatherSubsetDummy0(object):
        name = 'minimal'
        _fact_ids = ['minimal']

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    class GatherSubsetDummy1(object):
        name = 'standard'
        _fact_ids = ['standard']

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    class GatherSubsetDummy2(object):
        name = 'extended'
        _fact_ids = ['extended']

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    class GatherSubsetDummy3(object):
        name = 'another'
        _fact_ids = ['another', 'yetanother']

# Generated at 2022-06-20 17:00:25.036692
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('a', 'b')
    except ValueError as e:
        assert e.args[0] == 'a requires b but b does not exist'



# Generated at 2022-06-20 17:00:30.426471
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # We initialize with None as collected_facts
    ans = BaseFactCollector().collect()

    assert ans == {}, 'result  is not expected one {} '.format(ans)

    # We initialize with {} as collected_facts
    ans = BaseFactCollector().collect(collected_facts={})

    assert ans == {}, 'result  is not expected one {} '.format(ans)



# Generated at 2022-06-20 17:00:41.165853
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class customFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            return facts_dict

    assert customFactCollector().collect_with_namespace() == {}


# Generated at 2022-06-20 17:00:51.079784
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('test error')


# Dictionary of collector-name:collector-instance
_collectors = dict()

# Dictionary of collector-name:set-of-names-of-dependent-collectors
#
# This is used for sorting the order of the fact collection. The sort
# is topological, so that facts are collected in an order where the
# prerequisites (dependencies) come before the collectors that
# consume them.
_depends_on = defaultdict(set)

# Set of collector names
_known_collectors = set()


# Generated at 2022-06-20 17:00:54.824673
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    test = CollectorNotFoundError('error_msg')
    assert str(test) == 'error_msg'
    assert test.args == ('error_msg',)



# Generated at 2022-06-20 17:00:57.134552
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError(25)
    except Exception as e:
        assert isinstance(e, KeyError)



# Generated at 2022-06-20 17:01:00.333087
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    result = CycleFoundInFactDeps()
    assert result.__class__ == CycleFoundInFactDeps


# Generated at 2022-06-20 17:01:03.005364
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # Test to see if UnresolvedFactDep is able to take and be called with a list
    UnresolvedFactDep(['test1', 'test2'])


# Generated at 2022-06-20 17:01:05.992603
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # The expected behaviour of the method collect is to return an empty dictionary
    assert BaseFactCollector().collect() == {}


# TODO: rename to 'collector_for_platform'

# Generated at 2022-06-20 17:01:16.542920
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    facts_dict = {}
    class MyFactCollector(BaseFactCollector):
        name = 'test_base_fact'
        _fact_ids = set()

        _platform = 'Generic'

        def collect(self, module=None, collected_facts=None):
            #print "module", module
            #print "collected_facts", collected_facts
            facts_dict = {'my_fact':'my_value'}
            return facts_dict
    my_collector = MyFactCollector()
    assert my_collector.collect_with_namespace() == {'my_fact':'my_value'}

# Generated at 2022-06-20 17:01:18.503467
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    c = BaseFactCollector()
    assert c.name == 'base'
    assert c.fact_ids == set(['base'])
    assert c.collect() == {}



# Generated at 2022-06-20 17:01:29.855744
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    print ('in test_BaseFactCollector_collect_with_namespace')
    class testClass1(BaseFactCollector):
        # TODO/FIXME This is not really a good test because
        # BaseFactCollector.collect() does not call self._transform_name()
        # and for that reason, self._transform_name() itself is not tested
        def __init__(self):
            self.namespace = 'test_namespace'
            self.name = 'test_name'
            self.collected_facts = {}
            self.collected_facts['test_name'] = 'Test NAME'
            print ('self.namespace')
            print (self.namespace)
            print (self.name)

        def collect(self, module=None, collected_facts=None):
            return self.collected_facts

    test

# Generated at 2022-06-20 17:01:41.404668
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    err = CollectorNotFoundError('foo')
    assert str(err) == "Collector 'foo' not found"



# Generated at 2022-06-20 17:01:45.371288
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    facts_list = collector_classes_from_gather_subset(gather_subset=['all'])
    assert isinstance(facts_list, list)
    assert len(facts_list) >= 3

    #

# Generated at 2022-06-20 17:01:49.209006
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps
    except CycleFoundInFactDeps:
        exc = CycleFoundInFactDeps()
    assert exc is not None


# Generated at 2022-06-20 17:01:58.857727
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'd': set(['c', 'e']),
        'e': set(['c']),
        'f': set(['g']),
        'h': set(['f']),
        'g': set(['h', 'f']),
    }
    sorted_list = tsort(dep_map)

    seen = []
    for node, edges in sorted_list:
        seen.append(node)
        assert node not in edges

    assert sorted(dep_map.keys()) == sorted(seen)



# Generated at 2022-06-20 17:02:06.249651
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [
            FAKE_COLLECTOR_CLASS('a', required_facts=['b']),
        ],
        'b': [
            FAKE_COLLECTOR_CLASS('b', required_facts=['c']),
        ],
        'c': [
            FAKE_COLLECTOR_CLASS('c', required_facts=set()),
        ],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['c'])



# Generated at 2022-06-20 17:02:09.169590
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    instance = CycleFoundInFactDeps("")
    assert isinstance(instance, CycleFoundInFactDeps)



# Generated at 2022-06-20 17:02:19.232966
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts.collectors import get_collector_classes
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = get_collector_classes(default_collectors)

    all_valid_subsets = frozenset(['all', 'min', 'hardware', 'network', 'virtual'])

    # gather_subset='all' means collect all fact modules
    selected = collector_classes_from_gather_subset(all_collector_classes=all_collector_classes,
                                                    valid_subsets=all_valid_subsets,
                                                    gather_subset=['all'],
                                                    platform_info={'system': 'Linux'})
    # this will find all fact modules, but not anything that requires facter/ohai,
   

# Generated at 2022-06-20 17:02:30.146650
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['hardware', 'network', 'devices'])
    # gather_subset = ['network', '!hardware']
    # gather_subset = ['all', '!hardware']
    # gather_subset = ['hardware', '!all']
    # gather_subset = ['nonexistent']
    # gather_subset = ['!nonexistent']
    # gather_subset = ['!all']
    gather_subset = ['network', 'devices']
    # gather_subset = ['all']
    minimal_gather_subset = frozenset(['network'])
    aliases = {
        'hardware': ['devices', 'dmi'],
    }


# Generated at 2022-06-20 17:02:35.918053
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('all', 'network'),
                               gather_subset=['!all']) == set(['network'])
    assert get_collector_names(valid_subsets=('all', 'network', 'hardware'),
                               minimal_gather_subset=('network',),
                               gather_subset=['!all', 'hardware']) == set(['network', 'hardware'])
    assert get_collector_names(valid_subsets=('all',),
                               gather_subset=['!all', 'network']) == set(['network'])

# Generated at 2022-06-20 17:02:39.463840
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    collectors = []
    namespace = None
    bc = BaseFactCollector(collectors=collectors, namespace=namespace)
    module = None
    collected_facts = None
    ret = bc.collect_with_namespace(module=module, collected_facts=collected_facts)
    assert ret == {}



# Generated at 2022-06-20 17:02:51.242306
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # a simple test that confirms that a basic list is returned
    class Collector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = [name]

    class Collector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = [name]

    class Collector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = [name]

    all_fact_subsets = {
        'test1': [Collector1],
        'test2': [Collector2],
        'test3': [Collector3]
    }

    # make sure its sorted
    assert select_collector_classes(['test1', 'test2', 'test3'], all_fact_subsets) == [Collector1, Collector2, Collector3]

    # test

# Generated at 2022-06-20 17:02:56.687897
# Unit test for function select_collector_classes

# Generated at 2022-06-20 17:03:02.006347
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('fixture test')
    except CycleFoundInFactDeps as e:
        assert e.args[0] == 'fixture test'



# Generated at 2022-06-20 17:03:06.379627
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps(['acc-1', 'acc-2'])
    assert e.args == (['acc-1', 'acc-2'], )



# Generated at 2022-06-20 17:03:12.037323
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector
    found_collectors = collector.find_collectors_for_platform(collector.ALL_COLLECTOR_CLASSES, [{'system':'Generic'}])
    assert(found_collectors)



# Generated at 2022-06-20 17:03:22.304997
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system.system_linux import LinuxFactCollector
    from ansible.module_utils.facts.system.system_sunos import SunOSFactCollector

    collectors_for_platform = (LinuxFactCollector, SunOSFactCollector)
    result = build_fact_id_to_collector_map(collectors_for_platform)

# Generated at 2022-06-20 17:03:24.255740
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    try:
        raise CycleFoundInFactDeps('error')
    except CycleFoundInFactDeps as exc:
        assert str(exc) == 'error'



# Generated at 2022-06-20 17:03:31.494178
# Unit test for function select_collector_classes
def test_select_collector_classes():

    # map of fact subset -> list of collectors for that fact subset
    all_fact_subsets = {}

    # Collectors
    class CollectorA:
        name = 'a'

    class CollectorB:
        name = 'b'

    class CollectorC:
        name = 'c'

    class CollectorD:
        name = 'd'

    class CollectorE:
        name = 'e'

    # Add collectors to the all_fact_subset
    all_fact_subsets['a'] = [CollectorA, CollectorB, CollectorC]
    all_fact_subsets['b'] = [CollectorB, CollectorC]
    all_fact_subsets['c'] = [CollectorC, CollectorD, CollectorE]

    # Test positive case
    collector_names = ['a', 'b']

# Generated at 2022-06-20 17:03:42.340051
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

    import unittest

    all_collector_classes = [PkgMgrFactCollector, DistributionFactCollector]

    fact_id_to_collector_map = {
        'ansible_distribution': [DistributionFactCollector],
        'ansible_distribution_file_parsed': [DistributionFactCollector],
        'ansible_pkg_mgr': [PkgMgrFactCollector],
        'ansible_distribution_release': [DistributionFactCollector, PkgMgrFactCollector],
    }


# Generated at 2022-06-20 17:03:45.433242
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    error = CycleFoundInFactDeps()
    msg = str(error)
    assert 'CycleFoundInFactDeps' in msg



# Generated at 2022-06-20 17:04:08.339248
# Unit test for function tsort
def test_tsort():
    import pytest
    with pytest.raises(CycleFoundInFactDeps):
        tsort({'a': {'b'}, 'b': {'a'}})

    assert tsort({'a': {'b'}}) == [('a', {'b'}), ('b', set())]

    assert tsort({'a': {'b', 'c'}, 'b': {'c'}}) == [('a', {'b', 'c'}), ('b', {'c'}), ('c', set())]



# Generated at 2022-06-20 17:04:16.466037
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # since collect_with_namespace is an abstract method, we only test its exception capturing.
    collector = BaseFactCollector()
    try:
        collector.collect_with_namespace()
    except NotImplementedError:
        pass
    else:
        assert False, 'BaseFactCollector.collect_with_namespace() does not raise NotImplementedError!'


# Generated at 2022-06-20 17:04:25.508773
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class class_to_test(BaseFactCollector):
        _fact_ids = set(["test_fact"])
        name = "test_collector"
        required_facts = set(["test_required_fact"])

    # Create a class to test and verify that class variables are set as expected
    test_class_instance = class_to_test()
    assert hasattr(test_class_instance, 'collectors') == True
    assert hasattr(test_class_instance, 'namespace') == True
    assert test_class_instance.collectors == list()
    assert test_class_instance.namespace == None
    assert test_class_instance.name == "test_collector"
    assert test_class_instance.required_facts == set(["test_required_fact"])
    assert test_class_instance.fact_

# Generated at 2022-06-20 17:04:33.740539
# Unit test for function tsort
def test_tsort():
    # Test case 1 - diamond
    d1 = {'a': set(['b', 'c']),
          'b': set(['d']),
          'c': set(['d']),
          'd': set([]),
         }

    # Test case 2 - cycle
    d2 = {'a': set(['b', 'c']),
          'b': set(['d']),
          'c': set(['d']),
          'd': set(['a']),
         }

    results = {}
    # Test case 1 - diamond
    try:
        results['d1'] = tsort(d1)
    except CycleFoundInFactDeps:
        results['d1'] = False

    # Test case 2 - cycle

# Generated at 2022-06-20 17:04:37.626781
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('a', 'b')
    except UnresolvedFactDep as e:
        assert e.args[0] == 'a'
        assert e.args[1] == 'b'
        assert str(e) == "Unresolved dependency of 'a' on 'b'"



# Generated at 2022-06-20 17:04:50.870892
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with 'all' and 'min'
    assert get_collector_names(gather_subset=['min'],
                               valid_subsets=frozenset(['os', 'network']),
                               minimal_gather_subset=frozenset(['os']),
                               aliases_map=defaultdict(set)) == frozenset(['os'])
    # Test with 'all' and 'min' and aliases
    assert get_collector_names(gather_subset=['min'],
                               minimum_gather_subset=frozenset(['os']),
                               valid_subsets=frozenset(['os', 'network']),
                               aliases_map=defaultdict(set, {'hardware': frozenset(['os', 'network'])})) == frozens

# Generated at 2022-06-20 17:04:55.974338
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Args:
    #   all_collector_classes=None,
    #   valid_subsets=None,
    #   minimal_gather_subset=None,
    #   gather_subset=None,
    #   gather_timeout=None,
    #   platform_info=None

    all_collector_classes = [
        TestFakeCollector,
        FakeCollectorHardware,
        FakeCollectorNetwork,
        FakeCollector,
    ]

    # minimal_gather_subset=frozenset(['all'])

    # valid_subsets=frozenset(['all', 'network'])

    # gather_subset=['all']
    # gather_subset=['network']
    # gather_subset=['!all']
    # gather_subset=['!network']

# Generated at 2022-06-20 17:05:02.931153
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'platform': [BaseFactCollector],
        'network': [BaseFactCollector],
        'hardware': [BaseFactCollector],
        'ohai': [BaseFactCollector]
    }
    collector_names = set(['platform', 'network', 'hardware'])
    result = build_dep_data(collector_names, all_fact_subsets)

    assert (result['platform'] == {'ohai'}
            and result['hardware'] == {'ohai'}
            and result['network'] == {'ohai'})



# Generated at 2022-06-20 17:05:03.857454
# Unit test for function build_dep_data
def test_build_dep_data():
    pass



# Generated at 2022-06-20 17:05:12.286907
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # test collect with no implementation
    collectors = []
    namespace = Namespace('pre')
    base_fact_collector = BaseFactCollector(collectors=collectors, namespace=namespace)
    assert base_fact_collector.collect_with_namespace() == dict()

    # test with implementation
    def collect(self, module=None, collected_facts=None):
        facts_dict = {'test': 'test'}
        facts_dict = self._transform_dict_keys(facts_dict)
        return facts_dict

    setattr(BaseFactCollector, 'collect', collect)
    base_fact_collector = BaseFactCollector(collectors=collectors, namespace=namespace)
    assert base_fact_collector.collect_with_namespace() == {'pre_test': 'test'}



# Generated at 2022-06-20 17:05:35.279152
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Unit test for function get_collector_names'''

    # test 'all', no extra options, no exclusions
    assert get_collector_names(
        valid_subsets=frozenset(['network', 'other']),
        minimal_gather_subset=frozenset(['min_network']),
        gather_subset=['all']) == set(['network', 'other', 'min_network'])

    # test 'min', no exclusions
    assert get_collector_names(
        valid_subsets=frozenset(['network', 'other']),
        minimal_gather_subset=frozenset(['min_network']),
        gather_subset=['min']) == set(['min_network'])

    # test 'min', with an invalid subset

# Generated at 2022-06-20 17:05:39.293798
# Unit test for function resolve_requires
def test_resolve_requires():
    # This can be removed when the function is used in ansible
    all_fact_subsets = {'a': True, 'b': True, 'c': True}
    unresolved_requires = ['a', 'b', 'c', 'd']
    assert resolve_requires(unresolved_requires, all_fact_subsets) == unresolved_requires



# Generated at 2022-06-20 17:05:43.267138
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    all_collector_classes = list(collectors.all_collectors)
    found_collectors = find_collectors_for_platform(all_collector_classes, [{'system': 'Linux'}, {'system': 'Generic'}])
    assert 'distribution' in found_collectors
    assert 'distribution' in found_collectors
    assert 'architecture' in found_collectors



# Generated at 2022-06-20 17:05:54.134313
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ('software', 'hw')
    all_fact_subsets = {
        'software': [MockCollector('software', ('hw', 'os'))],
        'hw': [MockCollector('hw', ('os',))],
        'os': [MockCollector('os', ())],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    collector_names = ('software', 'hw')
    all_fact_subsets = {
        'software': [MockCollector('software', ('hw', 'os', 'foo'))],
        'hw': [MockCollector('hw', ('os',))],
        'os': [MockCollector('os', ())],
    }

# Generated at 2022-06-20 17:06:03.718332
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class MyFactCollector(BaseFactCollector):
        name = 'test_collector_name'
        required_facts = set()
        def collect(self, module=None, collected_facts=None):
            return {'a': 'b'}

    my_collector = MyFactCollector()

    assert my_collector.required_facts == set()
    assert my_collector.name == 'test_collector_name'
    assert my_collector.fact_ids == set(['test_collector_name'])

    facts = my_collector.collect()
    assert facts == {'a': 'b'}



# Generated at 2022-06-20 17:06:16.368701
# Unit test for function get_collector_names
def test_get_collector_names():
    # Setup test data
    module = {}
    module['gather_subset'] = None
    module['gather_network_resources'] = None
    module['gather_timeout'] = 30
    module['namespace'] = 'ansible_'
    module['add_local_facts'] = False
    module['gather_subset'] = ['!all', 'hardware']
    module['gather_network_resources'] = 'yes'

    valid_subsets = ['all', '!all', 'network', 'hardware', 'virtual', 'min']
    minimal_gather_subset = ['min']

    # Execute test
    selected_collectors = get_collector_names(valid_subsets, minimal_gather_subset, module['gather_subset'])

    # Verify results
    assert selected_collectors

# Generated at 2022-06-20 17:06:27.440962
# Unit test for function select_collector_classes
def test_select_collector_classes():
    b1 = BaseFactCollector(name='b1')
    b2 = BaseFactCollector(name='b2')
    b3 = BaseFactCollector(name='b3')
    b4 = BaseFactCollector(name='b4')

    c1 = BaseFactCollector(name='c1', required_facts=['b1'])
    c2 = BaseFactCollector(name='c2', required_facts=['b2'])
    c3 = BaseFactCollector(name='c3', required_facts=['b3'])

    d1 = BaseFactCollector(name='d1', required_facts=['c1', 'b1'])
    d2 = BaseFactCollector(name='d2', required_facts=['c2', 'b2'])
    d3 = BaseFactCo

# Generated at 2022-06-20 17:06:36.514950
# Unit test for function get_collector_names
def test_get_collector_names():
    # no alias, no negation
    assert get_collector_names(
        valid_subsets=frozenset(['hardware', 'logic']),
        minimal_gather_subset=frozenset(['hardware', 'network']),
        gather_subset=['logic'],
        aliases_map=defaultdict(set),
        platform_info=None) == set(['logic'])

    # negation, no alias

# Generated at 2022-06-20 17:06:46.455611
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # In this example, anonymous_collector_a and anonymous_collector_b have
    # no collector_name but discoverable by the requirement of collector_a
    # on it and collector_b.
    anonymous_collector_a = BaseFactCollector()
    anonymous_collector_a.name = None
    anonymous_collector_a.required_facts = set()

    anonymous_collector_b = BaseFactCollector()
    anonymous_collector_b.name = None
    anonymous_collector_b.required_facts = set()

    collector_a = BaseFactCollector()
    collector_a.name = 'collector_a'
    collector_a.required_facts = {'collector_d'}

    collector_b = BaseFactCollector()
    collector_b.name = 'collector_b'
   