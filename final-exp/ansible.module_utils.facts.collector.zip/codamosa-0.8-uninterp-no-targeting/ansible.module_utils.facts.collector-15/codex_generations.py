

# Generated at 2022-06-20 16:57:10.727831
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    with pytest.raises(CycleFoundInFactDeps):
        raise CycleFoundInFactDeps()


# Generated at 2022-06-20 16:57:17.981204
# Unit test for function get_collector_names
def test_get_collector_names():
    assert set(get_collector_names(['foo'])) == set(['foo'])
    assert set(get_collector_names(['bar', 'foo'])) == set(['foo', 'bar'])
    assert set(get_collector_names(['bar', 'foo', 'baz'])) == set(['foo', 'bar', 'baz'])
    assert set(get_collector_names(['baz'], subset=['foo'])) == set(['foo', 'baz'])
    assert set(get_collector_names(['baz'], subset=['!foo'])) == set(['baz'])
    assert set(get_collector_names(['baz'], subset=['!foo', '!bar', '!baz'])) == set()

# Generated at 2022-06-20 16:57:29.830694
# Unit test for function tsort
def test_tsort():
    graph = dict(
        a = 'bcd',
        b = 'cde',
        c = 'e',
        d = '',
        e = '',
        )
    sorted_list = tsort(dict((k, set(v)) for k,v in graph.items()))
    assert sorted_list == [
          ('a', set(['b', 'c', 'd'])),
          ('d', set([])),
          ('b', set(['c', 'd', 'e'])),
          ('e', set([])),
          ('c', set(['e'])),
          ]
    # self cycling
    graph['e'] = 'e'

# Generated at 2022-06-20 16:57:42.761020
# Unit test for function get_collector_names
def test_get_collector_names():
    assert frozenset(get_collector_names(platform_info={},
                                         valid_subsets=frozenset(['all', 'network', 'config', 'hardware']),
                                         minimal_gather_subset=frozenset(['config']),
                                         aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                                         gather_subset=['!network'])) == frozenset(['config', 'hardware', 'devices', 'dmi'])

    # for gather_subset=['!all'] we will still collect chosen minimal_gather_subset

# Generated at 2022-06-20 16:57:49.011335
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TC(BaseFactCollector):
        name='tc'
        _fact_ids = ['tc1', 'tc2']
        platform = 'Linux'
    class Fc(BaseFactCollector):
        name = 'fc'
        _fact_ids = frozenset(['fc1', 'fc2'])
        platform = 'Linux'

    res1, aliases_map1 = build_fact_id_to_collector_map([TC, Fc])
    assert res1['tc'] == [TC]
    assert res1['fc'] == [Fc]
    assert aliases_map1['tc'] == set(['tc1', 'tc2'])
    assert aliases_map1['fc'] == set(['fc1', 'fc2'])
    assert res1['tc1'] == [TC]

# Generated at 2022-06-20 16:58:00.690175
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'subset1'
        _fact_ids = {'subset1', 'subset2', 'subset3'}
    class Collector2(BaseFactCollector):
        name = 'subset2'
        _fact_ids = {'subset1', 'subset2', 'subset3'}
    class Collector3(BaseFactCollector):
        name = 'subset3'
        _fact_ids = {'subset1', 'subset2', 'subset3'}
    all_fact_subsets = {'subset1': [Collector1, Collector2],
                        'subset2': [Collector2],
                        'subset3': [Collector3]}

# Generated at 2022-06-20 16:58:08.385522
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import TransformNamespace
    from ansible.module_utils.facts.collector.linux.distribution import DistributionFactCollector

    namespace = TransformNamespace('ansible_', '', '_')
    facts = DistributionFactCollector(namespace=namespace).collect_with_namespace()
    print(facts)
    assert 'ansible_distribution' in facts



# Generated at 2022-06-20 16:58:23.089726
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {}
    collector_names = ['a', 'b', 'c']

    class CollectorA:
        required_facts = ['b']
    class CollectorB:
        required_facts = ['a', 'c']
    class CollectorC:
        required_facts = ['a']

    all_fact_subsets['a'] = [CollectorA, CollectorC]
    all_fact_subsets['b'] = [CollectorB]
    all_fact_subsets['c'] = [CollectorC]

    fact_dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert 'a' in fact_dep_map and fact_dep_map['a'] == set()
    assert 'b' in fact_dep_map and fact_dep_map['b'] == set

# Generated at 2022-06-20 16:58:31.457288
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    """Unit test for function find_collectors_for_platform
    """
    # Initilize test collectors
    class CollectorTestA(object):
        @staticmethod
        def platform_match(platform_info):
            return 1 if platform_info == 'a' else 0

    class CollectorTestB(object):
        @staticmethod
        def platform_match(platform_info):
            return 1 if platform_info == 'b' else 0

    class CollectorTestC(object):
        @staticmethod
        def platform_match(platform_info):
            return 1 if platform_info == 'c' else 0

    all_collector_classes = [CollectorTestA, CollectorTestB, CollectorTestC]

    # Test 3 cases
    # 1. Empty collectors
    # 2. Exact match
    # 3. Have multiple matches
    all_tests

# Generated at 2022-06-20 16:58:44.446830
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('network', 'virtual', 'hardware', 'firmware'))
    minimal_gather_subset = ('network', 'virtual')
    args = dict(valid_subsets=valid_subsets, minimal_gather_subset=minimal_gather_subset)


# Generated at 2022-06-20 16:59:01.293978
# Unit test for function build_dep_data
def test_build_dep_data():
    class C1(BaseFactCollector):
        name = 'c1'
        required_facts = set()

    class C2(BaseFactCollector):
        name = 'c2'
        required_facts = {'c1'}

    class C3(BaseFactCollector):
        name = 'c3'
        required_facts = {'c1'}

    class C4(BaseFactCollector):
        name = 'c4'
        required_facts = {'c2', 'c3'}

    collector_classes = [C1, C2, C3, C4]
    all_fact_subsets = build_fact_id_to_collector_map(collector_classes)[0]

# Generated at 2022-06-20 16:59:09.821659
# Unit test for function tsort
def test_tsort():
    test_data = [
        ({'a': {'b'}, 'b': {'c', 'd'}, 'c': set(), 'd': set()},
         [('c', set()), ('d', set()), ('b', {'c', 'd'}), ('a', {'b'})]),

        ({'a': {'b', 'c'}, 'b': {'c'}, 'c': set()},
         [('c', set()), ('b', {'c'}), ('a', {'b', 'c'})]),

        # make sure we preserve the order of the unsorted input
        ({'a': set(), 'b': set()},
         [('a', set()), ('b', set())]),
    ]


# Generated at 2022-06-20 16:59:18.931504
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'foo': [
            FakeCollector('foo', required_facts=('bar', 'baz'), _fact_ids=('fooid', )),
            FakeCollector('foo', required_facts=('baz', ), _fact_ids=('fooid', )),
        ],
        'bar': [
            FakeCollector('bar', required_facts=(), _fact_ids=('barid', )),
        ],
        'baz': [
            FakeCollector('baz', required_facts=(), _fact_ids=('bazid', )),
        ],
    }
    collector_names = ['foo', 'baz']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert 'bar' in unresolved



# Generated at 2022-06-20 16:59:30.374788
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.base import BaseFileSystem

    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['D'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set()
    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['E'])
    class F(BaseFactCollector):
        name = 'F'
        required_

# Generated at 2022-06-20 16:59:40.917641
# Unit test for function tsort

# Generated at 2022-06-20 16:59:43.912624
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc1 = BaseFactCollector()
    assert fc1.collectors == []
    assert fc1.namespace is None



# Generated at 2022-06-20 16:59:50.194440
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    compat_platforms = [{'system': 'Linux', 'distribution': 'Debian', 'lsb': {'release': '9.9', 'codename': 'stretch'}}]
    expected_collector_names = {'distribution', 'debian', 'linux'}
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert(expected_collector_names == set([f.name for f in found_collectors]))



# Generated at 2022-06-20 17:00:00.444987
# Unit test for function tsort
def test_tsort():
    from collections import Counter
    # Compilation of various topo-sorting examples
    # as well as a custom example


# Generated at 2022-06-20 17:00:10.979502
# Unit test for function tsort
def test_tsort():
    def check_cycle(unsorted_map):
        try:
            tsort(unsorted_map)
            assert False, "tsort should have detected cycle"
        except CycleFoundInFactDeps:
            pass

    unsorted_map = {}
    tsort(unsorted_map)

    unsorted_map = {'a': set()}
    sorted_list = tsort(unsorted_map)
    assert sorted_list == [('a', set())], "tsort failed to sort single node"

    unsorted_map = {'a': set(['b']), 'b': set()}
    sorted_list = tsort(unsorted_map)
    assert sorted_list == [('b', set()), ('a', set(['b']))], "tsort failed to sort"


# Generated at 2022-06-20 17:00:19.927446
# Unit test for function tsort
def test_tsort():
    dep_map = {'FACT_B': {'FACT_A'}, 'FACT_A': {'FACT_B'}}
    assert tsort(dep_map) == [('FACT_B', {'FACT_A'}),
                              ('FACT_A', {'FACT_B'})]

    dep_map = {'FACT_B': {'FACT_C', 'FACT_A'}, 'FACT_A': {'FACT_B'}}
    assert tsort(dep_map) == [('FACT_B', {'FACT_C', 'FACT_A'}),
                              ('FACT_C', set()),
                              ('FACT_A', {'FACT_B'})]


# Generated at 2022-06-20 17:00:36.243432
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    valid_subsets = frozenset(['all', 'hardware', 'network', 'virtual', 'ohai', 'facter'])
    minimal_gather_subset = frozenset(['foo', 'bar', 'baz'])
    gather_subset = ['all']
    platform_info = {'system': 'Generic'}
    gather_timeout = 10
    assert collector_classes_from_gather_subset(valid_subsets=valid_subsets,
                                                minimal_gather_subset=minimal_gather_subset,
                                                gather_subset=gather_subset,
                                                platform_info=platform_info,
                                                gather_timeout=gather_timeout)

# Generated at 2022-06-20 17:00:49.127573
# Unit test for function tsort
def test_tsort():
    import pytest
    from pytest import raises
    from collections import defaultdict

    # sort_list looks like: 'node, {list of unsorted nodes that depend on this node}'
    # The idea is a node depends on the nodes that are before it in the list.
    # The list returned is sorted so that each node depends on the nodes
    # before it in the list.
    #
    # the digraph looks like:
    #      A
    #     / \
    #    B   C
    #   / \
    #  D   E
    #
    #
    sort_list = [('A', set()),
                 ('B', set(['A'])),
                 ('C', set(['A'])),
                 ('D', set(['B'])),
                 ('E', set(['B'])), ]

# Generated at 2022-06-20 17:01:00.716736
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class _FakeCollector(BaseFactCollector):
        name = None

    class _A(_FakeCollector):
        name = 'a'

    class _B(_FakeCollector):
        name = 'b'
        required_facts = set(['c'])

    class _C(_FakeCollector):
        name = 'c'
        required_facts = set(['d'])

    class _D(_FakeCollector):
        name = 'd'
        required_facts = set(['a'])

    class _E(_FakeCollector):
        name = 'e'
        required_facts = set(['b'])

    # in this case, we have _B and _E that depend on _C, and _C that depends on _D
    # the code should sort the list so that _D is first, then _C, then

# Generated at 2022-06-20 17:01:10.168332
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collectors import get_collectors_for_platform
    from ansible.module_utils.facts import collector

    all_collectors = collector.get_collector_classes()

    test_platform_info = {'distribution': 'Ubuntu', 'distribution_version': '16', 'system': 'Linux'}
    found_collectors = find_collectors_for_platform(all_collectors, [test_platform_info])
    found_collector_names = set(map(lambda x: x.name, found_collectors))

    # One of the base collectors is always Linux.
    assert 'system' in found_collector_names

    # All of the Linux collectors should be found.
    assert 'distribution' in found_collector_names
    assert 'lsb' in found_collect

# Generated at 2022-06-20 17:01:19.588655
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.namespace import PrefixNamespace
    from ansible.module_utils.facts.collections.base import BaseFactCollector
    from mock import Mock, patch

    def _base_fact_collector_init_mock(self, collectors=None, namespace=None):
        self.namespace = namespace
        self.collectors = collectors or []

    mock_fact_collector = Mock()
    mock_fact_collector.configure_mock(**{
        'collect.return_value': {
            'fact_a': True,
            'fact_b': True,
        },
        '_transform_name.side_effect': PrefixNamespace(
            prefix='prefix_',
        ).transform,
    })


# Generated at 2022-06-20 17:01:30.047851
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestFactCollector1(BaseFactCollector):
        name = 'testfact1'
    class TestFactCollector2(BaseFactCollector):
        name = 'testfact2'
    class TestFactCollector3(BaseFactCollector):
        name = 'testfact3'

    # No repeat collector names
    selected_collector = select_collector_classes(['testfact1', 'testfact2'], {
        'testfact1': [TestFactCollector1],
        'testfact2': [TestFactCollector2],
        'testfact3': [TestFactCollector3],
    })
    assert len(selected_collector) == 2
    assert selected_collector[0] == TestFactCollector1
    assert selected_collector[1] == TestFactCollector2

    # Repeat collector names
    selected

# Generated at 2022-06-20 17:01:36.193626
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == set(['min', 'hardware', 'virtual', 'network', 'ohai', 'config', 'pkg_mgr', 'firmware'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['hardware', 'virtual']) == set(['min', 'hardware', 'virtual'])
    assert get_collector_names(gather_subset=['all', '!hardware']) == set(['min', 'virtual', 'network', 'ohai', 'config', 'pkg_mgr', 'firmware'])

# Generated at 2022-06-20 17:01:48.306627
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts import collector
    # We do not have access to the real collector classes, but we can
    # make a mockup based on the default dicts, which define the names
    # of the collectors and the required facts for each.
    special_class = type('A', (object,), dict(name='special', _fact_ids=['special'], required_facts=set()))

# Generated at 2022-06-20 17:02:00.137824
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from collections import namedtuple

    class DummyCollector(BaseFactCollector):
        pass

    class DummyNamespace:
        def transform(self, name):
            return name + '_'

    # This is a fake module. It has a get_bin_path that returns the pathname
    # if it is found.
    Module = namedtuple('Module', ['get_bin_path'])
    module = Module(get_bin_path=lambda arg: arg)

    d = DummyCollector()
    assert d.collect() == {}

    d = DummyCollector(namespace=DummyNamespace())
    assert d.collect() == {}

    facts_dict = d.collect_with_namespace()
    assert facts_dict == {}

    facts_dict = d.collect_with_namespace(module=module)

# Generated at 2022-06-20 17:02:10.443931
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.hardware import Hardware
    from ansible.module_utils.facts.collectors.network import Network
    from ansible.module_utils.facts.collectors.distribution import Distribution
    class MyCollector(BaseFactCollector):
        _fact_ids = set(['my_fact'])
        _platform = 'Generic'
        name = 'my_collector'
        required_facts = set(['my_req'])


# Generated at 2022-06-20 17:02:28.524029
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        _fact_ids = ['a', 'b']
        name = 'a'

    class Collector2(BaseFactCollector):
        _fact_ids = ['c', 'b']
        name = 'b'

    class Collector3(BaseFactCollector):
        _fact_ids = ['d', 'e']
        name = 'c'

    class Collector4(BaseFactCollector):
        _fact_ids = ['b', 'c']
        name = 'd'

    all_fact_subsets = {
        'a': [Collector1, Collector3],
        'b': [Collector4],
        'c': [Collector2]
    }

    assert select_collector_classes(['a'], all_fact_subsets) == [Collector1, Collector3]

# Generated at 2022-06-20 17:02:39.448108
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector1 = BaseFactCollector()
    assert collector1.collectors == []
    assert collector1.namespace is None
    assert collector1.fact_ids == set([collector1.name])
    assert collector1.name is None

    collector2 = BaseFactCollector(collectors=[collector1])
    assert collector2.collectors == [collector1]
    assert collector1 in collector2.collectors

    collector3 = BaseFactCollector(namespace='foo')
    assert collector3.namespace is 'foo'

    collector4 = BaseFactCollector(collectors=[BaseFactCollector()])
    assert len(collector4.collectors) == 2
    assert collector4.collectors[1].name == collector4.collectors[0].name


# Generated at 2022-06-20 17:02:49.337661
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FooCollector(BaseFactCollector):
        _fact_ids = ['foo1', 'foo2']
        name = 'foo'

    class BarCollector(BaseFactCollector):
        _fact_ids = ['bar']
        name = 'bar'

    # test empty list
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([])
    assert fact_id_to_collector_map == defaultdict(list)
    assert aliases_map == defaultdict(set)

    # test single item list
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([FooCollector])

# Generated at 2022-06-20 17:03:00.208285
# Unit test for function tsort
def test_tsort():
    # example from sort_dep_topo
    # https://github.com/mxcl/sort-dep-topo/blob/master/test/test-simple.sh
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['d', 'e']),
        'c': set(['g']),
        'e': set(['f']),
        'g': set(['h', 'i', 'j']),
        'j': set(['k', 'l']),
    }


# Generated at 2022-06-20 17:03:09.019330
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    from ansible.module_utils.facts import Collector

    try:
        Collector(platform_system='Linux',
                  deps=['collector-a', 'collector-b'],
                  callback=lambda module: module.exit_json())
        Collector(platform_system='Linux',
                  deps=['collector-b', 'collector-a'],
                  callback=lambda module: module.exit_json())
        raise AssertionError("CycleFoundInFactDeps not raised")
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-20 17:03:10.420230
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert True


# Generated at 2022-06-20 17:03:21.169089
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets["foo"].append(FakeClass("f", ["a", "b", "c"]))
    all_fact_subsets["foo"].append(FakeClass("f", ["a", "b", "c", "z"]))
    all_fact_subsets["foo"].append(FakeClass("f", ["a", "b", "c", "zz"]))
    all_fact_subsets["foo"].append(FakeClass("f", ["a", "b", "c", "zzz"]))
    all_fact_subsets["foo"].append(FakeClass("f", ["a", "b", "c", "z2"]))

    all_fact_subsets["bar"].append(FakeClass("b", ["f"]))
    all_

# Generated at 2022-06-20 17:03:26.819159
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    from ansible.module_utils.facts import Collector, Namespace
    from ansible.module_utils._text import to_bytes

    class TestCollector(Collector):
        _fact_ids = set(['test'])
        name = 'test'
        required_facts = set()

        def collect(self):
            return {'test': 'testval'}

    col = TestCollector()
    col.namespace = Namespace('test_ns')

    facts_dict = col.collect_with_namespace()
    assert facts_dict.get('test_ns_test') == 'testval'

    facts_dict = col.collect()
    assert facts_dict.get('test') == 'testval'



# Generated at 2022-06-20 17:03:38.931412
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgr

    hardware = Hardware()
    network = Network()
    pkg_mgr = PkgMgr()

    hardware.required_facts = {'network'}
    network.required_facts = {'pkg_mgr'}
    pkg_mgr.required_facts = set()

    all_fact_subsets = {
        'hardware': [hardware],
        'network': [network],
        'pkg_mgr': [pkg_mgr],
    }


# Generated at 2022-06-20 17:03:39.805678
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert BaseFactCollector().collect() == {}



# Generated at 2022-06-20 17:03:50.423388
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    myobj = BaseFactCollector
    module = AnsibleModule
    collected_facts = {}
    result = myobj.collect(module=module, collected_facts=collected_facts)



# Generated at 2022-06-20 17:04:01.387341
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class A1(BaseFactCollector):
        name = 'a'

    class B1(BaseFactCollector):
        name = 'b'

    class C1(BaseFactCollector):
        name = 'c'

    class D1(BaseFactCollector):
        name = 'd'

    class E1(BaseFactCollector):
        name = 'e'

    class F1(BaseFactCollector):
        name = 'f'

    class G1(BaseFactCollector):
        name = 'g'

    # They all match everything
    assert set(find_collectors_for_platform([A1], [{'system': 'Linux'}])) == {A1}

# Generated at 2022-06-20 17:04:03.936516
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    obj = UnresolvedFactDep('error message', 'bad dep')
    assert obj.message == 'error message'
    assert obj.dep == 'bad dep'



# Generated at 2022-06-20 17:04:11.509399
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class TestBaseFactCollector(BaseFactCollector):
        name = 'test_base_fact_collector'

    obj = TestBaseFactCollector()
    assert set(obj.required_facts) == set(['test_base_fact_collector'])


if platform.system() == 'Linux':
    from ansible.module_utils.facts import linux

    LinuxFactCollector = linux.LinuxFactCollector

elif platform.system() == 'OpenBSD':
    from ansible.module_utils.facts import openbsd

    OpenBSDFactCollector = openbsd.OpenBSDFactCollector

elif platform.system() == 'FreeBSD':
    from ansible.module_utils.facts import freebsd

    FreeBSDFactCollector = freebsd.FreeBSDFactCollector


# Generated at 2022-06-20 17:04:18.172963
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {"A": ["A"], "B": ["B"]}
    unresolved_requires = ["A", "B"]
    expected_result = ["A", "B"]
    result = resolve_requires(unresolved_requires, all_fact_subsets)
    assert result == expected_result


# Generated at 2022-06-20 17:04:31.025424
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    # collector_names = ['a', 'b', 'c']
    class A(BaseFactCollector):
        name = 'a'
        required_facts = ["b"]

    class B(BaseFactCollector):
        name = 'b'
        required_facts = ["c"]

    class C(BaseFactCollector):
        name = 'c'
        required_facts = []

    all_fact_subsets = {'a': [A], 'b': [B], 'c': [C]}
    dep_map = build_dep_data(['a', 'b', 'c'], all_fact_subsets)


# Generated at 2022-06-20 17:04:41.515056
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(frozenset(("all", "network", "foo", "bar")),
                               frozenset(("min", "ec2", "config", "baz")),
                               ["foo", "!bar"],
                               platform_info=None) == frozenset(("foo", "min", "ec2", "config", "baz"))

    assert get_collector_names(frozenset(("all", "network", "foo", "bar")),
                               frozenset(("min", "ec2", "config", "baz")),
                               [],
                               platform_info=None) == frozenset(("all", "min", "ec2", "config", "baz"))


# Generated at 2022-06-20 17:04:44.043667
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = dict()
    unresolved_requires = ["networking"]
    new_names = set()
    assert new_names == resolve_requires(unresolved_requires, all_fact_subsets)



# Generated at 2022-06-20 17:04:53.702126
# Unit test for function get_collector_names
def test_get_collector_names():
    assert set(get_collector_names(
        gather_subset=['all'],
        valid_subsets=frozenset(['foo', 'bar']),
        minimal_gather_subset=frozenset(['min'])
    )) == frozenset(['foo', 'bar', 'min'])

    assert set(get_collector_names(
        gather_subset=['foo'],
        valid_subsets=frozenset(['foo', 'bar']),
        minimal_gather_subset=frozenset(['min'])
    )) == frozenset(['foo', 'min'])


# Generated at 2022-06-20 17:05:03.408275
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    def test_find_collectors_for_platform():
        '''Test happy case for find_collectors_for_platform'''

        class TestCollector(BaseFactCollector):
            _platform = 'Linux'
            name = 'dummy1'

        class TestCollector2(BaseFactCollector):
            _platform = 'Linux'
            name = 'dummy2'

        class TestCollector3(BaseFactCollector):
            _platform = 'Windows'
            name = 'dummy3'

        class TestCollector4(BaseFactCollector):
            _platform = 'Windows'
            name = 'dummy4'

        class TestCollector5(BaseFactCollector):
            _platform = 'Generic'
            name = 'dummy5'


# Generated at 2022-06-20 17:05:27.586497
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestFactCollector(BaseFactCollector):
        _fact_ids = frozenset()
        name = 'test_name'
        required_facts = frozenset()

    all_fact_subsets = {
        'test_name': [TestFactCollector],
    }
    collector_names = set(['test_name'])

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    TestFactCollector.required_facts = frozenset(['test_name2'])
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == {'test_name2'}

    all_fact_subsets['test_name2'] = [TestFactCollector]
    unresolved = find_unres

# Generated at 2022-06-20 17:05:36.858719
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class FakeCollectors:
        def platform_match(self, platform_info):
            return None
    fc1 = FakeCollectors()
    fc1.name = 'fake_collector_1'
    fc2 = FakeCollectors()
    fc2.name = 'fake_collector_2'
    fc1.platform_match = lambda x: 'Linux'
    assert not find_collectors_for_platform([fc1, fc2], [{'system':'Linux'}])
    assert find_collectors_for_platform([fc1, fc2], [{'system':'Linux'}, {'system':'Linux'}]) == set([fc1])



# Generated at 2022-06-20 17:05:40.131074
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('missing fact')
    except CollectorNotFoundError as e:
        assert str(e) == 'missing fact'



# Generated at 2022-06-20 17:05:44.328410
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps('test error message')
    assert exc.args == ('test error message',)
    with timeout(0.3):
        assert repr(exc)



# Generated at 2022-06-20 17:05:54.719286
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    class Collector(BaseFactCollector):
        name = 'foo'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    # setup the namespace
    namespace = Namespace(prefix='foo_')

    # FIXME: maybe switch to a temp class?
    class ModuleFake:
        def __init__(self):
            self.fail_json = self._fail_json
            self.exit_json = self._exit_json

        def _fail_json(self, *args, **kwargs):
            raise AssertionError('FAILED')

        def _exit_json(self, *args, **kwargs):
            raise AssertionError('FAILED')

    # collect without namespace
    module = ModuleFake()

# Generated at 2022-06-20 17:06:05.291832
# Unit test for function resolve_requires
def test_resolve_requires():
    fact_id_to_collector_map = defaultdict(list)
    aliases_map = defaultdict(set)

    class TestCollector(BaseFactCollector):
        name = 'primary_name'
        required_facts = set()

    class RequiredCollector(BaseFactCollector):
        name = 'secondary_name'
        required_facts = set()

    class RequiredRequiredCollector(BaseFactCollector):
        name = 'third_name'
        required_facts = set()

    fact_id_to_collector_map['primary_name'].append(TestCollector)

    fact_id_to_collector_map['secondary_name'].append(RequiredCollector)

    fact_id_to_collector_map['third_name'].append(RequiredRequiredCollector)


# Generated at 2022-06-20 17:06:09.392629
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    msg = 'test msg'
    c = CollectorNotFoundError(msg)
    assert c.args[0] == msg



# Generated at 2022-06-20 17:06:17.934513
# Unit test for function tsort
def test_tsort():
    edge_map = dict(
        a={'c'},
        b={'c'},
        c={'d'},
        d={},
    )
    sorted_order = tsort(edge_map)
    assert sorted_order == [('d', set()), ('c', {'d'}), ('a', {'c'}), ('b', {'c'})]

    cycle_map = dict(
        a={'b'},
        b={'c'},
        c={'a'}
    )

    try:
        tsort(cycle_map)
    except CycleFoundInFactDeps:
        pass
    else:
        raise RuntimeError('tsort did not detect cycle')

test_tsort()



# Generated at 2022-06-20 17:06:27.990685
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = defaultdict(set)

    class CollectorA(BaseFactCollector):
        _fact_ids = {'c1', 'c2'}
        name = 'collector_a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        _fact_ids = {'c1', 'c3'}
        name = 'collector_b'
        required_facts = {'c1', 'c4'}

    all_fact_subsets['collector_a'].add(CollectorA)
    all_fact_subsets['collector_a'].add(CollectorA)
    all_fact_subsets['collector_b'].add(CollectorB)
    all_fact_subsets['c1'].add(CollectorA)
    all_

# Generated at 2022-06-20 17:06:30.880440
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():

    class SomeCollector(BaseFactCollector):
        name = 'some_collector'

    assert set(['some_collector']) == SomeCollector().fact_ids
