

# Generated at 2022-06-20 16:57:18.450223
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class Collector(BaseFactCollector):
        _fact_ids = {'test_id'}
        name = 'test_collector'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    collector = Collector(namespace=_NSPrefix('pre_'))

    expected_fact_ids = {'test_id', 'test_collector'}
    assert expected_fact_ids == collector.fact_ids
    assert collector.name == 'test_collector'

    facts1 = collector.collect_with_namespace()
    assert {'pre_test_fact': 'test_value'} == facts1


# Generated at 2022-06-20 16:57:23.307712
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestMWCollectorClass(BaseFactCollector):
        name = 'TestMWCollector'
        _fact_ids = ['TestMWCollector1', 'TestMWCollector2']

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

        def collect(self, module=None, collected_facts=None):
            return {'TestMWCollector': 'collected'}


# Generated at 2022-06-20 16:57:25.151045
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with pytest.raises(TypeError) as e:
        UnresolvedFactDep()
    assert '__init__() missing 1 required positional argument: \'fact_name\'' in str(e.value)
    ufd = UnresolvedFactDep(fact_name='foo')
    assert str(ufd) == "Unresolved dependency 'foo'"



# Generated at 2022-06-20 16:57:33.327029
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class GenericCollector:
        _platform = 'Generic'
        name = 'generic_collector'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    class LinuxCollector:
        _platform = 'Linux'
        name = 'linux_collector'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

    class NotAMatchCollector:
        _platform = 'NOTAPLATFORM'
        name = 'notamatch_collector'


# Generated at 2022-06-20 16:57:34.800081
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    with raises(ValueError):
        raise UnresolvedFactDep("Unable to resolve fact dependency")



# Generated at 2022-06-20 16:57:37.928862
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class StubCollector(BaseFactCollector):
        _fact_ids = {'yaml', 'yaml_data'}
        name = 'yaml'

    assert build_fact_id_to_collector_map([StubCollector]) == (
        {'yaml': [StubCollector], 'yaml_data': [StubCollector]},
        {'yaml': {'yaml_data'}}
    )



# Generated at 2022-06-20 16:57:48.799083
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = {
        'hardware': {'devices', 'dmi', 'pci'}
    }
    valid_subsets = frozenset(['all', 'min', 'network', 'hardware', 'devices', 'dmi', 'pci'])
    minimal_gather_subset = frozenset(['min'])

    # Testing no match
    gather_subset = ['no_match']
    result = get_collector_names(valid_subsets=valid_subsets,
                                 minimal_gather_subset=minimal_gather_subset,
                                 gather_subset=gather_subset,
                                 aliases_map=aliases_map)
    assert result == frozenset()

    # Testing all with no match
    gather_subset = ['all', 'no_match']

# Generated at 2022-06-20 16:58:00.600817
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    from copy import deepcopy
    tests = [
        (
            (
                {"ansible_distribution": "Ubuntu"},
                {}
            ),
            {},
        ),
        (
            (
                {},
                {}
            ),
            {},
        ),
        (
            (
                {"ansible_distribution": "Ubuntu"},
                {"ansible_distribution": "CentOS"}
            ),
            {},
        ),
        (
            (
                {},
                {"ansible_distribution": "CentOS"}
            ),
            {},
        ),
    ]
    for (input_param, expected_result) in tests:
        (module, collected_facts) = deepcopy(input_param)
        result = BaseFactCollector.collect(**deepcopy(input_param))
        assert result

# Generated at 2022-06-20 16:58:11.965076
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector:
        name = 'fake'
        required_facts = set()
    all_fact_subsets = {
        'fake': [FakeCollector]
    }

    assert_empty = find_unresolved_requires(['fake'], all_fact_subsets)

    assert_not_empty = find_unresolved_requires(['fake', 'fake2'], all_fact_subsets)
    assert 'fake2' in assert_not_empty

    # if multiple collectors are defined for a single name, only
    # one needs to not have unresolved requires
    class FakeCollector2:
        name = 'fake'
        required_facts = set()
    all_fact_subsets = {
        'fake': [FakeCollector, FakeCollector2]
    }
    assert_empty = find_unresolved

# Generated at 2022-06-20 16:58:20.282607
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, {
        'a': [MockFactCollector('a')],
        'b': [MockFactCollector('b', requires=['a'])]
    })
    assert unresolved == set()

    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, {
        'a': [MockFactCollector('a')],
        'b': [MockFactCollector('b', requires=['a', 'c'])]
    })
    assert unresolved == set(['c'])

    collector_names = ['a', 'b']

# Generated at 2022-06-20 16:58:33.188597
# Unit test for function tsort
def test_tsort():
    assert tsort({1: (2, 3), 2: (3,), 3: ()}) == [(3, ()), (2, (3,)), (1, (2, 3))]
    assert tsort({1: (2, 3, 4), 2: (3,), 3: (4,), 4: ()}) == [(4, ()), (3, (4,)), (2, (3,)), (1, (2, 3, 4))]
    assert tsort({1: (3,), 3: (4,), 4: (1,)}) == [(4, (1,)), (3, (4,)), (1, (3,))]

# Generated at 2022-06-20 16:58:45.355450
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import sys
    if sys.version_info[0] == 2:
        from mock import Mock
    else:
        from unittest.mock import Mock

    class EmptyCollector(BaseFactCollector):
        name = 'empty'

    platform_info = {'system': 'Linux'}

    all_collector_classes = [EmptyCollector]

    minimal_gather_subset = frozenset()

    # use gather_name etc to get the list of collectors

    valid_subsets = frozenset()


# Generated at 2022-06-20 16:58:58.063092
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class C(BaseFactCollector):
        name = "C"
        _fact_ids = {"C1", "C2"}
    class A(BaseFactCollector):
        name = "A"
        _fact_ids = {"A1", "A2"}
    class B(BaseFactCollector):
        name = "B"
        _fact_ids = {"B1", "B2"}

    all_fact_subsets = \
        {'C': [C, B], 'A': [A], 'B': [B, C]}


    collector_names = ['B', 'A', 'C', 'B']
    selected_collector_classes = \
        select_collector_classes(collector_names, all_fact_subsets)

    assert A in selected_collector_classes
    assert B in selected_collect

# Generated at 2022-06-20 16:59:07.688986
# Unit test for function resolve_requires
def test_resolve_requires():
    subsets = defaultdict(list)
    subsets['a'].append(BaseFactCollector())
    subsets['a'][0]._fact_ids = ('a1',)
    subsets['a'][0].required_facts = ('b',)

    subsets['b'].append(BaseFactCollector())
    subsets['b'][0]._fact_ids = ('b1',)
    subsets['b'][0].required_facts = ('c',)

    subsets['c'].append(BaseFactCollector())
    subsets['c'][0]._fact_ids = ('c1',)
    subsets['c'][0].required_facts = ('d',)


# Generated at 2022-06-20 16:59:18.258262
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        _fact_ids = {'collector1_1', 'collector1_2'}

    class Collector2(BaseFactCollector):
        _fact_ids = {'collector2_1', 'collector2_2'}

    class Collector3(BaseFactCollector):
        _fact_ids = {'collector3_1', 'collector3_2'}

    class Collector4(BaseFactCollector):
        _fact_ids = {'collector4_1', 'collector4_2'}

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['collector1'].append(Collector1)
    all_fact_subsets['collector1'].append(Collector2)

# Generated at 2022-06-20 16:59:30.048653
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['b'])
    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])
    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['f'])
    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])
    class G(BaseFactCollector):
        name = 'g'
        required_facts = set(['a', 'e'])

    # No gather_

# Generated at 2022-06-20 16:59:36.544442
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors.hardware import HardwareFactCollector
    from ansible.module_utils.facts.collectors.compat.platform import PlatformFactCollector
    from ansible.module_utils.facts.collectors.pip import PipFactCollector
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map((HardwareFactCollector,
                                                                            PlatformFactCollector,
                                                                            PipFactCollector))
    assert len(fact_id_to_collector_map['platform']) == 2
    assert fact_id_to_collector_map['platform'] == [PlatformFactCollector, HardwareFactCollector]
    assert len(fact_id_to_collector_map['python']) == 1
    assert fact_

# Generated at 2022-06-20 16:59:48.159745
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    selected_collector_classes = collector_classes_from_gather_subset(all_collector_classes=None,
                                                                      valid_subsets=None,
                                                                      minimal_gather_subset=None,
                                                                      gather_subset=None,
                                                                      gather_timeout=None,
                                                                      platform_info=None)
    assert selected_collector_classes == []

# Generated at 2022-06-20 16:59:59.934960
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class Collector(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1','test1_alias'])
        required_facts = set(['test2','test2_alias'])

    class Collector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2','test2_alias'])

    class Collector3(BaseFactCollector):
        name = 'test3'

    # some test collectors
    class Collector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test1','test3'])

    class Collector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['test3'])


# Generated at 2022-06-20 17:00:05.445451
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Mock out the platform.system function
    mock_system_fns = [lambda: 'Linux', lambda: 'Darwin', lambda: 'FreeBSD']

    # Mock out all the Collector classes.
    class CollectorLinux(BaseFactCollector):
        _platform = 'Linux'
    class CollectorFreeBSD(BaseFactCollector):
        _platform = 'FreeBSD'
    class CollectorDarwin(BaseFactCollector):
        _platform = 'Darwin'
    class CollectorGeneric(BaseFactCollector):
        _platform = None

    collectors_classes = [CollectorLinux, CollectorFreeBSD, CollectorDarwin, CollectorGeneric]

    # Test using each mock platform
    for mock_system in mock_system_fns:

        # Mock out the platform.system function
        platform.system = mock_system

        # Invoke find_collectors_for_

# Generated at 2022-06-20 17:00:12.130785
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():

    with pytest.raises(CollectorNotFoundError):
        raise CollectorNotFoundError("Test")


# Generated at 2022-06-20 17:00:20.462479
# Unit test for function build_dep_data
def test_build_dep_data():
    # Set up the test data.
    collector_names = ['a', 'b', 'c', 'd']
    all_fact_subsets = defaultdict(set)

    # Define the required facts necessary to complete this test.
    required_facts = {
        'a': set(),
        'b': set(),
        'c': {'a'},
        'd': {'a'},
    }

    # Override the required facts method and return the necessary facts.
    def over_required_facts(self):
        return required_facts[self.name]

    # Replace the required facts method with the newly created method.
    BaseFactCollector.required_facts = over_required_facts

    # Create the fact_collector_classes
    fact_collector_classes = list()

# Generated at 2022-06-20 17:00:27.168008
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'B': {'A'},
        'D': {'X', 'Y'},
        'E': set(),
        'A': {'B'},  # cycle
        'X': {'D'},  # cycle
        'Y': {'Z'},
        'Z': {'B', 'E'},
    }
    # should raise CycleFoundInFactDeps
    tsort(dep_map)
test_tsort()



# Generated at 2022-06-20 17:00:28.782154
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    ufd = UnresolvedFactDep('foo')
    assert 'foo' in str(ufd)


# Generated at 2022-06-20 17:00:38.987332
# Unit test for function get_collector_names
def test_get_collector_names():

    # Set parameters
    gather_subset=['all']
    minimal_gather_subset = ['min']
    valid_subsets = frozenset(['all', 'min', '!min', '!all'])
    aliases_map = defaultdict(set, {'ccd': set('ccd'), 'rhev': set('rhev'), 'openstack': set('openstack'), 'virtualization': set('virtualization'), 'libvirt': set('libvirt'), 'vmware': set('vmware'), 'network': set('network'), 'hardware': set('ccd', 'dmi', 'devices'), 'dmi': set('dmi'), 'devices': set('devices')})

    # Call get_collector_names()

# Generated at 2022-06-20 17:00:42.621941
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    class DummyException(Exception):
        pass

    try:
        raise CycleFoundInFactDeps()
    except CycleFoundInFactDeps:
        pass
    else:
        raise DummyException



# Generated at 2022-06-20 17:00:51.467467
# Unit test for function get_collector_names
def test_get_collector_names():
    # Basic test
    gather_subset = get_collector_names(
        ['all'],
        {},
        ['min'],
        {},
        {}
    )
    assert gather_subset == set()

    # All aliases test
    gather_subset = get_collector_names(
        ['all', 'fibridge'],
        ['all'],
        ['min'],
        {'net': ['fibridge', 'lom', 'all']},
        {}
    )
    assert gather_subset == {'all', 'fibridge'}


# Generated at 2022-06-20 17:00:55.854445
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['a', 'b'], {'a': ['a1', 'a2'], 'b': ['b1']}) == {'a': {'a'}, 'b': {'b'}}



# Generated at 2022-06-20 17:01:07.541553
# Unit test for function tsort
def test_tsort():
    # basic graph
    l = tsort({'B': {'A'}, 'C': {'B'}, 'D': {'B'}, 'E': {'C', 'D'}})
    assert l == [('C', {'B'}), ('D', {'B'}), ('B', {'A'}), ('E', {'C', 'D'})]

    # basic graph with cycle
    try:
        tsort({'B': {'A'}, 'C': {'B'}, 'D': {'E'}, 'E': {'B'}})
        assert False
    except CycleFoundInFactDeps:
        pass

    # basic graph with cycle

# Generated at 2022-06-20 17:01:11.375137
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('CNF', 'not found')
    except CollectorNotFoundError as e:
        assert e.args == ('CNF not found',)



# Generated at 2022-06-20 17:01:26.646611
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class CollectorClass(BaseFactCollector):
        _fact_ids = set()
        name = 'test_collector'

    class CollectorClass2(BaseFactCollector):
        _fact_ids = set()
        name = 'test_collector_2'

    assert build_fact_id_to_collector_map(
        (CollectorClass, CollectorClass2)) == ({'test_collector': [CollectorClass],
                                                'test_collector_2': [CollectorClass2]},
                                               defaultdict(set, {'test_collector': set(),
                                                                 'test_collector_2': set()}))

    class CollectorClass3(BaseFactCollector):
        _fact_ids = set(['foo'])
        name = 'test_collector_3'

    assert build_fact

# Generated at 2022-06-20 17:01:27.996226
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # TODO: write unit test
    pass



# Generated at 2022-06-20 17:01:31.459677
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    my_instance = BaseFactCollector()
    result = my_instance.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-20 17:01:40.162644
# Unit test for function tsort
def test_tsort():
    unsorted_map = {
        'b': set(['a']),
        'c': set(['a']),
        'd': set(['c']),
        'e': set(['d']),
        'f': set(['e', 'b'])
    }

    sorted_map = {
        'a': set(),
        'b': set(['a']),
        'c': set(['a']),
        'd': set(['c']),
        'e': set(['d']),
        'f': set(['e', 'b'])
    }
    new_list = [(key, value) for key, value in tsort(unsorted_map)]

    for item in new_list:
        assert item in sorted_map.items()



# Generated at 2022-06-20 17:01:47.349239
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    e = CollectorNotFoundError('test_message')
    assert(e.args == ('test_message',))


if platform.system() == 'Windows':
    from ansible.module_utils.facts.collectors.windows.hardware import Hardware
    from ansible.module_utils.facts.collectors.windows.local import Local
    from ansible.module_utils.facts.collectors.windows.virtual import Virtual
else:
    from ansible.module_utils.facts.collectors.posix.hardware import Hardware
    from ansible.module_utils.facts.collectors.posix.local import Local
    from ansible.module_utils.facts.collectors.posix.virtual import Virtual

# top-level fact key -> (collector class, fact dependencies)

# Generated at 2022-06-20 17:01:59.540003
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    # Checking that facts.collectors.all is a subtype of BaseFactCollector
    all_collectors = collectors.all
    assert issubclass(all_collectors, BaseFactCollector)
    # Checking that 'Generic' is part of the supported platforms
    Generic_found = False
    for class_elem in all_collectors:
        if 'Generic' in list(class_elem.platforms.keys()):
            Generic_found = True
            break
    assert Generic_found == True
    # Checking that 'Linux' is part of the supported platforms
    Linux_found = False
    for class_elem in all_collectors:
        if 'Linux' in list(class_elem.platforms.keys()):
            Linux_found = True
            break
    assert Linux

# Generated at 2022-06-20 17:02:00.542292
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    collector = BaseFactCollector()
    assert collector.fact_ids == set(['Generic'])



# Generated at 2022-06-20 17:02:06.777625
# Unit test for function build_dep_data
def test_build_dep_data():
    names = ['network', 'cache']
    all_fact_subsets = {
        'facts': ['Generic', 'System', 'Virtual'],
        'network': ['Interfaces', 'Default'],
        'system': ['Distribution', 'System'],
        'virtual': ['Virtual']
    }

    expected_dep_map = {'network': {'facts'},
                        'cache': {'facts'}}

    assert build_dep_data(names, all_fact_subsets) == expected_dep_map



# Generated at 2022-06-20 17:02:15.978564
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # no unresolved requires
    assert set() == find_unresolved_requires(['all', 'some'], {
        'all': [object()],
        'some': [object()]
    })

    # unresolved requires
    assert set(['test1', 'test2']) == find_unresolved_requires(['all', 'some'], {
        'all': [object()],
        'some': [object(required_facts=['test1', 'test2'])]
    })



# Generated at 2022-06-20 17:02:22.196409
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as ex:
        assert ex.args[0] == 'foo'
        assert str(ex) == 'foo'
    else:
        assert False, 'Expected an exception'



# Generated at 2022-06-20 17:02:39.463265
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorFake:
        name = None
        def __init__(self, name, required_facts=None):
            self.name = name
            self.required_facts = required_facts

    class CollectorA(CollectorFake):
        _fact_ids = frozenset(['a'])
        name = 'a'
        required_facts = frozenset(['x'])

    class CollectorB(CollectorFake):
        _fact_ids = frozenset(['b'])
        name = 'b'
        required_facts = frozenset(['y'])

    class CollectorC(CollectorFake):
        _fact_ids = frozenset(['c'])
        name = 'c'
        required_facts = frozenset(['a', 'x'])

    class CollectorD(CollectorFake):
        _

# Generated at 2022-06-20 17:02:47.509480
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts.collectors import all_collector_classes
    assert len(all_collector_classes) > 0, 'Cannot run the unit test if we dont have the list of collection classes.'

    platform_info = {'system': platform.system()}
    minimal_gather_subset = ['min']

    # test the default options. We expect to match the default options
    # for all platforms, which is minimal for most platforms.
    # 'all' is equivalent to minimal for Windows, so add it there.
    if platform_info['system'] == 'Windows':
        minimal_gather_subset.append('all')

    # only one class

# Generated at 2022-06-20 17:02:58.653511
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collectors import BaseFactCollector
    #initiate a class
    obj = BaseFactCollector()
    class namespace(object):
        def transform(self,key_name):
            return key_name
    
    obj.namespace = namespace()
    module = {}
    collected_facts = {}

    #check if the module has _transform_name method 
    assert callable(obj._transform_name)

    #call the collect_with_namespace
    result = obj.collect_with_namespace(module=module,collected_facts=collected_facts)

    #check the result
    assert isinstance(result,dict)


# Generated at 2022-06-20 17:03:02.087976
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    result = fc.collect()
    assert result == {}



# Generated at 2022-06-20 17:03:12.022642
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.alt
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MyCollector(BaseFactCollector):
        name = 'mycollector'

        _platform = 'MySystem'

        def collect(self):
            return {'a': 1}

    class MyLinuxCollector(BaseFactCollector):
        name = 'mylinuxcollector'

        _platform = 'Linux'

        def collect(self):
            return {'b': 1}

    collector.all_collectors.add(MyCollector)
    collector.all_collectors.add(MyLinuxCollector)

# Generated at 2022-06-20 17:03:15.768012
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    # Use built-in assert keyword
    try:
        raise CollectorNotFoundError(1)
    except CollectorNotFoundError as ex:
        assert ex[0] == 1


# Generated at 2022-06-20 17:03:18.068873
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fc = BaseFactCollector()
    results = fc.collect()
    assert results == {}, "Unexpected results found: %s" % results
# END Unit test for method collect of class BaseFactCollector



# Generated at 2022-06-20 17:03:25.850866
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    fact_name = 'abc'
    unresolved_dep = 'xyz'

    try:
        raise UnresolvedFactDep(fact_name, unresolved_dep)
    except UnresolvedFactDep as e:
        assert str(e) == "fact %s requires fact %s, but %s isn't defined" % (
            fact_name, unresolved_dep, unresolved_dep)



# Generated at 2022-06-20 17:03:28.561321
# Unit test for function resolve_requires
def test_resolve_requires():

    if platform.system() == 'Darwin':
        resolved_requires = resolve_requires(unresolved_requires, all_fact_subsets)
        assert resolved_requires == ['system', 'network']
    else:
        assert True


# Generated at 2022-06-20 17:03:34.618334
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
                        'net': ['net'],
                        'sys': ['sys'],
                        }

    new_names = resolve_requires(set(['net', 'nobody']), all_fact_subsets)
    assert new_names == set(['net'])



# Generated at 2022-06-20 17:03:49.021733
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [object()], 'b': [object()], 'c': [object()], 'd': [object()]}

    class A(object):
        required_facts = frozenset(['b', 'c'])

    class B(object):
        required_facts = frozenset(['a'])

    class C(object):
        required_facts = frozenset(['d', 'e'])

    all_fact_subsets['a'][0].required_facts = frozenset(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = frozenset(['a'])
    all_fact_subsets['c'][0].required_facts = frozenset(['d', 'e'])

    assert find_unresolved_

# Generated at 2022-06-20 17:03:56.232128
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    collectors = []
    namespace = object()
    base_fact_collector = BaseFactCollector(collectors=collectors, namespace=namespace)
    module = None
    collected_facts = None
    assert base_fact_collector.collect(module=module, collected_facts=collected_facts) == {}


# Generated at 2022-06-20 17:03:58.004687
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    test_str = 'test-str'
    err = CollectorNotFoundError(test_str)
    assert test_str in str(err)


# Generated at 2022-06-20 17:04:01.360732
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bc = BaseFactCollector()
    assert isinstance(bc, BaseFactCollector)


# Generated at 2022-06-20 17:04:11.139988
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {}
    assert resolve_requires(['a'], all_fact_subsets) == set()
    all_fact_subsets = {'a': None}
    assert resolve_requires(['a'], all_fact_subsets) == set(['a'])
    assert resolve_requires(['b'], all_fact_subsets) == set()
    assert resolve_requires(set(['a', 'b']), all_fact_subsets) == set(['a'])
    all_fact_subsets = {'b': None}
    assert resolve_requires(set(['a', 'b']), all_fact_subsets) == set(['b'])
    all_fact_subsets = {'a': None, 'b': None}

# Generated at 2022-06-20 17:04:21.766031
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['network']) == set(['network'])
    assert get_collector_names(gather_subset=['network', 'interfaces']) == set(['network', 'interfaces'])
    assert get_collector_names(gather_subset=['network', 'interfaces'], valid_subsets=['network', 'interfaces', 'all']) == set(['network', 'interfaces'])
    assert get_collector_names(gather_subset=['network', 'interfaces'], valid_subsets=['network', 'interfaces', 'all'], minimal_gather_subset=['interfaces']) == set(['network', 'interfaces'])

# Generated at 2022-06-20 17:04:32.426848
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''Test that the selected collector names are correct'''

    # Gather all facts
    selected_collector_classes = collector_classes_from_gather_subset(gather_subset=['all'])
    selected_collector_names = [x.name for x in selected_collector_classes]
    assert(selected_collector_names == ['min'])

    # Gather only network facts
    selected_collector_classes = collector_classes_from_gather_subset(gather_subset=['network'])
    selected_collector_names = [x.name for x in selected_collector_classes]
    assert(selected_collector_names == ['interfaces','biosdevname','default_ipv4','default_ipv6','min','distribution','dmi','virtual'])

    # Gather

# Generated at 2022-06-20 17:04:41.936204
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = ('all', 'network', 'software', 'hardware')

    # function is called inside module_util with minimal_gather_subset=('min'),
    # there is no way (that I know of) to test this without patching the module_util.
    # minimal_gather_subset=('min')
    assert get_collector_names(valid_subsets, gather_subset=['min']) == frozenset(('min',))
    assert get_collector_names(valid_subsets, gather_subset=['min', 'network']) == frozenset(('min', 'network'))
    assert get_collector_names(valid_subsets, gather_subset=['network', 'min']) == frozenset(('min', 'network'))

    # all alone returns full set


# Generated at 2022-06-20 17:04:52.885250
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'a'

    class B(BaseFactCollector):
        name = 'b'
        required_facts = {'a', 'c'}

    class C(BaseFactCollector):
        name = 'c'
        required_facts = {'b'}

    all_fact_subsets = { 'a':[A],
                         'b':[B],
                         'c':[C],
                       }

    collector_names = { 'a', 'b', 'c' }

    dep_map = build_dep_data(collector_names, all_fact_subsets)
    expected_dep_map = {
        'a': set(),
        'b': {'a', 'c'},
        'c': {'b'}
    }

    assert dep_map

# Generated at 2022-06-20 17:04:58.542902
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts
    import fact_collectors
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = ('test_fact',)
        required_facts = ('test_fact2',)

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = ('test_fact2',)

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _fact_ids = ('test_fact3',)

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'
        _fact_ids = ('test_fact4',)

    # test without subset

# Generated at 2022-06-20 17:05:17.879118
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    c = CycleFoundInFactDeps('a_msg')
    assert c.args[0] == 'a_msg'



# Generated at 2022-06-20 17:05:20.197114
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    if not isinstance(CollectorNotFoundError('test'), KeyError):
        raise AssertionError()



# Generated at 2022-06-20 17:05:28.573615
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class TestCollector1(BaseFactCollector):
        name = 'test_collector_1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test_collector_2'
        required_facts = {'test_collector_1'}

    class TestCollector3(BaseFactCollector):
        name = 'test_collector_3'
        required_facts = {'test_collector_2'}

    class TestCollector4(BaseFactCollector):
        name = 'test_collector_4'
        required_facts = {'test_collector_1'}


    all_collector_classes = [TestCollector1, TestCollector2, TestCollector3, TestCollector4]
    valid_subsets = frozenset()
   

# Generated at 2022-06-20 17:05:38.446253
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['min', 'all'])
    assert get_collector_names(gather_subset=['network']) == frozenset(['min', 'network'])
    assert get_collector_names(gather_subset=['!network']) == frozenset(['min', 'network'])
    assert get_collector_names(gather_subset=['network'], minimal_gather_subset=frozenset(['a'])) == frozenset(['min', 'a', 'network'])

# Generated at 2022-06-20 17:05:40.007895
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exc = CycleFoundInFactDeps('cycle')
    assert 'cycle' == exc.args[0]


# Generated at 2022-06-20 17:05:52.851009
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import CollectorNotFoundError
    from ansible.module_utils.facts import CycleFoundInFactDeps


    dict_test = dict()
    dict_test['system'] = 'Linux'
    dict_test['kernel'] = '2.6.32-431.17.1.el6.x86_64'
    dict_test['name'] = 'Red Hat Enterprise Linux Server'
    dict_test['distribution'] = 'Red Hat Enterprise Linux'
    dict_test['distribution_version'] = '6.5'
    dict_test['distribution_major_version'] = '6'
    dict_test['machine'] = 'x86_64'
    dict_test['os_family'] = 'RedHat'

# Generated at 2022-06-20 17:06:04.641760
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class ServiceCollector1(BaseFactCollector):
        name = 'services'
        def collect(self, module=None, collected_facts=None):
            return {'services': [], }

    class ServiceCollector2(BaseFactCollector):
        name = 'services'
        def collect(self, module=None, collected_facts=None):
            return {'services': [], }

    class EnvCollector(BaseFactCollector):
        name = 'env'
        def collect(self, module=None, collected_facts=None):
            return {'env': [], }


    # simple test for no subset spec

# Generated at 2022-06-20 17:06:09.682009
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    # No collector given
    try:
        BaseFactCollector()
    except:
        assert False

    # Valid collector given
    assert BaseFactCollector([BaseFactCollector()])



# Generated at 2022-06-20 17:06:11.106723
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    import json
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert json.loads(str(e)) == {'msg': 'foo'}



# Generated at 2022-06-20 17:06:24.784081
# Unit test for function tsort
def test_tsort():
    # no cycles
    dep_map = {'a': ['b'],
               'b': ['c'],
               'c': ['d'],
               'd': ['e'],
               'e': []}
    assert tsort(dep_map) == [('e', []), ('d', ['e']), ('c', ['d']), ('b', ['c']), ('a', ['b'])]

    # no cycles, different order added
    dep_map = {'b': ['c'],
               'c': ['d'],
               'd': ['e'],
               'e': [],
               'a': ['b']}