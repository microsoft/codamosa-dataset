

# Generated at 2022-06-20 16:57:06.966989
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    obj = CycleFoundInFactDeps()
    assert isinstance(obj, Exception)


# Generated at 2022-06-20 16:57:15.247346
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit test for function find_unresolved_requires'''
    # Append the parent directory to the system path in order to
    # import the script to test.
    import os, sys
    cwd = os.getcwd()
    sys.path.append(os.path.sep.join([cwd, os.path.pardir]))
    import fact_collector

    class FakeCollectorClass:
        '''Fake class for unit testing'''

        required_facts = set()
        name = None

        def __init__(self, name=None):
            self.name = name

    # Test cases

# Generated at 2022-06-20 16:57:16.422203
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    base = BaseFactCollector()
    assert base.collect() == {}

# Generated at 2022-06-20 16:57:26.577601
# Unit test for function select_collector_classes
def test_select_collector_classes():
    selection_names = ['identity', 'identity', 'local', 'network']
    all_fact_subsets = {
        'identity': [1, 2, 3],
        'local': [2, 3, 4],
        'network': [3, 4, 5]
    }
    selected_collector_classes = select_collector_classes(selection_names, all_fact_subsets)
    assert selected_collector_classes == [1, 2, 4, 5]



# Generated at 2022-06-20 16:57:28.606316
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    x = BaseFactCollector()
    assert x.collect(module='module', collected_facts='collected_facts') == {}
    return True



# Generated at 2022-06-20 16:57:42.068491
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils.facts import collector as test_collector
    from ansible.module_utils.facts import timeout
    collector_names = set([])
    all_fact_subsets = defaultdict(list)
    # test case 1: resolve_requires should return list of collector names of
    # facts which are dependent from 'network' fact subsets
    collector_names.update(['network'])
    # mapping between collector_name and collector_class
    all_fact_subsets['network'] = [test_collector.NetworkCollector]
    all_fact_subsets['network'].append(test_collector.NetworkCollector)
    all_fact_subsets['network'].append(test_collector.InterfaceCollector)

# Generated at 2022-06-20 16:57:50.689797
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():

    # Case of no namespace
    no_namespace = BaseFactCollector()
    response_none_namespace = no_namespace.collect_with_namespace()
    assert response_none_namespace == {}

    # Case with namespace class
    # Test with namespace object
    class TestBaseFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            facts_dict['a'] = '1'
            return facts_dict

    test_namespace = TestBaseFactCollector()
    test_namespace.namespace = 'test'
    response_namespace = test_namespace.collect_with_namespace()
    assert response_namespace == {'test_a': '1'}

    # Test with namespace callable

# Generated at 2022-06-20 16:57:55.066082
# Unit test for function build_dep_data
def test_build_dep_data():
    # Test building dep-data successfully
    collector_names = ['one', 'two']
    collector_one = create_collector_object('one', ['three'], [])
    collector_two = create_collector_object('two', ['three', 'one'], [])
    collector_three = create_collector_object('three', [], [])
    all_fact_subsets = {'one': [collector_one], 'two': [collector_two], 'three': [collector_three]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['one'] == set(['three'])
    assert dep_map['two'] == set(['three', 'one'])
    assert dep_map['three'] == set()



# Generated at 2022-06-20 16:58:02.455958
# Unit test for function get_collector_names
def test_get_collector_names():
    class TestFactColl1(BaseFactCollector):
        name = 'coll1'
    class TestFactColl2(BaseFactCollector):
        name = 'coll2'

    # no aliases
    aliases_map = defaultdict(set)

    # Tests for gather_subset=['all']
    gather_subset = ['all']
    valid_subsets = frozenset(['coll1'])
    minimal_gather_subset = frozenset(['coll1'])
    subsets = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map)
    assert subsets == frozenset(['coll1'])

    # Tests for gather_subset=['coll1', 'coll2']
    gather_subset = ['coll1', 'coll2']
   

# Generated at 2022-06-20 16:58:05.301694
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    test_classes = [
        TestCollectorClassA,
        TestCollectorClassB,
        TestCollectorClassC,
        TestCollectorClassD,
        TestCollectorClassE,
    ]
    assert collector_classes_from_gather_subset(test_classes) == [
        TestCollectorClassA,
        TestCollectorClassB,
        TestCollectorClassC,
        TestCollectorClassD,
        TestCollectorClassE,
    ]



# Generated at 2022-06-20 16:58:32.244229
# Unit test for function get_collector_names
def test_get_collector_names():
    # valid_subsets = frozenset(['one', 'two', 'three'])
    # gather_subset = ['!one']

    # additional_subsets = get_collector_names(valid_subsets=valid_subsets,
    #                                          minimal_gather_subset=minimal_gather_subset,
    #                                          gather_subset=gather_subset,
    #                                          aliases_map=aliases_map,
    #                                          platform_info=platform_info)

    # assert additional_subsets == expected_additional_subsets, 'failed to filter addtional subset correctly'
    pass



# Generated at 2022-06-20 16:58:44.788116
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['C'])
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['D'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set()

    all_fact_subsets = {A.name: [A, C], B.name: [B], C.name: [C], D.name: [D]}
    collector_names = ['A', 'B', 'C']


# Generated at 2022-06-20 16:58:47.939575
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep(['missing_fact'], ['present_fact'])
    except UnresolvedFactDep as e:
        assert e.args == (['missing_fact'], ['present_fact'])



# Generated at 2022-06-20 16:58:59.432902
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert resolve_requires(['a', 'c'], all_fact_subsets) == {'a', 'c'}
    assert resolve_requires(['a', 'c', 'd'], all_fact_subsets) == {'a', 'c'}
    assert resolve_requires(['a', 'c', 'z'], all_fact_subsets) == {'a', 'c'}
    try:
        resolve_requires(['a', 'c', 'z'], all_fact_subsets)
    except UnresolvedFactDep:
        assert True
    except:
        assert False

# Generated at 2022-06-20 16:59:08.881198
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    minimal_gather_subset = frozenset()

    valid_subsets = frozenset()

    platform_info = {'system': platform.system()}

    gather_timeout = timeout.DEFAULT_GATHER_TIMEOUT
    all_collector_classes = init_fact_collector_classes()

    # create a fake collectors
    class FakeCollector:
        _fact_ids = set()

        _platform = 'Generic'
        name = 'fake'
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            '''Base class for things that collect facts.

            'collectors' is an optional list of other FactCollectors for composing.'''
            self.collectors = collectors or []

            # self.namespace is a object with a 'transform' method that transforms
            # the

# Generated at 2022-06-20 16:59:18.674010
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest

    class TestFactCollector1(BaseFactCollector):
        _fact_ids = set(['test_name1', 'test_name2'])
        _platform = 'Darwin'
        name = 'test_name1'
        required_facts = set()

        @staticmethod
        def platform_match(platform_info):
            if platform_info.get('system', None) == TestFactCollector1._platform:
                return TestFactCollector1

    class TestFactCollector2(BaseFactCollector):
        _fact_ids = set(['test_name3', 'test_name4'])
        _platform = 'Darwin'
        name = 'test_name3'
        required_facts = set()


# Generated at 2022-06-20 16:59:30.012632
# Unit test for function tsort
def test_tsort():
    # Basic testing of tsort
    # A -> B
    # B -> C
    # C -> D
    # D -> B <- E
    # E -> A
    # Should be A -> E -> D -> C -> B
    deps = {'A': ['B'],
            'B': ['C'],
            'C': ['D'],
            'D': ['B', 'E'],
            'E': ['A']
            }
    expected = [('A', {'B'}),
                ('E', {'A'}),
                ('D', {'B', 'E'}),
                ('C', {'D'}),
                ('B', {'C'})]
    result = tsort(deps)
    assert expected == result



# Generated at 2022-06-20 16:59:40.718310
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Place collectos in a list
    collectors_for_platform = [
        BaseFactCollector(),
        BaseFactCollector(),
        BaseFactCollector()
    ]
    # Set up class.name and ._fact_ids for the collectors
    collectors_for_platform[0].name = "collector_0"
    collectors_for_platform[0]._fact_ids = {'fact_id_0', 'fact_id_a'}
    collectors_for_platform[1].name = "collector_1"
    collectors_for_platform[1]._fact_ids = {'fact_id_1', 'fact_id_b'}
    collectors_for_platform[2].name = "collector_2"

# Generated at 2022-06-20 16:59:49.028457
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import time
    class test_class(BaseFactCollector):
        _platform = 'Little Endian'
        name = 'test'
        _fact_ids = ['test_id']

        def collect(self, module=None, collected_facts=None):
            return {'test': time.time()}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([test_class])

    assert 'test' in fact_id_to_collector_map
    assert 'test_id' in fact_id_to_collector_map
    assert 'test' in aliases_map
    assert 'test_id' in aliases_map['test']
    assert fact_id_to_collector_map['test'] == [test_class]
    assert fact_id_to_

# Generated at 2022-06-20 16:59:55.874086
# Unit test for function resolve_requires
def test_resolve_requires():
    assert resolve_requires(["collector-1"],
                            {"collector-1": []}) == set(["collector-1"])

    assert resolve_requires(["collector-1", "collector-2"],
                            {"collector-1": [],
                             "collector-2": []}) == set(["collector-1", "collector-2"])



# Generated at 2022-06-20 17:00:06.455612
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert repr(e) == "Collector 'test' not found"



# Generated at 2022-06-20 17:00:08.465554
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class Collector(BaseFactCollector):
        name='collector'
        required_facts = set()

    collector = Collector()
    assert collector.collectors == []



# Generated at 2022-06-20 17:00:17.989386
# Unit test for function resolve_requires
def test_resolve_requires():
    collector_names = set(['network'])
    all_fact_subsets = {
            'network': set()
            }
    assert resolve_requires(['network'], all_fact_subsets) == set()

    assert resolve_requires(['nothere'], all_fact_subsets) == set()

    with_names = set(['network', 'nothere'])
    with pytest.raises(UnresolvedFactDep) as ex:
        resolve_requires(with_names, all_fact_subsets)
    assert 'unresolved fact dep %s' % ','.join(with_names) == str(ex)



# Generated at 2022-06-20 17:00:23.189301
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('foo')
    except CollectorNotFoundError as e:
        assert str(e) == "foo"
        assert e.args == ('foo',)



# Generated at 2022-06-20 17:00:25.912181
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    module = None
    collected_facts = None
    b = BaseFactCollector()
    out = b.collect(module, collected_facts)
    assert out == {}



# Generated at 2022-06-20 17:00:37.125759
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class T1(BaseFactCollector):
        _platform = 'Generic'
        name = 'test1'
    class T2(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'test2'
    class T3(BaseFactCollector):
        _platform = 'Darwin'
        name = 'test3'
    class T4(BaseFactCollector):
        _platform = 'Linux'
        name = 'test4'
    class T5(BaseFactCollector):
        _platform = 'OpenBSD'
        name = 'test5'
    class T6(BaseFactCollector):
        _platform = 'NetBSD'
        name = 'test6'

    all_collector_classes = [T1, T2, T3, T4, T5, T6]


# Generated at 2022-06-20 17:00:45.154201
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    # test for class UnresolvedFactDep
    try:
        raise UnresolvedFactDep("Unresolved Fact Dependency")
    except UnresolvedFactDep:
        pass
    try:
        raise UnresolvedFactDep("Unresolved Fact Dependency", "Key1", "Key2")
    except UnresolvedFactDep:
        pass


# Generated at 2022-06-20 17:00:55.308425
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c', 'd']),
        'c': set(['d']),
        'd': set(),
    }

    result = tsort(dep_map)
    assert result == [
        ('a', set(['b', 'c'])),
        ('b', set(['c', 'd'])),
        ('c', set(['d'])),
        ('d', set()),
    ]

    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c', 'd']),
        'c': set(['d']),
        'd': set(['a']),
    }

# Generated at 2022-06-20 17:01:07.644679
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        _fact_ids = ['a']

    class B(BaseFactCollector):
        _fact_ids = ['b']

    class C(BaseFactCollector):
        _fact_ids = ['c', 'd']

    class D(BaseFactCollector):
        _fact_ids = ['e']

    class F(BaseFactCollector):
        _fact_ids = ['f']

    some_collectors = [A, B, C, D, F]

    fact_id_2_collector, aliases_map = build_fact_id_to_collector_map(collectors_for_platform=some_collectors)

    assert fact_id_2_collector['a'] == [A]
    assert fact_id_2_collector['b'] == [B]

# Generated at 2022-06-20 17:01:12.538859
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps(('a', 'b', 'c'))
    assert e.args == ('Cycle found in dependencies; collector_name=a requires collector_name=b requires collector_name=c requires collector_name=a',)



# Generated at 2022-06-20 17:01:26.150913
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    dep_a = 'foo'
    dep_b = 'bar'
    msg = "The dependencies for these facts have cannot be resolved because there is an unresolved dependency for %s: %s" % (dep_a, dep_b)
    known_deps = (dep_a, dep_b)

    resolved_dep = UnresolvedFactDep(dep_a, [known_deps])
    assert resolved_dep.dep_fact == dep_a
    assert resolved_dep.known_deps == known_deps
    assert str(resolved_dep) == msg



# Generated at 2022-06-20 17:01:34.066819
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Apple(BaseFactCollector):
        _platform = 'Darwin'

        name = 'OS X'

    class Linux(BaseFactCollector):
        _platform = 'Linux'

        name = 'Linux'

    class Generic(BaseFactCollector):
        _platform = 'Generic'

        name = 'Generic'

    class All(BaseFactCollector):
        _platform = 'Darwin'
        _platform = 'Linux'

    assert find_collectors_for_platform({Apple, Linux, Generic, All},
                                        [{'system': 'Darwin'},
                                         {'system': 'Linux'},
                                         {'system': 'Generic'}]) == {Linux, Apple, Generic, All}

# Generated at 2022-06-20 17:01:38.911604
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # mock out the platform info
    gather_timeout = 30
    valid_subsets = frozenset(('facter', 'hardware'))
    minimal_gather_subset = frozenset(('facter',))
    fake_platform_info = {'system': 'FreeBSD', 'release': '9.2-RELEASE', 'version': 'FreeBSD 9.2-RELEASE #0 r255898: Thu Sep 26 22:50:31 UTC 2013     root@bake.isc.freebsd.org:/usr/obj/usr/src/sys/GENERIC  amd64'}
    gather_subset = ['hardware']
    class hardware(BaseFactCollector):
        _fact_ids = ['devices']
        _platform = 'FreeBSD'
        name = 'hardware'
        required_facts = set()
   

# Generated at 2022-06-20 17:01:49.620724
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['hardware', 'software', 'virtualization', 'network'])
    minimal_gather_subset = frozenset(['network'])
    aliases_ = {'hardware': frozenset(['hardware', 'cpu', 'devices', 'dmi']),
                'virtualization': frozenset(['virtualization', 'hypervisor'])}

    # All tests
    gather_subset = ['all']
    expected = valid_subsets
    actual = get_collector_names(valid_subsets,
                                 minimal_gather_subset,
                                 gather_subset,
                                 aliases_)
    assert actual == expected, "actual: %s, expected: %s" % (actual, expected)

    # Minimal set
    gather_subset = ['min']
    expected

# Generated at 2022-06-20 17:02:01.699301
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact1', 'test_fact2'])

        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact1': 'foo'}

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test2_fact1', 'test_fact2'])

        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2_fact1': 'foo2'}

    class TestCollectorMissingFact(BaseFactCollector):
        _fact_ids = set(['test3_fact1', 'test_fact2'])

        name = 'test3'

    fact_id_

# Generated at 2022-06-20 17:02:09.746315
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import network

    test_fact_id_to_collector_map = {}
    test_fact_id_to_collector_map['foo'] = [network.NetworkCollector]
    test_fact_id_to_collector_map['bar'] = [network.NetworkCollector]
    test_fact_id_to_collector_map['network'] = [network.NetworkCollector]

    actual = build_fact_id_to_collector_map([network.NetworkCollector])
    assert actual == (test_fact_id_to_collector_map, {'network': {'network', 'foo', 'bar'}})



# Generated at 2022-06-20 17:02:14.195189
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('Test for UnresolvedFactDep')
    except ValueError as e:
        assert str(e) == 'Test for UnresolvedFactDep'



# Generated at 2022-06-20 17:02:21.240364
# Unit test for function get_collector_names
def test_get_collector_names():
    # gather_subset=['all']
    assert(get_collector_names(gather_subset=['all'],
                               valid_subsets=['all', 'min', 'hardware', 'network', 'virtual'],
                               minimal_gather_subset=['min'],
                               aliases_map={'hardware': set(['devices', 'dmi', 'pci'])}) ==
                               {'all', 'min', 'hardware', 'network', 'virtual'})

    # gather_subset=['!min']

# Generated at 2022-06-20 17:02:31.115305
# Unit test for function get_collector_names
def test_get_collector_names():
    # case 1: all and default options
    opts = {'gather_subset': ['all']}
    valid_subsets = frozenset(('all', 'network', 'hardware', 'virtual'))
    minimal_subsets = frozenset(('network', 'hardware'))
    collect_subsets = get_collector_names(valid_subsets=valid_subsets,
                                          minimal_gather_subset=minimal_subsets,
                                          **opts)
    assert collect_subsets == valid_subsets

    # case 2: non-existent subset
    # NOTE: we removed 'system' from valid_subsets and aliases_map
    opts = {'gather_subset': ['all', 'system']}

# Generated at 2022-06-20 17:02:35.954517
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        _fact_ids = ['foo']
        name = 'Collector1'
        required_facts = ['bar']

    class Collector2(BaseFactCollector):
        _fact_ids = ['bar']
        name = 'Collector2'
        required_facts = []

    class Collector3(BaseFactCollector):
        _fact_ids = ['missing_fact']
        name = 'Collector3'
        required_facts = ['foo']

    all_fact_subsets = {
        'foo': [Collector1],
        'bar': [Collector2],
        'missing_fact': [Collector3],
    }

    # No unresolved requires with Collector3

# Generated at 2022-06-20 17:02:59.283926
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TempCollector(BaseFactCollector):
        _fact_ids = frozenset(['x', 'y'])
        name = 'foo'
        required_facts = set()

    class TestCollector1(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b'])
        name = 'a'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = frozenset(['b', 'c'])
        name = 'b'
        required_facts = frozenset(['a'])

    class TestCollector3(BaseFactCollector):
        _fact_ids = frozenset(['c', 'd'])
        name = 'c'
        required_facts = frozenset(['a'])


# Generated at 2022-06-20 17:03:00.694446
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    err = CycleFoundInFactDeps('Cycle found')
    assert str(err) == 'Cycle found'
    assert isinstance(err, Exception)




# Generated at 2022-06-20 17:03:05.288461
# Unit test for function resolve_requires
def test_resolve_requires():
    test_map = {'collector_a': ('collectors.B', 'collectors.C'),
                'collector_b': ('collectors.D', ),
                'collector_d': ('collectors.E', ),
            }
    dependency_map = defaultdict(set)
    for fact_collector, required_facts in test_map.items():
        for required_fact in required_facts:
            dependency_map[fact_collector].add(required_fact)

    assert set(resolve_requires(set(['collector_a']), dependency_map)) == set(['collector_a', 'collector_b', 'collector_d'])



# Generated at 2022-06-20 17:03:09.113182
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    # arrange
    testclass = BaseFactCollector()

    # act
    result = testclass.collect()

    # assert
    if (result != {}): raise AssertionError()
    



# Generated at 2022-06-20 17:03:20.200220
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'one': [type('Foo', (object,), {'requires_facts': (('two',),), 'name': 'one'})],
        'two': [type('Foo', (object,), {'requires_facts': (('three',),), 'name': 'two'})],
        'three': [type('Foo', (object,), {'requires_facts': (('four',),), 'name': 'three'})],
        'four': [type('Foo', (object,), {'requires_facts': (), 'name': 'four'})],
        'five': [type('Foo', (object,), {'requires_facts': (), 'name': 'five'})],
    }
    unresolved_requires = set(('one', 'five'))
    resolved = resolve_requires

# Generated at 2022-06-20 17:03:21.368174
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError('collector not found')



# Generated at 2022-06-20 17:03:23.251379
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    exception_obj = CycleFoundInFactDeps()
    assert isinstance(exception_obj, CycleFoundInFactDeps)
    assert isinstance(exception_obj, Exception)


# Generated at 2022-06-20 17:03:30.662214
# Unit test for function build_dep_data
def test_build_dep_data():
    import unittest
    class Collector(BaseFactCollector):
        name = 'test_collector_a'
        required_facts = set()
    class CollectorB(BaseFactCollector):
        name = 'test_collector_b'
        required_facts = set()
    class CollectorC(BaseFactCollector):
        name = 'test_collector_c'
        required_facts = set()
    class CollectorD(BaseFactCollector):
        name = 'test_collector_d'
        required_facts = {'test_collector_c'}
    class CollectorE(BaseFactCollector):
        name = 'test_collector_e'
        required_facts = {'test_collector_c'}
    class CollectorF(BaseFactCollector):
        name = 'test_collector_f'


# Generated at 2022-06-20 17:03:34.209147
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    exc = UnresolvedFactDep('foo')

    assert exc.args[0] == 'foo'



# Generated at 2022-06-20 17:03:37.675047
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    cnfe = CollectorNotFoundError(1)
    assert cnfe.args == (1,)
    cnfe.__str__()
    cnfe.__repr__()


# Generated at 2022-06-20 17:04:01.725113
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:# code that can raise a KeyError
        raise CollectorNotFoundError
    except CollectorNotFoundError as e:
        assert(e.args == ())
        pass

    try:# code that can raise a KeyError
        raise CollectorNotFoundError("custom message")
    except CollectorNotFoundError as e:
        assert(e.args == ("custom message",))
        pass



# Generated at 2022-06-20 17:04:10.965600
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)
    class MyCollector(BaseFactCollector):
        pass
    all_fact_subsets['all'].append(MyCollector)
    MyCollector.required_facts = {'foo'}
    #TEST
    assert(set() == find_unresolved_requires({'all'}, all_fact_subsets))
    #TEST
    assert(set() == find_unresolved_requires({'nonexistant_collector'}, all_fact_subsets))
    #TEST
    assert(set(['foo']) == find_unresolved_requires({'all', 'foo'}, all_fact_subsets))
    class MyCollector(BaseFactCollector):
        pass
    all_fact_subsets['all'].append(MyCollector)

# Generated at 2022-06-20 17:04:17.922306
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    fact_collector = BaseFactCollector()
    collected_facts = dict()
    assert fact_collector.collect(collected_facts=collected_facts) == {}
    fact_collector = BaseFactCollector(namespace="ansible")
    assert fact_collector.collect(collected_facts=collected_facts) == {}

# Generated at 2022-06-20 17:04:30.880585
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollectorClass(BaseFactCollector):
        _fact_ids = ['a_alias', 'b_alias']
        name = 'a_primary'

    class TestCollectorClass2(BaseFactCollector):
        _fact_ids = ['c_alias']
        name = 'c_primary'

    class TestCollectorClass3(BaseFactCollector):
        _fact_ids = ['d_alias', 'e_alias']
        name = 'd_primary'

    all_collectors_for_platform = [TestCollectorClass, TestCollectorClass2, TestCollectorClass3]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors_for_platform)

    assert fact_id_to_collector_map['a_primary']

# Generated at 2022-06-20 17:04:41.465172
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    import unittest

    # remember the original state of _COLLECTOR_CLASSES
    _COLLECTOR_CLASSES = set(collectors._COLLECTOR_CLASSES)

    class TestCollectorA(BaseFactCollector):
        _platform = 'A'
        name = 'A'

    class TestCollectorB(BaseFactCollector):
        _platform = 'B'
        name = 'B'

    class TestCollectorC_generic(BaseFactCollector):
        _platform = 'Generic'
        name = 'Generic'

    class TestCollectorC(TestCollectorC_generic):
        _platform = 'C'
        name = 'C'

    class TestCollectorD(BaseFactCollector):
        _platform = 'D'
        name = 'D'

# Generated at 2022-06-20 17:04:53.159727
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''
    Make sure that the find_unresolved_requires function correctly
    finds all unresolved requires then correctly handles the
    removal of duplicate names
    '''
    # create a list of names for the function to parse
    test_list = ['arch', 'distribution', 'distribution_release']

    # create a list of names for the function to parse
    test_list2 = ['arch', 'distribution', 'distribution_release', 'distribution_version']

    # create a list of names for the function to parse
    test_list3 = ['arch', 'distribution', 'distribution_release', 'distribution_version', 'distribution_major_version']

    # create a list of names for the function to parse

# Generated at 2022-06-20 17:05:00.745882
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'TestCollector'
        def collect(self):
            return {'test_key': 'test_value'}

    class TestNamespace:
        def transform(self, fact_name):
            return 'prefix-' + fact_name

    test_collector = TestCollector()
    test_collector_ns = TestCollector(namespace=TestNamespace())
    assert test_collector.collect() == {'test_key': 'test_value'}
    assert test_collector_ns.collect_with_namespace() == {'prefix-test_key': 'test_value'}


# Base class for Platform-specific FactCollectors.
# This class is intended to be subclassed.

# Generated at 2022-06-20 17:05:13.118480
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.utils import FactsCollector, network, hardware, network2
    all_fact_subsets = {
        'all': [network, hardware],
        'network': [network, network2],
        'hardware': [hardware, network],
    }

    actual = select_collector_classes(['network'], all_fact_subsets)
    expected = [network, network2]
    assert actual == expected

    actual = select_collector_classes(['network', 'hardware'], all_fact_subsets)
    expected = [network, network2, hardware]
    assert actual == expected

    actual = select_collector_classes(['network', 'hardware', 'network'], all_fact_subsets)
    expected = [network, network2, hardware]
    assert actual == expected



# Generated at 2022-06-20 17:05:25.287591
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    import unittest2
    import unittest2.mock as mock
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts import collector

    class TestClass(collector.BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    class TestNamespace:
        def transform(self, value):
            return '{0}-{1}'.format(self.prefix, value)
        def test_no_name(self):
            '''If there is no namespace, an empty dict should be returned.'''
            t = TestClass()
            result = t.collect_with_namespace()
            assert result == {}


# Generated at 2022-06-20 17:05:31.909239
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'all': [],
        'network': [],
        'min': [],
        'system': [],
    }
    assert resolve_requires(set(['min']), all_fact_subsets) == set(['min'])
    assert resolve_requires(set(['unknown']), all_fact_subsets) == set([])
    assert resolve_requires(set(['unknown', 'min']), all_fact_subsets) == set(['min'])

