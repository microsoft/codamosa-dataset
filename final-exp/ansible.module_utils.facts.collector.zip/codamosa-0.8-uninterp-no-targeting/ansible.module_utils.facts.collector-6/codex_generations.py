

# Generated at 2022-06-20 16:57:13.467358
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''
    Test build_fact_id_to_collector_map
    '''
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _platform = 'Generic'
        _fact_ids = {'test_collector_dep', 'test_collector_dep1'}

    class TestCollectorDup(BaseFactCollector):
        name = 'test_collector'
        _platform = 'Generic'
        _fact_ids = {'test_collector_dup_dep'}

    # Test with no collector
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([])
    assert fact_id_to_collector_map == {}
    assert aliases_map == defaultdict(set)

    # Test

# Generated at 2022-06-20 16:57:20.512030
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class FakeCollector:
        def __init__(self, name, required=None, _fact_ids=None):
            self.name = name
            self.required_facts = required or set()
            self._fact_ids = _fact_ids or set()

        @classmethod
        def platform_match(self, platform_info):
            return self

    # contains all facts that are gathered by this module
    all_facts_subsets = {}
    all_facts_subsets['a'] = [FakeCollector('a', ['b'], ['aid'])]
    all_facts_subsets['b'] = [FakeCollector('b', ['c'], ['bid'])]
    all_facts_subsets['c'] = [FakeCollector('c', [], ['cid'])]

    # used to determine what a gather subset

# Generated at 2022-06-20 16:57:27.497482
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():


    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a_1', 'a_2'])
        _platform = 'FreeBSD'


    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b_1', 'b_2'])
        _platform = 'Linux'


    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c_1', 'c_2'])
        _platform = 'Linux'


    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d_1', 'd_2'])
        _platform = 'Generic'



# Generated at 2022-06-20 16:57:33.357356
# Unit test for function resolve_requires
def test_resolve_requires():
    all_fact_subsets = {
        'all': [object()],
        '!min': [object()],
    }
    assert resolve_requires({'all', '!min'}, all_fact_subsets) == set()



# Generated at 2022-06-20 16:57:35.090603
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    c = CollectorNotFoundError('foo')
    assert c.args[0] == 'could not find foo fact collector'



# Generated at 2022-06-20 16:57:40.322151
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('could not resolve dependency between fact_a and fact_b')
    except UnresolvedFactDep as e:
        assert str(e) == 'could not resolve dependency between fact_a and fact_b'


# Generated at 2022-06-20 16:57:45.248843
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils import facts

    all_collectors = list(facts.get_collector_classes())
    for col_class in all_collectors:
        col_class._platform = 'Generic'
    platform_info = {'system': 'Linux', 'major': '7'}
    found_collectors = find_collectors_for_platform(all_collectors, [platform_info])
    assert len(found_collectors) > 6
    assert len(found_collectors) < len(all_collectors)



# Generated at 2022-06-20 16:57:49.314239
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [FakeCollector(required_facts=['b', 'c'])],
        'b': [FakeCollector(required_facts=['d'])],
        'c': [FakeCollector(required_facts=['d'])],
        'd': [FakeCollector(required_facts=['e'])],
    }

    assert find_unresolved_requires(['a', 'b'], all_fact_subsets) == set(['e', 'c'])


# TODO/FIXME: add unit tests

# Generated at 2022-06-20 16:58:00.792394
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    '''Test the find_collectors_for_platform() function
    '''

    # define a fake class that matches a platform
    class TestFactCollector:
        _platform = 'FakeOS'
        name = 'test'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            else:
                return None

    # define a fake platform_info
    platform_info = {
        'system': 'FakeOS',
        'release': '0.1',
    }

    # define a set of fake collector classes
    all_collector_classes = [TestFactCollector]

    # define a set of fake compat_platforms
    compat_platforms = [platform_info]

    # check if the test

# Generated at 2022-06-20 16:58:12.019180
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.collector.legacy import LegacyCollector
    from ansible.module_utils.facts.collector.network.base import NetworkCollector
    from ansible.module_utils.facts.collector.network.junos import JunosNetworkCollector
    from ansible.module_utils.facts.collector.network.iosxr import IosxrNetworkCollector
    from ansible.module_utils.facts.collector.network.ios import IosNetworkCollector
    from ansible.module_utils.facts.collector.network.nxos import NxosNetworkCollector
    from ansible.module_utils.facts.collector.network.eos import EosNetworkCollector

    # basic test to make sure it works for a few
   

# Generated at 2022-06-20 16:58:33.407394
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collectors import cpu
    from ansible.module_utils.facts.collectors import disk
    from ansible.module_utils.facts.collectors import dns
    from ansible.module_utils.facts.collectors import system
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import memory
    from ansible.module_utils.facts.collectors import virtual
    from ansible.module_utils.facts.collectors import cmdline
    from ansible.module_utils.facts.collectors import selinux
    from ansible.module_utils.facts.collectors import timezone
    from ansible.module_utils.facts.collectors import ohai


# Generated at 2022-06-20 16:58:45.436725
# Unit test for function get_collector_names
def test_get_collector_names():
    # Expected: minimal + all
    assert get_collector_names(valid_subsets=frozenset(('all', 'foo', 'bar')),
                               gather_subset=None) == frozenset(('all', 'min', 'foo', 'bar'))
    # Expected: minimal1 + minimal2 + minimal3 - minimal2

# Generated at 2022-06-20 16:58:52.673096
# Unit test for function tsort
def test_tsort():
    from nose.tools import assert_equals
    from nose.tools import assert_raises
    from functools import partial

    dep_map = {
        'A': frozenset(['B', 'C']),
        'B': frozenset(['C']),
        'C': frozenset(['D'])
    }

    # test a simple case
    assert_equals(tsort(dep_map), [('B', frozenset(['C'])), ('C', frozenset(['D'])), ('A', frozenset(['B', 'C']))])

    # this one should raise an exception

# Generated at 2022-06-20 16:58:53.753444
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    bc = BaseFactCollector()
    assert bc.fact_ids == set([None])


# Generated at 2022-06-20 16:58:57.776950
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    facts_dict={'a':1,'b':2}
    assert BaseFactCollector().collect(collected_facts=facts_dict)=={}


# Generated at 2022-06-20 16:59:07.108096
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    def _make_collector(name, aliases):
        class Collector(BaseFactCollector):
            name = name
            _fact_ids = aliases

        return Collector

    _collectors = [
        _make_collector('a', ['a', 'aa', 'aaa']),
        _make_collector('b', ['b', 'bb', 'bbb']),
        _make_collector('c', ['c', 'cc', 'ccc']),
        _make_collector('d', ['d', 'dd', 'ddd']),
    ]

    result = build_fact_id_to_collector_map(_collectors)

    assert(len(result) == 2)
    assert(len(result[0]) == 12)
    assert(len(result[1]) == 4)


# Generated at 2022-06-20 16:59:18.068149
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with invalid subset
    try:
        get_collector_names(gather_subset=['foo'])
        assert False
    except TypeError:
        pass

    # Test with valid subset
    try:
        assert get_collector_names(gather_subset=['network']) == set(['network'])
    except TypeError:
        assert False

    # Test with valid subset with exclusion
    try:
        assert get_collector_names(gather_subset=['!network']) == set()
    except TypeError:
        assert False

    # Test with valid subset with exclusion but with aliases

# Generated at 2022-06-20 16:59:19.128622
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    CollectorNotFoundError("Foo")



# Generated at 2022-06-20 16:59:27.645878
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class FakeCollector1(BaseFactCollector):
        _platform = 'AIX'
        name = 'foo'
    class FakeCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'bar'
    class FakeCollector3(BaseFactCollector):
        _platform = 'SunOS'
        name = 'baz'

    all_collector_classes = set([FakeCollector1, FakeCollector2, FakeCollector3])

    # Make sure we get all the platform specific ones
    compat_platforms = [{'system': 'AIX'}, {'system': 'Linux'}, {'system': 'SunOS'}]
    found_collectors_for_platform = find_collectors_for_platform(all_collector_classes, compat_platforms)

# Generated at 2022-06-20 16:59:39.100755
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # test that we get a unique set of FactCollectors for a given list of Fact Collector names
    # even when there are duplicate collectors for the same name
    class TestCollector1(BaseFactCollector):
        name = 'test'

        def __init__(self, **kwargs):
            super(TestCollector1, self).__init__(**kwargs)

    class TestCollector2(BaseFactCollector):
        name = 'test'

        def __init__(self, **kwargs):
            super(TestCollector2, self).__init__(**kwargs)


    class TestCollector3(BaseFactCollector):
        name = 'test'

        def __init__(self, **kwargs):
            super(TestCollector3, self).__init__(**kwargs)

    all_fact_subset

# Generated at 2022-06-20 16:59:52.962090
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class TestCollectorA(BaseFactCollector):
        _fact_ids = []
        _platform = 'TestPlatformA'
        name = 'name_a'

    class TestCollectorB(BaseFactCollector):
        _fact_ids = []
        _platform = 'TestPlatformB'
        name = 'name_b'

    class TestCollectorC(BaseFactCollector):
        _fact_ids = []
        _platform = 'TestPlatformC'
        name = 'name_c'

    class TestCollectorD(BaseFactCollector):
        _fact_ids = []
        _platform = 'Generic'
        name = 'name_d'

    all_collector_classes = [
        TestCollectorA,
        TestCollectorB,
        TestCollectorC,
        TestCollectorD,
    ]



# Generated at 2022-06-20 16:59:55.628318
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    temp_p = platform
    platform.system = lambda : 'Linux'
    test = BaseFactCollector()
    assert test.collect() == {}
    platform = temp_p



# Generated at 2022-06-20 17:00:07.600420
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts._collector.virtual import VirtualCollector
    from ansible.module_utils.facts._collector.default import DefaultCollector

    # Reset state of both collectors
    VirtualCollector.has_run = False
    DefaultCollector.has_run = False

    # Test case
    platform_info = {'system': 'AIX'}
    compat_platforms = [platform_info, {'system': 'Generic'}]
    all_collector_classes = [VirtualCollector, DefaultCollector]

    # Assert expected
    assert find_collectors_for_platform(all_collector_classes, compat_platforms) == {VirtualCollector}



# Generated at 2022-06-20 17:00:18.905590
# Unit test for function tsort
def test_tsort():
    # Test graph is from https://en.wikipedia.org/wiki/Topological_sorting#Example
    dep_map = defaultdict(set)
    dep_map[3].add(8)
    dep_map[5].add(11)
    dep_map[7].add(11)
    dep_map[7].add(8)
    dep_map[8].add(2)
    dep_map[11].add(9)
    dep_map[11].add(10)
    dep_map[8].add(9)
    dep_map[3].add(10)


# Generated at 2022-06-20 17:00:30.289077
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import CollectorNotFoundError

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['foo', 'bar'])

    collector_names_set = set(['test'])
    fact_subset_map = {}
    fact_subset_map['test'] = [TestCollector]
    fact_subset_map['foo'] = [TestCollector]
    fact_subset_map['bar'] = [TestCollector]
    fact_subset_map['baz'] = [TestCollector]

    assert find_unresolved_requires(collector_names_set, fact_subset_map) == set(['foo', 'bar'])

# Generated at 2022-06-20 17:00:38.948629
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    ''' Unit test for find_unresolved_requires '''

    class TestCollector1(BaseFactCollector):
        name = 'testcollector1'
        required_facts = ['testcollector2']
    class TestCollector2(BaseFactCollector):
        name = 'testcollector2'
        required_facts = ['testcollector3']
    class TestCollector3(BaseFactCollector):
        name = 'testcollector3'
        required_facts = []

    all_fact_subsets = {
        'testcollector1': [TestCollector1],
        'testcollector2': [TestCollector2],
        'testcollector3': [TestCollector3],
    }

    collector_names = set(['testcollector1'])

    # test does not find a required collector

# Generated at 2022-06-20 17:00:46.888318
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as e:
        assert e.args == ('test',)

platform_os_facts = {
    'Linux': 'Linux',
    'Darwin': 'MacOSX',
    'NetBSD': 'NetBSD',
    'FreeBSD': 'BSD',
    'OpenBSD': 'BSD',
}



# Generated at 2022-06-20 17:00:58.045855
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.network.base import BaseNetworkCollector
    from ansible.module_utils.facts.hardware.base import BaseHardwareCollector

    class NetworkHardwareCollector(BaseHardwareCollector):
        name = 'name1'
        _fact_ids = ['hardware', 'networking']

    all_fact_subsets = {
        'hardware': [NetworkHardwareCollector],
        'networking': [BaseNetworkCollector, NetworkHardwareCollector],
    }

    # collector_name = 'hardware'
    collector_name = 'networking'
    selected_collector_classes = select_collector_classes([collector_name], all_fact_subsets)
    assert selected_collector_classes == all_fact_subsets[collector_name]



# Generated at 2022-06-20 17:01:08.417089
# Unit test for function get_collector_names
def test_get_collector_names():
    '''unit test for get_collector_names'''

    # 'all' == min + os + hardware + network + virtual
    all_subsets = frozenset(['min', 'os', 'hardware', 'network', 'virtual'])
    min_subsets = frozenset(['min'])

    # First test a normal call
    collector_names = get_collector_names(
        valid_subsets=all_subsets,
        gather_subset=['!all'],
        platform_info=dict(system='Generic'))
    assert collector_names == frozenset([])

    # Test empty gather subset
    collector_names = get_collector_names(valid_subsets=all_subsets,
                                          gather_subset=[],
                                          platform_info=dict(system='Generic'))


# Generated at 2022-06-20 17:01:18.880537
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set()
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_2'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3', 'test_fact_id_4'])
        name = 'test_collector_3'

    collectors = [TestCollector1, TestCollector2, TestCollector3]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)

    assert len(fact_id_to_collector_map)

# Generated at 2022-06-20 17:01:32.542701
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['one', 'two', 'three']
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['one'].append(BaseFactCollector)
    all_fact_subsets['one'].append(BaseFactCollector)
    all_fact_subsets['two'].append(BaseFactCollector)
    all_fact_subsets['two'].append(BaseFactCollector)
    all_fact_subsets['three'].append(BaseFactCollector)
    all_fact_subsets['three'].append(BaseFactCollector)

    all_fact_subsets['one'][0].required_facts = {'two'}
    all_fact_subsets['one'][1].required_facts = {'three'}


# Generated at 2022-06-20 17:01:38.423766
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [CollectorOne, CollectorTwo, CollectorThree]
    compat_platforms = []

    def test_platform_match_one(platform):
        '''match to CollectorOne'''
        return CollectorOne if platform['system'] == CollectorOne._platform else None

    def test_platform_match_two(platform):
        '''match to CollectorTwo'''
        return CollectorTwo if platform['system'] == CollectorTwo._platform else None

    CollectorOne.platform_match = test_platform_match_one
    CollectorTwo.platform_match = test_platform_match_two
    CollectorThree.platform_match = test_platform_match_one

    # first all Linux
    compat_platforms = [{'system': 'Linux'}]

# Generated at 2022-06-20 17:01:41.081974
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    e = CycleFoundInFactDeps('msg')
    assert e.args[0] == 'msg'


# Generated at 2022-06-20 17:01:53.165598
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('all', 'network', 'virtual'),
                               minimal_gather_subset=('all', 'network'),
                               gather_subset=set(['all', 'network'])) == set(('network', 'all'))

    assert get_collector_names(valid_subsets=('all', 'network', 'virtual'),
                               minimal_gather_subset=('all', 'network'),
                               gather_subset=set(['network'])) == set(('network',))

    assert get_collector_names(valid_subsets=('all', 'network', 'virtual'),
                               minimal_gather_subset=('all', 'network'),
                               gather_subset=set(['virtual'])) == set(('virtual',))

    assert get_collector_

# Generated at 2022-06-20 17:01:59.448268
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collect_subset, collectors
    all_collector_classes = collectors.get_collector_classes()
    compat_platforms = [
        {'system': 'Linux'}
    ]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert(len(found_collectors) == 1)
    platform_match = None
    for all_collector_class in all_collector_classes:
        # ask the class if it is compatible with the platform info
        if all_collector_class.name == "network":
            platform_match = all_collector_class.platform_match(compat_platforms[0])

    assert(platform_match)


# Generated at 2022-06-20 17:02:04.591838
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils.facts.collector import (BaseFactCollector,
                                                      find_collectors_for_platform,
                                                      build_fact_id_to_collector_map,
                                                      select_collector_classes, )
    from ansible.module_utils.facts.collectors.network.default import Default

    # NOTE: configuring the minimal_gather_subset makes the test more robust,
    # so we can keep the 'all' option in the gather_subset without
    # triggering the 'all' collector.
    fake_minimal_gather_subset = frozenset([Default.name])
    # configuring the 'all' option to be an empty list also makes the test more robust
    fake_all_option = frozenset([])

    all_collector_classes = []
   

# Generated at 2022-06-20 17:02:17.724974
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class Collector1(BaseFactCollector):
        name = 'collector1'

    class Collector2(BaseFactCollector):
        name = 'collector2'

    class Collector2a(BaseFactCollector):
        name = 'collector2'

    class Collector3(BaseFactCollector):
        name = 'collector3'

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = ['collector1']

    class Collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = ['collector2', 'collector1']

    class Collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = ['collector3']

    class Collector7(BaseFactCollector):
        name = 'collector7'


# Generated at 2022-06-20 17:02:20.657197
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    obj = CollectorNotFoundError('name')
    assert obj.args[0] == 'name'



# Generated at 2022-06-20 17:02:22.411468
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    namespace = Namespace()
    collector = BaseFactCollector()
    assert collector.collect_with_namespace(collected_facts={}) == {}


# Generated at 2022-06-20 17:02:27.888665
# Unit test for function build_dep_data
def test_build_dep_data():
    dummy_collector_classes = [DummyCollector('a', ['b']),
                               DummyCollector('b', ['c']),
                               DummyCollector('c', [])]
    all_fact_subsets = defaultdict(list, {'a': [dummy_collector_classes[0]],
                                          'b': [dummy_collector_classes[1]],
                                          'c': [dummy_collector_classes[2]],
                                          'd': []})
    collector_names = ['a', 'b', 'c']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    expected_result = {'a': {'b'}, 'b': {'c'}, 'c': set()}

# Generated at 2022-06-20 17:02:43.073881
# Unit test for function get_collector_names
def test_get_collector_names():
    # 1A. Some (not all) subsets are defined.
    assert get_collector_names(gather_subset=['network', 'hardware'],
                               valid_subsets=frozenset(['network', 'hardware', 'ohai', 'system']),) == \
           frozenset(['network', 'hardware'])

    # 1B. All subsets are defined.
    assert get_collector_names(gather_subset=['network', 'hardware', 'ohai', 'system'],
                               valid_subsets=frozenset(['network', 'hardware', 'ohai', 'system']),) == \
           frozenset(['network', 'hardware', 'ohai', 'system'])

    # 1C. All subsets are defined. Additional subset is ignored.

# Generated at 2022-06-20 17:02:50.546571
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    from ansible.module_utils.facts.collectors import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixNamespace

    facts = BaseFactCollector()
    assert isinstance(facts, BaseFactCollector)
    assert facts.collectors == []

    facts = BaseFactCollector(['facts', 'facts1'])
    assert isinstance(facts, BaseFactCollector)
    assert facts.collectors == ['facts', 'facts1']

    facts = BaseFactCollector(namespace=PrefixNamespace('test'))
    assert isinstance(facts, BaseFactCollector)
    assert facts.collectors == []
    assert facts.namespace == PrefixNamespace('test')

test_BaseFactCollector()



# Generated at 2022-06-20 17:02:59.414729
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Invalid Input - Collector class not found for the name given
    collector_names = set(['test1', 'test2'])
    all_fact_subsets = defaultdict()
    all_fact_subsets['test1'] = [1, 2, 3]

    # Invalid Input - Collector class not found for the name given
    collector_names.add('test3')
    all_fact_subsets['test1'] = [1, 2]

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert(len(selected_collector_classes) == 3)



# Generated at 2022-06-20 17:03:06.381265
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    # Set up test objects/values
    a = BaseFactCollector()
    module = None
    collected_facts = {}

    # Call the method
    result = a.collect_with_namespace(module, collected_facts)

    # Verify the result
    assert result == {}



# Generated at 2022-06-20 17:03:19.066602
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector1 = BaseFactCollector()
    collector1._fact_ids = set('test_col1')
    collector1.name = 'test_col1'
    collector2 = BaseFactCollector()
    collector2._fact_ids = set('test_col2')
    collector2.name = 'test_col2'
    collector3 = BaseFactCollector()
    collector3._fact_ids = set('test_col3')
    collector3.name = 'test_col3'
    collector4 = BaseFactCollector()
    collector4._fact_ids = set('test_col4')
    collector4.name = 'test_col4'

    all_fact_subsets = {
        collector1.name: [collector1, collector4],
        collector2.name: [collector2]
    }

    selected_

# Generated at 2022-06-20 17:03:30.066212
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = frozenset(['a', 'b', 'c', 'd'])
    all_fact_subsets = {
        'a': [
            MockCollector(name='a', required_facts=frozenset()),
        ],
        'b': [
            MockCollector(name='b', required_facts=frozenset(['b', 'a'])),
        ],
        'c': [
            MockCollector(name='c', required_facts=frozenset(['c', 'a'])),
        ],
        'd': [
            MockCollector(name='d', required_facts=frozenset(['d', 'c', 'b'])),
        ],
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-20 17:03:31.960431
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # No assertion
    CycleFoundInFactDeps('description of problem')



# Generated at 2022-06-20 17:03:38.960144
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    # Test exception message construction
    try:
        raise CollectorNotFoundError('test')
    except CollectorNotFoundError as error:
        assert str(error) == "Fact collector 'test' could not be found"

    # Test exception with no message
    try:
        raise CollectorNotFoundError(None)
    except CollectorNotFoundError as error:
        assert str(error) == 'Fact collector could not be found'



# Generated at 2022-06-20 17:03:46.808386
# Unit test for function build_dep_data
def test_build_dep_data():
    expected_dep_map = {
        'A': {'B', 'C'},
        'B': {'D'},
        'C': {'D'},
        'D': set(),
        }
    all_fact_subsets = {
        'A': [
            _MockCollector('A', frozenset({'B', 'C'})),
        ],
        'B': [
            _MockCollector('B', frozenset({'D'})),
        ],
        'C': [
            _MockCollector('C', frozenset({'D'})),
        ],
        'D': [
            _MockCollector('D', frozenset({})),
        ],
    }

# Generated at 2022-06-20 17:03:48.798231
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    o = CycleFoundInFactDeps()
    assert o is not None


# Generated at 2022-06-20 17:04:04.767443
# Unit test for constructor of class UnresolvedFactDep
def test_UnresolvedFactDep():
    try:
        raise UnresolvedFactDep('foo')
    except UnresolvedFactDep as ex:                                                                                                                                                            
        assert ex.args[0] == 'foo'


# Generated at 2022-06-20 17:04:15.286310
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collectors
    collectors_for_platform = [
        collectors.SystemCollector(),
        collectors.LinuxKernelCollector(),
        collectors.DistributionCollector(),
        collectors.PlatformCollector(),
        collectors.LocaleCollector(),
        collectors.HardwareCollector(),
        collectors.VirtualizationCollector(),
    ]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-20 17:04:22.988427
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    class SomeFactCollector(BaseFactCollector):
        # provide a name that's different than the class name
        name = 'somename'

        # provide a platform and platform_match that matches
        _platform = platform.system()
        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None

        def collect(self, module=None, collected_facts=None):
            return 'returned value'

    collector = SomeFactCollector()
    assert collector.name == 'somename'
    assert collector.collect() == 'returned value'
    # returns an empty dict
    assert collector.collect_with_namespace() == {}

    # add a namespace, and make sure it is used

# Generated at 2022-06-20 17:04:32.856829
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Unit test for function get_collector_names

    The get_collector_names relies on many data structures that are not part of its input.
    These data structures are complex enough that it is difficult to unit test get_collector_names
    without involving them. This function will mock these data structures and test get_collector_names
    with each one of the data structures.
    '''
    class MockCollector(BaseFactCollector):
        '''Mock implementation of a BaseFactCollector

        A fact collector with a name and platform_match method
        '''
        _platform = 'Mock'
        name = 'mock_collector'

        @classmethod
        def platform_match(cls, platform_info):
            '''Return if the platform_info matches this collector.'''

# Generated at 2022-06-20 17:04:42.127910
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.platform.generic import GenericFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network.bonds import BondFactCollector

    class RequiresBond(BaseFactCollector):
        name = 'requires_bond'
        required_facts = set(['bond'])

    class RequiresNoSuchThing(BaseFactCollector):
        name = 'requires_no_such_thing'
        required_facts = set(['no_such_thing'])

    class RequiresAll(BaseFactCollector):
        name = 'requires_all'
        required_facts = set(['all'])

    class RequiresSomething(BaseFactCollector):
        name = 'requires_something'
        required_

# Generated at 2022-06-20 17:04:48.198288
# Unit test for function resolve_requires
def test_resolve_requires():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import _platform_info

    # Unit test needs to work on all platforms, so we create a list of possible platforms and
    # test each one to make sure that there is no unresolved dependencies.
    all_platform_info = []
    all_platform_info.append(dict(platform.uname()._asdict()))
    all_platform_info.extend(_platform_info())

    for platform_info in all_platform_info:
        all_fact_subsets = get_fact_subsets(platform_info=platform_info)

        # Now test the resolution
        unresolved_requires = find_unresolved_requires(['min'], all_fact_subsets)
        assert not unresolved_requires

        # There should be no unresolved dependencies,

# Generated at 2022-06-20 17:05:01.615660
# Unit test for function tsort
def test_tsort():
    dep_map = dict(a=set(), b=set(['a']), c=set(['a']), d=set(['c']), e=set(['c']), f=set(['b', 'd']), g=set(['d']))
    assert tsort(dep_map) == [('a', set()), ('b', set(['a'])), ('c', set(['a'])), ('d', set(['c'])), ('e', set(['c'])), ('f', set(['b', 'd'])), ('g', set(['d']))]

    dep_map = dict(a=set(['b']), b=set(['a']))

# Generated at 2022-06-20 17:05:10.696774
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    ''' Test for BaseFact Collector '''
    class DummyFactCollector(BaseFactCollector):
        name = 'dummy'
        _platform = 'Generic'

    assert DummyFactCollector().name == 'dummy'
    assert DummyFactCollector(['foo']).collectors == ['foo']
    assert DummyFactCollector([]).collectors == []
    assert DummyFactCollector(namespace='foo').namespace == 'foo'
    assert DummyFactCollector(namespace=None).namespace == None


# Generated at 2022-06-20 17:05:24.312070
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class KnownCollector1(BaseFactCollector):
        name = 'known_collector_1'
        required_facts = set()

    class KnownCollector2(BaseFactCollector):
        name = 'known_collector_2'
        required_facts = set()

    class KnownCollector3(BaseFactCollector):
        name = 'known_collector_3'
        required_facts = set()

    class KnownCollector4(BaseFactCollector):
        name = 'known_collector_4'
        required_facts = set(['known_collector_1'])

    class KnownCollector5(BaseFactCollector):
        name = 'known_collector_5'
        required_facts = set(['known_collector_1', 'known_collector_2'])


# Generated at 2022-06-20 17:05:26.271119
# Unit test for constructor of class CollectorNotFoundError
def test_CollectorNotFoundError():
    error = CollectorNotFoundError('some_name')
    assert error.args == ('some_name', )



# Generated at 2022-06-20 17:05:57.409932
# Unit test for constructor of class BaseFactCollector
def test_BaseFactCollector():
    fc = BaseFactCollector()
    assert fc.fact_ids == {'Generic'}, 'The ids are not what is expected: %s' % fc.fact_ids



# Generated at 2022-06-20 17:06:01.058535
# Unit test for method collect of class BaseFactCollector
def test_BaseFactCollector_collect():
    assert type(BaseFactCollector()) is BaseFactCollector
    test_fact_collector = BaseFactCollector()
    assert test_fact_collector.collect() == {}


# Generated at 2022-06-20 17:06:13.935632
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collectors = [TestDepsCollector('ALL'),
                  TestDepsCollector('A', requires=['C']),
                  TestDepsCollector('B', requires=['ALL', 'C', 'D']),
                  TestDepsCollector('C', requires=['D']),
                  TestDepsCollector('D', requires=['C']),
                  TestDepsCollector('E', requires=['X']),
                  TestDepsCollector('X', requires=['Y']),
                 ]

    all_fact_subsets = defaultdict(list)
    for collector in collectors:
        fact_subsets = collector._fact_ids
        fact_subsets.add(collector.name)
        for fact_subset in fact_subsets:
            all_fact_subsets[fact_subset].append(collector)

    unresolved

# Generated at 2022-06-20 17:06:22.735885
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['networking', 'networking_linux', 'networking_ios']
    collector_map = defaultdict(list)
    collector_map['networking'].append(1)
    collector_map['networking_linux'].append(2)
    collector_map['networking_ios'].append(3)

    result = select_collector_classes(collector_names, collector_map)
    assert result == [1, 2, 3]


# Generated at 2022-06-20 17:06:33.776283
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector import BaseFactCollector
    obj = BaseFactCollector()
    obj._transform_name = MagicMock()
    obj.collect = MagicMock(return_value={"eth0": {"macaddress": "00:11:22:33:44:55"}})
    obj._transform_dict_keys = MagicMock()
    with pytest.raises(AssertionError) as excinfo:
        obj.collect_with_namespace(collected_facts={"collected_facts": {}})
    pytest.raises(AssertionError, obj.collect_with_namespace, collected_facts={"collected_facts": {}})
    assert str(excinfo.value) == 'missing required positional argument: module'

# Generated at 2022-06-20 17:06:45.736133
# Unit test for constructor of class CycleFoundInFactDeps
def test_CycleFoundInFactDeps():
    # Create args for fact collector: collector-A
    fact_collector_deps = {
        'fact_collector_key_a': ['foo', 'bar'],
        'fact_collector_key_b': ['foo', 'bar']
    }
    collector_name_a = 'collector-A'
    fact_collector_a = {
        'collector_key': 'collector-A',
        'fact_collector_key_a': ['foo', 'bar'],
        'fact_collector_key_b': ['foo', 'bar']
    }
    # Create args for fact collector: collector-B