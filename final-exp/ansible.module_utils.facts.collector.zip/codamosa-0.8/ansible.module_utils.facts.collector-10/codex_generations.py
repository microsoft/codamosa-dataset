

# Generated at 2022-06-11 02:12:24.239153
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class MyCollectorA(BaseFactCollector):
        name = 'A'

    class MyCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class MyCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets[MyCollectorA.name].append(MyCollectorA)
    all_fact_subsets[MyCollectorB.name].append(MyCollectorB)
    all_fact_subsets[MyCollectorC.name].append(MyCollectorC)

    unresolved = find_unresolved_requires(set(['A', 'B']), all_fact_subsets)

# Generated at 2022-06-11 02:12:34.631802
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test func find_unresolved_requires'''
    all_fact_subsets = defaultdict(list)
    collector_names = set()
    required_facts = set()

    class Collector1:
        name = 'Collector1'
        required_facts = {'FACT2'}
    class Collector2:
        name = 'Collector2'
        required_facts = {'FACT3'}
    class Collector3:
        name = 'Collector3'
        required_facts = {'unresolved'}
    class Collector4:
        name = 'Collector4'
        required_facts = {'resolved', 'resolved'}

    for collector in (Collector1, Collector2, Collector3, Collector4):
        all_fact_subsets[collector.name].append(collector)
       

# Generated at 2022-06-11 02:12:45.803947
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import pytest
    from ansible.module_utils.facts.virtual import VirtualCollector
    class TestCollector(BaseFactCollector):
        _fact_ids = frozenset(['basic_fact'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = frozenset(['depends_on_test_collector'])
        name = 'depends_on_test_collector'
        required_facts = frozenset(['test_collector'])

    TC_INSTANCE = TestCollector()
    TC2_INSTANCE = TestCollector2()

    TEST_collectors_for_platform = [TestCollector, TestCollector2, VirtualCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id

# Generated at 2022-06-11 02:12:57.265281
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {'all': [SystemCollector]}
    collector_names = ['all']
    assert not find_unresolved_requires(collector_names, all_fact_subsets)

    all_fact_subsets = {'all': [SystemCollector]}
    collector_names = ['system']
    assert 'system' in find_unresolved_requires(collector_names, all_fact_subsets)
    collector_names = ['some_bad_collector']
    assert CollectorNotFoundError in find_unresolved_requires(collector_names, all_fact_subsets)

    collector_names = ['some_bad_collector']

# Generated at 2022-06-11 02:13:08.449098
# Unit test for function get_collector_names
def test_get_collector_names():
    # valid subset
    valid_subsets = frozenset(['all', 'network', 'hardware'])

    # the subset that is always included
    minimal_gather_subset = frozenset(['hardware', 'network'])

    # the subset of facts to be collected
    # see usage in gather_facts module
    gather_subset = ['all']

    # aliases for subsets, included if the alias is included
    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi'])

    # platform info
    platform_info = {}
    platform_info['system'] = platform.system()

    collect_names = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info)
    print

# Generated at 2022-06-11 02:13:17.808004
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'network', 'virtual'])
    minimal = frozenset(['all'])
    results = get_collector_names(valid_subsets=valid_subsets,
                                  minimal_gather_subset=minimal)
    assert(set(results) == set(['all']))

    results = get_collector_names(valid_subsets=valid_subsets,
                                  minimal_gather_subset=minimal,
                                  gather_subset=['!network'])
    assert(set(results) == set(['all']))

    # small is not a valid gather subset, so it will be ignored, leaving
    # the set of results at all

# Generated at 2022-06-11 02:13:29.151328
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [_FakeCollectorClass('a', required_facts=set(['b', 'c']))],
        'b': [_FakeCollectorClass('b', required_facts=set(['d']))],
        'c': [_FakeCollectorClass('c', required_facts=set(['d']))],
        'd': [_FakeCollectorClass('d', required_facts=set())],
    }

    # test 1: all deps resolved
    collector_names = ['a', 'b', 'c', 'd']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # test 2: 2 resolved, 2 unresolved
    collector_names = ['a', 'b', 'c']
    assert find_unresolved

# Generated at 2022-06-11 02:13:39.312410
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Define a moc collector class
    class CollectorMock(BaseFactCollector):
        _fact_ids = ['mock_id', 'mock_id2']
        name = 'collector_mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock_collect': 'is_run'}

    collector_classes = set()
    collector_classes.add(CollectorMock)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_classes)
    assert 'collector_mock' in fact_id_to_collector_map
    assert 'mock_id' in fact_id_to_collector_map

# Generated at 2022-06-11 02:13:51.680330
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test setup
    # class defines the facts it requires to run
    class BaseCollector():
        def required_facts(self):
            return {'base', 'required1'}

    class Derived1(BaseCollector):
        def required_facts(self):
            return {'derived1', 'required2'}

    class Derived2(BaseCollector):
        def required_facts(self):
            return {'derived2', 'required2'}

    class Derived3(BaseCollector):
        def required_facts(self):
            return {'derived3', 'required3'}

    # collector classes implemented in the test

# Generated at 2022-06-11 02:14:03.653854
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        _fact_ids = {'a1'}
        name = 'a'

    class B(BaseFactCollector):
        _fact_ids = {'b1'}
        name = 'b'

    class C(BaseFactCollector):
        _fact_ids = {'c1', 'c2'}
        name = 'c'

    # Test that a single collector maps to itself
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([A])
    assert fact_id_to_collector_map['a1'] == [A]
    assert fact_id_to_collector_map['a'] == [A]
    assert aliases_map['a'] == {'a1'}

    # Test 2 collectors

# Generated at 2022-06-11 02:14:20.481932
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'one': [FactCollector('one', required_facts=['two'])],
        'two': [FactCollector('two', required_facts=['three'])],
        'three': [FactCollector('three', required_facts=['four'])],
        'four': [FactCollector('four', required_facts=['five'])],
        'five': [FactCollector('five')],
    }

    collector_names = ['one']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert set(['two', 'three', 'four', 'five']) == unresolved

    collector_names = ['one', 'two', 'three', 'four']

# Generated at 2022-06-11 02:14:30.064844
# Unit test for function tsort
def test_tsort():
    import pytest
    # each item is a dict which maps nodes to node-deps

# Generated at 2022-06-11 02:14:35.549898
# Unit test for function tsort
def test_tsort():
    assert tsort({
        'asdf': ['zxcv'],
        'zxcv': ['zxcv'],
        'qwer': ['asdf'],
        'werq': ['qwer']
    }) == [('zxcv', {'zxcv'}), ('asdf', {'zxcv'}), ('qwer', {'asdf'}), ('werq', {'qwer'})]



# Generated at 2022-06-11 02:14:41.769705
# Unit test for function build_dep_data
def test_build_dep_data():
    data = defaultdict(set)
    data['a'] = {'b'}
    data['b'] = {'c'}
    output = build_dep_data(['a','b','c'], data)
    print(output)
    assert output == {'a': {'b'}, 'b': {'c'}, 'c': set()}
test_build_dep_data()


# Generated at 2022-06-11 02:14:49.134957
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class TestCollector1(object):
        _fact_ids = set((1, 2, 3))
        aliases_map = defaultdict(set)
        name = 'test_name'

    class TestCollector2(object):
        _fact_ids = set((3, 4, 5))
        aliases_map = defaultdict(set)
        name = 'test_name'


    collectors_for_platform = set([TestCollector1, TestCollector2])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # Verify that the aliases_map is correct
    assert aliases_map['test_name'] == set([1, 2, 3, 4, 5])

    # Verify that all entries are in the dict

# Generated at 2022-06-11 02:15:02.036431
# Unit test for function get_collector_names
def test_get_collector_names():
    """
    Test the get_collector_names method

    :return:
    """
    class FakeModule:
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    # Test all simple
    module = FakeModule()
    valid_subsets = frozenset(['all', 'network', 'virtual'])
    ret_val = get_collector_names(valid_subsets=valid_subsets, minimal_gather_subset=frozenset([]), aliases_map=defaultdict(set), platform_info={})
    assert sorted(ret_val) == ['all']

    # Test all with known values
    module = FakeModule(gather_subset=['network', 'virtual'])
    ret_val = get_collector

# Generated at 2022-06-11 02:15:10.669638
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b', 'c'])
        name = 'test1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b', 'd'])
        name = 'test2'

    all_collectors = [TestCollector1, TestCollector2]

    ret_dict, aliases_map = build_fact_id_to_collector_map(all_collectors)

    assert ret_dict['test1'] == [TestCollector1]
    assert ret_dict['test2'] == [TestCollector2]
    assert ret_dict['a'] == [TestCollector1, TestCollector2]

# Generated at 2022-06-11 02:15:20.964278
# Unit test for function get_collector_names
def test_get_collector_names():
    # test for
    # minimal_gather_subset=None,
    # gather_subset=None
    assert get_collector_names(valid_subsets=frozenset(['test', 'foo'])) == set(['test', 'foo'])

    # minimal_gather_subset=None,
    # gather_subset=frozenset(['all'])
    assert get_collector_names(valid_subsets=frozenset(['test', 'foo']),
                               gather_subset=['all']) == set(['test', 'foo'])

    # minimal_gather_subset=None,
    # gather_subset=frozenset(['test'])

# Generated at 2022-06-11 02:15:32.628285
# Unit test for function get_collector_names
def test_get_collector_names():
    from ansible.module_utils.facts import timer

    valid_subsets = frozenset({'all', 'network', 'virtual'})
    minimal_gather_subset = frozenset({'all'})
    aliases_map = defaultdict(set, {'hardware': {'devices', 'dmi'}})
    #
    assert get_collector_names(valid_subsets, minimal_gather_subset,
                               ['hardware'], aliases_map=aliases_map) == frozenset({'hardware', 'devices', 'dmi'})

    # Note: the 'all' fact collector is not used, but it is present in the result

# Generated at 2022-06-11 02:15:45.824623
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all']) == frozenset(['all'])
    assert get_collector_names(['all', '!network']) == frozenset(['all'])
    assert get_collector_names(['!all']) == frozenset(['min'])

    # Basic functionality
    assert get_collector_names(['network']) == frozenset(['network'])
    assert get_collector_names(['!network']) == frozenset(['min'])

    # Minimal gather subset
    assert get_collector_names(['network'], minimal_gather_subset=['min']) == frozenset(['min', 'network'])
    assert get_collector_names(['!network'], minimal_gather_subset=['min']) == fro

# Generated at 2022-06-11 02:16:00.877246
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Dummy1(BaseFactCollector):
        _fact_ids = {'dummy1'}
        name = 'dummy1'
    class Dummy2(BaseFactCollector):
        _fact_ids = {'dummy2'}
        name = 'dummy2'
    class Dummy3(BaseFactCollector):
        _fact_ids = {'dummy3', 'dummy-alias'}
        name = 'dummy3'
    class Dummy4(BaseFactCollector):
        _fact_ids = {'dummy4'}
        name = 'dummy4'
    d1 = Dummy1()
    d2 = Dummy2()
    d3 = Dummy3()
    d4 = Dummy4()

# Generated at 2022-06-11 02:16:11.075398
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(('subset1', 'subset2', 'subset3', 'subset4')),
                               minimal_gather_subset=frozenset(('subset1',)),
                               gather_subset=['subset2', 'subset3']) == frozenset(('subset1', 'subset2', 'subset3'))

# the aliases_map used by get_collector_names is similar to the one in VMware's setup.py
# for their facts modules
# TODO: replace this with a dict with a more helpful structure, as shown here:
#       https://docs.python.org/2/library/collections.html#defaultdict-examples
#       https://stackoverflow.com/questions/9542738/python-

# Generated at 2022-06-11 02:16:19.768231
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'test_fact_1': [], 'test_fact_2': [], 'test_fact_3': [], 'test_fact_4': []}
    test_collector_1 = type('test_collector_1', (BaseFactCollector,), {'required_facts': ('test_fact_2', 'test_fact_3',), 'name': 'test_fact_1'})
    test_collector_2 = type('test_collector_2', (BaseFactCollector,), {'required_facts': ('test_fact_1',), 'name': 'test_fact_2'})
    test_collector_3 = type('test_collector_3', (BaseFactCollector,), {'required_facts': tuple(), 'name': 'test_fact_3'})
    test

# Generated at 2022-06-11 02:16:30.003266
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector:
        required_facts = ()
        name = None
        @staticmethod
        def platform_match(platform_info):
            return TestCollector

    class TestCollectorA(TestCollector):
        name = 'testa'

    class TestCollectorB(TestCollector):
        name = 'testb'
        required_facts = ('testa',)

    class TestCollectorC(TestCollector):
        name = 'testc'
        required_facts = ('testb',)

    class TestCollectorD(TestCollector):
        name = 'testd'
        required_facts = ('testc',)

    class TestCollectorE(TestCollector):
        name = 'teste'
        required_facts = ('nonesuch',)


# Generated at 2022-06-11 02:16:40.203254
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['foo', 'bar']

    def _requires_by_collector_name(collector_name):
        if collector_name == 'foo':
            return set(['bar', 'baz'])
        else:
            return set()

    unresolved_facts = find_unresolved_requires(collector_names, _requires_by_collector_name)
    assert unresolved_facts == set(['baz'])

    collector_names = ['foo']
    unresolved_facts = find_unresolved_requires(collector_names, _requires_by_collector_name)
    assert unresolved_facts == set(['bar', 'baz'])

    collector_names = ['foo', 'bar', 'baz']

# Generated at 2022-06-11 02:16:51.512455
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)

    class Collector1(BaseFactCollector):
        _fact_ids = ['collector1', 'dmi']
        required_facts = ['abc']

    class Collector2(BaseFactCollector):
        _fact_ids = ['collector2']
        required_facts = ['collector1', 'dmi']

    class Collector3(BaseFactCollector):
        _fact_ids = ['collector3']
        required_facts = ['collector2']

    all_fact_subsets['collector1'].append(Collector1)
    all_fact_subsets['collector2'].append(Collector2)
    all_fact_subsets['collector3'].append(Collector3)

    collector_names = ['collector3', 'abc']
    assert find

# Generated at 2022-06-11 02:17:02.820475
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def make_mock_collector(collector_name, required_facts):
        class MockCollector:
            name = collector_name
            required_facts = required_facts

        return MockCollector

    def make_mock_all_fact_subsets(collector_classes):
        all_fact_subsets = defaultdict(list)
        for collector_class in collector_classes:
            all_fact_subsets[collector_class.name].append(collector_class)
        return all_fact_subsets

    # collect_a requires collect_b
    # collect_b requires collect_c
    # collect_c requires collect_d
    # collect_d requires collect_e
    # collect_e requires collect_f

    # collect_b requires collect_c,  collect_d requires collect_e
    # collect_

# Generated at 2022-06-11 02:17:06.301940
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'a': [Collector1, Collector2],
                        'b': [Collector3, Collector4]}
    dep_map = build_dep_data(['a', 'b'], all_fact_subsets)
    assert dep_map['a'] == set()
    assert dep_map['b'] == {'a'}



# Generated at 2022-06-11 02:17:12.622993
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest

    all_fact_subsets = {
        'one': [object],
        'two': [object],
        'three': [object],
    }
    all_fact_subsets['one'][0].requires_facts = lambda: frozenset(['two', 'three'])
    all_fact_subsets['two'][0].requires_facts = lambda: frozenset(['four'])

    # The function being tested:
    assert find_unresolved_requires(frozenset(['one']), all_fact_subsets) == frozenset(['four'])



# Generated at 2022-06-11 02:17:24.756370
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b', 'c'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()
    fact_subsets = {'a': [CollectorA], 'b':[CollectorB], 'c':[CollectorC]}
    collector_names = frozenset(['a', 'b', 'c'])
    dep_map = build_dep_data(collector_names, fact_subsets)
    assert dep_map == {'a': {'b', 'c'}, 'b': {'c'}, 'c': set()}


# Generated at 2022-06-11 02:17:45.295441
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'all': [],
        'network': [],
        'min': [],
        'hardware': [],
        'interface': [],
    }

    # No unresolved requires
    assert set() == find_unresolved_requires(['hardware', 'network'], all_fact_subsets)

    # 'min' requires 'all'
    assert set(['all']) == find_unresolved_requires(['min'], all_fact_subsets)

    # 'network' requires 'interface'
    assert set(['interface']) == find_unresolved_requires(['network'], all_fact_subsets)

    # both 'network' and 'min' require 'all' and 'interface'
    assert set(['all', 'interface']) == find_unresolved_

# Generated at 2022-06-11 02:17:55.236559
# Unit test for function get_collector_names
def test_get_collector_names():
    from ansible.module_utils.facts.collector.alias import AliasFactCollector
    from ansible.module_utils.facts.collector.network.default import NetworkFactCollector
    from ansible.module_utils.facts.collector.network.linux import NetworkLinuxFactCollector
    from ansible.module_utils.facts.collector.network.bsd import NetworkBSDFactCollector
    from ansible.module_utils.facts.collector.network.windows import NetworkWindowsFactCollector
    from ansible.module_utils.facts.collector.network.vmware import NetworkVMwareFactCollector
    from ansible.module_utils.facts.collector.network.aix import NetworkAIXFactCollector
    from ansible.module_utils.facts.collector.distribution.default import DistributionFactCollector

# Generated at 2022-06-11 02:17:59.718858
# Unit test for function get_collector_names
def test_get_collector_names():
    def test_it(gather_subset,
                valid_subsets,
                minimal_gather_subset,
                expected_result):
        result = get_collector_names(gather_subset=gather_subset,
                                     valid_subsets=valid_subsets,
                                     minimal_gather_subset=minimal_gather_subset)
        assert result == expected_result

    test_it(gather_subset=None,
            valid_subsets=None,
            minimal_gather_subset=None,
            expected_result=set(['all']))


# Generated at 2022-06-11 02:18:08.730321
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'first': [BaseFactCollector],
        'second': [BaseFactCollector],
        'third': [BaseFactCollector],
        'fourth': [BaseFactCollector],
    }
    all_fact_subsets['first'][0].required_facts = set(['second', 'fourth'])
    all_fact_subsets['second'][0].required_facts = set(['third'])

    unresolved = find_unresolved_requires(set(['first', 'second']), all_fact_subsets)
    assert unresolved == set(['fourth'])
    assert not find_unresolved_requires(set(['first', 'second', 'fourth']), all_fact_subsets)



# Generated at 2022-06-11 02:18:20.062943
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.dmi import Dmi

    all_fact_subsets = {
        'dmi': [Dmi],
        'network': [Network],
        'hardware': [Hardware],
    }

    # Both require dmi
    selected_collector_names = ['dmi', 'hardware', 'network']
    unresolved = find_unresolved_requires(selected_collector_names, all_fact_subsets)
    assert not unresolved, 'should not be unresolved: %s' % unresolved

    # Only hardware requires dmi
    selected_collector_names = ['hardware', 'network']
    unresolved = find_unresolved

# Generated at 2022-06-11 02:18:30.439150
# Unit test for function get_collector_names
def test_get_collector_names():
    # Valid subsets
    valid_subsets = frozenset(['devices', 'identity', 'load', 'memory', 'network',
                               'virtualization', 'all', 'min'])
    # Minimal gather subset
    minimal_gather_subset = frozenset(['identity'])
    # Aliases
    aliases_map = defaultdict(set)
    aliases_map['network'].add('devices')
    # Gather subset
    gather_subset = None

    # result
    get_collector_names_result = get_collector_names(valid_subsets, minimal_gather_subset,
                                                     gather_subset, aliases_map)
    get_collector_names_result.sort()
    assert get_collector_names_result == ['identity']

    # Gather subset


# Generated at 2022-06-11 02:18:40.360246
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {}
    all_fact_subsets["A"] = [A]
    all_fact_subsets["B"] = [B]
    all_fact_subsets["C"] = [C]
    all_fact_subsets["D"] = [D]
    collector_names = ["A", "B", "C", "D"]

    dep_data = build_dep_data(collector_names, all_fact_subsets)
    assert dep_data["A"] == set(["X","Y"])
    assert dep_data["B"] == set(["Y", "Z"])
    assert dep_data["C"] == set(["A", "B"])
    assert dep_data["D"] == set(["C"])



# Generated at 2022-06-11 02:18:52.185122
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    class CollectX(BaseFactCollector):
        name = 'x'

    class CollectY(BaseFactCollector):
        name = 'y'
        required_facts = frozenset(['z'])

    class CollectZ(BaseFactCollector):
        name = 'z'

    # results in a cycle
    class CollectA(BaseFactCollector):
        name = 'a'
        required_facts = frozenset(['b'])

    # results in a cycle
    class CollectB(BaseFactCollector):
        name = 'b'
        required_facts = frozenset(['a'])


# Generated at 2022-06-11 02:19:00.651216
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:19:11.392529
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # TODO: others
    from ansible.module_utils.facts import collectors
    from ansible.module_utils._text import to_text

    # find_unresolved_requires(self, collector_names, all_fact_subsets)
    #
    # all_fact_subsets
    #   a dict mapping fact_id (ie, the first arg to add_collector) to a list of FactCollector subclasses
    #
    # fact_id_to_collector_map
    #   a dict mapping fact_id to FactCollector class (the first arg to add_collector)
    #
    # aliases_map
    #   a dict mapping a fact_id to a set of aliases for that fact_id

    all_fact_subsets = {}


# Generated at 2022-06-11 02:19:47.719928
# Unit test for function get_collector_names
def test_get_collector_names():
    # simple case
    assert get_collector_names(gather_subset=['all']) == set(['all'])

    # check some negations
    assert get_collector_names(gather_subset=['all', '!min']) == set(['all'])

    # check that 'all' is additive, meaning it adds new subsets as
    # things are added
    assert get_collector_names(gather_subset=['all', 'min', '!hardware']) == set(['all', 'min'])
    assert get_collector_names(gather_subset=['all', 'min', '!hardware', '!dmi']) == set(['all', 'min'])

    # check that aliases for subsets work for both inclusion and exclusion

# Generated at 2022-06-11 02:20:00.851397
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['one', 'two', 'three']

# Generated at 2022-06-11 02:20:10.933134
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_dependencies = {}

    fact_id_to_collector_map = {}
    aliases_map = defaultdict(set)

    def add_collector(collector_name, required_facts=()):
        collector_dependencies[collector_name] = required_facts

        class MockCollector:
            name = collector_name
            required_facts = required_facts

            def __init__(self):
                pass

        MockCollector.name = collector_name

        fact_id_to_collector_map[collector_name].append(MockCollector)
        for alias in required_facts:
            aliases_map[collector_name].add(alias)

    # Add collector to get dependencies for
    add_collector('A')
    add_collector('D')
    add_collector('E')


# Generated at 2022-06-11 02:20:21.778281
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector_1'
        _fact_ids = set(['collector_1', 'collector_1_alias_1', 'collector_1_alias_2'])

    class Collector2(BaseFactCollector):
        name = 'collector_2'
        _fact_ids = set(['collector_2', 'collector_2_alias_1', 'collector_2_alias_2'])

    class Collector3(BaseFactCollector):
        name = 'collector_3'
        _fact_ids = set(['collector_3', 'collector_3_alias_1', 'collector_3_alias_2'])


# Generated at 2022-06-11 02:20:34.795261
# Unit test for function get_collector_names
def test_get_collector_names():

    assert get_collector_names([], ['all']) == frozenset()

    assert get_collector_names(['hardware', 'network'], ['all']) == frozenset({'hardware', 'network'})
    assert get_collector_names(['hardware', 'network'], ['!all']) == frozenset()
    assert get_collector_names(['hardware', 'network'], ['hardware']) == frozenset({'hardware'})
    assert get_collector_names(['hardware', 'network'], ['hardware', 'network']) == frozenset({'hardware', 'network'})
    assert get_collector_names(['hardware', 'network'], ['hardware', 'network', '!all']) == frozenset({'hardware', 'network'})
   

# Generated at 2022-06-11 02:20:44.110535
# Unit test for function get_collector_names
def test_get_collector_names():
    all_subsets = frozenset(['hardware', 'network', 'virtual'])
    minimal_subsets = frozenset(['hardware'])
    aliases_map = defaultdict(set,
                              {'hardware': frozenset(['devices', 'dmi']),
                               'network': frozenset(['interfaces'])})
    def do_test(gather_subset, exp_subsets):
        subsets = get_collector_names(valid_subsets=all_subsets,
                                      minimal_gather_subset=minimal_subsets,
                                      gather_subset=gather_subset,
                                      aliases_map=aliases_map)
        assert subsets == frozenset(exp_subsets)
    do_test(['devices'], ['devices'])
    do

# Generated at 2022-06-11 02:20:53.325845
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # this test is only valid with native python2.7
    # or with python3.5+
    try:
        from collections import OrderedDict
    except ImportError:
        return

    class MockCollector:
        def __init__(self):
            self.required_facts = frozenset(('abc', 'xyz.abc', 'xyz'))

    class MockCollector2(MockCollector):
        def __init__(self):
            super(MockCollector2, self).__init__()

            self.required_facts = self.required_facts.union(('xyz', 'xyz.abc', 'x'))

    class MockCollector3(MockCollector):
        pass

    fact_id_to_collector_map = OrderedDict()
    fact_id_to_collector

# Generated at 2022-06-11 02:21:04.303717
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Platform1(BaseFactCollector):
        _fact_ids = {'fact1', 'fact2'}
        name = 'platform1'

    class Platform2(Platform1):
        _fact_ids = {'fact3', 'fact4'}
        name = 'platform2'

    class Platform3(Platform1):
        name = 'platform3'

    all_collector_classes = [Platform1, Platform2, Platform3]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

    assert set(fact_id_to_collector_map.keys()) == {'platform1', 'platform2', 'platform3', 'fact1', 'fact2', 'fact3', 'fact4'}

# Generated at 2022-06-11 02:21:15.073205
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = {'B', 'C'}

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = {'C', 'D'}

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = {'C', 'D'}

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = {'A', 'C'}

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = {'E', 'B'}

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = {'F', 'B'}

    a_class = CollectorA

# Generated at 2022-06-11 02:21:25.028055
# Unit test for function get_collector_names