

# Generated at 2022-06-11 02:12:12.054542
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    collector_names = ['system']
    all_fact_subsets = {
        'system': [
            SystemFactCollector
        ]
    }
    
    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map['system'] == set()


# Generated at 2022-06-11 02:12:21.633143
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Quick smoke test of function find_unresolved_requires
    # (because there are not currently any unit tests for this code)
    from ansible.module_utils.facts.collectors import all_collector_classes
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import timeout

    all_fact_subsets = cache.FactsCache(timeout.FactsCacheTimeoutManager()).all_fact_subsets

    # build a list of collector_names that contain a cycle.
    # Assumption: there will always be at least one cycle.
    requires_dict = {}
    for collector_name, collector_classes in all_fact_subsets.items():
        requires_dict[collector_name] = set()

# Generated at 2022-06-11 02:12:32.965391
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(
        ['a'], {'a': [], 'b': []}) == set()
    assert find_unresolved_requires(
        ['a', 'b'], {'a': [], 'b': [], 'c': []}) == set()
    assert find_unresolved_requires(
        ['a'], {'a': [], 'b': [], 'c': []}) == set()

    class A:
        required_facts = {'b'}
    assert find_unresolved_requires(
        ['a'], {'a': [A], 'b': [], 'c': []}) == set()
    assert find_unresolved_requires(
        ['b'], {'a': [A], 'b': [], 'c': []}) == set()
    assert find

# Generated at 2022-06-11 02:12:41.450687
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.network.guess import GuessCollector
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.generic import NetworkCollector

    platform_info = {'network': {'os': 'Linux'}}

    all_collector_classes = (GuessCollector, LinuxNetworkCollector, NetworkCollector)
    expected = all_collector_classes

    assert find_collectors_for_platform(all_collector_classes, [platform_info]) == expected



# Generated at 2022-06-11 02:12:49.747615
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Some mock collector classes.
    # This one requires fact1.
    class Collector1:
        required_facts = {'fact1'}
    # This one requires fact2.
    class Collector2:
        required_facts = {'fact2'}
    # This one requires fact1 and fact2.
    class Collector3:
        required_facts = {'fact1', 'fact2'}
    # This one has no required facts.
    class Collector4:
        required_facts = set()
    all_fact_subsets = {
        'fact1': [Collector1],
        'fact2': [Collector2],
        'fact3': [Collector3],
        'fact4': [Collector4],
    }

    assert find_unresolved_requires({'fact1'}, all_fact_subsets)

# Generated at 2022-06-11 02:12:59.539480
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        name = 'testcollector1'
        _platform = 'AIX'

    class TestCollector2(BaseFactCollector):
        name = 'testcollector2'
        _platform = 'Linux'

    class TestCollector3(BaseFactCollector):
        name = 'testcollector3'
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        name = 'testcollector4'
        _platform = 'Darwin'

    class TestCollector5(BaseFactCollector):
        name = 'testcollector5'
        _platform = 'Darwin'

    collector_classes = [TestCollector1, TestCollector2, TestCollector3, TestCollector4, TestCollector5]

# Generated at 2022-06-11 02:13:09.051365
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test for find_unresolved_requires function'''
    all_fact_subsets = {
        'a': ['foo', 'bar', 'baz'],
        'b': ['foo', 'bar', 'baz'],
        'c': ['foo', 'bar', 'baz'],
        'd': ['foo', 'bar', 'baz'],
        'e': ['foo', 'bar', 'baz'],
        'f': ['foo', 'bar', 'baz'],
        'g': ['foo', 'bar', 'baz'],
        'h': ['foo', 'bar', 'baz']
    }


# Generated at 2022-06-11 02:13:18.043095
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    fake_collector_names = ['test1']
    fake_all_fact_subsets = {
        'test1': [FakeCollector],
        'test2': [FakeCollector],
        'test3': [FakeCollector],
        'test4': [FakeCollector],
    }

    result = find_unresolved_requires(fake_collector_names, fake_all_fact_subsets)
    assert result == set()

    class FakeCollector:
        name = 'test1'
        required_facts = {'test3', 'test4', 'test5'}

    # test1 requires test3, test4, test5
    # test3 requires test4
    # test4 requires test2


# Generated at 2022-06-11 02:13:29.329419
# Unit test for function tsort
def test_tsort():
    assert tsort({
        'A': ['B', 'C'],
        'B': ['D'],
        'C': ['E'],
        'D': ['E'],
        'E': [],
    }) == [
        ('E', []),
        ('D', ['E']),
        ('B', ['D']),
        ('C', ['E']),
        ('A', ['B', 'C']),
    ]

    assert tsort({
        'A': [],
        'B': ['A'],
        'C': ['A'],
    }) == [
        ('A', []),
        ('C', ['A']),
        ('B', ['A']),
    ]


# Generated at 2022-06-11 02:13:39.403938
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import (
        BaseFactCollector,
        get_collector_names,
        find_collectors_for_platform,
        build_fact_id_to_collector_map
    )

    class FakeFactCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = {'test_collector', 'test_collector_alias'}

    platform_info = {'system': 'Linux'}

    compat_platforms = [platform_info]

    all_collector_classes = [FakeFactCollector]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)


# Generated at 2022-06-11 02:14:04.023021
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector

    class A(BaseFactCollector):
        name = 'A'

    class B(BaseFactCollector):
        name = 'B'
        _fact_ids = {'B1', 'B2'}

    class C(B):
        name = 'C'

    class D(BaseFactCollector):
        name = 'D'
        _fact_ids = {'D1', 'D2'}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([A, B, C, D])

    assert len(fact_id_to_collector_map) == 6


# Generated at 2022-06-11 02:14:12.985218
# Unit test for function get_collector_names
def test_get_collector_names():
    platform_info = dict(system='Linux')

    # test all
    names = get_collector_names(platform_info=platform_info,
                                gather_subset=['all'],
                                valid_subsets=frozenset(['hardware', 'network', 'memory', 'virtual']),
                                minimal_gather_subset=frozenset(['memory']))
    assert names == set(['hardware', 'network', 'memory', 'virtual'])

    # test all
    names = get_collector_names(platform_info=platform_info,
                                gather_subset=['!'],
                                valid_subsets=frozenset(['hardware', 'network', 'memory', 'virtual']),
                                minimal_gather_subset=frozenset(['memory']))
   

# Generated at 2022-06-11 02:14:23.230593
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class test_collector_a(BaseFactCollector):
        _fact_ids = set(['a', 'b', 'c'])
        name = 'a'
    class test_collector_b(BaseFactCollector):
        _fact_ids = set(['d'])
        name = 'b'
    class test_collector_c(BaseFactCollector):
        _fact_ids = 'e'
        name = 'c'

    # test multiple ids for a single collector
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([test_collector_a])
    assert aliases_map['a'] == set(['a', 'b', 'c'])

# Generated at 2022-06-11 02:14:32.125324
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['collector1', 'collector2']
    all_fact_subsets = {}
    all_fact_subsets['collector1'] = []
    all_fact_subsets['collector2'] = []
    all_fact_subsets['collector1'].append(MockCollector(name="collector1", required_facts=set(["collector2"])))
    all_fact_subsets['collector2'].append(MockCollector(name="collector2", required_facts=set(["collector1"])))
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['collector1'] == set(['collector2'])
    assert dep_map['collector2'] == set(['collector1'])




# Generated at 2022-06-11 02:14:43.538977
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Base class
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    all_fact_subsets = {
        'test': [TestCollector],
        'test2': [TestCollector2],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test2'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test', 'test2'], all_fact_subsets) == set()

# Generated at 2022-06-11 02:14:49.280709
# Unit test for function get_collector_names
def test_get_collector_names():
    # test case #1: gather_subset = ['all']
    assert get_collector_names(['network'], ['network', 'min'], ['all'],
                               {'hardware': set(['devices', 'dmi'])},
                               None) == {'network'}

    # test case #2: gather_subset = ['hardware']
    assert get_collector_names(['network'], ['network', 'min'], ['hardware'],
                               {'hardware': set(['devices', 'dmi'])},
                               None) == {'devices', 'dmi'}

    # test case #3: gather_subset = ['!hardware']

# Generated at 2022-06-11 02:14:58.178176
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['distro', 'hardware', 'network', 'system']),
        minimal_gather_subset=frozenset(['hardware']),
        gather_subset=['distro', '!network', '!min'],
        aliases_map={'hardware': {'devices', 'dmi'}, 'network': {'interfaces'}},
    ) == {'distro', 'system', 'dmi', 'devices'}



# Generated at 2022-06-11 02:15:08.623225
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class DummyCollector1(BaseFactCollector):
        _fact_ids = set()
        required_facts = set(['a'])
    class DummyCollector2(BaseFactCollector):
        _fact_ids = set()
        required_facts = set(['b'])
    class DummyCollector3(BaseFactCollector):
        _fact_ids = set()
        required_facts = set(['c', 'd'])
    class DummyCollector4(BaseFactCollector):
        _fact_ids = set()
        required_facts = set(['e'])
    class DummyCollector5(BaseFactCollector):
        _fact_ids = set()
        required_facts = set(['f', 'c'])
    class DummyCollector6(BaseFactCollector):
        _fact_

# Generated at 2022-06-11 02:15:19.519804
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyCollector(BaseFactCollector):
        _fact_ids = frozenset(['my_fact'])

    class MyCollector2(BaseFactCollector):
        _fact_ids = frozenset(['my_fact2'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([
        MyCollector,
        MyCollector2,
    ])

    # Ensure that aliases_map is correct
    assert aliases_map['MyCollector'] == frozenset(['my_fact'])
    assert aliases_map['MyCollector2'] == frozenset(['my_fact2'])

    assert fact_id_to_collector_map['my_fact'] == [MyCollector]

# Generated at 2022-06-11 02:15:30.149681
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = [
        'name1',
        'name2',
        'name3',
    ]

    all_fact_subsets = {
        'name1': [collector('name1', required_facts=['name2'])],
        'name2': [collector('name2')],
        'name3': [collector('name3', required_facts=['name1'])],
        'name4': [collector('name4')],
        'name5': [collector('name5')],
    }

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert set(unresolved) == set(['name4', 'name5'])



# Generated at 2022-06-11 02:15:54.957360
# Unit test for function get_collector_names
def test_get_collector_names():
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    import re

    import pytest
    from ansible.module_utils.facts.collector import get_collector_names

    # Common parameterized data and tests
    params_data_template = ('test_name', 'valid_subsets', 'minimal_gather_subset', 'gather_subset', 'aliases_map',
                            'platform_info', 'expected_output')
    test_id = "get_collector_names(valid_subsets: %s, minimal_gather_subset: %s, gather_subset: %s)"

# Generated at 2022-06-11 02:16:05.006638
# Unit test for function get_collector_names
def test_get_collector_names():
    # simplest case
    assert get_collector_names(gather_subset=['all']) == {'all'}
    # simplest case w/ minimal_subset, which is always added
    assert get_collector_names(gather_subset=['all'],
                               minimal_gather_subset=['min']) == {'all', 'min'}
    # this test uses aliases_subset to verify that for the case of '!hardware',
    # both 'hardware' and its aliases are included in exclude_subsets
    assert get_collector_names(gather_subset=['kernel'],
                               aliases_map={'hardware': {'devices', 'dmi'}}) == {'kernel'}

# Generated at 2022-06-11 02:16:16.362538
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.default import DefaultCollector

    def collect(self, module=None, collected_facts=None):
        return dict(
            fact_a=1,
            fact_b=2,
            fact_c=3
        )

    def collect2(self, module=None, collected_facts=None):
        return dict(
            fact_b=20,
            fact_d=30
        )

    DefaultCollector2 = type('DefaultCollector2', (DefaultCollector,), dict(
        collect=collect2,
        _fact_ids=['fact_b', 'fact_d']
    ))

    # We must dynamically change the DefaultCollector class to remove
    # any side affects on other tests
    DefaultCollector.collect = collect

# Generated at 2022-06-11 02:16:27.820745
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution_major_version import DistributionMajorVersionFactCollector
    from ansible.module_utils.facts.system.distribution_release import DistributionReleaseFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector

    collectors = [DistributionFactCollector,
                  DistributionMajorVersionFactCollector,
                  DistributionReleaseFactCollector,
                  SystemFactCollector]
    all_fact_subsets = {
        'distribution': [DistributionFactCollector],
        'distribution_major_version': [DistributionMajorVersionFactCollector],
        'distribution_release': [DistributionReleaseFactCollector],
        'system': [SystemFactCollector]
    }



# Generated at 2022-06-11 02:16:34.278091
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1: No dependencies.
    collectors = ['test1']
    subsets = {'test1': []}
    assert find_unresolved_requires(collectors, subsets) == set()

    # Test case 2: No dependencies.
    collectors = ['test1', 'test2']
    subsets = {'test1': [], 'test2': []}
    assert find_unresolved_requires(collectors, subsets) == set()

    # Test case 3: Dependencies but no missing.
    collectors = ['test1', 'test2', 'test3']
    subsets = {'test1': [], 'test2': [], 'test3': []}
    subsets['test2'].append(object())
    subsets['test2'][0].required_facts = set(['test1'])
   

# Generated at 2022-06-11 02:16:45.534879
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    x = find_unresolved_requires(['a', 'b'],
                                 {'a': [object()],
                                  'b': [object()],
                                  'd': [object()]})
    assert(x == set(['d'])), x

    x = find_unresolved_requires(['a', 'b'],
                                 {'a': [object()],
                                  'b': [object()],
                                  'd': [object()]})
    assert(x == set(['d'])), x

    x = find_unresolved_requires(['a', 'b', 'd'],
                                 {'a': [object()],
                                  'b': [object()],
                                  'd': [object()]})
    assert(x == set()), x



# Generated at 2022-06-11 02:16:53.494284
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b'], {
        'a': [
            FactCollectorType('a', deps=['fact1', 'fact2', 'fact3']),
        ],
        'b': [
            FactCollectorType('b', deps=['fact2', 'fact3']),
        ]
    })
    assert dep_map == {'a': {'fact1', 'fact2', 'fact3'},
                       'b': {'fact2', 'fact3'}}



# Generated at 2022-06-11 02:17:04.315632
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # ensure that required_facts for "fact-a" is "fact-b"
    def fake_collector(name, required_facts):
        class SomeCollector(BaseFactCollector):
            name = name
            required_facts = required_facts
        return SomeCollector

    fact_b = fake_collector('fact-b', set())
    fact_a = fake_collector('fact-a', set(['fact-b']))

    fact_b_collector_classes = set([fact_b])
    fact_a_collector_classes = set([fact_a])

    # all_fact_subsets: is collector_name -> [collector_classes]

# Generated at 2022-06-11 02:17:07.845702
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector

    class CollectorDummy(BaseFactCollector):
        name = 'test_dummy'

    assert(build_fact_id_to_collector_map([CollectorDummy]) ==
           ({'test_dummy': [CollectorDummy]},
            defaultdict(set, {'test_dummy': set()})))



# Generated at 2022-06-11 02:17:17.329708
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.test.test_test_test_test as ft

    # test that all_collector_classes are found for supported platform
    all_collectors = find_collectors_for_platform(ft.TestDependentFactCollector.all_collector_classes,
                                                  [{'system': 'Generic'}])
    assert (len(all_collectors) == 1), "Expected to find all_collector_classes, found %s" % (all_collectors)

    # test that all_collector_classes are not found for unsupported platform
    all_collectors = find_collectors_for_platform(ft.TestDependentFactCollector.all_collector_classes,
                                                  [{'system': 'Unsupported'}])

# Generated at 2022-06-11 02:17:41.760073
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all','facter','system','network']
    collector_data = {'all': ['facter','system','network'],
                      'facter': ['system'],
                      'system': [],
                      'network': ['facter']}
    all_fact_subsets = { x:[x] for x in collector_data }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == collector_data

# Generated at 2022-06-11 02:17:48.806791
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts._collector.network.bond import BondFactCollector
    from ansible.module_utils.facts._collector.network.interfaces import InterfacesFactCollector

    all_collector_classes = set([BondFactCollector, InterfacesFactCollector])

    (fact_id_to_collector_map,
     aliases_map) = build_fact_id_to_collector_map(all_collector_classes)

    assert aliases_map['network'] == set(['interfaces', 'bond'])



# Generated at 2022-06-11 02:18:01.219786
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import tempfile
    import os
    import shutil
    import sys

    # This code should not be run during normal unit tests of Ansible, since
    # it requires a valid Python interpreter and Ansible library tree.
    # Instead, the unit tests that include this code should be run from the
    # top level of the Ansible source tree, where the required interpreter and
    # library are available.
    if not os.environ.get('ANSIBLE_TEST_DATA_ROOT'):
        return

    # Import the ansible.module_utils.facts library from the Ansible library tree,
    # rather than from the normal Python library path.
    test_data_root = os.environ['ANSIBLE_TEST_DATA_ROOT']

# Generated at 2022-06-11 02:18:10.071387
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'x': [object()],
                        'y': [object()],
                        'z': [object()]}
    collector_names = ['x', 'y', 'z']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'x': set(), 'y': set(), 'z': set()}

    x_class = object()
    y_class = object()
    y_class.required_facts = set(['x'])
    z_class = object()
    z_class.required_facts = set(['x', 'y'])

    all_fact_subsets = {'x': [x_class],
                        'y': [y_class],
                        'z': [z_class]}
    collector_names

# Generated at 2022-06-11 02:18:21.678689
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {}
    def get_collector_names(valid_subsets=None,
                            minimal_gather_subset=None,
                            gather_subset=None,
                            aliases_map=None,
                            platform_info=None):
        return ('a', 'b', 'c', 'd')

    collector_names = get_collector_names()
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert(dep_map == {'a': set(), 'b': set(), 'c': set(), 'd': set()})

    class BaseFactCollector1(BaseFactCollector):
        name='a'
        required_facts={'b'}
        _fact_ids={'a'}
        _platform='Generic'

   

# Generated at 2022-06-11 02:18:31.562798
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [FakeCollector(name='a', _fact_ids=['a'], required_facts=set())],
        'b': [FakeCollector(name='b', _fact_ids=['b'], required_facts=set())],
        'c': [FakeCollector(name='c', _fact_ids=['c'], required_facts=set(['b', 'a']))],
        'd': [FakeCollector(name='d', _fact_ids=['d'], required_facts=set(['a']))],
    }
    unresolved_requires = find_unresolved_requires(set(['a', 'c', 'd']), all_fact_subsets)
    assert len(unresolved_requires) == 0

    # The require r3 doesn't exist

# Generated at 2022-06-11 02:18:39.732842
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorNotFoundError(Exception):
        pass
    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        return {'fact_a', 'fact_b'}
    all_fact_subsets = {
        'fact_a': [1],
        'fact_b': [2],
        'fact_c': [3]
    }
    collector_names = ['fact_b', 'fact_c']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

    assert unresolved == {'fact_a'}



# Generated at 2022-06-11 02:18:52.094154
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [
            BaseFactCollector(name='a', required_facts=set(['b']))
        ],
        'b': [
            BaseFactCollector(name='b', required_facts=set(['c', 'd']))
        ],
        'c': [
            BaseFactCollector(name='c', required_facts=set(['e', 'f']))
        ],
        'd': [
            BaseFactCollector(name='d', required_facts=set(['e', 'f']))
        ],
        'e': [
            BaseFactCollector(name='e', required_facts=set())
        ],
        'f': [
            BaseFactCollector(name='f', required_facts=set())
        ],
    }

    assert find_un

# Generated at 2022-06-11 02:19:00.550838
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class DummyCollector1(BaseFactCollector):
        _fact_ids = set(['dummy_id'])
        name = 'dummy1'
        required_facts = set()

    class DummyCollector2(BaseFactCollector):
        _fact_ids = set(['dummy_id', 'dummy_id2'])
        name = 'dummy2'
        required_facts = set()

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([DummyCollector1, DummyCollector2])

    assert len(fact_id_to_collector_map['dummy1']) == 1
    assert len(fact_id_to_collector_map['dummy2']) == 1

# Generated at 2022-06-11 02:19:11.320684
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.basic import AnsibleModule

    class Collector1(BaseFactCollector):
        name = 'col1'
        _fact_ids = set(['fact1'])

    class Collector2(BaseFactCollector):
        name = 'col2'
        _fact_ids = set(['fact1'])

    class Collector3(BaseFactCollector):
        name = 'col3'
        _fact_ids = set(['fact2'])

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 5
    module.params['filter'] = '*'


# Generated at 2022-06-11 02:19:49.657329
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit test for find_unresolved_requires'''

    collector1_requires = set()
    collector2_requires = set(('foo', 'bar'))
    collector3_requires = set(('foo', 'baz'))
    collector4_requires = set(('foo',))

    # class based definition of a "Collector", using sets to simulate required facts
    Collector1 = type(str('Collector1'), (object,), {'required_facts': collector1_requires})
    Collector2 = type(str('Collector2'), (object,), {'required_facts': collector2_requires})
    Collector3 = type(str('Collector3'), (object,), {'required_facts': collector3_requires})

# Generated at 2022-06-11 02:20:01.988494
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(frozenset(['network']), frozenset(['min']), ['network']) == frozenset(['network'])
    assert get_collector_names(frozenset(['network']), frozenset(['min']), ['!network']) == frozenset(['min'])
    assert get_collector_names(frozenset(['network', 'min']), frozenset(['min']), ['network']) == frozenset(['network'])
    assert get_collector_names(frozenset(['network', 'min']), frozenset(['min']), ['network']) == frozenset(['network'])
    assert get_collector_names(frozenset(['min']), frozenset(['min']), ['network']) == fro

# Generated at 2022-06-11 02:20:13.197220
# Unit test for function tsort
def test_tsort():
    # graph data taken from https://en.wikipedia.org/wiki/Topological_sorting
    graph_data = {
        'work': ['prep'],
        'prep': ['eat'],
        'init': ['make', 'init2'],
        'make': ['eat'],
        'init2': ['make2'],
        'make2': ['eat'],
        'a': ['b'],
        'b': ['c'],
        'c': ['d'],
        'd': ['e'],
        'e': ['a']
    }

    try:
        tsort(graph_data)
        raise AssertionError('Expect CycleFoundInFactDeps error')
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-11 02:20:23.013367
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import hardware

    # test 1
    collector_classes = [system.Collector,
                         network.Collector,
                         hardware.Collector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_classes)

    assert fact_id_to_collector_map['distribution'] == [system.Collector]
    assert fact_id_to_collector_map['distribution_file_name_regex'] == [system.Collector]
    assert fact_id_to_collector_map['architecture'] == [system.Collector]

# Generated at 2022-06-11 02:20:35.740116
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def CollectorClass(name, required_facts):
        class Collector(object):
            name = name
            required_facts = required_facts
        return Collector
    collector_classes = [
        CollectorClass('a', []),
        CollectorClass('b', ['a', 'c']),
        CollectorClass('c', ['d']),
        CollectorClass('e', ['b']),
    ]
    all_fact_subsets = defaultdict(list)
    for collector_class in collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    collector_names = ['a', 'b', 'c', 'd', 'e']

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()


# Generated at 2022-06-11 02:20:44.750868
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'stuff': [StuffCollector],
                        'things': [ThingsCollector]}

    collector_names = ['things', 'stuff']

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    def assert_finds_unresolved(collector_names, all_fact_subsets, wanted):
        assert find_unresolved_requires(collector_names, all_fact_subsets) == wanted

    assert_finds_unresolved(['stuff', 'other'], all_fact_subsets, {'other'})
    assert_finds_unresolved(['stuff', 'other', 'things'], all_fact_subsets, {'other'})

# Generated at 2022-06-11 02:20:53.640501
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    require_check = {
        'a': ['b', 'c'],
        'b': ['c', 'd'],
        'c': [],
        'd': ['e'],
        'e': []
    }
    class V(BaseFactCollector):
        name = None
        def __init__(self, name, requires=None):
            self.name = name
            self.required_facts = set(requires or [])
            super(V, self).__init__()

    all_fact_subsets = dict()
    for k, v in require_check.items():
        all_fact_subsets[k] = [V(k, v)]

    ret = find_unresolved_requires(require_check.keys(), all_fact_subsets)
    assert ret == set(['e'])
test

# Generated at 2022-06-11 02:21:04.676675
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Foo(BaseFactCollector):
        _fact_ids = set()
        name = 'foo'

    class Bar(BaseFactCollector):
        _fact_ids = {'bar_foo_alias'}
        name = 'bar'

    class FooBar(BaseFactCollector):
        _fact_ids = {'bar_foo_alias'}
        name = 'foo'

    class Baz(BaseFactCollector):
        _fact_ids = set()
        name = 'baz'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([Foo,
                                                                             Bar,
                                                                             Baz,
                                                                             FooBar])

    assert len(fact_id_to_collector_map) == 5

# Generated at 2022-06-11 02:21:12.749760
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['foo'], {'foo': [object()]}
    ) == {'foo': set()}
    assert build_dep_data(['foo', 'bar'], {'foo': [object()], 'bar': [object()]}
    ) == {'foo': set(), 'bar': set()}
    assert build_dep_data(['foo', 'bar'], {'foo': [object()], 'bar': [object(), object()]}
    ) == {'foo': set(), 'bar': set()}



# Generated at 2022-06-11 02:21:19.236668
# Unit test for function find_unresolved_requires