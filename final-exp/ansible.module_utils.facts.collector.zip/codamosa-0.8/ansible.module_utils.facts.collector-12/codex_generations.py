

# Generated at 2022-06-11 02:12:05.347754
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    """
    Test the find_unresolved_requires() function
    """
    # for these tests:
    #  - a,b,c are collectors
    #  - d,e are not
    #  - d requires b and e, but e is not a collector
    #  - a,b,c require nothing
    all_fact_subsets = defaultdict(list)
    required_facts = defaultdict(list)
    required_facts['d'] = ['b', 'e']
    required_facts['e'] = []

    class TestCollectorA(BaseFactCollector):
        name = 'a'
        required_facts = required_facts.get(name, [])
    class TestCollectorB(BaseFactCollector):
        name = 'b'
        required_facts = required_facts.get(name, [])


# Generated at 2022-06-11 02:12:09.289195
# Unit test for function tsort
def test_tsort():
    assert tsort({'A': ['B', 'C'], 'B': [], 'C': ['B']}) == [('A', {'C', 'B'}), ('C', {'B'}), ('B', set())]



# Generated at 2022-06-11 02:12:19.115151
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Foo(BaseFactCollector):
        _fact_ids = set(['foo'])
        name = 'foo'

    class BarBaz(BaseFactCollector):
        _fact_ids = set(['bar', 'baz'])
        name = 'bar'

    class Qux(BaseFactCollector):
        _fact_ids = set(['foo'])
        name = 'qaz'

    result = build_fact_id_to_collector_map([Foo, BarBaz, Qux])
    aliases_map = result[1]
    assert set(aliases_map['bar']) == set(['bar', 'baz'])
    assert set(aliases_map['foo']) == set(['foo'])



# Generated at 2022-06-11 02:12:31.053187
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network.napalm import NapalmNetwork
    from ansible.module_utils.facts.collector.network.hardware import NetworkHardware
    from ansible.module_utils.facts.collector.network.default import DefaultNetwork
    from ansible.module_utils.facts.collector.system import System
    from ansible.module_utils.facts.collector.network.base import BaseNetwork
    names = [NapalmNetwork.name, NetworkHardware.name, DefaultNetwork.name, System.name, BaseNetwork.name]
    all_fact_subsets = {
        'network': {NapalmNetwork, NetworkHardware, DefaultNetwork, BaseNetwork},
        'system': {System}
    }
    dep_map = build_dep_data(names, all_fact_subsets)

# Generated at 2022-06-11 02:12:42.144569
# Unit test for function select_collector_classes
def test_select_collector_classes():
    f_1 = BaseFactCollector
    f_1._fact_ids = {'hardware', 'devices'}
    f_1.name = 'hardware'

    f_2 = BaseFactCollector
    f_2._fact_ids = {'kernel'}
    f_2.name = 'kernel'

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['hardware'].append(f_1)
    all_fact_subsets['devices'].append(f_1)
    all_fact_subsets['kernel'].append(f_2)

    all_fact_subsets['hardware'].append(f_1)
    all_fact_subsets['no_duplicates'].append(f_1)

    selected_collector_classes = select_collector

# Generated at 2022-06-11 02:12:50.064884
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    minimal_gather_subset = frozenset(['!all', 'min'])
    valid_subsets = frozenset(['all', 'min', 'a', 'b', 'c', 'extra'])

    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['a'])
    class CollectorExtra(BaseFactCollector):
        name = 'extra'
        required_facts = set(['a', 'b'])

    all_collector_classes = [CollectorA, CollectorB, CollectorC, CollectorExtra]


# Generated at 2022-06-11 02:12:59.720904
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [CollectorA,],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    # all is required for d
    # a, b are required for c
    # b is required for a
    #
    # So, if someone only requests 'c', 'd', then b, a are unresolved.
    collector_names = set(['c', 'd'])
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['a', 'b'])

    # if someone requests 'a', 'b' then nothing is unresolved
    collector_names = set(['a', 'b'])
    unresolved = find_unresolved_requires

# Generated at 2022-06-11 02:13:06.806954
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    from ansible.module_utils.facts.virtual.lxc import LxcVirtual
    from ansible.module_utils.facts.virtual.xenserver import XenserverVirtual
    from ansible.module_utils.facts.virtual.vbox import VboxVirtual
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtual
    from ansible.module_utils.facts.virtual.openvz import OpenVZVirtual
    from ansible.module_utils.facts.virtual.system_profiler import SystemProfilerVirtual
   

# Generated at 2022-06-11 02:13:12.325533
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['facts', 'mounts', 'default', 'logs'], {})
    assert dep_map == {}
# # Unit test for function build_dep_data
# def test_build_dep_data():
#     dep_map = build_dep_data(['facts', 'mounts', 'default', 'logs'], {})
#     assert dep_map == {}



# Generated at 2022-06-11 02:13:24.100272
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'A'

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = {'C'}

    class CollectorC(BaseFactCollector):
        name = 'C'

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = {'C', 'E'}

    # test for finding duplicate collectors
    all_fact_subsets = {'A': [CollectorA(), CollectorA()],
                        'B': [CollectorB(), CollectorB()]}

    collector_names = ['A', 'B']

    selected_collectors = select_collector_classes(collector_names, all_fact_subsets)

    assert len(selected_collectors) == 2

    # comparing the 2 collector

# Generated at 2022-06-11 02:13:39.723312
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import pytest
    from ansible_collections.ansible.misc.plugins.module_utils.facts.utils.collectors import \
        BaseFactCollector, LinuxFactCollector

    # Create the test class
    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ('test1', 'test2', 'test3')

        def __init__(self):
            super(TestFactCollector, self).__init__()

    # Build the list of collectors
    test_collector = TestFactCollector()
    all_fact_subsets = {
        'test': [test_collector],
        'linux': [LinuxFactCollector()],
    }

    # Test when a single fact is specified

# Generated at 2022-06-11 02:13:51.810038
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all']) == {'all'}
    assert get_collector_names(['network']) == {'network'}
    assert get_collector_names(['network', 'all']) == {'network', 'all'}
    assert get_collector_names(['network', '!all']) == {'network'}
    assert get_collector_names(['network', '!network', '!all']) == set()
    assert get_collector_names(['network', '!network']) == set()
    assert get_collector_names(['distribution', '!all', 'kernel']) == {'distribution', 'kernel'}
    # aliases

# Generated at 2022-06-11 02:14:03.922636
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Dummy:
        pass
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = frozenset(['id1', 'id2'])
    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = frozenset(['id3', 'id4', 'id5'])

    all_collector_classes = [Collector1, Collector2]
    compat_platform = Dummy()
    compat_platform.system = platform.system()
    compat_platforms = [compat_platform]
    collectors_for_platform = find_collectors_for_platform(all_collector_classes, compat_platforms)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector

# Generated at 2022-06-11 02:14:12.888134
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector(BaseFactCollector):
        _fact_ids = set(['whoami', 'whoami_alias'])
        name = 'whoami'

    class TestFactCollector2(BaseFactCollector):
        _fact_ids = set(['whoami2', 'whoami_alias2'])
        name = 'whoami2'

    class TestFactCollector3(BaseFactCollector):
        _fact_ids = set(['whoami3', 'whoami_alias3'])
        name = 'whoami3'

    class TestFactCollector4(BaseFactCollector):
        _fact_ids = set(['whoami4', 'whoami4_alias'])
        name = 'whoami4'


# Generated at 2022-06-11 02:14:20.993992
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    aliases_map = defaultdict(set)
    aliases_map['platform'].add('os_version')
    aliases_map['platform'].add('os_family')

    assert len(aliases_map['platform']) == 2

    aliases_map['network'].add('interfaces')

    assert len(aliases_map['network']) == 1

    aliases_map['network'].add('default_ipv4')
    assert len(aliases_map['network']) == 2

    assert len(aliases_map) == 3

    assert len(aliases_map['network'].intersection(aliases_map['platform'])) == 0



# Generated at 2022-06-11 02:14:30.418792
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [
            FooFactCollector('a', ['b']),
            ],
        'b': [
            FooFactCollector('b', ['c']),
            ],
        'c': [
            FooFactCollector('c', ['d']),
            ],
        }
    unresolved = find_unresolved_requires(set(['a']), all_fact_subsets)
    assert unresolved == set(['d'])

    unresolved = find_unresolved_requires(set(['a', 'b', 'c']), all_fact_subsets)
    assert not unresolved


# Generated at 2022-06-11 02:14:41.226058
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset([
        'foo',
        'bar',
        'baz',
        'network',
        'hardware',
        'devices',
        'dmi',
        ])


# Generated at 2022-06-11 02:14:48.980444
# Unit test for function get_collector_names
def test_get_collector_names():
    # We should be able to gather all facts from all collectors
    assert get_collector_names(gather_subset=['all']) == set()
    # We should be able to exclude all facts from all collectors
    assert get_collector_names(gather_subset=['!']) == set()
    # We should be able to gather a subset of facts from select collectors
    assert get_collector_names(gather_subset=['network']) == set()
    # We should be able to exclude a subset of facts from select collectors
    assert get_collector_names(gather_subset=['!network']) == set()
    # We should be able to gather a subset of facts from select collectors
    assert get_collector_names(gather_subset=['network', 'hardware']) == set()
    # We should

# Generated at 2022-06-11 02:15:00.067437
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collectors = [PlatformFactCollector, DistributionFactCollector, VirtualFactCollector]
    facts = {'platform': [PlatformFactCollector], 'virtual': [VirtualFactCollector], 'distribution': [DistributionFactCollector]}
    assert select_collector_classes(['platform'], facts) == [PlatformFactCollector]
    assert select_collector_classes(['platform', 'virtual'], facts) == [PlatformFactCollector, VirtualFactCollector], select_collector_classes(['platform', 'virtual'], facts)
    assert select_collector_classes(['platform', 'platform'], facts) == [PlatformFactCollector], select_collector_classes(['platform', 'platform'], facts)



# Generated at 2022-06-11 02:15:09.878483
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector0(BaseFactCollector):
        _fact_ids = set(['id0'])
        name = 'collector0'
    class Collector1(BaseFactCollector):
        _fact_ids = set(['id1.a', 'id1.b'])
        name = 'collector1'

    map_, aliases_map = build_fact_id_to_collector_map(
        [Collector0, Collector1])

    assert set(map_.keys()) == set(['collector0', 'id0', 'id1.a', 'id1.b', 'collector1'])

    assert aliases_map['collector0'] == set(['id0'])
    assert aliases_map['collector1'] == set(['id1.a', 'id1.b'])


# Generated at 2022-06-11 02:15:39.189024
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import re

    class fake_collector_1(BaseFactCollector):
        name = 'fake1'
        _fact_ids = set(['fake1', 'fake11'])
        required_facts = set()
        _platform = 'Fake1'

    class fake_collector_2(BaseFactCollector):
        name = 'fake2'
        _fact_ids = set(['fake2', 'fake22'])
        required_facts = set(['fake1'])
        _platform = 'Fake1'
    class fake_collector_3(BaseFactCollector):
        name = 'fake2'
        _fact_ids = set(['fake2', 'fake22'])
        required_facts = set(['fake1'])
        _platform = 'Fake3'


# Generated at 2022-06-11 02:15:44.393452
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class C1(BaseFactCollector):
        name = "C1"
        _fact_ids = {'a', 'b'}

    class C2(BaseFactCollector):
        name = "C2"
        _fact_ids = {'b', 'c'}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        collectors_for_platform=[C1, C2])

    print(aliases_map)
    print(fact_id_to_collector_map)
    assert aliases_map == defaultdict(set, {'C1': {'a', 'b'}, 'C2': {'b', 'c'}})

# Generated at 2022-06-11 02:15:56.096079
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires([], {}) == set()
    assert find_unresolved_requires(['all'],
            {'all':[AllFactCollector()]}) == set()
    assert find_unresolved_requires(['a'],
            {'a':[NameCollector('a')], 'b':[NameCollector('b')]}) == set()

    class A(BaseFactCollector):
        name = 'a'
        required_facts = ['b']

    class B(BaseFactCollector):
        name = 'b'
        required_facts = ['c']

    class C(BaseFactCollector):
        name = 'c'
        required_facts = ['d']

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set()


# Generated at 2022-06-11 02:16:05.940348
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Base(BaseFactCollector):
        name = 'base'
        _fact_ids = frozenset(['base_id'])

    class Derived(Base):
        name = 'derived'
        _fact_ids = frozenset(['derived_id'])

    class Derived2(Derived):
        name = 'derived2'
        _fact_ids = frozenset(['derived2_id'])

    class Derived3(Derived):
        name = 'derived3'
        _fact_ids = frozenset(['derived3_id'])

    class Derived4(Base):
        name = 'derived4'
        _fact_ids = frozenset(['derived4_id'])

    collector_classes = [Derived, Base, Derived2, Derived3, Derived4]
    fact

# Generated at 2022-06-11 02:16:17.214934
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # setup: create a bunch of classes that have 'requires' fields
    class CollectA(object):
        required_facts = set(['b'])
    class CollectB(object):
        required_facts = set(['c'])
    class CollectC(object):
        required_facts = set()
    class CollectD(object):
        required_facts = set(['e'])
    class CollectE(object):
        required_facts = set(['f'])
    class CollectF(object):
        required_facts = set(['does_not_exist'])
    class CollectG(object):
        required_facts = set(['nonexistent_1', 'nonexistent_2'])

# Generated at 2022-06-11 02:16:28.509087
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_name_to_fact_ids_map = {
        'collector_A': set(('collector_B',)),
        'collector_B': set(('collector_C',)),
        'collector_C': set(('collector_D',)),
        'collector_D': set(),
    }

    all_fact_subsets = defaultdict(list)
    for name, _ in collector_name_to_fact_ids_map.items():
        all_fact_subsets[name].append(type(name, (BaseFactCollector,), {
            'name': name,
            'required_facts': collector_name_to_fact_ids_map[name],
        }))

    collector_names = set(('collector_A',))

    # collector_A -> collector_B -> collector_C

# Generated at 2022-06-11 02:16:31.874821
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b'], {'a': [], 'b': []})
    assert dep_map == defaultdict(set, {'a': set(), 'b': set()}), 'failed to build empty dep_map'

# Generated at 2022-06-11 02:16:42.702414
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import os
    file_path = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../library/cloud/amazon/plugins/modules"))
    sys.path.insert(0, file_path)

    from cloud.amazon.plugins.modules.ec2_group_facts import EC2GroupFacts
    from cloud.amazon.plugins.modules.ec2_instance_facts import EC2InstanceFacts
    from cloud.amazon.plugins.modules.ec2_key_facts import EC2KeyFacts
    from cloud.amazon.plugins.modules.ec2_region_facts import EC2RegionFacts
    from cloud.amazon.plugins.modules.ec2_vpc_facts import EC2VpcFacts


# Generated at 2022-06-11 02:16:47.275411
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    def fake_fact_classes():
        class FakeFactClass(BaseFactCollector):
            name = None
            _fact_ids = set()
            _platform = None
            required_facts = set()

        class FakeFactClass1(FakeFactClass):
            name = 'f1'
            _fact_ids = {'f1'}
            _platform = 'Linux'
            required_facts = set()

        class FakeFactClass2(FakeFactClass):
            name = 'f2'
            _fact_ids = {'f2'}
            _platform = 'Linux'
            required_facts = {'f1'}

        class FakeFactClass3(FakeFactClass):
            name = 'f3'
            _fact_ids = {'f3'}
            _platform = 'Linux'

# Generated at 2022-06-11 02:16:52.130230
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'test_linux': [
            TestLinuxFactCollector,
            TestLinuxFactCollector2,
        ],
        'test_darwin': [
            TestDarwinFactCollector,
        ],
        'test_windows': [
            TestWindowsFactCollector,
        ]
    }

    # test_windows requires test_linux
    assert set(['test_linux']) == find_unresolved_requires(['test_windows'], all_fact_subsets)

    # test_linux is ok
    assert set() == find_unresolved_requires(['test_linux'], all_fact_subsets)

    # test_darwin is ok
    assert set() == find_unresolved_requires(['test_darwin'], all_fact_subsets)

    # test

# Generated at 2022-06-11 02:17:11.210010
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class CollectFacts1(BaseFactCollector):
        _fact_ids = frozenset(['fact1', 'fact2'])

    class CollectFacts2(BaseFactCollector):
        _fact_ids = frozenset(['fact3', 'fact4'])

    class CollectFacts3(BaseFactCollector):
        _fact_ids = frozenset(['fact5', 'fact6'])

    all_collector_classes = [
        CollectFacts1,
        CollectFacts2,
        CollectFacts3
    ]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)


# Generated at 2022-06-11 02:17:22.955535
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = {'required_fact1', 'required_fact2'}
    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = {'required_fact2', 'required_fact3'}
    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    collector_classes = {Collector1, Collector2, Collector3}

    all_fact_subsets = {}
    for collector_class in collector_classes:
        for fact_id in collector_class.fact_ids:
            all_fact_subsets.setdefault(fact_id, []).append(collector_class)


# Generated at 2022-06-11 02:17:32.108498
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.facts.fact_collector import TestCollector1, TestCollector2
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.facts.fact_collector import TestCollector3, TestCollector4

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test1'].append(TestCollector1)
    all_fact_subsets['test2'].append(TestCollector2)
    all_fact_subsets['test3'].append(TestCollector3)
    all_fact_subsets['test4'].append(TestCollector4)

    # No unresolved dependencies
    collector_names = ['test1', 'test2']
   

# Generated at 2022-06-11 02:17:43.139844
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'base': [BaseFactCollector]
        ,'dmi': [BaseFactCollector]
        ,'network': [BaseFactCollector, BaseFactCollector]
        ,'system': [BaseFactCollector]
    }

    for collector_class in all_fact_subsets.values():
        for c in collector_class:
            c.required_facts = set()

    # first, a set with no unresolved requirements
    collector_names = ['dmi', 'network', 'system']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # next a set with unresolved requirements

# Generated at 2022-06-11 02:17:53.810830
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = ('fact1a',)
        name = 'fact1'

    class Collector2(BaseFactCollector):
        _fact_ids = ('fact2a',)
        name = 'fact2'

    print("test_build_fact_id_to_collector_map")

# Generated at 2022-06-11 02:18:02.115030
# Unit test for function get_collector_names
def test_get_collector_names():
    assert sorted(get_collector_names(
        ["all"],
        ['min'],
        ['Network']
    )) == ['Network', 'min']

    assert sorted(get_collector_names(
        ["Arch"],
        ['min'],
        ['Arch', 'Network']
    )) == ['Arch', 'min', 'Network']

    # Test a platform-specific match
    if platform.system() == 'FreeBSD':
        assert sorted(get_collector_names(
            ["Facts", "FreeBSD"],
            ['min'],
            ['Network']
        )) == ['Facts', 'FreeBSD', 'min', 'Network']



# Generated at 2022-06-11 02:18:10.691330
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Setup

    class Collector0(BaseFactCollector):
        name = 'collector0'
        _platform = 'FakeOS'
        _fact_ids = ['collector0', 'collector0_1']

    class Collector1(BaseFactCollector):
        name = 'collector1'
        _platform = 'FakeOS'
        _fact_ids = ['collector1', 'collector1_1']

    all_collectors = [Collector0, Collector1]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors)


# Generated at 2022-06-11 02:18:18.647731
# Unit test for function build_dep_data
def test_build_dep_data():
    # build the input data
    collector_names = ['network', 'system']
    all_fact_subsets = {
        'network': [BaseFactCollector],
        'system': [BaseFactCollector],
    }
    expected_dep_data = {
        'network': set(),
        'system': set(),
    }
    dep_data = build_dep_data(collector_names, all_fact_subsets)
    assert (dep_data == expected_dep_data)



# Generated at 2022-06-11 02:18:27.852486
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['a1', 'a2'])
        name = 'a'
    class CollectorB(BaseFactCollector):
        _fact_ids = set(['b1', 'b2'])
        name = 'b'

    result = build_fact_id_to_collector_map([CollectorA, CollectorB])

    # build_fact_id_to_collector_map populates aliases_map
    # based on _fact_ids and name
    aliases_map = result[1]

    assert CollectorA.name in aliases_map
    assert CollectorB.name in aliases_map



# Generated at 2022-06-11 02:18:34.496505
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['f0']
    all_fact_subsets = {
        'f0': [
            FactCollectorClass(f0, [])
        ],
        'f1': [
            FactCollectorClass(f1, ['f0'])
        ]
    }

    result = find_unresolved_requires(collector_names, all_fact_subsets)
    assert result == set()



# Generated at 2022-06-11 02:19:09.965728
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.default import Default
    collector_for_platform = [Hardware, Network, Default]

# Generated at 2022-06-11 02:19:21.210917
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FakeCollectorA(BaseFactCollector):
        name = 'A'

    class FakeCollectorB(BaseFactCollector):
        name = 'B'

    class FakeCollectorC(BaseFactCollector):
        name = 'C'

    class FakeCollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = set(('a', 'c'))

    class FakeCollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = set(('A', 'C'))

    class FakeCollectorF(BaseFactCollector):
        name = 'F'
        _fact_ids = set(('A', 'B', 'D'))

    class FakeCollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-11 02:19:33.095485
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'foo': [object(),],
        'bar': [object(),],
        'baz': [object(),],
    }
    all_fact_subsets['foo'][0].required_facts = {'foo'}
    all_fact_subsets['bar'][0].required_facts = {'baz'}
    all_fact_subsets['baz'][0].required_facts = set()

    unresolved = find_unresolved_requires(set(), all_fact_subsets)
    assert set() == unresolved
    unresolved = find_unresolved_requires({'foo'}, all_fact_subsets)
    assert {'foo'} == unresolved
    unresolved = find_unresolved_requires({'bar'}, all_fact_subsets)

# Generated at 2022-06-11 02:19:45.818452
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.aix import DistributionAIXFactCollector
    from ansible.module_utils.facts.system.distribution.arch import DistributionArchFactCollector
    from ansible.module_utils.facts.system.distribution.coreos import DistributionCoreOSFactCollector
    from ansible.module_utils.facts.system.distribution.cisco_nxos import DistributionCiscoNxOSFactCollector
    from ansible.module_utils.facts.system.distribution.debian import DistributionDebianFactCollector
    from ansible.module_utils.facts.system.distribution.gentoo import DistributionGentooFactCollector

# Generated at 2022-06-11 02:19:59.043671
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fid-1a', 'fid-1b'])
        name = 'fact_1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fid-1c'])
        name = 'fact_1'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fid-3'])
        name = 'fact_3'

    test_collector_classes = (
        Collector1,
        Collector2,
        Collector3,
    )

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(test_collector_classes)


# Generated at 2022-06-11 02:20:06.107051
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import DEFAULT_COLLECTORS

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(DEFAULT_COLLECTORS)

    assert 'devicename' in fact_id_to_collector_map
    assert 'devices' in aliases_map

    assert 'dmi' in fact_id_to_collector_map
    assert 'dmi' in aliases_map['hardware']

    assert 'pkg_mgr' in aliases_map['software']

    assert 'identity' in aliases_map['system']


# Generated at 2022-06-11 02:20:10.689960
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test gather_subset expansion when gather_subset is ['all'],
    # minimal_gather_subset is ['min'] and valid_subsets is the empty set
    assert get_collector_names(valid_subsets=frozenset(),
                               minimal_gather_subset=frozenset(['min']),
                               aliases_map=defaultdict(set),
                               gather_subset=['all']) == frozenset(['min'])

    # Test gather_subset expansion when gather_subset is ['all'], valid_subsets
    # is ['hardware'...], minimal_gather_subset is ['min']

# Generated at 2022-06-11 02:20:21.586651
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import pytest
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import NetBSDDistributionFactCollector

    class Collector1(BaseFactCollector):
        _fact_ids = ['collector1']

        def __init__(self, *args, **kwargs):
            super(Collector1, self).__init__(*args, **kwargs)

    class Collector2(BaseFactCollector):
        _fact_ids = ['collector2']


# Generated at 2022-06-11 02:20:34.547606
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector0(BaseFactCollector):
        name = 'Collector0'
        _fact_ids = frozenset(['0', '00'])

    class Collector00(BaseFactCollector):
        name = 'Collector00'
        _fact_ids = frozenset(['00'])

    class Collector1(BaseFactCollector):
        name = 'Collector1'
        _fact_ids = frozenset(['1'])

    result = build_fact_id_to_collector_map(frozenset([Collector0, Collector00, Collector1]))

# Generated at 2022-06-11 02:20:43.939889
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts.collector import get_collectors_for_gather_subset

    if not hasattr(pytest, 'skip'):
        pytest.skip('Ansible too old')

    # TODO: this test is incomplete
    def get_mock_collectors():
        class MockCollector1(BaseFactCollector):
            name = 'mock1'
            _fact_ids = set(['mock1'])
            required_facts = set(['mock2'])

        class MockCollector2(BaseFactCollector):
            name = 'mock2'
            _fact_ids = set(['mock2'])
            required_facts = set(['mock1'])


# Generated at 2022-06-11 02:21:15.109527
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollectorA(BaseFactCollector):
        _fact_ids = set(['FACT_A'])
        name = 'test'
    class TestCollectorB(BaseFactCollector):
        _fact_ids = set(['FACT_B'])
        name = 'test'
    class TestCollectorC(BaseFactCollector):
        _fact_ids = set(['FACT_C'])
        name = 'test'
        required_facts = set(['FACT_A', 'FACT_B'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollectorA, TestCollectorB, TestCollectorC])
    assert 'test' in fact_id_to_collector_map
    assert 'FACT_A'

# Generated at 2022-06-11 02:21:21.248291
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.community.general.plugins.modules.system import distribution
    collector_classes = [distribution.GenericDistribution]
    all_fact_subsets = {}
    for collector_class in collector_classes:
        all_fact_subsets[collector_class.name] = [collector_class]
    collector_names = ['distribution']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['system'])



# Generated at 2022-06-11 02:21:26.091773
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data({"os", "distribution", "facter"}, {"os": ("a", "b"), "facter": ("a", "c")})
    assert dep_map == defaultdict(set, {"os": {"facter", "distribution"}, "distribution": {"facter"}, "facter": set()})


# Generated at 2022-06-11 02:21:34.294771
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['collector_a', 'collector_c', 'collector_d']
    all_fact_subsets = {
        'collector_a': [TestCollectorA, ],
        'collector_b': [TestCollectorB, ],
        'collector_c': [TestCollectorC, ],
        'collector_d': [TestCollectorD, ]}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'collector_b'}

