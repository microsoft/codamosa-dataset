

# Generated at 2022-06-11 02:12:20.492743
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FakeCollector1(BaseFactCollector):
        _fact_ids = frozenset(['fact_a_alias'])
        name = 'fact_a'
        required_facts = set()

    class FakeCollector2(BaseFactCollector):
        _fact_ids = frozenset(['fact_b_alias'])
        name = 'fact_b'
        required_facts = frozenset(['fact_a'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([FakeCollector1, FakeCollector2])
    assert aliases_map == {'fact_a': {'fact_a_alias'}, 'fact_b': {'fact_b_alias'}}

# Generated at 2022-06-11 02:12:32.495235
# Unit test for function get_collector_names
def test_get_collector_names():
    # all should be included with '!all,min'
    results = get_collector_names(valid_subsets=frozenset(['all']),
                                  minimal_gather_subset=frozenset(['min']),
                                  gather_subset=['!all', 'min'])
    assert results == frozenset(['all'])

    # all should be included with '!all,min'
    results = get_collector_names(valid_subsets=frozenset(['all']),
                                  minimal_gather_subset=frozenset(['min']),
                                  gather_subset=['!all', 'min'])
    assert results == frozenset(['all'])

    # no subsets should be included with '!all,min,foo'
    results = get_

# Generated at 2022-06-11 02:12:40.038828
# Unit test for function tsort
def test_tsort():
    '''Make sure we can tsort with a cycle present, which means we should
    raise an exception
    '''
    test_map = {
        'A': set(['B']),
        'B': set(['C']),
        'C': set(['A']),
    }
    try:
        tsort(test_map)
        raise AssertionError('Should have raised CycleFoundInFactDeps, but did not.')
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-11 02:12:46.326439
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set()

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set()

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set()

    class G(BaseFactCollector):
        name = 'g'
        required_facts = set(['a'])
        # results in cycle: a->

# Generated at 2022-06-11 02:12:57.693346
# Unit test for function get_collector_names
def test_get_collector_names():
    # GIVEN: a set of valid_subsets, minimal_gather_subsets, aliases_map, and params.
    valid_subsets = frozenset(['network', 'config', 'interfaces', 'default', 'hardware', 'dmi', 'devices', 'firmware', 'identity', 'all'])
    minimal_gather_subsets = frozenset(['system', 'platform', 'default'])
    aliases_map = {
        'default': frozenset(['system', 'platform', 'default']),
        'hardware': frozenset(['system', 'platform', 'default', 'hardware', 'devices', 'dmi', 'firmware']),
    }

    # WHEN: make a call to get_collector_names().

# Generated at 2022-06-11 02:13:08.691310
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'a': [
            Dummy_Collector_A,
            Dummy_Collector_A_1,
            Dummy_Collector_A_2,
        ],
        'b': [
            Dummy_Collector_B,
            Dummy_Collector_B_1,
            Dummy_Collector_B_2,
        ],
        'c': [
            Dummy_Collector_C,
            Dummy_Collector_C_1,
            Dummy_Collector_C_2,
        ],
    }
    collector_names = ['b', 'c', 'a', 'd']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

# Generated at 2022-06-11 02:13:17.956085
# Unit test for function get_collector_names
def test_get_collector_names():
    res = get_collector_names(
        gather_subset=['all'],
        valid_subsets=frozenset(['network', 'hardware'])
    )
    expected = frozenset(['network', 'hardware'])
    assert res == expected

    res = get_collector_names(
        gather_subset=['network'],
        valid_subsets=frozenset(['network', 'hardware'])
    )
    expected = frozenset(['network'])
    assert res == expected

    res = get_collector_names(
        gather_subset=['!network'],
        valid_subsets=frozenset(['network', 'hardware'])
    )
    expected = frozenset(['hardware'])
    assert res == expected

    res = get

# Generated at 2022-06-11 02:13:26.250610
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    for collector_name in ['aggregate_1','aggregate_2','aggregate_3','aggregate_4','aggregate_5']:
        collector_deps = set()
        for collector in [1,2,3,4,5]:
            for dep in [1,2,3,4,5]:
                collector_deps.add(dep)
        dep_map[collector_name] = collector_deps
    return dep_map



# Generated at 2022-06-11 02:13:37.795548
# Unit test for function select_collector_classes
def test_select_collector_classes():
    import os, sys

    REGEX_VALIDATE_COLLECTOR_NAME = r'^[a-z][a-z0-9_]*$'
    m = re.compile(REGEX_VALIDATE_COLLECTOR_NAME)
    class_set = set()
    for c in all_collectors_list:
        if c.name in class_set or not m.search(c.name):
            raise ValueError("Class %s not a valid name" % c.name)
        class_set.add(c.name)

    all_collector_classes = all_collectors_list
    # create a dict of name to class
    fact_id_to_collector_map = defaultdict(list)
    for collector_class in all_collector_classes:
        fact_id_to_collector

# Generated at 2022-06-11 02:13:47.140828
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [_FakeCollector(['b'])],
        'b': [_FakeCollector([])],
        'c': [_FakeCollector(['b', 'd'])],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['c'], all_fact_subsets) == set(['d'])



# Generated at 2022-06-11 02:14:04.493385
# Unit test for function get_collector_names
def test_get_collector_names():

    # test values for parameters
    input_gather_subset = ['all']
    input_valid_subsets = frozenset(['!min', 'hardware', 'software', 'all', 'min'])
    input_minimal_gather_subset = frozenset(['!min', 'all', 'min'])
    input_aliases_map = defaultdict(set, {'hardware': frozenset(['!software', 'devices', 'dmi'])})

    output_collector_names = get_collector_names(valid_subsets=input_valid_subsets,
                                                 minimal_gather_subset=input_minimal_gather_subset,
                                                 gather_subset=input_gather_subset,
                                                 aliases_map=input_aliases_map)

   

# Generated at 2022-06-11 02:14:15.279426
# Unit test for function get_collector_names
def test_get_collector_names():
    # TODO: unit test of get_collector_names is skipped by issue #34621
    # it works well when the test is run manually
    assert get_collector_names() == frozenset()
    return

    # most basic case, no subsets
    collected_subsets = get_collector_names()
    assert 'all' in collected_subsets

    # TODO: this test is skipped until the test of get_collector_names is fixed
    # # all with a subset
    # collected_subsets = get_collector_names(gather_subset=['a'])
    # assert 'a' in collected_subsets
    # assert 'all' not in collected_subsets

    # # subset expanded
    # collected_subsets = get_collector_names(gather_subset=['a'], aliases_

# Generated at 2022-06-11 02:14:25.712511
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['one', 'two', 'three']
    all_fact_subsets = {}
    all_fact_subsets['one'] = [class_one, class_two]
    all_fact_subsets['two'] = [class_two]
    all_fact_subsets['three'] = [class_three]
    class_one = FakeCollector('one', ['one'])
    class_two = FakeCollector('two', ['two'])
    class_three = FakeCollector('three', ['three'])
    details = build_dep_data(collector_names, all_fact_subsets)
    assert details == {'one': set(['one']), 'two': set(['two']), 'three': set(['three'])}


# Generated at 2022-06-11 02:14:37.662857
# Unit test for function get_collector_names
def test_get_collector_names():
    # minimal_gather_subset=None, gather_subset=None
    assert get_collector_names() == frozenset(['all'])
    # gather_subset=None
    assert get_collector_names(minimal_gather_subset=frozenset(['OS', 'hostname'])) == frozenset(['OS', 'hostname'])

    # minimal_gather_subset=None
    assert get_collector_names(gather_subset=['OS', 'hardware']) == frozenset(['OS', 'hardware'])
    assert get_collector_names(gather_subset=['OS', 'hardware', '!hardware']) == frozenset(['OS'])
    assert get_collector_names(gather_subset=['!all'])

# Generated at 2022-06-11 02:14:47.269594
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import darwin

    collectors_for_platform = [darwin.DarwinHardware, darwin.DarwinDefault]

    expected_fact_id_to_collector_map = {
        'default': [darwin.DarwinDefault],
        'hardware': [darwin.DarwinHardware],
        'system': [darwin.DarwinDefault],
    }

    expected_aliases_map = defaultdict(set, {
        'default': {'system'},
        'hardware': set(),
    })

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map == expected_fact_id_to_collector_map

# Generated at 2022-06-11 02:15:00.067151
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['a', 'b', 'c', 'd'])
    minimal_gather_subset = frozenset(['a', 'b'])
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(['devices', 'dmi'])

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset) == frozenset(['a', 'b', 'c', 'd'])

# Generated at 2022-06-11 02:15:08.701020
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyCollector(BaseFactCollector):
        _fact_ids = set(['foo', 'bar'])
        name = 'unit_test'
    result = build_fact_id_to_collector_map([MyCollector])
    expected_fact_id_to_collector_map = {
        'unit_test': [MyCollector],
        'foo': [MyCollector],
        'bar': [MyCollector],
    }
    expected_aliases_map = {
        'unit_test': set(['foo', 'bar']),
    }
    assert result == (expected_fact_id_to_collector_map, expected_aliases_map)



# Generated at 2022-06-11 02:15:19.519117
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = ['all', 'network', 'hardware', 'virtual']

    minimal_gather_subset = ['network']

    aliases_map = {'hardware': frozenset(['devices', 'dmi'])}

    # case 1, subset 'all'
    gather_subset = ['all']
    additional_subsets = get_collector_names(valid_subsets=valid_subsets,
                                             minimal_gather_subset=minimal_gather_subset,
                                             gather_subset=gather_subset,
                                             aliases_map=aliases_map)
    assert(additional_subsets == frozenset(['network', 'hardware', 'virtual']))

    # case 2, subset 'hardware'
    gather_subset = ['hardware']
    additional

# Generated at 2022-06-11 02:15:28.383897
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes(['Network', 'System'], {
        'Network': [1,2,3],
        'Hardware': [3,4,5],
        'System': [3,4,5],
        'Minimal': [6,7,8],
    }) == [1,2,3,4,5]

    assert select_collector_classes(['Network', 'Network'], {
        'Network': [1,2,3],
    }) == [1,2,3]

    assert select_collector_classes(['Network'], {}) == []



# Generated at 2022-06-11 02:15:38.164840
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Setup a module object
    module = FakeModule()
    platform_info = {'system': 'Linux'}
    # Create a Linux OS collector
    class OSCollectorLinux(BaseFactCollector):
        _platform = 'Linux'
        name = 'os'
        fact_ids = ['linux']
        required_facts = ['os']
        def collect(self, module=None, collected_facts=None):
            return {}

    class OSCollectorGeneric(BaseFactCollector):
        name = 'os'
        fact_ids = ['generic']
        required_facts = ['os']
        def collect(self, module=None, collected_facts=None):
            return {}

    # Create a test collector
    class TestCollector(BaseFactCollector):
        name = 'test'
        fact_ids = ['test']
        required

# Generated at 2022-06-11 02:15:55.797713
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'name1': (BaseFactCollector, ),
        'name2': (BaseFactCollector, ),
        'name3': (BaseFactCollector, ),
    }

    all_fact_subsets['name1'][0].required_facts = set(['name2'])
    all_fact_subsets['name3'][0].required_facts = set(['name4'])

    collector_names = set(['name1', 'name2'])

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

    assert not unresolved

    collector_names = set(['name1'])

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

    assert unresolved == set(['name2'])



# Generated at 2022-06-11 02:16:05.688129
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import copy

    class TestFactCollectorClass(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['testing'])

    expected_primary_name = 'test'
    expected_fact_ids = set([
        expected_primary_name,
        'testing'
    ])

    generic_platform_info = {}
    all_collector_classes = [
        TestFactCollectorClass
    ]

    found_collectors = find_collectors_for_platform(all_collector_classes,
                                                    [generic_platform_info])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(found_collectors)

    # check that our found classes match what we expect

# Generated at 2022-06-11 02:16:16.970980
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # NOTE: This test function is not called from anywhere;
    # it is here to facilitate writing tests for
    # find_unresolved_requires.
    from ansible.module_utils.facts import collector
    import pytest
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.ohai_flavor import OhaiFlavorCollector
    from ansible.module_utils.facts.collector.ansible_user import AnsibleUserCollector

    class TestCollector(BaseFactCollector):
        name = 'test_collector'

        required_facts = {'ohai.os'}

    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-11 02:16:28.283183
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        gather_subset=['all'],
        valid_subsets=frozenset(('platform', 'network'))) == frozenset(('platform', 'network'))

    assert get_collector_names(
        gather_subset=['!network'],
        valid_subsets=frozenset(('platform', 'network'))) == frozenset(('platform', 'network'))

    assert get_collector_names(
        gather_subset=['network'],
        valid_subsets=frozenset(('platform', 'network'))) == frozenset(('network',))


# Generated at 2022-06-11 02:16:37.856550
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():


    def make_collector_class(collector_name, required_facts):
        class Collector(BaseFactCollector):
            name = collector_name
            required_facts = required_facts
        return Collector

    class collectors(object):
        all_fact_subsets = {}
        all_fact_subsets[make_collector_class('foo', set())] = 'foo'
        all_fact_subsets[make_collector_class('bar', set())] = 'bar'
        all_fact_subsets[make_collector_class('baz', {'foo'})] = 'baz'
        all_fact_subsets[make_collector_class('qux', {'foo', 'bar'})] = 'qux'

# Generated at 2022-06-11 02:16:49.288900
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Define a test class to test the function
    class TestClass(BaseFactCollector):
        name = 'test_1'
        _fact_ids = set(['test_1', 'test_2',
                         'test_3'])
        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Generic':
                return cls
            return None

    class TestClass2(BaseFactCollector):
        name = 'test_2'
        _fact_ids = set(['test_2', 'test_3',
                         'test_4'])
        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Generic':
                return cls
            return None

    all

# Generated at 2022-06-11 02:16:56.970852
# Unit test for function tsort
def test_tsort():
    a = {'A': set(('B',)), 'B': set()}
    assert tsort(a) == [('B', set()), ('A', set(('B',)))]

    # Test it raises Error on cycles
    b = {'A': set(('B',)), 'B': set(('A',))}
    try:
        tsort(b)
        # tsort didn't raise error, test fails.
        assert False
    except CycleFoundInFactDeps:
        # it did raise error, so pass
        pass



# Generated at 2022-06-11 02:17:07.225483
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.pci import PciCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.dmi import DmiCollector

    fact_ids = [
        SystemCollector,
        PciCollector,
        VirtualCollector,
        DmiCollector,
    ]
    all_fact_subsets = defaultdict(list)

    for fact_id in fact_ids:
        all_fact_subsets[fact_id.name].append(fact_id)


# Generated at 2022-06-11 02:17:16.536587
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import sys
    sys.path.append('./lib/ansible/module_utils/facts/')
    from system import SystemCollector, VirtualizationCollector, NetworkCollector
    collectors_for_platform = [
        SystemCollector,
        VirtualizationCollector,
        NetworkCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert len(fact_id_to_collector_map) == 6
    assert fact_id_to_collector_map['system'] == [SystemCollector]
    assert fact_id_to_collector_map['virtualization'] == [VirtualizationCollector]
    assert fact_id_to_collector_map['network'] == [NetworkCollector]
    assert fact_id

# Generated at 2022-06-11 02:17:28.549489
# Unit test for function get_collector_names
def test_get_collector_names():
    input_valid_subsets = frozenset(['all', 'network', 'hardware', 'virtual'])
    input_minimal_gather_subset = frozenset(['network'])
    input_gather_subset = ['all', '!dmi']
    input_aliases_map = defaultdict(set)
    input_aliases_map['hardware'].update(['devices', 'dmi'])

    expected_result = frozenset(['network', 'virtual'])

    collector_names = get_collector_names(valid_subsets=input_valid_subsets,
                                          minimal_gather_subset=input_minimal_gather_subset,
                                          gather_subset=input_gather_subset,
                                          aliases_map=input_aliases_map)

# Generated at 2022-06-11 02:17:42.637420
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    mock_subsets = {
        'resolved': [
            'one',
            'two'
        ],
        'depends-resolved': [
            'resolved',
            'depends-unresolved'
        ],
        'unresolved': [
        ]
    }
    unresolved_requires = find_unresolved_requires(
        ['depends-resolved', 'unresolved'],
        mock_subsets
    )
    assert 'unresolved' in unresolved_requires
    assert 'resolved' not in unresolved_requires
    assert 'depends-resolved' not in unresolved_requires



# Generated at 2022-06-11 02:17:53.080879
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _platform = 'platformA'

    class CollectorB(BaseFactCollector):
        name = 'B'
        _platform = 'platformA'
        _fact_ids = ['extra_factA']

    class CollectorC(BaseFactCollector):
        name = 'C'
        _platform = 'platformA'
        _fact_ids = ['extra_factB', 'extra_factC']

    all_collector_classes = (CollectorA, CollectorB, CollectorC)

    platform_info_A = {
        'system': 'platformA'
    }
    platform_info_B = {
        'system': 'platformB'
    }

    platform_infos = (platform_info_A, platform_info_B)


# Generated at 2022-06-11 02:18:03.126848
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['C', 'D'])

    class TestCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['D'])

    class TestCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    all_fact_subsets = {
        'A': [TestCollectorA()],
        'B': [TestCollectorB()],
        'C': [TestCollectorC()],
    }

    unresolved = find_unresolved_requires(['A', 'B', 'C'], all_fact_subsets)
    assert unresolved == set()


# Generated at 2022-06-11 02:18:11.200235
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with value specified for gather_subset
    assert get_collector_names(valid_subsets=frozenset(['hardware']),
                               gather_subset=['hardware']) == frozenset(['hardware'])

    # Test with value not specified for gather_subset (should default to all)
    assert get_collector_names(valid_subsets=frozenset(['hardware', 'software']),
                               gather_subset=None) == frozenset(['hardware', 'software'])

    assert get_collector_names(valid_subsets=frozenset(['hardware', 'software']),
                               gather_subset=['!hardware']) == frozenset(['software'])


# Generated at 2022-06-11 02:18:23.383904
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = frozenset(['a'])
    all_fact_subsets = {
        'a': [FactCollectorA],
    }
    unreolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unreolved == set(['b'])

    collector_names = frozenset(['a'])
    all_fact_subsets = {
        'a': [FactCollectorA, FactCollectorA2],
    }
    unreolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unreolved == set(['b'])

    collector_names = frozenset(['a'])

# Generated at 2022-06-11 02:18:32.319935
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        _fact_ids = ['aaa', 'bbb']
    class B(BaseFactCollector):
        _fact_ids = ['bbb', 'ccc']
    class C(BaseFactCollector):
        _fact_ids = ['ccc', 'ddd']

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        [A, B, C])
    assert fact_id_to_collector_map == {
        'aaa': [A],
        'bbb': [A, B],
        'ccc': [B, C],
        'ddd': [C]
    }

# Generated at 2022-06-11 02:18:41.029409
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import ansible_default_collectors

    test_fact_subsets = dict(all=ansible_default_collectors)
    test_fact_subsets['foo'] = [BaseFactCollector]
    test_fact_subsets['foo'][0].required_facts = set(['bar'])

    assert 'bar' in find_unresolved_requires(['foo'], test_fact_subsets)

    test_fact_subsets['bar'] = [BaseFactCollector]
    assert not find_unresolved_requires(['foo'], test_fact_subsets)

    test_fact_subsets['bar'] = [object]
    test_fact_subsets['bar'][0].required_facts = set(['bar'])
    assert 'bar' in find_unresolved

# Generated at 2022-06-11 02:18:52.223539
# Unit test for function get_collector_names
def test_get_collector_names():
    try:
        result = get_collector_names(
            valid_subsets=frozenset(['all', 'network', 'ohai', '!network']),
            minimal_gather_subset=frozenset([]),
            gather_subset=['all', '!network'])
        print("result: %s" % result)
        assert result == set(['all', 'ohai'])
    except TypeError as ex:
        print("exception: %s" % ex)
        assert False


# Generated at 2022-06-11 02:19:00.653508
# Unit test for function get_collector_names
def test_get_collector_names():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector import (
        ALL_SUBSETS, LinuxFactCollector, DarwinFactCollector, get_collector_names,
    )
    valid_subsets = ALL_SUBSETS
    minimal_gather_subset = frozenset(['min'])
    aliases_map = defaultdict(set)

    aliases_map.update(LinuxFactCollector.aliases)
    aliases_map.update(DarwinFactCollector.aliases)

    test_data = dict(
        minimal_gather_subset=minimal_gather_subset,
        aliases_map=aliases_map,
        valid_subsets=valid_subsets,
        platform_info=None,
    )

    result = get_collector_

# Generated at 2022-06-11 02:19:06.652946
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = {'b'}

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = {'c', 'c0'}

    def sort_key(cls):
        return cls.__name__

    for platform_info in [
            {'system': 'Linux'},
            {'system': 'FreeBSD'},
    ]:
        collectors_for_platform = set([CollectorA, CollectorB, CollectorC])
        fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

        assert fact_id_to_

# Generated at 2022-06-11 02:19:36.204866
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # The simplest case -- no collector names, nothing to collect, nothing
    # unresolved
    collector_names = []
    unresolved = find_unresolved_requires(collector_names, {})
    assert unresolved == set()
    #
    # An unresolved fact, but not requested
    unresolved = find_unresolved_requires(collector_names, {'something': [BaseFactCollector]})
    assert unresolved == set()
    #
    # A collector with a single requirement, and that is requested
    collector_names = ['something']
    unresolved = find_unresolved_requires(collector_names, {'something': [BaseFactCollector]})
    assert unresolved == set()
    #
    # A collector with a single requirement, and that is not requested
    collector_names = ['something']
    unresolved = find_unresolved_requires

# Generated at 2022-06-11 02:19:46.286906
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['network', '!dmi'], valid_subsets=['network', 'dmi']) == set(['network'])

    # test aliases
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = set(['devices', 'dmi'])
    aliases_map['software'] = set(['os'])
    aliases_map['virtual'] = set(['container'])

    assert get_collector_names(gather_subset=['hardware', '!dmi'], valid_subsets=['devices', 'dmi'], aliases_map=aliases_map) == set(['devices'])



# Generated at 2022-06-11 02:19:59.697822
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector1': [MockCollector(required_facts=[])],
        'collector2': [MockCollector(required_facts=['collector1'])],
        'collector3': [MockCollector(required_facts=['collector1', 'collector2'])],
        'collector4': [MockCollector(required_facts=['collector1', 'collectorX'])],
    }
    collector_names = ['collector1', 'collector2', 'collector3']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['collector2', 'collector3'])

    collector_names = ['collector1', 'collector2', 'collector4']
    assert find_unres

# Generated at 2022-06-11 02:20:09.179733
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': []}
    # Unit test: no unresolved requires
    assert find_unresolved_requires(['a'], all_fact_subsets) == set()

    class A(BaseFactCollector):
        _fact_ids = {'a'}
        required_facts = {'b'}

    # Unit test: one unresolved require
    all_fact_subsets = {'a': [A]}
    assert find_unresolved_requires(['a'], all_fact_subsets) == {'b'}

    class B(BaseFactCollector):
        _fact_ids = {'b'}
        required_facts = {'c'}

    # Unit test: two unresolved requires
    all_fact_subsets = {'a': [A], 'b': [B]}


# Generated at 2022-06-11 02:20:15.093988
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        required_facts = set()

    all_fact_subsets = {TestCollector.name: [TestCollector]}
    unresolved = find_unresolved_requires([TestCollector.name], all_fact_subsets)
    assert len(unresolved) == 0



# Generated at 2022-06-11 02:20:24.110194
# Unit test for function get_collector_names
def test_get_collector_names():
    minimal_set = frozenset(['localhost'])
    valid_set = minimal_set.union(['hardware', 'network'])

    # basic test of 'all' and 'min'
    gs = ['all']
    result = get_collector_names(valid_subsets=valid_set,
                                 minimal_gather_subset=minimal_set,
                                 gather_subset=gs)
    assert result == valid_set

    gs = ['min']
    result = get_collector_names(valid_subsets=valid_set,
                                 minimal_gather_subset=minimal_set,
                                 gather_subset=gs)
    assert result == minimal_set

    # test excludes
    gs = ['all', '!network']

# Generated at 2022-06-11 02:20:32.588884
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'1': ['a', 'b'], '2': ['c', 'd'], '3': ['e', 'f']}
    collector_names = ['1', '2', '3']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['1'] == set() and dep_map['2'] == set() and dep_map['3'] == set()



# Generated at 2022-06-11 02:20:42.531256
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts.test_utils import FakeCollector

    FakeCollector.platform_match({'system': 'Linux'})

    # test for multiple collectors for the same name. Make sure all
    # required facts are considered, not just the first collector for
    # each name.
    dep_map = build_dep_data(['a'],
                             {'a': [FakeCollector('a', required_facts=['b']),
                                    FakeCollector('a', required_facts=['c'])]
                              })
    assert dep_map == {'a': {'b', 'c'}}

    # test 'all' collector

# Generated at 2022-06-11 02:20:52.439500
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from . import test_collectors
    class Collector1(BaseFactCollector):
        name = ' collector1 '
        required_facts = set(['c2', 'c3'])
    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['c1'])
    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    all_collectors_dict = {' collector1 ': [Collector1, ],
                           'collector2': [Collector2, ],
                           'collector3': [Collector3, ]}

    test_collectors.test_objects.extend([Collector1, Collector2, Collector3])


# Generated at 2022-06-11 02:21:03.015753
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b', 'c', 'd']
    all_fact_subsets = {
        'a': [MockCollectorClass(required_facts=['c', 'd']), ],
        'b': [MockCollectorClass(required_facts=['a']), ],
        'c': [MockCollectorClass(), ],
        }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    all_fact_subsets = {
        'a': [MockCollectorClass(required_facts=['c', 'd']), ],
        'b': [MockCollectorClass(required_facts=['a'], required_facts=['c']), ],
        'c': [MockCollectorClass(), ],
        }
    assert find_un

# Generated at 2022-06-11 02:21:39.460972
# Unit test for function get_collector_names
def test_get_collector_names():
    # test function get_collector_names():
    # get_collector_names(valid_subsets=None,
    #                     minimal_gather_subset=None,
    #                     gather_subset=None,
    #                     aliases_map=None,
    #                     platform_info=None):

    # test all=True
    subset_name_set = get_collector_names(gather_subset=['all'])
    assert subset_name_set == {'default', 'virtual'}

    # test minimal
    subset_name_set = get_collector_names(gather_subset=['min'])
    assert subset_name_set == {'default'}

    # test exclude subset
    subset_name_set = get_collector_names(gather_subset=['!virtual'])


# Generated at 2022-06-11 02:21:49.072612
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=('all', ),
                               minimal_gather_subset=('min', ),
                               valid_subsets=('all', 'min')) == set(('min', 'all'))

    assert get_collector_names(gather_subset=('min', ),
                               minimal_gather_subset=('min', ),
                               valid_subsets=('all', 'min')) == set(('min', ))

    assert get_collector_names(gather_subset=('!all', ),
                               minimal_gather_subset=('min', ),
                               valid_subsets=('all', 'min')) == set(('min', ))

