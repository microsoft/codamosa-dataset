

# Generated at 2022-06-11 02:11:58.133863
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Assume that all collectors can be imported
    assert(find_unresolved_requires(['all']) == set())

    # Check that 'all' is not resolved
    assert(find_unresolved_requires(['all'], ['all']) == set(['all']))

    # Check that a missing collector raises an error
    try:
        find_unresolved_requires(['missing_collector'])
        assert(False)
    except CollectorNotFoundError:
        assert(True)

    # Check that a collector with no requirest is returned
    assert(find_unresolved_requires(['all', 'missing_collector']) == set(['missing_collector']))

# Generated at 2022-06-11 02:12:06.528824
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector # noqa
    from ansible.module_utils.facts.collector.aix import AixDefault # noqa
    from ansible.module_utils.facts.collector.bsd import BSDHardware # noqa
    from ansible.module_utils.facts.collector.bsd import BSDNetwork # noqa
    from ansible.module_utils.facts.collector.bsd import BSDVirtual # noqa
    from ansible.module_utils.facts.collector.bsd import GenericBSD # noqa
    from ansible.module_utils.facts.collector.linux import LinuxDistribution # noqa
    from ansible.module_utils.facts.collector.linux import LinuxHardware # noqa
    from ansible.module_utils.facts.collector.linux import LinuxNetwork #

# Generated at 2022-06-11 02:12:14.474325
# Unit test for function tsort
def test_tsort():
    test_cases = [
        ({'a': set(), 'b': set(), 'c': set()}, [('a', set()), ('b', set()), ('c', set())]),
        ({'a': set(['b']), 'b': set(['c']), 'c': set()}, [('c', set()), ('b', set(['c'])), ('a', set(['b']))]),
        ({'a': set(['b']), 'b': set(['a']), 'c': set()}, CycleFoundInFactDeps),
        ({'a': set(['b']), 'b': set(['c']), 'c': set(['a']), 'd': set(['e'])}, CycleFoundInFactDeps),
    ]


# Generated at 2022-06-11 02:12:22.908359
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collectors = [
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
    ]
    collectors[0].name = 'first_collector'
    collectors[1].name = 'second_collector'
    collectors[2].name = 'third_collector'
    collectors[3].name = 'fourth_collector'
    collectors[4].name = 'fifth_collector'

    # This is an example of the all_fact_subsets object.
    # It is a dictionary of collector_name: [ list of Fact Collector Classes ]
    all_fact_subsets = {}
    for collector in collectors:
        all_fact_subsets[collector.name] = [collector]

    # Test to ensure that duplicates are removed
    collector_

# Generated at 2022-06-11 02:12:33.914405
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts import tsort
    unsorted_map = {'a': {'c'},
                    'b': {'c'},
                    'c': {'d'},
                    'd': {'e'},
                    'e': set()}
    sorted_list = tsort(unsorted_map)
    assert sorted_list == [
        ('e', set()),
        ('d', {'e'}),
        ('c', {'d'}),
        ('a', {'c'}),
        ('b', {'c'})
    ], sorted_list

    # If a node has no edges, it goes first
    unsorted_map = {'a': {},
                    'b': {}}
    sorted_list = tsort(unsorted_map)
    assert sorted_list

# Generated at 2022-06-11 02:12:44.949721
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts.runner import TESTS_DIR
    import os

    test_data_dir = os.path.join(TESTS_DIR, 'collector_test_data')
    dep_map_file = os.path.join(test_data_dir, 'dep_map.yaml')
    dep_map = tsort(read_yaml_file(dep_map_file))

    expected_sorted_list_file = os.path.join(test_data_dir, 'expected_sorted_list.yaml')
    expected_sorted_list = read_yaml_file(expected_sorted_list_file)

    assert dep_map == expected_sorted_list


# Generated at 2022-06-11 02:12:56.600439
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # this is a silly example to create a collector with a require
    class MyCollector(object):
        name = 'mycollector'
        required_facts = ('required',)

    all_fact_subsets = {'mycollector': [MyCollector],
                        'required': [MyCollector]}

    # missing sublist to verify collector_names is modified
    assert find_unresolved_requires(set(), all_fact_subsets) == set()

    # missing element to verify required is checked
    assert find_unresolved_requires(set(['mycollector']), all_fact_subsets) == set(['required'])

    # empty required to verify required is checked
    MyCollector.required_facts = ()
    assert find_unresolved_requires(set(['required']), all_fact_subsets) == set()

# Generated at 2022-06-11 02:13:07.820784
# Unit test for function build_dep_data
def test_build_dep_data():
    from . import LinuxFactCollector
    from . import NetworkFactCollector
    from . import SystemdFactCollector
    from . import DNFRepoFactCollector
    from . import DNFModuleFactCollector
    from . import DNFModuleProfileFactCollector
    from . import DNFModuleStreamFactCollector

    all_fact_subsets = {'systemd': [SystemdFactCollector],
                        'network': [NetworkFactCollector],
                        'system_info': [LinuxFactCollector],
                        'pkg_mgr': [DNFRepoFactCollector],
                        'module_mgr': [DNFModuleFactCollector],
                        'module_profile': [DNFModuleProfileFactCollector],
                        'module_stream': [DNFModuleStreamFactCollector]}

# Generated at 2022-06-11 02:13:17.332648
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_classes = []
    collector_classes.append(FakeFactCollector(name='blah', _fact_ids=set(['a', 'b'])))
    collector_classes.append(FakeFactCollector(name='blah', _fact_ids=set(['a', 'c'])))
    collector_classes.append(FakeFactCollector(name='blah', _fact_ids=set(['b', 'c'])))
    collector_classes.append(FakeFactCollector(name='blah', _fact_ids=set(['a', 'b', 'c'])))

    all_fact_subsets = FactSubsetMatcher.build_fact_id_to_collector_map(collector_classes)

    selected_collector_classes = select_collector_classes(['blah'], all_fact_subsets)


# Generated at 2022-06-11 02:13:28.922078
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class BaseCollector:
        name = 'base'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {self.name: True}

    class DeerCollector(BaseCollector):
        name = 'deer'

    class BearCollector(BaseCollector):
        name = 'bear'
        required_facts = set(['deer'])

    class RacoonCollector(BaseCollector):
        name = 'racoon'
        required_facts = set(['deer'])

    class SquirrelCollector(BaseCollector):
        name = 'squirrel'
        required_facts = set(['bear', 'racoon'])


# Generated at 2022-06-11 02:13:51.727110
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import generic, network
    all_fact_subsets = {
        generic.GenericFactCollector.name: [generic.GenericFactCollector],
        network.NetworkFactCollector.name: [network.NetworkFactCollector],
    }

    unresolved = find_unresolved_requires(collector_names=['facts'], all_fact_subsets=all_fact_subsets)
    assert sorted(unresolved) == sorted(set(['facts', 'local']))

    # FIXME: make this test pass by changing GenericFactCollector so it
    #        doesn't rely on network facts.
    #
    # unresolved = find_unresolved_requires(collector_names=['local'], all_fact_subsets=all_fact_subsets)
    # assert list(un

# Generated at 2022-06-11 02:14:03.807367
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from collections import defaultdict
    all_fact_subsets = defaultdict(list)

    class C1(BaseFactCollector):
        name = 'C1'
        required_facts = ['C2']
    class C2(BaseFactCollector):
        name = 'C2'
        required_facts = ['C3']
    class C3(BaseFactCollector):
        name = 'C3'
        required_facts = []

    all_fact_subsets['C1'].append(C1)
    all_fact_subsets['C2'].append(C2)
    all_fact_subsets['C3'].append(C3)

    assert find_unresolved_requires(['C1'], all_fact_subsets) == {'C2', 'C3'}
    assert find_unres

# Generated at 2022-06-11 02:14:12.796444
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test valid subset and minimal subset
    valid_subsets = frozenset(['network', 'software'])
    minimal_subsets = frozenset(['network'])

    # Test valid subset provided with minimal subset empty, gather_subset empty
    result_subsets = get_collector_names(valid_subsets=valid_subsets,
                                         minimal_gather_subset=frozenset())
    assert result_subsets == valid_subsets, result_subsets

    # Test valid subset provided with minimal subset non-empty, gather_subset non-empty
    result_subsets = get_collector_names(valid_subsets=valid_subsets,
                                         minimal_gather_subset=minimal_subsets,
                                         gather_subset=['network', 'software'])
    assert result_subsets

# Generated at 2022-06-11 02:14:23.021512
# Unit test for function get_collector_names
def test_get_collector_names():
    all_subset = frozenset(['facter', 'ohai'])
    minimal_subset = frozenset()

    gs_none = None
    gs_all = ['all']
    gs_min = ['min']
    gs_facter = ['!facter']
    gs_ohai = ['!ohai']
    gs_both = ['!facter', '!ohai']
    gs_all_min = ['all', 'min']
    gs_all_facter = ['all', '!facter']
    gs_all_ohai = ['all', '!ohai']
    gs_all_both = ['all', '!facter', '!ohai']
    gs_min_facter = ['min', '!facter']
    gs_min_

# Generated at 2022-06-11 02:14:31.935605
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test verifying that given no args, we get back 'all'
    assert 'all' in get_collector_names()
    # Test verifying that 'min' is always added after all the negations
    assert 'min' in get_collector_names(minimal_gather_subset=['min'], gather_subset=['!all'])
    # Test verifying that 'min' is not added if we have 'all' in the gather_subset
    assert 'min' not in get_collector_names(minimal_gather_subset=['min'], gather_subset=['all'])
    # Test verifying the handling of extra gather_subsets
    assert 'extra' in get_collector_names(valid_subsets=frozenset([]), gather_subset=['extra'])
    # Test verifying the handling

# Generated at 2022-06-11 02:14:43.327457
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class Collect1(BaseFactCollector):
        _fact_ids = set(['c1a', 'c1b'])
        name = 'c1'

    class Collect2(BaseFactCollector):
        _fact_ids = set(['c2a', 'c2b'])
        name = 'c2'

    collectors = [Collect1, Collect2]
    known_collector_names = frozenset([c.name for c in collectors])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    assert known_collector_names == set(fact_id_to_collector_map.keys())
    aliases_map_expected = defaultdict(set)

# Generated at 2022-06-11 02:14:50.908706
# Unit test for function build_dep_data
def test_build_dep_data():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'a', 'b'}

    class Test2Collector(BaseFactCollector):
        name = 'test2'
        required_facts = {'a', 'c'}

    all_fact_subsets = {'test': {TestCollector}, 'test2': {Test2Collector}}
    collector_names = ('test', 'test2')

    assert build_dep_data(collector_names, all_fact_subsets) == {
        'test': {'a', 'b'},
        'test2': {'a', 'c'}
    }



# Generated at 2022-06-11 02:15:03.852317
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class MockSubset1(BaseFactCollector):
        name = 'subset1'
        _fact_ids = set(['id1_for_subset1', 'id2_for_subset1'])

    class MockSubset2(BaseFactCollector):
        name = 'subset2'
        _fact_ids = set(['id1_for_subset2', 'id2_for_subset2'])

    class MockSubset3(BaseFactCollector):
        name = 'subset3'
        _fact_ids = set(['id1_for_subset3', 'id2_for_subset3'])


# Generated at 2022-06-11 02:15:09.188628
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['pluginshal'] = ['pluginshal']
    all_fact_subsets['pluginshaldeps'] = ['pluginshaldeps']
    all_fact_subsets['pluginsh'] = ['pluginsh']
    collector_names = ['pluginshal', 'pluginshaldeps']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == ('pluginsh', )



# Generated at 2022-06-11 02:15:18.906937
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'collector_a': [MockCollector('collector_a', requires=['collector_b'])],
                        'collector_b': [MockCollector('collector_b')]}

    unresolved = find_unresolved_requires(['collector_a', 'collector_b'], all_fact_subsets)
    assert not unresolved
    unresolved = find_unresolved_requires(['collector_a'], all_fact_subsets)
    assert unresolved == set(['collector_b'])
    unresolved = find_unresolved_requires(['collector_b'], all_fact_subsets)
    assert not unresolved



# Generated at 2022-06-11 02:15:37.988382
# Unit test for function get_collector_names
def test_get_collector_names():
    # given
    valid_subsets = frozenset(
        [
            'hardware',
            'network',
            'virtual',
            'defaults',
            'identity',
            'integration',
            'power',
            'security',
            'storage',
            'package',
            'cloud',
            'ansible_kernel',
            'ansible_system',
            'ansible_pkg_mgr',
            'all',
        ]
    )

    minimal_gather_subset = frozenset(
        [
            'ansible_kernel',
            'ansible_system',
            'ansible_pkg_mgr',
        ]
    )
    aliases_map = defaultdict(set)

    # when

# Generated at 2022-06-11 02:15:51.680769
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # pylint: disable=unused-variable,too-few-public-methods

    class FooCollector(BaseFactCollector):
        _fact_ids = frozenset(['foo'])
        required_facts = frozenset(['bar'])

    class BarCollector(BaseFactCollector):
        _fact_ids = frozenset(['bar'])
        required_facts = frozenset()

    all_fact_subsets = {
        'foo': [FooCollector, ],
        'bar': [BarCollector, ]
    }

    collector_names = ['foo']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['bar'])

    collector_names = ['bar']
    unresolved = find_unresolved_requires

# Generated at 2022-06-11 02:15:59.134789
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collectors as collectors
    collectors_for_platform = [collectors.SystemInfo, collectors.Hardware, collectors.Virtual]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert 'system_vendor' in fact_id_to_collector_map
    assert 'system' in fact_id_to_collector_map
    assert 'product_name' in fact_id_to_collector_map
    assert 'system_serialnumber' in fact_id_to_collector_map
    assert 'hardware' in aliases_map
    assert 'system_info' in aliases_map
    assert 'virtual' in aliases_map



# Generated at 2022-06-11 02:16:07.535176
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    inputs = (
        ({'collector_A'}, {'collector_A': set(['required_fact_A'])}),
        ({'collector_A', 'collector_B'}, {'collector_A': set(['collector_B']), 'collector_B': set()}),
        ({'collector_A', 'collector_B'}, {'collector_A': set(['collector_B', 'collector_C']), 'collector_B': set()}),
    )
    outputs = (
        {'required_fact_A'},
        {'collector_B'},
        {'collector_C'},
    )

# Generated at 2022-06-11 02:16:18.242147
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.community.general.plugins.modules.system import dnf
    class DNFModule(dnf.DNFModule):
        NAME = 'dnf'
        required_facts = frozenset(['command_not_found_issues'])
        @classmethod
        def platform_match(cls, platform_info):
            return cls
    import ansible.module_utils.facts.collector.default
    class AnsibleDefaultFactCollector(ansible.module_utils.facts.collector.default.FactCollector):
        NAME = 'default'
        _fact_ids = {'command_not_found_issues'}
        @classmethod
        def platform_match(cls, platform_info):
            return cls

# Generated at 2022-06-11 02:16:29.391774
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'factoid_a': [FactCollector1],
        'factoid_b': [FactCollector2],
    }

    assert find_unresolved_requires(['factoid_a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['factoid_b'], all_fact_subsets) == {'factoid_a'}
    assert find_unresolved_requires(['factoid_a', 'factoid_b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['factoid_b', 'factoid_a'], all_fact_subsets) == set()

# Generated at 2022-06-11 02:16:39.583063
# Unit test for function get_collector_names
def test_get_collector_names():
    class FakeCollector(BaseFactCollector):
        name = 'fake'

    class FakeCollector2(BaseFactCollector):
        name = 'fake2'

    valid_subsets = frozenset(('all', 'network', 'virtual', 'hardware'))
    minimal_gather_subset = frozenset(('fake', 'fake2'))
    aliases_map = defaultdict(set, {'hardware': frozenset(('devices', 'dmi'))})

    collector_names = frozenset((FakeCollector.name, FakeCollector2.name))

    # gather_subset_with_min = ['min']
    # gather_subset_with_min.extend(gather_subset)


# Generated at 2022-06-11 02:16:50.922138
# Unit test for function get_collector_names
def test_get_collector_names():

    def _test(expected, gather_subset, valid_subsets=None, minimal_gather_subset=None, aliases=None):
        actual = get_collector_names(valid_subsets=valid_subsets,
                                     minimal_gather_subset=minimal_gather_subset,
                                     gather_subset=gather_subset,
                                     aliases_map=aliases)
        assert actual == expected, \
            'gather_subset=%s, valid_subsets=%s, minimal_gather_subset=%s, aliases=%s: expected %s' \
            ', got %s' % (gather_subset, valid_subsets, minimal_gather_subset, aliases, expected, actual)

    _test(frozenset(), [])


# Generated at 2022-06-11 02:17:02.255221
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.collector import NetworkCollector
    from ansible.module_utils.facts.hardware import hardware
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.facts import Facts

    # pylint: disable=protected-access
    collector_classes_by_name = {}
    collector_classes_by_name[NetworkCollector.name] = [NetworkCollector]
    collector_classes_by_name[hardware.name] = [hardware]
    collector_classes_by_name[Facts.name] = [Facts]

    assert find_unresolved_requires(['all'], collector_classes_by_name) == set()

    assert find_unresolved_requires

# Generated at 2022-06-11 02:17:10.280658
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Dummy class for testing
    class DummyCollector:
        name = 'dummy'
        required_facts = {'another', 'single'}

    # Create a set of collector names, with a dummy class and the following requires:
    # another --> single --> dummy
    collector_names = {'dummy', 'another', 'single', 'other'}
    all_fact_subsets = {'dummy': [DummyCollector()]}
    all_fact_subsets['another'] = [DummyCollector()]
    all_fact_subsets['another'][0].required_facts = {'single'}
    all_fact_subsets['single'] = [DummyCollector()]
    all_fact_subsets['single'][0].required_facts = {'dummy'}
    all_fact_subsets

# Generated at 2022-06-11 02:17:55.073469
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts import defaultdict

    collectors = set()
    collector_classes = [
        ('foo', ('bar', 'bam')),
        ('bar', ('baz',)),
        ('baz', ('bam',)),
        ('bam', ('bar',)),
    ]

    for collector_name, required_facts in collector_classes:
        collector_class = type(collector_name,
                               (BaseFactCollector,),
                               {'name': collector_name,
                                'required_facts': set(required_facts),
                                })
        collectors.add(collector_class)

    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-11 02:18:03.362606
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class DummyCollectorA(BaseFactCollector):
        name = 'collectorA'
        required_facts = frozenset({'collectorB'})

    class DummyCollectorB(BaseFactCollector):
        name = 'collectorB'
        required_facts = set()

    all_fact_subsets = {'collectorA': [DummyCollectorA],
                        'collectorB': [DummyCollectorB]}
    assert set(['collectorB']) == find_unresolved_requires(['collectorA'], all_fact_subsets)
    assert set() == find_unresolved_requires(['collectorA', 'collectorB'], all_fact_subsets)



# Generated at 2022-06-11 02:18:11.223979
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = collectors.get_collectors_for_test()
    all_collector_names = all_fact_subsets.keys()

    # no unresolved
    collector_names = ['min', 'all', 'network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one unresolved
    collector_names = ['min', 'all', 'network', 'pkg_mgr']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'pkg_mgr'}

    # one and all unresolved

# Generated at 2022-06-11 02:18:23.385517
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Foo(BaseFactCollector):
        _fact_ids = set(['foo'])

    class Bar(BaseFactCollector):
        _fact_ids = set()

    class Qux(BaseFactCollector):
        _fact_ids = set(['qux'])

    X = Foo.platform_match('x')
    Y = Bar.platform_match('x')
    Z = Qux.platform_match('x')
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(set([X, Y, Z]))
    assert fact_id_to_collector_map['foo'] == [X]
    assert fact_id_to_collector_map['qux'] == [Z]
    assert 'bar' not in fact_id_to_collector

# Generated at 2022-06-11 02:18:31.845034
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # create a mock for the all_fact_subsets
    fact_subsets = defaultdict(list)
    fact_subsets['a'].append(FakeCollector('a', set(['b'])))
    fact_subsets['b'].append(FakeCollector('b', set(['c'])))
    fact_subsets['c'].append(FakeCollector('c', set(['d'])))
    fact_subsets['d'].append(FakeCollector('d', set(['e'])))
    fact_subsets['e'].append(FakeCollector('e', set()))
    unresolved = find_unresolved_requires(set(['a']), fact_subsets)
    assert(unresolved == set(['e']))



# Generated at 2022-06-11 02:18:42.450793
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # this is fake data, but it doesn't have to be, since we're testing
    # the logic of the code, not the data
    all_fact_subsets = {}
    for i in range(3):
        all_fact_subsets['subset_%d' % i] = []
        for j in range(2):
            new_class = type('Subset_%d_%d' % (i, j), (object,), {'required_facts': set(), 'name': 'subset_%d' % i})
            all_fact_subsets['subset_%d' % i].append(new_class)

    # an empty list should raise KeyError

# Generated at 2022-06-11 02:18:53.495017
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collect(BaseFactCollector):
        name = 'collect'
        _fact_ids = {'foo', 'bar', 'baz'}
        def collect(self):
            pass
    class OtherCollect(BaseFactCollector):
        name = 'other'
        _fact_ids = {'baz'}
        def collect(self):
            pass
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        [Collect, OtherCollect])
    assert fact_id_to_collector_map == {'baz': [Collect, OtherCollect], 'foo': [Collect], 'bar': [Collect], 'collect': [Collect], 'other': [OtherCollect]}

# Generated at 2022-06-11 02:19:06.467896
# Unit test for function select_collector_classes
def test_select_collector_classes():
    test_collector_one_class = type('test_collector_one_class', (BaseFactCollector,), {
        'name': 'test_collector_one',
        'required_facts': set(['test_collector_one']),
        '_fact_ids': set(['test_collector_one'])
    })
    test_collector_two_class = type('test_collector_two_class', (BaseFactCollector,), {
        'name': 'test_collector_two',
        'required_facts': set(['test_collector_two']),
        '_fact_ids': set(['test_collector_two'])
    })

# Generated at 2022-06-11 02:19:18.257381
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit test for function find_unresolved_requires'''
    invalid_collector_names = ['arch', 'ipv4', 'ipv6']
    all_fact_subsets = {'virtual': [BaseFactCollector], 'network': [BaseFactCollector]}
    assert find_unresolved_requires(invalid_collector_names, all_fact_subsets) == set(['arch', 'ipv4', 'ipv6'])

    valid_collector_names = ['arch', 'ipv4', 'network']
    all_fact_subsets = {'arch': [BaseFactCollector], 'ipv4': [BaseFactCollector], 'network': [BaseFactCollector]}
    assert find_unresolved_requires(valid_collector_names, all_fact_subsets) == set()



# Generated at 2022-06-11 02:19:25.630572
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyCollector(BaseFactCollector):
        name = 'my_collector'
        _fact_ids = ['foo', 'bar']

    class OtherCollector(BaseFactCollector):
        name = 'other_collector'
        _fact_ids = ['baz']

    collectors = [MyCollector, OtherCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    # both my_collector and OtherCollector should be found for 'baz'
    assert fact_id_to_collector_map['baz'] == [MyCollector, OtherCollector]

    # my_collector should be found for 'foo' and 'bar'

# Generated at 2022-06-11 02:20:25.111588
# Unit test for function build_dep_data
def test_build_dep_data():
    # For example,
    # collector_names: ['A', 'B', 'C', 'D', 'E']
    # collector_classes:
    # [('A', [(['B']), ['C']]),
    #  ('B', [(['C']), ['D']]),
    #  ('C', [['D'],['E']]),
    #  ('D', [['E']]),
    #  ('E', [])]

    collector_classes = []
    collector_names = ['A', 'B', 'C', 'D', 'E']
    all_fact_subsets = {}

    collector_a = BaseFactCollector()
    collector_a.name = 'A'
    collector_a.required_facts = set(['B', 'C'])

# Generated at 2022-06-11 02:20:37.194300
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = set(('first', 'second', 'third'))
    all_fact_subsets = {
        'first': [FakeCollector('first', requires=set(['second']))],
        'second': [
            FakeCollector('second', requires=set(['first'])),
            FakeCollector('second', requires=set(['third'])),
        ],
        'third': [FakeCollector('third', requires=set([]))],
    }
    expected = {
        'first': set(['second']),
        'second': set(['first', 'third']),
        'third': set([]),
    }

    dep_data = build_dep_data(collector_names, all_fact_subsets)
    assert dep_data == expected



# Generated at 2022-06-11 02:20:45.674909
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all', 'min']) == {'min'}
    assert get_collector_names(['all', 'min'], ['min']) == {'min'}
    assert get_collector_names(['all', 'min'], ['min'], ['min']) == {'min'}
    assert get_collector_names(['all', 'min'], ['min'], ['all']) == set()
    assert get_collector_names(['all', 'min', 'hardware'], ['min'], ['all']) == {'hardware'}
    assert get_collector_names(['all', 'min', 'hardware'], ['min'], ['hardware']) == {'hardware'}

# Generated at 2022-06-11 02:20:50.709567
# Unit test for function build_dep_data
def test_build_dep_data():
    deps = {'a': [], 'b': ['a'], 'c': ['a', 'b']}
    actual = build_dep_data(deps.keys(), deps)
    expected = {'a': set(), 'b': set(['a']), 'c': set(['a', 'b'])}
    assert(actual == expected)



# Generated at 2022-06-11 02:21:00.856813
# Unit test for function get_collector_names
def test_get_collector_names():
    extra_valid = frozenset(['valid1', 'valid2', 'valid3'])
    extra_minimal = frozenset(['minimal1', 'minimal2', 'minimal3'])
    aliases_map = defaultdict(set, dict(hardware=frozenset(['devices', 'dmi'])))
    platform_info = dict()

    # base case, with all
    assert get_collector_names(valid_subsets=extra_valid,
                               minimal_gather_subset=extra_minimal,
                               gather_subset=['all'],
                               aliases_map=aliases_map,
                               platform_info=platform_info) == extra_valid | extra_minimal
    # minimal, should just get the minimal gather_subset

# Generated at 2022-06-11 02:21:10.229758
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Make test class
    class TestCollector(BaseFactCollector):
        _fact_ids = {'fact_id'}
        name = 'name'
    collector_set = { TestCollector() }
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_set)
    assert 'fact_id' in fact_id_to_collector_map
    assert 'name' in fact_id_to_collector_map
    assert 'fact_id' in aliases_map['name']


# Generated at 2022-06-11 02:21:16.986211
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorOne(BaseFactCollector):
        name = 'CollectorOne'

    class CollectorTwo(BaseFactCollector):
        name = 'CollectorTwo'

    class CollectorThree(BaseFactCollector):
        name = 'CollectorThree'

    CollectorTwo._fact_ids = set(['alias1'])
    CollectorThree._fact_ids = set(['alias2', 'alias3'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map((CollectorOne, CollectorTwo, CollectorThree))

    assert set(fact_id_to_collector_map['CollectorOne']) == set((CollectorOne,))
    assert set(fact_id_to_collector_map['alias1']) == set((CollectorTwo,))

# Generated at 2022-06-11 02:21:27.353522
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector1(BaseFactCollector):
        _fact_ids = ['test_fact_id_1']
        name = 'test_collector_1'

    class TestFactCollector2(BaseFactCollector):
        _fact_ids = ['test_fact_id_2', 'test_fact_id_3']
        name = 'test_collector_2'

    class TestFactCollector3(BaseFactCollector):
        _fact_ids = ['test_fact_id_1', 'test_fact_id_2']
        name = 'test_collector_3'

    collectors_for_platform = [TestFactCollector1, TestFactCollector2, TestFactCollector3]
    aliases_map = defaultdict(set)

    fact_id_to_collector_map, aliases_map = build

# Generated at 2022-06-11 02:21:38.377192
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class MockClass(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

    all_fact_subsets = {}
    collector_names = set()

    # create mock classes
    MockClass1 = type('MockClass1', (MockClass,), {'name': 'MockClass1', 'required_facts': set(['MockClass2'])})
    MockClass2 = type('MockClass2', (MockClass,), {'name': 'MockClass2', 'required_facts': set()})
    MockClass3 = type('MockClass3', (MockClass,), {'name': 'MockClass3', 'required_facts': set(['MockClass1'])})

    # add mock classes to all fact subs