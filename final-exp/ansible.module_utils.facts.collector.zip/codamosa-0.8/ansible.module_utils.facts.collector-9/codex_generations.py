

# Generated at 2022-06-11 02:12:03.329427
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
  collectors = {'a': 1, 'b': 3, 'c': 3, 'd': 2}
  assert find_unresolved_requires(['a'], collectors) == set()
  assert find_unresolved_requires(['a', 'b'], collectors) == set()
  assert find_unresolved_requires(['c'], collectors) == set()
  assert find_unresolved_requires(['d'], collectors) == {'a'}


# Generated at 2022-06-11 02:12:08.841351
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        name = 'collector2'
    class Collector3(BaseFactCollector):
        name = 'collector3'
    class Collector4(BaseFactCollector):
        name = 'collector4'
    class Collector5(BaseFactCollector):
        name = 'collector5'

    collector_names = ['collector1', 'collector2', 'collector3', 'collector4', 'collector5']
    collector_classes = [Collector1, Collector2, Collector3, Collector4, Collector5]
    all_fact_subsets = {}
    for collector_name, collector_class in zip(collector_names, collector_classes):
        all_fact_subsets[collector_name]

# Generated at 2022-06-11 02:12:19.285391
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import sys
    import types

    class FakeCollector(BaseFactCollector):
        _fact_ids = set()
        name = 'fake'
        _platform = 'FakeOS'

    def make_fake_collector_class(name, platforms=None):
        sys_platform_names = tuple(platforms or ['Linux', 'Darwin', 'FreeBSD', 'OpenBSD', 'NetBSD'])
        sys_platform_names += (None, )

        for sys_platform_name in sys_platform_names:

            _platform = sys_platform_name or 'Generic'

            class_name = 'FakeCollector_%s_%s' % (name, _platform)

            class FakeCollectorClass(FakeCollector):
                name = class_name
                _platform = _platform

            FakeCollectorClass.__name__ = class_

# Generated at 2022-06-11 02:12:31.191978
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = {'a', 'b', 'c'}
    all_fact_subsets = {
        'a': {
            FakeCollectorClass({'a', 'z'}),
            FakeCollectorClass({'a', 'x', 'y'}),
        },
        'b': {
            FakeCollectorClass({'b', 'z'}),
        },
        'c': {
            FakeCollectorClass({'c', 'z'}),
        },
    }
    expected = {
        'a': {'z'},
        'b': {'z'},
        'c': {'z'},
    }
    assert build_dep_data(collector_names, all_fact_subsets) == expected


# Cycle detection from https://stackoverflow.com/a/146927

# Generated at 2022-06-11 02:12:42.379419
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_all_fact_subsets = {
        'collector-a': [(True, object())],
        'collector-b': [(True, object())],
        'collector-c': [(True, object())],
        'collector-d': [(True, object())],
    }

    collectors_a = test_all_fact_subsets['collector-a']
    collectors_b = test_all_fact_subsets['collector-b']
    collectors_c = test_all_fact_subsets['collector-c']
    collectors_d = test_all_fact_subsets['collector-d']

    collectors_a[0][1].required_facts = set(['collector-b', 'collector-c'])

# Generated at 2022-06-11 02:12:50.109042
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector

    platform_info = {'system': 'Linux', 'distribution': 'debian'}
    rv = find_collectors_for_platform(collector.fact_collector_classes, [platform_info])
    assert len(rv) == 1
    assert rv.pop().name == 'DebianLinux'

    platform_info['system'] = 'FreeBSD'
    rv = find_collectors_for_platform(collector.fact_collector_classes, [platform_info])
    assert len(rv) == 1
    assert rv.pop().name == 'FreeBSD'

    # no linux collectors should be returned if the platform is not linux
    platform_info['system'] = 'NotLinux'

# Generated at 2022-06-11 02:12:59.750465
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        name = "a"
        _fact_ids = ["foo"]
    class B(BaseFactCollector):
        name = "b"
        _fact_ids = ["bar", "foo", "wiz"]
    class C(BaseFactCollector):
        name = "c"
        _fact_ids = ["wiz"]
    class D(BaseFactCollector):
        name = "d"
        _fact_ids = ["wiz", "warg"]
    fact_id_to_collector_map, _ = build_fact_id_to_collector_map([A, B, C, D])
    assert fact_id_to_collector_map["b"] == [B]
    assert fact_id_to_collector_map["bar"] == [B]

# Generated at 2022-06-11 02:13:06.842211
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=['one', 'two', 'three'],
                               minimal_gather_subset=['one'],
                               gather_subset=['two'],
                               aliases_map=dict(hardware=['devices', 'dmi']),
                               platform_info=None) ==  {'one', 'two'}

    # test cases for hardware
    assert get_collector_names(valid_subsets=['one', 'two', 'three'],
                               minimal_gather_subset=['one'],
                               gather_subset=['!hardware'],
                               aliases_map=dict(hardware=['devices', 'dmi']),
                               platform_info=None) == {'one', 'three'}


# Generated at 2022-06-11 02:13:16.430322
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.netcommon.plugins.module_utils.compat.ipaddress import ipaddress

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.factories.base import BaseFactory
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.collector.base import BaseFactCollector
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set()
    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector1'])
    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set(['collector4'])

# Generated at 2022-06-11 02:13:28.061818
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors
    all_collector_classes = (
        collectors.Network,
        collectors.Linux,
        collectors.FreeBSD,
        collectors.Darwin,
        collectors.SunOS,
    )
    # test find unique platform
    compat_platforms = (dict(system='Linux'), dict(system='Solaris'))
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert found_collectors == set([collectors.Linux, collectors.SunOS])
    # test find multiple platforms
    compat_platforms = (dict(system='FreeBSD'), dict(system='Darwin'))
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert found_collect

# Generated at 2022-06-11 02:13:48.129059
# Unit test for function select_collector_classes

# Generated at 2022-06-11 02:13:56.236598
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Mock classes
    class MockCollectorClass1:
        _platform = 'Generic'
        name = 'mock1'
        @classmethod
        def platform_match(cls, platform_info):
            if 'system' in platform_info.keys():
                return cls
            return None
    class MockCollectorClass2:
        _platform = 'Linux'
        name = 'mock'
        @classmethod
        def platform_match(cls, platform_info):
            if 'system' in platform_info.keys():
                return cls
            return None
    class MockCollectorClass3:
        _platform = 'Bogus'
        name = 'mock3'

# Generated at 2022-06-11 02:14:08.143016
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import collections
    import unittest
    import ansible.module_utils.facts.collectors.generic

    class DummyCollector(BaseFactCollector):
        name = 'dummy'
        _fact_ids = set(['dummy'])

    class DummyCollector2(BaseFactCollector):
        name = 'dummy2'
        _fact_ids = set(['dummy2', 'dummy'])

    class TestBuildFactIdToCollectorMap(unittest.TestCase):

        def test_build_fact_id_to_collector_map(self):
            collector_classes = [DummyCollector, DummyCollector2]
            result, aliases_map = build_fact_id_to_collector_map(collector_classes)
            expected_result = collections.defaultdict(list)


# Generated at 2022-06-11 02:14:18.761703
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    all_collector_classes = [C1, C2, C3]
    compat_platforms = [{'system': 'Linux'}, {'system': 'RedHat'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 2
    assert C1 in found_collectors
    assert C3 in found_collectors

    compat_platforms = [{'system': 'Linux'}, {'system': 'RedHat'}, {'system': 'Bogus'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 2
    assert C1 in found_collectors
    assert C

# Generated at 2022-06-11 02:14:28.848524
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import sys
    import inspect
    import ansible.module_utils.facts.collector.base
    all_collector_classes = []
    for mod_name, mod_obj in inspect.getmembers(ansible.module_utils.facts.collector.base, inspect.isclass):
        all_collector_classes.append(mod_obj)
    compat_platforms = [{'system': 'Linux'}, {'system': 'FreeBSD'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    # For any platform it is expected that Linux and BSD collectors are returned
    linux_count = 0
    bsd_count = 0

# Generated at 2022-06-11 02:14:38.527602
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from collections import defaultdict
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['fact1'].append(object)
    all_fact_subsets['fact2'].append(object)
    all_fact_subsets['fact2'].append(object)
    all_fact_subsets['fact3'].append(object)

    # basic test. selects only the ones in collector_names:
    collector_names = ['fact2', 'fact3']
    collectors = select_collector_classes(collector_names, all_fact_subsets)
    assert len(collectors) == 2
    assert object in collectors

    # test that it doesn't select a fact name more than once:
    collector_names = ['fact2', 'fact2', 'fact3']
    collectors = select_collector_

# Generated at 2022-06-11 02:14:47.542116
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('a', 'b', 'c', 'd', 'e'))
    minimal_gather_subset = frozenset(('a', 'b'))

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=['all'],
                               aliases_map=defaultdict(set),
                               platform_info=None) == set(['a', 'b', 'c', 'd', 'e'])


# Generated at 2022-06-11 02:15:00.119153
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector-a': [
            object(),
            object(),
        ],
        'collector-b': [
            object(),
        ],
    }
    all_fact_subsets['collector-a'][0].required_facts = set()
    all_fact_subsets['collector-a'][1].required_facts = set()
    all_fact_subsets['collector-b'][0].required_facts = set(['collector-a'])

    assert set(['collector-b']) == find_unresolved_requires(['collector-a'], all_fact_subsets)


# Generated at 2022-06-11 02:15:06.932043
# Unit test for function select_collector_classes
def test_select_collector_classes():
    '''
    This function is a unit test for select_collector_classes.
    '''
    import os
    import sys
    import unittest
    CODE_DIR = os.path.dirname(os.path.abspath(__file__))
    PARENT_CODE_DIR = os.path.dirname(CODE_DIR)  # == ./lib/ansible/module_utils
    MODULE_UTILS_DIR = os.path.join(PARENT_CODE_DIR, 'module_utils')
    sys.path.append(MODULE_UTILS_DIR)
    from ansible.module_utils.facts import collectors
    import ansible.module_utils.facts.platforms.linux
    import ansible.module_utils.facts.platforms.darwin
    import ansible.module_utils.facts.platform

# Generated at 2022-06-11 02:15:18.037886
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collections import platform
    from ansible.module_utils.facts import collector

    all_fact_subsets = collector.fact_id_to_collector_map
    class_requires_map = {}
    for collector_name, collector_classes in all_fact_subsets.items():
        for collector_class in collector_classes:
            required_facts = collector_class.required_facts
            class_requires_map[collector_name] = required_facts
            if collector_class.name == collector_name:
                continue
            alias_required_facts = required_facts.copy()
            alias_required_facts.add(collector_class.name)
            class_requires_map[collector_name] = alias_required_facts


# Generated at 2022-06-11 02:15:34.366776
# Unit test for function get_collector_names
def test_get_collector_names():
    assert set(get_collector_names(gather_subset=['!all'],
                                   minimal_gather_subset=['min'],
                                   valid_subsets=['min', 'network', 'other'],
                                   aliases_map=_init_aliases_map())) == set(['min'])
    assert set(get_collector_names(gather_subset=['!network'],
                                   minimal_gather_subset=['min'],
                                   valid_subsets=['min', 'network', 'other'],
                                   aliases_map=_init_aliases_map())) == set(['min', 'other'])

# Generated at 2022-06-11 02:15:45.266669
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import all_collector_classes

    found_collectors = find_collectors_for_platform(all_collector_classes, [{'system': 'Linux'}])
    assert found_collectors

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(found_collectors)

    assert 'distribution' in fact_id_to_collector_map

    # and it has multiple aliases
    assert 'os_family' in fact_id_to_collector_map



# Generated at 2022-06-11 02:15:52.434251
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collectors import network
    all_fact_subsets = {'network': [network.NetworkCollector]}
    collector_names = ['network']
    dep_map = build_dep_data(collector_names=collector_names, all_fact_subsets=all_fact_subsets)
    assert 'network' in dep_map.keys()
    assert 'system' in dep_map['network']


# Generated at 2022-06-11 02:15:59.544270
# Unit test for function select_collector_classes
def test_select_collector_classes():
    fact_ids_to_collector_classes = {
        'a': [AnsibleCollector],
        'b': [AnsibleCollector, BOSECollector],
        'c': [AnsibleCollector, BOSECollector, CCollector],
    }

    test_cases = [
        ({'a'}, [AnsibleCollector]),
        ({'b', 'c'}, [AnsibleCollector, BOSECollector, CCollector]),
        ({'a', 'b', 'c'}, [AnsibleCollector, BOSECollector, CCollector]),
        ({'b', 'a', 'c'}, [AnsibleCollector, BOSECollector, CCollector]),
    ]
    for test_case in test_cases:
        assert select

# Generated at 2022-06-11 02:16:07.734265
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.facter import FacterCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    actual = build_fact_id_to_collector_map([FacterCollector, SystemCollector])


# Generated at 2022-06-11 02:16:18.364144
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestFactCollector(BaseFactCollector):
        name = 'test_collector'
        required_facts = ['test_required_fact']
    class TestCollectorWithRequires(BaseFactCollector):
        name = 'collector_with_requires'
        required_facts = ['unresolved_fact']
    class TestCollectorWithResolvedRequires(BaseFactCollector):
        name = 'collector_with_resolved_requires'
        required_facts = ['test_collector']

    all_fact_subsets = {
        'test_collector': [TestFactCollector],
        'collector_with_requires': [TestCollectorWithRequires],
        'collector_with_resolved_requires': [TestCollectorWithResolvedRequires]
    }

    collector_names = ['test_collector']

    assert find

# Generated at 2022-06-11 02:16:29.547585
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # This function returns a list of collector classes that match the args
    # Gather_subset is a spec describing which facts to gather.
    # valid_subsets is a frozenset of potential matches for gather_subset ('all', 'network') etc
    # minimal_gather_subsets is a frozenset of matches to always use, even for gather_subset='!all'
    # aliases_map maps the alias names like 'hardware' to the list of names that are part of hardware like 'devices' and 'dmi'

    # TODO: name collisions here? are there facts with the same name as a gather_subset (all, network, hardware, virtual, ohai, facter)
    all_fact_subsets, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    all_valid

# Generated at 2022-06-11 02:16:30.473349
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # TODO: write this test
    pass



# Generated at 2022-06-11 02:16:40.790190
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collectors

    class Collector1(BaseFactCollector):
        _fact_ids = set(['a', 'b', 'c'])
        name = 'name1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['c', 'd', 'e'])
        name = 'name2'

    class Collector3(BaseFactCollector):
        _fact_ids = set()
        name = 'name3'

    all_collector_classes = [collector.__class__ for collector in collectors.get_collectors()]
    all_collector_classes += [
        Collector1,
        Collector2,
        Collector3,
    ]

    # - put some aliases into
    # - put a collector into aliases that does not exists
    fact_id_to

# Generated at 2022-06-11 02:16:52.445613
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    """
    This test case tests build_fact_id_to_collector_map with a single fact collector
    """
    class FakeCollector(BaseFactCollector):
        _fact_ids = ('fact2')
        name = 'fact1'

    all_fact_collectors = [FakeCollector]

    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(all_fact_collectors)
    assert fact_id_to_collector_map

    assert 'fact1' in fact_id_to_collector_map
    assert fact_id_to_collector_map['fact1'][0] is FakeCollector

    assert 'fact2' in fact_id_to_collector_map

# Generated at 2022-06-11 02:17:06.575003
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.platform.default import DefaultFactCollector
    from ansible.module_utils.facts.collector.system.distribution import DistributionFactCollector

    class Collector_A(DefaultFactCollector):
        name = 'A'
        required_facts = set(['F'])

    class Collector_B(DefaultFactCollector):
        name = 'B'
        required_facts = set(['C', 'D', 'E'])

    class Collector_C(DefaultFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class Collector_D(DefaultFactCollector):
        name = 'D'
        required_facts = set(['A'])

    class Collector_E(DefaultFactCollector):
        name = 'E'
        required_

# Generated at 2022-06-11 02:17:12.322392
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'collector_1': 'dep1', 'collector_2': 'dep2', 'collector_3': 'dep1'}
    assert find_unresolved_requires(['c1', 'c3'], all_fact_subsets) == {'dep1', 'dep2'}
    assert find_unresolved_requires(['c1', 'c3', 'dep1'], all_fact_subsets) == {'dep2'}
    assert find_unresolved_requires(['c1', 'c3', 'dep2'], all_fact_subsets) == {'dep1'}
    assert find_unresolved_requires(['c1', 'c3', 'dep1', 'dep2'], all_fact_subsets) == set()



# Generated at 2022-06-11 02:17:24.385980
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test the behavior with __init__ name set
    class test_collector_1(BaseFactCollector):
        _fact_ids = {'test_id'}
        name = 'test_name1'

    class test_collector_2(BaseFactCollector):
        _fact_ids = {'test_id'}
        name = 'test_name2'

    # Test the behavior with name set to None
    class test_collector_3(BaseFactCollector):
        _fact_ids = {'test_id'}

    class test_collector_4(BaseFactCollector):
        _fact_ids = {'test_id'}

    collectors_for_platform = list([test_collector_1, test_collector_2, test_collector_3, test_collector_4])

    expected

# Generated at 2022-06-11 02:17:32.881034
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'platform': [platform],
        'network': [iptables, selinux, network],
    }
    # Make sure platforms don't matter
    assert find_unresolved_requires(['platform'], all_fact_subsets) == set()
    assert find_unresolved_requires(['platform', 'network'], all_fact_subsets) == set()

    # Make sure we fail fast
    with pytest.raises(CollectorNotFoundError):
        find_unresolved_requires(['missing'], all_fact_subsets)

    # Test that we find the right thing
    assert find_unresolved_requires(['network'], all_fact_subsets) == set(['platform'])

# Generated at 2022-06-11 02:17:43.958043
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Preparation
    class Test1Fact(BaseFactCollector):
        name = 'test1'
        required_facts = ['test2']

    class Test2Fact(BaseFactCollector):
        name = 'test2'
        required_facts = ['test3']

    class Test3Fact(BaseFactCollector):
        name = 'test3'

    Test1 = Test1Fact()
    Test2 = Test2Fact()
    Test3 = Test3Fact()
    all_fact_subsets = {
        'test1': [Test1],
        'test2': [Test2],
        'test3': [Test3],
    }

    # Test: All of the requirements should be resolved
    #       when the collector_names is set to be ['test1', 'test2', 'test3'].

# Generated at 2022-06-11 02:17:54.581905
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    valid_subsets = frozenset(('all', 'network', 'kernel', 'virtual', 'facter', 'ohai'))

    minimal_gather_subset = frozenset(('network'))

    platform_info = {'system': 'Linux'}

    gather_timeout = 10

    all_collector_classes = [
        Collector_Linux_all,
        Collector_Linux_kernel,
        Collector_Linux_virtual,
        Collector_Linux_facter,
        Collector_Linux_ohai,
        Collector_Generic_all,
        Collector_Generic_kernel,
        Collector_Generic_virtual,
        Collector_Generic_facter,
        Collector_Generic_ohai,
    ]

    # The list of all collector classes in desired order

# Generated at 2022-06-11 02:18:03.887634
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.collectors import NetworkCollector, HardwareCollector
    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector]
    }
    # assert that unresolved requires are found
    reqs = find_unresolved_requires(set(['network']), all_fact_subsets)
    assert reqs == set(['hardware'])
    # test with a namespace
    all_fact_subsets['network'][0].namespace = Namespace('foo_')
    reqs = find_unresolved_requires(set(['foo_network']), all_fact_subsets)
    assert reqs == set(['hardware'])
    # assert non-existent names

# Generated at 2022-06-11 02:18:09.238995
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {}
    def mk_class(requires=()):
        class Collect0(BaseFactCollector):
            name = 'collect0'
            required_facts = requires
        return Collect0
    all_fact_subsets['collect0'] = [mk_class()]
    all_fact_subsets['collect1'] = [mk_class(('collect2',))]
    all_fact_subsets['collect2'] = [mk_class(('collect3',))]
    all_fact_subsets['collect3'] = [mk_class(('collect0',))]
    assert find_unresolved_requires(['collect0', 'collect1'], all_fact_subsets) == set()
    assert find_unresolved_requires(['collect1', 'collect2'], all_fact_subsets)

# Generated at 2022-06-11 02:18:20.664665
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import inspect
    import os
    import sys

    ''' Unit test for function build_fact_id_to_collector_map'''
    # Get current file path
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

    # Get parent directory
    parent_dir = os.path.dirname(current_dir)

    # Add current directory to path
    path = parent_dir

    # Append to sys path
    sys.path.append(path)

    # Import module
    from ansible.module_utils.facts.facts import BaseFactCollector


# Generated at 2022-06-11 02:18:30.852765
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Test1(BaseFactCollector):
        name = 'test1'
    class Test2(BaseFactCollector):
        name = 'test2_primary'
        _fact_ids = ['test2_alias']
    class Test3(BaseFactCollector):
        name = 'test3_primary'
        _fact_ids = ['test3_alias1', 'test3_alias2']

    test_input = [Test1, Test2, Test3]

    expected_map = {
        'test1': [Test1],
        'test2_primary': [Test2],
        'test2_alias': [Test2],
        'test3_primary': [Test3],
        'test3_alias1': [Test3],
        'test3_alias2': [Test3],
    }
    expected_aliases_

# Generated at 2022-06-11 02:18:46.951382
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Note: we don't have to read this file at run time, just reference
    # the classes in a list since the interpreter will make sure it's
    # read already.
    from ansible.module_utils.facts import collectors as fact_collectors
    assert find_unresolved_requires(['all'], fact_collectors) == set()
    assert find_unresolved_requires(['arch', 'hostname'], fact_collectors) == set()
    assert find_unresolved_requires(['kernel', 'processor'], fact_collectors) == {'distribution', 'system'}
    assert find_unresolved_requires(['hardware', 'uptime'], fact_collectors) == set()

    assert find_unresolved_requires(['kernel'], fact_collectors) == {'distribution', 'system'}

# Generated at 2022-06-11 02:18:54.017195
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from copy import copy
    hc = copy(HardwareCollector)
    hc._fact_ids = set(['dmi', 'platform'])
    hc.name = 'hardware'
    nc = copy(NetworkCollector)
    nc._fact_ids = set(['network', 'fqdn'])
    nc.name = 'network'
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([hc, nc])
    assert fact_id_to_collector_map['hardware'] == [hc]

# Generated at 2022-06-11 02:19:07.108695
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class Collector(BaseFactCollector):
        name = 'DummyCollector'
        required_facts = ['non_existent']
        def collect(self):
            return {'a': 'x'}

    class CollectorWithAlias(BaseFactCollector):
        name = 'AliasCollector'
        _fact_ids = ['Alias1', 'Alias2']
        required_facts = ['non_existent']
        def collect(self):
            return {'a': 'x'}

    class CollectorWithRequires(BaseFactCollector):
        name = 'RequiresCollector'
        required_facts = ['AliasCollector']
        def collect(self):
            return {'b': 'y'}

    class CollectorWithRequires2(BaseFactCollector):
        name = 'RequiresCollector2'
        required_facts = ['RequiresCollector']
       

# Generated at 2022-06-11 02:19:18.786221
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(['a', 'b'], {'a':[], 'b':[], 'c':[]}) == set()
    assert find_unresolved_requires(['a', 'b'], {'a':[], 'b':[], 'c':[]}) == set()
    assert find_unresolved_requires(['a', 'b'], {'a':[], 'b':[], 'c':[], 'd':[], 'e':[]}) == set()

    class A:
        required_facts = set()
    class B:
        required_facts = set()
    class C:
        required_facts = set()
    class D:
        required_facts = set(['a', 'b'])
    class E:
        required_facts = set(['f'])


# Generated at 2022-06-11 02:19:24.104661
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestFactCollector(BaseFactCollector):
        name = 'test'
        required_facts = ['foo', 'bar']
    fake_fact_subsets = defaultdict(set)
    fake_fact_subsets['test'].add(TestFactCollector)
    dep_data = build_dep_data(['test'], fake_fact_subsets)
    assert dep_data['test'] == TestFactCollector.required_facts


# Generated at 2022-06-11 02:19:35.075245
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = frozenset(('B', 'C'))

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = frozenset(('D',))

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = frozenset(('D',))

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = frozenset(())

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = frozenset(('F',))

    # test a simple case where all deps are found
    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-11 02:19:46.914702
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    expected = set('abcd')
    all_fact_subsets = {'a': [FakeCollector('a', required_facts=['b'])],
                        'b': [FakeCollector('b', required_facts=['c'])],
                        'c': [FakeCollector('c', required_facts=['d'])]}
    collector_names = set('c')
    actual = find_unresolved_requires(collector_names, all_fact_subsets)
    assert expected == actual, "Expected %s, got %s" % (expected, actual)

    expected = set('bcd')

# Generated at 2022-06-11 02:19:56.210571
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], [[[], ['a'], ['a', 'b'], ['a', 'c'], ['b'], ['b', 'c'], ['c']], [[], ['a'], ['a', 'b'], ['a', 'c'], ['b'], ['b', 'c'], ['c']]])
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}



# Generated at 2022-06-11 02:20:05.824698
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Foo(object):
        required_facts = frozenset(('bar', 'baz'))
    class Bar(object):
        required_facts = frozenset(('fooness', 'baz'))
    class Baz(object):
        required_facts = frozenset()

    class Fooness(object):
        required_facts = frozenset()

    all_fact_subsets = {
        'foo': (Foo,),
        'bar': (Bar,),
        'baz': (Baz,),
        'fooness': (Fooness,),
    }

    assert find_unresolved_requires(['fooness'], all_fact_subsets) == set()

# Generated at 2022-06-11 02:20:17.930746
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _platform = 'A'
        name = 'A'

    class CollectorB(BaseFactCollector):
        _platform = 'B'
        name = 'B'

    class CollectorBAliases(BaseFactCollector):
        _platform = 'BAliases'
        name = 'BAliases'
        _fact_ids = set(['BAliases_alias1', 'BAliases_alias2'])

    result = build_fact_id_to_collector_map(set([CollectorA, CollectorB, CollectorBAliases]))
    # Tuple is FactID to collector map, aliases map

# Generated at 2022-06-11 02:20:45.552776
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    resolve_map = dict(
        A=set(['B']),
        B=set(['C']),
        C=set(['A']),
        D=set(['C', 'E']),
        E=set([]),
        F=set(['G']),
        G=set(['F'])
    )
    class _DummyCollector(BaseFactCollector):
        name = None
        required_facts = set()
        def __init__(self, name):
            super(_DummyCollector, self).__init__()
            self.name = name
            self.required_facts = resolve_map[name]

    all_fact_subsets = defaultdict(list)
    for name, resolve_to in resolve_map.items():
        collector = _DummyCollector(name)
        all

# Generated at 2022-06-11 02:20:54.042412
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    required_facts = {'Linux': {'ansible_distribution': {'required_facts': ['ansible_distribution_version'], 'required_by': ['ansible_distribution_version']}}, 'Generic': {'ansible_all_ipv4_addresses': {'required_facts': [], 'required_by': []}, 'ansible_all_ipv6_addresses': {'required_facts': [], 'required_by': []}}}
    all_fact_subsets = {}
    all_fact_subsets['Generic'] = required_facts['Generic']
    all_fact_subsets['Linux'] = required_facts['Linux']
    collector_names_list = ["ansible_distribution", "ansible_distribution_version"]

# Generated at 2022-06-11 02:21:05.172457
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['network', 'hardware', 'system', 'virtual', 'firmware'])
    assert get_collector_names(gather_subset=['min']) == frozenset(['system'])
    assert get_collector_names(gather_subset=['system', '!network']) == frozenset(['system'])
    assert get_collector_names(gather_subset=['system', 'network']) == frozenset(['network', 'system'])

    assert get_collector_names(gather_subset=['!system']) == frozenset(['network', 'hardware', 'virtual', 'firmware'])

# Generated at 2022-06-11 02:21:15.651949
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test correct subset pattern
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['all', 'hardware', 'virtual']),
                               minimal_gather_subset=frozenset(['all', 'hardware', 'virtual'])) == set(['all', 'hardware', 'virtual'])
    # Assert unknown subset is error
    try:
        get_collector_names(gather_subset=['unknown'],
                            valid_subsets=frozenset(['all', 'hardware', 'virtual']),
                            minimal_gather_subset=frozenset(['all', 'hardware', 'virtual']))
    except TypeError:
        pass
    # Test exclude subset

# Generated at 2022-06-11 02:21:25.863206
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.system import SystemCollector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    # mock out a few subclasses of BaseFactCollector
    class C1(BaseFactCollector):
        name = "c1"
        required_facts = set(['c1_req_fact'])
    class C2(BaseFactCollector):
        name = "c2"
        required_facts = set(['c2_req_fact'])
    class C3(BaseFactCollector):
        name = "c3"
        required_facts = set(['c3_req_fact'])

    # We're going to need to mock out 'require_facts' for

# Generated at 2022-06-11 02:21:37.055964
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(frozenset(['all']), frozenset(), ['all'], None, None) == frozenset(['all'])
    assert get_collector_names(frozenset(['hardware']), frozenset(), ['hardware'], None, None) == frozenset(['hardware'])
    assert get_collector_names(frozenset(['hardware', 'network']), frozenset(), ['network'], None, None) == frozenset(['network'])
    assert get_collector_names(frozenset(['hardware', 'network']), frozenset(), ['hardware'], None, None) == frozenset(['hardware'])