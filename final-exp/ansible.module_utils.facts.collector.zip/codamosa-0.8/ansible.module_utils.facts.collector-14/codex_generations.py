

# Generated at 2022-06-11 02:11:56.557755
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'network': [BaseFactCollector, BaseFactCollector],
        'min': [BaseFactCollector],
        'other': [BaseFactCollector],
    }

    collector_names = ['min', 'network', 'other', 'network']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 3
    assert all(isinstance(c, BaseFactCollector) for c in selected_collector_classes)



# Generated at 2022-06-11 02:12:05.770837
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'system': [BaseFactCollector]}

    assert build_dep_data(set(), all_fact_subsets) == {}
    assert build_dep_data(set(['system']), all_fact_subsets) == {'system': set()}

    class SystemFactCollector(BaseFactCollector):
        name = 'system'
        required_facts = set(['hardware'])

    class HardwareFactCollector(BaseFactCollector):
        name = 'hardware'
        required_facts = set(['bios'])

    class BiosFactCollector(BaseFactCollector):
        name = 'bios'
        required_facts = set(['system'])


# Generated at 2022-06-11 02:12:14.329289
# Unit test for function tsort
def test_tsort():
    # This is a test case from wikipedia that should return:
    # p, w, i, r, t, a, m, s, u
    # Note: i, t and m are the 3 acyclic ones, each pops one
    #       at a time and the remaining cycles are detected.
    #       (p, i, m, s, u) are the final set
    p_deps = set()
    w_deps = set(['i'])
    i_deps = set(['r'])
    r_deps = set(['t'])
    t_deps = set(['a'])
    a_deps = set(['s'])
    m_deps = set(['u'])
    s_deps = set(['p'])

# Generated at 2022-06-11 02:12:21.680962
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.virtual

# Generated at 2022-06-11 02:12:33.038694
# Unit test for function tsort
def test_tsort():
    try:
        tsort([('A', ('B',)), ('B', ('A',))])
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'we should have had a cycle error'

    dep_map = {'b': ('a', ), 'a': ('c', ), 'c': ()}
    expected = [('c', ()), ('a', ('c', )), ('b', ('a',))]
    assert expected == tsort(dep_map), 'should be the same as expected'

    dep_map = {'b': (), 'a': ('c', ), 'c': ()}
    expected = [('b', ()), ('c', ()), ('a', ('c', ))]
    assert expected == tsort(dep_map), 'should be the same as expected'


# Generated at 2022-06-11 02:12:44.780118
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'new_subset_2': [object()],
        'new_subset_3': [object()],
        }

    try:
        collector_names = ['new_subset_1']
        result = list(find_unresolved_requires(collector_names, all_fact_subsets))
    except CollectorNotFoundError:
        pass
    else:
        raise Exception('Expected error for case when collector_name not found in all_fact_subsets')

    try:
        collector_names = ['new_subset_1']
        result = list(find_unresolved_requires(collector_names, all_fact_subsets))
    except CollectorNotFoundError:
        pass

# Generated at 2022-06-11 02:12:56.557379
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector_1(BaseFactCollector):
        _fact_ids = set(['test_fact1'])
        name = 'test_collector_1'

    class Collector_2(BaseFactCollector):
        _fact_ids = set(['test_fact1', 'test_fact2', 'test_fact3'])
        name = 'test_collector_2'

    collectors = [Collector_1, Collector_2]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)

    assert ['test_fact1', 'test_fact2', 'test_fact3'] == sorted(fact_id_to_collector_map.keys())


# Generated at 2022-06-11 02:13:06.412586
# Unit test for function tsort
def test_tsort():
    data_map = {1: (2, 3),
                2: (4, 5),
                3: (6,),
                4: (7,),
                5: (8,)}
    sorted_list = tsort(data_map)
    assert sorted_list[0][0] == 6
    assert sorted_list[1][0] == 7
    assert sorted_list[2][0] == 8
    assert sorted_list[3][0] == 2
    assert sorted_list[4][0] == 4
    assert sorted_list[5][0] == 5
    assert sorted_list[6][0] == 3
    assert sorted_list[7][0] == 1



# Generated at 2022-06-11 02:13:15.980513
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    """
    Unit test for class find_collectors_for_platform
    """
    import unittest
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.platform import PlatformCollector

    class CollectorsToFind(PlatformCollector):
        _platform = 'Linux'
        name = 'CollectorsToFind'

    # set default values
    all_collector_classes = [PlatformCollector, CollectorsToFind]
    compat_platforms = ['Linux']
    # create variable to store result
    result = find_collectors_for_platform(all_collector_classes, compat_platforms)
    # create class for unit test

# Generated at 2022-06-11 02:13:27.611798
# Unit test for function get_collector_names
def test_get_collector_names():
    # Simple test of the function
    assert frozenset(get_collector_names(gather_subset=["!all"])) == frozenset([])
    assert frozenset(get_collector_names(gather_subset=["network"])) == frozenset(["network"])
    assert frozenset(get_collector_names(gather_subset=["!network"])) == frozenset([])
    assert frozenset(get_collector_names(gather_subset=["!network"], valid_subsets=frozenset(["network"]))) == frozenset([])
    assert frozenset(get_collector_names(gather_subset=["network"], valid_subsets=frozenset(["network"]))) == frozenset(["network"])

# Generated at 2022-06-11 02:13:50.610706
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileEntropyCollector
    from ansible.module_utils.facts.collector import BaseFileGlobCollector
    from ansible.module_utils.facts.collector import BaseFileTextCollector
    from ansible.module_utils.facts.collector import BaseFileBinaryCollector
    from ansible.module_utils.facts.collector import BasePackageManagerCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BaseKernelModulesCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector
    from ansible.module_utils.facts.collector import BaseHardware

# Generated at 2022-06-11 02:14:01.933847
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data([], {}) == defaultdict(set)
    assert build_dep_data(['a'], {}) == defaultdict(set)

    assert build_dep_data(['a'], {'a': []}) == {'a': set()}

    assert (build_dep_data(['a'], {'a': [object]}) ==
            {'a': set()})

    # mock a class with required_facts('b')
    class MockClass:
        required_facts = ('b',)
        @classmethod
        def platform_match(cls, ignored):
            return cls
    assert (build_dep_data(['a'], {'a': [MockClass]}) ==
            {'a': set(['b'])})

    # mock a class with required_facts('b')

# Generated at 2022-06-11 02:14:07.429095
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector

    all_fact_subsets = {'fib': [collector.FibonacciFactCollector]}
    all_fact_subsets.update(collector.fact_classes_by_name)
    assert 0 == len(
        set(select_collector_classes(['all'], all_fact_subsets)).difference(collector.fact_classes))



# Generated at 2022-06-11 02:14:18.571997
# Unit test for function build_dep_data
def test_build_dep_data():
    name = 'a'
    class CollectorA:
        name = name
        required_facts = ['b', 'c']
    CollectorA.__name__ = name
    name = 'b'
    class CollectorB:
        name = name
        required_facts = ['c']
    CollectorB.__name__ = name
    name = 'c'
    class CollectorC:
        name = name
        required_facts = []
    CollectorC.__name__ = name
    # create all_fact_subset
    all_fact_subsets = {'a': [CollectorA], 'b': [CollectorB], 'c': [CollectorC]}

    # create collector_names
    collector_names = ['a', 'b', 'c']

    # create expected dep map

# Generated at 2022-06-11 02:14:28.694806
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Darwin'
        name = 'test'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            pass

    class GenericCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_generic'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            pass

    platform_info = [{'system':'Darwin', 'release':'16.6.0'},{'system':'Generic', 'release':'16.6.0'}]

# Generated at 2022-06-11 02:14:38.411293
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import json
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    class A(BaseFactCollector):
        name = 'A'
    class B(BaseFactCollector):
        name = 'B'
        _platform = 'Darwin'
    class C(BaseFactCollector):
        name = 'C'
        _platform = 'Linux'
    class D(BaseFactCollector):
        name = 'D'
        _platform = 'Generic'

    all_collector_classes = frozenset([A, B, C, D])

    # Test find_collectors_for_platform function

# Generated at 2022-06-11 02:14:47.455449
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class FirstTestClass(BaseFactCollector):
        _platform = 'Darwin'
        name = 'first'
    class SecondTestClass(BaseFactCollector):
        _platform = 'Darwin'
        name = 'second'
    class FirstGenericClass(BaseFactCollector):
        _platform = 'Generic'
        name = 'first_generic'
    class SecondGenericClass(BaseFactCollector):
        _platform = 'Generic'
        name = 'second_generic'

    class ErrorTestClass(BaseFactCollector):
        _platform = 'Generic'
        name = 'error'
        def platform_match(cls):
            raise Exception("testing error handling")

    platform_info = {'system': 'Darwin'}
    platform_info_generic = {'system': 'Generic'}


# Generated at 2022-06-11 02:14:54.816690
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b']
    all_fact_subsets = {
        'a': [TestFactCollector('a')],
        'b': [TestFactCollector('b')]
    }
    expected = {'a': ['a', 'b'], 'b': ['a', 'b']}
    got = build_dep_data(collector_names, all_fact_subsets)
    assert expected == got



# Generated at 2022-06-11 02:15:06.383719
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import all_collector_classes
    from ansible.module_utils.facts import timeout, timeout
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.linux.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.collectors.linux.dns import LinuxDnsFactCollector
    from ansible.module_utils.facts.collectors.linux.packages import LinuxPackagesFactCollector

    all_fact_subsets = subset_fact_collectors(all_collector_classes)
    collector_names = set(all_fact_subsets.keys())

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

   

# Generated at 2022-06-11 02:15:12.079191
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['a', 'b', 'c', 'd', 'e']),
                               aliases_map=defaultdict(set, {
                                   'f': frozenset(['a', 'b'])
                               }),
                               gather_subset=['!d', 'f']) == frozenset(['a', 'b', 'c', 'f'])



# Generated at 2022-06-11 02:15:39.788465
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # create a fake all_fact_subsets list
    all_fact_subsets = {
        'a': ['a1', 'a2'],
        'b': ['b1', 'b2'],
        'c': ['c1', 'c2'],
        'd': ['d1', 'd2'],
        }
    # All of the following test cases are based on the invalid
    # fact names:  b, d, and f
    # and the valid fact names: a, c, e
    # This way, we can test the following:
    # b - invalid fact name
    # d - invalid fact name
    # f - invalid fact name
    # a - valid fact name
    # c - valid fact name
    # e - valid fact name
    # The following cases are based on these invalid fact
    # and valid

# Generated at 2022-06-11 02:15:52.931014
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['all'], dict(all=[TestCollectorA, TestCollectorB]))
    assert isinstance(dep_map, dict)
    assert isinstance(dep_map.get('all'), set)
    assert dep_map.get('all') == {'test_collector_a', 'test_collector_b'}

    dep_map = build_dep_data(['all', 'test_collector_a', 'test_collector_b'], dict(all=[TestCollectorA, TestCollectorB]))
    assert isinstance(dep_map, dict)
    assert isinstance(dep_map.get('all'), set)
    assert dep_map.get('all') == {'test_collector_a', 'test_collector_b'}

# Generated at 2022-06-11 02:16:03.423183
# Unit test for function get_collector_names
def test_get_collector_names():
    # minimal gather_subsets are ignored if mention in gather_subset
    assert get_collector_names(valid_subsets=frozenset(['network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network']) == frozenset([])
    assert get_collector_names(valid_subsets=frozenset(['network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all']) == frozenset([])

    assert get_collector_names(valid_subsets=frozenset(['network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network'])

# Generated at 2022-06-11 02:16:09.754004
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    fact_subsets = dict([
        ('fact1', [object()]),
        ('fact2', [object()]),
    ])
    assert find_unresolved_requires(['fact1', 'fact2'], fact_subsets) == set()
    assert find_unresolved_requires(['fact1', 'fact2', 'fact3'], fact_subsets) == set(['fact3'])



# Generated at 2022-06-11 02:16:19.109755
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [], 'b': [], 'c': []}
    # 'a' requires nothing, 'b' requires 'a', 'c' requires 'a' and 'b'
    for collector_name in all_fact_subsets:
        klass = type(collector_name, (object,), {
            'required_facts': set(all_fact_subsets) - set([collector_name]),
        })
        all_fact_subsets[collector_name] = [klass]

    assert find_unresolved_requires(set(), all_fact_subsets) == set()
    assert find_unresolved_requires(set(['a']), all_fact_subsets) == set()

# Generated at 2022-06-11 02:16:29.619776
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class C1(BaseFactCollector):
        name = 'C1'
        required_facts = ['unresolved']

    class C2(BaseFactCollector):
        name = 'C2'
        required_facts = ['unresolved']

    class C3(BaseFactCollector):
        name = 'C3'
        required_facts = ['unresolved', 'resolved']

    class C4(BaseFactCollector):
        name = 'C4'
        required_facts = ['resolved']

    class C5(BaseFactCollector):
        name = 'C5'
        required_facts = ['C4', 'resolved']

    class C6(BaseFactCollector):
        name = 'C6'
        required_facts = ['C4', 'C5']

    all_fact_subsets = defaultdict

# Generated at 2022-06-11 02:16:39.785578
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    class TestCollector1(BaseFactCollector):
        _fact_ids = ('dep_col', 'dep_col1')
        name = 'tcol1'
        required_facts = ('dep_col',)
        def collect(self, module=None, collected_facts=None):
            return dict()

    class TestCollector2(BaseFactCollector):
        _fact_ids = ('dep_col2', 'dep_col22')
        name = 'tcol2'
        required_facts = ('dep_col22',)
        def collect(self, module=None, collected_facts=None):
            return dict()

    all_collector_classes = [TestCollector1, TestCollector2]
    fact_id_to_collector

# Generated at 2022-06-11 02:16:51.124410
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset parameter specified
    result = get_collector_names()
    assert result == frozenset({'all'})

    # Test with empty gather_subset parameter specified
    result = get_collector_names(gather_subset=[])
    assert result == frozenset({'all'})

    # Test with minimal_gather_subset=frozenset({'min'}) and gather_subset=['min']
    result = get_collector_names(minimal_gather_subset=frozenset({'min'}),
                                 gather_subset=['min'])
    assert result == frozenset({'min'})

    # Test with minimal_gather_subset=frozenset({'min'}) and gather_subset=['all']

# Generated at 2022-06-11 02:17:02.521338
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    collectors = {'collector1': [MockCollector('collector1', {'requirement_2'})],
                  'collector2': [MockCollector('collector2', {'requirement_3'})],
                  'collector3': [MockCollector('collector3', {'requirement_4'})],
                  'requirement_1': [MockCollector('requirement_1', {'requirement_2'})],
                  'requirement_2': [MockCollector('requirement_2', {'requirement_3'})],
                  'requirement_3': [MockCollector('requirement_3', {'requirement_4'})],
                  'requirement_4': [MockCollector('requirement_4', set())],
                  }
    result = find_unresolved_

# Generated at 2022-06-11 02:17:07.342061
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class X(BaseFactCollector):
        _fact_ids = ['foo']
    assert build_fact_id_to_collector_map([BaseFactCollector, X]) == ({'ansible_facts': [BaseFactCollector], 'foo': [X], 'ansible_system': [BaseFactCollector]}, {'ansible_system': set(), 'ansible_facts': set()})
    assert build_fact_id_to_collector_map([X]) == ({'foo': [X]}, {'foo': set()})



# Generated at 2022-06-11 02:17:28.713472
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collectors = {
        'one': [TestCollector],
        'two': [TestCollector2],
        'three': [TestCollector3],
    }
    # One requires two
    assert find_unresolved_requires(['one'], collectors) == set(['two'])
    # Two requires three
    assert find_unresolved_requires(['two'], collectors) == set(['three'])
    # Two requires three, three requires two
    assert find_unresolved_requires(['two', 'three'], collectors) == set()
    # One requires two, two requires three, three requires two
    assert find_unresolved_requires(['one', 'two', 'three'], collectors) == set()



# Generated at 2022-06-11 02:17:37.502764
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset([
        'hardware', 'system', 'network', 'virtual', 'kernel', 'fips'
    ])

    minimal_gather_subset = frozenset(['min'])

    # NOTE: In this test, we pass an empty gather_subset list. This is a user
    # error, so the function will return 'min' as the subset list.
    assert get_collector_names(
        valid_subsets=valid_subsets,
        minimal_gather_subset=minimal_gather_subset,
        gather_subset=None,
        aliases_map=None,
        platform_info=None,
    ) == minimal_gather_subset

    # NOTE: In this test, we're passing 'all' in the gather_subset so the
    # function will

# Generated at 2022-06-11 02:17:47.715046
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.network import Network
    from ansible.module_utils.facts.collectors.base import CollectorNotFoundError

    # base connect test (no collector or 'device' collector is a subset of 'network')
    collector_names = ['network', 'device']

    all_fact_subsets = {'network': [Network],
                        'device': [Network]}

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test unresolved dependencies
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == {'device'}

    # test that a collector for a requires_facts not in collectable_subsets
    # does not cause an

# Generated at 2022-06-11 02:17:55.955795
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collector
    # we need to construct a minimal platform info
    platform_info = {'system': 'Generic'}
    facts_platform = 'generic'
    collectors_for_platform = set(find_collectors_for_platform(ansible.module_utils.facts.collector.legacy_collectors,
                                                               (platform_info,)))
    fact_id_to_collector_map, __ = build_fact_id_to_collector_map(collectors_for_platform)
    assert 'facter' in fact_id_to_collector_map
    assert 'ohai' in fact_id_to_collector_map
    assert 'pkg_mgr' in fact_id_to_collector_map

    # on a non generic platform, this should be empty

# Generated at 2022-06-11 02:18:05.412826
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''
    Run test for function find_unresolved_requires.
    '''
    collector_names = ['factA', 'factB', 'factC', 'factD']
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['factA'].append(TestFactCollectorA)
    all_fact_subsets['factB'].append(TestFactCollectorB)
    all_fact_subsets['factC'].append(TestFactCollectorC)
    all_fact_subsets['factD'].append(TestFactCollectorD)

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0
    collector_names.append('factE')

# Generated at 2022-06-11 02:18:15.609738
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.system import OpenBSD, Linux, FreeBSD, Windows, Darwin
    all_fact_subsets = {
        'all': [Linux],
        'hardware': [OpenBSD, FreeBSD, Darwin],  # OpenBSD.requires_facts() = {'hardware'}, etc
        'system_platform': [Windows],
        'bsd': [OpenBSD, FreeBSD],
    }

    assert not find_unresolved_requires(collector_names=set(['hardware', 'system_platform']), all_fact_subsets=all_fact_subsets)
    assert find_unresolved_requires(collector_names=set(['hardware', 'unresolved_fact']), all_fact_subsets=all_fact_subsets) == set(['unresolved_fact'])

    # even

# Generated at 2022-06-11 02:18:21.147050
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        gather_subset=['network']
        ) == set(['network'])

    assert get_collector_names(
        gather_subset=['network'],
        valid_subsets=['network', 'ohai']
        ) == set(['network'])

    assert get_collector_names(
        gather_subset=['!network'],
        valid_subsets=['network', 'ohai']
        ) == set(['ohai'])

    assert get_collector_names(
        gather_subset=['!all'],
        valid_subsets=['network', 'ohai']
        ) == set(['ohai'])


# Generated at 2022-06-11 02:18:30.322328
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['foo', 'bar']
    _all_fact_subsets = defaultdict(list)
    all_fact_subsets = defaultdict(list)
    for collector in collector_names:
        all_fact_subsets[collector].append(FakeCollector(collector,['req_fact']))
    for k,v in all_fact_subsets.items():
        _all_fact_subsets[k] = v
    mock_collector = FakeCollector('foo',['req_fact'])
    assert build_dep_data(collector_names, all_fact_subsets) == {'foo': set(['req_fact']),'bar': set(['req_fact'])}


# Generated at 2022-06-11 02:18:40.497965
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollectorA(BaseFactCollector):
        name = 'A'
        required_facts = ('B',)

    class TestCollectorB(BaseFactCollector):
        name = 'B'
        required_facts = ('C',)

    class TestCollectorC(BaseFactCollector):
        name = 'C'
        required_facts = ('D',)

    class TestCollectorD(BaseFactCollector):
        name = 'D'
        required_facts = ('E',)

    class TestCollectorE(BaseFactCollector):
        name = 'E'
        required_facts = ()

    class TestCollectorF(BaseFactCollector):
        name = 'F'
        required_facts = ('E',)

    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-11 02:18:52.184371
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    def _fake_collector_class(name, requires_facts):
        class _FakeClass(BaseFactCollector):
            name = name
            required_facts = requires_facts
        return _FakeClass

    #
    # Test a simple case with 'bios', 'dmi' and 'system'
    #

    # dmi requires system

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['dmi'].append(_fake_collector_class('dmi', ('system',)))
    all_fact_subsets['bios'].append(_fake_collector_class('bios', ('dmi',)))
    all_fact_subsets['system'].append(_fake_collector_class('system', ()))


# Generated at 2022-06-11 02:19:20.457715
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    ''' test function to verify the fact_id_to_collector_map is build correctly'''
    class A(BaseFactCollector):
        _fact_ids = {'a1', 'a2'}
        name = 'a'

    class B(BaseFactCollector):
        _fact_ids = {'b1', 'b2'}
        name = 'b'

    class C(BaseFactCollector):
        _fact_ids = {'c1', 'c2'}
        name = 'c'

    test_input = set([A, B, C])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(test_input)


# Generated at 2022-06-11 02:19:32.281260
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''This tests the function find_unresolved_requires'''
    import itertools
    import copy

    def _add_collector(name, requires_facts, all_fact_subsets):
        '''Return a new all_fact_subsets after adding the given collector'''
        new_all_fact_subsets = copy.deepcopy(all_fact_subsets)
        collector_classes = new_all_fact_subsets[name] = []
        collector_class = type('NewCollector', (object,), {})()
        collector_class.name = name
        collector_class.required_facts = set(requires_facts)
        collector_classes.append(collector_class)
        return new_all_fact_subsets


# Generated at 2022-06-11 02:19:44.730768
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class SampleCollector(BaseFactCollector):
        name = 'sample'

    class SampleCollectorDuplicateId(BaseFactCollector):
        name = 'sample_duplicate_ids'
        _fact_ids = ('sample', )

    class SampleCollectorDuplicateName(BaseFactCollector):
        name = 'sample'
        _fact_ids = ('alias', )

    class SampleCollectorDuplicateNameDuplicateId(BaseFactCollector):
        name = 'sample'
        _fact_ids = ('sample', 'alias')

    class SampleCollectorDuplicateNameDuplicateIdDuplicateId(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'sample'
        _fact_ids = ('alias', 'sample', 'alias2')


# Generated at 2022-06-11 02:19:57.551511
# Unit test for function build_dep_data
def test_build_dep_data():
    class dep_collector():
        name = 'first'
        required_facts = set()    
    class dep_collector2():
        name = 'second'
        required_facts = set()
    class dep_collector3():
        name = 'third'
        required_facts = set()
    class dep_collector4():
        name = 'fourth'
        required_facts = set()

    dep_collectors = {}
    dep_collectors['first'] = [dep_collector, dep_collector2, dep_collector3, dep_collector4]

    test = build_dep_data(['first'], dep_collectors)
    result = {'first': [], 'second': [], 'third': [], 'fourth': []}
    assert test == result



# Generated at 2022-06-11 02:20:06.581947
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    all_fact_subsets = dict(
        a=set([
            object(), object(required_facts=set(['b']))]),
        b=set([
            object(required_facts=set(['c', 'd'])),
            object(required_facts=set(['c', 'd']))]),
        c=set([
            object(required_facts=set(['e'])),
            object(required_facts=set(['e'])),
            object(required_facts=set(['e']))])
    )

    assert find_unresolved_requires(set(['a', 'b', 'c']), all_fact_subsets) == set(['d', 'e'])

# Generated at 2022-06-11 02:20:18.766280
# Unit test for function get_collector_names
def test_get_collector_names():
    # Create a mock platform_info
    platform_info = {
        'system': 'Linux',
        'os_family': 'Unbreakable Enterprise Kernel',
        'distribution': 'Oracle Linux Server'
    }

    # Create a mock aliases_map
    aliases_map = defaultdict(set)
    aliases_map['network'].add('networking')
    aliases_map['hardware'].add('devices')
    aliases_map['hardware'].add('dmi')

    # Gather_subset test for 'all'
    valid_subset = ['network', 'devices']
    minimal_gather_subset = ['devices']
    gather_subset = ['all']
    subsets = get_collector_names(valid_subset, minimal_gather_subset, gather_subset, aliases_map)
   

# Generated at 2022-06-11 02:20:26.051841
# Unit test for function get_collector_names
def test_get_collector_names():
    from ansible.module_utils.facts.collector.default import gather_subset_for_platform as default

    # default: all
    g_subset = ['all']
    v_subset = frozenset(('nameservers', 'network', 'all', 'local', 'virtual', 'fips', 'ipv4', 'distribution', 'virtualization', 'default_ipv4', 'default_ipv6', 'custom', 'kernel', 'dmi', 'system', 'os_family', 'name', 'ipv6', 'os_version', 'mounts', 'devices', 'architecture'))
    m_subset = frozenset(('network', 'system', 'ipv4', 'distribution', 'kernel', 'os_family', 'devices', 'architecture'))


# Generated at 2022-06-11 02:20:38.393655
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'foo': [object()],
        'bar': [object()],
        'one': [object()],
        'two': [object()],
    }

    # none existent
    assert find_unresolved_requires([], all_fact_subsets) == set()

    # one non-existent
    assert find_unresolved_requires(['foo'], all_fact_subsets) == set(['foo'])

    # all non-existent
    assert find_unresolved_requires(['foo', 'baz'], all_fact_subsets) == set(['foo', 'baz'])

    # all existent
    assert find_unresolved_requires(['foo', 'bar'], all_fact_subsets) == set()

    # one non-existent
   

# Generated at 2022-06-11 02:20:46.481682
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test gather_subset with no arguments
    s = get_collector_names()
    assert 'all' == s

    # Test gather_subset with a subset argument
    s = get_collector_names(gather_subset=['system'])
    assert 'system' == s

    # Test gather_subset with multiple subset arguments
    s = get_collector_names(gather_subset=['network', 'system'])
    assert 'network' == s

    # Test gather_subset with explicit aliases
    aliases_map = {'hardware': ['devices', 'dmi']}
    s = get_collector_names(aliases_map=aliases_map,
                            gather_subset=['hardware'])
    assert 'hardware' == s

    # Test gather_subset with invalid argument


# Generated at 2022-06-11 02:20:54.016822
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test for function build_fact_id_to_collector_map
    from ansible.module_utils.facts import plugins

    facts = plugins.get_fact_collector_classes()

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        facts
    )
    assert 'selinux' in fact_id_to_collector_map
    assert 'selinux_python' in fact_id_to_collector_map
    assert 'selinux_python' in aliases_map['selinux']
    assert 'Linux' in fact_id_to_collector_map
    assert 'BSD' in fact_id_to_collector_map



# Generated at 2022-06-11 02:21:31.784400
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class TestCollector1(BaseFactCollector):
        _fact_ids = set()
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        name = 'test2'
        required_facts = set(['test1'])

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        name = 'test4'
        required_facts = set(['test3'])

    class TestCollector5(BaseFactCollector):
        _fact_ids = set()
        name = 'test5'

# Generated at 2022-06-11 02:21:38.461990
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test if a specified subset has been retrieved
    collector_classes = collector_classes_from_gather_subset(gather_subset=['!facter'])
    assert 'facter' not in [x.name for x in collector_classes]

    # Test if a subset which contains another is excluded as well
    collector_classes = collector_classes_from_gather_subset(gather_subset=['!facter'])
    assert 'facter' not in [x.name for x in collector_classes]
    assert 'facter_text' not in [x.name for x in collector_classes]

    # Test if the virtual subset is filtered properly
    collector_classes = collector_classes_from_gather_subset(gather_subset=['!virtual'])
    assert 'virtual' in all_collectors()
