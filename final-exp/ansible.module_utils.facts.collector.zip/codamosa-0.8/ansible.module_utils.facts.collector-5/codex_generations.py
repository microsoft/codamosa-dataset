

# Generated at 2022-06-11 02:12:08.001386
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MockClass(BaseFactCollector):
        name = 'mock_name'
        _fact_ids = ['mock_name_alias']

    class MockClass2(BaseFactCollector):
        name = 'mock_name2'
        _fact_ids = ['mock_name2_alias']

    # Test a single Collector
    collector_classes = [MockClass]
    expected = {'mock_name': [MockClass], 'mock_name_alias': [MockClass]}
    expected_aliases = {'mock_name': set(['mock_name_alias'])}
    result, aliases_map = build_fact_id_to_collector_map(collector_classes)
    assert result == expected
    assert aliases_map == expected_aliases

    # Test multiple Collectors
   

# Generated at 2022-06-11 02:12:18.289861
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    class Collector1:
        required_facts = set()

    class Collector2:
        required_facts = set()

    class Collector3:
        required_facts = set(['Collector2'])

    class Collector4:
        required_facts = set(['Collector1', 'Collector2'])

    class Collector5:
        required_facts = set(['Collector4', 'Collector3'])

    class Collector6:
        required_facts = set(['Collector4', 'Collector5'])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['Collector1'].append(Collector1)
    all_fact_subsets['Collector2'].append(Collector2)
    all_fact_subsets['Collector3'].append(Collector3)
    all

# Generated at 2022-06-11 02:12:30.700961
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # no requires
    collector_names = {'one', 'two', 'three'}
    all_fact_subsets = {'one': [], 'two': [], 'three': []}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one require
    collector_names = {'one', 'two', 'three', 'one_require'}
    all_fact_subsets = {'one': [], 'two': [], 'three': [], 'one_require': [object()]}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one require: unresolved
    collector_names = {'one', 'two', 'three'}

# Generated at 2022-06-11 02:12:36.882820
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test for find_unresolved_requires. Requires for
    'devices' and 'dmi' are both "hardware". And 'hardware'
    requires 'firmware'.
    '''
    all_fact_subsets = {
        'devices': [
            {'required_facts': {'hardware'}}
        ],
        'dmi': [
            {'required_facts': {'hardware'}}
        ],
        'hardware': [
            {'required_facts': {'firmware'}}
        ],
        'firmware': [{'required_facts': set()}],
    }
    collector_names = set()

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-11 02:12:47.195264
# Unit test for function tsort
def test_tsort():
    tests = [
        (
            {
                1: [2],
                2: [3],
                3: [4],
                4: [1],
            },
            CycleFoundInFactDeps,
        ),
        (
            {
                1: [2],
                2: [3],
                3: [4],
                4: [],
            },
            None,
        ),
        (
            {
                1: [2],
                2: [3],
                3: [4],
                4: [5],
                5: [],
            },
            None,
        ),
    ]

# Generated at 2022-06-11 02:12:58.210250
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    try:
        from unittest.mock import Mock
    except:
        from mock import Mock

    collector_a = Mock()
    collector_a.platform_match = Mock()
    collector_a.name = 'A'
    collector_a._fact_ids = set()

    collector_b = Mock()
    collector_b.platform_match = Mock()
    collector_b.name = 'B'
    collector_b._fact_ids = {'B-alias'}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([collector_a, collector_b])

    assert fact_id_to_collector_map == {'A': [collector_a], 'B-alias': [collector_b], 'B': [collector_b]}



# Generated at 2022-06-11 02:13:08.891234
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.nxos.hardware import CiscoNxosHardware
    from ansible.module_utils.facts.collector.nxos.version import CiscoNxosVersion
    from ansible.module_utils.facts.collector.nxos.config import CiscoNxosConfig
    from ansible.module_utils.facts.collector.nxos.filesystems import CiscoNxosFileSystems
    from ansible.module_utils.facts.collector.nxos.interfaces import CiscoNxosInterfaces
    from ansible.module_utils.facts.collector.nxos.lldp_neighbors import CiscoNxosLldpNeighbors
    from ansible.module_utils.facts.collector.nxos.local import CiscoNxosLocal
   

# Generated at 2022-06-11 02:13:18.042944
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'b': {'a'},
        'c': {'b'},
        'd': {'c'},
        'e': {'d'},
        'a': set(),
    }
    assert tsort(dep_map) == [
        ('a', set()),
        ('b', {'a'}),
        ('c', {'b'}),
        ('d', {'c'}),
        ('e', {'d'}),
    ]

    dep_map = {
        'b': {'a'},
        'c': {'b'},
        'd': {'c'},
        'e': {'d'},
        'a': {'f'},
        'f': set(),
    }

# Generated at 2022-06-11 02:13:23.229529
# Unit test for function tsort
def test_tsort():
    data = {
        'A': set(['B']),
        'B': set(['C']),
        'C': set([]),
    }
    exp = [('C', set([])), ('B', set(['C'])), ('A', set(['B']))]
    test = tsort(data)
    assert test == exp, 'Expected %s got %s' % (exp, test)

    data = {
        'A': set(['B', 'D']),
        'B': set(['C']),
        'D': set(['C', 'E']),
        'C': set([]),
        'E': set([]),
    }

# Generated at 2022-06-11 02:13:33.766085
# Unit test for function get_collector_names
def test_get_collector_names():
    # test logic for get_collector_names
    # None case
    assert get_collector_names() == {'all'}
    # minimal_gather_subset is always gathered, even after negations
    assert (get_collector_names(
        minimal_gather_subset=frozenset(['foo']),
        gather_subset=['!all']) == {'foo'})
    # Include a subset specified in 'gather_subset'
    assert (get_collector_names(
        valid_subsets=frozenset(['foo', 'bar']),
        gather_subset=['foo']) == {'foo'})
    # Include a subset specified in 'gather_subset' and convert from
    # an alias

# Generated at 2022-06-11 02:13:52.348427
# Unit test for function find_unresolved_requires

# Generated at 2022-06-11 02:14:04.592925
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import _get_required_by_collector_name
    test_result = find_unresolved_requires(['a', 'b', 'c'], {'a': [object()], 'c': [object()]})
    assert 'b' in test_result
    assert len(test_result) == 1

    test_result = find_unresolved_requires(['a', 'b', 'c'], {'a': [object()], 'c': [object()], 'b': [object()]})
    assert len(test_result) == 0
    test_result = find_unresolved_requires(['a', 'b'], {'a': [object()], 'c': [object()], 'b': [object()]})
    assert len(test_result) == 1

# Generated at 2022-06-11 02:14:15.445549
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Verify find_unresolved_requires correctly finds all unresolved requires.'''
    # build a test fact_id_to_collector_map
    fact_id_to_collector_map = defaultdict(list)
    collector_class_a = object
    collector_class_a.name = 'A'
    collector_class_a.required_facts = frozenset(('C',))
    collector_class_b = object
    collector_class_b.name = 'B'
    collector_class_b.required_facts = frozenset(('A',))
    collector_class_c = object
    collector_class_c.name = 'C'
    collector_class_c.required_facts = frozenset()


# Generated at 2022-06-11 02:14:26.201832
# Unit test for function get_collector_names
def test_get_collector_names():
    assert(set(get_collector_names(valid_subsets=frozenset(['all', 'foo']),
                                   minimal_gather_subset=frozenset(['min']),
                                   gather_subset=['foo'],
                                   aliases_map={'bar': frozenset(['foo'])})) ==
                                 frozenset(['foo']))

    assert(set(get_collector_names(valid_subsets=frozenset(['all', 'foo']),
                                   minimal_gather_subset=frozenset(['min']),
                                   gather_subset=['!foo'],
                                   aliases_map={'bar': frozenset(['foo'])})) ==
                                 frozenset(['min']))


# Generated at 2022-06-11 02:14:35.283053
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.linux.cpu import ProcessorFactCollector, LinuxProcessorFactCollector
    all_collector_classes = [LinuxProcessorFactCollector, ProcessorFactCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

# Generated at 2022-06-11 02:14:42.000939
# Unit test for function tsort
def test_tsort():
    assert tsort({'a': ['b'], 'b': ['c'], 'c': ['d'], 'd': []}) == [('d', []), ('c', ['d']), ('b', ['c']), ('a', ['b'])]
    try:
        tsort({'a': ['b'], 'b': ['a']})
        assert False, 'Expected cycle error'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-11 02:14:48.883904
# Unit test for function get_collector_names
def test_get_collector_names():
    '''test that get_collector_names implements gather_subset correctly'''

    assert get_collector_names(
        gather_subset=['all'],
        valid_subsets=frozenset(['device', 'network', 'ohai', 'facter']),
        minimal_gather_subset=frozenset(['ohai', 'facter']),
        platform_info={'system': 'Linux'}) == frozenset(['ohai', 'facter', 'device', 'network'])


# Generated at 2022-06-11 02:15:01.852438
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    '''
    This function tests the AnsibleModule._load_params function.
    '''

    # TODO: these should probably be moved to a test file
    class CollectEnv(BaseFactCollector):
        name = 'env'
        _fact_ids = set(['env'])

        def collect(self, module=None, collected_facts=None):
            return {"env": os.environ}

    class CollectFacter(BaseFactCollector):
        name = 'facter'
        _fact_ids = set(['facter'])

        def collect(self, module=None, collected_facts=None):
            return {"facter": "my_facter_value"}

    class CollectOhai(BaseFactCollector):
        name = 'ohai'
        _fact_ids = set(['ohai'])

       

# Generated at 2022-06-11 02:15:10.599596
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from collections import defaultdict
    from ansible.module_utils.facts.collector.base import _get_requires_by_collector_name
    from ansible.module_utils.facts.collector.base import find_unresolved_requires
    all_fact_subsets = defaultdict(dict)
    all_fact_subsets['network']['test_a'] = 'test_a'
    all_fact_subsets['network']['test_b'] = 'test_b'

    assert set(_get_requires_by_collector_name('network', all_fact_subsets)) == set(['test_a', 'test_b'])
    assert set(_get_requires_by_collector_name('test_a', all_fact_subsets)) == set()


# Generated at 2022-06-11 02:15:15.058963
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    ''' test the function build_fact_id_to_collector_map '''
    class FakeCollector(BaseFactCollector):
        ''' This is a fake collector class '''
        _fact_ids = set(['fake_collector_2'])
        name = 'fake_collector'
        aliases_map = defaultdict(set)

    expected_fact_id_to_collector_map = {
        'fake_collector': [FakeCollector],
        'fake_collector_2': [FakeCollector],
    }

    expected_aliases_map = {
        'fake_collector': set(['fake_collector_2']),
    }

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([FakeCollector])

# Generated at 2022-06-11 02:15:34.666618
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorOne(BaseFactCollector):
        name = 'one'
        required_facts = set(['two'])

    class CollectorTwo(BaseFactCollector):
        name = 'two'
        required_facts = set(['three'])

    class CollectorThree(BaseFactCollector):
        name = 'three'
        required_facts = set()

    all_fact_subsets = {
        'one': [CollectorOne],
        'two': [CollectorTwo],
        'three': [CollectorThree]}

    assert find_unresolved_requires(['one'], all_fact_subsets) == set(['three'])
    assert find_unresolved_requires(['one', 'two'], all_fact_subsets) == set(['three'])

# Generated at 2022-06-11 02:15:47.509853
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorClass1(BaseFactCollector):
        name = 'one'
        required_facts = {'nonexist'}

    class CollectorClass2(BaseFactCollector):
        name = 'two'
        required_facts = {'three'}

    class CollectorClass3(BaseFactCollector):
        name = 'three'

    all_fact_subsets = {
        'one': [
            CollectorClass1,
        ],
        'two': [
            CollectorClass2,
        ],
        'three': [
            CollectorClass3,
        ],
    }
    assert find_unresolved_requires(['one', 'two', 'three'], all_fact_subsets) == {'nonexist'}



# Generated at 2022-06-11 02:15:57.719986
# Unit test for function select_collector_classes
def test_select_collector_classes():
    def _collector_class_factory(name, aliases=None, required=None):

        class FakeCollector(Collector):
            _fact_ids = set(aliases or [])
            name = name
            required_facts = set(required or [])

        return FakeCollector

    collector1 = _collector_class_factory('one')
    collector2 = _collector_class_factory('two')
    collector3 = _collector_class_factory('two')
    collector4 = _collector_class_factory('three', required=['one'])
    collector5 = _collector_class_factory('four', required=['three'])
    collector6 = _collector_class_factory('five', required=['four'])

# Generated at 2022-06-11 02:16:06.929585
# Unit test for function get_collector_names
def test_get_collector_names():
    # The answers we expect
    valid_subsets = frozenset(['all', 'configuration', 'hardware', 'network',
                               'virtual', 'min'])
    minimal_subsets = frozenset(['min'])

    # Tests
    for gather_subset in ['all', 'configuration', 'hardware', 'network',
                          'virtual', 'min', '!all',
                          '!configuration', '!hardware', '!network',
                          '!virtual', '!min', 'all,!network']:
        actual = get_collector_names(valid_subsets, minimal_subsets, gather_subset)

# Generated at 2022-06-11 02:16:17.953652
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector(BaseFactCollector):
        name = 'fake'
        required_facts = set(['required'])
    class BoringCollector(BaseFactCollector):
        name = 'boring'
        required_facts = set()

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['fake'].append(FakeCollector)
    all_fact_subsets['boring'].append(BoringCollector)

    assert find_unresolved_requires(['fake'], all_fact_subsets) == set(['required'])
    assert find_unresolved_requires(['fake', 'boring'], all_fact_subsets) == set(['required'])
    assert find_unresolved_requires(['boring', 'fake'], all_fact_subsets)

# Generated at 2022-06-11 02:16:29.151637
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:16:39.183862
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.platform.generic import GenericFactCollector

    all_fact_subsets = {
        'generic': [GenericFactCollector],
    }

    tests = [
        # no collector names
        ({}, []),

        # no requires
        ({'generic': []}, []),

        # requires that are satisfied
        ({'generic': ['generic']}, []),

        # requires that are NOT satisfied
        ({'generic': ['not_generic']}, ['not_generic']),

        # requires that are NOT satisfied
        ({'generic': ['generic', 'not_generic']}, ['not_generic']),
    ]

    for collector_names, expected_unresolved in tests:
        result = find_unresolved_requires(collector_names, all_fact_subsets)
        assert result == expected_un

# Generated at 2022-06-11 02:16:50.620120
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Setup
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
        required_facts = frozenset(['a'])
    class C(BaseFactCollector):
        name = 'c'
        required_facts = frozenset(['b'])
    class D(BaseFactCollector):
        name = 'd'
        required_facts = frozenset(['a', 'g', 'h'])

    all_fact_subsets = defaultdict(list)
    for collector_class in [A, B, C, D]:
        all_fact_subsets[collector_class.name].append(collector_class)

    # Test: no unresolved requires

# Generated at 2022-06-11 02:17:01.938656
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'cat': [BaseFactCollector],
        'dog': [BaseFactCollector, BaseFactCollector],
        'fish': [BaseFactCollector],
    }
    for collector in all_fact_subsets['cat']:
        collector.required_facts = set()
    for collector in all_fact_subsets['dog']:
        collector.required_facts = set(['turtle'])
    for collector in all_fact_subsets['fish']:
        collector.required_facts = set(['turtle'])
    dep_map = build_dep_data(all_fact_subsets.keys(), all_fact_subsets)
    assert dep_map['cat'] == set()
    assert dep_map['dog'] == set(['turtle'])

# Generated at 2022-06-11 02:17:10.147830
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network.pubkey import PubkeyNetworkFactCollector
    from ansible.module_utils.facts.collector.network.base import NetworkFactCollector
    from ansible.module_utils.facts.collector.network.ipv4 import IPv4NetworkFactCollector

    # network depends on pubkey, which depends on network... [network, pubkey, ipv4]
    all_fact_subsets = {
        NetworkCollector.name: [NetworkCollector],
        PubkeyNetworkFactCollector.name: [PubkeyNetworkFactCollector],
        NetworkFactCollector.name: [NetworkFactCollector],
        IPv4NetworkFactCollector.name: [IPv4NetworkFactCollector],
    }

# Generated at 2022-06-11 02:17:35.267861
# Unit test for function select_collector_classes
def test_select_collector_classes():
    r = select_collector_classes(['hardware', 'network', 'network', 'network'],
            {
                'hardware': [
                    1,
                    2
                ],
                'network': [
                    3,
                    4
                ]
            })
    assert r == [1, 2, 3, 4]


# Generated at 2022-06-11 02:17:45.944684
# Unit test for function build_dep_data
def test_build_dep_data():
    input1 = builder_all_fact_subsets(collector_names=['fact_a', 'fact_b', 'fact_c'],
                                      all_fact_subsets=defaultdict(list,
                                                                   {'fact_a': [BaseFactCollector()],
                                                                    'fact_b': [BaseFactCollector()],
                                                                    'fact_c': [BaseFactCollector()]}))

# Generated at 2022-06-11 02:17:55.312148
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector
    assert 'test_collector' not in collector.__dict__
    fake_test_collector = type('test_collector', (collector.BaseFactCollector, ), {
        'name': 'test_collector',
        '_fact_ids': ['f1', 'f2'],
    })
    assert build_fact_id_to_collector_map({fake_test_collector}) == ({
        'test_collector': [fake_test_collector, fake_test_collector],
        'f1': [fake_test_collector],
        'f2': [fake_test_collector],
    }, {
        'test_collector': {'f1', 'f2'}
    })


# Generated at 2022-06-11 02:18:04.208279
# Unit test for function get_collector_names
def test_get_collector_names():
    # Ensure data for testing is available
    assert 'all' in ANSIBLE_COLLECT_SUBSET
    assert 'default' in ANSIBLE_COLLECT_SUBSET

    # Test no options, default is returned
    names = get_collector_names()
    assert names == frozenset(['default'])

    # Test minimal subset is returned
    names = get_collector_names(minimal_gather_subset=frozenset(['minimal']))
    assert names == frozenset(['minimal'])

    # Test given subset is returned
    names = get_collector_names(gather_subset=['default'], valid_subsets=frozenset(['default']), minimal_gather_subset=frozenset(['default']))

# Generated at 2022-06-11 02:18:09.300725
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        gather_subset=['network']
    ) == set(['network'])

    # when adding an unknown subset, the fallback is still 'all'
    assert get_collector_names(
        gather_subset=['network', 'unknown']
    ) == get_collector_names(gather_subset=['network'])

    # when adding an known subset, and an unknown subset, the fallback is still 'all'
    assert get_collector_names(
        gather_subset=['unknown', 'network', 'unknown'],
        valid_subsets=frozenset(['network'])
    ) == get_collector_names(
        gather_subset=['network'],
        valid_subsets=frozenset(['network'])
    )

    #

# Generated at 2022-06-11 02:18:18.266781
# Unit test for function build_dep_data
def test_build_dep_data():
# function build_dep_data returns {'group_1':set(), 'group_2':set('group_1'), 'group_3': set('group_2')}
# so we use it in below.
    result = build_dep_data(['group_1', 'group_2', 'group_3'], {'group_1': 'group_1', 'group_2': 'group_2', 'group_3': 'group_3'})
    assert result == {'group_1':set(), 'group_2':set('group_1'), 'group_3': set('group_2')}



# Generated at 2022-06-11 02:18:28.982694
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Test if build_fact_id_to_collector_map function returns correct output.

    This function assumes there is a class named TestCollector with a name attribute
    equal to "test".
    '''
    from ansible.module_utils.facts import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = "test"
        required_facts = set()
        _fact_ids = set(["test1", "test2"])

        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            return facts_dict

    test_collector_class = TestCollector()
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([test_collector_class])

    assert fact_id_to

# Generated at 2022-06-11 02:18:39.591832
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector as facts_collector
    from ansible.module_utils.facts import default_collectors
    import json
    import os
    import platform
    import tempfile

    all_collector_classes = set(facts_collector.get_collector_classes())
    collectors_for_platform = find_collectors_for_platform(all_collector_classes,
                                                           [{'system': platform.system().lower()}])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # create a representative gather_subset (re-use default_collectors.py, but drop platform specific)
    all_fact_

# Generated at 2022-06-11 02:18:44.657966
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    # TODO: this test is incomplete, but better than nothing
    all_fact_subsets = {
        'b': [MockCollectorClass('b', requires=['c'])],
        'c': [MockCollectorClass('c')],
    }
    assert find_unresolved_requires(['c', 'b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b'], all_fact_subsets) == set('c')



# Generated at 2022-06-11 02:18:55.081851
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test function get_collector_names
    # Retrieve all facts elements
    minimal_subsets = ['hardware', 'network']
    valid_subsets = ['hardware', 'network', 'virtual']
    gather_subset = ['network', 'hardware', '!virtual']
    aliases_map = defaultdict(set, {'hardware': set(['devices', 'dmi'])})

    expected_subsets = set(['network', 'hardware', 'devices', 'dmi'])
    result_subsets = get_collector_names(valid_subsets=valid_subsets,
                                         minimal_gather_subset=minimal_subsets,
                                         gather_subset=gather_subset,
                                         aliases_map=aliases_map)

    assert result_subsets == expected_subsets

   

# Generated at 2022-06-11 02:19:17.679616
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['python', 'network', 'hardware', 'devices'])
    minimal_subsets = frozenset(['python', 'network'])
    gather_subset = ['hardware', 'network']

    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(['devices', 'dmi'])

    result = get_collector_names(valid_subsets=valid_subsets, minimal_gather_subset=minimal_subsets,
                                 gather_subset=gather_subset, aliases_map=aliases_map)

    assert result == frozenset(['network', 'hardware'])

    # test excluding hardware
    gather_subset = ['!hardware']


# Generated at 2022-06-11 02:19:25.352986
# Unit test for function get_collector_names
def test_get_collector_names():
    assert set(get_collector_names(gather_subset=['none'])) == set()
    assert set(get_collector_names(
        minimal_gather_subset=['min_subset'],
        gather_subset=['none'])) == set(['min_subset'])

    # gather_subset=['os', '!storage'],
    assert set(get_collector_names(
        valid_subsets=set(['os', 'storage', 'all']),
        aliases_map=defaultdict(set, {'storage': set(['lvm', 'zpool'])}),
        gather_subset=['os', '!storage'])) == set(['os'])

    # gather_subset=['all'],

# Generated at 2022-06-11 02:19:35.847987
# Unit test for function build_dep_data

# Generated at 2022-06-11 02:19:42.829094
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set, {
        'hardware': ['devices', 'dmi'],
    })
    assert get_collector_names(valid_subsets={'all', 'network', 'hardware'},
                               aliases_map=aliases_map,
                               gather_subset=['network', 'hardware']) == {'network', 'hardware', 'devices', 'dmi'}



# Generated at 2022-06-11 02:19:50.394994
# Unit test for function get_collector_names
def test_get_collector_names():
    # Basic usage
    assert get_collector_names(valid_subsets=["all"], gather_subset=["all"]) == frozenset(['all'])
    assert get_collector_names(valid_subsets=["all"], gather_subset=["min"]) == frozenset(['all'])
    assert get_collector_names(valid_subsets=["all", "min"], gather_subset=["all"]) == frozenset(['all', 'min'])
    assert get_collector_names(valid_subsets=["all", "min"], gather_subset=["min"]) == frozenset(['all', 'min'])
    assert get_collector_names(valid_subsets=["min"], gather_subset=["min"]) == frozenset(['min'])
    #

# Generated at 2022-06-11 02:20:02.492498
# Unit test for function get_collector_names
def test_get_collector_names():
    import itertools
    # get all permutations of the 'all', '!hardware', 'network' list
    permutations = itertools.permutations(['all', '!hardware', 'network'])
    for gather_subset in permutations:
        collect_names_to_use = get_collector_names(
            valid_subsets=frozenset(['all', 'network', 'hardware', 'virtual', 'dmi']),
            minimal_gather_subset=frozenset(['network']),
            gather_subset=list(gather_subset)
        )
        if gather_subset != ('all', '!hardware', 'network'):
            assert 'dmi' not in collect_names_to_use
        assert 'network' in collect_names_to_use



# Generated at 2022-06-11 02:20:13.792378
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector import BaseFactCollector, FileSystemCollector
    from ansible.module_utils.facts.collector.system import DISTRIBUTION_FILE_MAP, DISTRIBUTION_TO_FAMILY_MAP, LinuxDistributionCollector

    class FileSystemCollector2(BaseFactCollector):
        _fact_ids = {'diskspace'}
        name = 'diskspace'
        required_facts = {'fstype'}

    class LinuxDistroCollector2(LinuxDistributionCollector):
        _fact_ids = {'distro2'}
        name = 'distro2'
        required_facts = {'distribution_file'}


# Generated at 2022-06-11 02:20:23.462170
# Unit test for function get_collector_names
def test_get_collector_names():
    all_subsets = frozenset(['min', 'apps', 'platform', 'network', 'hardware', 'virtual'])

    module = DummyModule(dict(
        gather_subset='!all',
        gather_timeout=10,
        filter=dict(FACT_NAMESPACE='ansible_'),
        ansible_facts={}
    ))

    # gather_subset=all -> get all the facts
    collected_names = get_collector_names(
        valid_subsets=all_subsets,
        gather_subset=['all'],
    )
    assert collected_names == set(['min', 'apps', 'platform', 'network', 'hardware', 'virtual'])

    # gather_subset=!all -> get all the facts except for hardware and virtual
    collected_names = get_collector

# Generated at 2022-06-11 02:20:36.249090
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''
    test to find the unresolved requires
    '''
    from ansible.module_utils.facts import defaultdict
    all_fact_subsets = defaultdict(list)
    collector_names = set()

    # Example test case collectors
    class TestCollectorA(BaseFactCollector):
        _fact_ids = set(['a'])

        name = 'a'
        required_facts = ('zx',)

    class TestCollectorB(BaseFactCollector):
        _fact_ids = set(['b'])

        name = 'b'
        required_facts = ('zx',)

    class TestCollectorC(BaseFactCollector):
        _fact_ids = set(['c'])

        name = 'c'
        required_facts = ('zx',)


# Generated at 2022-06-11 02:20:36.910202
# Unit test for function build_dep_data
def test_build_dep_data():
    pass



# Generated at 2022-06-11 02:21:15.000943
# Unit test for function build_dep_data

# Generated at 2022-06-11 02:21:18.894350
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    collector_names = ['distribution']
    dep_map = build_dep_data(collector_names, {'distribution': [DistributionFactCollector]})
    assert set() == dep_map['distribution']


# Generated at 2022-06-11 02:21:30.030015
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorWithRequires(BaseFactCollector):
        name = 'collector_with_requires'
        required_facts = frozenset(('required_fact_1', 'required_fact_2'))
        # Unit test assumes no dependencies. In other words, that each collector
        # is a standalone fact.
    class CollectorWithoutRequires(BaseFactCollector):
        name = 'collector_without_requires'
        required_facts = frozenset()

    class FakeAllFactSubsets(object):
        def __init__(self):
            self.fact_id_to_collector_map = defaultdict(list)

            for collector in (
                    CollectorWithRequires,
                    CollectorWithoutRequires,
                    ):
                self.fact_id_to_collector_map[collector.name].append(collector)


# Generated at 2022-06-11 02:21:31.591813
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.other.facts import FactsCollector
    unresolved = find_unresolved_requires(['!all'], FactsCollector.all_fact_subsets)
    assert len(unresolved) == 1
    assert '!min' in unresolved



# Generated at 2022-06-11 02:21:37.938085
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import sys
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.bind
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.selinux
    import ansible.module_utils.facts.kernel
    import ansible.module_utils.facts.software
    import ansible.module_utils.facts.gce
    import ansible.module_utils.facts.ipmi
    import ansible.module_utils.facts.locale
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.date_time
   

# Generated at 2022-06-11 02:21:48.200427
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from unittest import mock
    import os

    old_PATH = os.environ['PATH']
    os.environ['PATH'] = '/bin:/usr/bin'