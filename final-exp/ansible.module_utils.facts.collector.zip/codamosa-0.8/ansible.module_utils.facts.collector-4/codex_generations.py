

# Generated at 2022-06-11 02:12:05.105386
# Unit test for function get_collector_names
def test_get_collector_names():
    # set up aliases_map so that we know that hardware facts include
    # {'devices','dmi','pcid'}
    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi', 'pcid'])

    valid_subsets = frozenset(['min', 'hardware', 'software', 'devices', 'dmi', 'pcid'])
    minimal_gather_subset = frozenset(['hardware'])

    gather_subset = ['min', '!dmi', 'software']

# Generated at 2022-06-11 02:12:14.097029
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    all_collector_classes = [DistributionFactCollector, PlatformFactCollector]


# Generated at 2022-06-11 02:12:22.682079
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=('all', 'foo', 'bar'), gather_subset=['min']) == frozenset(('foo', 'bar'))
    assert get_collector_names(valid_subsets=('all', 'foo', 'bar'), gather_subset=['all']) == frozenset(('foo', 'bar'))
    assert get_collector_names(valid_subsets=('all', 'foo', 'bar'), gather_subset=['bar']) == frozenset(('bar',))
    assert get_collector_names(valid_subsets=('all', 'foo', 'bar'), gather_subset=['!bar']) == frozenset(('foo',))

# Generated at 2022-06-11 02:12:33.759062
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names() == frozenset(('all',))
    assert get_collector_names(gather_subset=['network']) == frozenset(('network',))
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(('network',))
    assert get_collector_names(gather_subset=['!all']) == frozenset(('min',))
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(('network', 'min'))
    assert get_collector_names(gather_subset=['!all', '!network']) == frozenset(('min',))

# Generated at 2022-06-11 02:12:45.431353
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class NTPFactCollector(BaseFactCollector):
        name = 'ntp'
        _fact_ids = {'ntp'}

    class NetworkFactCollector(BaseFactCollector):
        name = 'network'
        _fact_ids = {'network'}

    class LocalFactCollector(BaseFactCollector):
        name = 'local'
        _fact_ids = {'local'}

        def collect(self, module=None, collected_facts=None):
            facts = {}
            facts['local'] = 'local'
            return facts

    class OtherFactCollector(BaseFactCollector):
        name = 'other'
        _fact_ids = {'other'}

    class SecondOtherFactCollector(BaseFactCollector):
        name = 'other'
        _fact_ids = {'other'}

# Generated at 2022-06-11 02:12:53.673765
# Unit test for function get_collector_names
def test_get_collector_names():
    in_args = {'gather_subset': ['min', '!network'],
               'valid_subsets': frozenset(['all', 'network']),
               'minimal_gather_subset': frozenset(['min']),
               'aliases_map': {
                   'network': ('network', 'fact_network'),
                   'hardware': ('devices', 'dmi')
               }
    }
    out_args = get_collector_names(**in_args)
    expected = frozenset(['min'])
    assert out_args == expected



# Generated at 2022-06-11 02:13:01.790442
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # repeat the test, once with a "version"
    # and once without.
    for ver in [None, '1.0.0']:
        compat_platforms = [{'system': 'Generic'}]
        if ver:
            compat_platforms[0]['version'] = ver

        class GenericCollector1(BaseFactCollector):
            name = 'generic1'
            _fact_ids = set(['generic1_fact'])
            def collect(self, module=None, collected_facts=None):
                return {'generic1_fact': 'generic1'}

        class GenericCollector2(BaseFactCollector):
            name = 'generic2'
            _fact_ids = set(['generic2_fact'])

# Generated at 2022-06-11 02:13:08.516670
# Unit test for function get_collector_names
def test_get_collector_names():

    assert get_collector_names(set(['all']), ['all'], ['all']) == set(['all'])
    assert get_collector_names(set(['all']), ['all'], ['!all']) == set()

    try:
        get_collector_names(set(['all']), ['all'], ['!all', 'network'])
        assert False
    except TypeError:
        pass

    assert get_collector_names(set(['hardware', 'network']), ['all'], ['!hardware', '!network']) == set()



# Generated at 2022-06-11 02:13:17.869314
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # NOTE: for this test, we don't care about the classes, just their names
    collectors_for_platform = [
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
    ]

    collector_classes = defaultdict(dict)

    # have a have an '_fact_ids' that matches it's name
    collector_classes['a']['name'] = 'a'
    collector_classes['a']['_fact_ids'] = ['a']

    # have a have an '_fact_ids' that does not match it's name
    collector_classes['b']['name'] = 'b'
    collector_classes['b']['_fact_ids'] = ['b1']

    #

# Generated at 2022-06-11 02:13:29.187459
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:13:55.732421
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test_alias'])

    # Test multiple collectors with same name
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestFactCollector, TestFactCollector])
    assert aliases_map['test'] == set(['test', 'test_alias'])
    assert fact_id_to_collector_map['test'] == [TestFactCollector, TestFactCollector]
    assert fact_id_to_collector_map['test_alias'] == [TestFactCollector, TestFactCollector]



# Generated at 2022-06-11 02:14:07.794321
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import (
        collector_for_system,
        get_collector_classes,
    )

    collectors = get_collector_classes(collector_for_system)
    subsets = dict((c.name, [c]) for c in collectors)

    def check(collector_names, expect_unresolved):
        unresolved = find_unresolved_requires(collector_names, subsets)
        assert unresolved == expect_unresolved

    # no requires
    collector_names = ['command_exists', 'pkg_mgr']
    check(collector_names, set())

    # one require
    collector_names = ['pkg_mgr', 'pkg_mgr_time_stamp_old_install', 'pkg_mgr_apt']

# Generated at 2022-06-11 02:14:18.636743
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # create sample all_facts_subsets
    def fake_collector_class(fact_name, required_facts):
        '''create a dummy fact collector class, suitable for use in all_facts_subsets'''
        new_class = type(str(fact_name), (BaseFactCollector,), {'name': fact_name, 'required_facts': required_facts})
        return new_class


# Generated at 2022-06-11 02:14:28.771016
# Unit test for function get_collector_names
def test_get_collector_names():
    '''test function get_collector_names'''
    assert get_collector_names(valid_subsets=frozenset(),
                               minimal_gather_subset=frozenset(),
                               gather_subset=None,
                               aliases_map=defaultdict(set),
                               platform_info=None) == set()

    assert get_collector_names(valid_subsets=frozenset(['network', 'ohai']),
                               minimal_gather_subset=frozenset(['ohai']),
                               gather_subset=None,
                               aliases_map=defaultdict(set),
                               platform_info=None) == set(['network', 'ohai'])


# Generated at 2022-06-11 02:14:38.489823
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = [
        FactCollectorA,
        FactCollectorB,
        FactCollectorC,
        FactCollectorD,
        FactCollectorE,
    ]
    result = build_fact_id_to_collector_map(collectors_for_platform)

# Generated at 2022-06-11 02:14:43.327384
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        ['all', 'hardware'],
        minimal_gather_subset=['min'],
        gather_subset=['hardware'],
        aliases_map={'hardware': ['devices', 'dmi']},
        platform_info={}) == ['hardware', 'devices', 'dmi']



# Generated at 2022-06-11 02:14:48.862316
# Unit test for function build_dep_data
def test_build_dep_data():
    test_collector_names = {'facts', 'otherfacts', 'morefacts'}
    test_all_fact_subsets = {'facts': [MockFactCollector('facts')],
                             'otherfacts': [MockFactCollector('otherfacts', ['facts'])],
                             'morefacts': [MockFactCollector('morefacts', ['otherfacts'])]}
    expected_dep_map = {'facts': set(), 'otherfacts': {'facts'}, 'morefacts': {'otherfacts'}}

    dep_map = build_dep_data(test_collector_names, test_all_fact_subsets)
    assert dep_map == expected_dep_map
# End of unit test for function build_dep_data


# Generated at 2022-06-11 02:15:01.838567
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c', 'd']
    all_fact_subsets = {}
    for name in collector_names:
        all_fact_subsets[name] = []
    for name in collector_names:
        all_fact_subsets[name].append(name)
    required_facts_a = set()
    required_facts_b = set()
    required_facts_c = {'a', 'b'}
    required_facts_d = {'c'}
    a = set()
    a.add(required_facts_a)
    b = set()
    b.add(required_facts_b)
    c = set()
    c.add(required_facts_c)
    d = set()
    d.add(required_facts_d)
    all_fact

# Generated at 2022-06-11 02:15:10.572046
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'foo', 'bar', 'baz'])
    minimal_gather_subset = frozenset(['all', 'foo'])
    aliases_map = defaultdict(set)
    aliases_map['foo'] = set(['bar', 'baz'])

    # with no arguments, it defaults to ['all']
    assert get_collector_names() == valid_subsets

    # a single string is treated as a gather_subset=['all']
    assert get_collector_names(gather_subset='all') == valid_subsets

    # a single subset can be included
    assert get_collector_names(gather_subset='foo') == set(['foo'])

    # a single subset can be excluded

# Generated at 2022-06-11 02:15:20.927178
# Unit test for function build_dep_data
def test_build_dep_data():
    import unittest
    import sys
    import os

    sys.path.append(os.path.abspath(os.path.join(__file__, '..', '..', '..')))

    collector_names = set(['network', 'platform', 'virtual', 'filesystem', 'hardware'])

# Generated at 2022-06-11 02:15:39.039224
# Unit test for function get_collector_names
def test_get_collector_names():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['foo'])
        name = 'foo'
        required_facts = set(['bar'])

    def do_test(subset, expected):
        names = get_collector_names(
            valid_subsets=frozenset(['all', 'min', 'foo']),
            minimal_gather_subset=frozenset(['min']),
            gather_subset=subset)
        assert names == expected, "subset %s did not give expected results: %s" % (subset, names)

    do_test(subset=None, expected=frozenset(['min', 'foo']))
    do_test(subset=['all'], expected=frozenset(['min', 'foo']))
   

# Generated at 2022-06-11 02:15:48.259996
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all', '!all', 'network', 'min']
    required_facts = {'all':{'network'}, '!all':{'network'}, 'network':{'min'}}
    dep_map = defaultdict(set)
    for collector_name in collector_names:
        for dep in required_facts[collector_name]:
            dep_map[collector_name].add(dep)
    assert build_dep_data(collector_names, required_facts) == dep_map



# Generated at 2022-06-11 02:15:58.127506
# Unit test for function get_collector_names
def test_get_collector_names():
    # Note that this test case relies on the behavior of
    # get_collector_names. If that function is modified, then
    # this test case may need to be changed as well.
    try:
        get_collector_names(
            valid_subsets=frozenset(['foo']),
            minimal_gather_subset=frozenset(['bar']),
            aliases_map=defaultdict(set),
            gather_subset=['!all', 'foo'])
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-11 02:16:07.186579
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    try_find_unresolved_requires(['a', 'b'], {'a': set(['b']), 'b': set(['a'])})
    try_find_unresolved_requires(['a', 'b', 'c'], {'a': set(['b']), 'b': set(['c']), 'c': set(['b'])})
    try_find_unresolved_requires(['a', 'b', 'c'], {'a': set(['b', 'c']), 'b': set(['c']), 'c': set(['b'])})
    try_find_unresolved_requires(['a', 'c'], {'a': set(['b', 'c']), 'b': set(['c']), 'c': set(['b'])})

    # test that

# Generated at 2022-06-11 02:16:18.056032
# Unit test for function build_dep_data
def test_build_dep_data():
    # TODO: remove this when we have a proper test/mocking framework
    from ..collector.fact_classes import (
        LocalAnsibleModule,
        BaseFactCollector,
        CollectorNotFoundError,
        CycleFoundInFactDeps,
        UnresolvedFactDep,
    )

    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = {'c'}
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = {'d'}
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = {'b'}

    all_collector_classes = [CollectorA, CollectorB, CollectorC, CollectorD]

# Generated at 2022-06-11 02:16:25.485392
# Unit test for function build_dep_data
def test_build_dep_data():
    class MockCollector(BaseFactCollector):
        name = 'fake'
        required_facts = set()

    mocked_all_fact_subsets = {'fake': [MockCollector]}
    mocked_collector_names = ['fake']
    result = build_dep_data(mocked_collector_names, mocked_all_fact_subsets)
    expected_result = defaultdict(set, {'fake': set()})
    assert result == expected_result, result



# Generated at 2022-06-11 02:16:33.075990
# Unit test for function get_collector_names
def test_get_collector_names():
    print('test_get_collector_names:')
    try:
        get_collector_names(gather_subset=['blah'],
                            valid_subsets=frozenset(['facter', 'hardware', 'virtual']))
        print('    Expected exception, got none.')
    except TypeError:
        print('    Got expected exception.')

    try:
        get_collector_names(gather_subset=['all', '!facter'],
                            valid_subsets=frozenset(['facter', 'hardware', 'virtual']))
        print('    Expected exception, got none.')
    except TypeError:
        print('    Got expected exception.')

    print('    Subset returned: %s' % get_collector_names())

# Generated at 2022-06-11 02:16:40.467798
# Unit test for function tsort
def test_tsort():
    cycle_facts = defaultdict(set, {'a': {'b'},
                                    'b': {'c'},
                                    'c': {'a'}})

    facts = defaultdict(set, {'b': {'a'},
                              'c': {'b', 'a'},
                              'd': {'c', 'a'}})

    assert tsort(cycle_facts) == []

    assert [x[0] for x in tsort(facts)] == ['a', 'b', 'c', 'd']



# Generated at 2022-06-11 02:16:49.390341
# Unit test for function tsort
def test_tsort():
    test_map = {'a':['b'], 'b':['c'], 'c':['d'], 'd':[]}
    sorted_list = tsort(test_map)
    assert (sorted_list == [('d', []), ('c', ['d']), ('b', ['c']), ('a', ['b'])])

    test_map = {'a':['a'], 'b':['c'], 'c':['d'], 'd':[]}
    try:
        tsort(test_map)
        assert (False)
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-11 02:17:00.708645
# Unit test for function build_dep_data
def test_build_dep_data():
    # Make a simple case
    collector_names = ['bob', 'fred', 'mary', 'jill']
    collectors_for_platform = []

    for name in collector_names:
        class Collector(BaseFactCollector):
            name = name
            required_facts = set()
        collectors_for_platform.append(Collector)

    all_fact_subsets = {}
    for collector in collectors_for_platform:
        all_fact_subsets.setdefault(collector.name, []).append(collector)

    for name in collector_names:
        assert name in all_fact_subsets

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map == {k: set() for k in collector_names}



# Generated at 2022-06-11 02:17:26.885646
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector_A(BaseFactCollector):
        name = 'A'
        required_facts = set('B')
    class Collector_B(BaseFactCollector):
        name = 'B'
    class Collector_C(BaseFactCollector):
        name = 'C'
    all_fact_subsets = {'A': (Collector_A,),
                        'C': (Collector_C,),
                        'B': (Collector_B,)}
    collector_names = ('A', 'B', 'C')
    result = build_dep_data(collector_names, all_fact_subsets)
    assert result == {'A': set(('B',)), 'B': set(), 'C': set()}
# /Unit test for function build_dep_data



# Generated at 2022-06-11 02:17:34.076118
# Unit test for function get_collector_names
def test_get_collector_names():
    import unittest

    class GetCollectorNamesTest(unittest.TestCase):
        def test_collector_names_with_single_gather_subset(self):
            names = get_collector_names(['hostname'], [])
            self.assertEqual(names, set(['hostname']))

        def test_collector_names_with_empty_aliases_map(self):
            names = get_collector_names(['hostname'], [], aliases_map={})
            self.assertEqual(names, set(['hostname']))

        def test_collector_names_with_no_aliases(self):
            names = get_collector_names(['hostname'], [], aliases_map={'network': []})

# Generated at 2022-06-11 02:17:40.952496
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = {'all': {'foo', 'bar'}, 'hardware': {'devices', 'dmi'}}
    assert get_collector_names(aliases_map=aliases_map, gather_subset=['hardware']) == {'devices', 'dmi'}
    assert get_collector_names(aliases_map=aliases_map, gather_subset=['!hardware']) == {'foo', 'bar'}



# Generated at 2022-06-11 02:17:47.593373
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = {'test1'}
        def collect(self, module=None, collected_facts=None):
            pass

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector])
    assert 'test_collector' in fact_id_to_collector_map
    assert 'test1' in fact_id_to_collector_map
    assert 'test_collector' in aliases_map



# Generated at 2022-06-11 02:17:55.907683
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:18:05.336301
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import collector_classes
    collectors = list(collector_classes)
    collectors[0]._fact_ids = set(['foo', 'bar'])
    collectors[1]._fact_ids = set(['baz', 'qux'])
    result, aliases_map = build_fact_id_to_collector_map(collectors)
    assert set(result['foo']) == set(collectors)
    assert set(result['bar']) == set(collectors)
    assert set(result['baz']) == set(collectors)
    assert set(result['qux']) == set(collectors)
    assert set(result['all']) == set(collectors)
    assert set(result['network']) == set(collectors)

# Generated at 2022-06-11 02:18:15.454049
# Unit test for function get_collector_names
def test_get_collector_names():
    from collections import defaultdict
    from ansible.module_utils.facts import get_collector_names

    # provided directly from ansible.module_utils.facts
    # fact_subset_aliases_map = {
    #     'hardware': {'devices', 'dmi'},
    #     'network': {'interfaces', 'default_ipv4', 'default_ipv6'},
    #     'identity': {'fqdn', 'hostname', 'domain'},
    #     'virtual': {'is_kvm', 'is_virtual', 'virtualization_role', 'virtualization_type'},
    #     'ohai': {'ohai'},
    #     'custom': {'ansible_facts'},
    # }

# Generated at 2022-06-11 02:18:19.479115
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.python_packages.python_packages import PythonPackagesFactCollector
    from ansible.module_utils.facts.collector.platform.platform import PlatformFactCollector
    all_fact_subsets = {'python_packages': [PythonPackagesFactCollector], 'platform': [PlatformFactCollector]}
    assert(find_unresolved_requires(['platform'], all_fact_subsets) == set())
    assert(find_unresolved_requires(['python_packages'], all_fact_subsets) != set())



# Generated at 2022-06-11 02:18:29.957557
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['other_thing'])
    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC]
        }
    collectors = find_unresolved_requires(['a', 'b'], all_fact_subsets)
    assert len(collectors) == 0
    collectors = find_unresolved_requires(['b'], all_fact_subsets)

# Generated at 2022-06-11 02:18:40.256716
# Unit test for function get_collector_names
def test_get_collector_names():
    # no arguments
    assert get_collector_names() == frozenset()

    # two valid subsets
    assert get_collector_names(valid_subsets=frozenset(['default']),
                               platform_info={'system': 'Linux'}) == frozenset(['default'])
    assert get_collector_names(valid_subsets=frozenset(['default', 'network']),
                               platform_info={'system': 'Linux'}) == frozenset(['default', 'network'])

    # single valid subset in gathering_subset
    assert get_collector_names(valid_subsets=frozenset(['default', 'network']),
                               gather_subset=['default'],
                               platform_info={'system': 'Linux'}) == frozenset(['default'])

# Generated at 2022-06-11 02:19:07.625646
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
  class FooFactCollector(BaseFactCollector):
    required_facts = set(['bar'])
  class BarFactCollector(BaseFactCollector):
    required_facts = set()

  foo_classes = [FooFactCollector]
  bar_classes = [BarFactCollector]

  fact_subsets = {
    'foo': foo_classes,
    'bar': bar_classes,
  }

  assert set(['bar']) == find_unresolved_requires(['foo'], fact_subsets)
  assert set([]) == find_unresolved_requires(['bar'], fact_subsets)

  class BazFactCollector(BaseFactCollector):
    required_facts = set(['foo'])

# Generated at 2022-06-11 02:19:19.251715
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import unittest

    class Collectors(unittest.TestCase):
        def test_collectors_dup(self):
            class Collector_1(BaseFactCollector):
                name = 'collector_1'
                # mock the class attribute _fact_ids
                _fact_ids = ['fact_id_1']

            class Collector_2(BaseFactCollector):
                name = 'collector_2'
                # mock the class attribute _fact_ids
                _fact_ids = ['fact_id_1']

            class Collector_3(BaseFactCollector):
                name = 'collector_3'
                # mock the class attribute _fact_ids
                _fact_ids = ['fact_id_3']


# Generated at 2022-06-11 02:19:31.242384
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class platform_collector_a(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'platform_collector_a'

    class platform_collector_b(BaseFactCollector):
        _fact_ids = set(['b', 'c'])
        name = 'platform_collector_b'

    class platform_collector_c(BaseFactCollector):
        _fact_ids = set(['c', 'd'])
        name = 'platform_collector_c'

    platform_collectors = [platform_collector_a,
                           platform_collector_b,
                           platform_collector_c]

    platform_info = {'system': 'Linux'}


# Generated at 2022-06-11 02:19:38.525915
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    # unit test helper class
    class CollectorA(object):
        name = 'A'
        required_facts = set()
    class CollectorB(object):
        name = 'B'
        required_facts = set()
    class CollectorC(object):
        name = 'C'
        required_facts = {'A', 'B'}

    all_fact_subsets = {'A': [CollectorA], 'B': [CollectorB], 'C': [CollectorC]}

    # ensure we can find both of the facts that C needs that are not in ['A', 'B', 'C']
    unresolved = find_unresolved_requires(collector_names=['A', 'B', 'C'], all_fact_subsets=all_fact_subsets)
    assert len(unresolved) == 0

    # we don

# Generated at 2022-06-11 02:19:48.195058
# Unit test for function get_collector_names
def test_get_collector_names():
    # case 1
    gather_subset = ['all']
    valid_subsets = frozenset(['hardware', 'network'])
    minimal_gather_subsets = frozenset(['min'])
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = set(['dev', 'dmi'])
    aliases_map['network'] = set(['net'])

    result = get_collector_names(
        valid_subsets=valid_subsets,
        minimal_gather_subset=minimal_gather_subsets,
        gather_subset=gather_subset,
        aliases_map=aliases_map,
    )

    assert result == set(['hardware', 'network', 'min'])

    # case 2

# Generated at 2022-06-11 02:20:01.224046
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = [
        'network',
        'system',
        'hardware',
    ]

    all_fact_subsets = {
        'network': [FakeCollector(name='network', required_facts=set())],
        'system': [FakeCollector(name='system', required_facts=set(['network']))],
        'hardware': [FakeCollector(name='hardware', required_facts=set(['network']))],
    }

    result = find_unresolved_requires(collector_names, all_fact_subsets)
    assert result == set()

    collector_names = [
        'network',
        'system',
        'hardware',
        'filesystem'
    ]


# Generated at 2022-06-11 02:20:11.491398
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    import ansible.module_utils.facts.collector.base

    class TestCollector1(ansible.module_utils.facts.collector.base.BaseFactCollector):
        name = 'test_collector_1'
        required_facts = ['test_collector_2', 'test_collector_3']

    class TestCollector2(ansible.module_utils.facts.collector.base.BaseFactCollector):
        name = 'test_collector_2'
        required_facts = []

    class TestCollector3(ansible.module_utils.facts.collector.base.BaseFactCollector):
        name = 'test_collector_3'
        required_facts = []



# Generated at 2022-06-11 02:20:22.161821
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_collectors = set()
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set()

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['B', 'C'])

    test_collectors.update([A, B, C, D])
    all_fact_subsets = defaultdict(list)
    for collector in test_collectors:
        all_fact_subsets[collector.name].append(collector)

    collector_names = ['A', 'D']

# Generated at 2022-06-11 02:20:35.198893
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_all_fact_subsets = {
        "a": [object()],
        "b": [object()],
        "c": [object()],
    }
    test_all_fact_subsets["a"][0].required_facts = set(["b"])
    test_all_fact_subsets["c"][0].required_facts = set(["b", "d"])

    assert set(["d"]) == find_unresolved_requires(["a", "c"], test_all_fact_subsets)

    # b is implicitly required by a and c
    assert set(["d", "b"]) == find_unresolved_requires(["a"], test_all_fact_subsets)

    # b is implicitly required by c
    assert set(["d", "b"]) == find_unres

# Generated at 2022-06-11 02:20:44.353047
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)
    class TestCollector:
        name = 'test_collector'
        required_facts = set()
    class TestCollectorDep:
        name = 'test_collector_dep'
        required_facts = set(['test_collector_dep_req'])
    class TestCollectorDepDep:
        name = 'test_collector_dep_dep'
        required_facts = set(['test_collector_dep_dep_req'])
    all_fact_subsets['test_collector'].append(TestCollector)
    all_fact_subsets['test_collector_dep_dep'].append(TestCollectorDepDep)
    all_fact_subsets['test_collector_dep'].append(TestCollectorDep)
    assert find_un

# Generated at 2022-06-11 02:21:17.883294
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test minimal_gather_subset handling
    assert set(['minimal_collector']) == set(get_collector_names(
        minimal_gather_subset=frozenset(['minimal_collector']),
        gather_subset=['all']))

    assert set(['minimal_collector',
                'not_set_as_min']) == set(get_collector_names(
        minimal_gather_subset=frozenset(['minimal_collector']),
        gather_subset=['all', 'not_set_as_min']))


# Generated at 2022-06-11 02:21:28.240556
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.distribution.fedora as fedora

    class TestFactCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    tc1 = TestFactCollector()
    tc2 = TestFactCollector()
    tc3 = TestFactCollector()

    mock_collectors = [tc1, tc2, tc3]

    for collector in mock_collectors:
        collector._fact_ids.add('test')

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(mock_collectors)

# Generated at 2022-06-11 02:21:39.105363
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # pylint: disable=W0212,C0111
    from ansible.module_utils.facts.platform.bsd import BSD
    from ansible.module_utils.facts.platform.linux import Linux
    from ansible.module_utils.facts.plugin.ios import IOS
    from ansible.module_utils.facts.plugin.iosxr import IOSXR


    class TestCollector(BaseFactCollector):
        _fact_ids = {'A', 'B'}

    class TestCollector2(BaseFactCollector):
        _fact_ids = {'C', 'D'}

    class TestCollector3(BaseFactCollector):
        _fact_ids = {'E'}
