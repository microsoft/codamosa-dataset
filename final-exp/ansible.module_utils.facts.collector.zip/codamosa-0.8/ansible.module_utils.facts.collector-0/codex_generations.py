

# Generated at 2022-06-11 02:12:05.251603
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test "all"
    all_fact_subsets = {'all': [1, 2, 3, 4]}
    collector_names = ['all']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [1, 2, 3, 4]

    # Test "all" and extras
    all_fact_subsets = {'all': [1, 2, 3, 4], 'extra1': [1], 'extra2': [4]}
    collector_names = ['all', 'extra1', 'extra2']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [1, 2, 3, 4]

    # Test "all

# Generated at 2022-06-11 02:12:14.216231
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test invalid input
    assert find_unresolved_requires(None, {'fact1': [1]}) == set()
    assert find_unresolved_requires([], None) == set()
    assert find_unresolved_requires([], {}) == set()
    assert find_unresolved_requires([], {'fact1': [1]}) == set()
    assert find_unresolved_requires([], {'collector1': [],
                                         'collector2': [],
                                         'collector3': None,
                                         'collector4': ['a']}) == set()
    assert find_unresolved_requires([], {}) == set()

    # Test the normal case

# Generated at 2022-06-11 02:12:22.049151
# Unit test for function tsort
def test_tsort():
    success_case = {
        'cat': set(['dog']),
        'dog': set(),
        'mouse': set(['cat']),
    }
    result = tsort(success_case)
    expected = [('dog', set()), ('cat', set(['dog'])), ('mouse', set(['cat']))]
    assert result == expected, result

    failure_case = {
        'cat': set(['dog']),
        'dog': set(['cat']),
    }
    try:
        tsort(failure_case)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, "We should always throw an exception!"



# Generated at 2022-06-11 02:12:30.951985
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class FakeLinux(BaseFactCollector):
        _fact_ids = set(['linux'])
        name = 'linux'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls

    assert find_collectors_for_platform([FakeLinux],
                                        [{'system': 'Linux'}]) == {FakeLinux}

    assert find_collectors_for_platform([FakeLinux],
                                        [{'system': 'Darwin'}]) == set()



# Generated at 2022-06-11 02:12:41.988519
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import pytest

    class MyCollectorA(BaseFactCollector):
        _fact_ids = {'a', 'aa'}
        name = 'a'

    class MyCollectorB(BaseFactCollector):
        _fact_ids = {'b', 'bb'}
        name = 'b'

    class MyCollectorC(BaseFactCollector):
        _fact_ids = {'c', 'cc'}
        name = 'c'

    all_collectors = {
        (MyCollectorA, []),
        (MyCollectorB, []),
        (MyCollectorC, []),
    }

    map, aliases_map = build_fact_id_to_collector_map(all_collectors)

    assert 'a' in map
    assert 'aa' in map

# Generated at 2022-06-11 02:12:49.566707
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.network.junos import JunosDefault, JunosLegacy
    from ansible.module_utils.facts.network.generic import GenericBond
    platform_info = {
                    'system': 'Junos',
                    'network': {
                        'interfaces': {
                            'ge-0/0/0': {
                                'type': 'ethernetCsmacd',
                                'physical': True
                            }
                        }
                    }
                }
    all_collector_classes = (JunosDefault, JunosLegacy, GenericBond)
    assert(len(find_collectors_for_platform(all_collector_classes, (platform_info, platform_info))) == 2)



# Generated at 2022-06-11 02:12:59.476525
# Unit test for function get_collector_names
def test_get_collector_names():
    # We've two dictionaries:
    # 1. aliases_map -- Maps fact subsets to fact collector names (e.g. 'hardware' -> ['dmi', 'devices'])
    # 2. valid_subsets -- Maps fact collector names to fact subsets (e.g. 'dmi' -> 'hardware')
    from ansible.module_utils.facts.collector import valid_subsets as v
    aliases_map = {v['hardware']:{'dmi', 'devices'}}
    # Minimal set of fact collectors are also a subset of valid_subsets
    minimal_gather_subset = frozenset(v['hardware'])
    map_valid_subsets = {v[k]:k for k in v}

    # Case 1a: gather_subset is not provided.
    #          In that case,

# Generated at 2022-06-11 02:13:09.060500
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector(BaseFactCollector):
        _platform = 'Generic'
        name = 'foo'

    class HPCollector(BaseFactCollector):
        _platform = 'HP-UX'
        name = 'hp'

    test_collectors = [Collector, HPCollector]

    found_collectors = find_collectors_for_platform(test_collectors, [{'system': 'Generic'}])
    assert len(found_collectors) == 1
    assert Collector in found_collectors

    found_collectors = find_collectors_for_platform(test_collectors, [{'system': 'Linux'}])
    assert len(found_collectors) == 1
    assert Collector in found_collectors


# Generated at 2022-06-11 02:13:15.503798
# Unit test for function tsort
def test_tsort():
    try:
        tsort(dict(a=['b', 'c'], b=['c', 'd'], c=[], d=['c']))
        assert False, 'did not catch cycle'
    except CycleFoundInFactDeps:
        pass

    assert tsort(dict(a=['b', 'c'], b=['c'], c=[])) == [('c', set()), ('b', {'c'}), ('a', {'b', 'c'})]



# Generated at 2022-06-11 02:13:24.088632
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible_collections.ansible.community.tests.unit.unit.mock import Mock

    selected_collector_classes = select_collector_classes(['a'],
                                                          {'a': [Mock(), Mock()],
                                                           'b': [Mock(), Mock()]
                                                           })

    # Assert collected facts does not contain facts about 'b'
    for fact_id in selected_collector_classes:
        if fact_id == 'b':
            assert False
        else:
            assert True



# Generated at 2022-06-11 02:13:35.320057
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['a'], {'a': set()}) == {'a': set()}
    assert build_dep_data(['a', 'b'], {'a': set(), 'b': set()}) == {'a': set(), 'b': set()}
    assert build_dep_data(['a'], {'a': set([1])}) == {'a': set([1])}



# Generated at 2022-06-11 02:13:46.130721
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = set(['b', 'c', 'a'])

    all_fact_subsets = {'a': [unittest_Obj1, unittest_Obj2],
                        'b': [unittest_Obj1, unittest_Obj3],
                        'c': [unittest_Obj2, unittest_Obj3],
                        'd': [unittest_Obj1, unittest_Obj2],
                        'e': [unittest_Obj2, unittest_Obj3]}

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['e'])



# Generated at 2022-06-11 02:13:55.232274
# Unit test for function get_collector_names
def test_get_collector_names():

    # non-negative logic
    assert get_collector_names(valid_subsets=set(['one', 'two', 'three']),
                               minimal_gather_subset=set(['min']),
                               aliases_map={'top': {'one', 'two'}},
                               gather_subset=['min', 'one', 'three']) == {'one', 'min', 'three'}

    # Negative logic
    assert get_collector_names(valid_subsets=set(['one', 'two', 'three']),
                               minimal_gather_subset=set(['min']),
                               aliases_map={'top': {'one', 'two'}},
                               gather_subset=['min', '!one', 'three']) == {'min', 'three'}

    # aliases

# Generated at 2022-06-11 02:14:07.430144
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires on some sample data

    '''
    dummy_dict = {'all': 'black'}
    expected_unresolved = set()
    assert find_unresolved_requires(expected_unresolved, dummy_dict) == expected_unresolved

    # insures that a missing collector_name doesn't fail to return the missing name
    expected_unresolved = set(['collector_name'])
    assert find_unresolved_requires(expected_unresolved, dummy_dict) == expected_unresolved

    sample_dict = {
        'a': [object, object],
        'b': [object, object],
        'c': [object, object],
        'd': [object, object],
        'e': [object, object]
    }


# Generated at 2022-06-11 02:14:15.731003
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.cpu import ProcessorFactCollector
    from ansible.module_utils.facts.collector.mount import MountFactCollector

    all_fact_subsets = {
        'cpu': [ProcessorFactCollector],
        'mount': [MountFactCollector],
    }
    collector_names = ['cpu', 'mount']
    expected_result = {
        'cpu': set(),
        'mount': {'cpu'},
    }
    result = build_dep_data(collector_names, all_fact_subsets)
    assert result == expected_result



# Generated at 2022-06-11 02:14:26.463360
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test for find_unresolved_requires function'''
    class TC1:
        required_facts = set(('rez',))
    class TC2:
        required_facts = set(('baz',))
    class TC3:
        required_facts = set(('foo',))
    class TC4:
        required_facts = set(('foo', 'baz', 'bar'))
    class TC5:
        required_facts = set()
    class TC6:
        required_facts = set(('rez', 'baz', 'foo'))

    subset_tc1 = {'tc1': [TC1]}
    subset_tc1_tc2 = {'tc1': [TC1], 'tc2': [TC2]}

# Generated at 2022-06-11 02:14:37.706451
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = ['B']
    class B(BaseFactCollector):
        name = 'B'
        required_facts = ['C']
    class C(BaseFactCollector):
        name = 'C'
        required_facts = []
    class D(BaseFactCollector):
        name = 'D'
        required_facts = ['A', 'C']

    all_subset_info = {'A': [A],
                       'B': [B],
                       'C': [C],
                       'D': [D]}
    expected_deps = {'A': {'B'},
                     'B': {'C'},
                     'C': {'C'},
                     'D': {'A', 'C'}}
    deps_in

# Generated at 2022-06-11 02:14:47.300856
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector(BaseFactCollector):
        _fact_ids = set([])
        name = None
        required_facts = set()

        def __init__(self):
            super(Collector, self).__init__()

    class CollectorA(Collector):
        _fact_ids = set(['a', 'b'])
        name = 'a'
        required_facts = set()

        def __init__(self):
            super(CollectorA, self).__init__()

    class CollectorB(Collector):
        _fact_ids = set(['c'])
        name = 'b'
        required_facts = set()

        def __init__(self):
            super(CollectorB, self).__init__()

    fact_id_to_collector_map, aliases_map = build_fact_id

# Generated at 2022-06-11 02:15:00.119751
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.default import DefaultCollector
    from ansible.module_utils.facts import collector
    import types
    import re

    is_collector = lambda obj: ((
        isinstance(obj, type) and issubclass(obj, BaseFactCollector) and
        obj != BaseFactCollector and
        '_platform' in obj.__dict__ and
        isinstance(obj._platform, str) and
        'name' in obj.__dict__ and
        isinstance(obj.name, str
                   ) and
        'required_facts' in obj.__dict__ and
        isinstance(obj.required_facts, set
                   )
    ))

    collectors_set = set()


# Generated at 2022-06-11 02:15:09.912277
# Unit test for function build_dep_data
def test_build_dep_data():
    # test helper for build_dep_data
    class Dummy:
        def __init__(self, required_facts):
            self.required_facts = required_facts

    collectors = {
        1: [Dummy(required_facts=['b', 'c'])],
        2: [Dummy(required_facts=['c', 'd'])],
        3: [Dummy(required_facts=['e', 'f'])],
        4: [Dummy(required_facts=['e', 'f'])],
        5: [Dummy(required_facts=['c', 'd', 'e', 'f'])],
    }

    test_collector_names = ['c', 'a', 'b', 'd', 'f', 'e']

# Generated at 2022-06-11 02:15:24.336435
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'name1': ['fact1', 'fact2'], 'name2': ['fact3', 'fact4']}
    collector_names = ['name1', 'name2']
    assert build_dep_data(collector_names, all_fact_subsets) == {'name1': set(), 'name2': set()}



# Generated at 2022-06-11 02:15:35.448829
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.hardware.dell
    import ansible.module_utils.facts.network.ios

    all_collector_classes = set([collector.Hardware, collector.Network,
                                 ansible.module_utils.facts.hardware.dell.Hardware,
                                 ansible.module_utils.facts.network.ios.Network])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)
    assert 'hardware' in fact_id_to_collector_map
    assert isinstance(fact_id_to_collector_map['hardware'][0], collector.Hardware)
    assert 'network' in fact_id_to_collector

# Generated at 2022-06-11 02:15:43.206731
# Unit test for function build_dep_data
def test_build_dep_data():
    cclass = type('CC', (object,), {'name': 'sample', 'required_facts': ['sample_dep']})
    all_fact_subsets = {'sample': [cclass]}
    dm = build_dep_data(['sample'], all_fact_subsets)
    assert dm['sample'] == {'sample_dep'}
    assert dm['sample_dep'] == set()



# Generated at 2022-06-11 02:15:55.235448
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['not_present'])
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['B'])
    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D', 'A'])

    seen_classes = set()
    seen_names = set()
    all_fact_subsets = defaultdict(list)


# Generated at 2022-06-11 02:16:05.276470
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['c'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a', 'c'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b', 'c'])

    all_fact_subsets = {
        'a': [A, ],
        'b': [B, ],
        'c': [C, ],
        'd': [D, ]
    }

    collector_names = ['a', 'b', 'c', 'd']
    unresolved = find_unres

# Generated at 2022-06-11 02:16:16.601193
# Unit test for function find_unresolved_requires

# Generated at 2022-06-11 02:16:27.960587
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import sys

    # test that the optional dmidecode is found if available
    # only run this test if we are on linux.
    if platform.system() == 'Linux':
        try:
            import dmidecode
            linux_platform_info = {'system': 'Linux', 'distribution': 'Ubuntu'}
            all_collectors = [BaseFactCollector, BaseDMI]
            collectors = find_collectors_for_platform(all_collectors, [linux_platform_info])
            assert len(collectors) == 2
            assert BaseFactCollector in collectors
            assert BaseDMI in collectors
        except ImportError:
            pass

    # Test for an unknown platform.
    all_collectors = [BaseFactCollector, BaseDMI]

# Generated at 2022-06-11 02:16:37.301928
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': ['b', 'd', 'e'],
        'b': ['f', 'e'],
        'c': ['a', 'd'],
        'd': ['f'],
        'e': ['f'],
        'f': [],
        'z': [],
        }

# Generated at 2022-06-11 02:16:48.731262
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'test1'
    class Collector2(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'test2'
    class Collector3(BaseFactCollector):
        _platform = 'SunOS'
        name = 'test3'
    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'test4'

    all_collectors = (Collector1, Collector2, Collector3, Collector4)
    linux_info = dict(system='Linux')
    freebsd_info = dict(system='FreeBSD')
    sunos_info = dict(system='SunOS')
    osx_info = dict(system='Darwin')
    generic_info = dict(system='Generic')

   

# Generated at 2022-06-11 02:16:59.902016
# Unit test for function get_collector_names
def test_get_collector_names():
    # Retrieve module parameters
    gather_subset = ['all']

    # the list of everything that 'all' expands to
    valid_subsets = frozenset()

    # if provided, minimal_gather_subset is always added, even after all negations
    minimal_gather_subset = frozenset()

    # Retrieve all facts elements
    additional_subsets = set()
    exclude_subsets = set()

    # total always starts with the min set, then
    # adds of the additions in gather_subset, then
    # excludes all of the excludes, then add any explicitly
    # requested subsets.
    gather_subset_with_min = ['min']
    gather_subset_with_min.extend(gather_subset)

    # subsets we mention in gather_subset explicitly, except for '

# Generated at 2022-06-11 02:17:44.380794
# Unit test for function get_collector_names
def test_get_collector_names():
    """Unit test for function get_collector_names.

    By default it will test the module, but if you instantiate the class
    it can be used to test the class as it is used in Ansible.
    """
    # pylint: disable=too-few-public-methods
    # pylint: disable=too-many-public-methods

    class ModuleStub:
        """Class stub for module parameter access."""
        # pylint: disable=too-few-public-methods
        def __init__(self, gather_subset=None):
            self.params = {
                'gather_subset': gather_subset or ['all'],
            }

    # pylint: disable=no-member
    # pylint: disable=unused-variable
    # pylint: disable=too

# Generated at 2022-06-11 02:17:54.896096
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = frozenset(('a', 'x'))

    class TestCollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = frozenset(('b', 'x'))

    class TestCollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = frozenset(('c', 'x'))

    class TestCollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = frozenset(('d', ))

    class TestCollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = frozenset(('e', ))

    class TestCollectorF(BaseFactCollector):
        name

# Generated at 2022-06-11 02:18:04.111033
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit tests for function find_unresolved_requires'''

    class A(BaseFactCollector):
        _fact_ids = ['A']
        required_facts = set()

    class B(BaseFactCollector):
        _fact_ids = ['B']
        required_facts = set(['A'])

    class C(BaseFactCollector):
        _fact_ids = ['C']
        required_facts = set(['B'])

    class D(BaseFactCollector):
        _fact_ids = ['D']
        required_facts = set(['A'])

    all_fact_subsets = {'A': [A],
                        'B': [B],
                        'C': [C],
                        'D': [D]}

    # Each test case is a tuple of (input, output)
    test_

# Generated at 2022-06-11 02:18:11.276236
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.linux import OSFactCollector
    from ansible.module_utils.facts.collector.linux import DistributionFactCollector
    from ansible.module_utils.facts.collector.networking import NetworkingFactCollector
    fname_to_collector_class = {'os': OSFactCollector, 'distribution': DistributionFactCollector, 'networking': NetworkingFactCollector}
    collector_classes = [fname_to_collector_class[fname] for fname in ['os', 'distribution', 'networking']]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_classes)


# Generated at 2022-06-11 02:18:23.480352
# Unit test for function build_dep_data
def test_build_dep_data():
    '''Tests the build_dep_data function'''
    # build collector classes to test with
    class FakeCollector1(BaseFactCollector): name = 'one'
    class FakeCollector2(BaseFactCollector): name = 'two'
    class FakeCollector3(BaseFactCollector): name = 'three'
    class FakeCollector4(BaseFactCollector): name = 'four'; required_facts = ('two', )
    class FakeCollector5(BaseFactCollector): name = 'five'; required_facts = ('three', 'one')

    # build fake all_fact_subsets to test with

# Generated at 2022-06-11 02:18:32.375116
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import LegacyFactCollector
    class TestCollector1(LegacyFactCollector):
        name = 'testcollector1'
        required_facts = {'required_fact1'}

    class TestCollector2(LegacyFactCollector):
        name = 'testcollector2'
        required_facts = {'required_fact2'}

    class TestCollector3(LegacyFactCollector):
        name = 'testcollector3'
        required_facts = {'required_fact1', 'required_fact2'}

    test_subsets = {'testcollector1': [TestCollector1],
                    'testcollector2': [TestCollector2],
                    'testcollector3': [TestCollector3]}

    # Test with no unresolved, should return empty set
    all_

# Generated at 2022-06-11 02:18:43.052329
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(None)
    assert {} == fact_id_to_collector_map
    assert {} == aliases_map

    fact_input = {'test1': set(['test1']), 'test2': set(['test1']), 'test3': set(['test3'])}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(fact_input)
    assert {'test1': list(['test1', 'test2']), 'test3': list(['test3'])} == fact_id_to_collector_map

# Generated at 2022-06-11 02:18:53.908524
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class MockCollector1(BaseFactCollector):
        _fact_ids = set(['mock_collector_1'])

        _platform = 'Linux'
        name = 'mock_collector_1'
        required_facts = set()

    class MockCollector2(BaseFactCollector):
        _fact_ids = set(['mock_collector_2'])

        _platform = 'Linux'
        name = 'mock_collector_2'
        required_facts = set()

    class MockCollector3(BaseFactCollector):
        _fact_ids = set(['mock_collector_3'])

        _platform = 'Linux'
        name = 'mock_collector_3'
        required_facts = set()


# Generated at 2022-06-11 02:19:07.016192
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class MockFactCollector(BaseFactCollector):
        name = 'sample_facts'
        required_facts = ['fact']

    class MockFactCollector2(BaseFactCollector):
        name = 'sample_facts_2'
        required_facts = ['fact_2']

    class MockFactCollector3(BaseFactCollector):
        name = 'sample_facts_3'
        required_facts = ['fact_2']


    all_collector_classes = [MockFactCollector, MockFactCollector2, MockFactCollector3]
    valid_subsets = frozenset(['sample_facts', 'sample_facts_2', 'sample_facts_3'])
    minimal_gather_subset = frozenset()
    gather_subset = ['all', '!sample_facts_2']
    gather_timeout

# Generated at 2022-06-11 02:19:14.591203
# Unit test for function find_collectors_for_platform

# Generated at 2022-06-11 02:19:33.626342
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector(object):
        required_facts = set()

    def make_fake_collector_class(name, required_facts):
        class FakeCollectorClass(FakeCollector):
            name = name
            required_facts = required_facts
        return FakeCollectorClass

    from ansible.module_utils.facts import collector as col
    import ansible.module_utils.facts.collector

    # TODO: this is fragile. Should really have our own CollectorRegistry class to use
    #       here. The concern is that the CollectorRegistry is a classmethod and there
    #       may be some side-effect to calling it.
    saved = ansible.module_utils.facts.collector.CollectorRegistry
    ansible.module_utils.facts.collector.CollectorRegistry = col.CollectorRegistry


# Generated at 2022-06-11 02:19:43.172446
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector

    class CollectorSubclass(collector.BaseFactCollector):
        name = 'myclass'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls.name:
                return cls
            return None

    assert find_collectors_for_platform({CollectorSubclass}, [dict(system='myclass')]) == set([CollectorSubclass])
# end unit test



# Generated at 2022-06-11 02:19:47.381044
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform(): #pylint: disable=too-many-locals
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector.linux import LinuxDmiFactCollector
    from ansible.module_utils.facts.collector.linux import LinuxIPRouteFactCollector

    infos = [{
        'distribution': 'RedHat',
        'distribution_release': '7.2',
        'distribution_version': '7.2',
        'os_family': 'RedHat',
        'system': 'Linux',
    }]

    # pretend to be a linux platform
    platform.system = lambda: 'Linux'

    # now pretend to be a generic platform
    platform.system = lambda: 'Generic'


# Generated at 2022-06-11 02:20:00.617540
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'A': [object], 'B': [object], 'C': [object], 'D': [object], 'E': [object]}
    collector_names = set(['A', 'B', 'C', 'D', 'E'])
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert not dep_map['A']
    assert not dep_map['B']
    assert not dep_map['C']
    assert not dep_map['D']
    assert not dep_map['E']
    assert all_fact_subsets['A'] == dep_map['A']
    assert all_fact_subsets['B'] == dep_map['B']
    assert all_fact_subsets['C'] == dep_map['C']
    assert all_

# Generated at 2022-06-11 02:20:08.421714
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [_FakeCollector('a', required_facts='b c')],
        'b': [_FakeCollector('b', required_facts='c')],
        'c': [_FakeCollector('c')],
        'd': [_FakeCollector('d', required_facts='a b')],
        'e': [_FakeCollector('e', required_facts='f')],
    }
    assert find_unresolved_requires(['a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['d'], all_fact_subsets) == set()
    assert find_unresolved_requires(['e'], all_fact_subsets) == set(['f'])

# Generated at 2022-06-11 02:20:18.766564
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'collector_a': [TestCollectorA],
                        'collector_b': [TestCollectorB]}

    # an empty list of collectors should always return empty
    assert find_unresolved_requires([], all_fact_subsets) == set()

    # asking for a collector that doesn't use requires should still return empty
    assert find_unresolved_requires(['collector_a'], all_fact_subsets) == set()

    # asking for a collector that requires another absent collector should return that absent collector
    assert find_unresolved_requires(['collector_b'], all_fact_subsets) == {'collector_a'}



# Generated at 2022-06-11 02:20:26.052539
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Mocking classes
    class MockClass1(BaseFactCollector):
        name = "mock_collector1"
        _fact_ids = ["mock_fact1"]

    class MockClass2(BaseFactCollector):
        name = "mock_collector2"
        _fact_ids = ["mock_fact2"]

    collectors_for_platform = [MockClass1, MockClass2]
    fact_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert sorted(aliases_map.get("mock_collector1")) == ["mock_fact1"]
    assert sorted(aliases_map.get("mock_collector2")) == ["mock_fact2"]

# Generated at 2022-06-11 02:20:30.846083
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collectors.system import SystemCollector

    all_collector_classes = [SystemCollector]

    # Test for finding collectors for a list of platforms
    compare_platforms = [{'system': 'Linux'}, {'system': 'Linux', 'distribution': 'Ubuntu'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compare_platforms)
    assert len(found_collectors) == 1
    assert found_collectors.pop().name == 'SystemCollector'

    # Test for finding collectors for a single platform
    compare_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compare_platforms)

# Generated at 2022-06-11 02:20:36.400636
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'foo': [
            type('', (BaseFactCollector,), {'name': 'foo', 'required_facts': ['bar']}),
        ],
        'bar': [
            type('', (BaseFactCollector,), {'name': 'bar', 'required_facts': ['biz']}),
        ],
        'biz': [
            type('', (BaseFactCollector,), {'name': 'biz', 'required_facts': []}),
        ],
    }
    collector_names = ['foo']
    dep_data = build_dep_data(collector_names, all_fact_subsets)
    assert dep_data == {
        'foo': set(['bar']),
        'bar': set(['biz']),
        'biz': set([]),
    }

# Generated at 2022-06-11 02:20:45.181944
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [MockCollectorClass('a', ('b', 'c'))],
                        'b': [MockCollectorClass('b', ('d',))],
                        'c': [MockCollectorClass('c', ())],
                        'd': [MockCollectorClass('d', ())]}
    collector_names = ['a', 'b', 'c', 'd']

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'d'}

    collector_names = ['a', 'c']

# Generated at 2022-06-11 02:21:02.697219
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collectors = dict(a=BaseFactCollector(name='a'),
                      b=BaseFactCollector(name='b', required_facts=['a']),
                      c=BaseFactCollector(name='c', required_facts=['b']),
                      d=BaseFactCollector(name='d', required_facts=['c']),
                      e=BaseFactCollector(name='e', required_facts=['c']),
                      f=BaseFactCollector(name='f', required_facts=['d']),
                      g=BaseFactCollector(name='g', required_facts=['d']),
                      h=BaseFactCollector(name='h', required_facts=['f']),
                      i=BaseFactCollector(name='i', required_facts=['g'])
                      )


# Generated at 2022-06-11 02:21:13.923144
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ('test', 'alias')

    class TestCollector2(TestCollector):
        name = 'test2'
        _fact_ids = ('test2', 'alias2')

    class TestCollector3(TestCollector):
        name = 'test'
        _fact_ids = ('test3', )

    collectors_for_platform = (TestCollector, TestCollector2, TestCollector3)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert ('test', 'alias') == tuple(fact_id_to_collector_map['test'][0]._fact_ids)

# Generated at 2022-06-11 02:21:23.354228
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class DummyCollector(BaseFactCollector):
        name = None
        required_facts = ['bar']

    class DummyCollector1(BaseFactCollector):
        name = 'foo'
        required_facts = ['bar']

    class DummyCollector2(BaseFactCollector):
        name = 'baz'
        required_facts = []

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['foo'].append(DummyCollector1)
    all_fact_subsets['baz'].append(DummyCollector2)

    # baz has no required_facts, so we should find nothing.
    assert find_unresolved_requires(['baz'], all_fact_subsets) == set()

    # foo has a required fact 'bar'
    unresolved_foo

# Generated at 2022-06-11 02:21:34.775017
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Test to make sure that the multiple collectors are added
    '''
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = ['foo', 'bar']

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = ['foo']

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = ['foo']

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({Collector1, Collector2, Collector3})
    assert fact_id_to_collector_map['collector1'] == [Collector1]

# Generated at 2022-06-11 02:21:42.013520
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector

    # Create a platform specific collector
    class Linux_Platform(PlatformFactCollector):
        name = 'platform'
        _fact_ids = PlatformFactCollector._fact_ids

        _platform = 'Linux'

    # Create a generic collector
    class Collector_A(BaseFactCollector):
        name = 'collector_a'
        _fact_ids = {'collector_a_fact'}

        # Create a requirement for this fact
        required_facts = {'platform'}

    # Create a generic collector
    class Collector_B(BaseFactCollector):
        name = 'collector_b'