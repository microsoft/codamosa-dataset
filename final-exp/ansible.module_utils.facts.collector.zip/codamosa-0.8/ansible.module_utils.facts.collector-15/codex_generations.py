

# Generated at 2022-06-11 02:11:58.166323
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = {'fact_id_1'}
        name = 'TestCollector1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = {'fact_id_1', 'fact_id_2'}
        name = 'TestCollector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = {'fact_id_1'}
        name = 'TestCollector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = {'fact_id_1', 'fact_id_2'}
        name = 'TestCollector4'


# Generated at 2022-06-11 02:12:04.268906
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''test_build_fact_id_to_collector_map'''

    gbc = GenericBaseCollector
    gbc.name = 'generic'
    gbc._fact_ids = frozenset(['generic1', 'generic2'])

    nbc = NetworkBaseCollector
    nbc.name = 'network'
    nbc._fact_ids = frozenset(['network1', 'network2'])

    hbc = HardwareBaseCollector
    hbc.name = 'hardware'
    hbc._fact_ids = frozenset(['hardware1', 'hardware2', 'devices'])

    sbc = StorageBaseCollector
    sbc.name = 'storage'
    sbc._fact_ids = frozenset(['storage1', 'storage2'])


# Generated at 2022-06-11 02:12:09.635669
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.system.linux import LinuxFactCollector
    class A(BaseFactCollector):
        _fact_ids = set(["a"])
        _platform = 'Linux'
        name = 'a'
        required_facts = set()

    class B(BaseFactCollector):
        _fact_ids = set(["b"])
        _platform = 'Linux'
        name = 'b'
        required_facts = set()

    class C(BaseFactCollector):
        _fact_ids = set(["c"])
        _platform = 'Linux'
        name = 'c'
        required_facts = set()


# Generated at 2022-06-11 02:12:19.983617
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test 1
    test_name = 'should select all collectors if no dependencies'
    a_collector = type('ACollector', (BaseFactCollector,), {'name': 'a'})
    b_collector = type('BCollector', (BaseFactCollector,), {'name': 'b'})

    all_fact_subsets = {'a': [a_collector],
                        'b': [b_collector]}
    collector_names = frozenset(['a', 'b'])
    expected = [a_collector, b_collector]

    actual = select_collector_classes(collector_names, all_fact_subsets)
    assert actual == expected, 'Test "%s" failed.' % test_name

    # Test 2

# Generated at 2022-06-11 02:12:31.946429
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    all_collectors = (
        NetworkConfigCollector,
        HardwareCollector,
        VirtualizationCollector,
        NetworkInterfacesCollector,
        IPRouteCollector,
        IPRulesCollector,
        RepoCollector,
        ModuleCollector,
    )
    compat_platforms = [
        {'system': 'Linux'},
        {'system': 'AIX'},
        {'system': 'Generic'},
    ]

    collectors_for_platform = find_collectors_for_platform(all_collectors, compat_platforms)
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert len(fact_id_to_collector_map) == 34

# Generated at 2022-06-11 02:12:43.524981
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from . import collectors
    from . import selinux
    list_of_collector_classes = [
        collectors.LinuxFactCollector,
        collectors.SelinuxFactCollector
    ]
    all_fact_subsets = build_fact_id_to_collector_map(list_of_collector_classes)[0]
    try:
        find_unresolved_requires(("selinux",), all_fact_subsets)
        assert True
    except UnresolvedFactDep:
        assert False

    try:
        find_unresolved_requires(("linux",), all_fact_subsets)
        assert False
    except UnresolvedFactDep:
        assert True


# Generated at 2022-06-11 02:12:53.550331
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = {
        'collector1' : set(['collector2', 'collector5']),
        'collector2' : set(['collector3', 'collector4']),
        'collector3' : set(['collector5']),
        'collector4' : set(),
        'collector5' : set()
        }
    collector_names = set(dep_map.keys())
    all_fact_subsets = {}
    for name in collector_names:
        all_fact_subsets[name] = [BaseFactCollector]

    assert build_dep_data(collector_names, all_fact_subsets) == dep_map



# Generated at 2022-06-11 02:13:01.737463
# Unit test for function tsort

# Generated at 2022-06-11 02:13:10.078007
# Unit test for function get_collector_names
def test_get_collector_names():
    class ModuleMock:
        def __init__(self, params):
            self.params = params

        def get_option(self, key):
            return self.params.get(key)

    # Tests
    module_mock = ModuleMock({'gather_subset': ['!all']})
    assert set(get_collector_names(set(['min']), None, None, module_mock)) == set(['min'])

    module_mock = ModuleMock({'gather_subset': ['!min']})
    assert set(get_collector_names(set(['all']), set(['min']), None, module_mock)) == set(['all'])

    module_mock = ModuleMock({'gather_subset': ['!all', '!min', 'os']})


# Generated at 2022-06-11 02:13:18.688720
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = ['test1']
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ['test2']

    all_fact_subsets = {
        'test1': [TestCollector1],
        'test2': [TestCollector2, TestCollector1]
    }

    assert select_collector_classes(['test1'], all_fact_subsets) == [TestCollector1]
    assert select_collector_classes(['test2'], all_fact_subsets) == [TestCollector2, TestCollector1]

# Generated at 2022-06-11 02:13:33.901023
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'a':[FakeCollector('a',['b']),FakeCollector('a',['b','c'])],
                        'b':[FakeCollector('b',['c'])],
                        'c':[FakeCollector('c',['d']),FakeCollector('c',['d','e'])]
                       }
    collector_names = ['a','b']

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    # Expected dep_map
    # {'a': {'b', 'c'}, 'b': {'c'}}
    assert len(dep_map) == 2
    assert set(dep_map.keys()) == set(['a','b'])

# Generated at 2022-06-11 02:13:41.652660
# Unit test for function tsort
def test_tsort():
    from itertools import permutations

    def tsort_test(unsorted_map, expected_result):
        result = tsort(unsorted_map)
        assert result == expected_result

    tsort_test(
        {'a': set(['b']), 'b': set(['c']), 'c': set()},
        [('c', set()), ('b', set(['c'])), ('a', set(['b']))]
    )


# Generated at 2022-06-11 02:13:48.286994
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # if no matches, we should return an empty set
    assert find_collectors_for_platform([], []) == set()

    class NotAMatch(BaseFactCollector):
        _platform = 'NotAmatch'
    assert find_collectors_for_platform([NotAMatch], [dict(system='Linux')]) == set()

    class MatchA(BaseFactCollector):
        _platform = 'Match'
    class MatchB(BaseFactCollector):
        _platform = 'Match'
    assert find_collectors_for_platform([MatchA, MatchB], [dict(system='Match')]) == set([MatchA, MatchB])

    class LinuxAMatch(BaseFactCollector):
        _platform = 'Linux'
    class BSDAMatch(BaseFactCollector):
        _platform = 'BSD'

# Generated at 2022-06-11 02:13:56.327836
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['one', 'two', 'three', 'four']
    all_fact_subsets = {'one': [{'required_facts': ['two', 'three', 'four']},
                                {'required_facts': ['two', 'three']}
                                ],
                        'two': [{'required_facts': ['three']}
                                ],
                        'three': [{'required_facts': ['four']}
                                  ],
                        'four': [{'required_facts': []}]
                        }
    dep_map = defaultdict(set)
    for collector_name in collector_names:
        collector_deps = set()
        for collector in all_fact_subsets[collector_name]:
            for dep in collector.required_facts:
                collector_deps.add(dep)
        dep_

# Generated at 2022-06-11 02:14:08.218318
# Unit test for function build_dep_data
def test_build_dep_data():
    collectors = {'collector_1': [object()],
                  'collector_2': [object()]}
    collector_names = set(collectors.keys())

    class FakeCollector:
        def __init__(self, required_facts):
            self.required_facts = required_facts

    def create_dep_data(collector_id, dep_id):
        return FakeCollector([dep_id])
    dep_data = build_dep_data(collector_names, collectors)
    assert dep_data == {'collector_1': set(), 'collector_2': set()}

    collectors = {'collector_1': [FakeCollector(['dep_1'])],
                  'collector_2': [FakeCollector(['dep_2'])]}
    collector_names = set(collectors.keys())

# Generated at 2022-06-11 02:14:14.199514
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {}
    dep_map = defaultdict(set)
    dep_map['a'] = set()
    dep_map['b'] = set()
    dep_map['c'] = set()

    data = build_dep_data(collector_names, all_fact_subsets)
    assert dict(data) == dict(dep_map)


# Generated at 2022-06-11 02:14:24.612801
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts._collector import BaseFactCollector
    from ansible.module_utils.facts.system import DistributionFactCollector
    from ansible.module_utils.facts.system import DomainFactCollector
    tests = [
        (['hostname', 'facter'],
         {'hostname': {'facter'}, 'facter': {'system'}, 'system': set()},
         ),
        (['all'],
         {'all': {'facter'}, 'facter': set(), 'system': set()},
         )
    ]

    class TestCollector(BaseFactCollector):
        _fact_ids = []
        _platform = None
        name = 'facter'
        required_facts = {'system'}


# Generated at 2022-06-11 02:14:31.563383
# Unit test for function build_dep_data
def test_build_dep_data():
    test_cases = (
        (
            ['foo', 'bar'],
            {
                'bar': {'foo'},
                'foo': {},
            },
        ),
        (
            ['foo', 'bar', 'baz'],
            {
                'bar': {'foo'},
                'foo': {},
                'baz': {'foo', 'bar'},
            },
        ),
    )
    for names, expected in test_cases:
        dep_data = build_dep_data(names, all_fact_subsets={n: {} for n in names})
        assert dep_data == expected



# Generated at 2022-06-11 02:14:42.981967
# Unit test for function build_dep_data
def test_build_dep_data():
    test_map = {
        'fact_a': ['fact_b'],
        'fact_b': ['fact_c'],
        'fact_c': ['fact_d'],
        'fact_b1': ['fact_c1'],
    }
    expected = {
        'fact_a': ['fact_b'],
        'fact_b': ['fact_c', 'fact_a'],
        'fact_c': ['fact_d', 'fact_b'],
        'fact_b1': ['fact_c1'],
    }
    all_fact_subsets = defaultdict(list)
    for key, val in test_map.items():
        class TestClass:
            required_facts = set(val)
        all_fact_subsets[key].append(TestClass)
    result = build

# Generated at 2022-06-11 02:14:46.608304
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'test': [BaseFactCollector, BaseFactCollector]}
    collector_names = {'test'}

    # if there are two collectors with the same name (fact id)
    # then the dep_data should include duplicate entries for the same fact
    # and that is okay
    assert build_dep_data(collector_names, all_fact_subsets) == {}



# Generated at 2022-06-11 02:15:34.773330
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(('all', 'network', 'ohai', 'hardware'))

    minimal_gather_subset = frozenset(('hardware', 'network', 'ohai'))

    aliases_map = defaultdict(set, {
        'network': frozenset(('interfaces', 'default_ipv4', 'default_ipv6')),
        'hardware': frozenset(('devices', 'dmi')),
    })


# Generated at 2022-06-11 02:15:48.426680
# Unit test for function build_dep_data
def test_build_dep_data():
    from . import freebsd
    from . import generic
    from . import openbsd
    from . import solaris
    from . import linux
    from ansible.module_utils.facts.collector import build_dep_data
    # Test cases

# Generated at 2022-06-11 02:15:58.418253
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.base import BaseFactCollector
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'B'
        required_facts = {'A'}
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set()
    class D(BaseFactCollector):
        name = 'D'
        required_facts = {'A', 'C'}
    class E(BaseFactCollector):
        name = 'E'
        required_facts = {'B', 'D'}
    class F(BaseFactCollector):
        name = 'F'
        required_facts = set()

# Generated at 2022-06-11 02:16:07.273289
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n']
    expected = {'a': set(['b','c','j']),
                'b': set(['d']),
                'c': set(['e','f']),
                'd': set([]),
                'e': set(['g','h']),
                'f': set(['i']),
                'g': set([]),
                'h': set([]),
                'i': set(['j']),
                'j': set(['k','l']),
                'k': set(['l']),
                'l': set(['m']),
                'm': set(['n']),
                'n': set([])}


# Generated at 2022-06-11 02:16:18.087532
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    # test empty
    assert find_unresolved_requires([], {}) == set()

    all_fact_subsets = {
        'collector1': [Collector1],
        'collector2': [Collector2],
        'collector3': [Collector3],
        'collector4': [Collector4],
    }

    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = ('collector2',)

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = ('collector3',)

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = ()

    class Collector4(BaseFactCollector):
        name = 'collector4'

# Generated at 2022-06-11 02:16:29.284381
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class A(BaseFactCollector):
        name = 'a'
        _fact_ids = set(('a-alias',))

    class B(BaseFactCollector):
        name = 'b'
        _fact_ids = set(('b-alias',))

    class C(BaseFactCollector):
        name = 'c'
        _fact_ids = set(('c-alias',))

    class D(BaseFactCollector):
        name = 'd'
        _fact_ids = set(('d-alias',))
        _platform = 'Linux'

    class E(BaseFactCollector):
        name = 'e'
        _fact_ids = set(('e-alias',))
        _platform = 'Windows'

    class F(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-11 02:16:39.471551
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.ansible_local import AnsibleLocalCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['ansible_local'].append(AnsibleLocalCollector)
    all_fact_subsets['file_system'].append(FileSystemCollector)
    assert not find_unresolved_requires(['ansible_local'], all_fact_subsets)
    assert not find_unresolved_requires(['ansible_local', 'file_system'], all_fact_subsets)

# Generated at 2022-06-11 02:16:50.820889
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test 1.
    # Given:
    collectors = [
        type('FakeCollector0', (BaseFactCollector, ), {'name':'fake0', '_fact_ids':['fake00','fake01','fake02']}),
        type('FakeCollector1', (BaseFactCollector, ), {'name':'fake1', '_fact_ids':['fake11','fake12','fake13']}),
        type('FakeCollector2', (BaseFactCollector, ), {'name':'fake2', '_fact_ids':['fake21','fake22','fake23']}),
    ]
    # When:
    (fact_id_to_collector_map, aliases_map) = build_fact_id_to_collector_map(collectors)
    # Then:
    assert fact_id_to_collect

# Generated at 2022-06-11 02:17:02.127976
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = ['foo', 'bar']
    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = ['foo', 'baz']
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        [Collector1, Collector2]
    )
    assert fact_id_to_collector_map == {
        'collector1': [Collector1],
        'collector2': [Collector2],
        'foo': [Collector1, Collector2],
        'bar': [Collector1],
        'baz': [Collector2]
    }

# Generated at 2022-06-11 02:17:10.225932
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestCollector1, self).__init__(*args, **kwargs)
            self.name = 'test1'
            self._fact_ids = {'test1'}

    class TestCollector2(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestCollector2, self).__init__(*args, **kwargs)
            self.name = 'test2'
            self._fact_ids = {'test2', 'test3'}


# Generated at 2022-06-11 02:17:29.427503
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test 1
    valid_subsets = frozenset(['all', 'foo'])
    minimal_gather_subset = frozenset([])
    gather_subset = ['all', 'foo']
    expected_collectors = ['all', 'foo']
    aliases_map = defaultdict(set)
    aliases_map['bar'] = set(['foo'])
    result = None
    try:
        result = get_collector_names(valid_subsets, minimal_gather_subset,
                                     gather_subset, aliases_map)
    except Exception as e:
        assert False, 'Test 1 failed with exception: {0}'.format(e)
    # No exception raised
    assert result == expected_collectors

    # Test 2
    valid_subsets = frozenset(['all', 'foo'])

# Generated at 2022-06-11 02:17:37.765479
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Tests the build_fact_id_to_collector_map function'''
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([
        TestCollector1,
        TestCollector2,
    ])

    assert fact_id_to_collector_map['test1'] == [TestCollector1]
    assert fact_id_to_collector_map['test2'] == [TestCollector2]
    assert fact_id_to_collector_map['test3'] == [TestCollector2]
    assert aliases_map['test2'] == set(['test3'])
    assert aliases_map['test1'] == set([])



# Generated at 2022-06-11 02:17:47.684749
# Unit test for function build_dep_data
def test_build_dep_data():
    class ACollector(BaseFactCollector):
        name = 'a'
        required_facts = ['b', 'c']

    class BCollector(BaseFactCollector):
        name = 'b'
        required_facts = ['c']

    class CCollector(BaseFactCollector):
        name = 'c'
        required_facts = []

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': set([ACollector]), 'b': set([BCollector]), 'c': set([CCollector])})
    assert dep_map['a'] == {'b', 'c'}
    assert dep_map['b'] == {'c'}
    assert dep_map['c'] == {}



# Generated at 2022-06-11 02:17:55.955940
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from lib.collectors.parsers.cmd import Command
    from lib.collectors.parsers.conans import Conan
    from lib.collectors.parsers.system import System

    valid_subsets = frozenset(['all', 'network', 'min', 'hardware'])
    minimal_gather_subset = frozenset(['min'])


# Generated at 2022-06-11 02:17:58.856539
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_data = build_dep_data(['foo'], {'foo': ['bar', 'baz']})
    assert dep_data == {'foo': ['bar', 'baz']}



# Generated at 2022-06-11 02:18:08.608598
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:18:20.016378
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    collector_names = {'system': {'required_facts': set(), 'name': 'system'},
                       'min': {'required_facts': set(), 'name': 'min'},
                       'env': {'required_facts': set(), 'name': 'env'},
                       'all': {'required_facts': {'min', 'env'}, 'name': 'all'}}
    all_collector_classes = [{'required_facts': {'min'}, 'name': 'env'},
                             {'required_facts': set(), 'name': 'min'},
                             {'required_facts': set(), 'name': 'all'}]


# Generated at 2022-06-11 02:18:30.402127
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all']) == set(['all'])
    assert get_collector_names(['!all']) == set(['all'])
    assert get_collector_names(['min']) == set(['min'])
    assert get_collector_names(['!min']) == set(['all'])

    assert get_collector_names(['all', '!min']) == set(['all'])
    assert get_collector_names(['!min', 'all']) == set(['all'])

    assert get_collector_names(['min', '!all']) == set(['min'])
    assert get_collector_names(['!all', 'min']) == set(['min'])


# Generated at 2022-06-11 02:18:38.919429
# Unit test for function build_dep_data
def test_build_dep_data():
    mock_collector_names = {'one', 'two', 'three'}
    mock_all_fact_subsets = {'one': [MockCollector('one', {'two'})], 'two': [MockCollector('two', {'three'})], 'three': [MockCollector('three', set())]}
    expected_dep_data = {'three': set(), 'two': {'three'}, 'one': {'two'}}
    assert build_dep_data(mock_collector_names, mock_all_fact_subsets) == expected_dep_data


# Generated at 2022-06-11 02:18:43.954073
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collectors = defaultdict(list)
    collectors['foo1'] = [FooCollector('foo1')]
    collectors['foo2'] = [FooCollector('foo2')]
    collectors['foo3'] = [FooCollector('foo3')]
    assert find_unresolved_requires(['foo2', 'foo3'], collectors) == set()
    assert find_unresolved_requires(['foo2'], collectors) == set(['foo1'])



# Generated at 2022-06-11 02:19:10.923240
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.system import SystemCollector
    class TestCollector(SystemCollector):
        _fact_ids = {'test_collect'}
        name = 'test_collect'
        required_facts = {'system', 'fqdn_ip4'}

    assert build_dep_data(['test_collect'], {'test_collect': [TestCollector]}) == {'fqdn_ip4': {'test_collect'},
                                                                                   'system': {'test_collect'},
                                                                                   'test_collect': set()}
    assert build_dep_data(['system'], {'system': [SystemCollector]}) == {'system': set()}


# Generated at 2022-06-11 02:19:21.917454
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:19:33.455464
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector_a': [MockCollector(name='collector_a', required_facts=['collector_b'])],
        'collector_b': [MockCollector(name='collector_b', required_facts=['collector_c'])],
        'collector_c': [MockCollector(name='collector_c', required_facts=set())]
    }

    collector_names = set(['collector_c'])

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()
    collector_names.add('collector_b')
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()
    collector_names.add('collector_a')

# Generated at 2022-06-11 02:19:46.244893
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from . import namespaces
    from . import facts
    all_fact_subsets = facts.discover_subsets(namespaces.get_all_namespaces())

    requirers = ['kernel', 'timezone', 'virtual']
    all_subsets = frozenset(all_fact_subsets.keys()) - frozenset(requirers)
    assert find_unresolved_requires(all_subsets, all_fact_subsets) == set(requirers)
    assert find_unresolved_requires(all_subsets | set(requirers), all_fact_subsets) == set()

    assert find_unresolved_requires(set(['!distribution', 'kernel', 'virtual']), all_fact_subsets) == set(['kernel'])

# Generated at 2022-06-11 02:19:59.645964
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeDict(dict):
        def __getitem__(self, key):
            try:
                value = super(FakeDict, self).__getitem__(key)
                if value is None:
                    value = []
                return value
            except KeyError:
                return None

    collector_names = ['a', 'b', 'c', 'd']

    def _get_collector_classes(collector_name):
        return ['x'] if collector_name in collector_names else 'y'

    all_fact_subsets = FakeDict({
        'a': ['x'],
        'b': ['x'],
        'c': ['x'],
        'd': ['x']
    })

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-11 02:20:09.180609
# Unit test for function tsort
def test_tsort():
    from operator import itemgetter
    unsorted_map = defaultdict(set, {
        'A': set(['B', 'C']),
        'B': set(['C']),
        'C': set(['F', 'G']),
        'F': set(),
        'G': set('B')
    })

    sorted_list = tsort(unsorted_map)

    # check the sorting
    if not all(dep_map.issubset(sorted_map) for name, dep_map in unsorted_map.items()
               for sorted_name, sorted_map in sorted_list):

        raise AssertionError('Unsorted=%s sorted=%s' % (unsorted_map, sorted_list))

    # check that the topological order is preserved

# Generated at 2022-06-11 02:20:20.425956
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class A(BaseFactCollector):
        platform = 'Generic'
        name = 'A'
    class B(BaseFactCollector):
        platform = 'Generic'
        name = 'B'
    class C(BaseFactCollector):
        platform = 'Generic'
        name = 'C'
        _fact_ids = {'C1'}
    class D(BaseFactCollector):
        platform = 'Generic'
        name = 'D'
        _fact_ids = {'D1', 'D2'}

    actual = build_fact_id_to_collector_map([A, B, C, D])

# Generated at 2022-06-11 02:20:33.029389
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [
            type('A', (object,), {'name': 'a', 'required_facts': ['b']}),
        ],
        'b': [
            type('B', (object,), {'name': 'b'}),
        ],
    }

    # happy path
    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # a collector name is not listed
    collector_names = ['b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['a'])

    # a deps is not listed
    all_fact_subsets['a'][0].required

# Generated at 2022-06-11 02:20:42.805401
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # This test is a bit too tightly coupled to the actual ansible.module_utils.facts
    # implementation, but it is good to have something in place.
    from ansible.module_utils.facts import (
        all_collector_classes,
        collector_classes_from_names,
        get_all_fact_subsets,
    )
    # import all the local fact modules, to populate the all_collector_classes
    for fact_class in all_collector_classes:
        pass

    fact_ids = [fact_class.name for fact_class in all_collector_classes]

    # Each class.name should be in fact_ids
    for fact_class in all_collector_classes:
        assert fact_class.name in fact_ids

    # Ensure that all_fact_subsets is the same
    all_

# Generated at 2022-06-11 02:20:52.631029
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case where all dependencies are met
    collector_names = ['foo', 'bar', 'baz']
    all_fact_subsets = {'foo': [object()], 'bar': [object()], 'baz': [object()]}

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test case where one dependency is not met
    collector_names = ['foo', 'bar', 'baz']
    all_fact_subsets = {'foo': [object()], 'bar': [object()], 'baz': [object()]}

    class CollectorFoo:
        required_facts = {'foo', 'bar', 'not_there'}

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-11 02:21:32.409403
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorX(BaseFactCollector):
        name = 'X'
        required_facts = set()

    class CollectorY(BaseFactCollector):
        name = 'Y'
        required_facts = {'X'}

    class CollectorZ(BaseFactCollector):
        name = 'Z'
        required_facts = set()

    class CollectorW(BaseFactCollector):
        name = 'W'
        required_facts = {'X', 'Z'}

    all_fact_subsets = {c.name: [c] for c in [CollectorX, CollectorY, CollectorZ, CollectorW]}

    assert find_unresolved_requires(['Y'], all_fact_subsets) == {'X'}
    assert find_unresolved_requires(['Y', 'W'], all_fact_subsets)

# Generated at 2022-06-11 02:21:38.943252
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    ansible_facts_subset = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
    }

    # Requires a, b => c
    # Requires c, d => e
    # Requires e => f
    # Requires c, f => g
    # Requires b => h => a

    class C0:
        required_facts = {'a', 'b'}
    class C1:
        required_facts = {'c', 'd'}
    class C2:
        required_facts = {'e'}