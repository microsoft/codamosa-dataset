

# Generated at 2022-06-11 02:12:05.284500
# Unit test for function select_collector_classes
def test_select_collector_classes():
    test_name_set_one = ['enc1377', 'enc1377', 'enc1377', 'enc1377', 'enc1376', 'enc1376', 'enc1376']
    test_name_set_two = ['enc1377', 'enc1377', 'enc1377', 'enc1376', 'enc1376', 'enc1376', 'enc1376']
    test_name_set_three = ['enc1377', 'enc1377', 'enc1377', 'enc1377', 'enc1376', 'enc1376', 'enc1376'] # expected result
    test_name_set_four = ['enc1377', 'enc1376', 'enc1377', 'enc1376', 'enc1377', 'enc1376', 'enc1377', 'enc1376'] # expected result
    test_name_set_five

# Generated at 2022-06-11 02:12:11.419392
# Unit test for function build_dep_data
def test_build_dep_data():
    required_facts = {'collector_one' : set(['one']),
                      'collector_two': set(['one', 'two'])}
    assert build_dep_data(['collector_one', 'collector_two', 'collector_three'], required_facts) == \
        {'collector_one': set(['one']), 'collector_two': set(['one', 'two']), 'collector_three': set()}



# Generated at 2022-06-11 02:12:21.190166
# Unit test for function tsort
def test_tsort():
    # Test for a simple dependency graph
    graph = {
        'a': set(('b', 'c')),
        'b': set(('c',)),
        'c': set(),
        }
    unsorted = graph.copy()
    expected = [('c', set()), ('b', set(('c',))), ('a', set(('b', 'c')))]
    sorted_graph = tsort(graph)
    assert sorted_graph == expected
    assert unsorted == graph
    # Test for a simple dependency graph with cycles
    graph = {
        'a': set(('b',)),
        'b': set(('c',)),
        'c': set(('a',)),
        }
    unsorted = graph.copy()
    with pytest.raises(CycleFoundInFactDeps):
        tsort

# Generated at 2022-06-11 02:12:32.659596
# Unit test for function get_collector_names

# Generated at 2022-06-11 02:12:44.387968
# Unit test for function find_unresolved_requires

# Generated at 2022-06-11 02:12:51.897645
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [A,],
        'c': [C,],
        'd': [D,],
    }

    collector_names = ['a', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['d'])

    collector_names = ['a', 'c', 'd']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-11 02:13:00.853447
# Unit test for function tsort
def test_tsort():
    from nose.tools import assert_equals, assert_true
    x = {'a': ['b'], 'b': ['c'], 'c': []}
    tsort(x)
    assert_equals(x, {'c': [], 'b': ['c'], 'a': ['b']})

    x = {'a': ['c'], 'b': ['a'], 'c': []}
    tsort(x)
    assert_equals(x, {'c': [], 'a': ['c'], 'b': ['a']})

    x = {'a': ['c'], 'b': ['a'], 'c': ['b']}
    try:
        tsort(x)
    except CycleFoundInFactDeps:
        # this should raise an error
        pass

# Generated at 2022-06-11 02:13:02.002246
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    assert collector_classes_from_gather_subset(platform_info={'system': 'Linux'})



# Generated at 2022-06-11 02:13:09.167622
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({Platform2, Platform1})
    assert fact_id_to_collector_map['platform'][0] is Platform1
    assert fact_id_to_collector_map['platform'][1] is Platform2
    assert Platform1.name in aliases_map
    assert Platform2.name in aliases_map
    assert fact_id_to_collector_map['platform_1'][0] is Platform1
    assert fact_id_to_collector_map['platform_2'][0] is Platform2



# Generated at 2022-06-11 02:13:12.717770
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    collector_names = ['pe_architecture', 'pe_machine', 'pe_machine_facts']
    all_fact_subsets = collector.get_fact_subsets()
    assert build_dep_data(collector_names, all_fact_subsets) == {'pe_architecture': set(), 'pe_machine': set(['pe_architecture']), 'pe_machine_facts': set(['pe_machine'])}



# Generated at 2022-06-11 02:13:26.295903
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b'])
        name = 'a'
    assert build_fact_id_to_collector_map(frozenset([CollectorA])) == ({'a': [CollectorA], 'b': [CollectorA]},
                                                                      defaultdict(set, {'a': {'a', 'b'}}))



# Generated at 2022-06-11 02:13:37.837500
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Check for single unresolved require
    all_fact_subsets = {'test_collector_class_2': ['test_collector_class_2']}
    collector_names = ['test_collector_class_2']
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved_requires == set(['test_collector_class_1']), 'set should only contain test_collector_class_1'

    # Check for multiple unresolved requires
    all_fact_subsets = {'test_collector_class_2': ['test_collector_class_2']}
    collector_names = ['test_collector_class_2', 'test_collector_class_3']

# Generated at 2022-06-11 02:13:50.222577
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import sys
    import os.path
    from ansible.module_utils.facts import legacy
    from ansible.module_utils.facts import collection

    # Use our generic linux collector to make sure that the tests will
    # pass regardless of the platform the tests are run on
    class Test_GenericLinuxCollector(BaseFactCollector):
        name = 'ansible_test_linux'
        _fact_ids = set()
        required_facts = ['ansible_test_required_fact']

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info['system'].lower() == 'linux':
                return cls
            return None

        def collect(self, module=None, collected_facts=None):
            return {
                'ansible_test_linux': True
            }


# Generated at 2022-06-11 02:14:01.361341
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    """
    Tests find_collectors_for_platform method
    """
    import sys
    class TestCollector(BaseFactCollector):
        name = "test"
        _platform = "Darwin"

        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            return facts_dict
    all_collector_classes = [TestCollector]

    # Check that the function returns the correct class for platform1
    compat_platforms = [{'system': 'Darwin'}]
    platform_match = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert platform_match
    assert platform_match.pop().name == 'test'

    # Check that the function returns the correct class for platform2

# Generated at 2022-06-11 02:14:10.963528
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.utils.module_docs as module_docs

    # gather_subset: 'network'
    res = collector_classes_from_gather_subset(
        all_collector_classes=module_docs.FACT_COLLECTOR_CLASSES,
        gather_subset=['network'],
        aliases_map={
            'hardware': set(('devices', 'dmi', 'cpuinfo')),
            'network': set(('interfaces', 'ipv4_addresses', 'ipv6_addresses', 'fqdn', 'default_ipv4')),
            'virtual': set(('virtualization_type', 'virtualization_role', 'openstack_facts')),
        },
        platform_info=dict(system='Linux'),
    )

# Generated at 2022-06-11 02:14:21.397290
# Unit test for function get_collector_names
def test_get_collector_names():
    # None if no subset provided
    valid_subsets = {'network'}
    minimal_gather_subset = {'network'}
    aliases_map = defaultdict(set)
    aliases_map['all'] = {'network'}
    valid_platforms = ['Linux']
    platform_info = {'system': 'Linux', 'distribution': 'Ubuntu'}
    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=None,
                               aliases_map=aliases_map, platform_info=platform_info) == set()

    # ['all'] if subset='all'

# Generated at 2022-06-11 02:14:27.358443
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class FakeCollector0(BaseFactCollector):
        name = 'fake0'
    class FakeCollector1(BaseFactCollector):
        name = 'fake1'
        _fact_ids = set(['foobar1'])
    class FakeCollector2(BaseFactCollector):
        name = 'fake2'
        _fact_ids = set(['foobar2'])
        required_facts = set(['fake0', 'fake1'])
    class FakeCollector3(BaseFactCollector):
        name = 'fake3'
        _fact_ids = set(['foobar3'])
        required_facts = set(['fake2'])
    class FakeCollector4(BaseFactCollector):
        name = 'fake4'
        _fact_ids = set(['foobar4'])
        required_facts

# Generated at 2022-06-11 02:14:37.784384
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from collections import namedtuple

    # create a fake collector classes from a tuple of (name, requires_facts)
    CollectorClass = namedtuple('CollectorClass', ['name', 'required_facts'])
    collector_classes = [
        CollectorClass('all', set()),
        CollectorClass('a', set()),
        CollectorClass('b', set(['a'])),
        CollectorClass('c', set(['a'])),
        CollectorClass('d', set(['b'])),
        CollectorClass('e', set(['a', 'b', 'c'])),
        CollectorClass('f', set(['a', 'b', 'c', 'd'])),
        CollectorClass('g', set(['f'])),
        CollectorClass('h', set(['g']))
    ]


# Generated at 2022-06-11 02:14:45.158830
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set, {'hardware': {'devices'}})
    had_problem = False

# Generated at 2022-06-11 02:14:56.969247
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['hardware'])) == frozenset(['hardware'])
    assert get_collector_names(valid_subsets=frozenset(['!hardware'])) == frozenset([])
    assert get_collector_names(valid_subsets=frozenset(['hardware', '!hardware'])) == frozenset([])
    assert get_collector_names(valid_subsets=frozenset(['hardware']), gather_subset=['hardware']) == frozenset(['hardware'])
    assert get_collector_names(valid_subsets=frozenset(['!hardware']), gather_subset=['!hardware']) == frozenset([])
    assert get_collector_names

# Generated at 2022-06-11 02:15:32.224470
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    col_a = type('ColA', (BaseFactCollector,), {'name': 'a', '_fact_ids': ['a_alias'], '_platform': 'Linux'})
    col_b = type('ColB', (BaseFactCollector,), {'name': 'b', '_fact_ids': ['b_alias'], '_platform': 'Linux'})
    col_c = type('ColC', (BaseFactCollector,), {'name': 'c', '_fact_ids': [], '_platform': 'Linux'})
    col_d = type('ColD', (BaseFactCollector,), {'name': 'd', '_fact_ids': ['d_alias', 'd_alias2'], '_platform': 'Linux'})

# Generated at 2022-06-11 02:15:40.216369
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['proc', 'dmi', 'facter']
    all_fact_subsets = {
        'dmi': [
            MockFactCollector('dmi', set()),
            MockFactCollector('dmi', set())
        ],
        'facter': [
            MockFactCollector('facter', set(['dmi'])),
            MockFactCollector('facter', set(['dmi']))
        ],
        'proc': [
            MockFactCollector('proc', set(['dmi', 'facter'])),
            MockFactCollector('proc', set(['dmi', 'facter']))
        ]
    }

# Generated at 2022-06-11 02:15:52.988747
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import ansible.module_utils.facts.system
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    test_all_fact_subsets = defaultdict(list)
    test_all_fact_subsets.update({DistributionFactCollector.name: [DistributionFactCollector]})

# Generated at 2022-06-11 02:16:03.465201
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector_func_cache

    all_fact_subsets = collector_func_cache.all_fact_subsets
    collector_names = all_fact_subsets['all']

    # assert there are no unresolved requires
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # assert that 'fake_collector' is unresolved, even though we ask for all collectors
    collector_names = all_fact_subsets['all'] + ['fake_collector']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 1
    assert 'fake_collector' in unresolved

    # assert that top-level requires are not resolved by other top-level requires
   

# Generated at 2022-06-11 02:16:15.205721
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'base': [BaseFactCollector],
        'foo': [BaseFoo],
        'bar': [BaseBar],
        'baz': [BaseBaz, BaseBaz2],
    }

    collector_names = ('base', 'foo', 'bar', 'baz')
    result = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not result

    collector_names = ('base', 'foo', 'bar')
    result = find_unresolved_requires(collector_names, all_fact_subsets)
    assert 'baz' in result

    collector_names = ('base', 'foo', 'bar', 'baz', 'qux')

# Generated at 2022-06-11 02:16:26.452413
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = set(['A', 'a'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = set(['B', 'b'])

    all_collectors = frozenset([CollectorA, CollectorB])
    fact_id_to_collector, aliases_map = \
        build_fact_id_to_collector_map(all_collectors)

    assert fact_id_to_collector['A'] == [CollectorA]
    assert fact_id_to_collector['a'] == [CollectorA]
    assert fact_id_to_collector['B'] == [CollectorB]

# Generated at 2022-06-11 02:16:33.387546
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.hardware.dmi import DmiFactCollector
    from ansible.module_utils.facts.collector.hardware.memory import MemoryFactCollector
    collectors_for_platform = set([DmiFactCollector, MemoryFactCollector])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert len(fact_id_to_collector_map) == 2
    assert len(aliases_map) == 2
    assert 'dmi' in aliases_map
    assert 'memory' in aliases_map
    assert 'dmi' in aliases_map['dmi']
    assert 'memory' in aliases_map['memory']



# Generated at 2022-06-11 02:16:44.579309
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test that find_unresolved_requires works as expected'''
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B', 'C'])

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['D'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set([])

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['A'].append(A)
    all_fact_subsets['B'].append(B)
    all_fact_subsets['C'].append(C)
    all_

# Generated at 2022-06-11 02:16:54.250431
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.hardware import Hardware
    import ansible.module_utils.facts.network as netcol
    hardware = Hardware(namespace=None)
    netcollector = netcol.Network(namespace=None, collectors=None)
    collector_names = ['hardware', 'network']
    all_fact_subsets = {'hardware': [hardware.__class__],
                        'network': [netcollector.__class__], }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['hardware'] == set()
    assert dep_map['network'] == set()



# Generated at 2022-06-11 02:17:04.580002
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collectors():
        class Collector_class():
            _fact_ids = set()
            name = None
            required_facts = set()
            def __init__(self):
                pass
    def collect(self, module=None, collected_facts=None):
        return {}
    Collectors.Collector_class.collect = collect
    instance_dict = {"name":"value", "_fact_ids":set("value"), "required_facts":set("value")}
    instance = type("instance", (object,), instance_dict)()
    collectors_for_platform = [instance]
    assert(build_fact_id_to_collector_map(collectors_for_platform) == ({'value': [instance]}, {'value': {'value'}}))



# Generated at 2022-06-11 02:17:25.142991
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class PythonInfo(BaseFactCollector):
        name = 'python_info'
        required_facts = set()
        _fact_ids = set(['python_info'])

    class PythonPath(BaseFactCollector):
        name = 'python_path'
        required_facts = set(['python_info'])
        _fact_ids = set(['python_path'])

    class PythonLibs(BaseFactCollector):
        name = 'python_libs'
        required_facts = set(['python_info'])
        _fact_ids = set(['python_libs'])

    class PythonPycInfo(BaseFactCollector):
        name = 'python_pyc_info'

# Generated at 2022-06-11 02:17:33.275946
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import shared_loader, collector
    all_collector_classes = shared_loader._get_all_fact_collector_classes()

    # System definitions:
    #   - Linux, FreeBSD, NetBSD, DragonFly and OpenBSD will match generic Linux
    #   - OpenWRT will match generic Linux and generic Networking
    #   - macOS will match Darwin
    #   - AIX will match generic Unix
    #   - Solaris will match generic Unix
    #   - Haiku will match generic Unix
    #   - HP-UX will match generic Unix
    #   - SunOS will match generic Unix
    #   - Illumos will match generic Unix
    #   - Unix will match generic Unix
    #   - Windows will match generic Windows
    #   - Other systems won't match anything


# Generated at 2022-06-11 02:17:44.380435
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.platform.generic.virtual import VirtualFactCollector
    from ansible.module_utils.facts.platform.linux import LinuxFactCollector
    from ansible.module_utils.facts.platform.linux.distribution import DistributionFactCollector

    from ansible.module_utils.facts.hardware.dmi import DmiFactCollector
    from ansible.module_utils.facts.hardware.base import HardwareFactCollector

    all_fact_subsets = defaultdict(set)
    all_fact_subsets['generic'].add(VirtualFactCollector)
    all_fact_subsets['linux'].add(LinuxFactCollector)
    all_fact_subsets['linux'].add(DistributionFactCollector)


# Generated at 2022-06-11 02:17:53.159094
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'c1': [
            _make_collector({'required_facts': ['a']}),
            _make_collector({'required_facts': ['b']})
        ],
        'c2': [
            _make_collector({'required_facts': ['a']})
        ]
    }
    assert find_unresolved_requires(['c1', 'c2'], all_fact_subsets) == set()
    assert find_unresolved_requires(['c1'], all_fact_subsets) == {'a', 'b'}



# Generated at 2022-06-11 02:17:58.354581
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import default

    assert default.FactCollector.name == 'default'

    assert default.FactCollector._fact_ids == set(['system'])

    assert build_fact_id_to_collector_map([default.FactCollector])[1] == {'default': set(['system'])}



# Generated at 2022-06-11 02:18:07.429676
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'collector_1'
        _platform = 'Darwin'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'collector_2'
        _platform = 'Linux'
        required_facts = set()

    platforms = [
        {
            'system': 'Darwin'
        },
        {
            'system': 'Other'
        },
        {
            'system': 'Linux'
        }
    ]

    assert find_collectors_for_platform([TestCollector, TestCollector2], platforms) == {TestCollector, TestCollector2}



# Generated at 2022-06-11 02:18:18.961691
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class NeedsFoo(BaseFactCollector):
        name = 'needs_foo'
        required_facts = ['foo']

    class Foo(BaseFactCollector):
        name = 'foo'

    class NeedsNeedsFoo(BaseFactCollector):
        name = 'needs_needs_foo'
        required_facts = ['needs_foo']

    # need to do this for get_collector_names
    all_fact_subsets = {}
    for c in [NeedsFoo, Foo, NeedsNeedsFoo]:
        all_fact_subsets.setdefault(c.name, []).append(c)

    # test of all requirements are satisfied
    collector_names = ['foo', 'needs_foo', 'needs_needs_foo']

# Generated at 2022-06-11 02:18:29.541084
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [Collector_A],
        'b': [Collector_B],
        'c': [Collector_C],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['d', 'e'])

    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [Collector_A],
        'b': [Collector_B],
        'c': [Collector_C],
        'd': [Collector_D],
        'e': [Collector_E],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-11 02:18:39.972433
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # create some fake collectors
    class FakeCollector1(BaseFactCollector):
        name = 'fake1'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            '''Return a class if platform matches, or None'''
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None

    class FakeCollector2(BaseFactCollector):
        name = 'fake2'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            '''Return a class if platform matches, or None'''
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None


# Generated at 2022-06-11 02:18:52.184833
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    
    # Test arguments
    all_collector_classes = [collectors.LinuxNetworkCollector]
    valid_subsets = frozenset(['all', 'network'])
    minimal_gather_subset = frozenset(['all'])
    gather_subset = ['network']
    gather_timeout = 30
    platform_info = {'system': 'Linux'}
    
    from inspect import signature
    assert len(signature(collector_classes_from_gather_subset).parameters) == 7

    # Call function
    returned_selected_collector_classes = collector_classes_from_gather_subset(all_collector_classes, valid_subsets, minimal_gather_subset, gather_subset, gather_timeout, platform_info)

    # Assert type

# Generated at 2022-06-11 02:19:22.238753
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    fake_dep_map = {
        'network': {'platform'},
        'platform': set()
    }
    dep_map = build_dep_data({'network', 'platform'}, {'network': [NetworkFactCollector]})
    assert dep_map == fake_dep_map


# Generated at 2022-06-11 02:19:33.752448
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['network', '!storage'],
                               valid_subsets=set(['archs', 'kernel']),
                               minimal_gather_subset=set(['archs', 'disk']),
                               platform_info=None) == set(['network', 'archs'])


# Generated at 2022-06-11 02:19:46.572296
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b', 'c'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['c', 'd'])

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['c', 'd', 'e'])

    class G(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-11 02:19:59.950022
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def Collector(name, requires=()):
        class TestCollector(BaseFactCollector):
            _fact_ids = set()
            name = name
            required_facts = requires
        return TestCollector

    Collector1 = Collector('c1', requires=('r1',))
    Collector2 = Collector('c2', requires=('r2',))
    Collector3 = Collector('c3', requires=('r3',))
    Collector4 = Collector('c4', requires=('r4',))
    Collector5 = Collector('c5', requires=('r1', 'r4'))
    Collector6 = Collector('c6', requires=('r2', 'r4'))
    Collector7 = Collector('c7', requires=('r3', 'r4'))
    Collector8 = Collector('c8', requires=('r5',))
   

# Generated at 2022-06-11 02:20:08.032879
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    from ansible.module_utils.facts import all_collector_classes
    from ansible.module_utils.facts import valid_subsets
    from ansible.module_utils.facts import minimal_gather_subset
    from ansible.module_utils.facts import aliases_map

    platform_info = {'system': 'Linux'}
    gather_timeout = None
    minimal_gather_subset = frozenset()
    valid_subsets = frozenset()


# Generated at 2022-06-11 02:20:19.761893
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class FakeFactsModule(object):
        pass
    fake_facts = FakeFactsModule()

    def mock_import_module(module):
        return fake_facts

    fake_facts.platform_info = [{'system': 'Linux'}]

    class CollectorMock(object):
        name = 'collector_mock'
        required_facts = set()
        _fact_ids = set()
        _platform = 'Linux'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls

    class CollectorMock2(object):
        name = 'collector_mock2'
        required_facts = set()
        _fact_ids = set()
        _platform = 'Linux'


# Generated at 2022-06-11 02:20:31.915225
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Test build_fact_id_to_collector_map function'''
    class Collector1(BaseFactCollector):
        _fact_ids = set(['foo', 'bar', 'baz'])
        name = 'collector_1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['bar', 'baz'])
        name = 'collector_2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['baz'])
        name = 'collector_3'

    # test case #1
    collectors_for_platform = set([Collector1, Collector2, Collector3])

# Generated at 2022-06-11 02:20:36.123886
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes_mock = [BaseFactCollector,BaseFactCollector]
    all_collector_classes_mock[0]._platform = 'Linux'
    all_collector_classes_mock[1]._platform = 'Darwin'
    compat_platforms_mock = [{'system':'Linux'},{'system':'Darwin'}]
    assert find_collectors_for_platform(all_collector_classes_mock,compat_platforms_mock) == \
           set([BaseFactCollector])


# Generated at 2022-06-11 02:20:37.575094
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Function get_collector_names has no unit test'''
    pass



# Generated at 2022-06-11 02:20:45.981101
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.base import load_collectors
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import build_fact_id_to_collector_map

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
        ),
    )
    collector_names, collectors_for_platform, all_fact_subsets = load_collectors(module)
    fact_id_to_collector_map = build_fact_id_to_collector_map(collectors_for_platform)

# Generated at 2022-06-11 02:21:15.141959
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class MockCollector(BaseFactCollector):
        _fact_ids = set()

        _platform = 'Mock'
        name = 'mock'
        required_facts = set()

    class NonMockCollector(BaseFactCollector):
        _fact_ids = set()

        _platform = 'Generic'
        name = 'nonmock'
        required_facts = set()

    # Create an object with no collectors
    collectors = list()
    collectors.append(MockCollector)
    collectors.append(NonMockCollector)
    compat_platforms = [{'system': 'Linux'}]

    # Verify that the platform specific collector was not returned given the invalid platform
    found_collectors = find_collectors_for_platform(collectors, compat_platforms)


# Generated at 2022-06-11 02:21:25.181874
# Unit test for function build_dep_data
def test_build_dep_data():
    # Test with a simple tree structure
    # 1 -> 2 -> 3 -> 4  (where -> means depends on)
    expected = {
        '1': {'2'},
        '2': {'3'},
        '3': {'4'},
        '4': set(),
    }
    actual = build_dep_data(expected.keys(), expected)
    assert actual == expected

    # Test with a diamond structure
    # 1 -> 2
    #    -> 3 -> 4
    # Then check with 2 and 3 swapped
    expected = {
        '1': {'2', '3'},
        '2': {'4'},
        '3': {'4'},
        '4': set(),
    }
    actual = build_dep_data(expected.keys(), expected)
    assert actual == expected


# Generated at 2022-06-11 02:21:36.370053
# Unit test for function get_collector_names
def test_get_collector_names():
    all_fact_names = frozenset(['platform', 'hardware', 'network', 'virtual'])
    minimal_gather_subset = frozenset(['platform', 'hardware', 'network'])
    aliases_map = {'hardware': 'devices', 'dmi': 'devices'}
    # default value of gather_subset should be ['all']
    assert get_collector_names(valid_subsets=all_fact_names,
                               minimal_gather_subset=minimal_gather_subset,
                               aliases_map=aliases_map) == all_fact_names
    # if gather_subset is explicitly set to None