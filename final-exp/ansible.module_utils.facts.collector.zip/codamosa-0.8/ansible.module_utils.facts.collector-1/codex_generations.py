

# Generated at 2022-06-11 02:12:05.215697
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    class FakeCollector:
        name = None
        required_facts = set()

    class TestFactCollector(FakeCollector):
        name = 'testcollector'

    class TestFactCollector2(FakeCollector):
        name = 'testcollector2'

    test_all_facts = [TestFactCollector, TestFactCollector2]
    test_valid_facts = frozenset(['testcollector', 'testcollector2'])
    test_minimal_facts = []
    test_gather_subset = []
    test_timeout = 1
    test_platform_info = {'system': 'FreeBSD'}

    test_expected_result = [TestFactCollector, TestFactCollector2]


# Generated at 2022-06-11 02:12:14.329212
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    """Test that the test collector can be found and excluded"""

    class TestCollector1(BaseFactCollector):
        name = 'test_collector1'

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        required_facts = frozenset(['test_collector1'])

    class TestCollector4(BaseFactCollector):
        name = 'test_collector3'
        required_facts = frozenset(['test_collector2'])

    class TestCollector5(BaseFactCollector):
        name = 'test_collector3'
        required_facts = frozenset(['test_collector2'])


# Generated at 2022-06-11 02:12:22.827351
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import _get_collector_classes
    import pytest

    all_collector_classes = _get_collector_classes()

    @pytest.mark.parametrize('selected_collector_names, unresolved_expected', (
        ({'hardware'}, {'dmi'}),
        ({'hardware', 'dmi'}, set()),
        ({'all', 'hardware'}, set()),
    ))
    def test_unresolved(selected_collector_names, unresolved_expected):
        collector_names_set = set(selected_collector_names)

        all_fact_subsets = {
            'hardware': [],
            'dmi': [],
        }


# Generated at 2022-06-11 02:12:33.852326
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MockCollector(BaseFactCollector):
        name = 'network'
        _fact_ids = ['network', 'network_resources']

    class MockCollector2(BaseFactCollector):
        name = 'network2'
        _fact_ids = ['network2', 'network2_resources']

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([MockCollector, MockCollector2])

    assert aliases_map == {'network2': {'network2', 'network2_resources'}, 'network': {'network', 'network_resources'}}
    assert MockCollector in fact_id_to_collector_map['network']
    assert MockCollector2 in fact_id_to_collector_map['network']
    assert MockCollector in fact_id

# Generated at 2022-06-11 02:12:45.545338
# Unit test for function tsort
def test_tsort():
    # A -> B
    # B -> C
    # A -> D
    # D -> C
    # C -> E
    # E -> D
    # D -> F
    dep_map = {
        'A': {'B', 'D'},
        'B': {'C'},
        'D': {'C', 'F'},
        'C': {'E'},
        'E': {'D'},
    }

    with pytest.raises(CycleFoundInFactDeps):
        tsort(dep_map)

    # test that cycle is detected when there are no dependencies
    dep_map = {
        'A': {},
        'B': {},
        'C': {},
        'D': {},
        'E': {},
        'F': {},
    }



# Generated at 2022-06-11 02:12:55.965424
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        WindowsFactCollector,
        RedHatFactCollector,
        SolarisFactCollector,
        BSDFactCollector,
        NetworkFactCollector,
    ]
    compat_platforms = [
        {'system': 'Windows'},
        {'system': 'Linux', 'distribution': 'RedHat'},
        {'system': 'Solaris'},
        {'system': 'BSD'},
    ]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert found_collectors == {WindowsFactCollector, RedHatFactCollector, SolarisFactCollector, BSDFactCollector}



# Generated at 2022-06-11 02:13:05.790012
# Unit test for function build_dep_data
def test_build_dep_data():
    test_fact_ids = ['test_fact_id']
    test_required_facts = ['required_facts_1', 'required_facts_2']
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = test_fact_ids
        required_facts = test_required_facts

    collector_names = ['test_collector']
    all_fact_subsets = {'test_collector': [TestCollector]}

    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['test_collector'] == set(test_required_facts)



# Generated at 2022-06-11 02:13:15.295119
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names() == set(['all'])
    # Retrieve module parameters
    gather_subset = ['all']

    # the list of everything that 'all' expands to
    valid_subsets = frozenset()

    # if provided, minimal_gather_subset is always added, even after all negations
    minimal_gather_subset = frozenset()

    aliases_map = defaultdict(set)

    # Retrieve all facts elements
    additional_subsets = set()
    exclude_subsets = set()

    # total always starts with the min set, then
    # adds of the additions in gather_subset, then
    # excludes all of the excludes, then add any explicitly
    # requested subsets.
    gather_subset_with_min = ['min']
    gather_subset_with_

# Generated at 2022-06-11 02:13:26.883338
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector1': [
            object()
        ]
    }
    # collector1 has no requirements, so no unresolved facts
    # if it did, it would look like:
    # {'collector1': [('collector1', ['required1'])]}
    assert find_unresolved_requires(set(['collector1']), all_fact_subsets) == set()

    assert find_unresolved_requires(set(['collector1', 'required1']), all_fact_subsets) == set()

    assert find_unresolved_requires(set(['required1']), all_fact_subsets) == set(['required1'])


# Generated at 2022-06-11 02:13:37.267565
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.hardware.dmi import DMI
    from ansible.module_utils.facts.hardware.smart import Smart

    collectors = [DMI, Smart]
    expected_fact_id_to_collector_map = {'dmi': [DMI], 'smart': [Smart]}
    expected_aliases_map = {'dmi': {'dmi'}, 'smart': {'smart'}}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    assert fact_id_to_collector_map == expected_fact_id_to_collector_map
    assert aliases_map == expected_aliases_map


# Generated at 2022-06-11 02:13:56.114480
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import sys
    from ansible.module_utils.facts.collector.all import AllCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    collectors_for_platform = {AllCollector, NetworkCollector, HardwareCollector}
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert 'all' in fact_id_to_collector_map['all']
    assert 'hardware' in fact_id_to_collector_map['hardware']
    assert 'network' in fact_id_to_collector_map['network']

    assert 'dmi' in fact_id_to_collect

# Generated at 2022-06-11 02:14:08.105019
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    class FakeCollector1(BaseFactCollector):
        name = 'fake_collector_1'
        _fact_ids = {'fake_collector_1'}
    class FakeCollector2(BaseFactCollector):
        name = 'fake_collector_2'
        _fact_ids = {'fake_collector_2', 'fake_collector_3'}

    # Collectors for platform, FakeCollector2 with name fake_collector_2 is also added
    collector_classes_for_platform = {FakeCollector1, FakeCollector2}
    # Build map of Fact ID to list of collectors
    result = build_fact_id_to_collector_map(collector_classes_for_platform)
    # Build expected map

# Generated at 2022-06-11 02:14:18.761971
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class AzerothNetworkCollector(BaseFactCollector):
        name = 'network'
        _fact_ids = {'network', 'net0', 'net1'}
        required_facts = []

    class AzerothDistributionCollector(BaseFactCollector):
        name = 'distribution'
        _fact_ids = {'distribution', 'distribution_release'}
        required_facts = []

    class AzerothHardwareCollector(BaseFactCollector):
        name = 'hardware'
        _fact_ids = {'hardware', 'cpu', 'ram'}
        required_facts = []

    found_collectors = {AzerothNetworkCollector, AzerothDistributionCollector, AzerothHardwareCollector}

    (fact_id_to_collector, aliases) = build_fact_id_to

# Generated at 2022-06-11 02:14:28.848575
# Unit test for function get_collector_names
def test_get_collector_names():
    class TestConfig(object):
        def __init__(self, subset, valid_subsets, minimal_gather_subset, aliases_map):
            self.gather_subset = subset
            self.valid_subsets = valid_subsets
            self.minimal_gather_subset = minimal_gather_subset
            self.aliases_map = aliases_map


# Generated at 2022-06-11 02:14:38.526942
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['a'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    all_fact_subsets = {
        A.name: [A],
        B.name: [B],
        C.name: [C],
        D.name: [D],
        E.name: [E],
    }



# Generated at 2022-06-11 02:14:45.718420
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test basic case
    all_fact_subsets = {
        'foo': [],
        'bar': [],
        'baz': [],
        'qux': [],
    }
    collector_names = ['foo', 'bar', 'baz']

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with one class that has a required fact
    all_fact_subsets = {
        'foo': [],
        'bar': [],
        'baz': [],
        'qux': [],
    }
    collector_names = ['foo', 'bar', 'baz']

    class Bar(BaseFactCollector):
        name = 'bar'
        required_facts = set(['qux'])
    all_fact_subsets

# Generated at 2022-06-11 02:14:57.804492
# Unit test for function get_collector_names
def test_get_collector_names():
    # First, test for a 'normal' run with no issues
    # assertEqual checks things are equal
    # assertNotEqual checks things are not equal
    assertEqual(get_collector_names(valid_subsets=frozenset(['all']), minimal_gather_subset=frozenset(['min']), gather_subset=['!all', 'min']), frozenset())
    assertNotEqual(get_collector_names(valid_subsets=frozenset(['all']), minimal_gather_subset=frozenset(['min']), gather_subset=['!all', 'min']), frozenset(['all']))

    # Now test excluding '!all' when 'min' is present

# Generated at 2022-06-11 02:15:08.351397
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(['all'], [], [], {}, None) == frozenset(['all'])
    assert get_collector_names(['all'], ['min'], [], {}, None) == frozenset(['min', 'all'])
    assert get_collector_names(['all'], ['min'], ['!min'], {}, None) == frozenset(['all'])
    assert get_collector_names(['all'], ['min'], ['!min', 'os'], {}, None) == frozenset(['os', 'all'])
    assert get_collector_names(['all'], ['min'], ['!all'], {}, None) == frozenset(['min'])

# Generated at 2022-06-11 02:15:19.367983
# Unit test for function get_collector_names
def test_get_collector_names():
    # set params
    gather_subset = ['!all', 'network']
    valid_subsets = frozenset(['hardware', 'network'])
    minimal_gather_subset = frozenset(['hardware'])
    aliases_map = defaultdict(set)
    aliases_map['network'].update(['network_resources', 'network_devices'])
    aliases_map['hardware'].update(['devices', 'dmi'])

    # get collector names
    collector_names = get_collector_names(
        valid_subsets=valid_subsets,
        minimal_gather_subset=minimal_gather_subset,
        gather_subset=gather_subset,
        aliases_map=aliases_map,
    )


# Generated at 2022-06-11 02:15:31.148832
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'architecture': [TestFactCollectorRequiredBy('architecture', ['machine_id', 'hostname'],
                                                     required_facts=['unresolved_fact'])],
        'machine_id': [TestFactCollectorRequiredBy('machine_id', ['hostname'])],
        'hostname': [TestFactCollectorRequiredBy('hostname', [])],
    }

    assert find_unresolved_requires(all_fact_subsets.keys(), all_fact_subsets) == {'unresolved_fact'}
    assert find_unresolved_requires(['architecture'], all_fact_subsets) == {'unresolved_fact'}

# Generated at 2022-06-11 02:15:54.077914
# Unit test for function build_dep_data
def test_build_dep_data():
    class FakeCollector(object):
        required_facts = set()
    all_fact_subsets = {
        'a': [FakeCollector(), FakeCollector()],
        'b': [FakeCollector()],
        'c': [FakeCollector()],
        'd': [FakeCollector(), FakeCollector()],
    }
    all_fact_subsets['a'][0].required_facts.add('c')
    all_fact_subsets['a'][1].required_facts.add('b')
    all_fact_subsets['c'][0].required_facts.add('d')
    all_fact_subsets['b'][0].required_facts.add('d')
    all_fact_subsets['d'][0].required_facts.add('b')


# Generated at 2022-06-11 02:16:04.355777
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MockCollector(BaseFactCollector):
        name = 'MockOne'
        _fact_ids = frozenset(('mock1', 'mock2'))
        _platform = 'Generic'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({MockCollector})

    assert fact_id_to_collector_map['MockOne'] == [MockCollector]
    assert fact_id_to_collector_map['mock1'] == [MockCollector]
    assert fact_id_to_collector_map['mock2'] == [MockCollector]
    assert aliases_map == defaultdict(set, {'MockOne': {'mock1', 'mock2'}})



# Generated at 2022-06-11 02:16:16.196614
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import default, hardware, network

    class Windows_10(default.GenericLinux):
        _platform = 'Windows'

        _fact_ids = ['pytest_1', 'pytest_2']

    class Windows_XP(default.GenericLinux):
        _platform = 'Windows'

        _fact_ids = ['pytest_3']

    class RedHat6(default.GenericLinux):
        _platform = 'Linux'

    class Suse11(default.GenericLinux):
        _platform = 'Linux'

    platform_info = {'system': 'Windows', 'release': '10', 'distribution': None}
    all_platform_matches = [Windows_10, Windows_XP, RedHat6, Suse11]


# Generated at 2022-06-11 02:16:27.674962
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # This lecacy way of storing factsets is being phased out.
    # Ansible uses a 'name' to identify factsets. That allows people
    # to compose factsets by setting gather_subset. The name is then
    # used to map to a class. To test this function, we need to create
    # a trivial factset class with a well known name.
    class TestFactset:
        name = 'test_factset'
        required_facts = set()

    # create a lookup of collector_name: [collector_class]
    all_fact_subsets = { 'test_factset': [TestFactset] }

    # The 'test_factset' is not in the list of collector_names, so
    # find_unresolved_requires() should return it.
    collector_names = set()
    unresolved = find_

# Generated at 2022-06-11 02:16:34.213187
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.default import DefaultCollector
    from ansible.module_utils.facts.collector.legacy import LegacyCollector

    collectors = [NetworkCollector, DefaultCollector, LegacyCollector]
    result = {}

    result[NetworkCollector.name] = [NetworkCollector]
    result[DefaultCollector.name] = [DefaultCollector]
    result[LegacyCollector.name] = [LegacyCollector]

    result[LegacyCollector.name].extend([NetworkCollector, DefaultCollector])
    result['network'].extend([NetworkCollector])
    result['dmi'].extend([DefaultCollector])
    result['cmdline'].extend([LegacyCollector])

# Generated at 2022-06-11 02:16:45.484063
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.solaris import SolarisDMI
    from ansible.module_utils.facts.collector.networking import Networking
    from ansible.module_utils.facts.collector.system import System
    from ansible.module_utils.facts.collector.virtual import Virtual
    from ansible.module_utils.facts.collector.kernel import Kernel

    # full mock with everything in the list

# Generated at 2022-06-11 02:16:56.779504
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['network'])
    minimal_gather_subset = frozenset(['facts_locale'])

    # XXX: The following test is failing because get_collector_names() is being called with
    #      gather_subset=None and not with gather_subset=['all']
    #      For now, I'm commenting out the test until I can get it working.
    #      --daniel
    #assert get_collector_names(
    #    valid_subsets=valid_subsets,
    #    minimal_gather_subset=minimal_gather_subset,
    #    gather_subset=None
    #) == minimal_gather_subset


# Generated at 2022-06-11 02:17:07.064818
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FactCollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class FactCollectorB(BaseFactCollector):
        name = 'B'

    fact_subsets = {
        'A': [FactCollectorA],
        'B': [FactCollectorB],
        }

    assert find_unresolved_requires(set(), fact_subsets) == set()
    assert find_unresolved_requires(set(['A']), fact_subsets) == set()
    assert find_unresolved_requires(set(['B']), fact_subsets) == set()
    assert find_unresolved_requires(set(['A', 'B']), fact_subsets) == set()

# Generated at 2022-06-11 02:17:16.311234
# Unit test for function get_collector_names
def test_get_collector_names():
    '''test for function get_collector_names'''
    valid_subsets = frozenset(['mount', 'uptime'])
    minimal_gather_subset = frozenset(['mount'])
    aliases_map = defaultdict(set)
    aliases_map['mount'] = set(['mount', 'file_system'])
    aliases_map['uptime'] = set(['uptime'])

    # Test for gather_subset = []
    assert get_collector_names(valid_subsets, minimal_gather_subset, [], aliases_map) == set(['mount'])

    # Test for gather_subset = 'min'
    assert get_collector_names(valid_subsets, minimal_gather_subset, ['min'], aliases_map) == set(['mount'])

   

# Generated at 2022-06-11 02:17:28.386001
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # pylint: disable=too-many-branches,too-many-statements
    all_collector_classes = [
        WindowsCollector,
        DarwinCollector,
        LinuxCollector,
        OpenBSDCollector,
        GenericCollector,
    ]

    all_fact_ids = set()
    for collector_class in all_collector_classes:
        all_fact_ids.add(collector_class.name)
        all_fact_ids.update(collector_class._fact_ids)

    valid_subsets = frozenset([
        'network',
        'hardware',
        'virtual',
        'identity',
        'hardware',
        'facter',
        'ohai',
        'all',
    ])


# Generated at 2022-06-11 02:18:24.759340
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class MockFactCollector1(BaseFactCollector):
        name = 'fact1'
        required_facts = set(['fact2'])
    class MockFactCollector2(BaseFactCollector):
        name = 'fact2'
        required_facts = set(['fact3'])
    class MockFactCollector3(BaseFactCollector):
        name = 'fact3'
        required_facts = set(['fact4'])
    class MockFactCollector4(BaseFactCollector):
        name = 'fact4'
        required_facts = set()

# Generated at 2022-06-11 02:18:33.062436
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.base import BaseFactCollector
    collector_classes = (
        TestCollector('collectorA', required_facts=['factA']),
        TestCollector('collectorB', required_facts=['factA']),
        TestCollector('collectorC', required_facts=['factD']),
        TestCollector('collectorD', required_facts=['factA', 'factB', 'factC']),
    )
    all_fact_subsets = {}
    for collector_class in collector_classes:
        all_fact_subsets[collector_class.name] = [collector_class]

    collector_names = {'collectorA', 'collectorB'}

# Generated at 2022-06-11 02:18:43.892139
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class DummyCollectorOne(BaseFactCollector):
        name = 'one'
        required_facts = ('two',)

    class DummyCollectorTwo(BaseFactCollector):
        name = 'two'
        required_facts = ('three',)

    class DummyCollectorThree(BaseFactCollector):
        name = 'three'
        required_facts = ('four',)

    class DummyCollectorFour(BaseFactCollector):
        name = 'four'

    class DummyCollectorFive(BaseFactCollector):
        name = 'five'
        required_facts = ('six',)

    class DummyCollectorSix(BaseFactCollector):
        name = 'six'

    class DummyCollectorSeven(BaseFactCollector):
        name = 'seven'
        required_facts = ('eight',)


# Generated at 2022-06-11 02:18:54.526052
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class MyCollectorA(BaseFactCollector):
        name = 'a'
    class MyCollectorB(BaseFactCollector):
        name = 'b'
    class MyCollectorC(BaseFactCollector):
        name = 'c'
    class MyCollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = {'d1', 'd2'}

    collectors = [MyCollectorA, MyCollectorB, MyCollectorC, MyCollectorD]

# Generated at 2022-06-11 02:19:05.859965
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector_a': [
            BaseFactCollector,
            BaseFactCollector,
        ]
    }

    BaseFactCollector.required_facts = ['b', 'c']
    assert set() == find_unresolved_requires(['collector_a'], all_fact_subsets)
    assert {'b'} == find_unresolved_requires(['collector_a', 'b'], all_fact_subsets)
    assert {'b', 'c'} == find_unresolved_requires(['collector_a', 'b', 'c'], all_fact_subsets)



# Generated at 2022-06-11 02:19:13.924203
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector:
        _fact_ids = set()
        name = None

        def __init__(self):
            class_name = self.__class__.__name__
            self.name = class_name

    class CollectorA(Collector):
        _fact_ids = frozenset({'a', 'aa', 'aaa', 'aaaa'})

    class CollectorB(Collector):
        _fact_ids = frozenset({'b', 'bb', 'bbb', 'bbbb'})

    class CollectorC(Collector):
        _fact_ids = frozenset({'c', 'cc', 'ccc', 'cccc'})

    class CollectorD(Collector):
        _fact_ids = frozenset({'d', 'dd', 'ddd', 'dddd'})


# Generated at 2022-06-11 02:19:23.593222
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''Test build_fact_id_to_collector_map'''
    class A(BaseFactCollector):
        pass
    class B(BaseFactCollector):
        pass
    class C(BaseFactCollector):
        pass

    A.name = 'a'
    B.name = 'b'
    C.name = 'c'
    A._fact_ids.update(['aa', 'ab', 'ac'])
    B._fact_ids.update(['ba', 'bb'])
    C._fact_ids.update(['ca', 'cb', 'cc', 'cd'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([A, B, C])

    assert len(fact_id_to_collector_map) == 13


# Generated at 2022-06-11 02:19:34.738376
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test requirements
    valid_subsets = frozenset(['network', 'hardware'])
    minimal_gather_subset = frozenset(['network'])

    # Test cases

# Generated at 2022-06-11 02:19:46.878360
# Unit test for function build_dep_data
def test_build_dep_data():
    from collections import namedtuple
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.collector import BaseFactCollector

    MockCollector = namedtuple('MockCollector', 'name required_facts')

    mockcollector_a = MockCollector('a', {'b'})
    mockcollector_b = MockCollector('b', {'c'})

    all_fact_subsets = {'a': [mockcollector_a], 'b': [mockcollector_b]}

    expected_dep_map = {'a': {'b'}, 'b': {'c'}}
    dep_map = build_dep_data(all_fact_subsets.keys(), all_fact_subsets)
    assert expected_dep_map == dep_map

   

# Generated at 2022-06-11 02:20:00.141534
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'foo': [], 'bar': [], 'baz': [], 'qux': []}
    class TestFooCollector(object):
        name = 'foo'
        required_facts = set(['foo'])

    class TestBarCollector(object):
        name = 'bar'
        required_facts = set(['bar'])

    class TestBazCollector(object):
        name = 'baz'
        required_facts = set(['baz'])

    foo_collector = TestFooCollector()
    bar_collector = TestBarCollector()
    baz_collector = TestBazCollector()

    all_fact_subsets['foo'].append(foo_collector)
    all_fact_subsets['bar'].append(bar_collector)

# Generated at 2022-06-11 02:21:10.230071
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from collections import defaultdict
    d1 = {'foo': set()}
    d2 = {'foo': set(), 'bar': set(), 'baz': set()}
    d3 = {'foo': set(['bar']), 'bar': set(['baz']), 'baz': set(['foo'])}
    d4 = {'foo': set(['bar']), 'bar': set(['baz']), 'baz': set()}
    class dummy1:
        def __init__(self):
            self.name = 'foo'
            self.required_facts = set()
    class dummy2:
        def __init__(self):
            self.name = 'bar'
            self.required_facts = set()

# Generated at 2022-06-11 02:21:16.985545
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Test1(BaseFactCollector):
        name = 'test1'
        _fact_ids = frozenset(['test1'])
    class Test2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['test2'])
    class Test3(BaseFactCollector):
        name = 'test3'
        _fact_ids = frozenset(['test3', 'alias3'])

    assert build_fact_id_to_collector_map([Test1, Test2, Test3]) == ({'test1': [Test1], 'test2': [Test2], 'test3': [Test3], 'alias3': [Test3]},
                                                             {'test3': {'test3', 'alias3'}})



# Generated at 2022-06-11 02:21:27.354034
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    fact_deps = {
        'fact_a': {'requires': ['fact_b']},
        'fact_b': {'requires': ['fact_c']},
        'fact_c': {'requires': ['fact_b']},
        'fact_d': {'requires': []},
    }
    name_to_position = {name: position for position, name in enumerate(sorted(fact_deps))}

    def get_required_facts(collector_name):
        return fact_deps[collector_name]['requires']

    def get_deps(collector_names):
        unresolved = find_unresolved_requires(collector_names, name_to_position, get_required_facts, 'fact')
        assert len(unresolved) == 1

# Generated at 2022-06-11 02:21:38.366180
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector0(BaseFactCollector):
        name = 'TestCollector0'
        required_facts = set()
    class TestCollector1(BaseFactCollector):
        name = 'TestCollector1'
        required_facts = set(['TestCollector0'])
    class TestCollector2(BaseFactCollector):
        name = 'TestCollector2'
        required_facts = set()
    class TestCollector3(BaseFactCollector):
        name = 'TestCollector3'
        required_facts = set(['TestCollector2'])
    class TestCollector4(BaseFactCollector):
        name = 'TestCollector4'
        required_facts = set(['TestCollector1', 'TestCollector3'])
