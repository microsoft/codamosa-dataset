

# Generated at 2022-06-11 02:12:03.853686
# Unit test for function build_dep_data
def test_build_dep_data():
    test_collector_names = ['a', 'b', 'c', 'd']
    test_all_fact_subsets = {
        'a': [FactsCollectorA],
        'b': [FactsCollectorB],
        'c': [FactsCollectorC],
        'd': [FactsCollectorD],
    }

    dep_map = build_dep_data(test_collector_names, test_all_fact_subsets)

    assert dep_map['a'] == {'c'}
    assert dep_map['b'] == {'c'}
    assert dep_map['c'] == set()
    assert dep_map['d'] == {'a', 'b'}
    assert dep_map.get('x') == None


# Test data for function create_collectors_order
#

# Generated at 2022-06-11 02:12:04.440765
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    assert True

# Generated at 2022-06-11 02:12:13.854409
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Test1(BaseFactCollector):
        _fact_ids = set(['test1'])
    class Test2(BaseFactCollector):
        _fact_ids = set(['test2', 'test22'])
    class Test3(BaseFactCollector):
        _fact_ids = set(['test3'])
    class Test4(BaseFactCollector):
        _fact_ids = set(['test4'])

    class TestAll(BaseFactCollector):
        _fact_ids = set(['test1', 'test2', 'test22', 'test3', 'test4'])

    class TestMin(BaseFactCollector):
        _fact_ids = set(['test2'])

    class TestHardware(BaseFactCollector):
        _fact_ids = set(['test4', 'test3'])



# Generated at 2022-06-11 02:12:21.293002
# Unit test for function find_unresolved_requires

# Generated at 2022-06-11 02:12:32.736367
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['collector_test_1', 'collector_test_2']
    collector_test_1 = BaseFactCollector()
    collector_test_1.required_facts = {'collector_test_2'}
    collector_test_2 = BaseFactCollector()
    collector_test_2.required_facts = {'collector_test_3'}
    collector_test_3 = BaseFactCollector()
    collector_test_3.required_facts = {'collector_test_1'}
    all_fact_subsets = {}
    all_fact_subsets['collector_test_1'] = [collector_test_1]
    all_fact_subsets['collector_test_2'] = [collector_test_2]

# Generated at 2022-06-11 02:12:44.475430
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'

    class B(BaseFactCollector):
        name = 'B'
        required_facts = {'A'}

    class C(BaseFactCollector):
        name = 'C'
        required_facts = {'A'}

    all_fact_subsets = {'A': [A],
                        'B': [B],
                        'C': [C]}
    collector_names = {'A', 'B', 'C'}
    assert len(find_unresolved_requires(collector_names, all_fact_subsets)) == 0

    collector_names = {'C'}
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved_requires) == 1


# Generated at 2022-06-11 02:12:56.339355
# Unit test for function get_collector_names
def test_get_collector_names():
    # basic all/min tests
    assert get_collector_names(['all']) == {'all'}
    assert get_collector_names(['min']) == {'min'}
    assert get_collector_names(['!all']) == {'min'}
    assert get_collector_names(['!min']) == {}
    assert get_collector_names(['!all', 'min']) == {'min'}
    assert get_collector_names(['!min', 'all']) == {'all'}
    assert get_collector_names(['!min', 'min']) == {'min'}

    # test with some other subsets
    assert get_collector_names(['all'], ['min', 'foo']) == {'all'}
    assert get_collect

# Generated at 2022-06-11 02:13:07.540442
# Unit test for function get_collector_names
def test_get_collector_names():
    all_subsets = frozenset(['a', 'b', 'c', 'd', 'e', 'f'])
    min_subsets = frozenset(['a', 'b'])
    aliases_map = defaultdict(set, {
        'hardware': set(['devices', 'dmi']),
        'software': set(),
    })

    # gather all
    assert get_collector_names(valid_subsets=all_subsets,
                               minimal_gather_subset=min_subsets,
                               gather_subset=['all'],
                               aliases_map=aliases_map) == set(['a', 'b', 'c', 'd', 'e', 'f'])

    # gather nothing

# Generated at 2022-06-11 02:13:17.119970
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts.collector import tsort
    # make sure that tsort does not choke on empty dep_map
    assert tsort({}) == []

    # empty dep_map for a node means that it does not depend on anything
    assert tsort({'a': set()}) == [('a', set())]

    # if a node depends on another node, it comes after it
    assert tsort({'a': set(), 'b': set(['a'])}) == [('a', set()), ('b', set(['a']))]

    # if we have multiple nodes that do not depend on anything,
    # they are sorted in some arbitrary order
    assert sorted(tsort({'a': set(), 'b': set()})) == [('a', set()), ('b', set())]

    # well, it is

# Generated at 2022-06-11 02:13:28.732068
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires function'''
    class Foo(object):
        def __init__(self, required_facts):
            self.name = 'foo'
            self.required_facts = required_facts

    class Bar(object):
        def __init__(self):
            self.name = 'bar'
            self.required_facts = set()

    class Baz(object):
        def __init__(self, required_facts):
            self.name = 'baz'
            self.required_facts = required_facts

    # Test case with one unresolved requirement
    foo_class = Foo(['bar'])
    bar_class = Bar()
    baz_class = Baz(['foo', 'bar'])


# Generated at 2022-06-11 02:13:41.247816
# Unit test for function build_dep_data
def test_build_dep_data():
    print('==== TEST: build_dep_data ====')
    class TestCollector1(BaseFactCollector):
        _fact_ids = set()
        _platform = 'linux'
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'linux'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'linux'
        name = 'test3'
        required_facts = {'test1'}

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'linux'
        name = 'test4'
        required_facts

# Generated at 2022-06-11 02:13:48.106723
# Unit test for function tsort
def test_tsort():
    # This graph is a cycle. No sorting is possible.
    dep_map_a = {
        'a': set(['b', 'c']),
        'b': set(['d']),
        'c': set(['a']),
        'd': set(['b']),
    }
    # This graph is cycle free.
    dep_map_b = {
        'a': set(['b', 'c']),
        'b': set(['d']),
        'c': set(['b']),
        'd': set(['e']),
        'e': set([]),
    }

    assert tsort(dep_map_a) == []

# Generated at 2022-06-11 02:13:54.972812
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = set()
    collectors_for_platform.add(FactsCollectorA)
    collectors_for_platform.add(FactsCollectorB)
    result = build_fact_id_to_collector_map(collectors_for_platform)
    assert result[0] == {
        'a': [FactsCollectorA],
        'b': [FactsCollectorB],
        'c': [FactsCollectorB],
    }
    assert result[1] == {
        'a': set(),
        'b': set(['c'])
    }


# Generated at 2022-06-11 02:14:04.247837
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import Network, Platform
    all_fact_subsets = {'network': [Network], 'platform': [Platform]}
    assert find_unresolved_requires(['network'], all_fact_subsets) == set(['platform'])
    assert find_unresolved_requires(['platform', 'network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'platform'], all_fact_subsets) == set()


# Generated at 2022-06-11 02:14:13.225313
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
    class C(BaseFactCollector):
        name = 'c'
    class D(BaseFactCollector):
        name = 'd'

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a_fact_id'].append(A)
    all_fact_subsets['b_fact_id'].append(B)
    all_fact_subsets['b_fact_id'].append(C)
    all_fact_subsets['c_fact_id'].append(C)
    all_fact_subsets['c_fact_id'].append(D)

# Generated at 2022-06-11 02:14:23.455183
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        _fact_ids = frozenset(['collector2', 'collector2-alias'])
        name = 'collector2'
    class Collector3(BaseFactCollector):
        _fact_ids = frozenset(['collector3', 'collector3-alias'])
        name = 'collector3'

    collectors_for_platform = (Collector1(), Collector2(), Collector3())
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['collector1'] == [Collector1()]
    assert fact_id_to_collector

# Generated at 2022-06-11 02:14:32.308560
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'collector_1': [MagicMock(name='class_1', required_facts=set(['collector_2']))],
                        'collector_2': [MagicMock(name='class_2', required_facts=set(['collector_1']))],
                        'collector_3': [MagicMock(name='class_3', required_facts=set(['collector_4']))],
                        'collector_4': [MagicMock(name='class_4', required_facts=set())]}
    collector_names = ['collector_1', 'collector_3']
    unresolved = set(['collector_2'])

    assert find_unresolved_requires(collector_names, all_fact_subsets) == unresolved

    # test both classes getting resolved
   

# Generated at 2022-06-11 02:14:43.742447
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import hardware as hardware_collector

    collectors_for_platform = [hardware_collector.Hardware, hardware_collector.Virtual, hardware_collector.DMIHardware]

    # test the function does something
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert 'hardware' in fact_id_to_collector_map
    assert 'virtual' in fact_id_to_collector_map
    assert 'dmi' in fact_id_to_collector_map

    # test that the entries are correct
    assert fact_id_to_collector_map['hardware'] == [hardware_collector.Hardware]
    assert fact_id_to_collector_

# Generated at 2022-06-11 02:14:54.065924
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all'], valid_subsets=['facts', 'networking', 'hardware']) == set(['networking', 'hardware', 'facts'])
    assert get_collector_names(gather_subset=['all'], valid_subsets=['facts', 'networking']) == set(['networking', 'facts'])
    assert get_collector_names(gather_subset=['all'], valid_subsets=['networking', 'hardware']) == set(['networking', 'hardware'])
    assert get_collector_names(gather_subset=['all'], valid_subsets=['facts']) == set(['facts'])

# Generated at 2022-06-11 02:15:05.910340
# Unit test for function get_collector_names
def test_get_collector_names():
    # Declare variables
    gather_subset = ['all']
    minimal_gather_subset = frozenset()
    valid_subsets = frozenset(['all'])
    aliases_map = defaultdict(set)
    platform_info = {}
    # Call tested method
    result = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info)
    # Check requirements in documentation
    assert hasattr(result, '__iter__')
    assert len(result) == 0
    assert isinstance(result, frozenset)
    assert isinstance(result, set)

    # Declare variables
    gather_subset = ['all']
    minimal_gather_subset = frozenset(['all'])
    valid_subsets = frozens

# Generated at 2022-06-11 02:15:32.829701
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collectors

    class our_collector(BaseFactCollector):
        name = 'foo'
        _fact_ids = set(['bar'])

    our_collector_class = our_collector
    all_collector_classes = [our_collector_class]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collector_classes)

    assert our_collector_class in fact_id_to_collector_map['foo']
    assert our_collector_class in fact_id_to_collector_map['bar']
    assert 'foo' in aliases_map
    assert 'bar' in aliases_map['foo']



# Generated at 2022-06-11 02:15:45.992902
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class DepCollector(BaseFactCollector):  # pylint: disable=too-few-public-methods
        name = 'dep'
        _fact_ids = set(['foo'])

    class TestCollector(BaseFactCollector):  # pylint: disable=too-few-public-methods
        name = 'test'
        required_facts = set(('dep',))
        _fact_ids = set(['bar'])

    test_collector = TestCollector()
    dep_collector = DepCollector()

    test_collectors = (test_collector, dep_collector)
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(test_collectors)

# Generated at 2022-06-11 02:15:56.995773
# Unit test for function get_collector_names
def test_get_collector_names():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import GenericDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import BSDDistributionFactCollector
    import pytest


# Generated at 2022-06-11 02:16:06.579611
# Unit test for function tsort
def test_tsort():
    from nose.tools import assert_raises
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['d']),
        'c': set(['d']),
        'd': set(),
    }
    assert tsort(dep_map) == [('a', set(['b', 'c'])), ('b', set(['d'])), ('c', set(['d'])), ('d', set())]

    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['d']),
        'c': set(['d']),
        'd': set(['b']),
    }
    assert_raises(CycleFoundInFactDeps, tsort, dep_map)



# Generated at 2022-06-11 02:16:17.700081
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # create a mock for BaseFactCollector
    class MockFactCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'kvm'
        required_facts = set()

        def __init__(self, collectors=None, namespace=None):
            super(MockFactCollector, self).__init__(collectors=collectors, namespace=namespace)

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
        def collect(self, module=None, collected_facts=None):
            facts_dict = {'testkey': 'testvalue'}
            return facts_dict

    # create a mock for BaseFactCollector

# Generated at 2022-06-11 02:16:28.900083
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.mageia
    import ansible.module_utils.facts.system.distribution.oracle
    import ansible.module_utils.facts.system.distribution.opensuse
    import ansible.module_utils.facts.system.distribution.sles
    import ansible.module_utils.facts.system.distribution.ubuntu


# Generated at 2022-06-11 02:16:37.351273
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test1', 'test2'])

        name = 'test'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector])

    assert fact_id_to_collector_map['test'] == [TestCollector]
    assert fact_id_to_collector_map['test1'] == [TestCollector]
    assert fact_id_to_collector_map['test2'] == [TestCollector]
    assert aliases_map == {'test': set(['test1', 'test2'])}



# Generated at 2022-06-11 02:16:48.832119
# Unit test for function tsort
def test_tsort():
    from ansible.module_utils.facts._collections import BaseFactCollection
    from ansible.module_utils.facts._collections.system import System
    from ansible.module_utils.facts._collections.virtual import Virtual, DmidecodeVirtual
    from ansible.module_utils.facts._collections.extras import Distribution
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.system import Virtual as VirtualFacts
    all_fact_subsets = {System.name: [System],
                        Virtual.name: [Virtual, DmidecodeVirtual],
                        Distribution.name: [Distribution]}
    dep_map = defaultdict(set)

# Generated at 2022-06-11 02:16:59.583750
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([NetworkCollector])
    assert NetworkCollector.name in fact_id_to_collector_map
    assert 'network' in fact_id_to_collector_map
    assert len(fact_id_to_collector_map) == 2

    # mapping called by the original name and aliases should yield the same class
    assert fact_id_to_collector_map['all'] == fact_id_to_collector_map['network']
    assert NetworkCollector.name in aliases_map
    assert 'network' in aliases_map[NetworkCollector.name]



# Generated at 2022-06-11 02:17:08.894428
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class DummyCollector(BaseFactCollector):
        pass

    class DummyCollectorS390X(BaseFactCollector):
        _platform = 'Linux'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system') == 'Linux' and platform_info.get('machine') == 's390x':
                return cls
            return None

    class DummyCollectorLinux(BaseFactCollector):
        _platform = 'Linux'

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system') == 'Linux':
                return cls
            return None

    class DummyCollectorLinuxAndBSD(BaseFactCollector):
        _platform = 'Linux'


# Generated at 2022-06-11 02:17:43.958211
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_case = [
        # collector_names, all_fact_subsets, expected_result
        (['thisfact'], defaultdict(set, {'thisfact': {'otherfact'}}), set()),
        (['thisfact'], defaultdict(set, {'thisfact': {'otherfact'}, 'otherfact': {}}), set(['otherfact'])),
    ]

    for (collector_names, all_fact_subsets, expected_result) in test_case:
        result = find_unresolved_requires(collector_names, all_fact_subsets)
        assert isinstance(result, set)
        assert result == expected_result



# Generated at 2022-06-11 02:17:53.625325
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.default import DefaultCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector

    # set up collectors
    collectors = [DefaultCollector, NetworkCollector]

    # map of fact_id to expected Collector.name
    expected = {
        'default': ['default'],
        'network': ['network', 'default'],
        'all': ['network', 'default'],
    }

    fact_to_collector_map, _ = build_fact_id_to_collector_map(collectors)

    assert fact_to_collector_map == expected

    return fact_to_collector_map



# Generated at 2022-06-11 02:18:03.579265
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class TestCollector(BaseFactCollector):
        name = 'TestCollector'
        _fact_ids = ['id1', 'id2']

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    class TestCollector2(BaseFactCollector):
        name = 'TestCollector2'
        _fact_ids = ['id3', 'id4']

        @classmethod
        def platform_match(cls, platform_info):
            return cls

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(set([TestCollector, TestCollector2]))
    assert len(fact_id_to_collector_map) == 6
    assert 'TestCollector' in fact_id_to_collector_

# Generated at 2022-06-11 02:18:11.247032
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    all_fact_subsets = {
        'a_fact': [
            type('', (object,), {'required_facts': set()})
        ],
        'requires_a_fact': [
            type('', (object,), {'required_facts': set(['a_fact'])})
        ],
        'raises_collector_not_found': [
            type('', (object,), {'required_facts': set(['foo'])})
        ],
        'c_fact': [
            type('', (object,), {'required_facts': set(['b_fact'])})
        ],
        'b_fact': [
            type('', (object,), {'required_facts': set(['c_fact'])})
        ],
    }

    assert find_unres

# Generated at 2022-06-11 02:18:23.428449
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['a'])
    }

    try:
        sorted_list = tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        raise RuntimeError('no CycleFoundInFactDeps raised')

    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['a']),
        'e': set(['f']),
        'f': set()
    }


# Generated at 2022-06-11 02:18:32.347572
# Unit test for function get_collector_names
def test_get_collector_names():
    # Make sure we get all collectors when no subset is specified
    assert get_collector_names(valid_subsets=['all']) == ['all']

    # Make sure we get the specified subset when one is specified
    assert get_collector_names(valid_subsets=['all'], gather_subset=['hardware']) == ['hardware']

    # Make sure we get the specified subset, without 'min', when one is specified
    assert get_collector_names(valid_subsets=['all'], minimal_gather_subset=['min'], gather_subset=['hardware']) == ['hardware']

    # Make sure we get the specified subset, without 'min', when one is specified

# Generated at 2022-06-11 02:18:43.059383
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # "arch" is a fact that is not required by any collector
    assert find_unresolved_requires(['arch'],
                                    {'arch': []}) == set()
    # "arch" is a fact that is not required by any collector
    assert find_unresolved_requires(['arch'],
                                    {'arch': [], 'platform': [], 'lsb': [], 'facter': []}) == set()

    # "arch" and "platform" are facts that are not required by any collector
    assert find_unresolved_requires(['arch', 'platform'],
                                    {'arch': [], 'platform': [], 'lsb': [], 'facter': []}) == set()

    # "arch" is not a required fact for 'lsb'

# Generated at 2022-06-11 02:18:53.909182
# Unit test for function get_collector_names
def test_get_collector_names():
    # pylint: disable=unused-variable
    assert get_collector_names(['all']) == {'all'}
    assert get_collector_names(['all', '!kernel']) == {'all'}
    assert get_collector_names(['!all']) == {'min'}
    assert get_collector_names(['!all', 'kernel']) == {'kernel'}

    assert get_collector_names(['all', '!kernel'], minimal_gather_subset=['min']) == {'all'}
    assert get_collector_names(['all', 'kernel'], minimal_gather_subset=['min']) == {'all', 'kernel'}

# Generated at 2022-06-11 02:19:06.921008
# Unit test for function select_collector_classes
def test_select_collector_classes():
    f1 = type('F1', (BaseFactCollector,), {'name': 'f1'})
    f2 = type('F2', (BaseFactCollector,), {'name': 'f2'})
    f1b = type('F1b', (BaseFactCollector,), {'name': 'f1',
                                            '_fact_ids': ['c2', 'c3']})

    all_fact_subsets = {
        f1.name: [f1, f1b],
        f2.name: [f2],
        'c1': [f1],
        'c2': [f1b],
        'c3': [f1b],
    }


# Generated at 2022-06-11 02:19:14.533725
# Unit test for function build_dep_data
def test_build_dep_data():
    collectorA = BaseFactCollector()
    collectorA.name = 'collectorA'
    collectorA.required_facts = ['collectorB']

    collectorB = BaseFactCollector()
    collectorB.name = 'collectorB'
    collectorB.required_facts = ['collectorC']

    collectorC = BaseFactCollector()
    collectorC.name = 'collectorC'
    collectorC.required_facts = []

    all_fact_subsets = {
        'collectorB': [collectorB],
        'collectorA': [collectorA],
        'collectorC': [collectorC]
    }
    collector_names = set(['collectorA', 'collectorB', 'collectorC'])

# Generated at 2022-06-11 02:19:42.219594
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {'test': [BaseFactCollector, BaseFactCollector, BaseFactCollector]}
    collector_names = ['test', 'test', 'test']
    assert len(select_collector_classes(collector_names, all_fact_subsets)) == 1
    collector_names.append('test')
    assert len(select_collector_classes(collector_names, all_fact_subsets)) == 1



# Generated at 2022-06-11 02:19:50.114486
# Unit test for function build_dep_data
def test_build_dep_data():
    def _make_class(name, *deps):
        class DummyClass(object):
            pass

        dummy_class = DummyClass()
        dummy_class.name = name
        dummy_class.required_facts = set(deps)

        return dummy_class

    test_deps = {
        'a': ['b', 'c'],
        'd': ['e'],
    }

    input_collectors = [_make_class(name, *deps) for name, deps in test_deps.items()]
    all_fact_subsets = {
        name: [coll] for name, coll in zip(test_deps.keys(), input_collectors)}
    collector_names = test_deps.keys()


# Generated at 2022-06-11 02:20:02.448428
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import pytest  # noqa
    from .. import plugins  # noqa

    # Setup
    all_collector_classes = plugins.all_fact_collectors
    valid_subsets = frozenset({'hardware', 'network', 'packages', 'virtual'})
    minimal_gather_subset = frozenset({'hardware'})
    gather_subset = ['all']
    platform_info = {'system': 'Linux'}
    expected_collector_classes = [plugins.LinuxHardwareFactCollector]

    # Test function

# Generated at 2022-06-11 02:20:13.743443
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.network import NetworkCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.platform.hpux import HPUXCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.platform.linux import LinuxCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.system import SystemCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.virtual import VirtualCollector

# Generated at 2022-06-11 02:20:23.431214
# Unit test for function build_dep_data
def test_build_dep_data():
    class a_b_c(BaseFactCollector):
        name = 'a'
        required_facts = ['b', 'c']
    class a_d_e(BaseFactCollector):
        name = 'a'
        required_facts = ['d', 'e']
    class b_d(BaseFactCollector):
        name = 'b'
        required_facts = ['d']
    class c(BaseFactCollector):
        name = 'c'
        required_facts = []
    class d(BaseFactCollector):
        name = 'd'
        required_facts = []
    class e(BaseFactCollector):
        name = 'e'
        required_facts = []

    a_b_c.platform_match = a_d_e.platform_match = b_d.platform_match = c.platform_

# Generated at 2022-06-11 02:20:36.203022
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # inputs:
    #   - collector_names is a set of collector names that is the final
    #     collection of names
    #   - all_fact_subsets is a dict of collector_name -> list_of_collector_classes

    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = ('a',)

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = ('b',)

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = ('c',)

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = ('d',)

    class CollectorE(BaseFactCollector):
        name = 'E'

# Generated at 2022-06-11 02:20:45.022465
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test for empty collector_names
    assert select_collector_classes([], {}) == []

    # Test for unavailable collector
    all_fact_subsets = {}
    assert select_collector_classes(['unavailable'], all_fact_subsets) == []

    # Test for collector that has no duplicates
    all_fact_subsets = {
        'available': [
            'available',
        ],
    }
    assert select_collector_classes(['available'], all_fact_subsets) == ['available']

    # Test for collector that has two duplicates
    all_fact_subsets = {
        'available': [
            'available',
            'available_duplicate',
        ],
    }
    assert select_collector_classes(['available'], all_fact_subsets) == ['available']

# Generated at 2022-06-11 02:20:51.793996
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_col_classes = [
        'collector1',
        'collector2',
        'collector3',
        'collector4',
    ]

    collector_names = ['collector1', 'collector3']
    all_fact_subsets = defaultdict(lambda:all_col_classes)

    expected_classes = ['collector1', 'collector3']
    actual_classes = list(select_collector_classes(collector_names, all_fact_subsets))

    assert(expected_classes == actual_classes)



# Generated at 2022-06-11 02:20:58.938892
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    OS_SPECIFIC_FACT_SUBSETS = {'linux': ['FactCollectorClass1']}
    fact_ids_to_collector_class = {'FactCollectorClass1': [('FactCollectorClass1', ['required_fact'])]}
    collector_names = ['FactCollectorClass1']
    unresolved = find_unresolved_requires(collector_names, fact_ids_to_collector_class)
    assert(unresolved == set(['required_fact']))
# End unit test for function find_unresolved_requires



# Generated at 2022-06-11 02:21:05.012833
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.facts.hardware import Hardware as Collector

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(set([Collector]))

    assert sorted(aliases_map.keys()) == ['hardware']
    assert sorted(aliases_map['hardware']) == ['devices', 'dmi', 'disk']



# Generated at 2022-06-11 02:21:28.125316
# Unit test for function get_collector_names
def test_get_collector_names():
    class TestNamespace:
        def __init__(self, prefix):
            self.prefix = prefix
        def transform(self, key_name):
            return self.prefix + '_' + key_name

    class TestPlatformInfo:
        def __init__(self, platform_name):
            self.platform_name = platform_name

    def _assert_collected_facts(expected_facts,
                                collectable_facts,
                                gather_subset,
                                minimal_gather_subset=None,
                                aliases_map=None,
                                platform_info=None):
        minimal_gather_subset = minimal_gather_subset or []
        aliases_map = aliases_map or defaultdict(set)

# Generated at 2022-06-11 02:21:36.874979
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['collector_name'], {'collector_name': [BaseFactCollector]})
    assert not dep_map, 'build_dep_data should return an empty defaultdict'
    class TestCollector(BaseFactCollector):
        required_facts = ['dependency_facter']
    dep_map = build_dep_data(['collector_name'], {'collector_name': [TestCollector]})
    assert dep_map['collector_name'] == set(['dependency_facter']), 'build_dep_data should return required facts'

