

# Generated at 2022-06-11 02:11:58.198480
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Test1(BaseFactCollector):
        name = 'Test1'
        _platform = 'Generic'
    class Test2(BaseFactCollector):
        name = 'Test2'
        _platform = 'Generic'
    class Test3(BaseFactCollector):
        name = 'Test3'
        _platform = 'RedHat'

    all_collector_classes = (Test1, Test2, Test3)

    # from list
    compat_platforms = ['Linux', 'RedHat']
    assert find_collectors_for_platform(all_collector_classes, compat_platforms) == (Test1, Test2)
    # from dict (as would be returned by platform.platform()
    compat_platforms = [{'system': 'Linux'}, {'system': 'RedHat'}]
    assert find_collectors

# Generated at 2022-06-11 02:12:04.326391
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test the find_unresolved_requires function'''
    test_class_1 = type('TestClass1', (BaseFactCollector,), {
        'required_facts': ('test2',),
        '_fact_ids': ('test1',),
        'name': 'test1',
    })
    test_class_2 = type('TestClass2', (BaseFactCollector,), {
        'required_facts': (),
        '_fact_ids': ('test2',),
        'name': 'test2',
    })
    test_fact_subsets = {'test1': [test_class_1], 'test2': [test_class_2]}
    result = find_unresolved_requires(['test1'], test_fact_subsets)
    assert result == {'test2'}
    result

# Generated at 2022-06-11 02:12:13.788028
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = ['B2']

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = ['C2', 'C3']

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = ['D2', 'B2']

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = ['E2', 'E3', 'C3']

    class CollectorF(BaseFactCollector):
        name = 'F'
        _fact_ids = ['E2']

    class CollectorG(BaseFactCollector):
        name = 'G'
        _

# Generated at 2022-06-11 02:12:22.532698
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # create a couple of collectors that can be used
    class CollectorA(BaseFactCollector):
        name = 'a'
        def __init__(self):
            self.required_facts = set(('b',))
    class CollectorB(BaseFactCollector):
        name = 'b'
        def __init__(self):
            self.required_facts = set(('d',))
    class CollectorC(BaseFactCollector):
        name = 'c'
        def __init__(self):
            self.required_facts = set(('b',))
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'
        def __init__(self):
            self.required_facts = set(('h',))

# Generated at 2022-06-11 02:12:33.627821
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.default import DefaultFactCollector

    class CollectorA(BaseFactCollector):
        _fact_ids = ('a',)
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = ('b',)
        name = 'b'
        required_facts = ('a',)

    class CollectorC(BaseFactCollector):
        _fact_ids = ('c',)
        name = 'c'
        required_facts = ('a',)

    class CollectorD(BaseFactCollector):
        _fact_ids = ('d',)

# Generated at 2022-06-11 02:12:45.312935
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # testing trivial case
    collector_names = ['a', 'b']
    all_fact_subsets = {'a': [1, 2], 'b': [3, 4]}
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    # testing case with unresolved require
    collector_names = ['a']
    all_fact_subsets = {'a': [1, 2], 'b': [3, 4]}
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == {'b'}

    # testing case with different requires
    collector_names = ['a', 'b']

# Generated at 2022-06-11 02:12:56.810354
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    COLLECTOR_1 = type('Collector1', (BaseFactCollector,), { "platform": 'test', "name": 'test1' })
    COLLECTOR_2 = type('Collector2', (BaseFactCollector,), { "platform": 'test', "name": 'test2' })
    COLLECTOR_3 = type('Collector3', (BaseFactCollector,), { "platform": 'test', "name": 'test3' })
    COLLECTOR_4 = type('Collector3', (BaseFactCollector,), { "platform": 'other', "name": 'test4' })
    all_collector_classes = { COLLECTOR_1, COLLECTOR_2, COLLECTOR_3, COLLECTOR_4 }
    compat_platforms = [ { "system": "test" } ]

    found_collect

# Generated at 2022-06-11 02:13:08.010308
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Empty collector
    class EmptyCollector(BaseFactCollector):
        name = 'empty'
        _fact_ids = set()
        def collect(self, module=None, collected_facts=None):
            return {}

    # Collector with a single alias
    class AliasCollector(BaseFactCollector):
        name = 'alias'
        _fact_ids = {'alias_id'}
        def collect(self, module=None, collected_facts=None):
            return {}

    # Collector with several aliases
    class ManyAliasesCollector(BaseFactCollector):
        name = 'multi'
        _fact_ids = {'multi', 'multi_id'}
        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-11 02:13:17.467911
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(['cpu'], {'cpu': []}) == set()
    assert find_unresolved_requires(['cpu', 'network'], {'cpu': [], 'network': []}) == set()
    assert find_unresolved_requires(['cpu', 'network'], {'cpu': [], 'network': [], 'all': []}) == set()

    class cpu(BaseFactCollector):
        name = 'cpu'
        required_facts = set(['network'])

    cpu_class = cpu()
    all_fact_subsets = defaultdict(list)
    for fact_id in cpu_class.fact_ids:
        all_fact_subsets[fact_id].append(cpu_class)

    assert find_unresolved_requires(['cpu'], all_fact_subsets)

# Generated at 2022-06-11 02:13:28.420701
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils._text import to_bytes
    from . import get_all_collector_classes
    all_collector_classes = get_all_collector_classes()

    compat_platforms = (dict(system='Linux', machine='ppc64le'),
                        dict(system='Linux', machine='x86_64'),
                        dict(system='Darwin', machine='Power Macintosh'),
                        dict(system='Darwin', machine='x86_64'),
                        dict(system='Windows', machine='AMD64'))

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert len(found_collectors) == len(all_collector_classes) - 1



# Generated at 2022-06-11 02:14:07.676121
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import selinux

    collectors = (
        hardware.Hardware,
        network.Network,
        selinux.SELinux,
    )

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)

    assert fact_id_to_collector_map['hardware'] == [hardware.Hardware]
    assert fact_id_to_collector_map['network'] == [network.Network]
    assert fact_id_to_collector_map['selinux'] == [selinux.SELinux]

# Generated at 2022-06-11 02:14:18.636466
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = dict(
        b=dict(B=None),
        a=dict(A=None),
        c=dict(C=None),
    )
    from ansible.module_utils.facts.system import Distribution
    assert find_unresolved_requires(['b'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b', 'a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b'])
    assert find_unresolved_requires(['a', 'c'], all_fact_subsets) == set(['b'])

    all_fact_subsets['c']['C'].requires_facts = set(['d'])


# Generated at 2022-06-11 02:14:25.201452
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class FakeCollector(BaseFactCollector):
        name = 'acollector'
        _fact_ids = set(['acollector',
                         'acollector_foo',
                         'acollector_bar'])

        def collect(self):
            return {'acollector_foo': 'foo',
                    'acollector_bar': 'bar'}

    class FakeCollector2(BaseFactCollector):
        name = 'acollector2'
        required_facts = ['acollector_foo']
        _fact_ids = ['acollector2',
                     'acollector2_foo']


# Generated at 2022-06-11 02:14:29.054523
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector import GenericFactCollector

    class MyFactCollector(GenericFactCollector):
        _fact_ids = frozenset(['a', 'b', 'c'])
        name = 'my'

    collector_list = [MyFactCollector]

    (fact_id_to_collector_map, aliases_map) = build_fact_id_to_collector_map(collector_list)

    assert aliases_map['my'] == set(['a', 'b', 'c', 'my'])

    assert fact_id_to_collector_map['my'] == [MyFactCollector]
    assert fact_id_to_collector_map['a'] == [MyFactCollector]

# Generated at 2022-06-11 02:14:38.667751
# Unit test for function tsort
def test_tsort():
    assert tsort({}) == []
    assert tsort({'B': {'A'}, 'A': {}}) == [('A', set()), ('B', {'A'})]
    # B->C->D->E, then A->D, then E
    assert tsort({'B': {'C'}, 'A': {'D'}, 'C': {'D'}, 'D': {'E'}, 'E': {}}) == [
        ('A', {'D'}),
        ('B', {'C'}),
        ('C', {'D'}),
        ('D', {'E'}),
        ('E', set())
    ]


# Generated at 2022-06-11 02:14:45.369154
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from test.units.module_utils.facts.collectors import DummyCollector
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([DummyCollector])
    assert fact_id_to_collector_map == {'dummy': [DummyCollector], 'alias': [DummyCollector]}
    assert aliases_map == {'dummy': {'alias'}}
    assert fact_id_to_collector_map['alias'] == fact_id_to_collector_map['dummy']
    assert id(fact_id_to_collector_map['alias']) == id(fact_id_to_collector_map['dummy'])


# Generated at 2022-06-11 02:14:57.246919
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # mock all the collectors for the test
    class SpecialCollector(BaseFactCollector):
        # These are the fact_ids that this collector provides and the aliases
        # for those facts. This will probably be replaced by a decorator.
        _fact_ids = frozenset(('special1', 'special2'))
        name = 'special'
    class Special2Collector(BaseFactCollector):
        _fact_ids = frozenset(('special1',))
        name = 'special2'

    # pass the collectors to the function and get the result
    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(set((SpecialCollector, Special2Collector, )))

    # Assert the function has returned what it should

# Generated at 2022-06-11 02:15:07.953545
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible_collections.community.general.plugins.module_utils.facts.collectors import hardware
    from ansible_collections.community.general.plugins.module_utils.facts.collectors import network

    hardware.Network = network.Network
    hardware.Network.name = 'network'

    all_fact_subsets = {
        'hardware': [hardware.Hardware, hardware.Network],
        'network': [network.Network],
    }
    collector_names = ['hardware', 'network']
    collector_dep_data = build_dep_data(collector_names, all_fact_subsets)

    # expect network has a dep of network
    assert collector_dep_data['network'] == {'network'}
    # expect hardware has deps of hardware and network

# Generated at 2022-06-11 02:15:17.482947
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        CollectorsTestClass1, CollectorsTestClass2,
        CollectorsTestClass3, CollectorsTestClass4]
    compat_platforms = [{}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    # class2 has the same name as class1, so both should be found
    assert CollectorsTestClass1 in found_collectors
    assert CollectorsTestClass2 in found_collectors
    assert CollectorsTestClass3 not in found_collectors
    assert CollectorsTestClass4 not in found_collectors


# Generated at 2022-06-11 02:15:27.941519
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible_collections.ansible.netcommon.tests.unit.modules.network.common.facts.test_collector_classes import TestFactsCollector
    all_fact_subsets = {
        'fact1': [TestFactsCollector],
        'fact2': [TestFactsCollector],
    }
    collector_names = {
        'fact1',
        'fact2',
    }
    # No unresolved requires here
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()
    # Make fact1 require fact3 which is not in collector_names
    TestFactsCollector.required_facts = {'fact3'}
    collector_names = {
        'fact1',
        'fact2',
    }

# Generated at 2022-06-11 02:15:41.657252
# Unit test for function get_collector_names
def test_get_collector_names():
    assert set(['a', 'b']) == set(get_collector_names(gather_subset=['a', 'b', '!'],
                                                      valid_subsets=frozenset(['a', 'b', 'all']),
                                                      minimal_gather_subset=['min']))



# Generated at 2022-06-11 02:15:54.221540
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        _fact_ids = []
        name = 'Collector1'
        required_facts = set()
    class Collector2(BaseFactCollector):
        _fact_ids = []
        name = 'Collector2'
        required_facts = set()
    class Collector3(BaseFactCollector):
        _fact_ids = []
        name = 'Collector3'
        required_facts = set()
    class Collector4(BaseFactCollector):
        _fact_ids = []
        name = 'Collector4'
        required_facts = set()
    class Collector5(BaseFactCollector):
        _fact_ids = []
        name = 'Collector5'
        required_facts = set()
    class Collector6(BaseFactCollector):
        _fact_ids = []


# Generated at 2022-06-11 02:16:04.470499
# Unit test for function get_collector_names
def test_get_collector_names():
    try:
        get_collector_names(valid_subsets=frozenset())
    except Exception:
        pass
    else:
        assert False, "Exception expected when gather_subset=all and no valid_subsets provided"

    assert minimal_subset == get_collector_names(valid_subsets=frozenset(('all', 'network')),
                                                 gather_subset=['!all'])

    assert minimal_subset == get_collector_names(valid_subsets=frozenset(('all', 'network')),
                                                 gather_subset=['!network'],
                                                 minimal_gather_subset=minimal_subset)


# Generated at 2022-06-11 02:16:11.689123
# Unit test for function build_dep_data
def test_build_dep_data():
    collectors = {'A': [BaseFactCollector()], 'B': [BaseFactCollector()]}
    collectors['A'][0].required_facts = set(['B'])
    collectors['B'][0].required_facts = set(['C'])
    dep_map = build_dep_data(['A'], collectors)
    assert dep_map == {'A': set(['B']), 'B': set(['C'])}



# Generated at 2022-06-11 02:16:20.020469
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector:
        name = 'foo'
        required_facts = set()

    class FakeCollector2:
        name = 'bar'
        required_facts = set()

    class FakeCollector3(FakeCollector):
        name = 'baz'
        required_facts = frozenset(['foo'])

    class FakeCollector4(FakeCollector3):
        name = 'bat'
        required_facts = frozenset(['foo'])

    class FakeCollector5(FakeCollector3):
        name = 'boo'
        required_facts = frozenset(['underscore_is_not_resolved'])

    class FakeCollector6(FakeCollector3):
        name = 'metal'
        required_facts = frozenset(['bar'])


# Generated at 2022-06-11 02:16:30.217516
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_collector_classes = [DummyFactCollectorA, DummyFactCollectorB]

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'].append(DummyFactCollectorA)
    all_fact_subsets['b'].append(DummyFactCollectorB)

    collector_names = ['a']

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

    assert selected_collector_classes == [DummyFactCollectorA]

    collector_names = ['a', 'a', 'b', 'b']

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)


# Generated at 2022-06-11 02:16:37.504906
# Unit test for function get_collector_names
def test_get_collector_names():
    result = get_collector_names(
        valid_subsets=frozenset(['all', 'min', '!foo', '!network', 'network', 'bar']),
        minimal_gather_subset=frozenset(['foo']),
        gather_subset=frozenset(['foo', 'bar', '!network']),
        aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
        platform_info=None
    )
    assert result == frozenset(['bar', 'foo'])



# Generated at 2022-06-11 02:16:48.935785
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def _collector_names_to_classes(collector_names, all_fact_subsets):
        for name in collector_names:
            for collector in all_fact_subsets[name]:
                yield collector
    # just a fake class to use for the tests
    class CollectorClass:
        required_facts = []
        name = None
        def __init__(self, name, required_facts):
            self.required_facts = required_facts
            self.name = name

    # simple test
    all_fact_subsets = {
        'a': [CollectorClass('a', [])],
        'b': [CollectorClass('b', ['a'])],
    }
    collector_names = ['b']

# Generated at 2022-06-11 02:16:59.745466
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # pylint: disable=unused-variable
    class TestRequiredFactCollector(BaseFactCollector):
        _fact_ids = {'required'}
        required_facts = {'required'}
        name = 'required'

    class TestCollector(BaseFactCollector):
        _fact_ids = {'test'}
        required_facts = {'required'}
        name = 'test'

    all_fact_subsets = {
        'test': [TestCollector],
        'required': [TestRequiredFactCollector],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()

    assert find_unresolved_requires(set(), all_fact_subsets) == {'test', 'required'}



# Generated at 2022-06-11 02:17:05.118218
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = {'a', 'b', 'c'}

    def mock_get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return {'b', 'd'}
        if collector_name == 'b':
            return {'e'}
        if collector_name == 'c':
            return {'b'}
        if collector_name == 'd':
            return {}
        if collector_name == 'e':
            return {'d'}
        return {}

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets=None, get_requires_by_collector_name=mock_get_requires_by_collector_name)

    assert unresolved == {'d'}



# Generated at 2022-06-11 02:17:29.974492
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import get_collector_classes

    all_collector_names = set(get_collector_classes().keys())
    all_fact_subsets = dict()
    for collector_name in all_collector_names:
        all_fact_subsets[collector_name] = [get_collector_classes()[collector_name]]

    # Should not return anything when no collector is specified
    result = find_unresolved_requires([], all_fact_subsets)
    assert len(result) == 0

    # Should not return anything when all of the collector requires is satisfied
    result = find_unresolved_requires(all_collector_names, all_fact_subsets)
    assert len(result) == 0

    # Should return collectors that are missing from a subset
   

# Generated at 2022-06-11 02:17:40.161295
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['a'].append(CollectorA)
    all_fact_subsets['b'].append(CollectorB)
    all_fact_subsets['b'].append(CollectorC)

    # Test that no collectors are selected when invalid collectors are asked
    selected_collectors = select_collector_classes(['x'], all_fact_subsets)
    assert selected_collectors == []

    # Test that only one instance of a collector is in the returned list

# Generated at 2022-06-11 02:17:48.741220
# Unit test for function get_collector_names
def test_get_collector_names():
    # Avoid AnsibleDeprecationWarning
    setattr(platform, 'python_implementation', lambda: 'CPython')

    valid_subsets = frozenset(['foo'])
    minimal_gather_subset = frozenset(['minimal', 'bar'])
    aliases_map = defaultdict(set)
    aliases_map['aliased'].add('foo')

    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               gather_subset=[],
                               aliases_map=aliases_map) == frozenset(['bar', 'minimal'])


# Generated at 2022-06-11 02:18:01.275939
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

    import inspect
    import pytest

    class FakeCollectorClass:
        @staticmethod
        def platform_match(platform_info):
            if platform_info.get('system') == 'Linux':
                return TestCollector

    class TestFactCollectorClass(FakeCollectorClass):
        @staticmethod
        def platform_match(platform_info):
            # This should never be called because it is not registered in the test.
            assert False


# Generated at 2022-06-11 02:18:10.072361
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    # Create list of classes for platforms with different names
    class GenericCollector0(BaseFactCollector):
        pass
    class GenericCollector1(BaseFactCollector):
        pass
    class GenericCollector2(BaseFactCollector):
        pass
    class GenericCollector3(BaseFactCollector):
        pass
    class GenericCollector4(BaseFactCollector):
        pass
    class GenericCollector5(BaseFactCollector):
        pass
    class GenericCollector6(BaseFactCollector):
        pass
    class GenericCollector7(BaseFactCollector):
        pass
    class GenericCollector8(BaseFactCollector):
        pass
    class GenericCollector9(BaseFactCollector):
        pass
    class GenericCollector10(BaseFactCollector):
        pass

# Generated at 2022-06-11 02:18:21.678659
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    a = {'a': 'a', 'b': 'c'}
    b = {'a': 'b', 'b': 'c'}
    c = {'a': 'a', 'b': 'c'}
    d = 'a'
    f = {'a': 'b', 'b': 'c', 'x': 'x'}
    g = 'x'
    fact_subsets = {
        'a': [a, c],
        'b': [b],
        'c': [c],
        'd': [d],
        'e': [],
        'f': [f],
        'g': [g]
    }

    assert find_unresolved_requires([], fact_subsets) == set()
    assert find_unresolved_requires(['d'], fact_subsets)

# Generated at 2022-06-11 02:18:31.562653
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from collections import namedtuple
    FactCollectorClass = namedtuple('FactCollectorClass', 'name required_facts')
    c1 = FactCollectorClass('c1', set(['c2', 'c3']))
    c2 = FactCollectorClass('c2', set(['c3']))
    c3 = FactCollectorClass('c3', set([]))
    all_fact_subsets = {
        'c1': [c1],
        'c2': [c2],
        'c3': [c3],
    }

    collector_names = ['c1']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert set(['c2', 'c3']) == unresolved

    collector_names = ['c1', 'c2']
   

# Generated at 2022-06-11 02:18:42.114896
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def setup():
        class Collector1:
            name = 'a'
            required_facts = frozenset(['b'])
        class Collector2:
            name = 'b'
            required_facts = frozenset()

        collector_classes = set([Collector1, Collector2])
        all_fact_subsets = {
            'a': [Collector1],
            'b': [Collector2],
        }
        return collector_classes, all_fact_subsets

    def test_no_required_facts_specified():
        collector_classes, all_fact_subsets = setup()
        collector_names = set(['a'])
        unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
        assert unresolved == set(['b'])


# Generated at 2022-06-11 02:18:53.201408
# Unit test for function select_collector_classes
def test_select_collector_classes():
    def check_result(result, expected_names):
        actual_names = [x.name for x in result]
        assert actual_names == expected_names

    import pytest

    # This code is just to make the tests below work
    class FakeCollector:
        def __init__(self, name):
            self.name = name
            self.required_facts = set()

        def __str__(self):
            return '<FakeCollector name={}>'.format(self.name)

        __repr__ = __str__

    class FakeCollector_A(FakeCollector):
        name = "A"
        _fact_ids = set(["A", "B"])

    class FakeCollector_B(FakeCollector):
        name = "B"

# Generated at 2022-06-11 02:19:06.467413
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Define a class FactCollector1
    class FactCollector1(BaseFactCollector):
        name = 'fact_collector1'
        _fact_ids = set(['f1_fact1'])

    # Define a class FactCollector2
    class FactCollector2(BaseFactCollector):
        name = 'fact_collector2'
        _fact_ids = set(['f2_fact1'])

    # Call the function build_fact_id_to_collector_map with collectors FactCollector1, FactCollector2
    fact_id_to_collector_map_output, aliases_map_output = build_fact_id_to_collector_map([FactCollector1, FactCollector2])

    # Expected output
    fact_id_to_collector_map_expected = defaultdict

# Generated at 2022-06-11 02:19:32.069317
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'collectorA'
    class CollectorA2(BaseFactCollector):
        name = 'collectorA2'
        _fact_ids = set(['a_fact_id'])
    class CollectorB(BaseFactCollector):
        name = 'collectorB'
    class CollectorB2(BaseFactCollector):
        name = 'collectorB2'
        _fact_ids = set(['b_fact_id'])
    class CollectorC(BaseFactCollector):
        name = 'collectorC'
        _fact_ids = set(['c_fact_id'])


# Generated at 2022-06-11 02:19:44.462318
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires function'''
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }

    class MockedCollectorA:
        required_facts = {'b'}
    class MockedCollectorB:
        required_facts = {'c'}
    class MockedCollectorC:
        required_facts = {'d'}

    all_fact_subsets['a'][0].required_facts = MockedCollectorA.required_facts
    all_fact_subsets['b'][0].required_facts = MockedCollectorB.required_facts
    all_fact_subsets['c'][0].required_facts = MockedCollectorC.required_facts

    # all

# Generated at 2022-06-11 02:19:50.345635
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collectors_dict = {
        'a': [1, 2, 3],
        'b': [4, 5]
    }
    collector_names = ['a', 'b']
    expected_result = [1, 2, 3, 4, 5]
    assert select_collector_classes(collector_names, collectors_dict) == expected_result



# Generated at 2022-06-11 02:20:02.493857
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector1': [object()],
        'collector2': [object()],
        'collector3': [object()]
    }

    assert find_unresolved_requires(['collector1'], all_fact_subsets) == set()

    class Collector(object):
        required_facts = ['collector2']
    all_fact_subsets['collector1'] = [Collector()]

    # collector2 isn't mentioned
    assert find_unresolved_requires(['collector1'], all_fact_subsets) == set(['collector2'])

    class Collector(object):
        required_facts = ['collector2']
    all_fact_subsets['collector2'] = [Collector()]

    # collector2 is mentioned but depends on collector3

# Generated at 2022-06-11 02:20:10.833740
# Unit test for function get_collector_names
def test_get_collector_names():
    gathered_facts = get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'virtual', 'hardware', 'identity']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!all', '!network'],
        aliases_map={'hardware': frozenset(['devices', 'dmi']),
                     'identity': frozenset(['facter', 'ohai', 'system_profiler'])}
    )
    assert gathered_facts == frozenset(['virtual'])



# Generated at 2022-06-11 02:20:20.711826
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import json

    all_fact_subsets = all_facts_to_dict({
        'A': ['b'],
        'B': ['c'],
        'C': ['d']
    })

    assert find_unresolved_requires(['A', 'B', 'C'], all_fact_subsets) == set(['d'])

    # duplicate collects are ignored
    assert find_unresolved_requires(['A', 'B', 'C', 'A'], all_fact_subsets) == set(['d'])

    # Requires for collectors not included are ignored
    assert find_unresolved_requires(['A', 'B'], all_fact_subsets) == set()



# Generated at 2022-06-11 02:20:33.502340
# Unit test for function build_dep_data
def test_build_dep_data():
    class foo_col(BaseFactCollector):
        _fact_ids = set(['foo'])
        name = 'foo'
        required_facts = set()
    class bar_col(BaseFactCollector):
        _fact_ids = set(['bar'])
        name = 'bar'
        required_facts = set()
    class baz_col(BaseFactCollector):
        _fact_ids = set(['baz'])
        name = 'baz'
        required_facts = set(['foo'])
    class qux_col(BaseFactCollector):
        _fact_ids = set(['qux'])
        name = 'qux'
        required_facts = set(['bar', 'baz'])


# Generated at 2022-06-11 02:20:39.710906
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {'a': ['a', 'b', 'c'], 'b': ['d', 'e', 'f'], 'c':['g', 'h', 'i']}
    collector_names = ['a', 'b', 'c']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == ['a', 'd', 'g']

    # Now test for duplicate collector names
    collector_names = ['a', 'b', 'c', 'a', 'b', 'c']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == ['a', 'd', 'g']



# Generated at 2022-06-11 02:20:47.038421
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts import collector

    for collector_class in BaseFactCollector.__subclasses__():
        print(collector_class)

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform=BaseFactCollector.__subclasses__())

    assert fact_id_to_collector_map
    assert aliases_map



# Generated at 2022-06-11 02:20:54.708198
# Unit test for function build_dep_data
def test_build_dep_data():
    from . import linux

    all_fact_subsets = {
        'system_platform': [linux.SystemPlatformFactCollector]
    }
    collector_names = ['system_platform']
    assert build_dep_data(collector_names, all_fact_subsets) == {
        'system_platform': set()
    }

    all_fact_subsets = {
        'system_platform': [linux.SystemPlatformFactCollector],
        'system': [linux.SystemFactCollector],
        'virtual': [linux.VirtualFactCollector],
    }
    collector_names = ['system_platform', 'system', 'virtual']

# Generated at 2022-06-11 02:21:28.074006
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'gather_subset1': ['me'],
                        'gather_subset2': ['you'],
                        'gather_subset3': ['gather_subset2', 'GatherSubset1']}
    test_collector_names = ['gather_subset1', 'gather_subset2', 'gather_subset3']
    assert find_unresolved_requires(test_collector_names, all_fact_subsets) == set()
    test_collector_names = ['gather_subset1']
    assert find_unresolved_requires(test_collector_names, all_fact_subsets) == set(['gather_subset2'])
    test_collector_names = ['gather_subset3']
    assert find_un

# Generated at 2022-06-11 02:21:38.279806
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.hardware import Hardware

    module = AnsibleModule
    collectors = [collector.Hardware, collector.Network]
    for_platform = collectors
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(for_platform)
    assert fact_id_to_collector_map == {'hardware': [collector.Hardware],
                                        'devices': [collector.Hardware],
                                        'network': [collector.Network]}

    assert aliases_map == {'hardware': {'hardware', 'devices'}}

