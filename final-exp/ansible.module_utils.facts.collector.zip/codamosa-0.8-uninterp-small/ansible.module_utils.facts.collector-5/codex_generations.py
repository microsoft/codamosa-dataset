

# Generated at 2022-06-24 21:38:20.967924
# Unit test for function get_collector_names
def test_get_collector_names():
    base_fact_collector_1 = BaseFactCollector()
    if base_fact_collector_1:
        pass
    else:
        raise AssertionError("No collector provided for test")
    valid_subsets = frozenset()
    minimal_gather_subset = frozenset()
    aliases_map = defaultdict(set)
    # the list of all collector.
    # we set it to a list of known, non-composite collectos to avoid
    # depending on all of them.
    valid_subsets = {
        'ansible_local',
        'ansible_distribution',
    }
    # minimal_gather_subset
    minimal_gather_subset = frozenset({
        'ansible_local',
        'ansible_distribution',
    })
    # aliases

# Generated at 2022-06-24 21:38:27.323326
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    print('test_find_collectors_for_platform')
    all_collector_classes = [LinuxFactCollector, WindowsFactCollector]
    compat_platforms = [{'system': 'Linux'}, {'system': 'Windows'}]
    assert(find_collectors_for_platform(all_collector_classes, compat_platforms) == set([LinuxFactCollector, WindowsFactCollector]))


# Generated at 2022-06-24 21:38:37.722992
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    test_platform_info = {'system': 'Linux', 'distribution': 'CentOS', 'distribution_version': '7.2.1511', 'distribution_major_version': '7'}
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.virtual.lspci import LSPCIVirtualFactCollector
    for all_collector_class in [DistributionFactCollector, SystemFactCollector, LSPCIVirtualFactCollector]:
        collector = all_collector_class()
        if collector.platform_match(test_platform_info):
            print("Success")
        else:
            print("Failed")



# Generated at 2022-06-24 21:38:49.343244
# Unit test for function tsort
def test_tsort():
    assert tsort({"a": set(["b"]), "b": set(["c"]), "c": set([]), "d": set(["c"])}) == [("a", set(["b"])), ("b", set(["c"])), ("d", set(["c"])), ("c", set([]))]
    assert tsort({"a": set(["f"]), "b": set(["c","e"]), "c": set([]), "d": set(["c"]), "e": set(["d"]), "f": set(["e"])}) == [("a", set(["f"])), ("c", set([])) , ("d", set(["c"])), ("b", set(["c","e"])), ("e", set(["d"])), ("f", set(["e"]))]

# Generated at 2022-06-24 21:38:56.470874
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _platform = 'TestOS1'
        name = 'test1'

    class TestCollector2(BaseFactCollector):
        _platform = 'TestOS2'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'TestOS3'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'TestOS4'
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _platform = 'TestOS5'
        name = 'test5'

    class TestCollector7(BaseFactCollector):
        _platform = 'TestOS7'
        name = 'test7'


# Generated at 2022-06-24 21:39:01.426338
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert select_collector_classes([], {}) == []


# Generated at 2022-06-24 21:39:06.595902
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
        'c': set(['d']),
        'd': set(['e']),
        'e': set([])
    }
    sorted_list = tsort(dep_map)
    sorted_fact_id_list = [item[0] for item in sorted_list]
    assert sorted_fact_id_list == ['e', 'd', 'c', 'b', 'a']



# Generated at 2022-06-24 21:39:15.215897
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.linux import Distribution
    from ansible.module_utils.facts.collector.linux import Network
    from ansible.module_utils.facts.collector.linux import Dmidecode
    from ansible.module_utils.facts.collector.linux import Virtual
    from ansible.module_utils.facts.collector.linux import ShellVar
    from ansible.module_utils.facts.collector.linux import Perf
    from ansible.module_utils.facts.collector.linux import Path
    from ansible.module_utils.facts.collector.linux import PythonVirtualEnv
    from ansible.module_utils.facts.collector.linux import SystemdService
    from ansible.module_utils.facts.collector.linux import Pip

# Generated at 2022-06-24 21:39:21.768619
# Unit test for function select_collector_classes
def test_select_collector_classes():
    all_fact_subsets = {
        'default': [],
        'f1': [base_fact_collector_0],
        'f2': [base_fact_collector_0]
    }
    results = select_collector_classes(['f1', 'f2', 'default'], all_fact_subsets)
    assert len(results) == 1



# Generated at 2022-06-24 21:39:27.294050
# Unit test for function select_collector_classes
def test_select_collector_classes():
    assert BaseFactCollector.platform_match({}) is BaseFactCollector
    assert BaseFactCollector.platform_match({'system': 'Linux'}) is None

    # create a test subclass that matches for 'Linux'
    class MyLinuxCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'LinuxFacts'

    assert MyLinuxCollector.platform_match({}) is None
    assert MyLinuxCollector.platform_match({'system': 'Linux'}) is MyLinuxCollector
    assert MyLinuxCollector.platform_match({'system': 'FreeBSD'}) is None

    # gather_subset is a spec describing which facts to gather.
    # valid_subsets is a frozenset of potential matches for gather_subset ('all', 'network') etc
    # minimal_gather_subsets is a frozens

# Generated at 2022-06-24 21:39:43.986574
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # start with a single test case
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()

    all_fact_subsets = defaultdict(list)

    all_fact_subsets['test1'].extend([ base_fact_collector_0 ])
    all_fact_subsets['test2'].extend([ base_fact_collector_1, base_fact_collector_2 ])

    collector_names = ['test1', 'test2']

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)


# Generated at 2022-06-24 21:39:52.355723
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = 'base_fact_collector_0'
    base_fact_collector_0.required_facts = set()

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = 'base_fact_collector_1'
    base_fact_collector_1.required_facts = set(['base_fact_collector_0'])

    fact_subsets = dict()
    fact_subsets['base_fact_collector_0'] = [base_fact_collector_0]
    fact_subsets['base_fact_collector_1'] = [base_fact_collector_1]


# Generated at 2022-06-24 21:40:00.957850
# Unit test for function get_collector_names

# Generated at 2022-06-24 21:40:11.066641
# Unit test for function build_dep_data
def test_build_dep_data():
    class FakeCollector(BaseFactCollector):
        name = 'fake1'
        required_facts = set(['fact1', 'fact2'])

    class FakeCollector2(BaseFactCollector):
        name = 'fake2'
        required_facts = set(['fact2'])

    all_fact_subsets = {
        'fact1': [FakeCollector],
        'fact2': [FakeCollector, FakeCollector2]
    }

    dep_map = build_dep_data(['fact1', 'fact2'], all_fact_subsets)

    assert dep_map['fact1'] == set(['fact2'])
    assert dep_map['fact2'] == set()



# Generated at 2022-06-24 21:40:20.266454
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # Create 2 classes of fact collectors. Compatible with 2 different platforms.
    class A_Collector_0(BaseFactCollector):
        _platform = 'A'
        name = 'A_Collector_0'
    class A_Collector_1(BaseFactCollector):
        _platform = 'A'
        name = 'A_Collector_1'
    class B_Collector_0(BaseFactCollector):
        _platform = 'B'
        name = 'B_Collector_0'

    # Empty platform_info
    all_collector_classes = (A_Collector_0,A_Collector_1,B_Collector_0)
    compat_platforms = tuple()

# Generated at 2022-06-24 21:40:30.483802
# Unit test for function select_collector_classes
def test_select_collector_classes():
    bfc_0 = BaseFactCollector(name='foo')
    bfc_1 = BaseFactCollector(name='foo', aliases=['bar'])
    bfc_2 = BaseFactCollector(name='bar')
    bfc_3 = BaseFactCollector(name='baz')
    bfc_4 = BaseFactCollector(name='bar')

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['foo'].append(bfc_0)
    all_fact_subsets['foo'].append(bfc_1)
    all_fact_subsets['bar'].append(bfc_2)
    all_fact_subsets['bar'].append(bfc_4)
    all_fact_subsets['baz'].append(bfc_3)

    selected

# Generated at 2022-06-24 21:40:39.959781
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Setup
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_3 = BaseFactCollector()
    base_fact_collector_4 = BaseFactCollector()
    base_fact_collector_5 = BaseFactCollector()

    base_fact_collector_2._fact_ids.add('base_fact_collector_5')
    base_fact_collector_3._fact_ids.add('base_fact_collector_5')
    base_fact_collector_4._fact_ids.add('base_fact_collector_5')

# Generated at 2022-06-24 21:40:48.676852
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = 'platform'
    base_fact_collector_0._fact_ids = set(['platform'])
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = 'virtual'
    base_fact_collector_1._fact_ids = set(['virtual'])
    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_2.name = 'hardware'
    base_fact_collector_2._fact_ids = set(['devices', 'dmi'])

    test = [base_fact_collector_0, base_fact_collector_1, base_fact_collector_2]

# Generated at 2022-06-24 21:40:58.528601
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test simple case of get_collector_names
    assert get_collector_names(valid_subsets=['all'], gather_subset=['all']) == frozenset(['all'])

    # Test exclude case of get_collector_names
    try:
        get_collector_names(valid_subsets=['all'], gather_subset=['!all'])
    except TypeError:
        pass
    else:
        raise AssertionError("Expecting to get TypeError exception")

    # Test bad case of get_collector_names
    try:
        get_collector_names(valid_subsets=['all'], gather_subset=['bad'])
    except TypeError:
        pass
    else:
        raise AssertionError("Expecting to get TypeError exception")

    #

# Generated at 2022-06-24 21:41:07.452435
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Get the list of all the collectors in module_utils
    from ansible.module_utils.facts import collectors as ansible_collectors
    from ansible.module_utils._text import to_text

    all_collector_classes = set()
    for collector_name in dir(ansible_collectors):
        collector_class = getattr(ansible_collectors, collector_name)
        if not hasattr(collector_class, 'name'):
            continue

        all_collector_classes.add(collector_class)

    # test case
    # 1) Platform should match with Darwin, but not Linux
    # 2) Platform should match with Linux, but not Darwin
    # 3) Platform should match with Linux(System) and Darwin(System)
    # 4) Platform should match with Darwin, but not Linux
    # 5) Platform should

# Generated at 2022-06-24 21:41:24.420920
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Setup
    all_collector_classes = []
    compat_platforms = []
    # Exercise
    result = find_collectors_for_platform(all_collector_classes, compat_platforms)
    # Verify
    assert result == set()
    # Cleanup - none necessary



# Generated at 2022-06-24 21:41:32.412015
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = set()
    all_fact_subsets = defaultdict(list)
    all_fact_subsets['distribution'].append(BaseFactCollector())
    all_fact_subsets['distribution'].append(BaseFactCollector())

    all_fact_subsets['dmi'].append(BaseFactCollector())
    all_fact_subsets['dmi'].append(BaseFactCollector())

    select_collector_classes(collector_names, all_fact_subsets)

    collector_names.add('distribution')
    collector_names.add('dmi')

    select_collector_classes(collector_names, all_fact_subsets)


# Generated at 2022-06-24 21:41:44.708493
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class FakeCollector(object):
        def __init__(self, name, required_facts):
            self.name = name
            self.required_facts = required_facts

    all_fact_subsets = dict()

    # Add fact subset 'foo', with a collector named 'foo', requiring 'bar'
    collector = FakeCollector('foo', ['bar'])
    all_fact_subsets['foo'] = [collector]

    # Add fact subset 'bar', with a collector named 'bar', requiring 'baz'
    collector = FakeCollector('bar', ['baz'])
    all_fact_subsets['bar'] = [collector]

    # Add fact subset 'baz', with a collector named 'baz', requiring nothing
    collector = FakeCollector('baz', [])
    all_fact_subsets['baz']

# Generated at 2022-06-24 21:41:51.454841
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['basic'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['network'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['all'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b'])
    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d', 'a'])

    all_collector_classes = [
        CollectorA(),
        CollectorB(),
        CollectorC(),
        CollectorD(),
        CollectorE()
    ]

    # build a fact

# Generated at 2022-06-24 21:42:01.858687
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test case 1: single class is given as input
    class test_case_1(BaseFactCollector):
        name = 'test_case_1'
    base_fact_collector_1 = test_case_1()
    subset = [base_fact_collector_1]
    selected_collectors = select_collector_classes(subset, subset)
    assert selected_collectors == [base_fact_collector_1]

    # Test case 2: duplicate class is given as input, ensure only one instance
    # exists in the list
    class test_case_2(BaseFactCollector):
        name = 'test_case_2'
    base_fact_collector_2 = test_case_2()

# Generated at 2022-06-24 21:42:12.899722
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = "base_fact_collector_0"
    base_fact_collector_0.required_facts = set(["base_fact_collector_0"])

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = "base_fact_collector_1"
    base_fact_collector_1.required_facts = set(["base_fact_collector_0", "base_fact_collector_1"])

    # all_fact_subsets is the output of build_fact_id_to_collector_map
    all_fact_subsets = defaultdict(list)

# Generated at 2022-06-24 21:42:20.492338
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector_a': [BaseFactCollector()],
        'collector_b': [BaseFactCollector()],
        'collector_c': [BaseFactCollector()],
    }
    collector_names = ['collector_a', 'collector_b', 'collector_c']
    # Verify that len of unresolved is zero
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0
    # Verify that len of unresolved is one
    collector_names = ['collector_a', 'collector_b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 1
    # Verify that len of unresolved is two

# Generated at 2022-06-24 21:42:31.203922
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c', 'd']
    all_fact_subsets = {
        'a': [object(), object(), object()],
        'b': [object(), object(), object()],
        'c': [object(), object(), object()],
        'd': [object(), object(), object()],
    }

    dep_data = build_dep_data(collector_names, all_fact_subsets)
    assert isinstance(dep_data, defaultdict)
    assert len(dep_data.keys()) == 4
    # assert list(dep_data.keys()) == ['a', 'b', 'c', 'd']
    assert list(dep_data.keys()) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-24 21:42:40.934317
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class_collector_0 = BaseFactCollector()
    class_collector_0._fact_ids = set(['collector_0_fact_0', 'collector_0_fact_1'])
    class_collector_0.name = 'class_collector_0'
    class_collector_1 = BaseFactCollector()
    class_collector_1._fact_ids = set(['collector_1_fact_0', 'collector_1_fact_1'])
    class_collector_1.name = 'class_collector_1'

    collectors_for_platform = [class_collector_0, class_collector_1]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

   

# Generated at 2022-06-24 21:42:43.841371
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    all_collector_classes = [BaseFactCollector()]
    collectors_for_platform = []
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert fact_id_to_collector_map == defaultdict(list)
    assert aliases_map == defaultdict(set)
    assert aliases_map.get('Generic') == set()


# Generated at 2022-06-24 21:43:40.654328
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = set(['network', 'hardware'])
    minimal_gather_subset = set(['network'])
    gather_subset = ['network', 'hardware']
    result = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset)
    assert result == set(['network', 'hardware'])


# Generated at 2022-06-24 21:43:51.765328
# Unit test for function get_collector_names
def test_get_collector_names():
    # Creating a list of collector names
    subset_name = ['!all', 'all', 'network']
    # Creating a frozenset that contains all the names
    valid_subsets = frozenset(subset_name)
    # The valid subset name that should always be included
    minimal_gather_subset = frozenset(['sensor'])
    # The subset name that we need to get the corresponding collector names
    gather_subset = ['sensor', '!all']
    # The aliases map that should always be included
    aliases_map = defaultdict(set)
    aliases_map['network'] = set(['network_info'])
    # Create an object of type AnsibleModule
    platform_info = {'system': 'Arista'}
    # Test get_collector_names with different combinations of arguments
    collector_

# Generated at 2022-06-24 21:43:58.925468
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # test simple collector with no aliases
    test_case_0 = BaseFactCollector()
    collector_classes = [test_case_0]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_classes)
    assert set(fact_id_to_collector_map.keys()) == set(test_case_0._fact_ids)
    assert test_case_0 in fact_id_to_collector_map['test']

    # test collector with aliases and one other collector
    test_case_1 = BaseFactCollector()
    test_case_1.name = 'test_case_1'
    test_case_1._fact_ids.add('alias_1')
    test_case_1._fact_ids.add('alias_2')

# Generated at 2022-06-24 21:44:09.793762
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    fact_id_to_collector_map = defaultdict(list)
    test_name = 'test_name'
    required_fact_in_map = 'required_fact_in_map'
    required_fact_not_in_map = 'required_fact_not_in_map'
    required_facts = (required_fact_in_map, required_fact_not_in_map,)

    class TestCollectorClass(BaseFactCollector):
        name = test_name
        required_facts = required_facts
    fact_id_to_collector_map[required_fact_in_map].append(TestCollectorClass)

    collector_names = (required_fact_in_map, test_name,)
    all_fact_subsets = fact_id_to_collector_map
    unresolved = find_unresolved

# Generated at 2022-06-24 21:44:17.309105
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # expected: set(['collector0', 'collector2'])
    all_fact_subsets = {
        'collector0': [BaseFactCollector()],
        'collector1': [BaseFactCollector()],
        'collector2': [BaseFactCollector()],
        'collector3': [BaseFactCollector()],
    }
    collector_names = ['collector1', 'collector3']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['collector0', 'collector2'])



# Generated at 2022-06-24 21:44:28.663007
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorsA(BaseFactCollector):
        name = 'a'
        _fact_ids = ['b', 'c']
    class CollectorsB(BaseFactCollector):
        name = 'b'
        _fact_ids = ['d', 'e']

    # test for no collectors
    assert([]) == build_fact_id_to_collector_map([])

    # test for more than one collector
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([CollectorsA, CollectorsB])

# Generated at 2022-06-24 21:44:38.875349
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Test with all option set to true
    class MyFactCollector_0(BaseFactCollector):
        name = 'dummy_0'
        required_facts = ('a','b','c','d')
    class MyFactCollector_1(BaseFactCollector):
        name = 'dummy_1'
        required_facts = ('a','b','c','d')
    class MyFactCollector_2(BaseFactCollector):
        name = 'dummy_2'
        required_facts = ('a','b','c','d')
    class MyFactCollector_3(BaseFactCollector):
        name = 'dummy_3'
        required_facts = ('a','b','c','d')
    class MyFactCollector_4(BaseFactCollector):
        name = 'dummy_4'
        required_facts

# Generated at 2022-06-24 21:44:49.341330
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class fact_collector_0(BaseFactCollector):
        name = 'fact_0'

    class fact_collector_1(BaseFactCollector):
        name = 'fact_1'

    class fact_collector_2(BaseFactCollector):
        name = 'fact_2'

    class fact_collector_3(BaseFactCollector):
        name = 'fact_3'

    class fact_collector_4(BaseFactCollector):
        name = 'fact_4'

    class fact_collector_5(BaseFactCollector):
        name = 'fact_5'

    class fact_collector_6(BaseFactCollector):
        name = 'fact_6'

    class fact_collector_7(BaseFactCollector):
        name = 'fact_7'


# Generated at 2022-06-24 21:44:53.811904
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Testing with a list of all_collector_classes, gather_subset=['all'], minimal_gather_subset=['min']
    all_collector_classes = [BaseFactCollector]
    minimal_gather_subset = ['min']
    gather_subset = ['all']
    platforms_info = {'system': 'FreeBSD'}
    collector_classes = collector_classes_from_gather_subset(all_collector_classes=all_collector_classes,
                                                             minimal_gather_subset=minimal_gather_subset,
                                                             gather_subset=gather_subset,
                                                             platform_info=platforms_info)
    # test whether the list of collectors selected are as expected

# Generated at 2022-06-24 21:44:56.960732
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'subset_0': [base_fact_collector_0]}
    collector_names = ('subset_0')
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved


# Generated at 2022-06-24 21:45:32.099257
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_3 = BaseFactCollector()
    base_fact_collector_4 = BaseFactCollector()

    collector_names = ['name_0', 'name_1', 'name_2', 'name_3', 'name_4']

# Generated at 2022-06-24 21:45:38.966498
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    collector_names = set()
    collector_names.add('fact1')
    collector_names.add('fact2')
    collector_names.add('fact3')
    collector_names.add('fact4')
    collector_nnames.add('fact5')
    dep_map = build_dep_data(collector_names, dep_map)
    assert dep_map['fact1'] == set(), 'Test Failed: Function build_dep_data'
    assert dep_map['fact2'] == set(), 'Test Failed: Function build_dep_data'
    assert dep_map['fact3'] == set(), 'Test Failed: Function build_dep_data'
    assert dep_map['fact4'] == set(), 'Test Failed: Function build_dep_data'

# Generated at 2022-06-24 21:45:46.425804
# Unit test for function build_dep_data
def test_build_dep_data():

    # build list of collector classes
    all_collector_classes = [
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
        BaseFactCollector,
    ]

    # build collector names
    collector_names = ['collector_0']

    all_fact_subsets = defaultdict(list)

    # build fact subsets
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    # build dep data
    dep_map = build_dep_data(collector_names, all_fact_subsets)

    # positive test case; check if dep data has collector_0
    assert 'collector_0' in dep_map


#

# Generated at 2022-06-24 21:45:54.058665
# Unit test for function build_dep_data
def test_build_dep_data():
    # create Fact subset 'foo'
    class FactCollectorFoo(BaseFactCollector):
        name = 'foo'
        _fact_ids = frozenset(['foo_id_0'])
        required_facts = set(['hardware'])

    all_fact_subsets = {
        'foo': [FactCollectorFoo]
    }

    collector_names = ['hardware', 'foo']

    deps = build_dep_data(collector_names, all_fact_subsets)
    assert deps['hardware'] == set()
    assert deps['foo'] == {'hardware'}


# Generated at 2022-06-24 21:46:01.535521
# Unit test for function select_collector_classes
def test_select_collector_classes():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0._fact_ids = set()

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids = set()

    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_2._fact_ids = set()

    base_fact_collector_3 = BaseFactCollector()
    base_fact_collector_3._fact_ids = set()

    base_fact_collector_4 = BaseFactCollector()
    base_fact_collector_4._fact_ids = set()

    base_fact_collector_5 = BaseFactCollector()
    base_fact_collector_5._fact_ids = set()

   

# Generated at 2022-06-24 21:46:10.666894
# Unit test for function build_dep_data
def test_build_dep_data():
    fact_collector_0 = BaseFactCollector()
    fact_collector_1 = BaseFactCollector()
    fact_collector_2 = BaseFactCollector()
    fact_collector_3 = BaseFactCollector()
    fact_collector_4 = BaseFactCollector()
    fact_collector_5 = BaseFactCollector()
    fact_collector_6 = BaseFactCollector()
    fact_collector_7 = BaseFactCollector()

    fact_collector_0.name = 'fact_collector_0'
    fact_collector_1.name = 'fact_collector_1'
    fact_collector_2.name = 'fact_collector_2'
    fact_collector_3.name = 'fact_collector_3'

# Generated at 2022-06-24 21:46:19.480882
# Unit test for function get_collector_names
def test_get_collector_names():
    platform_info = {'system': 'Generic'}
    gather_subset = ['all']
    valid_subsets = [
        'all',
        'min',
        'hardware',
        'network',
        'virtual',
        'identity',
        'system'
    ]
    aliases_map = {
        'hardware': ['devices', 'dmi'],
        'virtual': ['docker', 'facter']
    }
    fact_collector_names = get_collector_names(valid_subsets = valid_subsets,
                                               minimal_gather_subset = {'min'},
                                               gather_subset = gather_subset,
                                               aliases_map = aliases_map,
                                               platform_info = platform_info)

# Generated at 2022-06-24 21:46:28.326756
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1: no unresolved requirement
    all_fact_subsets = {
        'TestCollector0': [BaseFactCollector],
        'TestCollector1': [BaseFactCollector],
    }

    try:
        collector_names = {'TestCollector0', 'TestCollector1'}
        unresolved_collector_names = find_unresolved_requires(collector_names, all_fact_subsets)

        assert not unresolved_collector_names
    except:
        raise AssertionError('Failed to find no unresolved requirements')

    # Test 2: one unresolved requirement
    all_fact_subsets = {
        'TestCollector0': [BaseFactCollector],
        'TestCollector1': [BaseFactCollector],
    }


# Generated at 2022-06-24 21:46:38.385012
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()

    base_fact_collector_0.required_facts = ['base_fact_collector_1']
    base_fact_collector_1.required_facts = ['base_fact_collector_2']
    base_fact_collector_2.required_facts = set()

    base_fact_collector_0.name = 'base_fact_collector_0'
    base_fact_collector_1.name = 'base_fact_collector_1'
    base_fact_collector_2.name = 'base_fact_collector_2'

    collector_names = ['base_fact_collector_0']

# Generated at 2022-06-24 21:46:45.705222
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b']
    all_fact_subsets = {
        'a': [
            type('MockCollector0', (BaseFactCollector,), {'required_facts': set(['b']), 'name': 'a'}),
        ],
        'b': [
            type('MockCollector1', (BaseFactCollector,), {'required_facts': set(['a']), 'name': 'b'}),
        ],
    }

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()
