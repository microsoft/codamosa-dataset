

# Generated at 2022-06-24 21:37:59.651273
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class_0 = BaseFactCollector()
    class_1 = BaseFactCollector()
    class_2 = BaseFactCollector()
    class_3 = BaseFactCollector()
    class_list = [class_0, class_1, class_2, class_3]
    result = build_fact_id_to_collector_map(class_list)
    assert result[0][0] == [class_0]
    assert result[0][1] == [class_1]
    assert result[0][2] == [class_2]
    assert result[0][3] == [class_3]


# Generated at 2022-06-24 21:38:04.358082
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Find any collector names that have unresolved requires
    # Returns a list of collector names that correspond to collector
    # classes whose .requires_facts() are not in collector_names.
    #
    # Expected
    # 1. var_0 should be set to ['min'].
    #
    test_case_0()


# Generated at 2022-06-24 21:38:05.221104
# Unit test for function build_dep_data
def test_build_dep_data():
    assert callable(build_dep_data)


# Generated at 2022-06-24 21:38:11.075121
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        CollectorA(),
        CollectorB(),
        CollectorC()
    ]
    compat_platforms = [
        CollectorC.platform_info,
        CollectorB.platform_info
    ]

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert len(found_collectors) == 2
    assert CollectorC in found_collectors
    assert CollectorB in found_collectors



# Generated at 2022-06-24 21:38:22.130248
# Unit test for function build_dep_data
def test_build_dep_data():
    assert not build_dep_data(set(), {})
    assert not build_dep_data(['a'], {})
    assert build_dep_data(['a'], {'a': []}) == {'a': set()}
    assert build_dep_data(['a'], {'a': [], 'b': []}) == {'a': set()}
    assert build_dep_data(['a', 'b'], {'a': [], 'b': []}) == {'a': set(), 'b': set()}
    # test multiple collectors with different deps
    assert build_dep_data(['a'], {'a': [MockCollector(['b', 'c'])]}) == {'a': set(['b', 'c'])}

# Generated at 2022-06-24 21:38:31.967796
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collectors

    all_collector_classes = collectors.get_collector_classes()
    gathered_platform = platform.platform()
    compat_platforms = (gathered_platform, {'system': 'Generic'})
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    print("found_collectors ", found_collectors)
    for collector in found_collectors:
        print("collector ", collector.name)
        print("collector ", collector.required_facts)
        print("collector ", collector._fact_ids)
    print("")


# Generated at 2022-06-24 21:38:33.999498
# Unit test for function get_collector_names
def test_get_collector_names():
    args_0 = []
    # Test case 0
    test_case_0()



# Generated at 2022-06-24 21:38:39.936904
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collector_for_platform = []
    fact_id_to_collector_map = defaultdict(list)

    collector_for_platform.append("hello")
    collector_for_platform.append("world")

    # Check the positive condition
    fact_id_to_collector_map["hello"].append("hello")
    fact_id_to_collector_map["world"].append("world")

    assert build_fact_id_to_collector_map(collector_for_platform) == fact_id_to_collector_map


# Generated at 2022-06-24 21:38:46.579639
# Unit test for function get_collector_names
def test_get_collector_names():
    test_cases = [0]
    for i in test_cases:
        print("*" * 50)
        if(i == 0):
            print("Test Case " + str(i)) 
            test_case_0()
            print("*" * 50 + "\n")
# Main function for testing
if __name__ == "__main__":
    test_get_collector_names()

# Generated at 2022-06-24 21:38:52.580261
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    list_0 = []
    list_1 = []
    list_2 = []

    # Test case 0
    var_0 = get_collector_names(list_0)
    found_collectors = find_collectors_for_platform(var_0, list_1)
    assert len(found_collectors) > 0
    # Test case 1

    # Test case 2
    found_collectors = find_collectors_for_platform(var_0, [])
    assert len(found_collectors) == 0



# Generated at 2022-06-24 21:39:09.097549
# Unit test for function get_collector_names
def test_get_collector_names():
    # Init input arguments
    test_0 = {}

    # Call the function
    result = get_collector_names(**test_0)

    # Check result
    assert result is None


# Generated at 2022-06-24 21:39:10.287955
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    print(find_unresolved_requires(var_0))


# Generated at 2022-06-24 21:39:19.248639
# Unit test for function get_collector_names
def test_get_collector_names():
    # Init arguments used for the test
    var_0 = [
        'all',
        'network',
    ]
    var_1 = [
        'all',
        'network',
        'min',
        '!all',
        '!network',
    ]
    var_2 = []
    var_3 = []
    var_4 = []
    retval = get_collector_names(var_0, var_1, var_2, var_3, var_4)
    assert retval == { 'min' }, "Return value does not match expected value"


# Generated at 2022-06-24 21:39:24.596080
# Unit test for function build_dep_data
def test_build_dep_data():
    assert ('assert' in dir(__builtins__))
    var_arg_0 = ['name_0']
    var_arg_1 = {'name_0': [__builtins__.object()]}
    var_res_0 = build_dep_data(var_arg_0, var_arg_1)
    assert (var_res_0 in (['name_0'],))


# Generated at 2022-06-24 21:39:27.397282
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    try:
        var_0 = []
        assert find_unresolved_requires(var_0, var_0) == set()
    except Exception as e:
        print('Caught exception: %s' % e)



# Generated at 2022-06-24 21:39:35.311175
# Unit test for function tsort
def test_tsort():
    all_fact_subsets = {'my_facts': [('<class \'ansible_collections.community.general.plugins.modules.collectors.my_facts.MyFactCollector\'>', ['my_facts', 'my_dep_fact'])], 'my_dep_fact': [('<class \'ansible_collections.community.general.plugins.modules.collectors.my_dep.MyDepCollector\'>', ['my_dep_fact'])]}
    collector_names = ['my_dep_fact', 'my_facts']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    sorted_list = tsort(dep_map)
    assert sorted_list == [('my_dep_fact', set()), ('my_facts', {'my_dep_fact'})]


# Generated at 2022-06-24 21:39:37.014868
# Unit test for function tsort
def test_tsort():
    var_0 = []
    test_case_0()

if __name__ == "__main__":
    test_tsort()

# Generated at 2022-06-24 21:39:40.459433
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = test_case_0()
    expected = None
    actual = build_fact_id_to_collector_map(collectors_for_platform)
    assert actual == expected


# Generated at 2022-06-24 21:39:46.666112
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    var_0 = [{'system': 'test'}]
    var_1 = set()
    var_2 = find_collectors_for_platform(var_1, var_0)
    assert var_2 == set(), "find_collectors_for_platform should return set()"


# Generated at 2022-06-24 21:39:57.860890
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=None,
                        minimal_gather_subset=None,
                        gather_subset=['all'],
                        aliases_map=None,
                        platform_info=None) == set([])
    assert get_collector_names(valid_subsets=None,
                        minimal_gather_subset=None,
                        gather_subset=['min'],
                        aliases_map=None,
                        platform_info=None) == set([])
    assert get_collector_names(valid_subsets=None,
                        minimal_gather_subset=None,
                        gather_subset=['not_min'],
                        aliases_map=None,
                        platform_info=None) == set(['not_min'])

# Generated at 2022-06-24 21:40:21.392777
# Unit test for function get_collector_names
def test_get_collector_names():
    # Arrange
    valid_subsets=frozenset(("network","foo"))
    gather_subset=["min","network"]
    aliases_map=defaultdict(set,{"network":("ethernet","ipv4")})

    # Act
    result = get_collector_names(valid_subsets, gather_subset=gather_subset, aliases_map=aliases_map)

    # Assert
    assert result == frozenset(("min","ethernet","ipv4"))

    # Arrange
    valid_subsets=frozenset(("network","foo"))
    gather_subset=["!min","!network"]
    aliases_map=defaultdict(set,{"network":("ethernet","ipv4")})

    # Act

# Generated at 2022-06-24 21:40:27.152146
# Unit test for function build_dep_data
def test_build_dep_data():
    var_0 = []
    var_0.append("dmi")
    var_0.append("devices")
    dep_map = build_dep_data(var_0,all_fact_subsets)
    if (len(dep_map) > 1):
        return False
    return True


# Generated at 2022-06-24 21:40:34.639113
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    var_0 = ['__main__.TestCollector_4', '__main__.TestCollector_2',
             '__main__.TestCollector_3']
    var_1 = defaultdict(list)
    var_1['test_fc_1'].append(var_0[0])
    var_1['test_fc_1'].append(var_0[2])
    var_1['test_fc_2'].append(var_0[1])
    var_1['test_fc_3'].append(var_0[2])
    var_1['test_fc_4'].append(var_0[0])
    var_1['test_fc_5'].append(var_0[0])
    var_1['test_fc_6'].append(var_0[0])


# Generated at 2022-06-24 21:40:42.557605
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # input:
    collector_names = ['foo', 'bar', 'baz', 'qux', 'quux']
    all_fact_subsets = {'foo': ['Requires bar and baz.'], 'bar': ['Requires foo and baz.'], 'baz': ['Requires foo and bar.'], 'qux': ['Requires quux.'], 'quux': ['Requires qux.']}

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-24 21:40:47.217470
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    assert find_collectors_for_platform([test_find_collectors_for_platform()], test_find_collectors_for_platform()) == test_find_collectors_for_platform()


# Generated at 2022-06-24 21:40:49.391798
# Unit test for function tsort
def test_tsort():
    var_1 = []
    for value in var_0:
        var_1 = tsort(value)


# Generated at 2022-06-24 21:40:52.796176
# Unit test for function get_collector_names
def test_get_collector_names():
    assert True


# Generated at 2022-06-24 21:40:57.119614
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    const_0 = ('a', 'b')
    const_1 = ('a', 'b', 'c')
    # Testing for ValueError: (('a', 'b', 'c'), ('a', 'b')) is not a subset of ('a', 'b')
    try:
        print("Testing for ValueError: (('a', 'b', 'c'), ('a', 'b')) is not a subset of ('a', 'b')")
        test_case_0()
    except ValueError as error:
        print("Caught exception:", error)


# Generated at 2022-06-24 21:41:05.868022
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    var_0 = []
    var_0.append('hardware')
    var_0.append('network')
    var_0.append('virtual')
    var_0.append('system')

    expected_result = set([])

    from ansible.module_utils.facts.system.base import BaseFactCollector

    class hardware(BaseFactCollector):
        pass

    class network(BaseFactCollector):
        pass

    class virtual(BaseFactCollector):
        pass

    class system(BaseFactCollector):
        pass

    all_fact_subsets = {'system': [system], 'virtual': [virtual],
                       'network': [network], 'hardware': [hardware]}

    actual_result = find_unresolved_requires(var_0, all_fact_subsets)

    assert actual_result == expected

# Generated at 2022-06-24 21:41:12.466942
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with this fixed input
    var_0 = []
    expected_0 = set()
    actual_0 = find_unresolved_requires(var_0)
    assert actual_0 == expected_0, "Failed test_find_unresolved_requires_0"
    if actual_0 != expected_0:
        print("Failed for test_find_unresolved_requires_0: expected {}, got {}".format(
            actual_0,
            expected_0,
        ))
    print("test_find_unresolved_requires_0: OK")
    
# Test of functions find_unresolved_requires and find_unresolved_requires

# Generated at 2022-06-24 21:41:33.787836
# Unit test for function get_collector_names
def test_get_collector_names():
    names = get_collector_names(gather_subset=['network'],
                                valid_subsets=frozenset(['network', 'hardware', 'virtual']),
                                minimal_gather_subset=frozenset([]),
                                platform_info={})
    assert names == set(['network'])

    # Negating a subset removes all sub-items (ex. '!hardware' removes 'devices')
    names = get_collector_names(gather_subset=['!hardware'],
                                valid_subsets=frozenset(['network', 'hardware', 'virtual', 'devices']),
                                minimal_gather_subset=frozenset([]),
                                platform_info={})
    assert names == set(['network', 'virtual'])

    # Neg

# Generated at 2022-06-24 21:41:45.919000
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case 1
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = 'architecture'

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = 'distribution'
    base_fact_collector_1.required_facts = set()

    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_2.name = 'virtualization'
    base_fact_collector_2.required_facts = set(['architecture'])

    base_fact_collector_3 = BaseFactCollector()
    base_fact_collector_3.name = 'operating_system'

# Generated at 2022-06-24 21:41:55.311183
# Unit test for function tsort
def test_tsort():
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6

    # Create test maps
    # Map 1
    dep_map_1 = {
        a: {b, c},
        b: {d},
        c: {d},
        d: {e},
        e: {f},
        f: {}
    }
    # Map 2
    dep_map_2 = {
        a: {b, c},
        b: {d},
        c: {d},
        d: {e},
        e: {f},
        f: {a}
    }
    # Map 3

# Generated at 2022-06-24 21:42:05.097745
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)
    class_0 = BaseFactCollector()
    all_fact_subsets['test-case-0'].append(class_0)
    collector_names = ['test-case-0']
    assert len(find_unresolved_requires(collector_names, all_fact_subsets)) == 0
    all_fact_subsets['test-case-1'].append(class_0)
    collector_names.append('test-case-1')
    assert len(find_unresolved_requires(collector_names, all_fact_subsets)) == 0
    class_1 = BaseFactCollector()
    class_1.required_facts = set(['test-case-0'])

# Generated at 2022-06-24 21:42:14.866585
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class test_class_0(BaseFactCollector):
        _fact_ids = {'test_fact_0'}
        _platform = 'Generic'
        _required_facts = set()
    class test_class_1(BaseFactCollector):
        _fact_ids = {'test_fact_1'}
        _platform = 'Generic'
        _required_facts = set()
    class test_class_2(BaseFactCollector):
        _fact_ids = {'test_fact_2'}
        _platform = 'Generic'
        _required_facts = set()
    class test_class_3(BaseFactCollector):
        _fact_ids = {'test_fact_3'}
        _platform = 'Generic'
        _required_facts = set()

    found_collectors = find_collectors_

# Generated at 2022-06-24 21:42:22.393238
# Unit test for function get_collector_names
def test_get_collector_names():
    # Extracted from Ansible (https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/hardware/dmi.py)
    valid_subsets = frozenset()
    gather_subset = ['all']
    platform_info = {'distribution': '', 'distribution_major_version': '', 'distribution_release': '',
                     'distribution_version': '', 'kernel': '', 'system': 'Linux'}
    # Extracted from Ansible (https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/__init__.py).

# Generated at 2022-06-24 21:42:25.309284
# Unit test for function tsort
def test_tsort():
    a = {"a": set(["b", "c"]),
         "b": set(["d"]),
         "c": set(["d"]),
         "d": set()
        }
    expected = [('a', set(['b', 'c'])), ('c', set(['d'])), ('b', set(['d'])), ('d', set([]))]
    assert tsort(a) == expected


# Generated at 2022-06-24 21:42:34.317063
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a' : [ base_fact_collector_0 ],
        'b' : [ base_fact_collector_0 ],
        'c' : [ base_fact_collector_0 ],
        'd' : [ base_fact_collector_0 ]
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b', 'c'], all_fact_subsets) == set()
    assert find_unresolved_requires(['a', 'b', 'c'], all_fact_subsets) == set()
    assert find_unresolved_requires(['a', 'z', 'c'], all_fact_subsets) == set('z')


# Generated at 2022-06-24 21:42:41.405277
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    all_fact_subsets = defaultdict(set)
    all_fact_subsets['A'] = set([base_fact_collector_0])
    all_fact_subsets['B'] = set([base_fact_collector_0])
    all_fact_subsets['C'] = set([base_fact_collector_0])
    all_fact_subsets['D'] = set([base_fact_collector_0])

    base_fact_collector_0.required_facts = set(['B', 'C', 'D'])

    collector_names = set(['A', 'B', 'D'])

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['C'])


# Generated at 2022-06-24 21:42:45.684692
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b']
    collector_0 = BaseFactCollector()
    collector_0.name = 'a'
    collector_1 = BaseFactCollector()
    collector_1.name = 'b'

    all_fact_subsets = {
        'a': [
            collector_0,
        ],
        'b': [
            collector_1,
        ]
    }

    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == defaultdict(set)


# Generated at 2022-06-24 21:42:54.927882
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    def dummy_fact_collector_A():
        pass

    def dummy_fact_collector_B():
        pass

    def dummy_fact_collector_C():
        pass

    all_collector_classes = [dummy_fact_collector_A, dummy_fact_collector_B, dummy_fact_collector_C]
    all_valid_subsets = frozenset(all_collector_classes)
    minimal_gather_subset = frozenset()
    valid_subsets = frozenset()
    gather_subset = ['!A', 'B']
    platform_info = {'system': 'Generic'}


# Generated at 2022-06-24 21:43:04.018980
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 0
    all_fact_subsets = {
        'collector_0': [
            BaseFactCollector,
        ],
    }
    collector_names = ['collector_0']

    assert(find_unresolved_requires(collector_names, all_fact_subsets) == set())

    # Test case 1
    collector_names = ['collector_0', 'collector_1']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert(len(unresolved) == 1)
    assert(unresolved == set(['collector_1']))


# Generated at 2022-06-24 21:43:15.188787
# Unit test for function tsort
def test_tsort():
    dep_map = dict()

    # Create a dictionary
    dep_map = {
        'Node0': {'Node2', 'Node3'},
        'Node1': {'Node3'},
        'Node2': {'Node4'},
        'Node3': {'Node4'},
        'Node4': {'Node5'},
        'Node5': {'Node0'}
    }

    # Call a function to check for a cycle
    try:
        tsort(dep_map)
        assert 0, "Should have failed with CycleFoundInFactDeps"
    except CycleFoundInFactDeps as e:
        pass

    # Create a dictionary to test tsort

# Generated at 2022-06-24 21:43:23.214339
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0._fact_ids = { 'name_0' }
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids = { 'name_1' }
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map( [ base_fact_collector_0, base_fact_collector_1 ] )
    if 'name_0' not in fact_id_to_collector_map:
        raise AssertionError("'name_0' not in fact_id_to_collector_map")
    if 'name_1' not in fact_id_to_collector_map:
        raise Assertion

# Generated at 2022-06-24 21:43:29.245937
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Test(BaseFactCollector):
        name = 'Test'
        required_facts = {}
    class TestA(BaseFactCollector):
        name = 'TestA'
        required_facts = {'Test'}
    class TestB(BaseFactCollector):
        name = 'TestB'
        required_facts = {'Test'}
    class TestC(BaseFactCollector):
        name = 'TestC'
        required_facts = {'TestA', 'TestB'}
    class TestD(BaseFactCollector):
        name = 'TestD'
        required_facts = {'TestA', 'TestB'}

    collectors = [TestA,
                  TestB,
                  TestD]

    all_fact_subsets = defaultdict(list)
    for collector_class in collectors:
        all_fact

# Generated at 2022-06-24 21:43:39.572019
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'network': [BaseFactCollector()],
                        'os': [BaseFactCollector()],
                        'hardware': [BaseFactCollector()],
                        'virtual': [BaseFactCollector()],
                        'gather_subset': [BaseFactCollector()],
                        'devices': [BaseFactCollector()],
                        'facter_legacy': [BaseFactCollector()],
                        'dmi': [BaseFactCollector()],
                        'puppet_legacy': [BaseFactCollector()]}

    collector_names = ['network', 'os']
    print('test 1: collector_names: ' + str(collector_names))
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved


# Generated at 2022-06-24 21:43:45.738532
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'test0': [test_case_0]}
    collector_names = ['test0']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved
    assert find_unresolved_requires([], all_fact_subsets) == set()



# Generated at 2022-06-24 21:43:54.805442
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Verifies that an empty list of collectors results in an empty dictionary.
    assert build_fact_id_to_collector_map([]) == ({}, defaultdict(set))

    # Verifies that a list of collectors returns the appropriate fact_id_to_collector_map.

# Generated at 2022-06-24 21:43:58.681978
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = defaultdict(set)

    all_fact_subsets['foo'].add(BaseFactCollector())
    all_fact_subsets['bar'].add(BaseFactCollector())

    dep_map = build_dep_data(['foo', 'bar'], all_fact_subsets)

    assert dep_map == {
        'foo': set(),
        'bar': set(),
    }



# Generated at 2022-06-24 21:44:06.761218
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FakeCollector(object):
        name = "fake_collector"
        _fact_ids = set()

    fake_collector = FakeCollector()
    fake_collector_array = []
    fake_collector_array.append(fake_collector)

    expected_result = defaultdict(list)
    expected_result["fake_collector"] = fake_collector_array
    result = build_fact_id_to_collector_map(fake_collector_array)
    assert result == expected_result



# Generated at 2022-06-24 21:44:17.546002
# Unit test for function get_collector_names
def test_get_collector_names():
    gather_subset = ['all']
    valid_subsets = ('network', 'hardware')
    minimal_gather_subset = ('minimal_subset_1', 'minimal_subset_2')
    aliases_map = {'hardware': ('devices', 'dmi')}
    expected_gather_subset_names = ('network', 'hardware', 'devices', 'dmi', 'minimal_subset_1', 'minimal_subset_2')
    gather_subset_names = get_collector_names(valid_subsets=valid_subsets,
                                              minimal_gather_subset=minimal_gather_subset,
                                              aliases_map=aliases_map,
                                              gather_subset=gather_subset)

# Generated at 2022-06-24 21:44:23.922244
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    linux_platform = {'system': 'Linux'}
    darwin_platform = {'system': 'Darwin'}

    # Test Class0
    class Collector0(BaseFactCollector):
        _platform = 'Linux'
        _fact_ids = ('test0',)
    # Test Class1
    class Collector1(BaseFactCollector):
        _platform = 'Darwin'
        _fact_ids = ('test1',)
    # Test Class2
    class Collector2(BaseFactCollector):
        _platform = 'Generic'
        _fact_ids = ('test2',)

    all_collectors = [Collector0, Collector1, Collector2,]

    # Test linux
    found_collectors = find_collectors_for_platform(all_collectors, [linux_platform])

    # should find all


# Generated at 2022-06-24 21:44:30.599087
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class BaseFactCollectorA(BaseFactCollector):
        _fact_ids = set(['id1', 'id2'])
        name = 'name1'
    class BaseFactCollectorB(BaseFactCollector):
        _fact_ids = set(['id3', 'id4'])
        name = 'name2'
    collector_classes = [BaseFactCollectorA, BaseFactCollectorB]
    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(collector_classes)
    assert fact_id_to_collector_map['id1'] == [BaseFactCollectorA]
    assert fact_id_to_collector_map['id2'] == [BaseFactCollectorA]

# Generated at 2022-06-24 21:44:39.200893
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Unit tests for function get_collector_names.'''

    # basic gathering
    assert get_collector_names(minimal_gather_subset=frozenset(['!all']),
                               gather_subset=['something']) == frozenset(['something'])

    # minimal gathering
    assert get_collector_names(minimal_gather_subset=frozenset(['minimal']),
                               gather_subset=['!all']) == frozenset(['minimal'])

    # aliases_map tests

# Generated at 2022-06-24 21:44:49.734767
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import (collectors as all_collectors,
                                            linux as linux_collectors,
                                            netbsd as netbsd_collectors,
                                            windows as windows_collectors,
                                            sunos as sunos_collectors,
                                            openbsd as openbsd_collectors)

    # Create a fake platform set
    linux_platform_info = {'system': 'Linux'}
    compat_platforms = [linux_platform_info]

    # Retrieve all available fact collectors
    all_collector_classes = all_collectors.collector_classes
    assert(len(all_collector_classes) > 100)

    # Check that we do not find any fact collector for a fake platform
    all_collector_classes.extend([BaseFactCollector])

# Generated at 2022-06-24 21:44:57.716769
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_0 = BaseFactCollector()
    collector_0.required_facts = set(['a', 'b'])
    collector_0.name = 'c0'
    collector_1 = BaseFactCollector()
    collector_1.required_facts = set(['c', 'd'])
    collector_1.name = 'c1'

    class PlatformFactCollector(BaseFactCollector):
        name = 'platform'

    platform_info = {'system': 'Linux'}
    platform_fact_collector = PlatformFactCollector()

    all_subsets = {
        collector_0.name: [collector_0],
        collector_1.name: [collector_1],
        platform_fact_collector.name: [platform_fact_collector]
    }

    deps = build_dep_data

# Generated at 2022-06-24 21:45:04.305158
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [test_case_0]
    compat_platforms = {'system': platform.system()}

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert len(found_collectors) == 1



# Generated at 2022-06-24 21:45:11.713040
# Unit test for function get_collector_names

# Generated at 2022-06-24 21:45:22.577312
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyFactCollector(BaseFactCollector):
        _fact_ids = frozenset(['myfact'])
        name = 'myfact'
    class MyOtherFactCollector(MyFactCollector):
        _fact_ids = frozenset(['myotherfact'])
        name = 'myfact'

    if platform.system() != 'Linux':
        # skips unit test if we're not on Linux.
        # on windows test fails with:
        #   AttributeError: module 'platform' has no attribute 'linux_distribution'
        return
    collectors = {
        'myfact': MyFactCollector,
        'myotherfact': MyOtherFactCollector,
        'system': BaseFactCollector
    }


# Generated at 2022-06-24 21:45:32.050521
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['timezone', 'version']
    all_fact_subsets = {
        'timezone': [
            BaseFactCollector,
            BaseFactCollector,
            BaseFactCollector,
        ],
        'version': [
            BaseFactCollector,
            BaseFactCollector,
            BaseFactCollector,
        ]
    }

    ret = find_unresolved_requires(collector_names, all_fact_subsets)
    assert ret == set()

    collector_names = ['timezone']

# Generated at 2022-06-24 21:45:43.759164
# Unit test for function get_collector_names
def test_get_collector_names():

    # Test case 0
    platform_info_0 = {}
    aliases_map_0 = {}
    valid_subsets_0 = ('all', 'min', '!hardware', '!network')
    gather_subset_0 = ('network', 'min')
    minimal_gather_subset_0 = ('!hardware', 'network')
    collector_names = get_collector_names(valid_subsets=valid_subsets_0,
                                          minimal_gather_subset=minimal_gather_subset_0,
                                          gather_subset=gather_subset_0,
                                          aliases_map=aliases_map_0,
                                          platform_info=platform_info_0)
    assert collector_names == {'network'}

    # Test case 1
    platform_info

# Generated at 2022-06-24 21:45:54.097504
# Unit test for function get_collector_names
def test_get_collector_names():
    try:
        get_collector_names(valid_subsets=set(), gather_subset=['min'])
    except TypeError:
        pass
    else:
        raise Exception("Did not raise TypeError on empty valid_subsets with 'min' in gather_subset")
    try:
        get_collector_names(valid_subsets=set(), gather_subset=['unknown'])
    except TypeError:
        pass
    else:
        raise Exception("Did not raise TypeError on empty valid_subsets with 'unknown' in gather_subset")

    assert get_collector_names(valid_subsets=set(), gather_subset=['unknown'], aliases_map={'unknown': set(['A'])}) == set(['A'])


# Generated at 2022-06-24 21:46:01.587278
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Foobar(BaseFactCollector):
        _fact_ids = set(['bar', 'foo'])
        name = 'foobar'

    # Single FactCollector
    collectors_for_platform = [Foobar]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert len(fact_id_to_collector_map) == 3
    assert 'foobar' in fact_id_to_collector_map
    assert 'bar' in fact_id_to_collector_map
    assert 'foo' in fact_id_to_collector_map

    assert 'foobar' in aliases_map
    assert len(aliases_map['foobar']) == 2

# Generated at 2022-06-24 21:46:10.498104
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # GIVEN: a set of valid subsets and a set of collectors
    valid_subsets = frozenset(['software', 'hardware', 'network'])
    minimal_gather_subset = frozenset(['hardware'])
    gather_subset = ['!all']

    # GIVEN: A set of BaseFactCollector classes
    BaseCollector = BaseFactCollector
    class HardwareCollector(BaseCollector):
        name = 'hardware'
        required_facts = {'software'}

    class SoftwareCollector(BaseCollector):
        name = 'software'
        required_facts = set()

    class NetworkCollector(BaseCollector):
        name = 'network'
        required_facts = {'software', 'hardware'}


# Generated at 2022-06-24 21:46:20.206604
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # fact collector classes necessary for test
    class Class1(BaseFactCollector):
        _fact_ids = frozenset(['Class1'])
        name = 'Class1'
        required_facts = frozenset(['Class2'])

    class Class2(BaseFactCollector):
        _fact_ids = frozenset(['Class2'])
        name = 'Class2'
        required_facts = frozenset(['Class3'])

    class Class3(BaseFactCollector):
        _fact_ids = frozenset(['Class3', 'Class3-alias'])
        name = 'Class3'
        required_facts = frozenset(['Class1'])

    # test case with no unresolved dependencies
    collector_names = frozenset(['Class1', 'Class2', 'Class3'])
    all

# Generated at 2022-06-24 21:46:23.572951
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'base': [BaseFactCollector]}
    unresolved = find_unresolved_requires(
        collector_names=['base'],
        all_fact_subsets=all_fact_subsets
    )

    assert not unresolved



# Generated at 2022-06-24 21:46:33.698794
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    all_fact_subsets = defaultdict(set)
    collector_names = [('test0', 'test1', 'test2', 'test3', 'test4')]

    BaseFactCollector.required_facts = set()
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.required_facts = set(['test1'])
    base_fact_collector_0._fact_ids = set(['test0', 'test1'])

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.required_facts = set(['test2'])
    base_fact_collector_1._fact_ids = set(['test1', 'test2'])

    base_fact_

# Generated at 2022-06-24 21:46:40.397771
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0._fact_ids.update(['fact_id_0', 'fact_id_1'])

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids.update(['fact_id_2', 'fact_id_3'])

    collectors_for_platform = [base_fact_collector_0, base_fact_collector_1]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    return fact_id_to_collector_map


# Generated at 2022-06-24 21:46:48.835334
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()

    base_fact_collector_0.required_facts = set(['1'])
    base_fact_collector_1.required_facts = set(['2'])
    base_fact_collector_2.required_facts = set(['3', '4'])

    collectors_dict = {
        '0': [base_fact_collector_0],
        '1': [base_fact_collector_1],
        '2': [base_fact_collector_2]
    }
    
    initial_collectors = set(['0', '1'])

# Generated at 2022-06-24 21:46:54.962661
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collectors
    all_fact_subsets = collectors.collector_registry._fact_subsets

    collector_names = ['all']
    
    # test case 0
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert (dep_map['all'] == {'ansible_distribution_major_version', 'ansible_distribution', 'ansible_machine', 'ansible_distribution_release', 'ansible_os_family', 'ansible_distribution_version', 'ansible_architecture', 'ansible_distribution_file_parsed'})



# Generated at 2022-06-24 21:47:17.071875
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    BaseFactCollectorClass = BaseFactCollector
    class FactCollector0(BaseFactCollectorClass):
        pass
    class FactCollector1(BaseFactCollectorClass):
        pass
    class FactCollector2(BaseFactCollectorClass):
        pass
    class FactCollector3(BaseFactCollectorClass):
        pass
    class FactCollector4(BaseFactCollectorClass):
        pass
    class FactCollector5(BaseFactCollectorClass):
        pass

    # Test case 0: No unresolved requires

# Generated at 2022-06-24 21:47:26.407881
# Unit test for function get_collector_names
def test_get_collector_names():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    aliases_map = {
        'hardware': set(['devices', 'dmi']),
    }
    platform_info = {
        'system': 'Linux',
    }
    # get the collector names using all the defaults. Should return 'all'
    # which is the only item in valid_subsets
    result = get_collector_names()
    assert result == set(['all'])

    # try a negative subset
    gather_subset = ['!all']
    result = get_collector_names(gather_subset=gather_subset,
                                 minimal_gather_subset=set(['min']))
    assert result == set(['min'])

    #

# Generated at 2022-06-24 21:47:32.548097
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_collector_names = {'pci_devices'}
    test_all_fact_subsets = {'pci_devices': [base_fact_collector_0, base_fact_collector_0]}
    assert find_unresolved_requires(test_collector_names, test_all_fact_subsets) == set()


# Generated at 2022-06-24 21:47:38.926942
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    all_fact_collectors = [ base_fact_collector_0, base_fact_collector_1, base_fact_collector_2 ]
    result = collector_classes_from_gather_subset( all_fact_collectors )
    assert result == [ base_fact_collector_0, base_fact_collector_1, base_fact_collector_2 ]


# Generated at 2022-06-24 21:47:45.032210
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    required_facts = set()
    required_facts.add("name0")
    required_facts.add("name1")
    class FactCollector0(BaseFactCollector):
        _fact_ids = set()
        required_facts = required_facts
    class FactCollector1(BaseFactCollector):
        _fact_ids = set()
        required_facts = set()
    class FactCollector2(BaseFactCollector):
        _fact_ids = set()
        required_facts = required_facts
    class FactCollector3(BaseFactCollector):
        _fact_ids = set()
        required_facts = required_facts
    class FactCollector4(BaseFactCollector):
        _fact_ids = set()
        required_facts = required_facts
    class FactCollector5(BaseFactCollector):
        _