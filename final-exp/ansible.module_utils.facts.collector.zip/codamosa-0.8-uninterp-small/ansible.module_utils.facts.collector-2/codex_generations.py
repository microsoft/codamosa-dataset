

# Generated at 2022-06-24 21:38:18.613387
# Unit test for function select_collector_classes
def test_select_collector_classes():
    foo_collector_class = type('FooCollector', (BaseFactCollector,), {'name': 'foo', 'required_facts': ['bar']})
    bar_collector_class = type('BarCollector', (BaseFactCollector,), {'name': 'bar', 'required_facts': []})
    baz_collector_class = type('BazCollector', (BaseFactCollector,), {'name': 'baz'})

    fact_id_to_collector_map = defaultdict(list)
    fact_id_to_collector_map['bar'].append(bar_collector_class)
    fact_id_to_collector_map['foo'].append(foo_collector_class)

# Generated at 2022-06-24 21:38:27.900759
# Unit test for function tsort
def test_tsort():
    """Test for tsort function

    This function checks for the function tsort for its functionality.
    """

    # Test case 0:
    # Check if cycle_found_in_fact_deps_0 is an instance of CycleFoundInFactDeps
    assert isinstance(cycle_found_in_fact_deps_0, CycleFoundInFactDeps)

    # Test case 1:
    # Check if the value of sorted_list returned by tsort function is equal to true_sorted_list
    # when dep_map has no cycles
    dep_map = {'0': ['1', '2'], '1': ['3'], '2': ['3'], '3': []}

# Generated at 2022-06-24 21:38:38.153425
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'os': [object()],
        'network': [object(), object()],
        'kernel': [object()]
        }

    all_fact_subsets['network'][0].required_facts = set(['os'])
    all_fact_subsets['network'][1].required_facts = set(['os'])
    all_fact_subsets['kernel'][0].required_facts = set(['network'])

    collector_names = set(['os', 'network', 'kernel'])

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert len(dep_map['os']) == 0
    assert dep_map['network'] == set(['os'])

# Generated at 2022-06-24 21:38:49.769333
# Unit test for function build_dep_data
def test_build_dep_data():
    class Test1(BaseFactCollector):
        name = 'Test1'
        required_facts = set(['Test2'])
    class Test2(BaseFactCollector):
        name = 'Test2'
        required_facts = set(['Test1'])

    collectors = [Test1, Test2]
    collector_classes = dict((collector.name, collector) for collector in collectors)

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    module = FakeModule()

    # This should raise CycleFoundInFactDeps
    dep_map = build_dep_data(['Test1', 'Test2'], collector_classes)

# Generated at 2022-06-24 21:38:56.778119
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector0(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector_0'
        required_facts = set()

    class TestCollector1(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector_1'
        required_facts = set()

    test_fact_id_to_collector_map, test_aliases_map = build_fact_id_to_collector_map([TestCollector0, TestCollector1])
    assert (test_fact_id_to_collector_map['test_collector_0'][0] == TestCollector0)

# Generated at 2022-06-24 21:39:07.889376
# Unit test for function build_dep_data
def test_build_dep_data():
    class collector_0(BaseFactCollector):
        _fact_ids = set()
        name = 'collector_0'
        required_facts = set()

    class collector_1(BaseFactCollector):
        _fact_ids = set()
        name = 'collector_1'
        required_facts = {'collector_0'}

    class collector_2(BaseFactCollector):
        _fact_ids = set()
        name = 'collector_2'
        required_facts = {'collector_1'}

    class collector_3(BaseFactCollector):
        _fact_ids = set()
        name = 'collector_3'
        required_facts = {'collector_2'}

    class collector_4(BaseFactCollector):
        _fact_ids = set()

# Generated at 2022-06-24 21:39:17.323240
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'Collector_A'
        required_facts = ('B',)

    class CollectorB(BaseFactCollector):
        name = 'Collector_B'
        required_facts = ('A',)

    class CollectorC(BaseFactCollector):
        name = 'Collector_C'
        required_facts = ('D',)

    class CollectorD(BaseFactCollector):
        name = 'Collector_D'
        required_facts = ()

    class CollectorE(BaseFactCollector):
        name = 'Collector_E'
        required_facts = ()

    collector_classes = [
        CollectorA,
        CollectorB,
        CollectorC,
        CollectorD,
        CollectorE,
    ]

    all_fact_subsets = defaultdict(list)
   

# Generated at 2022-06-24 21:39:26.950524
# Unit test for function tsort
def test_tsort():
    tsorted = tsort({'a': {'b'}, 'b': {'c', 'd'}, 'c': {'f'}, 'd': {'e', 'f'}, 'e': {'f', 'g'}})
    assert tsorted == [('a', {'b'}), ('b', {'c', 'd'}), ('c', {'f'}), ('d', {'e', 'f'}), ('e', {'f', 'g'}), ('f', set()), ('g', set())]

# Generated at 2022-06-24 21:39:37.138552
# Unit test for function tsort
def test_tsort():
    # This should pass
    sorted_list = tsort({'a': ['b'], 'b': [], 'c': ['b'], 'd': ['c', 'a']})

    # The result should be ['b','c','a','d']
    assert sorted_list[0][0] == 'b' and sorted_list[1][0] == 'c' and sorted_list[2][0] == 'a' and sorted_list[3][0] == 'd'

    # This should produce an exception of type CycleFoundInFactDeps
    cycle_found_in_fact_deps_0 = CycleFoundInFactDeps()
    try:
        tsort({'a': ['b'], 'b': ['c'], 'c': ['a']})
    except CycleFoundInFactDeps:
        cycle_found_in_

# Generated at 2022-06-24 21:39:47.280940
# Unit test for function find_unresolved_requires

# Generated at 2022-06-24 21:40:00.609265
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest

    class DepCollectorA(BaseFactCollector):
        name = 'dep_a'
        required_facts = set(['dep_b', 'dep_c'])

    class DepCollectorB(BaseFactCollector):
        name = 'dep_b'
        required_facts = set(['dep_c'])

    class DepCollectorC(BaseFactCollector):
        name = 'dep_c'
        required_facts = set()

    # Test case 1:
    collector_names = ['dep_a']

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['dep_a'].append(DepCollectorA)
    all_fact_subsets['dep_b'].append(DepCollectorB)

# Generated at 2022-06-24 21:40:11.399637
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector],
        'd': [BaseFactCollector], }
    # Set up some cyclical dependencies
    all_fact_subsets['a'][0].required_facts.add('a')
    all_fact_subsets['b'][0].required_facts.add('c')
    all_fact_subsets['c'][0].required_facts.add('b')
    all_fact_subsets['d'][0].required_facts.add('a')
    # Raises CycleFoundInFactDeps if cycle exists

# Generated at 2022-06-24 21:40:20.143157
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'hardware': [
            type('Foo', (BaseFactCollector,), {'required_facts': set(['os', 'dmi']), 'name': 'hardware'}),
        ],
        'os': [
            type('Foo', (BaseFactCollector,), {'required_facts': set(), 'name': 'os'}),
        ],
        'dmi': [
            type('Foo', (BaseFactCollector,), {'required_facts': set(), 'name': 'dmi'}),
        ],
    }
    collector_names = frozenset(['hardware'])

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-24 21:40:30.262111
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test collectorA to collect fact1 and fact2
    class collectorA(BaseFactCollector):
        _platform = 'Generic'
        name = 'collectorA'
        # required_facts is the set of facts this collector depends on
        required_facts = set()

        def collect(self):
            return {'fact1': 'fact1', 'fact2': 'fact2'}

    # Test collectorB to collect fact1 and fact3
    class collectorB(BaseFactCollector):
        _platform = 'Generic'
        name = 'collectorB'
        # required_facts is the set of facts this collector depends on
        required_facts = set()

        def collect(self):
            return {'fact1': 'fact1', 'fact3': 'fact3'}

    # Test collectorC to collect fact2 and fact3

# Generated at 2022-06-24 21:40:39.165943
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(set(['a', 'b', 'c']), {'a': [], 'b': [], 'c': []}) == \
           {'a': set(), 'b': set(), 'c': set()}

    assert build_dep_data(set(['a', 'b', 'c']), {'a': [], 'b': [get_collector_classes_for_fact_deps_0], 'c': []}) == \
           {'a': set(), 'b': {'d', 'e'}, 'c': set()}



# Generated at 2022-06-24 21:40:44.893340
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # setup
    with open("test/data/all_fact_subsets.txt") as f:
        all_fact_subsets_str = f.read()
        all_fact_subsets = eval(all_fact_subsets_str)

    # invocation
    unresolved = find_unresolved_requires(('sysinfo',), all_fact_subsets)

    # verification
    assert (unresolved == set())


# Generated at 2022-06-24 21:40:52.997685
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # Test an empty list of collection classes
    # Parameters
    all_collector_classes = []
    compat_platforms = [
        {'system': 'AIX'},
        {'system': 'SunOS'},
        {'system': 'Linux'},
        {'system': 'FreeBSD'},
        {'system': 'OpenBSD'},
        {'system': 'NetBSD'},
        {'system': 'DragonFly'},
        {'system': 'Darwin'},
        {'system': 'HP-UX'},
        {'system': 'Windows'}
    ]

    # Execution
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    # Verification
    assert [] == found_collectors

    # Test an empty list of compatible platforms

# Generated at 2022-06-24 21:41:01.293793
# Unit test for function select_collector_classes
def test_select_collector_classes():

    # Declare a map of all collector classes that could be used
    all_fact_subsets = {
        "base": [BaseFactCollector],
        "foo": [BaseFactCollector, BaseFactCollector],
        "bar": [BaseFactCollector, BaseFactCollector],
    }

    # Check that an empty list is returned if an empty list is input
    assert select_collector_classes([], all_fact_subsets) == []

    # Check that an empty list is returned if an invalid collector name is input
    assert select_collector_classes(["invalid"], all_fact_subsets) == []

    # Check that a list containing the only BaseFactCollector is returned if a valid name is input
    assert select_collector_classes(["base"], all_fact_subsets) == [BaseFactCollector]

    # Check

# Generated at 2022-06-24 21:41:09.677596
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    class FactCollector1(BaseFactCollector):
        _fact_ids = set(['f1a', 'f1b'])

    class FactCollector2(BaseFactCollector):
        _fact_ids = set(['f2a', 'f2b'])

    class FactCollector3(BaseFactCollector):
        _fact_ids = set(['f3a', 'f3b'])

    class FactCollector4(BaseFactCollector):
        _fact_ids = set(['f4a', 'f4b'])

    class FactCollector5(BaseFactCollector):
        _fact_ids = set(['f5a', 'f5b'])

    class FactCollector6(BaseFactCollector):
        _fact_ids = set(['f6a', 'f6b'])

   

# Generated at 2022-06-24 21:41:12.309996
# Unit test for function get_collector_names
def test_get_collector_names():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=[]),
        ),
        supports_check_mode=True,
    )
    module.exit_json(changed=True)


# Generated at 2022-06-24 21:41:28.087354
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    # Test 0:
    #   collector_names: ['a', 'b', 'c']
    #   requires_facts:
    #      a: ['d', 'e']
    #      b: ['f', 'g']
    #      c: ['g', 'h']
    # Answer:
    #    ['d', 'e', 'f']
    collector_names = ['a', 'b', 'c']

    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector],
    }
    all_fact_subsets['a'][0].required_facts = {'d', 'e'}
    all_fact_subsets['b'][0].required_facts = {'f', 'g'}
   

# Generated at 2022-06-24 21:41:32.872448
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    t0 = test_case_0()
    if t0 != None:
        print("test_case_0: FAILED")
        return False
    print("test_case_0: PASSED")



# Generated at 2022-06-24 21:41:40.217015
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with default value for each argument
    get_collector_names()

    # Test with all named arguments
    get_collector_names(valid_subsets=frozenset(), minimal_gather_subset=frozenset(), gather_subset=['all'], aliases_map=defaultdict(set), platform_info=None)



# Generated at 2022-06-24 21:41:42.286861
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['test'], {'test': 'test'}) == {'test': {'test'}}



# Generated at 2022-06-24 21:41:46.737224
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = defaultdict(set)
    all_fact_subsets = defaultdict(set)
    collector_names = set()

    try:
        test_dep_map = build_dep_data(collector_names, all_fact_subsets)
    except Exception as exc:
        assert type(exc) is CycleFoundInFactDeps
    else:
        assert 0, "Expected CycleFoundInFactDeps"


# Generated at 2022-06-24 21:41:55.244392
# Unit test for function get_collector_names
def test_get_collector_names():

    # Empty gather subset in case of empty list pass
    assert get_collector_names(gather_subset=[]) == frozenset()

    # Empty gather subset in case of None pass
    assert get_collector_names(gather_subset=None) == frozenset()

    # Empty gather subset in case of 'all' pass
    assert get_collector_names(gather_subset=['all']) == frozenset()


# Generated at 2022-06-24 21:42:04.981178
# Unit test for function find_unresolved_requires

# Generated at 2022-06-24 21:42:14.825093
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires([], {}) == set()
    assert find_unresolved_requires(['a'], {'a': []}) == set()
    assert find_unresolved_requires(['a'], {'a': [object()]}) == set()
    assert find_unresolved_requires(['a'], {'a': [object()], 'b': [object()]}) == set()
    assert find_unresolved_requires(['a'], {'a': [object()], 'b': [object()]}) == set()
    assert find_unresolved_requires(['a'], {'a': [object()], 'b': [object(), object()]}) == set()

# Generated at 2022-06-24 21:42:22.393967
# Unit test for function select_collector_classes
def test_select_collector_classes():

    # Test case with collector_names = [] and all_fact_subsets = {}
    collector_names = []
    all_fact_subsets = {}
    assert select_collector_classes(collector_names, all_fact_subsets) == []

    # Test case with collector_names = ['all'] and all_fact_subsets = {'all':[], 'test_test': ['a', 'b']},
    # 'all' and 'test_test' are the keys of all_fact_subsets.
    collector_names = ['all']
    all_fact_subsets = {'all':[], 'test_test': ['a', 'b']}
    assert select_collector_classes(collector_names, all_fact_subsets) == []

    # Test case with collector_names = ['all', 'test_test

# Generated at 2022-06-24 21:42:27.047595
# Unit test for function get_collector_names

# Generated at 2022-06-24 21:42:38.791690
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = { 'network' }
    all_fact_subsets = { 'network' : [BaseFactCollector] }
    dep_map = { 'network' : set() }
    dep_data = build_dep_data(collector_names, all_fact_subsets)
    if dep_map != dep_data:
        print('test_build_dep_data failed')
        print('expected: %s' % dep_map)
        print('returned: %s' % dep_data)


# Generated at 2022-06-24 21:42:50.507399
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test collector set that does not produce a conflict, but does produce 2 collectors
    all_collector_classes = [
        type('Collector0', (BaseFactCollector, ), dict(name='collector0',
                                                       _fact_ids={'collector0', },
                                                       required_facts=set())),
        type('Collector1', (BaseFactCollector, ), dict(name='collector1',
                                                       _fact_ids={'collector1', },
                                                       required_facts=set())),
    ]
    collectors_for_platform = find_collectors_for_platform(all_collector_classes, [{}, ])

# Generated at 2022-06-24 21:43:02.001156
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no optional argument
    assert set(['min']) == set(get_collector_names())

    # Test with no optional argument added
    assert set(['min', 'network', 'package']) == set(get_collector_names(valid_subsets=frozenset(['network', 'package', 'hardware'])))

    # Test with gather_subset=network
    assert set(['min', 'network']) == set(get_collector_names(gather_subset=['network'],
                                                              valid_subsets=frozenset(['network', 'package', 'hardware'])))

    # Test with gather_subset=!network

# Generated at 2022-06-24 21:43:05.347782
# Unit test for function build_dep_data
def test_build_dep_data():
    assert build_dep_data(['a', 'b', 'c'], {'a': {'b', 'c'}, 'b': {'c'}, 'c': set()}) == {'a': {'b', 'c'}, 'b': {'c'}, 'c': set()}



# Generated at 2022-06-24 21:43:13.218893
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import _get_collectors

    # No unresolved dependencies
    collector_names = set(['facter'])
    all_fact_subsets = _get_collectors()[0]
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    # Resolved dependency
    collector_names = set(['online_macs', 'facter'])
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    # Unresolved dependency
    collector_names = set(['online_macs', 'facter', 'network_interfaces'])

# Generated at 2022-06-24 21:43:17.969337
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = set()
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-24 21:43:24.155197
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    test_class = BaseFactCollector()
    test_class.name = 'class_name'
    test_class._fact_ids = ['class_name', 'small_name']
    collectors_for_platform = [test_class]
    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(collectors_for_platform)
    test_value = {'class_name': [test_class], 'small_name': [test_class]}
    assert fact_id_to_collector_map == test_value, "Expected %s but got %s." % (test_value, fact_id_to_collector_map)



# Generated at 2022-06-24 21:43:29.902314
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_collector_names = ['!all', 'network']
    test_all_fact_subsets = {'!all': [], 'network': []}
    assert find_unresolved_requires(test_collector_names, test_all_fact_subsets) == set()

    test_all_fact_subsets = {'!all': [], 'network': [], '!inventory': []}
    assert find_unresolved_requires(test_collector_names, test_all_fact_subsets) == set()

    test_collector_names = ['!all', 'network', '!inventory']
    test_all_fact_subsets = {'!all': [], 'network': ['!inventory']}

# Generated at 2022-06-24 21:43:39.307839
# Unit test for function build_dep_data

# Generated at 2022-06-24 21:43:50.967854
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = dict()
    all_fact_subsets['A'] = [object]
    all_fact_subsets['B'] = [object]
    all_fact_subsets['C'] = [object]
    all_fact_subsets['D'] = [object]

    # case 0: no unresolved requires, return empty list.
    collector_names = ['A']
    assert sorted(find_unresolved_requires(collector_names, all_fact_subsets)) == []

    # case 1: unresolved requires found, return non-empty list.
    collector_names = ['A', 'B']
    assert sorted(find_unresolved_requires(collector_names, all_fact_subsets)) == ['A', 'B']

    # case 2: empty list of collector names, return empty list.
    collector

# Generated at 2022-06-24 21:44:02.193966
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collectors_for_platform = set()
    collectors_for_platform.add(PlatformFactCollector)
    collectors_for_platform.add(ArchitectureFactCollector)
    collectors_for_platform.add(UnameFactCollector)

    all_fact_subsets = {}
    for collector_class in collectors_for_platform:
        all_fact_subsets.setdefault(collector_class.name, []).append(collector_class)
        for fact_id in collector_class._fact_ids:
            all_fact_subsets.setdefault(fact_id, []).append(collector_class)

    collector_names = ['all']

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

    assert set(unresolved) == set()


# Generated at 2022-06-24 21:44:07.557643
# Unit test for function get_collector_names
def test_get_collector_names():

    # Test with all valid subsets
    valid_subsets = frozenset(['all', 'network', 'hardware'])
    minimal_gather_subset = frozenset()
    aliases_map = defaultdict(set)
    aliases_map['hardware'] = frozenset(['devices', 'dmi'])

    # Create sets of subsets
    test_gather_subset_0 = frozenset()
    test_gather_subset_1 = frozenset(['all'])
    test_gather_subset_2 = frozenset(['!all'])
    test_gather_subset_3 = frozenset(['network'])
    test_gather_subset_4 = frozenset(['network', '!hardware'])

# Generated at 2022-06-24 21:44:13.419562
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 0
    all_fact_subsets = {'a': ['1'], 'b': ['2'], 'c': ['3'], 'd': ['4'], 'e': ['5'], 'f': ['6'], 'abc': ['7'], 'edf': ['8']}
    collector_names = ['a', 'b', 'c', 'd', 'e', 'f', 'abc', 'edf']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()
    # Test case 1

# Generated at 2022-06-24 21:44:21.069263
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    collector_names = [
        'a',
        'b',
        'c',
        'd'
    ]

    # Test that an unresolved require throws an error
    def test1():
        all_fact_subsets = {
            'a': BaseFactCollector(),
            'b': BaseFactCollector(required_facts={'e'})
        }
        assert find_unresolved_requires(collector_names, all_fact_subsets) == {'e'}

    test1()

    # Test that a missing collector throws an error
    def test2():
        all_fact_subsets = {
            'a': BaseFactCollector(),
            'b': BaseFactCollector(required_facts={'e'})
        }

# Generated at 2022-06-24 21:44:27.285303
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_collector_names = ['nivlac', 'yob']
    test_all_fact_subsets = {'nivlac':
                             [BaseFactCollector(['nivlac', 'yob']),
                              BaseFactCollector(['nivlac', 'yob']),
                              BaseFactCollector(['nivlac', 'yob'])],
                             'yob':
                             [BaseFactCollector(['nivlac', 'yob']),
                              BaseFactCollector(['nivlac', 'yob']),
                              BaseFactCollector(['nivlac', 'yob'])]}

    assert find_unresolved_requires(test_collector_names, test_all_fact_subsets) == set()



# Generated at 2022-06-24 21:44:33.307321
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # TODO: fix test. This isn't actually testing anything because all_fact_subsets is a list (not a dict)
    unresolved = find_unresolved_requires(['network'], [])
    assert len(unresolved) == 0


# Generated at 2022-06-24 21:44:40.847306
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'collectora'
        _fact_ids = set()
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'collectorb'
        _fact_ids = set()
        required_facts = {'collectora'}

    class CollectorC(BaseFactCollector):
        name = 'collectorc'
        _fact_ids = {'collectorc_alias'}
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'collectord'
        _fact_ids = set()
        required_facts = {'collectorc_alias'}

    collectors_for_platform = {CollectorA, CollectorB, CollectorC, CollectorD}

    all_aliases_map, _ = build_fact_id_to

# Generated at 2022-06-24 21:44:44.312450
# Unit test for function build_dep_data
def test_build_dep_data():
    val = build_dep_data('test', 'test')
    assert val == defaultdict(set), 'Expecting value to be defaultdict(set), get %s' % val


# Generated at 2022-06-24 21:44:54.174994
# Unit test for function get_collector_names
def test_get_collector_names():
    import pytest

    def _call_fut(*args, **kwargs):
        return get_collector_names(*args, **kwargs)

    valid_subsets = frozenset(['what', 'ever', 'network'])

    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi'])

    # Empty gather_subset
    # Empty gather_subset
    gather_subset = ['all']
    expected_set = set(['network'])
    actual_set = _call_fut(valid_subsets=valid_subsets,
                           minimal_gather_subset=frozenset(),
                           gather_subset=gather_subset,
                           aliases_map=aliases_map)
    assert actual_set == expected_set

# Generated at 2022-06-24 21:44:55.110254
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_case_0()



# Generated at 2022-06-24 21:45:16.320577
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = [
        class_for_test_get_fact_collector_names_0,
        class_for_test_get_fact_collector_names_1,
        class_for_test_get_fact_collector_names_2
    ]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        collectors_for_platform)

    assert len(fact_id_to_collector_map) == 8
    assert fact_id_to_collector_map['collector_name_0'] == [class_for_test_get_fact_collector_names_0]

# Generated at 2022-06-24 21:45:26.406933
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = {
        'architecture',
        'fqdn',
        'lsb',
        'system',
        'virtual'
    }
    all_fact_subsets = {
        'architecture': [BaseCollector],
        'fqdn': [BaseCollector],
        'lsb': [BaseCollector],
        'system': [BaseCollector],
        'virtual': [BaseCollector]
    }
    all_fact_subsets['architecture'][0].required_facts = set()
    all_fact_subsets['fqdn'][0].required_facts = {'system'}
    all_fact_subsets['lsb'][0].required_facts = set()
    all_fact_subsets['system'][0].required_facts = set()
    all_

# Generated at 2022-06-24 21:45:34.923579
# Unit test for function get_collector_names
def test_get_collector_names():
    gather_subset = ['all']
    minimal_gather_subset = frozenset(['network', 'facter'])
    valid_subsets = frozenset(['network', 'facter', 'hardware', 'devices', 'dmi'])
    aliases_map = defaultdict(set, {'hardware': frozenset(['devices', 'dmi']), 'all': frozenset(['facter', 'hardware'])})
    collector_names = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map)
    assert collector_names == frozenset(['network', 'facter', 'devices', 'dmi'])
    gather_subset = ['!network', 'dmi']

# Generated at 2022-06-24 21:45:41.967082
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Empty set should raise an error
    try:
        build_fact_id_to_collector_map(set())
    except KeyError:
        pass
    else:
        raise AssertionError("test_build_fact_id_to_collector_map: build_fact_id_to_collector_map returned incorrect result for empty set argument")
    test = [CollectorNotFoundError()]
    expected_result = {'CollectorNotFoundError': [CollectorNotFoundError()]}
    result = build_fact_id_to_collector_map(test)
    assert result == expected_result



# Generated at 2022-06-24 21:45:48.688668
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = set(['all', 'min', 'hello'])
    minimal_gather_subset = set(['min'])
    gather_subset = ['all']
    aliases_map = defaultdict(set)
    assert get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map) == set(['all', 'min'])
    aliases_map = defaultdict(set)
    gather_subset = ['!min']
    assert get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map) == set(['all'])
    aliases_map = defaultdict(set)
    gather_subset = ['all', '!min']

# Generated at 2022-06-24 21:45:58.490515
# Unit test for function build_dep_data
def test_build_dep_data():
    def test_dep_map(build_dep_data):

        # Test 1
        collector_names = ['!foo', '!bar']
        all_fact_subsets = {'foo': ['A'], 'bar': ['B']}
        dep_map = build_dep_data(collector_names, all_fact_subsets)
        assert dep_map == {}

        # Test 2
        collector_names = ['foo', 'bar']
        all_fact_subsets = {'foo': ['A'], 'bar': ['B']}
        dep_map = build_dep_data(collector_names, all_fact_subsets)
        assert dep_map == {'foo': set(), 'bar': set()}

        # Test 3
        collector_names = ['foo', 'bar']

# Generated at 2022-06-24 21:45:59.162648
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_case_0()


# Generated at 2022-06-24 21:46:06.649067
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map_expected = {'defaults': {'timezone', 'defaults'}, 'timezone': {'defaults', 'timezone'}}
    all_fact_subsets_0 = {'defaults': [object, object], 'timezone': [object, object]}
    collector_names_0 = ['defaults', 'timezone']
    dep_map = build_dep_data(collector_names_0, all_fact_subsets_0)
    assert dep_map == dep_map_expected


# Generated at 2022-06-24 21:46:17.241581
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = dict()
    all_fact_subsets['distribution'] = [
        'test0',
        'test1',
        'test2',
        'test3',
        'test4'
    ]
    all_fact_subsets['distribution'][0].required_facts = ['distribution', 'network']
    all_fact_subsets['distribution'][1].required_facts = ['distribution', 'network']
    all_fact_subsets['distribution'][2].required_facts = ['distribution', 'network']
    all_fact_subsets['distribution'][3].required_facts = ['distribution', 'network']
    all_fact_subsets['distribution'][4].required_facts = ['distribution', 'network']

# Generated at 2022-06-24 21:46:23.609163
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # setup
    import collections

    all_fact_subsets = collections.defaultdict(set)
    collector_names = set()

    # test invalid collector_names
    try:
        find_unresolved_requires(collector_names, all_fact_subsets)
        assert False
    except CycleFoundInFactDeps:
        pass

    # test valid collector names
    collector_names = set()
    collector_names.add('fact_a')
    collector_names.add('fact_b')

    all_fact_subsets = collections.defaultdict(set)
    all_fact_subsets[collector_names[0]].add(1)


# Generated at 2022-06-24 21:47:03.647998
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # collector_names -> set of collector_names
    all_fact_subsets = {
        'simple': [BaseFactCollector()],
        'hard': [BaseFactCollector()],
        'harder': [BaseFactCollector(required_facts={'hard', 'simple'})],
        'hardest': [BaseFactCollector(required_facts={'harder'})],
    }

    # tests
    result_0 = find_unresolved_requires({'simple', 'hard'}, all_fact_subsets)
    expected_0 = set()
    assert result_0 == expected_0

    result_1 = find_unresolved_requires({'simple', 'hardest'}, all_fact_subsets)
    expected_1 = {'harder'}
    assert result_1 == expected_1

    result_

# Generated at 2022-06-24 21:47:08.976127
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all', 'network']
    all_fact_subsets = {'network':[BaseFactCollector, BaseFactCollector],
                        'all':[BaseFactCollector, BaseFactCollector]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == defaultdict(set,[('all', set()), ('network', set())])


# Generated at 2022-06-24 21:47:15.179951
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {}
    collector_names = ['nonexistent_fact']

    try:
        unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
        if 'nonexistent_fact' in unresolved_requires:
            raise AssertionError('"nonexistent_fact" should not be returned by find_unresolved_requires')
    except CollectorNotFoundError as e:  # expected, since the fact collector is non-existent
        pass



# Generated at 2022-06-24 21:47:18.732737
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'xyz': [], 'abc': []}
    collector_names = ['xyz', 'abc']
    dep_map = {'xyz': set([]), 'abc': set([])}
    assert build_dep_data(collector_names, all_fact_subsets) == dep_map


# Generated at 2022-06-24 21:47:27.809965
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        gather_subset=['all', '!network'],
        minimal_gather_subset=['hardware']) == frozenset(['all', 'hardware'])
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        gather_subset=['!all', 'hardware'],
        minimal_gather_subset=['hardware']) == frozenset(['hardware'])

# Generated at 2022-06-24 21:47:38.472641
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

    def _test_build_fact_id_to_collector_map_template(collectors_for_platform):
        fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
        assert len(aliases_map) == 1
        assert len(aliases_map['test']) == 0
        assert len(fact_id_to_collector_map) == 1
        assert len(fact_id_to_collector_map['test']) == 1
        assert fact_id_to_collector_map['test'][0] == TestCollector

    _test_build_fact_id_to_collector_map_

# Generated at 2022-06-24 21:47:47.043703
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        "test_fact_a": [TestFactA],
        "test_fact_b": [TestFactB],
    }

    # a test collector that has no required_facts
    collector_names = ["test_fact_a"]
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # a test collector that requires test_fact_b
    collector_names = ["test_fact_a"]
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # a test collector that requires test_fact_b
    collector_names = ["test_fact_b"]
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)