

# Generated at 2022-06-24 21:38:23.981174
# Unit test for function build_dep_data
def test_build_dep_data():
    from collections import defaultdict
    from ansible.module_utils.facts.collectors import network, hardware, other

    all_fact_subsets = defaultdict(list)
    all_fact_subsets["network"].append(network.NetworkCollector)
    all_fact_subsets["network"].append(network.NetworkLegacyCollector)
    all_fact_subsets["hardware"].append(hardware.HardwareLegacyCollector)
    all_fact_subsets["hardware"].append(hardware.HardwareCollector)
    all_fact_subsets["all"].append(other.AllCollector)

    expected_dep_map = defaultdict(set)
    expected_dep_map['network'] = set([])
    expected_dep_map['hardware'] = set([])

# Generated at 2022-06-24 21:38:28.342724
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Create the collector_names which is the list of all the fact collector modules, in this case, it is ['default', 'hardware']
    collector_names = ['default', 'hardware']
    # Create a list of all the fact collector classes
    all_fact_subsets = [
        BaseFactCollector(),  # Test 1: This is a base class, so there are no requires.
        TestCollectorWithRequires(),  # Test 2: This class has requires, so needs to be compared with all the collector_names.
        TestCollectorWithoutRequires()  # Test 3: This class doen't have requires, so needs to be compared with all the collector_names.
    ]
    # Create a map which collect all the fact collector class with its corresponding name, in this case, it is like
    # {'default': [<TestCollectorWithoutRequires object at 0x

# Generated at 2022-06-24 21:38:38.382987
# Unit test for function get_collector_names
def test_get_collector_names():
    get_collector_names()
    get_collector_names(gather_subset=['!all'])
    get_collector_names(gather_subset=['!all'], aliases_map={'networking': ['network'], 'hardware': ['devices', 'dmi']})
    get_collector_names(gather_subset=['!min'])
    get_collector_names(gather_subset=['!min'], aliases_map={'networking': ['network']})
    get_collector_names(gather_subset=['network'], aliases_map={'networking': ['network']})
    get_collector_names(gather_subset=['network'], aliases_map={'networking': ['network', 'dmi']})

# Generated at 2022-06-24 21:38:47.494739
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'Foo': [TestCaseFooClass], 'Bar': [TestCaseBarClass], 'Baz': [TestCaseBazClass]}
    collector_names = {'Foo', 'Baz'}
    # collector_names = {'Foo', 'Bar', 'Baz'}
    # collector_names = {'Foo', 'Baz', 'Bar'}
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)

    assert unresolved_requires == {'Bar'}
    # assert unresolved_requires == set()



# Generated at 2022-06-24 21:38:55.400955
# Unit test for function get_collector_names
def test_get_collector_names():
    try:
        get_collector_names()
    except TypeError as e:
        pass
    else:
        raise AssertionError("test_get_collector_names: expected a TypeError exception")
    try:
        get_collector_names(gather_subset=[], minimal_gather_subset=['test_1'], valid_subsets=['test_1', 'test_2'])
    except TypeError as e:
        pass
    else:
        raise AssertionError("test_get_collector_names: expected a TypeError exception")
    try:
        get_collector_names(gather_subset=[], minimal_gather_subset=['test_1'], valid_subsets=['test_1', 'test_2'])
    except TypeError as e:
        pass

# Generated at 2022-06-24 21:39:06.304632
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # a list of collectors to test
    class DummyCollectorA(BaseFactCollector):
        # all_collectors = set()
        name = "testA"
        _fact_ids = ('test_A',)
    class DummyCollectorB(BaseFactCollector):
        # all_collectors = set()
        name = "testB"
        _fact_ids = ('test_B',)
        required_facts = ('test_A',)
    class DummyCollectorC(BaseFactCollector):
        # all_collectors = set()
        name = "testC"
        _fact_ids = ('test_C',)
        required_facts = ('test_B',)
    class DummyCollectorD(BaseFactCollector):
        # all_collectors = set()
        name = "testD"

# Generated at 2022-06-24 21:39:17.239674
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    dummy_collector_classes = [
        type('CollectorA', (BaseFactCollector,), {
            'name': 'collector_a',
            'required_facts': set(),
        }),
        type('CollectorB', (BaseFactCollector,), {
            'name': 'collector_b',
            'required_facts': set(['collector_a']),
        }),
        type('CollectorC', (BaseFactCollector,), {
            'name': 'collector_c',
            'required_facts': set(['collector_b']),
        }),
        type('CollectorD', (BaseFactCollector,), {
            'name': 'collector_d',
            'required_facts': set(['collector_c']),
        }),
    ]

    all_fact_

# Generated at 2022-06-24 21:39:21.659103
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    uut = {
        'fact1': set(['1','2','3','4']),
        'fact2': set(['5','6','7','8']),
        'fact3': set(['9','10','11','12'])
        }


# Generated at 2022-06-24 21:39:27.929766
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # generate all_fact_subsets
    all_fact_subsets = {'test_case_0': [test_case_0]}
    collector_names = ['test_case_0']

    # get unresolved_collector_names
    unresolved_collector_names = find_unresolved_requires(collector_names, all_fact_subsets)

    # test result
    assert(len(unresolved_collector_names) == 0)
    print('test_find_unresolved_requires passed!')



# Generated at 2022-06-24 21:39:35.685784
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case 0
    collector_names = {'a', 'c'}
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector]
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # test case 1
    collector_names = {'c', 'b'}
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector]
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'b'}

    # test case 2

# Generated at 2022-06-24 21:39:45.998212
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollectorA(BaseFactCollector):
        name = 'TestCollectorA'

        _fact_ids = ('a', 'b', 'c')

    class TestCollectorB(BaseFactCollector):
        name = 'TestCollectorB'
        required_facts = ('a', 'c')

        _fact_ids = ('d', 'e', 'f')

    class TestCollectorC(BaseFactCollector):
        name = 'TestCollectorC'
        required_facts = ('a', 'b')

        _fact_ids = ('g', 'h')


    all_fact_subsets = {
        'TestCollectorA': (TestCollectorA,),
        'TestCollectorB': (TestCollectorB,),
        'TestCollectorC': (TestCollectorC,),
    }


# Generated at 2022-06-24 21:39:53.642895
# Unit test for function tsort
def test_tsort():
    # An example graph, to use as input to test tsort()
    graph = {
        'initrd': set(['rootfs']),
        'rootfs': set(['disk', 'net']),
        'disk': set(['cdr', 'dvdr']),
        'cdr': set([]),
        'dvdr': set(['dvd']),
        'dvd': set(['bluray']),
        'bluray': set([]),
        'net': set(['modem']),
        'modem': set([]),
    }
    # The expected result from tsort(), on our example graph

# Generated at 2022-06-24 21:40:02.065509
# Unit test for function get_collector_names
def test_get_collector_names():
    '''test that gather_subset is parsed correctly'''
    assert get_collector_names(aliases_map={'hardware': set(('devices', 'dmi', ))}) == set(['all'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['!hardware']) == set(['all', 'min'])
    assert get_collector_names(gather_subset=['!hardware'],
                               aliases_map={'hardware': set(('devices', 'dmi', ))}) == set(['all', 'min'])
    assert get_collector_names(gather_subset=['software']) == set(['software'])
    assert get_collector

# Generated at 2022-06-24 21:40:05.840470
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['collector1', 'collector2'], {'collector1' : ['dep1', 'dep2'], 'collector2' : ['dep2', 'dep3']})
    assert dep_map['collector1'] == set(['dep1', 'dep2'])
    assert dep_map['collector2'] == set(['dep2', 'dep3'])


# Generated at 2022-06-24 21:40:14.672173
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['!all']) == frozenset()
    assert get_collector_names(gather_subset=['network', 'foo'], valid_subsets=frozenset(['network', 'foo'])) == frozenset(['network', 'foo'])
    assert get_collector_names(gather_subset=['network', '!foo'], valid_subsets=frozenset(['network', 'foo'])) == frozenset(['network'])
    assert get_collector_names(gather_subset=['network', '!all'], valid_subsets=frozenset(['network', 'foo'])) == frozenset(['network'])

# Generated at 2022-06-24 21:40:24.622414
# Unit test for function tsort
def test_tsort():
    dep_map = {'a': set([]), 'b': set(['a']), 'c': set(['b']), 'd': set(['c']), 'e': set(['d'])}
    sorted_list = tsort(dep_map)
    assert len(sorted_list) == len(dep_map), "tsort should return all facts"
    assert sorted_list == [('a', set([])), ('b', set(['a'])), ('c', set(['b'])), ('d', set(['c'])), ('e', set(['d']))], \
        "tsort should return sorted list"
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set(['a'])}

# Generated at 2022-06-24 21:40:33.346919
# Unit test for function tsort
def test_tsort():
    assert tsort({'a': ['b'],
                  'b': ['c'],
                  'c': []}) == [('c', []), ('b', ['c']), ('a', ['b'])]
    assert tsort({'a': ['b'],
                  'b': ['c'],
                  'c': ['d'],
                  'd': ['a']}) == []
    assert tsort({'a': ['b', 'c'],
                  'b': ['c', 'd'],
                  'c': ['d'],
                  'd': []}) == [('d', []), ('c', ['d']), ('b', ['c', 'd']), ('a', ['b', 'c'])]
    try:
        tsort({})
    except CycleFoundInFactDeps:
        pass

# Generated at 2022-06-24 21:40:42.968297
# Unit test for function get_collector_names
def test_get_collector_names():
    test_platform_info = {'distribution': ['RedHat', '7.4.1708', 'Core'],
                          'distribution_release': '7.4.1708',
                          'distribution_version': 'Core',
                          'kernel': 'Linux',
                          'kernel_version': '3.10.0-693.21.1.el7.x86_64',
                          'macaddress': '00:0c:29:20:2d:b1',
                          'os': 'Linux',
                          'system': 'Linux',
                          'system_vendor': 'VMware, Inc.',
                          'virtualization_role': 'guest',
                          'virtualization_type': 'kvm'}


# Generated at 2022-06-24 21:40:51.632701
# Unit test for function build_fact_id_to_collector_map

# Generated at 2022-06-24 21:40:55.070368
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = list()
    all_fact_subsets = list()
    unresolved_fact_dep_test_case_0 = find_unresolved_requires(collector_names, all_fact_subsets)


# Generated at 2022-06-24 21:41:07.293711
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case 0
    collector_names = ["!hardware", "!network", "system", "virtual", "kernel", "local"]
    all_fact_subsets = {"hardware": [], "network": []}
    try:
        find_unresolved_requires(collector_names, all_fact_subsets)
        assert False
    except CollectorNotFoundError as e:
        assert str(e) == 'Fact collector "hardware" not found'

test_find_unresolved_requires()


# Generated at 2022-06-24 21:41:18.261404
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = {'hardware': ['devices', 'dmi']}

    # test basic 'all'
    collector_names = get_collector_names(valid_subsets=frozenset(['all', 'network']),
                                          aliases_map=aliases_map,
                                          platform_info={'system': 'Generic'})
    assert collector_names == frozenset(['all', 'network'])

    # test empty gather_subset with default 'min'

# Generated at 2022-06-24 21:41:26.110273
# Unit test for function get_collector_names
def test_get_collector_names():
    set_0 = get_collector_names(['dmi'], 'all')
    set_0.add('network')
    set_0.add('all')
    assert set_0 == frozenset(['network', 'dmi', 'all'])
    set_1 = get_collector_names(['dmi'], '!hardware')
    assert set_1 == frozenset(['dmi'])
    set_2 = get_collector_names(['dmi'], '!memory')
    assert set_2 == frozenset(['dmi'])
    set_3 = get_collector_names(['dmi'], '!all')
    assert set_3 == frozenset(['dmi'])


# Generated at 2022-06-24 21:41:35.638380
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = { 'collector_0': [BaseFactCollector],
                         'collector_1': [BaseFactCollector],
                         'collector_2': [BaseFactCollector],
                         'collector_3': [BaseFactCollector],
                         'collector_4': [BaseFactCollector],
                         'collector_5': [BaseFactCollector],
                         'collector_6': [BaseFactCollector],
                         'collector_7': [BaseFactCollector],
                         'collector_8': [BaseFactCollector],
                         'collector_9': [BaseFactCollector],
                         }

    # These collectors require a collector that does not exist
    # TODO: find a way to reference the collector class in this dictionary
    # without having to define it here. ie, instead of BaseFactCollector
   

# Generated at 2022-06-24 21:41:41.359469
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    unresolved_fact_dep_0 = UnresolvedFactDep()
    assert(test_case_0() == unresolved_fact_dep_0)
    print('Test find_unresolved_requires - PASSED')

# Generated at 2022-06-24 21:41:46.175532
# Unit test for function get_collector_names
def test_get_collector_names():
    aliases_map = defaultdict(set)
    aliases_map['hardware'].add('devices')
    aliases_map['hardware'].add('dmi')
    aliases_map['hardware'].add('cpu')
    aliases_map['hardware'].add('memory')
    aliases_map['hardware'].add('virtualization')

    aliases_map['network'].add('interfaces')
    aliases_map['network'].add('default_ipv4')

    # Test case 1
    add_fact_collectors = set()

# Generated at 2022-06-24 21:41:55.527403
# Unit test for function get_collector_names
def test_get_collector_names():
    # Check that aliases get converted correctly
    assert get_collector_names(gather_subset=['hardware'],
                               aliases_map={'hardware': {'devices', 'dmi'}}) == {'devices', 'dmi'}

    # Check that bad subset names fail
    try:
        get_collector_names(gather_subset=['bad_subset'],
                            valid_subsets={'good_subset'})
    except TypeError:
        pass
    else:
        raise AssertionError("Bad subset does not raise TypeError")

    assert get_collector_names(gather_subset=['bad_subset'],
                               valid_subsets={'good_subset'},
                               aliases_map={'good_subset': {'bad_subset'}})

# Generated at 2022-06-24 21:42:05.613988
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test cases for the function get_collector_names
    # Case 0: simple test using all

    valid_subsets = frozenset({'platform', 'system', 'hw'})
    minimal_subsets = frozenset({'system', 'hw'})
    gather_subset = ['all']
    aliases_map = {'hw': {'platform'}}
    expected_names = frozenset({'platform', 'system', 'hw'})

    try:
        actual_names = get_collector_names(valid_subsets, minimal_subsets, gather_subset,
                                           aliases_map)

    except TypeError as e:
        print('Exception was thrown: %s' % (e))
        assert False

    except ValueError as e:
        print('Exception was thrown: %s' % (e))
       

# Generated at 2022-06-24 21:42:07.916742
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert unresolved_fact_dep_0 == UnresolvedFactDep()





# Generated at 2022-06-24 21:42:17.724517
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assertUnresolved = True
    assertUnresolved = False

    # When the assertUnresolved variable is true, we expect the find_unresolved_requires
    # function to find unresolved dependencies. In this case, we check to see if the
    # UnresolvedFactDep exception is thrown. If the assertUnresolved variable is
    # false, we expect to find no unresolved dependencies, so we check to see if
    # an empty list is returned.
    collector_names = ['en0']
    all_fact_subsets = {
        'en0' : [BaseFactCollector]
    }
    try:
        assert find_unresolved_requires(collector_names, all_fact_subsets) == []
        assert assertUnresolved == False
    except UnresolvedFactDep as e:
        assert assertUnresolved == True

# Generated at 2022-06-24 21:42:24.984574
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # all_fact_subsets = {'my_fact': 'my_fact_collector'}
    # collector_name = 'my_fact'
    # required_facts = {'my_other_fact'}
    #
    # unresolved = find_unresolved_requires(collector_name, all_fact_subsets)
    # assert(unresolved == required_facts)
    pass



# Generated at 2022-06-24 21:42:34.074458
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector2 import NetworkFactCollector
    from ansible.module_utils.facts.collector2 import VirtualFactCollector
    from ansible.module_utils.facts.collector2 import SELinuxFactCollector
    from ansible.module_utils.facts.collector2 import HardwareFactCollector
    from ansible.module_utils.facts.collector2 import OperatingSystemFactCollector

    collectors_for_platform = [NetworkFactCollector, VirtualFactCollector, SELinuxFactCollector, \
                                HardwareFactCollector, OperatingSystemFactCollector]

    aliases_map = dict()
    aliases_map['network'] = {'interfaces', 'default_ipv4', 'default_ipv6'}

# Generated at 2022-06-24 21:42:41.466504
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with all gather_subset possibilities
    valid_subsets = frozenset(['foo', 'bar', 'foobar'])
    minimal_gather_subset = frozenset(['foo'])


# Generated at 2022-06-24 21:42:46.786044
# Unit test for function get_collector_names

# Generated at 2022-06-24 21:42:53.464091
# Unit test for function build_dep_data
def test_build_dep_data():
    # Positive test case 1
    collector_names = ["all"]
    all_fact_subsets = {"all": [test_case_0]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert(dep_map == {})



# Generated at 2022-06-24 21:42:59.943409
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert set() == find_unresolved_requires(set(['hardware']), {'hardware': [test_case_0]})
    assert set(['ansible_all_ipv4_addresses']) == find_unresolved_requires(set(['hardware']), {'hardware': [test_case_0]})



# Generated at 2022-06-24 21:43:03.114046
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 0
    # Input:
    #     collector_names = {"dmi"}
    #     all_fact_subsets = {"dmi": [dmi_c.name, dmi_c.required_facts]}, {"dmi": {hardware, dmi}}
    # Expected result:
    #     []
    unresolved_fact_dep_0 = UnresolvedFactDep()


# Generated at 2022-06-24 21:43:11.546722
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collector_map, alias_map = build_fact_id_to_collector_map(find_collectors_for_platform(all_collectors, {'system': 'Generic'}))
    assert len(collector_map) > 25, 'Something wrong with the numver of collectors'
    assert len(alias_map) > 25, 'Something wrong with the numver of aliases'


# Generated at 2022-06-24 21:43:22.665318
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test using
    https://github.com/ansible/ansible/blob/v2.5.1/lib/ansible/module_utils/facts/system/linux.py#L417
    as a starting point.
    '''
    # This test is intended to be run using Python 2.6 or 2.7.
    # It would need modifications to work with Python 3.
    #
    # It is easier to modify the original code for this test
    # than to try to use patch.object().
    from ansible.module_utils import facts
    from ansible.module_utils.facts import system

    # temporary_collectors is a list of classes that are added to
    # system.collector_classes during this test.
    temporary_collectors = []

    # We need to override system.collector_classes for this test.

# Generated at 2022-06-24 21:43:27.273789
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    fact_id_to_collector_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert('Generic' in fact_id_to_collector_map)
    assert('Generic' in fact_id_to_collector_map)
    assert(len(fact_id_to_collector_map['Generic']) == 1)
    assert(type(fact_id_to_collector_map['Generic'][0]) == BaseFactCollector)



# Generated at 2022-06-24 21:43:39.203577
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['min', 'platform', 'memory']
    # create a mock of all_fact_subsets for testing
    all_fact_subsets = {'platform': [BaseFactCollector(), BaseFactCollector()],
                        'min': [BaseFactCollector()],
                        'memory': [BaseFactCollector(), BaseFactCollector()]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    # dep_map should be a defaultdict for further use in resolve_deps function
    assert isinstance(dep_map, defaultdict)


# Generated at 2022-06-24 21:43:50.791724
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    a = type('a', (BaseFactCollector, object), {'_fact_ids': set(['a1', 'a2']), 'name': 'a'})
    b = type('b', (BaseFactCollector, object), {'_fact_ids': set(['b1', 'b2']), 'name': 'b'})
    x = type('x', (BaseFactCollector, object), {'_fact_ids': set(['x1', 'x2']), 'name': 'x'})

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([a, b])
    assert fact_id_to_collector_map['a'] == [a]
    assert fact_id_to_collector_map['a1'] == [a]
   

# Generated at 2022-06-24 21:44:01.804210
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():

    import platform
    import base64
    from datetime import datetime

    class SubclassFactCollector(BaseFactCollector):

        _platform = 'Generic'
        name = 'subclass_fact'
        required_facts = frozenset()

        def collect(self, module=None, collected_facts=None):
            return {'subclass_fact_key': 'subclass_fact_value'}

    class SubclassFactCollectorDep(BaseFactCollector):

        _platform = 'Generic'
        name = 'subclass_fact_dep'
        required_facts = frozenset(['subclass_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'subclass_fact_dep_key': 'subclass_fact_dep_value'}


# Generated at 2022-06-24 21:44:11.224226
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector0(BaseFactCollector):
        name = 'collector0'

    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['extra0'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['extra1'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['extra2', 'extra1'])

    # Test with multiple collectors with no conflicts
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([Collector0, Collector1, Collector2, Collector3])

# Generated at 2022-06-24 21:44:20.930880
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['hardware', 'network']),
        minimal_gather_subset=frozenset(['hardware']),
        gather_subset=['!hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None) == frozenset(['network'])


# Generated at 2022-06-24 21:44:26.341501
# Unit test for function get_collector_names

# Generated at 2022-06-24 21:44:34.216133
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    raw_collector_names = frozenset(['all_a', 'all_b', 'all'])
    #all_a_c is supposed to require all_b, but doesn't.
    #all_a is supposed to require all_a_c, but doesn't.
    collector_names = frozenset(['all_a','all_b', 'all_a_c'])
    expected = set(['all_b', 'all_a_c'])
    assert find_unresolved_requires(collector_names,raw_collector_names) == expected


# Generated at 2022-06-24 21:44:43.371582
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_1 = BaseFactCollector
    collector_1.required_facts = set(['2', '3'])
    collector_1.name = '1'
    collector_2 = BaseFactCollector
    collector_2.required_facts = set()
    collector_2.name = '2'
    collector_3 = BaseFactCollector
    collector_3.required_facts = set([])
    collector_3.name = '3'

    all_fact_subsets = {
        '1': [collector_1],
        '2': [collector_2],
        '3': [collector_3]
    }

    actual_result = find_unresolved_requires(['1'], all_fact_subsets)
    expected_result = set()
    assert actual_result == expected_result

# Generated at 2022-06-24 21:44:52.659567
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class new_collectors(BaseFactCollector):
        _fact_ids = set(['new', 'new1', 'new2'])
        name = 'new'
    collectors = set([new_collectors])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors)
    assert('new' in fact_id_to_collector_map and 'new' in aliases_map)
    assert('new1' in fact_id_to_collector_map and 'new1' in aliases_map)
    assert('new2' in fact_id_to_collector_map and 'new2' in aliases_map)


# Generated at 2022-06-24 21:44:57.384600
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    def test_case_1():
        class FactCollector0(BaseFactCollector):
            name = 'FactCollector0'

        class FactCollector1(BaseFactCollector):
            name = 'FactCollector1'
            required_facts = ['FactCollector0']

        class FactCollector2(BaseFactCollector):
            name = 'FactCollector2'
            required_facts = ['FactCollector0']

        class FactCollector3(BaseFactCollector):
            name = 'FactCollector3'
            required_facts = ['FactCollector1', 'FactCollector2', 'fact4']

        class FactCollector4(BaseFactCollector):
            name = 'FactCollector4'
            required_facts = ['FactCollector3']


# Generated at 2022-06-24 21:45:13.241136
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = [BaseFactCollector()]
    fact_id_to_collector_map = defaultdict(list)
    aliases_map = defaultdict(set)

    assert(build_fact_id_to_collector_map(collectors_for_platform) == (fact_id_to_collector_map, aliases_map))


# Generated at 2022-06-24 21:45:23.735145
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 0: it should return nothing if everything is solved
    all_fact_subsets = {'z': [base_fact_collector_0]}
    expected_result = set()
    collector_names = ['z']
    actual_result = find_unresolved_requires(collector_names, all_fact_subsets)
    if actual_result != expected_result:
        print("Expected:", expected_result,
              "Actual:", actual_result)
        return False

    # Test 1: it should return nothing if everything is solved
    all_fact_subsets = {'z': [base_fact_collector_0]}
    expected_result = set()
    collector_names = ['z']
    actual_result = find_unresolved_requires(collector_names, all_fact_subsets)
   

# Generated at 2022-06-24 21:45:32.144464
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    fact_collector_0 = BaseFactCollector()
    fact_collector_0.name = 'test_item_0'
    fact_collector_0.required_facts = set(['test_item_1', 'test_item_2'])

    fact_collector_1 = BaseFactCollector()
    fact_collector_1.name = 'test_item_1'
    fact_collector_1.required_facts = set(['test_item_2'])

    fact_collector_2 = BaseFactCollector()
    fact_collector_2.name = 'test_item_2'
    fact_collector_2.required_facts = set()


# Generated at 2022-06-24 21:45:40.132629
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_0 = BaseFactCollector(name='base_0')
    base_fact_collector_1 = BaseFactCollector(name='base_1')
    base_fact_collector_2 = BaseFactCollector(name='base_2')
    base_fact_collector_2.required_facts = set(['base_0', 'base_1'])
    base_fact_collector_3 = BaseFactCollector(name='base_3')
    base_fact_collector_3.required_facts = set(['base_2'])
    base_fact_collector_4 = BaseFactCollector(name='base_4')
    base_fact_collector_4.required_facts = set(['base_2'])

# Generated at 2022-06-24 21:45:47.266615
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Base case: tests that, given an empty set of collector names, all collectors
    # require facts that aren't present.
    all_fact_subsets = {'one': [BaseFactCollector()],
                        'two': [BaseFactCollector()],
                        'three': [BaseFactCollector()],
                        'four': [BaseFactCollector()],
                        'five': [BaseFactCollector()]}
    for collector_name in all_fact_subsets:
        required_facts = _get_requires_by_collector_name(collector_name, all_fact_subsets)
        for required_fact in required_facts:
            if required_fact not in all_fact_subsets:
                raise Exception()

    # Base case: tests that, given a set of collector names, collectors with no
    # required facts are considered resolved.

# Generated at 2022-06-24 21:45:57.491821
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    assert find_unresolved_requires(set(['fact_1', 'fact_2']),
        all_fact_subsets={'fact_1': [BaseFactCollector],
            'fact_2': [BaseFactCollector]}) == set()

    # fact_2 requires fact_1, but fact_1 is not in collector_names
    assert find_unresolved_requires(set(['fact_2']),
        all_fact_subsets={'fact_1': [BaseFactCollector],
            'fact_2': [type('TestCollector', (BaseFactCollector,), {
                'name': 'fact_2', 'required_facts': set(['fact_1'])})]}) == set(['fact_1'])

    # fact_3 depends on itself

# Generated at 2022-06-24 21:46:08.246678
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()

    base_fact_collector_0._fact_ids = ['ns0_var0', 'ns0_var1']
    base_fact_collector_0.name = 'ns0'

    base_fact_collector_1._fact_ids = ['ns1_var0', 'ns1_var1']
    base_fact_collector_1.name = 'ns1'

    base_fact_collector_2._fact_ids = ['ns2_var0', 'ns2_var1']
    base_fact_collector_2.name = 'ns2'


# Generated at 2022-06-24 21:46:11.598362
# Unit test for function build_dep_data
def test_build_dep_data():
    data = build_dep_data(['fact_a'], {'fact_a' : [BaseFactCollector()]})
    assert 'fact_a' in data
    assert len(data['fact_a']) == 0


# Generated at 2022-06-24 21:46:20.561759
# Unit test for function get_collector_names
def test_get_collector_names():

    # valid subset values
    valid_subsets = frozenset(['all', 'network', 'hardware', 'virtual', 'facter'])

    # minimal subset values
    minimal_gather_subset = frozenset(['all', 'network', 'hardware', 'virtual', 'facter'])

    assert get_collector_names(valid_subsets, minimal_gather_subset, ['dmi']) == {'dmi'}

    assert get_collector_names(valid_subsets, minimal_gather_subset, ['all']) == set(valid_subsets)

    assert get_collector_names(valid_subsets, minimal_gather_subset, ['minimal']) == minimal_gather_subset


# Generated at 2022-06-24 21:46:27.721019
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Define a simple fact collector
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = {'t1', 't2'}

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map({TestCollector})

    assert fact_id_to_collector_map['test'] == [TestCollector]
    assert TestCollector in fact_id_to_collector_map['t1']
    assert TestCollector in fact_id_to_collector_map['t2']
    assert aliases_map['test'] == {'t1', 't2'}



# Generated at 2022-06-24 21:46:43.101287
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = [
        'services',
        'uptime',
        'users'
    ]
    all_fact_subsets = {
        'services': [
            BaseFactCollector(),
            BaseFactCollector(),
            BaseFactCollector()
        ],
        'uptime': [
            BaseFactCollector(),
            BaseFactCollector()
        ],
        'users': [
            BaseFactCollector(),
            BaseFactCollector()
        ]
    }
    print(build_dep_data(collector_names, all_fact_subsets))


# Generated at 2022-06-24 21:46:49.117613
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # tests gather_subset '!all' with minimal_gather_subset 
    collect_subset = ['!all']
    minimal_subset = frozenset(['min'])
    all_collector_classes = [BaseFactCollector]
    valid_subsets = frozenset(['all', 'min'])
    collector_classes = collector_classes_from_gather_subset(all_collector_classes, 
            valid_subsets, minimal_subset, collect_subset)
    # We expect to get the BaseFactCollector class back
    expected_collector_class = BaseFactCollector
    assert collector_classes == [expected_collector_class]


# Generated at 2022-06-24 21:46:56.450717
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # create a test object for testing
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = 'TestCollector0'
    base_fact_collector_0._fact_ids = set(['test_fact_0', 'test_fact_1', 'test_fact_2'])

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = 'TestCollector1'
    base_fact_collector_1._fact_ids = set(['test_fact_3'])

    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_2.name = 'TestCollector2'

# Generated at 2022-06-24 21:47:02.505254
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector0(BaseFactCollector):
        _fact_ids = ['test1']
        name = 'collector0'

    class TestCollector1(BaseFactCollector):
        _fact_ids = ['test2']
        name = 'collector1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test3']
        name = 'collector2'

    collectors_for_platform = find_collectors_for_platform([
        TestCollector0, TestCollector1, TestCollector2
    ], [{}])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        collectors_for_platform)

    assert(len(fact_id_to_collector_map) == 3)

# Generated at 2022-06-24 21:47:08.810270
# Unit test for function get_collector_names
def test_get_collector_names():

    # Test looking for 'all'
    valid_subsets = frozenset(['a', 'b', 'c', 'd'])
    minimal_gather_subset = frozenset()
    gather_subset = ['all']
    aliases_map = defaultdict(set)
    platform_info = None

    assert get_collector_names(valid_subsets, minimal_gather_subset, gather_subset,
                               aliases_map, platform_info) == set(['a', 'b', 'c', 'd'])

    # Test looking for something not listed
    minimal_gather_subset = frozenset(['a', 'b', 'c'])
    gather_subset = ['x']


# Generated at 2022-06-24 21:47:12.155492
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case 0
    all_fact_subsets = {}
    collector_names = ['all']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved


# Generated at 2022-06-24 21:47:20.324520
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_collector_0 = BaseFactCollector()
    test_collector_1 = BaseFactCollector()
    test_collector_2 = BaseFactCollector()
    test_collector_3 = BaseFactCollector()
    test_collector_0.required_facts = {'test_collector_1'}
    test_collector_1.required_facts = {'test_collector_2'}
    test_collector_2.required_facts = {'test_collector_3'}
    test_collector_3.required_facts = {'test_collector_4'}

    all_fact_subsets = defaultdict(list)
    all_fact_subsets['test_collector_0'].append(test_collector_0)

# Generated at 2022-06-24 21:47:28.872052
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class MyCollector(BaseFactCollector):
        _fact_ids = set(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'])
        name = 'MyCollector'
        required_facts = set()

    class SecondCollector(BaseFactCollector):
        _fact_ids = set(['a','b','c','d'])
        name = 'SecondCollector'
        required_facts = set()

    class ThirdCollector(BaseFactCollector):
        _fact_ids = set(['c','d'])
        name = 'ThirdCollector'
        required_facts = set()

    all_collectors = set()

# Generated at 2022-06-24 21:47:37.491776
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids = {'test'}
    base_fact_collector_1.name = 'test'
    base_fact_collector_1.required_facts = {'test'}

    all_fact_subsets = {'test': [base_fact_collector_1]}
    collector_names = ['test']

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map['test'] == {'test'}


# Generated at 2022-06-24 21:47:46.240643
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()

    collectors = [base_fact_collector_0, base_fact_collector_1]

    fact_id_to_collector_map = defaultdict(list)
    aliases_map = defaultdict(set)

    for collector_class in collectors:
        primary_name = collector_class.name

        fact_id_to_collector_map[primary_name].append(collector_class)

        for fact_id in collector_class._fact_ids:
            fact_id_to_collector_map[fact_id].append(collector_class)
            aliases_map[primary_name].add(fact_id)
