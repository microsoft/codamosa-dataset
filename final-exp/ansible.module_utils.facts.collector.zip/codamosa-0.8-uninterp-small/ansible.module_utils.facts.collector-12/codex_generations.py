

# Generated at 2022-06-24 21:38:16.669789
# Unit test for function tsort
def test_tsort():
    """
    tests tasksort (topological sort) of a graph
    """

    # graph 1
    unsorted_map = {'A': ['B', 'C'],
                    'B': ['C', 'D'],
                    'C': [],
                    'D': ''}

    sorted_list = tsort(unsorted_map)

    assert(sorted_list == [('C', set()), ('D', set()), ('B', {'C', 'D'}), ('A', {'B', 'C'})])

    # graph 2
    unsorted_map = {'A': ['B', 'C'],
                    'B': ['C', 'D'],
                    'C': [],
                    'D': '',
                    'E': ['A']}

    sorted_list = tsort(unsorted_map)

# Generated at 2022-06-24 21:38:24.001000
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class WindowsFact(BaseFactCollector):
        _platform = 'Windows'

    class LinuxFact(BaseFactCollector):
        _platform = 'Linux'

    class SolarisFact(BaseFactCollector):
        _platform = 'Solaris'

    class SampleFact(BaseFactCollector):
        _platform = 'Generic'
        name = 'primary'
        required_facts = set()

    all_collector_classes = [WindowsFact, LinuxFact, SolarisFact, SampleFact]

    compat_platforms = [{'system': platform.system()}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    specific_collector = None
    generic_collector = None
    for collector in found_collectors:
        print(collector.name)

# Generated at 2022-06-24 21:38:36.273719
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector0(BaseFactCollector):
        _fact_ids = frozenset(('test_collector_0', 'test_0_0', 'test_0_1'))

        name = 'test_collector_0'

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict()
            facts_dict['test_0_0'] = 'test_collector_0_0'
            facts_dict['test_0_1'] = 'test_collector_0_1'
            return facts_dict

    class TestCollector1(BaseFactCollector):
        _fact_ids = frozenset(('test_collector_1', 'test_1_0', 'test_1_1'))

        name = 'test_collector_1'


# Generated at 2022-06-24 21:38:47.578310
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    name = 'mock_collector_1'
    fact_ids = ['mock_fact_1']
    required_facts = ['mock_required_fact_1']
    # override required class attributes
    class MockCollector1(BaseFactCollector):
        _fact_ids = fact_ids
        name = name
        required_facts = required_facts

    MockCollector1._platform = platform.system()

    class MockCollector2(BaseFactCollector):
        name = 'mock_collector_2'
        _fact_ids = ['mock_fact_2']
        required_facts = ['mock_required_fact_2']
    test_collectors = [MockCollector1, MockCollector2, BaseFactCollector]
    test_platforms = [platform.system(), platform.system()]
   

# Generated at 2022-06-24 21:38:55.494944
# Unit test for function tsort
def test_tsort():
    # Tests tsort when there are no edges
    test_case_0 = {'alpha': [], 'beta': []}
    assert tsort(test_case_0) == [('alpha', []), ('beta', [])], "Unable to tsort when there are no edges"

    # Tests tsort when there are no cycles
    test_case_1 = {'alpha': ['charlie'], 'beta': ['delta'], 'charlie': [], 'delta': []}
    assert tsort(test_case_1) == [('charlie', []), ('delta', []), ('alpha', ['charlie']), ('beta', ['delta'])], "Unable to tsort when there are no cycles"

    # Tests tsort when there are two nodes which are both the same end

# Generated at 2022-06-24 21:39:06.549926
# Unit test for function build_dep_data
def test_build_dep_data():

    class FactCollector_0(BaseFactCollector):
        _fact_ids = set(['test_collector_0'])
        name = 'test_collector_0'
        required_facts = set(['test_collector_1', 'test_collector_2'])

    class FactCollector_1(BaseFactCollector):
        _fact_ids = set(['test_collector_1'])
        name = 'test_collector_1'
        required_facts = set(['test_collector_2'])


    class FactCollector_2(BaseFactCollector):
        _fact_ids = set(['test_collector_2'])
        name = 'test_collector_2'
        required_facts = set(['test_collector_3'])


# Generated at 2022-06-24 21:39:17.260618
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class ExampleCollector(BaseFactCollector):
        name = 'example'
        required_facts = set(['subset-A', 'subset-B'])
    class AnotherExampleCollector(BaseFactCollector):
        name = 'another_example'
        required_facts = set(['subset-C'])
    class YetAnotherExampleCollector(BaseFactCollector):
        name = 'yet_another_example'
        required_facts = set(['subset-D', 'subset-E', 'subset-F'])

# Generated at 2022-06-24 21:39:22.242458
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['fact_id_1', 'fact_id_2', 'fact_id_3']
    all_fact_subsets = {'fact_id_1': [BaseFactCollector()],
                        'fact_id_2': [BaseFactCollector()],
                        'fact_id_3': [BaseFactCollector()],
                        }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map == {'fact_id_1': set(),
                       'fact_id_2': set(),
                       'fact_id_3': set(),
                       }


# Generated at 2022-06-24 21:39:25.370049
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # Create fact collectors
    fact_collector_0 = BaseFactCollector(platform='Linux')
    fact_collector_1 = BaseFactCollector(platform='Generic')

    found_collectors = find_collectors_for_platform([fact_collector_0, fact_collector_1], ['Linux'])
    assert set([fact_collector_0]) == found_collectors


# Generated at 2022-06-24 21:39:33.038032
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def test_case_1():
        '''
        collector-0 requires collector-1
        collector-1 requires collector-2

        expected:
        collector-0 requires collector-1
        collector-1 requires collector-2
        '''

        base_fact_collector_0 = BaseFactCollector()
        setattr(base_fact_collector_0, 'name', 'collector-0')
        setattr(base_fact_collector_0, 'required_facts', set(['collector-1']))

        base_fact_collector_1 = BaseFactCollector()
        setattr(base_fact_collector_1, 'name', 'collector-1')
        setattr(base_fact_collector_1, 'required_facts', set(['collector-2']))

        base_fact_collector_

# Generated at 2022-06-24 21:39:51.523750
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test-case 1:
    # Test case where collector_classes is None
    all_collector_classes = None
    collectors_for_platform = find_collectors_for_platform(all_collector_classes,
                                                           compat_platforms=[None])
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert len(fact_id_to_collector_map) == 0
    assert len(aliases_map) == 0

    # Test-case 2:
    # Test case where collector_classes is an empty set
    all_collector_classes = set()
    collectors_for_platform = find_collectors_for_platform(all_collector_classes,
                                                           compat_platforms=[None])

# Generated at 2022-06-24 21:39:57.781967
# Unit test for function select_collector_classes
def test_select_collector_classes():
    fake_collector_classes = [
        object, object, object, object, object,
        object, object, object, object, object,
        object, object, object, object, object,
    ]

    all_fact_subsets = {
        'all': fake_collector_classes,
    }
    selected_collector_classes = select_collector_classes(['all'], all_fact_subsets)

    # duplicate values should be removed
    assert selected_collector_classes == [fake_collector_classes[0]]


# Generated at 2022-06-24 21:40:07.798212
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'a': [BaseFactCollector()],
                        'b': [BaseFactCollector(name='b', required_facts=set(['b']))],
                        'c': [BaseFactCollector(name='c', required_facts=set(['a']))],
                        'd': [BaseFactCollector(name='d', required_facts=set(['c', 'a']))]}

    assert find_unresolved_requires(['b', 'a'], all_fact_subsets) == set(['b'])
    assert find_unresolved_requires(['b', 'c', 'a'], all_fact_subsets) == set(['b'])

    assert find_unresolved_requires(['c', 'a'], all_fact_subsets) == set([])

# Generated at 2022-06-24 21:40:17.665684
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class fact_collector_0(BaseFactCollector):
        _fact_ids = set()

        _platform = 'Generic'
        name = 'fact_collector_0'
        required_facts = set()

    class fact_collector_1(BaseFactCollector):
        _fact_ids = {'fact_id_1', 'fact_id_2', 'fact_id_3'}

        _platform = 'Generic'
        name = 'fact_collector_1'
        required_facts = set()

    class fact_collector_2(BaseFactCollector):
        _fact_ids = {'fact_id_1', 'fact_id_2', 'fact_id_3'}

        _platform = 'Generic'
        name = 'fact_collector_2'
        required_facts = set()

   

# Generated at 2022-06-24 21:40:21.341667
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    '''
    Testing new function
    '''
    collectors_for_platform = set()
    collectors_for_platform.add(base_fact_collector_0)
    #print(build_fact_id_to_collector_map(collectors_for_platform))



# Generated at 2022-06-24 21:40:31.473068
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = frozenset(('a', 'A'))

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = frozenset(('b', 'B'))

    # do not actually load _fact_ids from classes because we are testing
    # a function
    class CollectorC(BaseFactCollector):
        name = 'C'

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = frozenset(('d', 'D'))

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = frozenset(('e', 'E'))


# Generated at 2022-06-24 21:40:40.990173
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    BASE = BaseFactCollector
    class A(BASE):
        name = 'a'
        required_facts = set()

    class B(BASE):
        name = 'b'
        required_facts = {'a'}

    class C(BASE):
        name = 'c'
        required_facts = {'b'}

    class D(BASE):
        name = 'd'
        required_facts = {'c'}

    all_fact_subsets = defaultdict(set)
    all_fact_subsets['a'].add(A)
    all_fact_subsets['b'].add(B)
    all_fact_subsets['c'].add(C)
    all_fact_subsets['d'].add(D)


# Generated at 2022-06-24 21:40:49.379745
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    # Test case: empty collector list:
    # Expected results:
    # No collector returned
    all_classes = set()
    lenght_expected = 0
    result_actual = len(find_collectors_for_platform(all_classes, ['Linux']))
    assert result_actual == lenght_expected

    # Test case: non-empty collector list, with platform 'Generic'
    # Expected results:
    # Collector returned
    class BaseFactCollector_1(BaseFactCollector):
        _platform = 'Linux'
        name = 'BaseFactCollector_1'

    all_classes = [BaseFactCollector_1]
    lenght_expected = 1
    result_actual = len(find_collectors_for_platform(all_classes, ['Linux']))
    assert result_actual == lenght_

# Generated at 2022-06-24 21:40:58.997852
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class FactCollectorA(BaseFactCollector):
        _fact_ids = set(['test1', 'test2'])
        name = 'a'

    class FactCollectorB(BaseFactCollector):
        _fact_ids = set(['test3', 'test4'])
        name = 'b'

    class FactCollectorC(BaseFactCollector):
        _fact_ids = set(['test5', 'test6'])
        name = 'c'

    class FactCollectorD(BaseFactCollector):
        _fact_ids = set(['test6'])
        name = 'c'


# Generated at 2022-06-24 21:41:03.040889
# Unit test for function tsort
def test_tsort():
    x = {1: [2, 3], 2: [4], 3: [4, 5], 4:[], 5:[]}
    # x = {1: [1], 2: []}
    # x = {1: [2, 3], 2: [2], 3: [2]}
    print(tsort(x))



# Generated at 2022-06-24 21:41:18.283827
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'network'])
    minimal_gather_subset = frozenset(['all'])
    gather_subset = ['all']
    aliases_map = defaultdict({'hardware': ['devices', 'dmi']})
    platform_info = dict()

    # correct call
    get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info)

    gather_subset = ['!all']
    # correct call
    get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info)

    gather_subset = ['!network']
    # correct call

# Generated at 2022-06-24 21:41:26.673774
# Unit test for function get_collector_names
def test_get_collector_names():
    '''Get collector names based on gather_subset spec'''
    # Retrieve module parameters
    gather_subset = ['all']

    # the list of everything that 'all' expands to
    valid_subsets = frozenset(['network', 'hardware'])
    minimal_gather_subsets = frozenset(['virtual'])
    aliases_map = defaultdict(set, {'all': frozenset(['network', 'hardware'])})

    # Retrieve all facts elements
    additional_subsets = get_collector_names(valid_subsets,
                                             minimal_gather_subset=minimal_gather_subsets,
                                             aliases_map=aliases_map,
                                             gather_subset=gather_subset)

    # Verify get_collector_names results
   

# Generated at 2022-06-24 21:41:33.274727
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = 'Test'

    collectors = []
    collectors.append(base_fact_collector_0)

    collector_dict = {}
    for collector in collectors:
        collector_dict[collector.name] = collector

    #input data for build_fact_id_to_collector_map
    collector_classes_in = [base_fact_collector_0]
    fact_id_to_collector_map_expected = {'Test': [base_fact_collector_0]}
    aliases_map_expected = defaultdict(set)
    aliases_map_expected['Test'] = set()

    # run code
    fact_id_to_collector_map, aliases_map = build_fact_id_to_

# Generated at 2022-06-24 21:41:44.681794
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class test_collector(BaseFactCollector):
        _fact_ids = {'test_collector'}

    collector_list = [test_collector, test_collector, BaseFactCollector]

    result = build_fact_id_to_collector_map(collector_list)
    for collector in result:
        if isinstance(collector, dict):
            for k, v in collector.items():
                assert k == 'test_collector' and v[0] == test_collector
        elif isinstance(collector, defaultdict):
            for k, v in collector.items():
                assert k == 'test_collector' and v == {'test_collector'}
        else:
            raise TypeError


# Generated at 2022-06-24 21:41:51.656353
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    global test_class_0_used
    test_class_0_used = False
    class TestCollectorClass0(BaseFactCollector):
        name = 'test_class_0'
        def collect(self, module=None, collected_facts=None):
            global test_class_0_used
            test_class_0_used = True
            return {}

    class TestCollectorClass1(BaseFactCollector):
        name = 'test_class_1'
        def collect(self, module=None, collected_facts=None):
            return {}

    all_collector_classes = [TestCollectorClass0, TestCollectorClass1]

    platform_info = {'system': 'Generic'}

    valid_subsets = frozenset(['test_class_0', 'test_class_1'])
    minimal_

# Generated at 2022-06-24 21:41:59.118305
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collectors = [
        {
            '_platform': 'Windows',
            'name': 'windows'
        },
        {
            '_platform': 'Generic',
            'name': 'generic'
        }
    ]
    compat_platforms = [
        {
            'system': 'Windows'
        },
        {
            'system': 'Generic'
        }
    ]
    collectors = find_collectors_for_platform(all_collectors, compat_platforms)
    assert len(collectors) == 2


# Generated at 2022-06-24 21:42:07.455705
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = {'dpkg_lshw', 'aix_ifconfig', 'network_gather_subset'}
    all_fact_subsets = {'dpkg_lshw': [BaseFactCollector], 'aix_ifconfig': [BaseFactCollector], 'network_gather_subset': [BaseFactCollector]}
    
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    print(type(unresolved))
    print(unresolved)


# Generated at 2022-06-24 21:42:17.707518
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class collector_0(BaseFactCollector):
        name = '0'
        required_facts = set()

    class collector_1(BaseFactCollector):
        name = '1'
        required_facts = set()

    class collector_2(BaseFactCollector):
        name = '2'
        required_facts = set(['0', '1', '3'])

    all_fact_subsets = {
        '0': [collector_0],
        '1': [collector_1],
        '2': [collector_2],
    }

    # No unresolved requires
    collector_names = ['0', '1']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    # Unresolved requires
    collector

# Generated at 2022-06-24 21:42:28.216164
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # This is only a simple test for now
    # test case 0 - empty collectors
    test_set_0 = set()
    assert find_collectors_for_platform(test_set_0, [platform.system()]) == set()
    # test case 1 - one collector, no match
    test_set_1 = {BaseFactCollector}
    assert find_collectors_for_platform(test_set_1, [platform.system()]) == set()
    # test case 2 - one collector, one match
    test_set_2 = {test_case_0}
    assert find_collectors_for_platform(test_set_2, [platform.system()]) == test_set_2
    # test case 3 - two collectors, one match
    test_set_3 = {test_case_0, BaseFactCollector}


# Generated at 2022-06-24 21:42:36.671936
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [
        {
            '_platform': 'Linux',
            'name': 'collector_0'
        },
        {
            '_platform': 'Linux',
            'name': 'collector_1'
        },
        {
            '_platform': 'Darwin',
            'name': 'collector_2'
        },
        {
            '_platform': 'Linux',
            'name': 'collector_3'
        }
    ]
    compat_platforms = [
        {
            'system': 'Linux'
        },
        {
            'system': 'Darwin'
        }
    ]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)


# Generated at 2022-06-24 21:43:01.027704
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {}
    class Collector0(BaseFactCollector):
        name = '_collector_0'
        _fact_ids = ['_fact_0']

    class Collector1(BaseFactCollector):
        name = '_collector_1'
        _fact_ids = ['_fact_1']

    class Collector2(BaseFactCollector):
        name = '_collector_2'
        _fact_ids = ['_fact_2']
        required_facts = ['_collector_0']

    class Collector3(BaseFactCollector):
        name = '_collector_3'
        _fact_ids = ['_fact_3']
        required_facts = ['_collector_1', '_collector_0']


# Generated at 2022-06-24 21:43:08.652807
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = []
    test_map = defaultdict(list)
    test_aliases = defaultdict(set)

    # create a class for unit test
    class MyCollector(BaseFactCollector):
          name = "TestFact"
          def collect(self, module=None, collected_facts=None):
              return {}

    # add the class to collectors_for_platform
    collectors_for_platform.append(MyCollector)

    # create the expected result
    test_map["TestFact"] = [MyCollector]
    test_aliases["TestFact"] = set()

    # call the function and compare the result
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert aliases_map == test_ali

# Generated at 2022-06-24 21:43:14.231235
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Test for function find_collectors_for_platform
    # Test 1: Test for no platform match
    all_collector_classes = []
    compat_platforms = []
    class TestAllCollectorClass1:
        _platform = None
        name = None
        required_facts = None
        @classmethod
        def platform_match(cls, platform_info):
            return None
    all_collector_classes.append(TestAllCollectorClass1)
    assert find_collectors_for_platform(all_collector_classes, compat_platforms) == set()

    # Test 2: Test for platform match
    all_collector_classes = []
    compat_platforms = []
    class TestAllCollectorClass2:
        _platform = 'Generic'
        name = None
        required_facts = None

# Generated at 2022-06-24 21:43:20.005990
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Create test data
    collectors_for_platform = [base_fact_collector_0]

    # Run function
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    # Check result
    assert len(fact_id_to_collector_map) == 1
    assert len(aliases_map) == 0


# Generated at 2022-06-24 21:43:29.104437
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['all', 'mounts']
    all_fact_subsets = {
        'mounts': [BaseFactCollector()],
        'network': [BaseFactCollector()],
        'all': [BaseFactCollector()],
    }
    all_fact_subsets['network'][0].required_facts = set(['all'])
    all_fact_subsets['mounts'][0].required_facts = set(['network'])

    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)

    # Expecting 1 unresolved requirement: network
    assert len(unresolved_requires) == 1

# TODO/maybe: the 'deps' and 'reverse_deps' stuff is a bit complicated.
#  Maybe move the basic parts of it into a utility

# Generated at 2022-06-24 21:43:39.284874
# Unit test for function get_collector_names
def test_get_collector_names():
    minimal_gather_subset_0 = frozenset(['min'])
    minimal_gather_subset_1 = frozenset(['min'])
    minimal_gather_subset_2 = frozenset(['min'])
    minimal_gather_subset_3 = frozenset(['min'])
    minimal_gather_subset_4 = frozenset(['min'])

    valid_subsets_0 = frozenset(['all', '!fact', 'network'])
    valid_subsets_1 = frozenset(['hardware'])
    valid_subsets_2 = frozenset(['all', '!min'])
    valid_subsets_3 = frozenset(['all', '!min', 'OS', 'hardware'])

# Generated at 2022-06-24 21:43:46.384858
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [BaseFactCollector]
    compat_platforms = [{'os': 'A1'}, {'os': 'A2'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 1
    assert BaseFactCollector in found_collectors


# Generated at 2022-06-24 21:43:50.327020
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    collectors = [base_fact_collector_0]
    result = build_fact_id_to_collector_map(collectors)
    assert result == defaultdict(list)
    base_fact_collector_0._fact_ids.add('test_key')
    result = build_fact_id_to_collector_map(collectors)
    assert result == defaultdict(list, {'test_key': [base_fact_collector_0]})


# Generated at 2022-06-24 21:43:58.408912
# Unit test for function get_collector_names
def test_get_collector_names():
    '''
    This is test for the positive condition
    '''
    valid_subsets = ['aix','ansible','archive','asup','bsd','cloud','date','deb','distribution','docker','domain','etc','facter','file','hardware','hostname','interfaces','ipmi','kernel','ldap','local','log','mac','mount','network','nodes','ohai','os','package','pkg','platform','ps','python','selinux','service','ssh','system','time','user','virtual','vmware']
    gather_subset = ['all', 'min']
    minimal_gather_subset = ['min', 'all']
    assert get_collector_names(valid_subsets, minimal_gather_subset, gather_subset) == 0


# Generated at 2022-06-24 21:44:03.950832
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [BaseFactCollector, ]
    compat_platforms = [{}]

    collect_list = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert collect_list == [BaseFactCollector, ]

    test_case_0()


# Generated at 2022-06-24 21:44:30.622351
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    class FactCollector_0(BaseFactCollector):
        name = 'name_0'
        required_facts = set()

    class FactCollector_1(BaseFactCollector):
        name = 'name_1'
        required_facts = {'name_0'}

    class FactCollector_2(BaseFactCollector):
        name = 'name_2'
        required_facts = {'name_0'}

    class FactCollector_3(BaseFactCollector):
        name = 'name_3'
        required_facts = {'name_1', 'name_2'}


# Generated at 2022-06-24 21:44:39.229385
# Unit test for function get_collector_names
def test_get_collector_names():
    # unit test for get_collector_names
    # get_collector_names(valid_subsets,
    #                    minimal_gather_subset,
    #                    gather_subset,
    #                    aliases_map,
    #                    platform_info)


    valid_subsets = ('min', 'hardware', 'network', 'virtual')
    minimal_gather_subset = ('min', 'hardware')
    gather_subset = ['all']
    aliases_map = {'hardware': set(['devices']), 'network': set(['network_resources'])}
    platform_info = {'system': 'foo'}

    print(get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info))
    # Expected Value:


# Generated at 2022-06-24 21:44:49.782985
# Unit test for function get_collector_names
def test_get_collector_names():
    # Basic test case
    try:
        collector_names = get_collector_names(valid_subsets = frozenset('all'),
                                              minimal_gather_subset = frozenset(('network',)),
                                              gather_subset = ['network', '!network'])
    except TypeError as e:
        if e.message == 'Bad subset \'!network\' given to Ansible. gather_subset options allowed: all, network':
            pass
        else:
            raise
    # Test case: Should raise TypeError

# Generated at 2022-06-24 21:44:57.715455
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Set up test list
    collector_names = ['a', 'b', 'd']
    all_fact_subsets = {
        'a': [BaseFactCollector()],
        'b': [BaseFactCollector()],
        'c': [BaseFactCollector()],
        'd': [BaseFactCollector()],
    }
    # No required facts, should return empty list
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Inject a required fact
    all_fact_subsets['a'][0].required_facts = {'c'}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'c'}

    # Add required fact to list
    collector_names.append('c')
   

# Generated at 2022-06-24 21:45:03.126714
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with minimal arguments
    actual = get_collector_names()

# TODO: tests for fact_collector_names_for_task
# TODO: tests for get_fact_collector_names_ordered


# TODO/MAYBE: move this somewhere else

# Generated at 2022-06-24 21:45:10.712638
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''
    collector_names     = {'a', 'b', 'c', 'd'}
    all_fact_subsets    = {
        'a': {1, 2, 3},
        'b': {},
        'c': {6, 7},
        'd': {},
        }

    '''
    collector_names = set(['a', 'b', 'c', 'd'])
    all_fact_subsets = defaultdict(set)
    all_fact_subsets['a'] = set([1, 2, 3])
    all_fact_subsets['b'] = set([])
    all_fact_subsets['c'] = set([6, 7])
    all_fact_subsets['d'] = set([])


# Generated at 2022-06-24 21:45:22.098698
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {'foo': [BaseFactCollector]}
    collector_names = ['foo']
    required_facts = find_unresolved_requires(collector_names, all_fact_subsets)
    assert required_facts == set()

    all_fact_subsets = {'foo': [BaseFactCollector(required_facts=('bar', 'baz'))]}
    collector_names = ['foo']
    required_facts = find_unresolved_requires(collector_names, all_fact_subsets)
    assert required_facts == frozenset(('bar', 'baz'))

    all_fact_subsets = {'foo': [BaseFactCollector(required_facts=('bar', 'baz'))]}
    collector_names = ['foo', 'bar', 'baz']
    required

# Generated at 2022-06-24 21:45:32.026920
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    def test_find_unresolved_requires_inner(
        collector_names,
        all_fact_subsets,
        expected_unresolved,
    ):
        unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
        assert unresolved == expected_unresolved

    all_fact_subsets = {
        'fact0': [BaseFactCollector()],
        'fact1': [BaseFactCollector()],
        'fact2': [BaseFactCollector()],
        'fact3': [BaseFactCollector()],
    }
    for fact_id in all_fact_subsets.keys():
        all_fact_subsets[fact_id][0].name = fact_id


# Generated at 2022-06-24 21:45:41.558836
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    fact_collector_0 = BaseFactCollector()
    fact_collector_0.name = 'test_fact_0'
    fact_collector_0.required_facts = {'test_fact_1'}

    fact_collector_1 = BaseFactCollector()
    fact_collector_1.name = 'test_fact_1'
    fact_collector_1.required_facts = {'test_fact_2'}

    fact_collector_2 = BaseFactCollector()
    fact_collector_2.name = 'test_fact_2'
    fact_collector_2.required_facts = {}

    fact_collector_3 = BaseFactCollector()
    fact_collector_3.name = 'test_fact_3'

# Generated at 2022-06-24 21:45:48.411563
# Unit test for function build_dep_data
def test_build_dep_data():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    setattr(base_fact_collector_0, 'required_facts', set(['base_fact_collector_1']))
    setattr(base_fact_collector_1, 'required_facts', set(['base_fact_collector_2']))
    setattr(base_fact_collector_2, 'required_facts', set(['base_fact_collector_0']))
    setattr(base_fact_collector_0, 'name', 'base_fact_collector_0')
    setattr(base_fact_collector_1, 'name', 'base_fact_collector_1')
   

# Generated at 2022-06-24 21:46:09.733178
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Test case 0
    base_fact_collector_0 = BaseFactCollector()

# Generated at 2022-06-24 21:46:13.810371
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['base0']
    all_fact_subsets = {'base0': [base_fact_collector_0]}
    assert(find_unresolved_requires(collector_names, all_fact_subsets) == set())



# Generated at 2022-06-24 21:46:17.780749
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    assert base_fact_collector_0.name is None
    assert base_fact_collector_0._fact_ids == set()
    assert base_fact_collector_0.required_facts == set()
    assert hasattr(base_fact_collector_0, 'collect')


# Generated at 2022-06-24 21:46:27.237762
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all'],
                               minimal_gather_subset=frozenset(['']),
                               valid_subsets=frozenset([''])) == frozenset(['', 'min'])
    assert get_collector_names(gather_subset=['all'],
                               minimal_gather_subset=frozenset(['min']),
                               valid_subsets=frozenset(['foo', 'bar'])) == frozenset(['foo', 'min', 'bar'])

# Generated at 2022-06-24 21:46:36.881827
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # test case 1
    all_fact_subsets = {'all': [type('test', (BaseFactCollector,), {'name': 'test'})], '!min': [type('test', (BaseFactCollector,), {'name': 'test'})]}
    collector_names = ['min']
    result = select_collector_classes(collector_names, all_fact_subsets)
    assert result == []

    # test case 2
    collector_names = ['all', '!min']
    result = select_collector_classes(collector_names, all_fact_subsets)
    assert result == [type('test', (BaseFactCollector,), {'name': 'test'})]


# Generated at 2022-06-24 21:46:46.509846
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    fact_id_to_collector_map = {
        u'base': [BaseFactCollector],
        u'base_0': [BaseFactCollector],
        u'base_1': [BaseFactCollector],
        u'base_2': [BaseFactCollector],
        u'base_3': [BaseFactCollector],
        u'base_4': [BaseFactCollector],
        u'base_5': [BaseFactCollector],
        u'base_6': [BaseFactCollector],
        u'base_7': [BaseFactCollector],
        u'base_8': [BaseFactCollector],
        u'base_9': [BaseFactCollector]
    }

# Generated at 2022-06-24 21:46:53.914869
# Unit test for function get_collector_names
def test_get_collector_names():
    # 1
    assert get_collector_names(gather_subset=['all']) == set()
    # 2
    assert get_collector_names(gather_subset=['min']) == set()
    # 3
    assert get_collector_names(gather_subset=['!all']) == set()
    # 4
    assert get_collector_names(gather_subset=['all', '!all']) == set()
    # 5
    assert get_collector_names(gather_subset=['!all', 'all']) == set()
    # 6
    assert get_collector_names(gather_subset=['!all', 'all', 'min']) == set()
    # 7

# Generated at 2022-06-24 21:47:02.940486
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector0(BaseFactCollector):
        name = 'collector0'
        required_facts = {'test1', 'test2'}

    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = {'test1', 'test3'}

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = {'test3', 'test4'}

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = {'test5', 'test6'}


# Generated at 2022-06-24 21:47:09.547865
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    BaseFactCollector1 = BaseFactCollector
    class BaseFactCollector2(BaseFactCollector):
        pass

    class BaseFactCollector3(BaseFactCollector):
        pass

    class BaseFactCollector4(BaseFactCollector):
        pass

    class BaseFactCollector5(BaseFactCollector):
        pass

# Generated at 2022-06-24 21:47:14.453457
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['all', 'alias', 'alias']
    all_fact_subsets = {'all': [],
                        'alias': [test_case_0]}
    updated_fact_ids = select_collector_classes(collector_names, all_fact_subsets)
    assert updated_fact_ids == [test_case_0]



# Generated at 2022-06-24 21:47:30.163328
# Unit test for function select_collector_classes
def test_select_collector_classes():
    fact_subsets = dict()
    fact_subsets['test_dependency_satisfied_0'] = [test_dependency_satisfied_0]
    fact_subsets['test_dependency_0'] = [test_dependency_0]
    fact_subsets['test_dependency_satisfied_1'] = [test_dependency_satisfied_1]
    fact_subsets['test_dependency_1'] = [test_dependency_1]

    selected_collector_classes = select_collector_classes(['test_dependency_satisfied_0', 'test_dependency_0', 'test_dependency_satisfied_1', 'test_dependency_1'], fact_subsets)
    print(selected_collector_classes)

# Generated at 2022-06-24 21:47:39.854166
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    all_fact_collector_classes = [
        PlatformFactCollector,
        ArchFactCollector,
        DistributionFactCollector,
        MachineFactCollector,
    ]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_fact_collector_classes)

    assert set(fact_id_to_collector_map.keys()) == set(['platform', 'arch', 'distribution', 'machine'])
    assert len(fact_id_to_collector_map['platform']) == 1
    assert len(fact_id_to_collector_map['arch']) == 1
    assert len(fact_id_to_collector_map['distribution']) == 1
    assert len(fact_id_to_collector_map['machine'])

# Generated at 2022-06-24 21:47:45.963749
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0.name = u'base'
    base_fact_collector_0.required_facts = 'nope'

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1.name = u'base'
    base_fact_collector_1.required_facts = 'nope'
    base_fact_collector_1._fact_ids = ['base']

    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_2.name = u'system'
    base_fact_collector_2.required_facts = 'nope'
    base_fact_collector_2._fact_ids = ['system']


# Generated at 2022-06-24 21:47:49.092076
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['sub_all', 'sub_min']
    all_fact_subsets = {'sub_all': [BaseFactCollector], 'sub_min': [BaseFactCollector]}
    select_collector_classes(collector_names, all_fact_subsets)
