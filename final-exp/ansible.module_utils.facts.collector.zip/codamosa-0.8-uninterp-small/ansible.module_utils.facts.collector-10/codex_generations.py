

# Generated at 2022-06-24 21:38:23.930161
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = set()

    collector_classes = []

    compat_platforms = (
        {'System': 'test_system_0'},
        {'System': 'test_system_1'},
        {'System': 'test_system_1'},
        {'System': 'test_system_2'},
        {'System': 'test_system_1'}
    )

    collector_classes.append(BaseFactCollector)
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 1
    found_collector = found_collectors.pop()
    assert found_collector == BaseFactCollector



# Generated at 2022-06-24 21:38:33.024512
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collectors1:
        class BaseFactCollector:
            name = 'name1'

    class Collectors2:
        class BaseFactCollector:
            name = 'name2'

    class Collectors3:
        class BaseFactCollector:
            name = 'name3'

    class Collectors4(Collectors1, Collectors2, Collectors3):
        pass

    class Collectors5:
        class BaseFactCollector:
            name = 'name4'

    test_input = (Collectors1, Collectors2, Collectors3, Collectors4, Collectors5)
    test_platform = {'system': 'Linux'}
    test_platform_2 = {'system': 'Darwin'}

    expected_result = {Collectors1, Collectors2, Collectors3}
    actual_result = find_collect

# Generated at 2022-06-24 21:38:37.438283
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    expected_result_0 = set()
    expected_result_1 = {'fact-2'}
    expected_result_2 = {'fact-2', 'fact-3'}
    expected_result_3 = set()
    expected_result_4 = set()
    expected_result_5 = {'fact-1'}
    expected_result_6 = {'fact-1', 'fact-2'}
    expected_result_7 = {'fact-1'}
    expected_result_8 = {'fact-3'}

    fact_collector_0 = BaseFactCollector()
    fact_id_0 = 'fact-0'
    fact_collector_0.name = fact_id_0
    fact_collector_0.required_facts = set()
    fact_collector_0._fact_ids

# Generated at 2022-06-24 21:38:48.782502
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():

    class TestCollectorMatchSysName(BaseFactCollector):
        _platform = 'Linux'
        name = 'test_collector_1_0'

    class TestCollectorMatchSysNameVer(BaseFactCollector):
        _platform = 'Linux'
        name = 'test_collector_2_0'
        _sys_version = '3.10.0-514.10.2.el7.x86_64'

    class TestCollectorMatchSysNameVerNot(BaseFactCollector):
        _platform = 'Linux'
        name = 'test_collector_1_1'
        _sys_version = '3.10.0-514.10.2.el7.x86_64'

    class TestCollectorMatchSysNameNot(BaseFactCollector):
        _platform = 'Linux'

# Generated at 2022-06-24 21:38:54.828374
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['all', 'snapd', 'network', 'snapd_info']
    all_fact_subsets = {'all': [BaseFactCollector],
                        'snapd': [BaseFactCollector],
                        'network': [BaseFactCollector],
                        'snapd_info': [BaseFactCollector]}

    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'all': set(),
                       'snapd': set(),
                       'network': set(),
                       'snapd_info': set()}



# Generated at 2022-06-24 21:39:01.474031
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class MockAllCollectorClass:
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()
        def __init__(self):
            pass
        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == cls._platform:
                return cls
            return None
    class MockAllCollectorClass0(MockAllCollectorClass):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'hostname'
        required_facts = set()
    class MockAllCollectorClass1(MockAllCollectorClass):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'distribution'
        required_facts = set()
   

# Generated at 2022-06-24 21:39:12.378729
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_3 = BaseFactCollector()

    collector_list = [base_fact_collector_0, base_fact_collector_1, base_fact_collector_2, base_fact_collector_3]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collector_list)

    assert fact_id_to_collector_map.get(base_fact_collector_0.name) is not None

# Generated at 2022-06-24 21:39:18.626827
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collectors_for_platform = []
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert fact_id_to_collector_map == defaultdict(list)
    assert aliases_map == defaultdict(set)


# Generated at 2022-06-24 21:39:24.679506
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    all_collector_classes = []
    collectors_for_platform = []
    collectors_for_platform.append(BaseFactCollector)

    fact_id_to_collector_map, aliases_map = \
        build_fact_id_to_collector_map(collectors_for_platform)

    assert (fact_id_to_collector_map['Generic'] ==
            [BaseFactCollector])
    assert (aliases_map == defaultdict(set))


# Generated at 2022-06-24 21:39:33.110045
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_set0 = {'test_fact'}
    test_set1 = {'test_fact', 'test_fact_1'}

    assert find_unresolved_requires(test_set0, {}) == test_set0
    assert find_unresolved_requires(test_set1, {}) == test_set1
    assert find_unresolved_requires(set(), {}) == set()

    all_fact_subsets = {
        'test_fact': [BaseFactCollector],
        'test_fact_1': [BaseFactCollector],
    }
    assert find_unresolved_requires(test_set0, all_fact_subsets) == set()
    assert find_unresolved_requires(test_set1, all_fact_subsets) == set()



# Generated at 2022-06-24 21:39:50.459899
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {}
    assert find_unresolved_requires(['foo'], all_fact_subsets) == set()
    assert find_unresolved_requires(['base'], all_fact_subsets) == set()

    collector_0 = BaseFactCollector()
    collector_0.required_facts = set(['foo'])
    collector_0.name = 'collector-0'
    all_fact_subsets[collector_0.name] = [collector_0]

    collector_1 = BaseFactCollector()
    collector_1.required_facts = set(['foo'])
    collector_1.name = 'collector-1'
    all_fact_subsets[collector_1.name] = [collector_1]


# Generated at 2022-06-24 21:39:56.457835
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # collector_names and all_fact_subsets are the same as in
    # the test_case_0 from above
    base_fact_collector_0 = BaseFactCollector()
    collector_names = [base_fact_collector_0]
    all_fact_subsets = {base_fact_collector_0: [base_fact_collector_0]}
    assert not find_unresolved_requires(collector_names, all_fact_subsets)

    base_fact_collector_0 = BaseFactCollector()
    collector_names = [base_fact_collector_0]
    all_fact_subsets = {base_fact_collector_0: [base_fact_collector_0]}
    assert not find_unresolved_requires(collector_names, all_fact_subsets)



# Generated at 2022-06-24 21:40:06.901490
# Unit test for function get_collector_names
def test_get_collector_names():
    base_fact_collector_0 = BaseFactCollector()
    valid_subsets = [
            'all',
            'hardware',
            'network',
            'virtual'
            ]
    minimal_gather_subset = ['all']
    gather_subset = [
            'min',
            '!hardware',
            '!network',
            '!virtual'
            ]
    aliases_map = {}
    assert(get_collector_names(valid_subsets,
                               minimal_gather_subset,
                               gather_subset,
                               aliases_map,
                               base_fact_collector_0) == set())


# Generated at 2022-06-24 21:40:14.753191
# Unit test for function get_collector_names
def test_get_collector_names():

    # test 0
    valid_subsets = frozenset(('all', 'network', 'virtual'))
    minimal_gather_subset = frozenset(('all'))
    gather_subset = ['all']
    aliases_map = defaultdict(set)
    platform_info = {'system': 'Linux'}

    additional_subsets = get_collector_names(valid_subsets=valid_subsets,
                                             minimal_gather_subset=minimal_gather_subset,
                                             gather_subset=gather_subset,
                                             aliases_map=aliases_map,
                                             platform_info=platform_info)
    assert(additional_subsets == minimal_gather_subset)

    # test 1

# Generated at 2022-06-24 21:40:24.623283
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = {'collector-a', 'collector-a-alias'}
        name = 'collector-a'

    class CollectorB(BaseFactCollector):
        _fact_ids = {'collector-b'}
        name = 'collector-b'

        # collector-b depends on collector-a for some data
        required_facts = {'collector-a'}

    class CollectorC(BaseFactCollector):
        _fact_ids = {'collector-c'}
        name = 'collector-c'

        # collector-c depends on collector-b for some data
        required_facts = {'collector-b'}

    class CollectorD(BaseFactCollector):
        _fact_ids = {'collector-d'}
       

# Generated at 2022-06-24 21:40:31.593526
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # GIVEN a list of all names of the fact collectors
    all_names = ['all', 'min', 'hardware', 'network', 'virtual', 'ohai', 'facter', 'system']

    # WHEN a subset of fact collector names is passed to function select_collector_classes
    # along with the set of all names
    selected_names = select_collector_classes(['hardware', 'facter'], all_names)

    # THEN the selected names should match the subset names
    assert selected_names == ['hardware', 'facter']


# Generated at 2022-06-24 21:40:40.315263
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0._fact_ids.add('base')
    base_fact_collector_0.name = 'base'

    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids.add('base')
    base_fact_collector_1.name = 'base'

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([base_fact_collector_0, base_fact_collector_1])
    assert aliases_map[base_fact_collector_0.name] == {'base'}


# Generated at 2022-06-24 21:40:48.975774
# Unit test for function get_collector_names
def test_get_collector_names():
    # alises mapping to be defined in a future patch in module_utils/facts.py
    aliases_map = defaultdict(set)

    valid_subsets = frozenset()
    minimal_gather_subset = frozenset(['!all'])

    gather_subset_0 = ['!minimal']
    gather_subset_1 = ['!minimal', '!hardware']
    gather_subset_2 = ['!minimal', 'network']
    gather_subset_3 = ['all']
    gather_subset_4 = ['!all']
    gather_subset_5 = ['minimal', '!all', 'network']
    gather_subset_6 = ['all', 'minimal']
    gather_subset_7 = ['!all', 'minimal']

# Generated at 2022-06-24 21:40:58.709240
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():

    # Test collector_names with unknown collector
    collector_names = {'cpu', 'unknown'}
    all_fact_subsets = {'cpu': [1, 2, 3], 'memory': [4, 5, 6]}
    try:
        find_unresolved_requires(collector_names, all_fact_subsets)
        assert False
    except CollectorNotFoundError as e:
        assert str(e) == 'Fact collector "unknown" not found'

    # Test collector_names with unresolved require
    collector_names = {'cpu', 'mem'}
    all_fact_subsets = {'cpu': [1, 2, 3], 'mem': [4, 5, 6]}
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test collector_names with resolved

# Generated at 2022-06-24 21:41:09.131625
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'network', 'hardware', 'virtual'])
    minimal_gather_subset = frozenset(['all'])

    # Test all collection
    gather_subset = ['all']
    collector_names = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset)
    assert collector_names == set(['all'])

    # Test minimal collection
    gather_subset = ['min']
    collector_names = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset)
    assert collector_names == set(['all'])

    # Test negative subset collection
    gather_subset = ['!network']

# Generated at 2022-06-24 21:41:26.289092
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_0._fact_ids = ['test']
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_1._fact_ids = ['test2']

    collectors_for_platform = {base_fact_collector_0, base_fact_collector_1}

    fact_id_to_collector_map, _ = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map.keys() == {'test', 'test2'}
    assert fact_id_to_collector_map['test'] == [base_fact_collector_0]

# Generated at 2022-06-24 21:41:30.207685
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = frozenset(['4', '5', '6'])
    all_fact_subsets = {'5': [BaseFactCollector()], '6': [BaseFactCollector()], '4': [BaseFactCollector()]}
    assert(build_dep_data(collector_names, all_fact_subsets) == {'5': set(), '6': set(), '4': set()})


# Generated at 2022-06-24 21:41:34.369021
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    test_case_0()



# Generated at 2022-06-24 21:41:46.041923
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'base': [base_fact_collector_0],
        'bios': [bios_fact_collector_0],
        'network': [network_fact_collector_0]
    }

    class bios_fact_collector_0(BaseFactCollector):
        name = 'bios'
        required_facts = set()

    class network_fact_collector_0(BaseFactCollector):
        name = 'network'
        required_facts = frozenset(('base', 'bios'))
        '''name and required_facts are defined as fact collectors in unit tests'''

    class bios_fact_collector_1(BaseFactCollector):
        name = 'bios'
        required_facts = frozenset(('base',))

# Generated at 2022-06-24 21:41:53.013842
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # A list of BaseFactCollector instances
    collectors_for_platform = [base_fact_collector_0]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(
        collectors_for_platform)
    assert(fact_id_to_collector_map['BaseFactCollector']
           == collectors_for_platform)



# Generated at 2022-06-24 21:42:03.260569
# Unit test for function select_collector_classes
def test_select_collector_classes():

    fact_subsets = {'distribution': ['CentOS'],
                    'hostvars': ['host1'],
                    'interfaces': ['eth0', 'eth1']}

    # Test case: only one subset
    collector_names = ['hostvars']
    selected_collector_classes = select_collector_classes(collector_names, fact_subsets)
    assert ['host1'] == selected_collector_classes

    # Test case: two of the three subsets in the list
    collector_names = ['hostvars', 'interfaces']
    selected_collector_classes = select_collector_classes(collector_names, fact_subsets)
    assert ['host1', 'eth0', 'eth1'] == selected_collector_classes

    # Test case: all three subsets in the list
    collector_names

# Generated at 2022-06-24 21:42:08.480224
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # Try to retrieve a list of fact collectors that match arguements given
    # First try empty arguments
    all_collector_classes = []
    valid_subsets = set()
    minimal_gather_subset = set()
    gather_subset = []
    gather_timeout = None
    platform_info = None

    collectors = collector_classes_from_gather_subset(all_collector_classes=all_collector_classes,
                                                      valid_subsets=valid_subsets,
                                                      minimal_gather_subset=minimal_gather_subset,
                                                      gather_subset=gather_subset,
                                                      gather_timeout=gather_timeout,
                                                      platform_info=platform_info)
    print("collectors: ", collectors)

    # Next try with an unknown

# Generated at 2022-06-24 21:42:16.217522
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    class FirstCollector(BaseFactCollector):
        name = 'first'
        _fact_ids = set(['first'])  # for assert

        _platform = 'Fake'
        required_facts = set(['one', 'two'])  # for assert

    class SecondCollector(BaseFactCollector):
        name = 'second'
        _fact_ids = set(['second'])  # for assert

        _platform = 'Fake'

    class ThirdCollector(BaseFactCollector):
        name = 'third'

# Generated at 2022-06-24 21:42:26.677222
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector.hardware.cpu import CPUCollector
    from ansible.module_utils.facts.collector.hardware.dmi import DmiCollector
    from ansible.module_utils.facts.collector.hardware.mem_0 import Mem0Collector
    from ansible.module_utils.facts.collector.hardware.mem_1 import Mem1Collector
    from ansible.module_utils.facts.collector.hardware.mem_2 import Mem2Collector
    from ansible.module_utils.facts.collector.hardware.system import SystemCollector
    from ansible.module_utils.facts.collector.hardware.motherboard import MotherboardCollector

# Generated at 2022-06-24 21:42:35.425693
# Unit test for function select_collector_classes
def test_select_collector_classes():
    dummy_collector_class_0 = BaseFactCollector()
    dummy_collector_class_1 = BaseFactCollector()
    dummy_collector_class_2 = BaseFactCollector()
    dummy_collector_class_3 = BaseFactCollector()

    all_fact_subsets = {
        'all': [dummy_collector_class_0,
                dummy_collector_class_1,
                dummy_collector_class_2,
                dummy_collector_class_3],
        'min': [dummy_collector_class_2,
                dummy_collector_class_3],
        'something_else': [dummy_collector_class_1,
                           dummy_collector_class_3],
    }


# Generated at 2022-06-24 21:42:50.670359
# Unit test for function get_collector_names
def test_get_collector_names():
    all_data = [
        (['fact1', 'fact2'], ['fact1', 'fact2']),
        (['fact1', '!fact2'], ['fact1']),
        (['!fact2'], []),
        (['min'], ['fact1']),
    ]
    valid_subsets = {'fact1', 'fact2', 'fact3'}
    minimal_gather_subset = {'fact1'}
    aliases_map = {'fact1': {'fact1'}}

# Generated at 2022-06-24 21:43:01.772418
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['network', 'hardware', 'virtual']
    all_fact_subsets = {}
    all_fact_subsets['network'] = ['network']
    all_fact_subsets['hardware'] = ['hardware']
    all_fact_subsets['virtual'] = ['virtual']
    all_fact_subsets['network'].append(BaseFactCollector())
    all_fact_subsets['hardware'].append(BaseFactCollector())
    all_fact_subsets['virtual'].append(BaseFactCollector())
    result_unresolved = set()
    result_unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(result_unresolved) == 0


# Generated at 2022-06-24 21:43:05.661400
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    collector_classes = [BaseFactCollector]
    fact_id_to_collector_map_result,aliases_map = build_fact_id_to_collector_map(collector_classes)
    assert fact_id_to_collector_map_result['Generic'] == [BaseFactCollector]
    assert aliases_map['Generic'] == set()


# Generated at 2022-06-24 21:43:13.268058
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = defaultdict(list)

    class BaseFactCollector_0(BaseFactCollector):
        name = 'base_fact_collector_0'
        required_facts = set()
    all_fact_subsets['base_fact_collector_0'].append(BaseFactCollector_0)

    class BaseFactCollector_1(BaseFactCollector):
        name = 'base_fact_collector_1'
        required_facts = set()
    all_fact_subsets['base_fact_collector_1'].append(BaseFactCollector_1)

    class BaseFactCollector_2(BaseFactCollector):
        name = 'base_fact_collector_2'
        required_facts = set()

# Generated at 2022-06-24 21:43:18.607036
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    base_fact_collector_2 = BaseFactCollector()
    base_fact_collector_3 = BaseFactCollector()

    base_fact_collector_0.name = 'collector_0'
    base_fact_collector_1.name = 'collector_1'
    base_fact_collector_2.name = 'collector_2'
    base_fact_collector_3.name = 'collector_3'

    base_fact_collector_0.required_facts = ['collector_2']
    base_fact_collector_1.required_facts = ['collector_3']
    base_fact_collector_2.required_facts = []
   

# Generated at 2022-06-24 21:43:25.787584
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class BaseFactCollector1(BaseFactCollector):
        _platform = 'Linux'

    class BaseFactCollector2(BaseFactCollector):
        _platform = 'Linux'

    class BaseFactCollector3(BaseFactCollector):
        _platform = 'Linux'

    class BaseFactCollector4(BaseFactCollector):
        _platform = 'Linux'

    all_collector_classes = [BaseFactCollector1, BaseFactCollector2, BaseFactCollector3, BaseFactCollector4]
    compat_platforms = ['Linux', 'Other']

    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    assert len(found_collectors) == 4
    assert BaseFactCollector1 in found_collectors
    assert BaseFactCollector2 in found_collect

# Generated at 2022-06-24 21:43:36.294377
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    base_fact_collector = BaseFactCollector()
    assert len(base_fact_collector.fact_ids) == 1
    assert 'system' in base_fact_collector.fact_ids
    assert 'Generic' == base_fact_collector._platform
    assert base_fact_collector.name is None

    class SampleFactCollector(BaseFactCollector):
        _fact_ids = {'sample_fact'}
        _platform = 'Linux'
        name = 'sample_collector'
        required_facts = {'system'}

    class AnotherSampleFactCollector(BaseFactCollector):
        _fact_ids = {'another_sample_fact', 'sample_fact'}
        _platform = 'Generic'
        name = 'another_sample_collector'

# Generated at 2022-06-24 21:43:43.043512
# Unit test for function find_unresolved_requires

# Generated at 2022-06-24 21:43:53.772207
# Unit test for function get_collector_names
def test_get_collector_names():
    base_fact_collector_0 = BaseFactCollector()
    base_fact_collector_1 = BaseFactCollector()
    aliases_map = defaultdict(set)
    aliases_map.update({"hardware": set(["devices", "dmi"])})
    gather_subset = ["all"]
    platform_info = {"distribution": "Fedora", "distribution_release": "29", "distribution_version": "29", "system": "Linux"}
    valid_subsets = frozenset()
    minimal_gather_subset = frozenset(["all"])
    expected_result = frozenset(["all"])
    result = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map, platform_info)
    assert result == expected

# Generated at 2022-06-24 21:44:00.408960
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    _, aliases_map = build_fact_id_to_collector_map(set())
    assert aliases_map == defaultdict(set)
    _, aliases_map = build_fact_id_to_collector_map({BaseFactCollector})
    assert aliases_map == defaultdict(set, {'Generic': ('Generic',)})
    _, aliases_map = build_fact_id_to_collector_map({BaseFactCollector, LinuxFactCollector})
    assert aliases_map == defaultdict(set, {'Linux': ('Linux',), 'Generic': ('Generic',)})
    _, aliases_map = build_fact_id_to_collector_map({BaseFactCollector, LinuxFactCollector_0})

# Generated at 2022-06-24 21:44:15.685264
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    found_collectors = find_collectors_for_platform(base_fact_collector_0, compat_platforms)
    assert base_fact_collector_0.name in found_collectors

# Generated at 2022-06-24 21:44:19.863088
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    """ Unit test for function: build_fact_id_to_collector_map """
    collectors_for_platform = set([test_case_0])

# Generated at 2022-06-24 21:44:24.352779
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    # Just ensure function runs without error

    collectors_for_platform = [test_case_0()]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)



# Generated at 2022-06-24 21:44:30.886074
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    def MyFactCollector1(BaseFactCollector):
        name = 'myfact'
        required_facts = [
            'myfact',
            'dummyfact',
        ]

    def MyFactCollector2(BaseFactCollector):
        name = 'myfact'
        required_facts = [
            'myfact',
            'dummyfact',
        ]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform=[MyFactCollector1, MyFactCollector2])

    assert fact_id_to_collector_map['myfact'] == [MyFactCollector1, MyFactCollector2]

# Generated at 2022-06-24 21:44:39.311718
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    test_fact_subsets = {
        'first': [BaseFactCollector],
        'second': [BaseFactCollector],
        'last': [BaseFactCollector],
    }
    fact_collector_id = 'first'
    fact_collector_id_list = ['first']
    assert find_unresolved_requires(fact_collector_id_list, test_fact_subsets) == set()

    fact_collector_id_list = ['first', 'second']
    assert find_unresolved_requires(fact_collector_id_list, test_fact_subsets) == set()

    fact_collector_id_list = ['first', 'second', 'last']
    assert find_unresolved_requires(fact_collector_id_list, test_fact_subsets) == set()



# Generated at 2022-06-24 21:44:49.876191
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_subsets = frozenset(('all', 'min', 'facter', 'ohai', 'network', 'hardware'))
    minimal_subsets = frozenset(('min'))
    # TODO: move gather_subset_always_included_in_all here?
    aliases_map = defaultdict(set, {
        'hardware': frozenset(('devices', 'dmi')),
    })
    platform_info = {
        'system': 'Linux',
    }
    module = None
    # NOTE: this is skipped when not a terminal, but I want to see it
    # (and timeout is overwritten later).
    timeout_value = 5

# Generated at 2022-06-24 21:44:58.736854
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestFactCollector(BaseFactCollector):
        name = 'test_fact_collector'

    fact_collectors_for_platform = [TestFactCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(fact_collectors_for_platform)

    assert fact_id_to_collector_map
    assert isinstance(fact_id_to_collector_map, defaultdict)

    # Check entry for key 'test_fact_collector'
    assert fact_id_to_collector_map.get('test_fact_collector', None)
    assert len(fact_id_to_collector_map.get('test_fact_collector', False)) == 1

    # Check entry for key 'test_fact_collector_1'

# Generated at 2022-06-24 21:45:09.118067
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a' : set(['b', 'c']),
        'b' : set(['c']),
        'd' : set(['a']),
        'e' : set(['d', 'a']),
    }
    sorted_list = tsort(dep_map)

    assert len(sorted_list) == 5
    assert sorted_list[0][0] == 'c'
    assert sorted_list[1][0] == 'b'
    assert sorted_list[2][0] == 'a'
    assert sorted_list[3][0] == 'd'
    assert sorted_list[4][0] == 'e'

    # Add a circular dependency
    dep_map['c'] = set(['d'])

# Generated at 2022-06-24 21:45:15.511675
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector import PLATFORM_COLLECTOR_SUBSETS # pylint: disable=import-error
    from ansible.module_utils.facts import collection

    # Setup
    all_collector_classes = [collection.LinuxDistribution]
    compat_platforms = [{'system': platform.system()}]

    # Invoke
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)

    # Check
    assert(len(found_collectors) == 1)
    assert(list(found_collectors)[0] == collection.LinuxDistribution)



# Generated at 2022-06-24 21:45:20.713804
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.system.apparmor import AppArmorFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

    # Test when different sub classes of BaseFactCollector are present and expected
    # results are same as input
    all_collector_classes_input = {AppArmorFactCollector(), DistributionFactCollector(), PkgMgrFactCollector()}
    all_collector_classes_output = find_collectors_for_platform(all_collector_classes_input,
                                                                ["Debian-8-x86_64"])
    assert(all_collector_classes_input == all_collector_classes_output)

    # Test when different

# Generated at 2022-06-24 21:45:44.888855
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector as facts_collector
    sz = len(facts_collector.FACT_SUBSETS)
    #additional_subsets = get_collector_names(valid_subsets=facts_collector.FACT_SUBSETS, gather_subset=['network', 'hardware', '!fibrechannel'])
    #additional_subsets = get_collector_names(valid_subsets=facts_collector.FACT_SUBSETS, gather_subset=['network', 'hardware', 'fibrechannel', '!all'])
    #additional_subsets = get_collector_names(valid_subsets=facts_collector.FACT_SUBSETS, gather_subset=['network', 'hardware', '!all'])
    #add

# Generated at 2022-06-24 21:45:54.985150
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    test_collector_classes = [
        BaseFactCollector(['all']),
        BaseFactCollector(['network']),
        BaseFactCollector(['network', 'all']),
        BaseFactCollector(['all', 'network'])
    ]

    test_module_params = {
        'gather_subset': [
            None, ['all'], ['network'], ['all', 'network'], ['network', 'all']
        ],
        'valid_subsets': [
            ['all', 'network', 'hardware'], ['network', 'hardware'],
            ['all', 'hardware'], ['all']
        ],
        'minimal_gather_subset': [
            ['network'], ['all', 'network'], ['all']
        ]
    }


# Generated at 2022-06-24 21:46:02.040811
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'all': [
            BaseFactCollector(name='all'),
        ],
        'min': [
            BaseFactCollector(name='min'),
        ],
        'network': [
            BaseFactCollector(name='network'),
        ],
        'all_network': [
            BaseFactCollector(name='all_network', required_facts=['all', 'network']),
        ],
        'all_nothing': [
            BaseFactCollector(name='all_nothing', required_facts=['all', 'nothing']),
        ],
    }

    collector_names = ['all', 'min', 'network', 'all_network', 'all_nothing']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-24 21:46:06.615917
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = [BaseFactCollector]
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert(found_collectors == set([BaseFactCollector]))



# Generated at 2022-06-24 21:46:17.241816
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class BaseFactCollector1(BaseFactCollector):
        _platform = 'A'
        name = 'name_a'

    class BaseFactCollector2(BaseFactCollector):
        _platform = 'A'
        name = 'name_b'

    class BaseFactCollector3(BaseFactCollector):
        _platform = 'B'
        name = 'name_c'

    all_collectors = [BaseFactCollector1, BaseFactCollector2, BaseFactCollector3]

    compat_platform_name = 'A'

    platform_info = {'system': compat_platform_name}

    res = find_collectors_for_platform(all_collectors, [platform_info])
    assert set(res) == set(all_collectors[0:2]), 'Did not return all collectors for a specific platform'



# Generated at 2022-06-24 21:46:23.587403
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():

    collectors_for_platform = [
        BaseFactCollector('collector_0'),
        BaseFactCollector('collector_1'),
        BaseFactCollector('collector_2'),
    ]

    fact_id_to_collector_map_exp = {
        'collector_0': [BaseFactCollector('collector_0')],
        'collector_1': [BaseFactCollector('collector_1')],
        'collector_2': [BaseFactCollector('collector_2')],
    }

    aliases_map_exp = {
        'collector_0': {'collector_0'},
        'collector_1': {'collector_1'},
        'collector_2': {'collector_2'},
    }

    fact_id_to_collector_map,

# Generated at 2022-06-24 21:46:26.355884
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    all_collector_classes = []
    compat_platforms = []
    actual_result = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert actual_result == set()


# Generated at 2022-06-24 21:46:31.349876
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    #input
    all_collector_classes = []
    compat_platforms = [
        {'system': 'Linux'},
        {'system': 'Windows'}
    ]

    #output
    found_collectors = []

    assert find_collectors_for_platform(all_collector_classes, compat_platforms) == found_collectors



# Generated at 2022-06-24 21:46:39.867464
# Unit test for function get_collector_names
def test_get_collector_names():
    # empty collector
    base_fact_collector = BaseFactCollector()

    # test empty params and expected results
    result = get_collector_names()
    assert result == frozenset(('all',))

    # test subset params and expected results
    result = get_collector_names('all')
    assert result == frozenset(('all',))

    # test negative
    result = get_collector_names('!all')
    assert not result

    # test subset and excludes params and expected results
    result = get_collector_names('network,!all')
    assert result == frozenset(('network',))

    # test subset and excludes params and expected results
    result = get_collector_names(('!network,!hardware,network,all'))

# Generated at 2022-06-24 21:46:46.437306
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [base_fact_collector_0],
                        'b': [base_fact_collector_0],
                        'c': [base_fact_collector_0]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['a'] == set()
    assert dep_map['b'] == set()
    assert dep_map['c'] == set()


# Generated at 2022-06-24 21:47:15.934331
# Unit test for function get_collector_names
def test_get_collector_names():
    # Retrieve module parameters
    gather_subset = ['all']
    # the list of everything that 'all' expands to
    valid_subsets = frozenset()
    # if provided, minimal_gather_subset is always added, even after all negations
    minimal_gather_subset = frozenset()

    aliases_map = defaultdict(set)

    # Call function
    result = get_collector_names(valid_subsets, minimal_gather_subset, gather_subset, aliases_map)

    # Check result
    assert result == frozenset()



# Generated at 2022-06-24 21:47:25.290330
# Unit test for function find_unresolved_requires

# Generated at 2022-06-24 21:47:31.906467
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['system', 'virtual']
    all_fact_subsets = {
        'system': [BaseFactCollector(), BaseFactCollector()],
        'virtual': [BaseFactCollector()]
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved


# Generated at 2022-06-24 21:47:39.485595
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1
    all_fact_subsets= {'collector0': [BaseFactCollector()], 'collector1': [BaseFactCollector()], 'collector2': [BaseFactCollector()],
                       'collector3': [BaseFactCollector()]}
    all_fact_subsets['collector0'][0].required_facts= set(['collector2','collector3','collector4'])
    all_fact_subsets['collector1'][0].required_facts= set(['collector4','collector5'])
    all_fact_subsets['collector2'][0].required_facts= set(['collector0','collector1'])

    # Test 1.1: all collectors have unresolved requires
    collector_names = ['collector0','collector1','collector2']
   

# Generated at 2022-06-24 21:47:45.671726
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Case 0:
    # 'system' is the only fact-collector we have, it requires 'os_version'
    #
    # Expected: ['os_version'] is returned
    class SystemFactCollector(BaseFactCollector):
        name = 'system'
        required_facts = set(['os_version'])

    all_fact_subsets = {'system': [SystemFactCollector]}

    collector_names = set(['system'])
    unresolved_requires = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved_requires == set(['os_version'])

    # Case 1:
    # 'system' is the only fact-collector we have, it requires 'os_version'
    # os_version is a fact-collector that requires 'os_name'
