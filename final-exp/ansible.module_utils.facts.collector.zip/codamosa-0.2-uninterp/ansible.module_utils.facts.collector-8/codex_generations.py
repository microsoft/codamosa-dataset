

# Generated at 2022-06-16 23:41:04.500813
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:41:16.249037
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ('test', 'test_alias')

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ('test2', 'test2_alias')

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = ('test3', 'test3_alias')


# Generated at 2022-06-16 23:41:24.691772
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network'])

    class Test2Collector(BaseFactCollector):
        name = 'test2'
        required_facts = set(['network'])

    class Test3Collector(BaseFactCollector):
        name = 'test3'
        required_facts = set(['network'])

    class Test4Collector(BaseFactCollector):
        name = 'test4'
        required_facts = set(['network', 'hardware'])


# Generated at 2022-06-16 23:41:35.363794
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:41:46.344336
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_fact_id5'])

# Generated at 2022-06-16 23:41:54.330066
# Unit test for function build_dep_data
def test_build_dep_data():
    # Test case 1
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector]
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    # Test case 2
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [BaseFactCollector],
        'b': [BaseFactCollector],
        'c': [BaseFactCollector]
    }

# Generated at 2022-06-16 23:42:01.282539
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'system': [SystemCollector],
        'network': [NetworkCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['system'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:42:11.783171
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'network']
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['network', 'min'])

    # Test with gather_subset=['!all', '!network']

# Generated at 2022-06-16 23:42:21.726983
# Unit test for function tsort
def test_tsort():
    dep_map = {'a': ['b'], 'b': ['c'], 'c': ['d'], 'd': ['e'], 'e': ['f'], 'f': ['g'], 'g': ['h'], 'h': ['i'], 'i': ['j'], 'j': ['k'], 'k': ['l'], 'l': ['m'], 'm': ['n'], 'n': ['o'], 'o': ['p'], 'p': ['q'], 'q': ['r'], 'r': ['s'], 's': ['t'], 't': ['u'], 'u': ['v'], 'v': ['w'], 'w': ['x'], 'x': ['y'], 'y': ['z'], 'z': ['a']}

# Generated at 2022-06-16 23:42:29.660385
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'


# Generated at 2022-06-16 23:42:53.449731
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.network
    import ansible.module_utils.facts.collectors.hardware
    import ansible.module_utils.facts.collectors.virtual
    import ansible.module_utils.facts.collectors.ohai
    import ansible.module_utils.facts.collectors.facter


# Generated at 2022-06-16 23:43:00.877808
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:43:06.316480
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all', 'network']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['network'] == set(['all'])
    assert dep_map['all'] == set()



# Generated at 2022-06-16 23:43:14.413940
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires'''
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])
    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])
    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

# Generated at 2022-06-16 23:43:24.028152
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import all_collector_classes
    from ansible.module_utils.facts.collectors.system import GenericCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts.collectors.virtual import VirtualCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionCollector

    collectors_for_platform = [GenericCollector, NetworkCollector, HardwareCollector, VirtualCollector, DistributionCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector

# Generated at 2022-06-16 23:43:36.413838
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:43:45.592584
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    # test that 'network' requires 'system'
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == {'system'}

    # test that 'network' does not require 'network'
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert 'network' not in unresolved

    # test that 'system' does not require 'network'
   

# Generated at 2022-06-16 23:43:57.170496
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    # test that we get all the collectors
    collector_names = ['a', 'b', 'c', 'd']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 4
    assert CollectorA

# Generated at 2022-06-16 23:44:09.693320
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_2'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:44:22.715476
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               aliases_map=defaultdict(set, hardware=['devices', 'dmi'])) == frozenset(['network', 'hardware', 'devices', 'dmi'])

# Generated at 2022-06-16 23:44:36.846009
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:44:49.531397
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {
    #       'a': [A],
    #       'b': [B],
    #       'c': [C],
    #   }
    #   A.required_facts = ['b']
    #   B.required_facts = ['c']
    #   C.required_facts = []
    #
    #   Should return an empty set
    class A(BaseFactCollector):
        name = 'a'
        required_facts = ['b']
    class B(BaseFactCollector):
        name = 'b'
        required_facts = ['c']
    class C(BaseFactCollector):
        name = 'c'
        required_facts = []

    collector_names

# Generated at 2022-06-16 23:44:59.442830
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test 1:
    #   collector_names = ['all']
    #   all_fact_subsets = {'all': [A, B, C, D]}
    #   expected_result = [A, B, C, D]
    all_fact_subsets = {'all': [A, B, C, D]}
    collector_names = ['all']
    expected_result = [A, B, C, D]
    assert select_collector_classes(collector_names, all_fact_subsets) == expected_result

    # Test 2:
    #   collector_names = ['all', 'A']
    #   all_fact_subsets = {'all': [A, B, C, D]}
    #   expected_result = [A, B, C, D]

# Generated at 2022-06-16 23:45:10.861744
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.collector.network.freebsd import FreebsdNetworkCollector
    from ansible.module_utils.facts.collector.network.netbsd import NetbsdNetworkCollector
    from ansible.module_utils.facts.collector.network.openbsd import OpenbsdNetworkCollector
    from ansible.module_utils.facts.collector.network.aix import AixNetworkCollector
    from ansible.module_utils.facts.collector.network.hpux import HPUXNetworkCollector
    from ansible.module_utils.facts.collector.network.sunos import SunOSNetworkCollector

# Generated at 2022-06-16 23:45:21.046240
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'all': [network.NetworkCollector],
        'network': [network.NetworkCollector],
    }

    assert find_unresolved_requires(['all'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'all'], all_fact_subsets) == set()
    assert find_unresolved_requires(['all', 'network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'all', 'network'], all_fact_subsets) == set()
    assert find_unresolved_requires

# Generated at 2022-06-16 23:45:34.009748
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.pip import PipCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'network'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'pip'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
       

# Generated at 2022-06-16 23:45:46.610582
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.file_system
    import ansible.module_utils.facts.collector.selinux
    import ansible.module_utils.facts.collector.cmdline
    import ansible.module_utils.facts.collector.system


# Generated at 2022-06-16 23:45:55.182545
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip3 import Pip3Collector
    from ansible.module_utils.facts.collector.pipenv import PipenvCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector

# Generated at 2022-06-16 23:46:05.364653
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
    }

    # test with no duplicates
    collector_names = ['network', 'hardware', 'system']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [NetworkCollector, HardwareCollector, SystemCollector]

    # test with duplicates

# Generated at 2022-06-16 23:46:16.962927
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set([]),
        'd': set(['c']),
        'e': set(['f']),
        'f': set(['g']),
        'g': set(['f']),
    }
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'tsort did not raise CycleFoundInFactDeps'

    # test a simple case
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
    }
    sorted_list = tsort(dep_map)

# Generated at 2022-06-16 23:46:35.855034
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()


# Generated at 2022-06-16 23:46:47.301670
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

    class G(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:46:57.294124
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
    }

    # test that 'network' requires 'system'
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['system'])

    # test that 'network' and 'system' require nothing
    collector_names = ['network', 'system']

# Generated at 2022-06-16 23:47:09.424334
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:47:18.913622
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:47:30.444458
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:47:42.302057
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:47:54.116085
# Unit test for function build_fact_id_to_collector_map

# Generated at 2022-06-16 23:48:05.046292
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
    class C(BaseFactCollector):
        name = 'c'
    class D(BaseFactCollector):
        name = 'd'
    class E(BaseFactCollector):
        name = 'e'

    all_fact_subsets = {
        'a': [A, B, C],
        'b': [B, C],
        'c': [C, D],
        'd': [D, E],
        'e': [E],
    }

    assert select_collector_classes(['a', 'b', 'c', 'd', 'e'], all_fact_subsets) == [A, B, C, D, E]
    assert select_collector

# Generated at 2022-06-16 23:48:13.438229
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['all'], minimal_gather_subset=['min']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['all'], minimal_gather_subset=['min'], valid_subsets=['all', 'min']) == frozenset(['all'])

    # Test with min
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['min'], minimal_gather_subset=['min']) == frozenset

# Generated at 2022-06-16 23:48:59.770790
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'system'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'test2'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = {'test3'}


# Generated at 2022-06-16 23:49:07.844221
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.mount import MountCollector

# Generated at 2022-06-16 23:49:20.258738
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()
    assert get_collector_names(gather_subset=['!all', 'min']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'min', '!min']) == frozenset()
    assert get_collector_names(gather_subset=['!all', 'min', '!min', 'min']) == frozenset(['min'])
    assert get_

# Generated at 2022-06-16 23:49:30.039396
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:49:40.860086
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = {'fact1', 'fact2'}

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = {'fact2', 'fact3'}

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = {'fact3', 'fact4'}

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = {'fact4', 'fact5'}

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = {'fact5', 'fact6'}


# Generated at 2022-06-16 23:49:51.562717
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.virtual


# Generated at 2022-06-16 23:50:03.575293
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['all']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], valid_subsets=['all', 'network']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_sub

# Generated at 2022-06-16 23:50:12.599173
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!hardware', 'network', 'devices'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None) == frozenset(['network', 'devices'])

    # Test with minimal options

# Generated at 2022-06-16 23:50:23.317949
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'foo': [object()],
        'bar': [object()],
        'baz': [object()],
        'qux': [object()],
    }
    all_fact_subsets['foo'][0].required_facts = set(['bar'])
    all_fact_subsets['bar'][0].required_facts = set(['baz'])
    all_fact_subsets['baz'][0].required_facts = set(['qux'])
    all_fact_subsets['qux'][0].required_facts = set(['quux'])

    assert find_unresolved_requires(['foo'], all_fact_subsets) == set(['quux'])

# Generated at 2022-06-16 23:50:31.318750
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_fact_subsets()
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter', 'puppet']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter', 'puppet', 'ohai']