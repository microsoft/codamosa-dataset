

# Generated at 2022-06-16 23:40:57.298150
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set()


# Generated at 2022-06-16 23:41:06.556164
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'network'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'network', 'test'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'test2'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'

# Generated at 2022-06-16 23:41:16.642729
# Unit test for function tsort
def test_tsort():
    test_dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set([]),
        'd': set(['c']),
    }
    expected_result = [
        ('c', set([])),
        ('b', set(['c'])),
        ('a', set(['b', 'c'])),
        ('d', set(['c'])),
    ]
    assert tsort(test_dep_map) == expected_result

    test_dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(['a']),
        'd': set(['c']),
    }

# Generated at 2022-06-16 23:41:27.992219
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
                               platform_info=None) == frozenset(['network', 'all'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:41:37.390620
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test4'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test5'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5', 'test6'])


# Generated at 2022-06-16 23:41:48.254199
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:41:55.269645
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_fact_id5'])

# Generated at 2022-06-16 23:42:01.950989
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:42:11.704393
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b']))]

    # Test a graph with a cycle
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set(['a'])}
    try:
        sorted_list = tsort(dep_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-16 23:42:21.642580
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # pylint: disable=unused-variable
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['C', 'B'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['C', 'B', 'A'])

    class CollectorF(BaseFactCollector):
        name = 'F'

# Generated at 2022-06-16 23:42:34.813087
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact2', 'fact3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact4', 'fact5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact5', 'fact6'])


# Generated at 2022-06-16 23:42:45.051058
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    dep_map = build_dep_data(['all'], all_fact_subsets)
    assert dep_map['all'] == set(['min'])
    assert dep_map['min'] == set()
    assert dep_map['network'] == set(['min'])
    assert dep_map['hardware'] == set(['min'])
    assert dep_map['virtual'] == set(['min'])
    assert dep_map['facter'] == set(['min'])
    assert dep_map['ohai'] == set(['min'])
    assert dep_map['puppet'] == set(['min'])
    assert dep_map['system'] == set(['min'])


# Generated at 2022-06-16 23:42:52.163064
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()


# Generated at 2022-06-16 23:43:04.037479
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'distribution': [DistributionCollector],
        'virtual': [VirtualCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware'], all_fact_subsets) == set()
    assert find_unresolved

# Generated at 2022-06-16 23:43:13.155820
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == set(['all'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', 'foo']) == set(['min', 'foo'])
    assert get_collector_names(gather_subset=['!all', '!foo']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', '!foo', 'bar']) == set(['min', 'bar'])
    assert get_collector_names(gather_subset=['!all', '!foo', '!bar']) == set(['min'])
    assert get_

# Generated at 2022-06-16 23:43:22.817549
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector


# Generated at 2022-06-16 23:43:35.182074
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'foo']) == frozenset(['min', 'foo'])
    assert get_collector_names(gather_subset=['!all', '!foo']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!foo', 'bar']) == frozenset(['min', 'bar'])
    assert get_collector_names(gather_subset=['!all', '!foo', '!bar']) == fro

# Generated at 2022-06-16 23:43:44.711251
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:43:49.428093
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_resources': [network.NetworkResourcesCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network_resources'], all_fact_subsets) == set(['network'])



# Generated at 2022-06-16 23:44:00.077554
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['network'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'

# Generated at 2022-06-16 23:44:15.776867
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no arguments
    assert get_collector_names() == frozenset()

    # Test with valid_subsets
    assert get_collector_names(valid_subsets=frozenset(['all'])) == frozenset(['all'])

    # Test with minimal_gather_subset
    assert get_collector_names(minimal_gather_subset=frozenset(['min'])) == frozenset(['min'])

    # Test with gather_subset
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with aliases_map
    assert get_collector_names(aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']})) == frozenset()

   

# Generated at 2022-06-16 23:44:26.901769
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set()
        raise KeyError('collector_name')

    unresolved = find_unresolved_requires(['a'], all_fact_subsets, _get_requires_by_collector_name)

# Generated at 2022-06-16 23:44:34.938908
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:44:48.336423
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all']), gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(valid_subsets=frozenset(['all']), gather_subset=['!all']) == frozenset()

    # Test with gather_subset=['!all', 'all']

# Generated at 2022-06-16 23:44:58.492634
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1', 'test_fact_id_2'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3', 'test_fact_id_4'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_5', 'test_fact_id_6'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_7', 'test_fact_id_8'])

# Generated at 2022-06-16 23:45:10.175791
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = set(['d', 'e'])
    all_fact_subsets['c'][0].required_facts = set(['f'])
    all_fact_subsets['d'][0].required_facts = set()
    all_fact_subsets['e'][0].required_facts = set()
    all_fact_subsets['f'][0].required

# Generated at 2022-06-16 23:45:20.662485
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=all
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=!all
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=!all,!min
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=!all,!min,min

# Generated at 2022-06-16 23:45:33.634288
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all'],
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                               platform_info=None) == frozenset(['network'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:45:46.314201
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact2'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact3'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact4'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact5'])

    class Collector6(BaseFactCollector):
        name = 'collector6'

# Generated at 2022-06-16 23:45:54.990361
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': []})
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': []})
    assert dep_map == {'a': set(), 'b': set(), 'c': set(), 'd': set()}

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': [], 'e': []})

# Generated at 2022-06-16 23:46:20.421067
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # a requires b
    _get_requires_by_collector_name('a', all_fact_subsets).add('b')

    # b requires c
    _get_requires_by_collector_name('b', all_fact_subsets).add('c')

    # c requires d
    _get_requires_by_collector_name('c', all_fact_subsets).add('d')

    # d requires a
    _get_requires_by_collector_name('d', all_fact_subsets).add('a')

    # a, b, c, d are all in the list of collector names


# Generated at 2022-06-16 23:46:32.297587
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['system'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])


# Generated at 2022-06-16 23:46:41.275081
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'system': [SystemCollector],
        'network': [NetworkCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['system'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:46:53.929479
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:47:06.331333
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])

    class CollectorG(BaseFactCollector):
        name = 'g'
       

# Generated at 2022-06-16 23:47:16.708724
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
    }

    # no unresolved requires
    collector_names = ['network', 'system']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = ['network', 'virtual']
    assert find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:47:24.725255
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=[]) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collect

# Generated at 2022-06-16 23:47:36.087308
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])
    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])
    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    collectors_for_platform = [Collector1, Collector2, Collector3]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert len(fact_id_to_collector_map) == 6

# Generated at 2022-06-16 23:47:45.888322
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1', 'test1_alias'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test2_alias'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3', 'test3_alias'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4', 'test4_alias'}

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = {'test5', 'test5_alias'}

# Generated at 2022-06-16 23:47:57.581691
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        name = 'collector2'
    class Collector3(BaseFactCollector):
        name = 'collector3'
    class Collector4(BaseFactCollector):
        name = 'collector4'
    class Collector5(BaseFactCollector):
        name = 'collector5'
    class Collector6(BaseFactCollector):
        name = 'collector6'


# Generated at 2022-06-16 23:48:31.176806
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import Pip3Collector
    from ansible.module_utils.facts.collector.pip import Pip2Collector

# Generated at 2022-06-16 23:48:40.268177
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])
    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])
    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()

    all_fact

# Generated at 2022-06-16 23:48:53.017320
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    def _get_requires_by_collector_name(collector_name):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set()
        raise ValueError('unknown collector name %s' % collector_name)

    unresolved = find_unresolved_requires(['a', 'b', 'c', 'd'], all_fact_subsets)
    assert not unresolved

   

# Generated at 2022-06-16 23:49:03.792809
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=all
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=min
    assert get_collector_names(gather_subset=['min']) == frozenset()

    # Test with gather_subset=!all
    assert get_collector_names(gather_subset=['!all']) == frozenset()

    # Test with gather_subset=!min
    assert get_collector_names(gather_subset=['!min']) == frozenset()

    # Test with gather_subset=!min,!all

# Generated at 2022-06-16 23:49:14.864112
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_resources': [network.NetworkResourcesCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = ['network_resources']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'network'}

    # no unresolved requires
    collector_names = ['network', 'network_resources']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()



# Generated at 2022-06-16 23:49:26.834381
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['id1', 'id2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['id2', 'id3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['id3', 'id4'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['id4', 'id5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['id5', 'id6'])


# Generated at 2022-06-16 23:49:33.381080
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['platform'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['platform'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])


# Generated at 2022-06-16 23:49:39.876040
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import hardware
    from ansible.module_utils.facts.collectors import virtual
    from ansible.module_utils.facts.collectors import default

    collectors_for_platform = [network.NetworkCollector, hardware.HardwareCollector, virtual.VirtualCollector, default.DefaultCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [network.NetworkCollector]
    assert fact_id_to_collector_map['hardware'] == [hardware.HardwareCollector]
    assert fact_id_to_collector_map['virtual']

# Generated at 2022-06-16 23:49:50.719600
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set()

    all_fact_subsets = {
        'a': [A],
        'b': [B],
        'c': [C],
        'd': [D],
        'e': [E],
    }

    assert find_unresolved_requires

# Generated at 2022-06-16 23:50:01.265620
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1_1', 'collector1_2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2_1', 'collector2_2'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3_1', 'collector3_2'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4_1', 'collector4_2'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact