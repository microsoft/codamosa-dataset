

# Generated at 2022-06-16 23:40:46.434325
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    # test without namespace
    c = TestCollector()
    assert c.collect_with_namespace() == {'foo': 'bar'}

    # test with namespace
    class TestNamespace:
        def transform(self, key_name):
            return 'test_' + key_name

    c = TestCollector(namespace=TestNamespace())
    assert c.collect_with_namespace() == {'test_foo': 'bar'}



# Generated at 2022-06-16 23:40:57.386604
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:41:06.614996
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.config import ConfigCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

# Generated at 2022-06-16 23:41:16.673017
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == {'all'}

    # Test with gather_subset=['all', 'network']
    assert get_collector_names(gather_subset=['all', 'network']) == {'all', 'network'}

    # Test with gather_subset=['all', 'network', '!all']
    assert get_collector_names(gather_subset=['all', 'network', '!all']) == {'network'}

    # Test with gather_subset=['all', 'network', '!all', '!network']
    assert get_collector_names(gather_subset=['all', 'network', '!all', '!network']) == set()

   

# Generated at 2022-06-16 23:41:27.189320
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'min']

# Generated at 2022-06-16 23:41:37.340381
# Unit test for function build_fact_id_to_collector_map

# Generated at 2022-06-16 23:41:48.202408
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'system'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'virtual'], all_fact_subsets) == {'system'}

# Generated at 2022-06-16 23:41:54.211005
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    # test with no namespace
    collector = TestCollector()
    assert collector.collect_with_namespace() == {'test': 'test'}

    # test with namespace
    class TestNamespace:
        def transform(self, key_name):
            return 'test_' + key_name

    collector = TestCollector(namespace=TestNamespace())
    assert collector.collect_with_namespace() == {'test_test': 'test'}



# Generated at 2022-06-16 23:41:57.605148
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    test_collector = TestCollector()
    assert test_collector.collect_with_namespace() == {'test': 'test'}



# Generated at 2022-06-16 23:42:04.523280
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:42:27.760347
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                               platform_info=None) == frozenset(['all', 'network', 'hardware'])

    # Test with minimal_gather_subset

# Generated at 2022-06-16 23:42:40.545400
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', 'min']
    assert get_collector_names(gather_subset=['all', '!min', 'min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', 'min', '!all

# Generated at 2022-06-16 23:42:49.804420
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        gather_subset=['all'],
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['min']),
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
    ) == frozenset(['all', 'network', 'hardware'])


# Generated at 2022-06-16 23:42:57.438394
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:43:07.202174
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['A'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['A'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['A'])

    class CollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:43:19.429820
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:43:31.654187
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:43:42.312951
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:43:50.283129
# Unit test for function collector_classes_from_gather_subset

# Generated at 2022-06-16 23:44:00.797495
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=['all', 'network', 'hardware'],
                               minimal_gather_subset=['min'],
                               gather_subset=['all'],
                               aliases_map={'hardware': ['devices', 'dmi']},
                               platform_info={'system': 'Linux'}) == {'all', 'network', 'hardware', 'min'}

    assert get_collector_names(valid_subsets=['all', 'network', 'hardware'],
                               minimal_gather_subset=['min'],
                               gather_subset=['!all'],
                               aliases_map={'hardware': ['devices', 'dmi']},
                               platform_info={'system': 'Linux'}) == {'min'}

    assert get_

# Generated at 2022-06-16 23:44:23.837050
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['system'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:44:33.046729
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_id']
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test_id2']
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = ['test_id3']
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = ['test_id4']
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = ['test_id5']
        name = 'test_collector5'

    class TestCollector6(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:44:46.648454
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])


# Generated at 2022-06-16 23:44:57.096230
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    assert dep_map['network'] == set()
    assert dep_map['hardware'] == set()
    assert dep_map['virtual'] == set()
    assert dep_map['facter'] == set()
    assert dep_map['ohai'] == set()
    assert dep_map['system'] == set()
    assert dep_map['pkg_mgr'] == set()
    assert dep_map['min'] == set()
    assert dep_map['identity'] == set()

# Generated at 2022-06-16 23:45:09.147703
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {'a': [A], 'b': [B], 'c': [C]}
    #   where A.required_facts = set(['b'])
    #        B.required_facts = set(['c'])
    #        C.required_facts = set(['d'])
    #   expected result: set(['d'])
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class C(BaseFactCollector):
        name = 'c'

# Generated at 2022-06-16 23:45:19.941372
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact2', 'fact3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact4', 'fact5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact5', 'fact6'])


# Generated at 2022-06-16 23:45:32.816949
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:45:46.223826
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = set(['f'])


# Generated at 2022-06-16 23:45:54.885634
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with empty collector_names
    assert find_unresolved_requires(collector_names=[], all_fact_subsets={}) == set()

    # Test with collector_names that have no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(name='a', required_facts=set())],
        'b': [MockCollector(name='b', required_facts=set())],
        'c': [MockCollector(name='c', required_facts=set())],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with collector_names that have unresolved requires
    collector_names = ['a', 'b', 'c']
    all

# Generated at 2022-06-16 23:46:04.995234
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['e', 'f'])
        if collector_name == 'd':
            return set(['f'])
        if collector_name == 'e':
            return set(['f'])

# Generated at 2022-06-16 23:46:22.258941
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set()

    unresolved = find_unresolved_requires(['a'], all_fact_subsets)
    assert unresolved == set()


# Generated at 2022-06-16 23:46:33.707027
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector

# Generated at 2022-06-16 23:46:41.926169
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    # create a fake collector that requires 'foo'
    class FakeCollector(collector.BaseFactCollector):
        name = 'bar'
        required_facts = set(['foo'])

    # create a fake collector that requires 'bar'
    class FakeCollector2(collector.BaseFactCollector):
        name = 'baz'
        required_facts = set(['bar'])

    # create a fake collector that requires 'baz'
    class FakeCollector3(collector.BaseFactCollector):
        name = 'qux'
        required_facts = set(['baz'])

    # create a fake collector that requires 'qux'
    class FakeCollector4(collector.BaseFactCollector):
        name = 'quux'

# Generated at 2022-06-16 23:46:54.359582
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }


# Generated at 2022-06-16 23:47:06.383840
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'virtual': [VirtualCollector],
        'system': [SystemCollector],
        'distribution': [DistributionCollector],
    }

    # Test that a collector with no requires returns no unresolved requires
    collector_names = ['network']
    unresolved = find_unresolved

# Generated at 2022-06-16 23:47:16.781074
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        required_facts = set(['a', 'b'])

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        required_facts = set(['b', 'c'])

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        required_facts = set(['c', 'd'])

    all_fact_subsets = {
        'test': [TestCollector],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

    collector_names = ['test', 'test2', 'test3']

    dep_map = build_

# Generated at 2022-06-16 23:47:24.744054
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])
    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d', 'b'])
    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])
   

# Generated at 2022-06-16 23:47:36.125817
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    all_fact_subsets = {
        'collector1': [Collector1],
        'collector2': [Collector2],
        'collector3': [Collector3],
    }
    collector_names = ['collector1', 'collector2', 'collector3']
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:47:45.918515
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d', 'a'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e', 'b'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:47:57.582037
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import all_collector_classes
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionCollector

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        required_facts = set(['network'])

    class FakeCollector2(BaseFactCollector):
        name = 'fake2'
        required_facts = set(['network', 'hardware'])

    class FakeCollector3(BaseFactCollector):
        name = 'fake3'
        required_facts = set

# Generated at 2022-06-16 23:48:40.043176
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:48:52.749061
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    import pytest
    all_fact_subsets = {'test_collector': [collector.BaseFactCollector]}
    collector_names = ['test_collector']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'test_collector': set()}
    all_fact_subsets = {'test_collector': [collector.BaseFactCollector]}
    collector_names = ['test_collector']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'test_collector': set()}
    all_fact_subsets = {'test_collector': [collector.BaseFactCollector]}


# Generated at 2022-06-16 23:49:03.577735
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        name = 'test_collector1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_collector4'])
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_collector5'])

# Generated at 2022-06-16 23:49:15.184531
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = ['network']

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = ['hardware']

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = ['network', 'hardware']

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = ['test2']


# Generated at 2022-06-16 23:49:27.059322
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

# Generated at 2022-06-16 23:49:33.487155
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:49:40.020903
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:49:50.840814
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:50:01.407225
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:50:11.883081
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['a', 'b'])
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['a', 'b'])
    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['a', 'b'])
    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['a', 'b'])
    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['a', 'b'])