

# Generated at 2022-06-16 23:40:57.209360
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['A', 'B'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['B', 'C'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

    class CollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:41:06.988859
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:41:16.996600
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test1'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test2'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['test3', 'test4'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'
        required_facts = set(['test5'])

   

# Generated at 2022-06-16 23:41:27.591765
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    all_fact_subsets['a'][0].required_facts = set(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = set(['c'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set()

    assert find_unresolved_requires(set(['a']), all_fact_subsets) == set()
    assert find_unresolved_requires(set(['a', 'b']), all_fact_subsets) == set

# Generated at 2022-06-16 23:41:37.367871
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    # Test a simple case
    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test a case where there is a missing required fact
    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['c'])

    # Test a case where there is a missing required fact, but it is
    # not in

# Generated at 2022-06-16 23:41:48.253319
# Unit test for function tsort
def test_tsort():
    test_data = {
        'a': {'b', 'c'},
        'b': {'c', 'd'},
        'c': {'d'},
        'd': set(),
    }
    assert tsort(test_data) == [('d', set()), ('c', {'d'}), ('b', {'c', 'd'}), ('a', {'b', 'c'})]

    test_data = {
        'a': {'b', 'c'},
        'b': {'c', 'd'},
        'c': {'d'},
        'd': {'a'},
    }

# Generated at 2022-06-16 23:41:55.291058
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['e']),
        'e': set(['f']),
        'f': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [
        ('f', set([])),
        ('e', set(['f'])),
        ('d', set(['e'])),
        ('c', set(['d'])),
        ('b', set(['c'])),
        ('a', set(['b'])),
    ]

    # Test a graph with a cycle

# Generated at 2022-06-16 23:42:06.105654
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class DummyCollector(BaseFactCollector):
        name = 'dummy'
        required_facts = set()

    class DummyCollector2(BaseFactCollector):
        name = 'dummy2'
        required_facts = set()

    class DummyCollector3(BaseFactCollector):
        name = 'dummy3'
        required_facts = set()

    class DummyCollector4(BaseFactCollector):
        name = 'dummy4'
        required_facts

# Generated at 2022-06-16 23:42:16.275275
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = ('test1', 'test1_alias')

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ('test2', 'test2_alias')

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = ('test3', 'test3_alias')

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = ('test4', 'test4_alias')

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = ('test5', 'test5_alias')


# Generated at 2022-06-16 23:42:24.645464
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['!all'],
                               valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network'])

    assert get_collector_names(gather_subset=['!all', 'network'],
                               valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network'])


# Generated at 2022-06-16 23:42:41.116822
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['a', 'b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b', 'c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['a', 'b', 'c', 'd'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:42:50.184463
# Unit test for function tsort

# Generated at 2022-06-16 23:42:57.557098
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with all defaults
    assert get_collector_names() == frozenset(['all'])
    # test with all defaults, but gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])
    # test with all defaults, but gather_subset=['!network']
    assert get_collector_names(gather_subset=['!network']) == frozenset(['all'])
    # test with all defaults, but gather_subset=['!network', 'network']
    assert get_collector_names(gather_subset=['!network', 'network']) == frozenset(['network'])
    # test with all defaults, but gather_subset=['!network', '!network']
    assert get

# Generated at 2022-06-16 23:43:08.702672
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'virtual': [VirtualCollector],
        'system': [SystemCollector],
    }

    # no unresolved requires
    collector_names = ['network', 'hardware', 'virtual', 'system']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # unresolved requires

# Generated at 2022-06-16 23:43:19.582066
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_collector'])
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_collector4'])
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:43:25.814155
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': []})
    assert dep_map == defaultdict(set, {'a': set(), 'b': set(), 'c': set()})

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': []})
    assert dep_map == defaultdict(set, {'a': set(), 'b': set(), 'c': set(), 'd': set()})

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': [], 'e': []})
    assert dep_map == default

# Generated at 2022-06-16 23:43:35.854672
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector

    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert 'all' in dep_map
    assert 'system' in dep_map['all']
    assert 'network' in dep_map['all']
    assert 'virtual' in dep_map['all']
    assert 'facter' in dep_map['all']
    assert 'ohai' in dep_map['all']



# Generated at 2022-06-16 23:43:45.226939
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'network']
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['min', 'network'])

    # Test with gather_subset=['!all', '!network']

# Generated at 2022-06-16 23:43:52.448323
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_fact_id5'])

# Generated at 2022-06-16 23:44:02.317459
# Unit test for function tsort
def test_tsort():
    # Test case 1
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('d', set([])), ('c', set(['d'])), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test case 2
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['a']),
    }

# Generated at 2022-06-16 23:44:23.761082
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    # test with a single collector
    class TestCollector(BaseFactCollector):
        name = 'test'

    collector_classes = collector_classes_from_gather_subset(all_collector_classes=[TestCollector],
                                                             valid_subsets=frozenset(['test']),
                                                             minimal_gather_subset=frozenset(['test']),
                                                             gather_subset=['test'],
                                                             gather_timeout=None,
                                                             platform_info={'system': 'Generic'})
    assert collector_classes == [TestCollector]

    # test with a single collector, with a gather_subset of 'all'

# Generated at 2022-06-16 23:44:31.095352
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_resources': [network.NetworkResourcesCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = ['network_resources']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'network'}



# Generated at 2022-06-16 23:44:37.100178
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
    }

    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['c'])

    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved

# Generated at 2022-06-16 23:44:49.671480
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'min']

# Generated at 2022-06-16 23:44:59.511619
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'virtual': [VirtualCollector],
        'system': [SystemCollector],
        'distribution': [DistributionCollector],
    }

    # test that a collector with no requires returns nothing
    collector_names = ['network']
    unresolved = find_unresolved_requires

# Generated at 2022-06-16 23:45:10.927742
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import PipCollector

# Generated at 2022-06-16 23:45:21.074145
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:45:34.022136
# Unit test for function tsort

# Generated at 2022-06-16 23:45:46.611356
# Unit test for function tsort

# Generated at 2022-06-16 23:45:55.183472
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact2', 'fact3'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact3', 'fact4'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact4', 'fact5'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['fact5', 'fact6'])
        name = 'collector5'


# Generated at 2022-06-16 23:46:14.973460
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import all_collector_classes
    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    # test that a collector with no requires returns no unresolved
    collector_names = ['system']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test that a collector with requires returns the requires
    collector_names = ['distribution']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert 'system' in unresolved

    # test that a collector with requires returns the requires

# Generated at 2022-06-16 23:46:28.938353
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()


# Generated at 2022-06-16 23:46:36.844696
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['hardware'], all_fact_subsets) == set()
    assert find_unresolved_requires(['system'], all_fact_subsets) == set()


# Generated at 2022-06-16 23:46:49.754206
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
    }

    # test that NetworkCollector.requires_facts is resolved
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test that NetworkCollector.requires_facts is not resolved
    collector_names = ['network', 'hardware']

# Generated at 2022-06-16 23:46:58.529148
# Unit test for function tsort
def test_tsort():
    assert tsort({'a': ['b'], 'b': ['c'], 'c': []}) == [('c', set()), ('b', {'c'}), ('a', {'b'})]
    assert tsort({'a': ['b'], 'b': ['c'], 'c': ['a']}) == [('c', {'a'}), ('b', {'c'}), ('a', {'b'})]
    assert tsort({'a': ['b'], 'b': ['c'], 'c': ['d'], 'd': ['a']}) == [('d', {'a'}), ('c', {'d'}), ('b', {'c'}), ('a', {'b'})]

# Generated at 2022-06-16 23:47:10.927020
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:47:20.047098
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['foo', 'bar']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['foo', 'bar']) == frozenset(['foo', 'bar'])

    # Test with gather_subset=['foo', 'bar'], valid_subsets=['foo', 'bar']

# Generated at 2022-06-16 23:47:31.286690
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:47:42.804038
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set()

    all_fact_subsets = {
        'a': [A],
        'b': [B],
        'c': [C],
        'd': [D],
        'e': [E],
    }

    assert find_un

# Generated at 2022-06-16 23:47:54.948913
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:48:12.725957
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test1', 'test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test3', 'test4'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test5', 'test6'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test7', 'test8'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test9', 'test10'])


# Generated at 2022-06-16 23:48:20.475051
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    class MockCollector:
        required_facts = set()

    class MockCollectorA(MockCollector):
        name = 'a'
        required_facts = {'b'}

    class MockCollectorB(MockCollector):
        name = 'b'
        required_facts = {'c'}

    class MockCollectorC(MockCollector):
        name = 'c'
        required_facts = {'d'}

    class MockCollectorD(MockCollector):
        name = 'd'
        required_facts = set()


# Generated at 2022-06-16 23:48:32.748933
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
    }

    dep_map = build_dep_data(['a', 'b', 'c'], all_fact_subsets)
    assert dep_map['a'] == set(['b'])
    assert dep_map['b'] == set(['c'])

# Generated at 2022-06-16 23:48:39.046558
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
    }

    # Test with no unresolved requires
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test with unresolved requires
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved



# Generated at 2022-06-16 23:48:52.363921
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:49:03.312481
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']})
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']})
        ],
        'c': [
            type('c', (object,), {'required_facts': []})
        ]
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:49:14.740685
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['system'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:49:26.738299
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.collector.system.linux import LinuxSystemCollector
    from ansible.module_utils.facts.collector.network.bsd import BSDNetworkCollector
    from ansible.module_utils.facts.collector.system.bsd import BSDSystemCollector
    from ansible.module_utils.facts.collector.network.windows import WindowsNetworkCollector
    from ansible.module_utils.facts.collector.system.windows import Windows

# Generated at 2022-06-16 23:49:33.333944
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['a', 'b', 'c'])

    class CollectorF(BaseFactCollector):
        name = 'f'


# Generated at 2022-06-16 23:49:43.558712
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a'])

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b'])
   

# Generated at 2022-06-16 23:50:11.091695
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test'], all_fact_subsets) == set(['system'])

# Generated at 2022-06-16 23:50:17.670837
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
    }

    collector_names = ['a', 'b']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['c'])

    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved

# Generated at 2022-06-16 23:50:28.036656
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['collector5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = set(['collector6'])

    class Collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = set()
