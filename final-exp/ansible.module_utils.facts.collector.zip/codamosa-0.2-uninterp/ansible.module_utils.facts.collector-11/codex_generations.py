

# Generated at 2022-06-16 23:40:55.819285
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5', 'test5_alias'])


# Generated at 2022-06-16 23:41:06.988701
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['network', 'min'])
    assert get_collector_names(gather_subset=['!network']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!network', '!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!network', '!all', 'network']) == frozenset(['network', 'min'])


# Generated at 2022-06-16 23:41:14.488836
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])

    class CollectorG(BaseFactCollector):
        name = 'g'
       

# Generated at 2022-06-16 23:41:23.421132
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'platform': [PlatformCollector],
        'system': [SystemCollector],
    }

    # NetworkCollector requires 'platform'
    # PlatformCollector requires 'system'
    # SystemCollector requires nothing

    # Test 1:
    #   collector_names = ['network']
    #   expected_unresolved = ['platform']
    collector_names = ['network']
    expected_unresolved = ['platform']

# Generated at 2022-06-16 23:41:30.466418
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('d', set()), ('c', set(['d'])), ('b', set(['c'])), ('a', set(['b']))]

    # Test a graph with a cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['a']),
    }

# Generated at 2022-06-16 23:41:42.788105
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_classes()
    collector_names = ['all']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    collector_names = ['all', 'network', '!network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    collector_names = ['all', 'network', '!network', '!all']
    unresolved = find_un

# Generated at 2022-06-16 23:41:49.429787
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    collectors_for_platform = [NetworkCollector, HardwareCollector, SystemCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'][0] == NetworkCollector
    assert fact_id_to_collector_map['hardware'][0] == HardwareCollector
    assert fact_id_to_collector_map['system'][0] == SystemCollector

    assert aliases_map['network'] == set

# Generated at 2022-06-16 23:42:00.254519
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:42:11.348085
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', '!network']
    assert get_collector_names(gather_subset=['all', '!min', '!network']) == frozenset(['all', 'network'])

    # Test with gather_subset=['all', '!min', '

# Generated at 2022-06-16 23:42:21.345952
# Unit test for function tsort
def test_tsort():
    # Test for cycle
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': {'a'}}
    try:
        tsort(dep_map)
        assert False, 'Expected CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass

    # Test for simple sort
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': {'d'}, 'd': {'e'}, 'e': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('e', set()), ('d', {'e'}), ('c', {'d'}), ('b', {'c'}), ('a', {'b'})]

    # Test for sort with

# Generated at 2022-06-16 23:42:34.862652
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    # test that a missing required fact is found
    collector_names = ['a']
    unresolved = find_unresolved_requires

# Generated at 2022-06-16 23:42:44.916670
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import (
        BaseFactCollector,
        NetworkFactCollector,
        HardwareFactCollector,
        DMIHardwareFactCollector,
        LinuxHardwareFactCollector,
        LinuxDistributionFactCollector,
        VirtualizationFactCollector,
    )

    all_collector_classes = [
        NetworkFactCollector,
        HardwareFactCollector,
        DMIHardwareFactCollector,
        LinuxHardwareFactCollector,
        LinuxDistributionFactCollector,
        VirtualizationFactCollector,
    ]

    # create a fake platform info
    compat_platforms = [
        {'system': 'Linux', 'distribution': 'CentOS'},
        {'system': 'Linux'},
        {'system': 'Generic'},
    ]


# Generated at 2022-06-16 23:42:52.063975
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'collector_a': [object()],
        'collector_b': [object()],
        'collector_c': [object()],
        'collector_d': [object()],
        'collector_e': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'collector_a':
            return set(['collector_b', 'collector_c'])
        if collector_name == 'collector_b':
            return set(['collector_c', 'collector_d'])
        if collector_name == 'collector_c':
            return set(['collector_d'])

# Generated at 2022-06-16 23:43:03.995129
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'system', 'test'}

    all_fact_subsets = {
        'system': [SystemCollector],
        'network': [NetworkCollector],
        'test': [TestCollector],
        'test2': [TestCollector2],
    }


# Generated at 2022-06-16 23:43:13.116541
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _platform = 'Generic'

    class CollectorB(BaseFactCollector):
        name = 'B'
        _platform = 'Generic'

    class CollectorC(BaseFactCollector):
        name = 'C'
        _platform = 'Generic'

    class CollectorD(BaseFactCollector):
        name = 'D'
        _platform = 'Generic'

    class CollectorE(BaseFactCollector):
        name = 'E'
        _platform = 'Generic'

    class CollectorF(BaseFactCollector):
        name = 'F'
        _platform = 'Generic'

    class CollectorG(BaseFactCollector):
        name = 'G'
        _platform = 'Generic'

    class CollectorH(BaseFactCollector):
        name = 'H'

# Generated at 2022-06-16 23:43:20.548242
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set(['system'])
    assert find_unresolved_requires(['system'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['network', 'system'], all_fact_subsets) == set()



# Generated at 2022-06-16 23:43:33.493133
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()


# Generated at 2022-06-16 23:43:41.922259
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no arguments
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['!network']

# Generated at 2022-06-16 23:43:54.434587
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:44:01.332525
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {}

   

# Generated at 2022-06-16 23:44:23.749553
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

    class CollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:44:33.010415
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_all': [network.NetworkAllCollector],
        'network_gather_subset': [network.NetworkGatherSubsetCollector],
        'network_min': [network.NetworkMinCollector],
    }

    # no unresolved requires
    collector_names = ['network_all']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # no unresolved requires
    collector_names = ['network_all', 'network_min']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # no unresolved requires

# Generated at 2022-06-16 23:44:46.593977
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all defaults
    assert get_collector_names() == frozenset(['all'])
    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])
    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])
    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:44:57.048167
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [], 'b': [], 'c': []}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    class CollectorA:
        required_facts = set()
    class CollectorB:
        required_facts = set(['a'])
    class CollectorC:
        required_facts = set(['b'])
    class CollectorD:
        required_facts = set(['c'])
    class CollectorE:
        required_facts = set(['d', 'a'])


# Generated at 2022-06-16 23:45:09.061478
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'collector1'

    class Collector2(BaseFactCollector):
        name = 'collector2'

    class Collector3(BaseFactCollector):
        name = 'collector3'

    class Collector4(BaseFactCollector):
        name = 'collector4'

    class Collector5(BaseFactCollector):
        name = 'collector5'

    class Collector6(BaseFactCollector):
        name = 'collector6'

    class Collector7(BaseFactCollector):
        name = 'collector7'

    class Collector8(BaseFactCollector):
        name = 'collector8'

    class Collector9(BaseFactCollector):
        name = 'collector9'

    class Collector10(BaseFactCollector):
        name = 'collector10'

# Generated at 2022-06-16 23:45:19.858221
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = frozenset(['network', 'system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    collector_names = ['network', 'test']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:45:32.817130
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!network']
    assert get_collector_names(gather_subset=['all', '!network']) == frozenset(['all', '!network'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['!network']

# Generated at 2022-06-16 23:45:46.225341
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:45:53.988276
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['min', 'network'])
    assert get_collector_names(gather_subset=['!all', '!network']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network']) == frozenset(['min', 'network'])

# Generated at 2022-06-16 23:46:03.874114
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!network']

# Generated at 2022-06-16 23:46:32.251059
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1', 'test_fact_id_2'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_5'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:46:41.062578
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = frozenset(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'test': [TestCollector],
    }

    # test that an unresolved require raises an error
    collector_names = ['test']

# Generated at 2022-06-16 23:46:53.730862
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.system import SystemCollector
    from ansible.module_utils.facts.collectors.virtual import VirtualCollector

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])


# Generated at 2022-06-16 23:47:06.256604
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # unresolved requires
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # no unresolved requires
    collector_names = ['network', 'system']

# Generated at 2022-06-16 23:47:16.664118
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:47:28.016160
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class G(BaseFactCollector):
        name = 'g'
        required_facts = set(['f'])



# Generated at 2022-06-16 23:47:37.574855
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'all': [network.NetworkCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'all'], all_fact_subsets) == set()
    assert find_unresolved_requires(['all'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'all', 'foo'], all_fact_subsets) == set(['foo'])



# Generated at 2022-06-16 23:47:46.793156
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['min']),
                               aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
                               platform_info=None) == frozenset(['all', 'network'])

    # Test with no options

# Generated at 2022-06-16 23:47:58.644957
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineCollector


# Generated at 2022-06-16 23:48:08.395897
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _platform = 'Linux'

    class CollectorB(BaseFactCollector):
        name = 'b'
        _platform = 'Linux'

    class CollectorC(BaseFactCollector):
        name = 'c'
        _platform = 'Darwin'

    class CollectorD(BaseFactCollector):
        name = 'd'
        _platform = 'Generic'

    class CollectorE(BaseFactCollector):
        name = 'e'
        _platform = 'Generic'

    class CollectorF(BaseFactCollector):
        name = 'f'
        _platform = 'Generic'

    class CollectorG(BaseFactCollector):
        name = 'g'
        _platform = 'Generic'


# Generated at 2022-06-16 23:48:49.097546
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()

    all_fact_subsets = {
        'test': [TestCollector],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set(['test2', 'test3'])

# Generated at 2022-06-16 23:49:00.780556
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['network', 'min'])
    assert get_collector_names(gather_subset=['!all', '!network']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network']) == frozenset(['network', 'min'])
    assert get_collector_names(gather_subset=['!all', '!network', '!min']) == frozenset()

# Generated at 2022-06-16 23:49:08.397456
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a', 'b'])
    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['a', 'b', 'c'])


# Generated at 2022-06-16 23:49:20.904302
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
    }

    # no requires
    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one requires
    collector_names = ['a', 'b', 'c', 'd']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # one requires, one missing
    collector_names = ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-16 23:49:30.434626
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = frozenset(['network', 'hardware'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'test'], all_fact_subsets) == set()
    assert find

# Generated at 2022-06-16 23:49:41.025638
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['a1', 'a2'])
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['b1', 'b2'])
        name = 'b'

    class CollectorC(BaseFactCollector):
        _fact_ids = set(['c1', 'c2'])
        name = 'c'

    class CollectorD(BaseFactCollector):
        _fact_ids = set(['d1', 'd2'])
        name = 'd'

    class CollectorE(BaseFactCollector):
        _fact_ids = set(['e1', 'e2'])
        name = 'e'


# Generated at 2022-06-16 23:49:51.743499
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PackageManagerCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:50:03.837551
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([CollectorA, CollectorB, CollectorC])

    assert fact_id_to_collector_map['a'] == [CollectorA]
    assert fact_id_to_collector_map['b'] == [CollectorA, CollectorB]
    assert fact_id_to_collector

# Generated at 2022-06-16 23:50:12.816203
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Unit test for function find_unresolved_requires'''
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])


# Generated at 2022-06-16 23:50:23.359116
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set()
