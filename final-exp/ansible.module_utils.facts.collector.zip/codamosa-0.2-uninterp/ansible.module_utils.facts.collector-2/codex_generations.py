

# Generated at 2022-06-16 23:40:49.016652
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = ['a1', 'a2']

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = ['b1', 'b2']

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = ['c1', 'c2']

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = ['d1', 'd2']

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = ['e1', 'e2']

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = ['f1', 'f2']

   

# Generated at 2022-06-16 23:41:01.554169
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['hardware'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware'], all_fact_subsets) == set()
    assert find_unresolved_requires(['hardware', 'network'], all_fact_subsets) == set()

    # hardware requires network, so this should fail
    assert find_

# Generated at 2022-06-16 23:41:07.750063
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:41:17.043382
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact3', 'fact4'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact5', 'fact6'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact7', 'fact8'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['fact9', 'fact10'])
        name = 'collector5'


# Generated at 2022-06-16 23:41:27.670359
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = set(['A', 'B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = set(['B', 'C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = set(['C', 'D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = set(['D'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = set(['E'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        _fact_ids = set(['F'])


# Generated at 2022-06-16 23:41:39.564886
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_fact_id5'])

# Generated at 2022-06-16 23:41:48.431316
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = None
        required_facts = set()

    class TestCollector1(TestCollector):
        _platform = 'Linux'
        name = 'test_collector_1'

    class TestCollector2(TestCollector):
        _platform = 'Linux'
        name = 'test_collector_2'

    class TestCollector3(TestCollector):
        _platform = 'Generic'
        name = 'test_collector_3'

    class TestCollector4(TestCollector):
        _platform = 'Generic'
        name = 'test_collector_4'

    class TestCollector5(TestCollector):
        _platform = 'Generic'

# Generated at 2022-06-16 23:41:55.366217
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'virtual': [VirtualCollector],
        'system': [SystemCollector],
    }

    collector_names = ['network', 'hardware', 'virtual', 'system']

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    collector_names = ['network', 'hardware', 'virtual']



# Generated at 2022-06-16 23:42:06.142424
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    # Create a mock collector class
    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set(['mock'])

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}

    # Create a mock collector class
    class MockCollector2(BaseFactCollector):
        name = 'mock2'
        _fact_ids = set(['mock2'])

       

# Generated at 2022-06-16 23:42:16.315566
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:42:53.328282
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.mount import MountCollector


# Generated at 2022-06-16 23:43:04.080671
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set()

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['A'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['A', 'B'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['B', 'C'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['C', 'D'])

    class G(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:43:13.188330
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:43:22.859452
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_all': [network.NetworkAllCollector],
        'network_interfaces': [network.NetworkInterfacesCollector],
        'network_routes': [network.NetworkRoutesCollector],
        'network_neighbors': [network.NetworkNeighborsCollector],
        'network_gather_subset': [network.NetworkGatherSubsetCollector],
    }

    # test that network_all requires network_interfaces and network_routes
    collector_names = ['network_all']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:43:35.228888
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'
        _

# Generated at 2022-06-16 23:43:44.744925
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['collector5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = set(['collector6'])

    class Collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = set(['collector7'])

   

# Generated at 2022-06-16 23:43:52.153210
# Unit test for function tsort
def test_tsort():
    # Test a simple acyclic graph
    dep_map = {'a': set(['b', 'c']),
               'b': set(['c']),
               'c': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test a graph with a cycle
    dep_map = {'a': set(['b']),
               'b': set(['c']),
               'c': set(['a'])}
    try:
        sorted_list = tsort(dep_map)
        assert False, 'tsort should have thrown an exception'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-16 23:44:02.090133
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    # all_fact_subsets['a'] requires 'b'
    # all_fact_subsets['b'] requires 'c'
    # all_fact_subsets['c'] requires 'd'
    # all_fact_subsets['d'] requires 'e'
    # all_fact_subsets['e'] requires 'f'
    # all_fact_subsets['f'] requires 'a'
    #
    # This is a cycle.
    #
    # all_fact_subsets['a'] requires 'b'
    # all_fact_

# Generated at 2022-06-16 23:44:08.718016
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [], 'b': [], 'c': []}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    class CollectorA:
        required_facts = ['b', 'c']

    class CollectorB:
        required_facts = ['c']

    class CollectorC:
        required_facts = []

    all_fact_subsets = {'a': [CollectorA], 'b': [CollectorB], 'c': [CollectorC]}
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:44:16.285577
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:44:34.977697
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['b', 'c'])
        name = 'b'

    class CollectorC(BaseFactCollector):
        _fact_ids = set(['c', 'd'])
        name = 'c'

    class CollectorD(BaseFactCollector):
        _fact_ids = set(['d', 'e'])
        name = 'd'

    class CollectorE(BaseFactCollector):
        _fact_ids = set(['e', 'f'])
        name = 'e'

    class CollectorF(BaseFactCollector):
        _fact_ids = set(['f', 'g'])
        name

# Generated at 2022-06-16 23:44:48.337315
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:44:58.492490
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test4'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test5'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5', 'test6'])


# Generated at 2022-06-16 23:45:10.177749
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact3'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact4'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact5'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['fact6'])
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _fact_ids = set(['fact7'])


# Generated at 2022-06-16 23:45:20.665363
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    collectors_for_platform = [TestCollector1, TestCollector2, TestCollector3]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-16 23:45:33.632008
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with no unresolved requires
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with one unresolved require
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with one unresolved require

# Generated at 2022-06-16 23:45:46.314916
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:45:54.046333
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.mount import MountCollector


# Generated at 2022-06-16 23:46:03.873394
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['system', 'network'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])


# Generated at 2022-06-16 23:46:16.050611
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }

    # test no unresolved requires
    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test one unresolved require
    collector_names = ['a', 'b', 'c', 'd']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['d'])

    # test two unresolved requires
    collector_names = ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-16 23:46:50.936474
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1', 'test_fact_id_2'])
        name = 'test_collector_1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_5'])
        name

# Generated at 2022-06-16 23:46:59.199399
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with gather_subset = ['all']
    assert get_collector_names(gather_subset=['all']) == {'all'}

    # Test with gather_subset = ['!all']
    assert get_collector_names(gather_subset=['!all']) == {'min'}

    # Test with gather_subset = ['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == set()

    # Test with gather_subset = ['!all', '!min', 'all']
    assert get_collector_names(gather_subset=['!all', '!min', 'all']) == {'all'}

    # Test with gather_subset = ['!all', '!min', '

# Generated at 2022-06-16 23:47:04.417763
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set(['system'])
    assert find_unresolved_requires(['system'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['network', 'system'], all_fact_subsets) == set()



# Generated at 2022-06-16 23:47:11.643608
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:47:20.902230
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:47:32.165814
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [], 'b': [], 'c': []}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    class A:
        required_facts = set()
    class B:
        required_facts = set()
    class C:
        required_facts = set()
    class D:
        required_facts = set(['a'])
    class E:
        required_facts = set(['a', 'b'])
    class F:
        required_facts = set(['a', 'b', 'c'])

# Generated at 2022-06-16 23:47:43.514776
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
        'i': [object()],
        'j': [object()],
        'k': [object()],
    }

    # no requires
    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # requires that are in collector_names
    collector_names = ['a', 'b', 'c', 'd']

# Generated at 2022-06-16 23:47:55.221622
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = frozenset(['test_collector1'])
        name = 'test_collector1'
        required_facts = frozenset()

    class TestCollector2(BaseFactCollector):
        _fact_ids = frozenset(['test_collector2'])
        name = 'test_collector2'
        required_facts = frozenset()

    class TestCollector3(BaseFactCollector):
        _fact_ids = frozenset(['test_collector3'])
        name = 'test_collector3'
        required_facts = frozenset()

    class TestCollector4(BaseFactCollector):
        _fact_ids = frozenset(['test_collector4'])

# Generated at 2022-06-16 23:48:06.062215
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import NetworkCollector
    from ansible.module_utils.facts.collectors import HardwareCollector
    from ansible.module_utils.facts.collectors import DmiCollector
    from ansible.module_utils.facts.collectors import VirtualCollector

    collectors_for_platform = [NetworkCollector, HardwareCollector, DmiCollector, VirtualCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [NetworkCollector]
    assert fact_id_to_collector_map['hardware'] == [HardwareCollector]

# Generated at 2022-06-16 23:48:14.171801
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:48:43.379193
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact3'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact4'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact5'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['fact6'])
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _fact_ids = set(['fact7'])


# Generated at 2022-06-16 23:48:55.666083
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import all_collector_classes
    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    # test with no unresolved requires
    collector_names = ['system']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test with unresolved requires
    collector_names = ['system', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['network'])

    # test with unresolved requires
    collector_names = ['system', 'network', 'dmi']
    unresolved = find

# Generated at 2022-06-16 23:49:01.158422
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set()

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['A'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

    class G(BaseFactCollector):
        name = 'G'
        required_facts = set(['F'])


# Generated at 2022-06-16 23:49:05.428978
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.lxc
    import ansible.module_utils.facts.virtual.openvz
    import ansible.module_utils.facts.virtual.zstack
    import ansible.module_utils.facts.virtual.gce
    import ansible.module

# Generated at 2022-06-16 23:49:17.092518
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:49:28.357757
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['system', 'test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['system', 'test', 'test2'])


# Generated at 2022-06-16 23:49:39.499745
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:49:50.394351
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:50:00.712323
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3'])


# Generated at 2022-06-16 23:50:11.300659
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network', 'system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'system'], all_fact_subsets) == set()
    assert find_unresolved_