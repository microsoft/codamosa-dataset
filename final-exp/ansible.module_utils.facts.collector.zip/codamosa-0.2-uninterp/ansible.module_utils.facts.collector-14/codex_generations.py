

# Generated at 2022-06-16 23:40:57.386825
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], minimal_gather_subset=['min']
    assert get_collector_names(gather_subset=['all'], minimal_gather_subset=['min']) == frozenset(['all', 'min'])

    # Test with gather_subset=['all'], minimal_gather_subset=['min'], valid_subsets=['all', 'min']

# Generated at 2022-06-16 23:41:01.526667
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:41:11.051820
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_2'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:41:19.427355
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('', (object,), {'required_facts': ['b', 'c']}),
            type('', (object,), {'required_facts': ['b', 'c']}),
        ],
        'b': [
            type('', (object,), {'required_facts': ['c']}),
            type('', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('', (object,), {'required_facts': []}),
            type('', (object,), {'required_facts': []}),
        ],
    }

# Generated at 2022-06-16 23:41:27.058474
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
        'i': [object()],
        'j': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d', 'e'])
        if collector_name == 'c':
            return set(['f', 'g'])

# Generated at 2022-06-16 23:41:37.312152
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = set(['f'])


# Generated at 2022-06-16 23:41:47.199533
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _platform = 'Generic'

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'
        _platform = 'Generic'

    class TestCollector5(BaseFactCollector):
        name = 'test_collector5'
        _platform = 'Generic'

    class TestCollector6(BaseFactCollector):
        name = 'test_collector6'
        _platform = 'Generic'


# Generated at 2022-06-16 23:41:54.524674
# Unit test for function select_collector_classes
def test_select_collector_classes():
    collector_names = ['network', 'network', 'network']
    all_fact_subsets = {'network': [1, 2, 3]}
    assert select_collector_classes(collector_names, all_fact_subsets) == [1, 2, 3]

    collector_names = ['network', 'network', 'network']
    all_fact_subsets = {'network': [1, 2, 3], 'network_resources': [4, 5, 6]}
    assert select_collector_classes(collector_names, all_fact_subsets) == [1, 2, 3, 4, 5, 6]

    collector_names = ['network', 'network', 'network']

# Generated at 2022-06-16 23:42:01.433888
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts import collector
    all_fact_subsets = {
        'all': [collector.GenericFactCollector],
        'network': [collector.NetworkFactCollector],
        'min': [collector.GenericFactCollector]
    }
    assert select_collector_classes(['all'], all_fact_subsets) == [collector.GenericFactCollector]
    assert select_collector_classes(['network'], all_fact_subsets) == [collector.NetworkFactCollector]
    assert select_collector_classes(['min'], all_fact_subsets) == [collector.GenericFactCollector]

# Generated at 2022-06-16 23:42:11.851097
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:42:28.351952
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector(BaseFactCollector):
        _platform = 'Generic'
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _platform = 'Generic'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _platform = 'Generic'

# Generated at 2022-06-16 23:42:40.628171
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:42:49.908947
# Unit test for function build_dep_data
def test_build_dep_data():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['a', 'b'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['a', 'c'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['a', 'd'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['a', 'e'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['a', 'f'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'


# Generated at 2022-06-16 23:42:55.493388
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollectorLinux(TestCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test'
        required_facts = set()

    class TestCollectorLinux2(TestCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test2'
        required_facts = set()

    class TestCollectorLinux3(TestCollector):
        _fact_ids = set()
        _platform = 'Linux'
        name = 'test3'
        required_facts = set()


# Generated at 2022-06-16 23:43:06.379325
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'Darwin'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector6'

    class Collector7(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector7'


# Generated at 2022-06-16 23:43:19.353288
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1: no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            TestCollector('a', required_facts=['b']),
            TestCollector('a', required_facts=['c']),
        ],
        'b': [
            TestCollector('b', required_facts=['c']),
        ],
        'c': [
            TestCollector('c', required_facts=[]),
        ],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test case 2: one unresolved requires
    collector_names = ['a', 'b', 'c']

# Generated at 2022-06-16 23:43:22.404440
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [1, 2], 'b': [3, 4], 'c': [5, 6]})
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}



# Generated at 2022-06-16 23:43:34.741295
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:43:44.376981
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SELinuxCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineCollector


# Generated at 2022-06-16 23:43:56.357682
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import hardware
    from ansible.module_utils.facts.collectors import virtual
    from ansible.module_utils.facts.collectors import default

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'hardware': [hardware.HardwareCollector],
        'virtual': [virtual.VirtualCollector],
        'default': [default.DefaultCollector],
    }

    collector_names = ['network', 'hardware', 'virtual', 'default']

    dep_map = build_dep_data(collector_names, all_fact_subsets)

    assert dep_map['network'] == set(['default'])

# Generated at 2022-06-16 23:44:13.164564
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['test1', 'test2'])
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])
    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()
    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])
    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['test4'])

# Generated at 2022-06-16 23:44:25.478441
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        _platform = 'Generic'
        name = 'test_collector1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        _platform = 'Generic'
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        _platform = 'Generic'
        name = 'test_collector3'
        required_facts = set()


# Generated at 2022-06-16 23:44:34.122752
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': set(['b', 'c'])}),
        ],
        'b': [
            type('b', (object,), {'required_facts': set(['c'])}),
        ],
        'c': [
            type('c', (object,), {'required_facts': set()}),
        ],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with unresolved requires
    collector_names = ['a', 'b', 'c']

# Generated at 2022-06-16 23:44:47.603638
# Unit test for function tsort
def test_tsort():
    # Test graph from https://en.wikipedia.org/wiki/Topological_sorting#Depth-first_search
    dep_map = {
        'undershorts': set(),
        'socks': set(),
        'watch': set(),
        'pants': {'undershorts'},
        'shoes': {'socks'},
        'shirt': set(),
        'belt': {'pants'},
        'tie': {'shirt'},
        'jacket': {'shirt'},
        'socks': {'pants'},
        'pajamas': {'undershorts', 'shirt'},
    }
    sorted_list = tsort(dep_map)

# Generated at 2022-06-16 23:44:57.869201
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts import collector
    import unittest

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _platform = 'Linux'

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        _platform = 'Linux'

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        _platform = 'Generic'

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'
        _platform = 'Linux'

    class TestCollector5(collector.BaseFactCollector):
        name = 'test5'
        _platform = 'Linux'


# Generated at 2022-06-16 23:45:09.619543
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set()

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:45:20.478836
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:45:33.497047
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:45:46.317351
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.zfs import ZFSCollector
    from ansible.module_utils.facts.collector.zpool import ZPoolCollector

    # create a list of all the collector classes

# Generated at 2022-06-16 23:45:54.046100
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['foo', 'bar'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['foo', 'baz'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['foo', 'baz'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['foo', 'baz'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['foo', 'baz'])
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:46:09.723376
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(('all', 'network', 'hardware', 'devices', 'dmi')),
        minimal_gather_subset=frozenset(('network', 'hardware')),
        gather_subset=['!all', 'network', '!hardware', 'devices'],
        aliases_map=defaultdict(set, {'hardware': frozenset(('devices', 'dmi'))}),
        platform_info=None) == frozenset(('network', 'devices'))

    # Test with minimal options

# Generated at 2022-06-16 23:46:18.834019
# Unit test for function get_collector_names
def test_get_collector_names():
    valid_subsets = frozenset(['all', 'network', 'hardware', 'devices', 'dmi'])
    minimal_gather_subset = frozenset(['network'])
    aliases_map = defaultdict(set)
    aliases_map['hardware'].update(['devices', 'dmi'])

    # Test gather_subset=None
    assert get_collector_names(valid_subsets=valid_subsets,
                               minimal_gather_subset=minimal_gather_subset,
                               aliases_map=aliases_map) == frozenset(['network'])

    # Test gather_subset=['all']

# Generated at 2022-06-16 23:46:31.285755
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PackageManagerCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:46:40.522435
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector5'

    all_collector_classes = [Collector1, Collector2, Collector3, Collector4, Collector5]

    # Test case 1:
    # compat_platforms = [{'system': 'Linux'}]
    # expected_result = [Collect

# Generated at 2022-06-16 23:46:53.278390
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b'])
    all_fact_subsets['b'][0].required_facts = set(['c'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set(['e'])

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['e'])

# Generated at 2022-06-16 23:47:06.190043
# Unit test for function tsort
def test_tsort():
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('d', set()), ('c', set(['d'])), ('b', set(['c'])), ('a', set(['b', 'c']))]

    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(['d']),
        'd': set(['a']),
    }

# Generated at 2022-06-16 23:47:16.623061
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!min']

# Generated at 2022-06-16 23:47:24.652017
# Unit test for function tsort
def test_tsort():
    test_dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set([]),
        'd': set(['e']),
        'e': set(['f']),
        'f': set(['d']),
    }
    try:
        tsort(test_dep_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass


# Generated at 2022-06-16 23:47:36.048257
# Unit test for function tsort
def test_tsort():
    # Test for a cycle
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': {'a'}}
    try:
        tsort(dep_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass

    # Test for a simple case
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': {'d'}, 'd': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('d', set()), ('c', {'d'}), ('b', {'c'}), ('a', {'b'})]

    # Test for a more complex case

# Generated at 2022-06-16 23:47:45.888795
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_classes()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    collector_names = ['all', 'network']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    assert dep_map['network'] == set()
    collector_names = ['all', 'network', 'facter']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    assert dep_map['network'] == set()

# Generated at 2022-06-16 23:48:03.928100
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.file import FileCollector
    from ansible.module_utils.facts.collector.service import ServiceCollector
    from ansible.module_utils.facts.collector.puppet import PuppetCollector
    from ansible.module_utils.facts.collector.ohai import OhaiCollector

# Generated at 2022-06-16 23:48:12.659607
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', 'network']
    assert get_collector_names(gather_subset=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_subset=['all', '!network']
    assert get_collector_names(gather_subset=['all', '!network']) == frozenset(['all'])

    # Test with gather_subset=['all', '!network', 'network']

# Generated at 2022-06-16 23:48:20.424215
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test for gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test for gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test for gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test for gather_subset=['!all', '!min', 'network']
    assert get_collector_names(gather_subset=['!all', '!min', 'network']) == frozenset(['network'])

    # Test for gather_sub

# Generated at 2022-06-16 23:48:32.649180
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:48:37.652736
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network', 'system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:48:50.016248
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:49:01.565985
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set()

    all_fact_subsets = {
        'A': [A],
        'B': [B],
        'C': [C],
        'D': [D],
    }

    assert find_unresolved_requires(['A'], all_fact_subsets) == set(['B', 'C', 'D'])
    assert find_unresolved

# Generated at 2022-06-16 23:49:10.768741
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:49:21.414644
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set(['system'])
    assert find_unresolved_requires(['system'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['system', 'network'], all_fact_subsets) == set()



# Generated at 2022-06-16 23:49:30.664430
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            FakeCollector('a', required_facts=set()),
            FakeCollector('a', required_facts=set()),
        ],
        'b': [
            FakeCollector('b', required_facts=set()),
            FakeCollector('b', required_facts=set()),
        ],
        'c': [
            FakeCollector('c', required_facts=set()),
            FakeCollector('c', required_facts=set()),
        ],
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    # Test with one unresolved require

# Generated at 2022-06-16 23:49:52.213945
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set()
    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])
    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['A'])
    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['B', 'C'])
    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])
    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])
   

# Generated at 2022-06-16 23:50:04.402501
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.distribution


# Generated at 2022-06-16 23:50:12.405873
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            FakeCollector('a', ['b']),
            FakeCollector('a', ['c']),
        ],
        'b': [
            FakeCollector('b', ['c']),
        ],
        'c': [
            FakeCollector('c', ['a']),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {
        'a': {'b', 'c'},
        'b': {'c'},
        'c': {'a'},
    }



# Generated at 2022-06-16 23:50:23.274170
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

    class CollectorG(BaseFactCollector):
        name = 'G'
       

# Generated at 2022-06-16 23:50:31.291577
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all defaults
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']