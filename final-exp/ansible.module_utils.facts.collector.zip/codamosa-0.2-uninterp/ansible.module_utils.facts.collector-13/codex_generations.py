

# Generated at 2022-06-16 23:40:55.185175
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_2'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:41:05.173762
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['all']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], valid_subsets=['all', 'network']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_sub

# Generated at 2022-06-16 23:41:16.323148
# Unit test for function tsort
def test_tsort():
    # Test 1: simple
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set([])), ('b', set(['c'])), ('a', set(['b']))]

    # Test 2: simple cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        tsort(dep_map)
        assert False, 'Expected CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass

    # Test 3: more complex cycle
    dep

# Generated at 2022-06-16 23:41:27.850581
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import hardware
    from ansible.module_utils.facts.collectors import default
    from ansible.module_utils.facts.collectors import virtual
    from ansible.module_utils.facts.collectors import darwin
    from ansible.module_utils.facts.collectors import system
    from ansible.module_utils.facts.collectors import distribution

    all_collector_classes = [
        network.NetworkCollector,
        hardware.HardwareCollector,
        default.DefaultCollector,
        virtual.VirtualCollector,
        darwin.DarwinCollector,
        system.SystemCollector,
        distribution.DistributionCollector,
    ]


# Generated at 2022-06-16 23:41:39.759443
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['min']),
        gather_subset=['!network', 'hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None) == frozenset(['hardware', 'devices', 'dmi'])

    # test with no options

# Generated at 2022-06-16 23:41:48.606658
# Unit test for function tsort
def test_tsort():
    # Test 1:
    #   A -> B
    #   B -> C
    #   C -> A
    #
    #   Should raise CycleFoundInFactDeps
    dep_map = {
        'A': {'B'},
        'B': {'C'},
        'C': {'A'},
    }
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        raise AssertionError('tsort did not raise CycleFoundInFactDeps for cyclic graph')

    # Test 2:
    #   A -> B
    #   B -> C
    #   C -> D
    #
    #   Should return [('A', {'B'}), ('B', {'C'}), ('C', {'D'}),

# Generated at 2022-06-16 23:41:59.766207
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set()
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    all_fact_subsets = {
        'A': [A],
        'B': [B],
        'C': [C],
        'D': [D],
    }

    assert find_unresolved_requires(['A'], all_fact_subsets)

# Generated at 2022-06-16 23:42:11.330747
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware', 'system'], all_fact_subsets) == set()
    assert find_unresolved_

# Generated at 2022-06-16 23:42:16.395753
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test'])

    all_fact_subsets = {
        'test': [TestCollector, TestCollector],
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    collector_names = ['test', 'network', 'system']

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

    assert len(selected_collector_classes) == 3


# Generated at 2022-06-16 23:42:24.699155
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = {'fact1', 'fact2'}

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = {'fact3', 'fact4'}

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = {'fact5', 'fact6'}

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = {'fact7', 'fact8'}

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = {'fact9', 'fact10'}


# Generated at 2022-06-16 23:42:46.437365
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:42:53.806350
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!foo']
    assert get_collector_names(gather_subset=['all', '!foo']) == frozenset(['all'])

    # Test with gather_subset=['all', '!foo'], valid_subsets=['foo']
    assert get_collector_names(gather_subset=['all', '!foo'], valid_subsets=['foo']) == frozenset(['all'])

    # Test with gather_subset=['

# Generated at 2022-06-16 23:43:01.691871
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    # Test with a collector that has no requires
    collector_names = ['test_collector']
    all_fact_subsets = {'test_collector': [collector.BaseFactCollector]}
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test with a collector that requires a collector that is not in collector_names
    collector_names = ['test_collector']
    all_fact_subsets = {'test_collector': [collector.BaseFactCollector]}
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test with a collector that requires a collector that is in collector_names

# Generated at 2022-06-16 23:43:11.985567
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }
    # a requires b, c, d
    # b requires e
    # c requires e
    # d requires f
    # e requires f
    # f requires nothing
    def _get_requires_by_collector_name(collector_name):
        if collector_name == 'a':
            return set(['b', 'c', 'd'])
        if collector_name == 'b':
            return set(['e'])
        if collector_name == 'c':
            return set(['e'])

# Generated at 2022-06-16 23:43:22.976871
# Unit test for function select_collector_classes

# Generated at 2022-06-16 23:43:35.364285
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = set(['d'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set()

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b', 'c', 'd'])

# Generated at 2022-06-16 23:43:45.512182
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollectorRequires(BaseFactCollector):
        name = 'test_requires'
        required_facts = set(['test'])

    class TestCollectorRequiresRequires(BaseFactCollector):
        name = 'test_requires_requires'
        required_facts = set(['test_requires'])

    class TestCollectorRequiresRequiresRequires(BaseFactCollector):
        name = 'test_requires_requires_requires'
        required_facts = set(['test_requires_requires'])


# Generated at 2022-06-16 23:43:57.075888
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', 'min']

# Generated at 2022-06-16 23:44:09.693228
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:44:22.714255
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:44:36.816541
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all']) == frozenset(['network'])

    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all', 'network']) == frozenset(['network'])


# Generated at 2022-06-16 23:44:49.531512
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['test'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test', 'system'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:44:57.296617
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!network']

# Generated at 2022-06-16 23:45:04.103727
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_id']
        name = 'test_collector'

    assert build_fact_id_to_collector_map([TestCollector]) == (
        {'test_id': [TestCollector], 'test_collector': [TestCollector]},
        {'test_collector': {'test_id'}}
    )



# Generated at 2022-06-16 23:45:12.944472
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', 'hardware']

# Generated at 2022-06-16 23:45:21.978950
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1: no unresolved requires
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test 2: one unresolved require
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    collector_names = ['a', 'b', 'c']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # Test 3: one unresolved require
    all_fact

# Generated at 2022-06-16 23:45:34.493287
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': {'devices', 'dmi'}}),
                               platform_info=None) == frozenset(['all', 'network'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:45:47.032935
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip3 import Pip3Collector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgM

# Generated at 2022-06-16 23:45:55.464942
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:46:05.778315
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    all_fact_subsets = collector.get_collector_subsets()

    # no unresolved requires
    collector_names = ['all']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # no unresolved requires
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # no unresolved requires
    collector_names = ['all', 'network', 'dmi']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # unresolved requires
    collector_names = ['all', 'network', 'dmi', 'hardware']


# Generated at 2022-06-16 23:46:26.198301
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test that it returns an empty set when there are no unresolved requires
    assert find_unresolved_requires(['a', 'b'], {'a': [], 'b': []}) == set()

    # Test that it returns a set of unresolved requires
    assert find_unresolved_requires(['a', 'b'], {'a': [], 'b': [], 'c': []}) == {'c'}



# Generated at 2022-06-16 23:46:36.727156
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _fact_ids = set(['test_collector_1', 'test_collector_2'])

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _fact_ids = set(['test_collector2_1', 'test_collector2_2'])

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _fact_ids = set(['test_collector3_1', 'test_collector3_2'])

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'

# Generated at 2022-06-16 23:46:49.490328
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_fact_subsets()
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter', 'puppet']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set()

    collector_names = ['all', 'network', 'facter', 'puppet', 'ohai']

# Generated at 2022-06-16 23:46:58.316633
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }


# Generated at 2022-06-16 23:47:10.660025
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'


# Generated at 2022-06-16 23:47:19.851229
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all']) == frozenset(['network'])

    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network']) == frozenset(['all'])


# Generated at 2022-06-16 23:47:31.109300
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file import FileCollector

# Generated at 2022-06-16 23:47:42.641098
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mounts import MountsCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:47:54.809796
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']})
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
            type('b', (object,), {'required_facts': ['a']})
        ],
        'c': [
            type('c', (object,), {'required_facts': ['a']}),
            type('c', (object,), {'required_facts': ['b']})
        ]
    }

# Generated at 2022-06-16 23:48:05.654419
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mounts import MountsCollector
    from ansible.module_utils.facts.collector.selinux import SELinuxCollector
   

# Generated at 2022-06-16 23:48:20.373526
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set(['e'])
        if collector_name == 'e':
            return set(['f'])

# Generated at 2022-06-16 23:48:32.598388
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'virtual': [VirtualCollector],
        'system': [SystemCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:48:41.158180
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['a', 'b', 'c']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['a', 'b', 'c']) == frozenset(['a', 'b', 'c'])

    # Test with gather_subset=['all'], valid_subsets=['a', 'b', 'c'], minimal_gather_subset=['a']

# Generated at 2022-06-16 23:48:53.891416
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

    class G(BaseFactCollector):
        name = 'G'
        required_facts = set(['F'])



# Generated at 2022-06-16 23:49:04.436543
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_resources': [network.NetworkResourcesCollector],
        'network_resources_lo': [network.NetworkResourcesLoCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network_resources'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['network_resources_lo'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['network', 'network_resources'], all_fact_subsets) == set()
    assert find_unres

# Generated at 2022-06-16 23:49:15.997185
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set()

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])

    class CollectorG(BaseFactCollector):
        name = 'g'
        required_facts = set()

   

# Generated at 2022-06-16 23:49:27.546184
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'network'}

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
        'virtual': [VirtualCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()

# Generated at 2022-06-16 23:49:39.051376
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_fact_id']
        name = 'test_collector'
    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test_fact_id2']
        name = 'test_collector2'
    class TestCollector3(BaseFactCollector):
        _fact_ids = ['test_fact_id3']
        name = 'test_collector3'
    class TestCollector4(BaseFactCollector):
        _fact_ids = ['test_fact_id4']
        name = 'test_collector4'
    class TestCollector5(BaseFactCollector):
        _fact_ids = ['test_fact_id5']
        name = 'test_collector5'


# Generated at 2022-06-16 23:49:49.877052
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['collector5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = set(['collector6'])

    class Collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = set(['collector7'])

   

# Generated at 2022-06-16 23:49:56.187740
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:50:20.995953
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test']

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ['test2']

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = ['test3']

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = ['test4']


# Generated at 2022-06-16 23:50:29.391099
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'all': [network.NetworkCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # no unresolved requires
    collector_names = ['all']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = []
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['network'])

