

# Generated at 2022-06-16 23:40:51.390132
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no args
    assert get_collector_names() == frozenset(['all'])

    # test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # test with gather_subset=['all', '!min', '!network']
    assert get_collector_names(gather_subset=['all', '!min', '!network']) == frozenset(['all', '!network'])

    # test with gather_subset=['all', '!min', '!network

# Generated at 2022-06-16 23:41:03.783489
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!all', 'hardware'],
        aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
        platform_info={'system': 'Linux'}
    ) == frozenset(['network', 'devices', 'dmi'])

    # Test with minimal options

# Generated at 2022-06-16 23:41:16.170690
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:41:24.658970
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['a'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['a', 'b'])

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['a', 'b', 'c'])

   

# Generated at 2022-06-16 23:41:33.171944
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['network', 'min'])
    assert get_collector_names(gather_subset=['!all', '!network']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network']) == frozenset(['network', 'min'])

# Generated at 2022-06-16 23:41:45.588119
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:41:51.917480
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])


# Generated at 2022-06-16 23:42:01.409019
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['network']) == frozenset(['network'])

    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network']) == frozenset(['hardware'])


# Generated at 2022-06-16 23:42:09.129756
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_all': [network.NetworkAllCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network_all'], all_fact_subsets) == set(['network'])



# Generated at 2022-06-16 23:42:19.272694
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.linux import LinuxHardware
    from ansible.module_utils.facts.collector.linux import LinuxVirtual
    from ansible.module_utils.facts.collector.linux import LinuxDistribution
    from ansible.module_utils.facts.collector.linux import LinuxSystem
    from ansible.module_utils.facts.collector.linux import LinuxNetwork
    from ansible.module_utils.facts.collector.linux import LinuxUser
    from ansible.module_utils.facts.collector.linux import LinuxMount
    from ansible.module_utils.facts.collector.linux import LinuxPackageManager
    from ansible.module_utils.facts.collector.linux import LinuxCommand
    from ansible.module_utils.facts.collector.linux import LinuxDefaultRoute

# Generated at 2022-06-16 23:42:34.562211
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:42:44.834315
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mounts import MountsCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:42:53.449487
# Unit test for function build_dep_data
def test_build_dep_data():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set(['collector4'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set()

    all_fact_subsets = {
        'collector1': [Collector1],
        'collector2': [Collector2],
        'collector3': [Collector3],
        'collector4': [Collector4],
    }


# Generated at 2022-06-16 23:43:00.876347
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'test1'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'test2'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required

# Generated at 2022-06-16 23:43:11.812977
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:43:22.947256
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:43:35.320027
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!hardware'],
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                               platform_info=None) == frozenset(['network'])

    # Test with only valid_subsets

# Generated at 2022-06-16 23:43:44.809719
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
    }

    collector_names = ['network', 'system', 'virtual']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [NetworkCollector, SystemCollector, VirtualCollector]

    collector_names = ['network', 'system', 'virtual', 'network']
    selected_collector_classes = select_collector

# Generated at 2022-06-16 23:43:52.205463
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.identity import IdentityCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:44:02.123566
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:44:21.928854
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']})
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']})
        ],
        'c': [
            type('c', (object,), {'required_facts': []})
        ]
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {
        'a': {'b', 'c'},
        'b': {'c'},
        'c': set()
    }



# Generated at 2022-06-16 23:44:31.508522
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set()


# Generated at 2022-06-16 23:44:36.691795
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': []}),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(),
    }



# Generated at 2022-06-16 23:44:49.385327
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'base': [BaseFactCollector],
    }

    collector_names = ['network', 'system', 'virtual']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved, 'unresolved: %s' % unresolved


# Generated at 2022-06-16 23:44:59.333663
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = set(['d'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set()

    assert find_unresolved_requires(['a'], all_fact_subsets) == set()
    assert find_unresolved_requires(['b'], all_fact_subsets) == set()
    assert find_un

# Generated at 2022-06-16 23:45:10.860609
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': []}),
        ],
    }
    assert build_dep_data(collector_names, all_fact_subsets) == {
        'a': {'b', 'c'},
        'b': {'c'},
        'c': set(),
    }



# Generated at 2022-06-16 23:45:21.043875
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': []}),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:45:34.020044
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.platform.linux import LinuxFactCollector
    from ansible.module_utils.facts.collector.platform.freebsd import FreeBSDFactCollector

    class LinuxCollector(BaseFactCollector):
        name = 'linux'
        _platform = 'Linux'

    class FreeBSDCollector(BaseFactCollector):
        name = 'freebsd'
        _platform = 'FreeBSD'

    class GenericCollector(BaseFactCollector):
        name = 'generic'
        _platform = 'Generic'

    class OtherCollector(BaseFactCollector):
        name = 'other'
        _platform = 'Other'


# Generated at 2022-06-16 23:45:46.609726
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    collectors_for_platform = [NetworkCollector, SystemCollector, BaseFactCollector, HardwareCollector, VirtualCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [NetworkCollector]
    assert fact_id_to_

# Generated at 2022-06-16 23:45:55.212735
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    assert dep_map['network'] == set()
    assert dep_map['hardware'] == set()
    assert dep_map['virtual'] == set()
    assert dep_map['system'] == set()
    assert dep_map['facter'] == set()
    assert dep_map['ohai'] == set()
    assert dep_map['puppet'] == set()
    assert dep_map['collectd'] == set()
    assert dep_map['salt'] == set()

# Generated at 2022-06-16 23:46:14.159290
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = ('a', 'b')

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = ('b', 'c')

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = ('c', 'd')

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = ('d', 'e')

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = ('e', 'f')

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = ('f', 'g')

    class CollectorG(BaseFactCollector):
        name

# Generated at 2022-06-16 23:46:28.415973
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b', 'c']}),
            type('a', (object,), {'required_facts': ['b', 'c']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
            type('b', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': []}),
            type('c', (object,), {'required_facts': []}),
        ],
    }

# Generated at 2022-06-16 23:46:38.480630
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1: no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector([])],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test 2: one unresolved require
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector(['d'])],
    }
    assert find_unres

# Generated at 2022-06-16 23:46:50.936162
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [], 'b': [], 'c': []}
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = {'a'}

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = {'b'}

    collector_names = ['a', 'b', 'c']

# Generated at 2022-06-16 23:46:59.228448
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test'], all_fact_subsets) == {'system'}

# Generated at 2022-06-16 23:47:06.174533
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['collector5'])


# Generated at 2022-06-16 23:47:16.579637
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == set(['all'])
    assert get_collector_names(gather_subset=['min']) == set(['min'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['!min']) == set(['all'])
    assert get_collector_names(gather_subset=['!min', '!all']) == set()
    assert get_collector_names(gather_subset=['!min', '!all', 'min']) == set(['min'])

# Generated at 2022-06-16 23:47:24.621148
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = {'collector1', 'collector1_alias'}

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = {'collector2', 'collector2_alias'}

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = {'collector3', 'collector3_alias'}

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = {'collector4', 'collector4_alias'}

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:47:35.967323
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'platform': [PlatformCollector],
        'pkg_mgr': [PkgMgrCollector],
        'service_mgr': [ServiceMgrCollector],
    }

    # Test that a collector with no requires returns an empty set
    collector_names = ['network']

# Generated at 2022-06-16 23:47:45.792741
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == set(['all'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', '!network']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == set(['network'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network']) == set(['network'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network', '!network']) == set(['min'])
    assert get_collector_

# Generated at 2022-06-16 23:48:32.649166
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    class CollectorA(collector.BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(collector.BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(collector.BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(collector.BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(collector.BaseFactCollector):
        name = 'E'
        required_facts = set()

    class CollectorF(collector.BaseFactCollector):
        name = 'F'

# Generated at 2022-06-16 23:48:41.187003
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:48:53.951199
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:49:04.475603
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.default import DefaultCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = {'system'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'test'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_

# Generated at 2022-06-16 23:49:15.998678
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:49:27.546242
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # test case 1: no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            FakeCollector(name='a', required_facts=set()),
        ],
        'b': [
            FakeCollector(name='b', required_facts=set()),
        ],
        'c': [
            FakeCollector(name='c', required_facts=set()),
        ],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # test case 2: one unresolved requires
    collector_names = ['a', 'b', 'c']

# Generated at 2022-06-16 23:49:39.052267
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = {'test', 'test_alias'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test2_alias'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3', 'test3_alias'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4', 'test4_alias'}

    all_collector_classes = [TestCollector, TestCollector2, TestCollector3, TestCollector4]
    fact_id_to_collector_map, aliases_

# Generated at 2022-06-16 23:49:49.921561
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # no unresolved requires
    collector_names = ['a', 'b']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # 'c' is not in collector_names
    collector_names = ['a', 'b']
    all_fact_subsets['a'] = [object()]
    all_fact_subsets['a'][0].required_facts = set(['c'])
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['c'])

    # 'c' is not in collector_names,

# Generated at 2022-06-16 23:49:56.208423
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import hardware
    from ansible.module_utils.facts.collectors import default
    from ansible.module_utils.facts.collectors import virtual
    from ansible.module_utils.facts.collectors import cloud
    from ansible.module_utils.facts.collectors import darwin
    from ansible.module_utils.facts.collectors import aix
    from ansible.module_utils.facts.collectors import freebsd
    from ansible.module_utils.facts.collectors import openbsd
    from ansible.module_utils.facts.collectors import netbsd
    from ansible.module_utils.facts.collectors import linux

# Generated at 2022-06-16 23:50:07.824298
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
