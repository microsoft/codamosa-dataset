

# Generated at 2022-06-16 23:41:03.632305
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:41:16.171066
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
    }

    class A(object):
        required_facts = set(['b', 'c'])
    class B(object):
        required_facts = set(['d', 'e'])
    class C(object):
        required_facts = set(['f', 'g'])
    class D(object):
        required_facts = set(['a'])
    class E(object):
        required_facts = set(['b'])
    class F(object):
        required_facts = set(['c'])


# Generated at 2022-06-16 23:41:27.716760
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:41:39.591690
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:41:48.460963
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # a requires b, c
    # c requires d
    # d requires a
    #
    # a, b, c, d should be returned
    def get_requires_by_collector_name(collector_name):
        if collector_name == 'a':
            return {'b', 'c'}
        if collector_name == 'c':
            return {'d'}
        if collector_name == 'd':
            return {'a'}
        return set()

    unresolved = find_unresolved_requires(['a', 'b', 'c', 'd'], all_fact_subsets)
   

# Generated at 2022-06-16 23:41:59.167208
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'
    class CollectorF(BaseFactCollector):
        name = 'f'
    class CollectorG(BaseFactCollector):
        name = 'g'
    class CollectorH(BaseFactCollector):
        name = 'h'
    class CollectorI(BaseFactCollector):
        name = 'i'
    class CollectorJ(BaseFactCollector):
        name = 'j'
    class CollectorK(BaseFactCollector):
        name = 'k'
   

# Generated at 2022-06-16 23:42:11.290086
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None) == frozenset(['network', 'devices', 'dmi'])


# Generated at 2022-06-16 23:42:21.772701
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.identity import IdentityCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:42:29.683621
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:42:40.742988
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test 1
    all_fact_subsets = {'all': [BaseFactCollector, BaseFactCollector]}
    collector_names = ['all']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 2
    assert selected_collector_classes[0] == BaseFactCollector
    assert selected_collector_classes[1] == BaseFactCollector

    # Test 2
    all_fact_subsets = {'all': [BaseFactCollector, BaseFactCollector]}
    collector_names = ['all', 'all']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 2

# Generated at 2022-06-16 23:43:04.244254
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    collector_names = ['a', 'b', 'c', 'd']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [CollectorA, CollectorB, CollectorC, CollectorD]

    collector_names

# Generated at 2022-06-16 23:43:13.310802
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SELinuxCollect

# Generated at 2022-06-16 23:43:22.985208
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:43:35.364734
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:43:44.842450
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # create a mock collector class
    class MockCollector:
        def __init__(self, name):
            self.name = name

    # create a mock collector class with a fact id
    class MockCollectorWithFactId:
        def __init__(self, name, fact_id):
            self.name = name
            self._fact_ids = set([fact_id])

    # create a mock collector class with a fact id and a required fact
    class MockCollectorWithFactIdAndRequiredFact:
        def __init__(self, name, fact_id, required_fact):
            self.name = name
            self._fact_ids = set([fact_id])
            self.required_facts = set([required_fact])

    # create a mock collector class with a fact id and a required fact

# Generated at 2022-06-16 23:43:48.709262
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_collector'])
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_collector4'])
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:43:59.464663
# Unit test for function build_dep_data
def test_build_dep_data():
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['a'])

    class E(BaseFactCollector):
        name = 'e'
        required_facts = set()

    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class G(BaseFactCollector):
        name = 'g'
        required_facts = set(['f'])

    all_fact

# Generated at 2022-06-16 23:44:11.507834
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    all_fact_subsets = collector.get_collector_classes()

    # test that 'all' is not unresolved
    collector_names = ['all']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test that 'all' is not unresolved
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test that 'all' is not unresolved
    collector_names = ['network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test that 'all' is not unresolved

# Generated at 2022-06-16 23:44:23.852534
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network', 'system'])

    class Test2Collector(BaseFactCollector):
        name = 'test2'
        required_facts = set(['network', 'test'])

    class Test3Collector(BaseFactCollector):
        name = 'test3'
        required_facts = set(['network', 'test', 'test2'])


# Generated at 2022-06-16 23:44:33.047157
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

    class G(BaseFactCollector):
        name = 'G'
        required_facts = set(['F'])



# Generated at 2022-06-16 23:44:54.667569
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': []})
    assert dep_map == defaultdict(set, {'a': set(), 'b': set(), 'c': set()})

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': []})
    assert dep_map == defaultdict(set, {'a': set(), 'b': set(), 'c': set(), 'd': set()})

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': [], 'e': []})
    assert dep_map == default

# Generated at 2022-06-16 23:45:02.634122
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # test with gather_subset=['!all', 'min']
    assert get_collector_names(gather_subset=['!all', 'min']) == frozenset(['min'])

    # test with gather_subset=['!all', 'min', 'network']

# Generated at 2022-06-16 23:45:12.238197
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b', 'c'])
    all_fact_subsets['b'][0].required_facts = set(['d'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set()

    assert find_unresolved_requires(set(['a']), all_fact_subsets) == set(['b', 'c', 'd'])

# Generated at 2022-06-16 23:45:21.675027
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector


# Generated at 2022-06-16 23:45:34.317796
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test a graph with a cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'tsort did not raise CycleFoundInFactDeps'



# Generated at 2022-06-16 23:45:46.865335
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set()


# Generated at 2022-06-16 23:45:55.355251
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:46:05.588254
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    # test that we get the expected collectors
    collector_names = ['a', 'b', 'c', 'd']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 4
    assert CollectorA

# Generated at 2022-06-16 23:46:17.030593
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector6'

    class Collector7(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector7'


# Generated at 2022-06-16 23:46:30.408427
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test1'])
        _platform = 'Linux'
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test2'])
        _platform = 'Linux'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test3'])
        _platform = 'Linux'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test4'])
        _platform = 'Linux'
        name = 'test4'
        required_

# Generated at 2022-06-16 23:46:46.685732
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:46:56.921178
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'Generic'
        name = 'a'

    class CollectorB(BaseFactCollector):
        _platform = 'Generic'
        name = 'b'

    class CollectorC(BaseFactCollector):
        _platform = 'Generic'
        name = 'c'

    class CollectorD(BaseFactCollector):
        _platform = 'Generic'
        name = 'd'

    class CollectorE(BaseFactCollector):
        _platform = 'Generic'
        name = 'e'

    class CollectorF(BaseFactCollector):
        _platform = 'Generic'
        name = 'f'

    class CollectorG(BaseFactCollector):
        _platform = 'Generic'
        name = 'g'


# Generated at 2022-06-16 23:47:08.989358
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set()
    assert dep_map['network'] == set()
    assert dep_map['virtual'] == set()
    assert dep_map['hardware'] == set()
    assert dep_map['facter'] == set()
    assert dep_map['ohai'] == set()
    assert dep_map['system'] == set()
    assert dep_map['min'] == set()
    assert dep_map['pkg_mgr'] == set()
    assert dep_map['python'] == set()

# Generated at 2022-06-16 23:47:16.665015
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_resources': [network.NetworkResourcesCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = ['network_resources']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['network'])



# Generated at 2022-06-16 23:47:27.973874
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts.collectors.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['network'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['network', 'hardware'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['network', 'hardware', 'virtual'])


# Generated at 2022-06-16 23:47:38.655815
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()


# Generated at 2022-06-16 23:47:47.393690
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:47:59.428007
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import Pip3Collector
    from ansible.module_utils.facts.collector.pip import Pip2Collector
    from ansible.module_utils.facts.collector.pip import Pip3Collector
    from ansible.module_utils.facts.collector.pip import Pip2Collector

# Generated at 2022-06-16 23:48:08.955347
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    # Test for function find_collectors_for_platform
    # Create a fake class for testing
    class FakeCollector(BaseFactCollector):
        _platform = 'Fake'
        name = 'fake'
        required_facts = set()

    # Create a fake class for testing
    class FakeCollector2(BaseFactCollector):
        _platform = 'Fake'
        name = 'fake2'
        required_facts = set()

    # Create a fake class for testing
    class FakeCollector3(BaseFactCollector):
        _platform = 'Fake'
        name = 'fake3'
        required_facts = set()

    # Create a fake class for testing
    class FakeCollector4(BaseFactCollector):
        _platform = 'Fake'
        name = 'fake4'
        required_facts = set()

    # Create

# Generated at 2022-06-16 23:48:18.479231
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'A'
        _platform = 'Linux'

    class CollectorB(BaseFactCollector):
        name = 'B'
        _platform = 'Linux'

    class CollectorC(BaseFactCollector):
        name = 'C'
        _platform = 'Generic'

    class CollectorD(BaseFactCollector):
        name = 'D'
        _platform = 'Generic'

    all_collectors = [CollectorA, CollectorB, CollectorC, CollectorD]

    # test Linux
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collectors, compat_platforms)

# Generated at 2022-06-16 23:48:37.245955
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'Linux'
        name = 'a'

    class CollectorB(BaseFactCollector):
        _platform = 'Linux'
        name = 'b'

    class CollectorC(BaseFactCollector):
        _platform = 'Generic'
        name = 'c'

    class CollectorD(BaseFactCollector):
        _platform = 'Generic'
        name = 'd'

    class CollectorE(BaseFactCollector):
        _platform = 'Linux'
        name = 'e'

    class CollectorF(BaseFactCollector):
        _platform = 'Linux'
        name = 'f'

    class CollectorG(BaseFactCollector):
        _platform = 'Linux'
        name = 'g'


# Generated at 2022-06-16 23:48:48.841961
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names(gather_subset=[]) == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!all']
    assert get_collector_names(gather_subset=['all', '!all']) == frozenset()

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', 'min']

# Generated at 2022-06-16 23:49:00.583402
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set(['test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test5'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set()


# Generated at 2022-06-16 23:49:08.259706
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no subset
    assert get_collector_names() == frozenset(['all'])

    # Test with subset
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with subset and min
    assert get_collector_names(gather_subset=['network'], minimal_gather_subset=['min']) == frozenset(['min', 'network'])

    # Test with subset and min and aliases
    assert get_collector_names(gather_subset=['network'], minimal_gather_subset=['min'], aliases_map={'hardware': ['devices', 'dmi']}) == frozenset(['min', 'network'])

    # Test with subset and min and aliases and exclude
    assert get_

# Generated at 2022-06-16 23:49:20.804052
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
                               platform_info=None) == frozenset(['network', 'hardware'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:49:30.346963
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'Linux'
        name = 'a'

    class CollectorB(BaseFactCollector):
        _platform = 'Linux'
        name = 'b'

    class CollectorC(BaseFactCollector):
        _platform = 'Generic'
        name = 'c'

    class CollectorD(BaseFactCollector):
        _platform = 'Generic'
        name = 'd'

    class CollectorE(BaseFactCollector):
        _platform = 'Darwin'
        name = 'e'

    class CollectorF(BaseFactCollector):
        _platform = 'Darwin'
        name = 'f'

    class CollectorG(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'g'

    class CollectorH(BaseFactCollector):
        _platform

# Generated at 2022-06-16 23:49:40.945570
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact'])
        name = 'test'
        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact2'])
        name = 'test2'
        _platform = 'Generic'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact3'])
        name = 'test3'
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact4'])
        name = 'test4'
        _platform = 'Generic'


# Generated at 2022-06-16 23:49:51.638095
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
    }

    # Test with no unresolved requires
    collector_names = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert len(unresolved) == 0

    # Test with one unresolved require
    collector_names = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']

# Generated at 2022-06-16 23:50:03.706617
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'min']
    assert get_collector_names(gather_subset=['!all', 'min']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']

# Generated at 2022-06-16 23:50:08.993575
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    collector_names = ['all', 'network']
    all_fact_subsets = {
        'all': [collector.NetworkCollector],
        'network': [collector.NetworkCollector]
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'all': set(), 'network': set()}


# Generated at 2022-06-16 23:50:30.969343
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = {'test_fact_id'}
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = {'test_fact_id2'}
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = {'test_fact_id3'}
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = {'test_fact_id4'}
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = {'test_fact_id5'}