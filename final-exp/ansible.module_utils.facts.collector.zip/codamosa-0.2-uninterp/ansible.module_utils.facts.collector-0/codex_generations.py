

# Generated at 2022-06-16 23:40:42.148174
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'

    all_fact_subsets = {
        'a': [CollectorA, CollectorA],
        'b': [CollectorB, CollectorB],
        'c': [CollectorC, CollectorC],
        'd': [CollectorD, CollectorD],
        'e': [CollectorE, CollectorE],
    }

    collector_names = ['a', 'b', 'c', 'd', 'e']
    selected_collector_classes = select_

# Generated at 2022-06-16 23:40:54.286119
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network']) == frozenset(['all'])

    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network', 'network']) == frozenset(['network'])


# Generated at 2022-06-16 23:41:04.574050
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

# Generated at 2022-06-16 23:41:12.932885
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:41:22.579374
# Unit test for method collect_with_namespace of class BaseFactCollector
def test_BaseFactCollector_collect_with_namespace():
    class TestCollector(BaseFactCollector):
        name = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    # test with no namespace
    collector = TestCollector()
    facts = collector.collect_with_namespace()
    assert facts == {'test': 'test'}

    # test with a namespace
    class TestNamespace:
        def transform(self, key_name):
            return 'test_' + key_name

    collector = TestCollector(namespace=TestNamespace())
    facts = collector.collect_with_namespace()
    assert facts == {'test_test': 'test'}



# Generated at 2022-06-16 23:41:32.994233
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:41:45.429598
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
                               platform_info=None) == frozenset(['network', 'hardware', 'devices', 'dmi'])
    # Test with minimal parameters

# Generated at 2022-06-16 23:41:51.815629
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = set(['A', 'B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = set(['B', 'C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = set(['C', 'D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = set(['D', 'E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = set(['E', 'F'])

    class CollectorF(BaseFactCollector):
        name = 'F'

# Generated at 2022-06-16 23:41:59.356751
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.system.linux
    import ansible.module_utils.facts.system.generic
    import ansible.module_utils.facts.system.netbsd
    import ansible.module_utils.facts.system.openbsd
    import ansible.module_utils.facts.system.freebsd
    import ansible.module_utils.facts.system.sunos
    import ansible.module_utils.facts.system.aix
    import ansible.module_utils.facts.system.hpux
    import ansible.module_utils.facts.system.windows
    import ansible.module_utils.facts.system.darwin
    import ansible.module_utils.facts.system.vmware
    import ansible.module_utils.facts.system.xenserver
    import ansible.module

# Generated at 2022-06-16 23:42:08.777380
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        name = 'test_collector1'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        name = 'test_collector2'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None


# Generated at 2022-06-16 23:42:27.012442
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'
    class CollectorF(BaseFactCollector):
        name = 'f'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
        'e': [CollectorE],
        'f': [CollectorF],
    }

    # Test 1: Simple case

# Generated at 2022-06-16 23:42:37.473122
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': []})
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': []})
    assert dep_map == {'a': set(), 'b': set(), 'c': set(), 'd': set()}

    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [], 'b': [], 'c': [], 'd': [], 'e': []})

# Generated at 2022-06-16 23:42:45.092682
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B', 'C'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set()

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

    class CollectorG(BaseFactCollector):
        name = 'G'
        required_facts = set

# Generated at 2022-06-16 23:42:52.184760
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }

    # test that it works with no unresolved requires
    collector_names = ['a', 'b', 'c']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # test that it works with unresolved requires
    collector_names = ['a', 'b']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'c'}

    # test that it works with a missing collector
    collector_names = ['a', 'b', 'd']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'d'}




# Generated at 2022-06-16 23:43:04.037841
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    collector_names = ['a', 'b', 'c', 'd']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {
        'a': set(),
        'b': set(),
        'c': set(),
        'd': set(),
    }

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = ['b', 'c']

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = ['c', 'd']


# Generated at 2022-06-16 23:43:13.158693
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:43:22.913584
# Unit test for function tsort
def test_tsort():
    # Test for a cycle
    dep_map = {'a': set(['b']), 'b': set(['a'])}
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        raise AssertionError('tsort did not detect a cycle')

    # Test for a simple sort
    dep_map = {'a': set(['b']), 'b': set(['c']), 'c': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b']))]

    # Test for a sort with multiple edges

# Generated at 2022-06-16 23:43:35.319509
# Unit test for function tsort
def test_tsort():
    # Test for a simple graph
    graph = {'a': set(['b']),
             'b': set(['c']),
             'c': set(['d']),
             'd': set(['e']),
             'e': set(['f']),
             'f': set(['g']),
             'g': set([]),
             }
    sorted_graph = tsort(graph)
    assert sorted_graph == [('g', set([])),
                            ('f', set(['g'])),
                            ('e', set(['f'])),
                            ('d', set(['e'])),
                            ('c', set(['d'])),
                            ('b', set(['c'])),
                            ('a', set(['b'])),
                            ]

    #

# Generated at 2022-06-16 23:43:45.470195
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

# Generated at 2022-06-16 23:43:57.027884
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'


# Generated at 2022-06-16 23:44:14.293853
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB, CollectorC],
        'c': [CollectorC, CollectorD],
        'd': [CollectorD, CollectorE],
        'e': [CollectorE],
    }

    collector_names = ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-16 23:44:26.343277
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import network

    # Test that we can find a collector by its primary name
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([network.NetworkCollector])
    assert fact_id_to_collector_map['network'] == [network.NetworkCollector]

    # Test that we can find a collector by its alias
    assert fact_id_to_collector_map['interfaces'] == [network.NetworkCollector]

    # Test that we can find a collector by its primary name
    assert fact_id_to_collector_map['network'] == [network.NetworkCollector]

    # Test that we can find a collector by its alias

# Generated at 2022-06-16 23:44:34.049173
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        _fact_ids = {'test_fact_id'}
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = {'test_fact_id2'}
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = {'test_fact_id3'}
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids

# Generated at 2022-06-16 23:44:47.501526
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'test1'

    class TestCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Darwin'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'test4'

    all_collector_classes = [TestCollector1, TestCollector2, TestCollector3, TestCollector4]

    # Test for Linux
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
   

# Generated at 2022-06-16 23:44:54.663220
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set()

    class CollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:44:59.643477
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert len(dep_map) == 1
    assert 'all' in dep_map
    assert len(dep_map['all']) == 0


# Generated at 2022-06-16 23:45:10.968392
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.linux import LinuxHardware
    from ansible.module_utils.facts.collector.linux import LinuxDistribution
    from ansible.module_utils.facts.collector.linux import LinuxVirtual
    from ansible.module_utils.facts.collector.linux import LinuxSystem
    from ansible.module_utils.facts.collector.linux import LinuxNetwork
    from ansible.module_utils.facts.collector.linux import LinuxUser
    from ansible.module_utils.facts.collector.linux import LinuxMount
    from ansible.module_utils.facts.collector.linux import LinuxPackageManager
    from ansible.module_utils.facts.collector.linux import LinuxCommand
    from ansible.module_utils.facts.collector.linux import LinuxDefaultRoute

# Generated at 2022-06-16 23:45:21.103036
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1', 'test1_alias'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test2_alias'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3', 'test3_alias'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4', 'test4_alias'}

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = {'test5', 'test5_alias'}

# Generated at 2022-06-16 23:45:34.020104
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _platform = 'Linux'

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _platform = 'Linux'

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _platform = 'Generic'

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _platform = 'Generic'

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _platform = 'Linux'

    class Collector6(BaseFactCollector):
        name = 'collector6'
        _platform = 'Linux'

    class Collector7(BaseFactCollector):
        name = 'collector7'
        _platform = 'Linux'


# Generated at 2022-06-16 23:45:42.823539
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test2'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector])

    assert fact_id_to_collector_map['test'] == [TestCollector]
    assert fact_id_to_collector_map['test2'] == [TestCollector]
    assert aliases_map['test'] == set(['test', 'test2'])



# Generated at 2022-06-16 23:45:57.302565
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4'}

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = {'test5'}

    class TestCollector6(BaseFactCollector):
        name = 'test6'

# Generated at 2022-06-16 23:46:08.477621
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name

# Generated at 2022-06-16 23:46:18.304993
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5'])


# Generated at 2022-06-16 23:46:30.818001
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {
    #       'a': [A],
    #       'b': [B],
    #       'c': [C],
    #   }
    #   where A.required_facts = {'b'}, B.required_facts = {'c'}, C.required_facts = {}
    #   expected result: set()
    class A(BaseFactCollector):
        name = 'a'
        required_facts = {'b'}
    class B(BaseFactCollector):
        name = 'b'
        required_facts = {'c'}
    class C(BaseFactCollector):
        name = 'c'
        required_facts = set()
    collector_names

# Generated at 2022-06-16 23:46:40.394346
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:46:53.149009
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'

    all_fact_subsets = {
        'a': [CollectorA, CollectorB],
        'b': [CollectorB, CollectorC],
        'c': [CollectorC, CollectorD],
        'd': [CollectorD, CollectorE],
        'e': [CollectorE],
    }


# Generated at 2022-06-16 23:47:02.788789
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test', 'test_alias'])

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map([TestCollector])

    assert fact_id_to_collector_map['test'] == [TestCollector]
    assert fact_id_to_collector_map['test_alias'] == [TestCollector]
    assert aliases_map['test'] == set(['test_alias'])



# Generated at 2022-06-16 23:47:13.897677
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector1(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:47:23.221387
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'system'}

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['test'], all_fact_subsets) == {'system'}



# Generated at 2022-06-16 23:47:35.491420
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # pylint: disable=unused-variable
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'
    class CollectorF(BaseFactCollector):
        name = 'f'
    class CollectorG(BaseFactCollector):
        name = 'g'
    class CollectorH(BaseFactCollector):
        name = 'h'
    class CollectorI(BaseFactCollector):
        name = 'i'
    class CollectorJ(BaseFactCollector):
        name = 'j'

# Generated at 2022-06-16 23:48:35.368357
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:48:42.646236
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # a requires b
    # b requires c
    # c requires d
    # d requires a
    for collector_name in all_fact_subsets:
        collector_classes = all_fact_subsets[collector_name]
        for collector_class in collector_classes:
            collector_class.required_facts = set([collector_name])

    # no unresolved requires
    collector_names = ['a', 'b', 'c', 'd']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires

# Generated at 2022-06-16 23:48:54.941027
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    '''Test find_unresolved_requires'''
    # pylint: disable=too-few-public-methods
    class TestCollector(BaseFactCollector):
        '''Test Collector'''
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        '''Test Collector 2'''
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        '''Test Collector 3'''
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        '''Test Collector 4'''
        name = 'test4'
        required_facts = set(['test2'])


# Generated at 2022-06-16 23:49:05.112635
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.collector.platform import Platform
    from ansible.module_utils.facts.collector.virtual import Virtual
    from ansible.module_utils.facts.collector.system import System
    from ansible.module_utils.facts.collector.fips import Fips
    from ansible.module_utils.facts.collector.selinux import Selinux
    from ansible.module_utils.facts.collector.mounts import Mounts
    from ansible.module_utils.facts.collector.distribution import Distribution

# Generated at 2022-06-16 23:49:16.654878
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:49:28.029644
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip3 import Pip3Collector

# Generated at 2022-06-16 23:49:39.458746
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = {'network', 'system'}

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
        'virtual': [VirtualCollector],
    }

    collector_names = ['test']
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:49:50.303314
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:50:00.488168
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['system'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['system'])



# Generated at 2022-06-16 23:50:11.133939
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
    }

    # no unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # unresolved requires
    collector_names = ['network']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # no unresolved requires
    collector_names = ['network', 'system']
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()


