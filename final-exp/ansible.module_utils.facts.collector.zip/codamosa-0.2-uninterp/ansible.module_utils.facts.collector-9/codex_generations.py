

# Generated at 2022-06-16 23:41:04.855732
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:41:16.286886
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = {'collector1_id1', 'collector1_id2'}

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = {'collector2_id1', 'collector2_id2'}

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = {'collector3_id1', 'collector3_id2'}

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = {'collector4_id1', 'collector4_id2'}

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:41:27.817060
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:41:39.717629
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.collector.network.bsd import BSDNetworkCollector
    from ansible.module_utils.facts.collector.network.windows import WindowsNetworkCollector

    all_collector_classes = [NetworkCollector, LinuxNetworkCollector, BSDNetworkCollector, WindowsNetworkCollector]

    compat_platforms = [{'system': 'Linux'}, {'system': 'Windows'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 2
    assert LinuxNetworkCollector in found_collectors
   

# Generated at 2022-06-16 23:41:49.100148
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None
    ) == frozenset(['network'])

    # Test with minimal options

# Generated at 2022-06-16 23:41:59.985803
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               gather_subset=['!all']) == frozenset()
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               gather_subset=['!all', 'all']) == frozenset(['all'])
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               gather_subset=['!all', '!all']) == frozenset()

# Generated at 2022-06-16 23:42:11.321023
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
        'e': [CollectorE],
    }

    collector_names = ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-16 23:42:21.302958
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {'a': [A1, A2], 'b': [B1, B2], 'c': [C1, C2]}
    #   expected_result = [A1, A2, B1, B2, C1, C2]
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [A1, A2], 'b': [B1, B2], 'c': [C1, C2]}
    expected_result = [A1, A2, B1, B2, C1, C2]
    result = select_collector_classes(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:42:28.111490
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'pkg_mgr': [PkgMgrCollector],
    }

    # test no unresolved requires

# Generated at 2022-06-16 23:42:40.587226
# Unit test for function build_dep_data
def test_build_dep_data():
    import pytest
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.default import DefaultCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector

# Generated at 2022-06-16 23:42:52.138149
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network import NetworkLegacyCollector
    from ansible.module_utils.facts.collector.network import NetworkMinCollector
    from ansible.module_utils.facts.collector.network import NetworkAllCollector
    from ansible.module_utils.facts.collector.network import NetworkHardwareCollector
    from ansible.module_utils.facts.collector.network import NetworkConfigCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesLegacyCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesMinCollector

# Generated at 2022-06-16 23:43:03.951080
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import network, hardware
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_id2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test_id3'])


# Generated at 2022-06-16 23:43:13.076340
# Unit test for function select_collector_classes
def test_select_collector_classes():
    # Test 1
    all_fact_subsets = {
        'a': [1, 2, 3],
        'b': [4, 5, 6],
        'c': [7, 8, 9],
    }
    collector_names = ['a', 'b', 'c']
    expected_result = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert select_collector_classes(collector_names, all_fact_subsets) == expected_result

    # Test 2
    all_fact_subsets = {
        'a': [1, 2, 3],
        'b': [4, 5, 6],
        'c': [7, 8, 9],
    }
    collector_names = ['a', 'b', 'c', 'a', 'b', 'c']
   

# Generated at 2022-06-16 23:43:22.680881
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:43:35.042975
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set()

    all_fact_subsets = {
        'A': [CollectorA],
        'B': [CollectorB],
        'C': [CollectorC],
        'D': [CollectorD],
    }


# Generated at 2022-06-16 23:43:44.602407
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:43:51.978277
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'
    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'
    class Collector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector3'
    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector4'

    all_collector_classes = [Collector1, Collector2, Collector3, Collector4]

    # Test for Linux
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 4
   

# Generated at 2022-06-16 23:44:01.969617
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _platform = 'Linux'

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _platform = 'Linux'

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _platform = 'Generic'

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _platform = 'Linux'

    class TestCollector6(BaseFactCollector):
        name = 'test6'
        _platform = 'Generic'

    class TestCollector7(BaseFactCollector):
        name = 'test7'

# Generated at 2022-06-16 23:44:13.764364
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:44:26.206645
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact'])
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact2'])
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact3'])
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact4'])
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test_fact5'])
        name = 'test5'

    class TestCollector6(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:44:46.324339
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test1'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test2'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['test3', 'test4'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'

# Generated at 2022-06-16 23:44:56.799495
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])


# Generated at 2022-06-16 23:45:08.699443
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

    all_collector_classes = [NetworkCollector, SystemCollector, DistributionCollector]

    # test for Linux
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
    assert len(found_collectors) == 3

    # test for Darwin
    compat_platforms = [{'system': 'Darwin'}]
    found_collectors = find_collectors_for_platform(all_collector_classes, compat_platforms)
   

# Generated at 2022-06-16 23:45:19.732095
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test that find_unresolved_requires works as expected
    # with a simple case
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set()

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }


# Generated at 2022-06-16 23:45:32.817590
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:45:46.223628
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:45:53.986806
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _platform = 'Generic'
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _platform = 'Generic'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Generic'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _platform = 'Linux'
        name = 'test5'

    class TestCollector6(BaseFactCollector):
        _platform = 'Linux'
        name = 'test6'

    class TestCollector7(BaseFactCollector):
        _platform = 'Linux'

# Generated at 2022-06-16 23:46:03.875068
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
    ) == frozenset(['network', 'devices', 'dmi'])


# Generated at 2022-06-16 23:46:16.051857
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:46:29.841648
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    collectors_for_platform = [NetworkCollector, HardwareCollector, SystemCollector, VirtualCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [NetworkCollector]
    assert fact_id_to_collector_map['hardware'] == [HardwareCollector]
    assert fact_id_to_collector_

# Generated at 2022-06-16 23:46:53.319595
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = ('a', 'b')

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = ('b', 'c')

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = ('c', 'd')

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = ('d', 'e')

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = ('e', 'f')

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = ('f', 'g')

    class CollectorG(BaseFactCollector):
        name

# Generated at 2022-06-16 23:47:06.188802
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!network']

# Generated at 2022-06-16 23:47:16.621047
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.zfs import ZFSCollector
    from ansible.module_utils.facts.collector.zpool import ZpoolCollector
    from ansible.module_utils.facts.collector.zfs_zpool import ZFS

# Generated at 2022-06-16 23:47:27.882161
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['network', '!hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None
    ) == frozenset(['network'])

    # Test with minimal options

# Generated at 2022-06-16 23:47:38.559899
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import (
        BaseFactCollector,
        NetworkFactCollector,
        HardwareFactCollector,
        VirtualizationFactCollector,
        DistributionFactCollector,
        SystemFactCollector,
    )

    collectors_for_platform = [
        NetworkFactCollector,
        HardwareFactCollector,
        VirtualizationFactCollector,
        DistributionFactCollector,
        SystemFactCollector,
    ]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [NetworkFactCollector]
    assert fact_id_to_collector_map['hardware'] == [HardwareFactCollector]
    assert fact_id

# Generated at 2022-06-16 23:47:47.344951
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {'a': [object()], 'b': [object()], 'c': [object()]}
    collector_names = ['a', 'b', 'c']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}

    class CollectorA(object):
        required_facts = ['b']
    class CollectorB(object):
        required_facts = ['c']
    class CollectorC(object):
        required_facts = ['a']
    all_fact_subsets = {'a': [CollectorA()], 'b': [CollectorB()], 'c': [CollectorC()]}
    collector_names = ['a', 'b', 'c']
    dep

# Generated at 2022-06-16 23:47:59.382685
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(frozenset(['all', 'network', 'hardware']),
                               frozenset(['network']),
                               ['all']) == frozenset(['network', 'all'])
    assert get_collector_names(frozenset(['all', 'network', 'hardware']),
                               frozenset(['network']),
                               ['!all']) == frozenset(['network'])
    assert get_collector_names(frozenset(['all', 'network', 'hardware']),
                               frozenset(['network']),
                               ['!all', 'network']) == frozenset(['network'])

# Generated at 2022-06-16 23:48:08.916634
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = frozenset(['test3'])


# Generated at 2022-06-16 23:48:18.446497
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1', 'fact2'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact3', 'fact4'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact5', 'fact6'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact7', 'fact8'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['fact9', 'fact10'])
        name = 'collector5'


# Generated at 2022-06-16 23:48:30.158131
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all']), gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', 'network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['!all']
    assert get_collect

# Generated at 2022-06-16 23:48:52.699249
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_fact_subsets()

    # test a simple case
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test a case where a collector is missing
    collector_names = ['all', 'network', 'missing']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert 'missing' in unresolved

    # test a case where a collector is missing, but is required by another
    collector_names = ['all', 'network', 'missing', 'network_resources']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
   

# Generated at 2022-06-16 23:49:03.534341
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'virtual']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!all']) == frozenset(['network'])

    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'virtual']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!network']) == frozenset(['virtual'])


# Generated at 2022-06-16 23:49:15.184736
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.pip import PipFactCollector
    from ansible.module_utils.facts.collector.pip3 import Pip3FactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector

# Generated at 2022-06-16 23:49:27.059742
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
    }

    # a requires b, c, d
    # b requires e, f
    # c requires g
    # d requires h
    # e requires f
    # f requires g
    # g requires h
    # h requires a
    #
    # a -> b -> e -> f -> g -> h -> a
    #        \-> f -> g -> h -> a
    #     \-> c -> g -> h -> a
    # \-> d -> h -> a
    #
    #

# Generated at 2022-06-16 23:49:38.122855
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network
    from ansible.module_utils.facts.collectors import hardware
    from ansible.module_utils.facts.collectors import default
    from ansible.module_utils.facts.collectors import virtual

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'hardware': [hardware.HardwareCollector],
        'default': [default.DefaultCollector],
        'virtual': [virtual.VirtualCollector],
    }

    collector_names = ['network', 'hardware', 'default', 'virtual']

    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    collector_names = ['network', 'hardware', 'default', 'virtual', 'missing']

    unresolved

# Generated at 2022-06-16 23:49:48.683415
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    collectors_for_platform = [NetworkCollector, HardwareCollector, VirtualCollector, SystemCollector]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_id_to_collector_map['network'] == [NetworkCollector]
    assert fact_id_to_collector_map['hardware'] == [HardwareCollector]
    assert fact_id_to_collector_

# Generated at 2022-06-16 23:49:55.743393
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'c'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['d', 'e'])
        name = 'f'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['g', 'h'])
        name = 'i'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['j', 'k'])
        name = 'l'

    collectors_for_platform = [Collector1, Collector2, Collector3, Collector4]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)

    assert fact_

# Generated at 2022-06-16 23:50:07.398538
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['A'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['B'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['E'])

    class G(BaseFactCollector):
        name = 'G'
        required_facts = set(['F'])



# Generated at 2022-06-16 23:50:13.036639
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            FakeCollector(name='a', required_facts=set(['b'])),
        ],
        'b': [
            FakeCollector(name='b', required_facts=set(['c'])),
        ],
        'c': [
            FakeCollector(name='c', required_facts=set(['d'])),
        ],
    }
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['d'])



# Generated at 2022-06-16 23:50:23.863388
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'hardware': [HardwareCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network', 'hardware'], all_fact_subsets) == set()