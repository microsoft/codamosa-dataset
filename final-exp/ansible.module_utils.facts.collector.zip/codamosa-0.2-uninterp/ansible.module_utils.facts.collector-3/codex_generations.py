

# Generated at 2022-06-16 23:40:57.432598
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = frozenset(['a', 'b', 'c'])
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = frozenset(['b', 'c', 'd'])
        name = 'b'

    class CollectorC(BaseFactCollector):
        _fact_ids = frozenset(['c', 'd', 'e'])
        name = 'c'

    class CollectorD(BaseFactCollector):
        _fact_ids = frozenset(['d', 'e', 'f'])
        name = 'd'

    class CollectorE(BaseFactCollector):
        _fact_ids = frozenset(['e', 'f', 'g'])
        name = 'e'


# Generated at 2022-06-16 23:41:01.562538
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names(gather_subset=[]) == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', '!network']
    assert get_collector_names(gather_subset=['all', '!min', '!network']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', '

# Generated at 2022-06-16 23:41:11.105264
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

# Generated at 2022-06-16 23:41:22.300944
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['a', 'b'])
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['a', 'b'])
    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['a', 'b'])
    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['a', 'b'])
    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['a', 'b'])

# Generated at 2022-06-16 23:41:32.958366
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        _platform = 'TestPlatform1'
        name = 'test_collector1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        _platform = 'TestPlatform2'
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        _platform = 'TestPlatform3'
        name = 'test_collector3'
        required_facts = set()


# Generated at 2022-06-16 23:41:45.429514
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system', 'network'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])


# Generated at 2022-06-16 23:41:51.867986
# Unit test for function tsort
def test_tsort():
    # Test 1: simple graph
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set([])), ('b', set(['c'])), ('a', set(['b']))]

    # Test 2: graph with multiple roots
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
        'd': set(['e']),
        'e': set([]),
    }
    sorted_list = tsort(dep_map)

# Generated at 2022-06-16 23:42:01.384751
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class DummyCollector(BaseFactCollector):
        name = 'dummy'
        required_facts = set()

    class DummyCollector2(BaseFactCollector):
        name = 'dummy2'
        required_facts = set()

    class DummyCollector3(BaseFactCollector):
        name = 'dummy3'
        required_facts = set()

    class DummyCollector4(BaseFactCollector):
        name = 'dummy4'
        required_facts = set()

    class DummyCollector5(BaseFactCollector):
        name

# Generated at 2022-06-16 23:42:11.831607
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'platform': [PlatformCollector],
        'system': [SystemCollector],
    }

    collector_names = ['network', 'platform', 'system']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert selected_collector_classes == [NetworkCollector, PlatformCollector, SystemCollector]

    collector_names = ['network', 'platform', 'system', 'network']
    selected_collector_classes = select_collector

# Generated at 2022-06-16 23:42:21.726773
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', 'network']

# Generated at 2022-06-16 23:42:38.183415
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['!hardware'],
                               aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])})) == frozenset(['network', 'devices', 'dmi'])

# Generated at 2022-06-16 23:42:47.852600
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:42:57.244874
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']

# Generated at 2022-06-16 23:43:06.984334
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    all_fact_subsets = {
        'collector1': [Collector1],
        'collector2': [Collector2],
        'collector3': [Collector3],
    }

    assert find_unresolved_requires(['collector1'], all_fact_subsets) == set(['collector2', 'collector3'])

# Generated at 2022-06-16 23:43:19.394181
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:43:25.670105
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.cmdline import CmdLineCollector


# Generated at 2022-06-16 23:43:38.215111
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

    class TestCollector2(BaseFactCollector):
        name = 'test'

    class TestCollector3(BaseFactCollector):
        name = 'test'

    class TestCollector4(BaseFactCollector):
        name = 'test'

    class TestCollector5(BaseFactCollector):
        name = 'test'

    class TestCollector6(BaseFactCollector):
        name = 'test'

   

# Generated at 2022-06-16 23:43:46.853796
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['fact1'])
        _platform = 'Linux'
        name = 'collector1'
        required_facts = set()

    class Collector2(BaseFactCollector):
        _fact_ids = set(['fact2'])
        _platform = 'Linux'
        name = 'collector2'
        required_facts = set()

    class Collector3(BaseFactCollector):
        _fact_ids = set(['fact3'])
        _platform = 'Linux'
        name = 'collector3'
        required_facts = set()

    class Collector4(BaseFactCollector):
        _fact_ids = set(['fact4'])
        _platform = 'Linux'
        name = 'collector4'
        required_facts = set()

# Generated at 2022-06-16 23:43:58.516334
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'A'
        _fact_ids = {'a', 'b'}

    class CollectorB(BaseFactCollector):
        name = 'B'
        _fact_ids = {'b', 'c'}

    class CollectorC(BaseFactCollector):
        name = 'C'
        _fact_ids = {'c', 'd'}

    class CollectorD(BaseFactCollector):
        name = 'D'
        _fact_ids = {'d', 'e'}

    class CollectorE(BaseFactCollector):
        name = 'E'
        _fact_ids = {'e', 'f'}

    class CollectorF(BaseFactCollector):
        name = 'F'
        _fact_ids = {'f', 'g'}

   

# Generated at 2022-06-16 23:44:10.416952
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:44:25.680387
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1', 'test_fact_id_2'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_5'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:44:34.242317
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector

# Generated at 2022-06-16 23:44:47.700675
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set()

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:44:57.997157
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(
        valid_subsets=frozenset(['a', 'b', 'c']),
        minimal_gather_subset=frozenset(['a']),
        gather_subset=['a'],
        aliases_map=defaultdict(set),
    ) == set(['a'])

    assert get_collector_names(
        valid_subsets=frozenset(['a', 'b', 'c']),
        minimal_gather_subset=frozenset(['a']),
        gather_subset=['a', 'b'],
        aliases_map=defaultdict(set),
    ) == set(['a', 'b'])


# Generated at 2022-06-16 23:45:09.701139
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {'a': [], 'b': [], 'c': []}

    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    all_fact_subsets['a'] = [object()]
    all_fact_subsets['a'][0].required_facts = set(['b'])
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    all_fact_subsets['a'][0].required_facts = set(['b', 'd'])
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['d'])



# Generated at 2022-06-16 23:45:20.551972
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [FakeCollector(['b'])],
        'b': [FakeCollector(['c'])],
        'c': [FakeCollector([])],
        'd': [FakeCollector(['a'])],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b', 'c'])
    assert find_unresolved_requires(['a', 'b'], all_fact_subsets) == set(['c'])
    assert find_unresolved_requires(['a', 'b', 'c'], all_fact_subsets) == set()
    assert find_unresolved_requires(['d'], all_fact_subsets) == set(['a', 'b', 'c'])

# Generated at 2022-06-16 23:45:33.542773
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b'])
    assert find_unresolved_requires(['a', 'b'], all_fact_subsets) == set(['c'])
    assert find_unresolved_requires

# Generated at 2022-06-16 23:45:38.278654
# Unit test for function build_dep_data
def test_build_dep_data():
    dep_map = build_dep_data(['a', 'b', 'c'], {'a': [1, 2], 'b': [3, 4], 'c': [5, 6]})
    assert dep_map == {'a': set(), 'b': set(), 'c': set()}



# Generated at 2022-06-16 23:45:50.057127
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:45:57.177568
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test', 'test_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:46:16.855529
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector5'

    all_collector_classes = [Collector1, Collector2, Collector3, Collector4, Collector5]

    # test for Linux
    compat_platforms = [{'system': 'Linux'}]
    found_collectors = find_collect

# Generated at 2022-06-16 23:46:30.361180
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])


# Generated at 2022-06-16 23:46:40.098157
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with a single collector that requires a single fact
    collector_names = ['collector_a']
    all_fact_subsets = {
        'collector_a': [
            type('CollectorA', (object,), {'required_facts': ['fact_b']})
        ]
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == {'fact_b'}

    # Test with a single collector that requires multiple facts
    collector_names = ['collector_a']
    all_fact_subsets = {
        'collector_a': [
            type('CollectorA', (object,), {'required_facts': ['fact_b', 'fact_c']})
        ]
    }

# Generated at 2022-06-16 23:46:53.022889
# Unit test for function build_dep_data
def test_build_dep_data():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
    }

    class A(object):
        required_facts = set(['b', 'c'])

    class B(object):
        required_facts = set(['d'])

    class C(object):
        required_facts = set(['e'])

    class D(object):
        required_facts = set(['f'])

    class E(object):
        required_facts = set(['g'])


# Generated at 2022-06-16 23:47:05.842888
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector6'

    class Collector7(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector7'


# Generated at 2022-06-16 23:47:16.355162
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = set(['test1', 'test1_alias'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2', 'test2_alias'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3', 'test3_alias'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4', 'test4_alias'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:47:24.423976
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:47:35.924214
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']), gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['!network']

# Generated at 2022-06-16 23:47:45.757464
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    import unittest
    import sys
    import os
    import tempfile
    import shutil

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'

# Generated at 2022-06-16 23:47:57.538309
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1', 'test1_alias'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test2_alias'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3', 'test3_alias'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4', 'test4_alias'}

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = {'test5', 'test5_alias'}

# Generated at 2022-06-16 23:49:01.369735
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['c'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['a'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['d'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['e'])
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _fact_ids = set(['f'])

# Generated at 2022-06-16 23:49:10.397775
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set()
        raise KeyError(collector_name)

    unresolved = find_unresolved_requires(['a'], all_fact_subsets)
    assert unresolved == set()

    unresolved = find_unres

# Generated at 2022-06-16 23:49:22.688858
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact4'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact6'])

    class Collector6(BaseFactCollector):
        name = 'collector6'
        _fact_ids

# Generated at 2022-06-16 23:49:31.348794
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(gather_subset=None) == set()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == set()

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == set()

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == set()

    # Test with gather_subset=['!min']
    assert get_collector_names(gather_subset=['!min']) == set()

    # Test with gather_subset=['!min', '!all']

# Generated at 2022-06-16 23:49:41.818068
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    all_collectors = [NetworkCollector, SystemCollector, HardwareCollector, VirtualCollector]

    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(all_collectors)

    assert fact_id_to_collector_map['network'] == [NetworkCollector]

# Generated at 2022-06-16 23:49:52.256781
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])
    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])
    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    collectors_for_platform = [Collector1, Collector2, Collector3]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)


# Generated at 2022-06-16 23:50:04.445073
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b', 'c'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = set(['f'])


# Generated at 2022-06-16 23:50:13.304774
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('A', (BaseFactCollector,), {
                'name': 'a',
                'required_facts': ['b', 'c']
            })
        ],
        'b': [
            type('B', (BaseFactCollector,), {
                'name': 'b',
                'required_facts': ['c']
            })
        ],
        'c': [
            type('C', (BaseFactCollector,), {
                'name': 'c',
                'required_facts': []
            })
        ]
    }
    expected = {
        'a': {'b', 'c'},
        'b': {'c'},
        'c': set()
    }


# Generated at 2022-06-16 23:50:24.201020
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['collector1', 'collector1_alias'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['collector2', 'collector2_alias'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['collector3', 'collector3_alias'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['collector4', 'collector4_alias'])
        name = 'collector4'
