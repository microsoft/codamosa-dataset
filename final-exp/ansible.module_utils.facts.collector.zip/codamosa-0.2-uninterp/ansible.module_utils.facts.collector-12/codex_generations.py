

# Generated at 2022-06-16 23:41:02.953122
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['network', 'hardware']),
                               minimal_gather_subset=frozenset(['min'])) == frozenset(['network', 'hardware', 'min'])
    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['network', 'hardware']),
                               minimal_gather_subset=frozenset(['min'])) == frozenset(['network', 'min'])

# Generated at 2022-06-16 23:41:16.088457
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test3'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set(['test4'])

    class TestCollector6(BaseFactCollector):
        name = 'test6'
        required_facts = set(['test5'])


# Generated at 2022-06-16 23:41:24.556504
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set(['test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()

    all_fact_subsets = {
        'test1': [TestCollector1],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

    assert find_unresolved_requires(['test1'], all_fact_subsets) == set(['test2', 'test3'])

# Generated at 2022-06-16 23:41:30.639526
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

# Generated at 2022-06-16 23:41:42.962058
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        name = 'collector2'
    class Collector3(BaseFactCollector):
        name = 'collector3'
    class Collector4(BaseFactCollector):
        name = 'collector4'

    all_fact_subsets = {
        'collector1': [Collector1, Collector2],
        'collector2': [Collector2, Collector3],
        'collector3': [Collector3, Collector4],
        'collector4': [Collector4, Collector1],
    }

    collector_names = ['collector1', 'collector2', 'collector3', 'collector4']

# Generated at 2022-06-16 23:41:48.620761
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            FakeCollector(name='a', required_facts=['b']),
        ],
        'b': [
            FakeCollector(name='b', required_facts=['c']),
        ],
        'c': [
            FakeCollector(name='c', required_facts=[]),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map == {
        'a': {'b'},
        'b': {'c'},
        'c': set(),
    }



# Generated at 2022-06-16 23:41:59.764255
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['all']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], valid_subsets=['all', 'network']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_sub

# Generated at 2022-06-16 23:42:11.319881
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import (
        BaseFactCollector,
        NetworkFactCollector,
        HardwareFactCollector,
        VirtualFactCollector,
        DMIHardwareFactCollector,
        LinuxHardwareFactCollector,
        LinuxVirtualFactCollector,
        LinuxNetworkFactCollector,
        LinuxDMIHardwareFactCollector,
        LinuxDefaultNetworkFactCollector,
        LinuxDistributionFactCollector,
        LinuxSystemdFactCollector,
        LinuxSysctlFactCollector,
        LinuxCmdlineFactCollector,
        LinuxDefaultDistributionFactCollector,
        LinuxDefaultSysctlFactCollector,
        LinuxDefaultCmdlineFactCollector,
        LinuxDefaultSystemdFactCollector,
        LinuxDefaultHardwareFactCollector,
        LinuxDefaultVirtualFactCollector,
    )

    collectors_for_platform

# Generated at 2022-06-16 23:42:21.307880
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])
    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])
    class E(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])
    class F(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

# Generated at 2022-06-16 23:42:29.418097
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        required_facts = set(['test2'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()

    all_fact_subsets = {
        'test1': [TestCollector1],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

    assert find_unresolved_requires(['test1'], all_fact_subsets) == set(['test2'])
    assert find_unresolved_requires(['test2'], all_fact_subsets)

# Generated at 2022-06-16 23:42:43.966578
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = {'test2'}


# Generated at 2022-06-16 23:42:53.390499
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'B'
        required_facts = set()
    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['A'])
    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['B', 'C'])
    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])


# Generated at 2022-06-16 23:43:00.798983
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=all
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=min
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=!all
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=!min
    assert get_collector_names(gather_subset=['!min']) == frozenset(['all'])

    # Test with gather_

# Generated at 2022-06-16 23:43:11.786933
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b', 'c']}),
            type('a', (object,), {'required_facts': ['c']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['a']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': ['b']}),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:43:22.947519
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with empty gather_subset
    assert get_collector_names(gather_subset=[]) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!all']
    assert get_collector_names(gather_subset=['all', '!all']) == frozenset(['min'])

    # Test with gather_subset=['all', '!all', 'min']

# Generated at 2022-06-16 23:43:35.043132
# Unit test for function tsort
def test_tsort():
    # Test 1: no cycle
    dep_map = {'a': set(['b', 'c']),
               'b': set(['c']),
               'c': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test 2: cycle
    dep_map = {'a': set(['b']),
               'b': set(['c']),
               'c': set(['a'])}
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'Expected CycleFoundInFactDeps'



# Generated at 2022-06-16 23:43:44.603051
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=[]) == frozenset(['min'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['min']

# Generated at 2022-06-16 23:43:52.008735
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector
    import pytest

    class TestCollector1(collector.BaseFactCollector):
        name = 'test1'
        required_facts = set(['test2'])

    class TestCollector2(collector.BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])

    class TestCollector3(collector.BaseFactCollector):
        name = 'test3'
        required_facts = set()

    class TestCollector4(collector.BaseFactCollector):
        name = 'test4'
        required_facts = set(['test5'])

    class TestCollector5(collector.BaseFactCollector):
        name = 'test5'
        required_facts = set()


# Generated at 2022-06-16 23:43:56.495898
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['all']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], valid_subsets=['all', 'network']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['all', 'network']) == frozenset(['all', 'network'])

    # Test with gather_sub

# Generated at 2022-06-16 23:44:04.888415
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [
            type('a', (object,), {'required_facts': ['b']}),
            type('a', (object,), {'required_facts': ['c']}),
        ],
        'b': [
            type('b', (object,), {'required_facts': ['c']}),
        ],
        'c': [
            type('c', (object,), {'required_facts': []}),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:44:16.433501
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:44:27.338461
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class Collector1(BaseFactCollector):
        name = 'collector1'
    class Collector2(BaseFactCollector):
        name = 'collector2'
    class Collector3(BaseFactCollector):
        name = 'collector3'
    class Collector4(BaseFactCollector):
        name = 'collector4'
    class Collector5(BaseFactCollector):
        name = 'collector5'
    class Collector6(BaseFactCollector):
        name = 'collector6'
    class Collector7(BaseFactCollector):
        name = 'collector7'
    class Collector8(BaseFactCollector):
        name = 'collector8'
    class Collector9(BaseFactCollector):
        name = 'collector9'


# Generated at 2022-06-16 23:44:35.188569
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'network']
    assert get_collector_names(gather_subset=['!all', 'network']) == frozenset(['min', 'network'])

    # Test with gather_subset=['!all', 'network', '!network']

# Generated at 2022-06-16 23:44:48.558289
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == set(['all'])
    assert get_collector_names(gather_subset=['!all']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', 'network']) == set(['min', 'network'])
    assert get_collector_names(gather_subset=['!all', '!network']) == set(['min'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network']) == set(['min', 'network'])
    assert get_collector_names(gather_subset=['!all', '!network', 'network', '!network']) == set(['min'])
   

# Generated at 2022-06-16 23:44:58.684487
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:45:10.358780
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_fact_id']
        name = 'test_collector'

    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test_fact_id2']
        name = 'test_collector2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = ['test_fact_id3']
        name = 'test_collector3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = ['test_fact_id4']
        name = 'test_collector4'

    class TestCollector5(BaseFactCollector):
        _fact_ids = ['test_fact_id5']
        name = 'test_collector5'


# Generated at 2022-06-16 23:45:20.697438
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset()

    # Test with gather_subset=['all'], valid_subsets=['foo', 'bar']
    assert get_collector_names(gather_subset=['all'], valid_subsets=['foo', 'bar']) == frozenset(['foo', 'bar'])

    # Test with gather_subset=['all'], valid_subsets=['foo', 'bar'], minimal_gather_subset=['foo']

# Generated at 2022-06-16 23:45:33.674403
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:45:46.314503
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1: no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector([])],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test 2: unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector(['d'])],
    }
    assert find_unresolved

# Generated at 2022-06-16 23:45:54.955111
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'a'
        required_facts = set()
    class B(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])
    class C(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])
    class D(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    all_fact_subsets = {
        'a': [A],
        'b': [B],
        'c': [C],
        'd': [D],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set

# Generated at 2022-06-16 23:46:15.352790
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network import NetworkLegacyCollector
    from ansible.module_utils.facts.collector.network import NetworkMinCollector
    from ansible.module_utils.facts.collector.network import NetworkAllCollector
    from ansible.module_utils.facts.collector.network import NetworkHardwareCollector
    from ansible.module_utils.facts.collector.network import NetworkConfigCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesMinCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesAllCollector

# Generated at 2022-06-16 23:46:29.290729
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test with no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test with unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set(['d'])

    # Test with unresolved requires, but with

# Generated at 2022-06-16 23:46:39.234614
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
                               platform_info=None) == frozenset(['network', 'all', 'hardware'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:46:52.052708
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set(['A'])

    class CollectorG(BaseFactCollector):
        name = 'G'

# Generated at 2022-06-16 23:46:59.682307
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }
    all_fact_subsets['a'][0].required_facts = set(['b'])
    all_fact_subsets['b'][0].required_facts = set(['c'])
    all_fact_subsets['c'][0].required_facts = set(['d'])
    all_fact_subsets['d'][0].required_facts = set(['e'])

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['e'])

# Generated at 2022-06-16 23:47:11.378492
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return {'b', 'c'}
        if collector_name == 'b':
            return {'d'}
        if collector_name == 'c':
            return {'e'}
        if collector_name == 'd':
            return {'f'}
        if collector_name == 'e':
            return {'f'}

# Generated at 2022-06-16 23:47:20.416384
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
        'h': [object()],
    }

    # a requires b, c
    # b requires d
    # c requires d
    # d requires e
    # e requires f
    # f requires g
    # g requires h
    # h requires a
    #
    # This is a cycle.
    #
    # The expected result is that all of these are unresolved
    #
    # a, b, c, d, e, f, g, h
    #
    # This is because we can't resolve any of them.

# Generated at 2022-06-16 23:47:31.601142
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['network', 'hardware']),
                               gather_subset=['all']) == frozenset(['network', 'hardware'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['network', 'hardware']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', 'hardware']

# Generated at 2022-06-16 23:47:43.085571
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import PipCollector
    from ansible.module_utils.facts.collector.pip import PipCollector

# Generated at 2022-06-16 23:47:55.042381
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
    }

    # a requires b, c
    # b requires d
    # c requires d
    # d requires a
    def get_requires_by_collector_name(collector_name):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set(['a'])
        raise CollectorNotFoundError('Fact collector "%s" not found' % collector_name)

    unresolved = find_

# Generated at 2022-06-16 23:48:12.260029
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set()

    all_fact_subsets = {
        'a': [CollectorA],
        'b': [CollectorB],
        'c': [CollectorC],
        'd': [CollectorD],
    }

    assert find_unresolved_requires(['a'], all_fact_subsets) == set(['b'])
   

# Generated at 2022-06-16 23:48:20.183805
# Unit test for function get_collector_names
def test_get_collector_names():
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()
    assert get_collector_names(gather_subset=['!all', 'min']) == frozenset(['min'])
    assert get_collector_names(gather_subset=['!all', 'min', '!min']) == frozenset()
    assert get_collector_names(gather_subset=['!all', 'min', '!min', 'min']) == frozenset(['min'])
    assert get_

# Generated at 2022-06-16 23:48:32.497491
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['system'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['system', 'test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'

# Generated at 2022-06-16 23:48:41.071184
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:48:53.828908
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'

    all_fact_subsets = {
        'a': [CollectorA, CollectorA],
        'b': [CollectorB, CollectorB],
        'c': [CollectorC, CollectorC],
        'd': [CollectorD, CollectorD],
    }

    collector_names = ['a', 'b', 'c', 'd']

    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)

    assert len(selected_collector_classes) == 4


# Generated at 2022-06-16 23:49:04.398894
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {
    #       'a': [CollectorA],
    #       'b': [CollectorB],
    #       'c': [CollectorC],
    #   }
    #   CollectorA.required_facts = ['a']
    #   CollectorB.required_facts = ['b']
    #   CollectorC.required_facts = ['c']
    #   Expected result: []
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = ['a']
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = ['b']
    class CollectorC(BaseFactCollector):
        name = 'c'

# Generated at 2022-06-16 23:49:15.946061
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', 'min']
    assert get_collector_names(gather_subset=['all', 'min']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset

# Generated at 2022-06-16 23:49:27.546297
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _fact_ids = set(['b', 'c'])
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _fact_ids = set(['c', 'd'])
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _fact_ids = set(['e'])
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _fact_ids = set(['f'])
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _fact_ids = set(['g'])
       

# Generated at 2022-06-16 23:49:39.051562
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network'])) == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']

# Generated at 2022-06-16 23:49:49.920961
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pci import PciCollector
    from ansible.module_utils.facts.collector.dmi import DmiCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:50:15.882698
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'test': [TestCollector],
    }

    collector_names = ['network', 'system', 'virtual', 'test']

# Generated at 2022-06-16 23:50:27.120731
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # Test with gather_subset=['!all', '!min', '!foo']