

# Generated at 2022-06-16 23:40:55.623087
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test_collector'
        _platform = 'Generic'

    class TestCollector2(BaseFactCollector):
        name = 'test_collector2'
        _platform = 'Generic'

    class TestCollector3(BaseFactCollector):
        name = 'test_collector3'
        _platform = 'Generic'

    class TestCollector4(BaseFactCollector):
        name = 'test_collector4'
        _platform = 'Generic'

    class TestCollector5(BaseFactCollector):
        name = 'test_collector5'
        _platform = 'Generic'

    class TestCollector6(BaseFactCollector):
        name = 'test_collector6'
        _platform = 'Generic'


# Generated at 2022-06-16 23:41:06.964493
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.collector.mount import MountCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector

# Generated at 2022-06-16 23:41:16.945877
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': set()}
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', {'c'}), ('a', {'b'})]

    # Test a graph with a cycle
    dep_map = {'a': {'b'}, 'b': {'c'}, 'c': {'a'}}
    try:
        sorted_list = tsort(dep_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass

    # Test a graph with multiple cycles

# Generated at 2022-06-16 23:41:27.529238
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'A'
        name = 'A'

    class CollectorB(BaseFactCollector):
        _platform = 'B'
        name = 'B'

    class CollectorC(BaseFactCollector):
        _platform = 'C'
        name = 'C'

    class CollectorD(BaseFactCollector):
        _platform = 'D'
        name = 'D'

    class CollectorE(BaseFactCollector):
        _platform = 'E'
        name = 'E'

    class CollectorF(BaseFactCollector):
        _platform = 'F'
        name = 'F'

    class CollectorG(BaseFactCollector):
        _platform = 'G'
        name = 'G'


# Generated at 2022-06-16 23:41:37.368149
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['test1', 'test2'])
    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test3'])
    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set()
    class TestCollector4(BaseFactCollector):
        name = 'test4'
        required_facts = set(['test5'])
    class TestCollector5(BaseFactCollector):
        name = 'test5'
        required_facts = set()

# Generated at 2022-06-16 23:41:47.236164
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:41:52.981287
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no subset
    assert get_collector_names() == frozenset(['all'])

    # Test with subset
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with subset and min
    assert get_collector_names(gather_subset=['network'], minimal_gather_subset=['min']) == frozenset(['network', 'min'])

    # Test with subset and min and alias
    assert get_collector_names(gather_subset=['network'], minimal_gather_subset=['min'], aliases_map={'network': ['network_resources']}) == frozenset(['network', 'min', 'network_resources'])

    # Test with subset and min and alias and exclude

# Generated at 2022-06-16 23:41:59.937973
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionCollector
    from ansible.module_utils.facts.collectors.system import SystemCollector

    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_id']
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _fact_ids = ['test_id2']
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = ['test_id3']

# Generated at 2022-06-16 23:42:07.707706
# Unit test for function tsort

# Generated at 2022-06-16 23:42:18.132890
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

    class TestCollector2(BaseFactCollector):
        name = 'test'

    class TestCollector3(BaseFactCollector):
        name = 'test'

    class TestCollector4(BaseFactCollector):
        name = 'test'

    class TestCollector5(BaseFactCollector):
        name = 'test'

    class TestCollector6(BaseFactCollector):
        name = 'test'

    class TestCollector7(BaseFactCollector):
        name = 'test'

# Generated at 2022-06-16 23:42:40.587328
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset()

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all'], minimal_gather_subset=['min']
    assert get_collector_names(gather_subset=['all'], minimal_gather_subset=['min']) == frozenset(['all'])

    # Test with gather_subset=['min']
    assert get_collector_names(gather_subset=['min']) == frozenset(['min'])

    # Test with gather_subset=['min'], minimal_gather_subset=['min']

# Generated at 2022-06-16 23:42:49.878014
# Unit test for function build_dep_data
def test_build_dep_data():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b', 'c'])
    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])
    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set()
    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['a'])
    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])


# Generated at 2022-06-16 23:42:55.478849
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        _platform = 'Generic'
        name = 'test_collector1'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        _platform = 'Generic'
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_collector3'])
        _platform = 'Generic'
        name = 'test_collector3'
        required_facts = set()


# Generated at 2022-06-16 23:43:05.428519
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class Collector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector1'

    class Collector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'collector2'

    class Collector3(BaseFactCollector):
        _platform = 'FreeBSD'
        name = 'collector3'

    class Collector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector4'

    class Collector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector5'

    class Collector6(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector6'

    class Collector7(BaseFactCollector):
        _platform = 'Generic'
        name = 'collector7'

    all

# Generated at 2022-06-16 23:43:12.501221
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'Generic'
        name = 'a'

    class CollectorB(BaseFactCollector):
        _platform = 'Generic'
        name = 'b'

    class CollectorC(BaseFactCollector):
        _platform = 'Linux'
        name = 'c'

    class CollectorD(BaseFactCollector):
        _platform = 'Linux'
        name = 'd'

    class CollectorE(BaseFactCollector):
        _platform = 'Linux'
        name = 'e'

    class CollectorF(BaseFactCollector):
        _platform = 'Linux'
        name = 'f'

    class CollectorG(BaseFactCollector):
        _platform = 'Linux'
        name = 'g'


# Generated at 2022-06-16 23:43:21.289256
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _platform = 'test'

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _platform = 'test2'

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _platform = 'test3'

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _platform = 'test4'

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _platform = 'test5'

    class TestCollector6(BaseFactCollector):
        name = 'test6'
        _platform = 'test6'

    class TestCollector7(BaseFactCollector):
        name = 'test7'
       

# Generated at 2022-06-16 23:43:34.329126
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all valid subsets
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               gather_subset=['all']) == frozenset(['all', 'network', 'hardware'])
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               gather_subset=['network']) == frozenset(['network'])
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               gather_subset=['hardware']) == frozenset(['hardware'])

# Generated at 2022-06-16 23:43:44.015774
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', '!min']

# Generated at 2022-06-16 23:43:55.822641
# Unit test for function select_collector_classes
def test_select_collector_classes():
    class CollectorA(BaseFactCollector):
        name = 'a'
    class CollectorB(BaseFactCollector):
        name = 'b'
    class CollectorC(BaseFactCollector):
        name = 'c'
    class CollectorD(BaseFactCollector):
        name = 'd'
    class CollectorE(BaseFactCollector):
        name = 'e'
    class CollectorF(BaseFactCollector):
        name = 'f'
    class CollectorG(BaseFactCollector):
        name = 'g'


# Generated at 2022-06-16 23:44:00.367143
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:44:23.423783
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:44:32.746931
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.mounts
    import ansible.module_utils.facts.collector.devices
    import ansible.module_utils.facts.collector.dmi
    import ansible.module_utils.facts.collector.selinux

# Generated at 2022-06-16 23:44:46.430691
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_collector1'])
        name = 'test_collector1'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_collector2'])
        name = 'test_collector2'
        required_facts = set()

        @classmethod
        def platform_match(cls, platform_info):
            if platform_info.get('system', None) == 'Linux':
                return cls
            return None


# Generated at 2022-06-16 23:44:53.463492
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.system


# Generated at 2022-06-16 23:45:01.988588
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import pytest
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    class TestCollector(BaseFactCollector):
        _platform = 'Test'
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _platform = 'Test'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Test'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Test'
        name = 'test4'


# Generated at 2022-06-16 23:45:11.884833
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test'])
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test2'])
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test3'])
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test4'])
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_ids = set(['test5'])

# Generated at 2022-06-16 23:45:21.505033
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['platform'])

    all_fact_subsets = {
        'platform': [PlatformCollector],
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'test': [TestCollector],
    }

    assert find_unresolved_requires(['platform'], all_fact_subsets) == set()
    assert find_unresolved_requires

# Generated at 2022-06-16 23:45:34.165934
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test case 1:
    #   collector_names = ['a', 'b', 'c']
    #   all_fact_subsets = {
    #       'a': [A],
    #       'b': [B],
    #       'c': [C],
    #   }
    #   A.required_facts = ['b']
    #   B.required_facts = ['c']
    #   C.required_facts = []
    #   expected_unresolved = set()
    class A(BaseFactCollector):
        name = 'a'
        required_facts = ['b']
    class B(BaseFactCollector):
        name = 'b'
        required_facts = ['c']
    class C(BaseFactCollector):
        name = 'c'
        required_facts = []
    collector_

# Generated at 2022-06-16 23:45:46.692357
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class CollectorA(BaseFactCollector):
        _platform = 'Linux'
        name = 'A'

    class CollectorB(BaseFactCollector):
        _platform = 'Linux'
        name = 'B'

    class CollectorC(BaseFactCollector):
        _platform = 'Darwin'
        name = 'C'

    class CollectorD(BaseFactCollector):
        _platform = 'Generic'
        name = 'D'

    class CollectorE(BaseFactCollector):
        _platform = 'Generic'
        name = 'E'

    all_collectors = [CollectorA, CollectorB, CollectorC, CollectorD, CollectorE]

    # test matching linux
    linux_platform_info = {'system': 'Linux'}

# Generated at 2022-06-16 23:45:55.241849
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class TestCollector1(BaseFactCollector):
        name = 'test_collector_1'
        required_facts = set(['test_collector_2'])

    class TestCollector2(BaseFactCollector):
        name = 'test_collector_2'
        required_facts = set(['test_collector_3'])

    class TestCollector3(BaseFactCollector):
        name = 'test_collector_3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        name = 'test_collector_4'
        required_facts = set(['test_collector_5'])

    class TestCollector5(BaseFactCollector):
        name = 'test_collector_5'
        required_facts = set()

    all_fact_subsets

# Generated at 2022-06-16 23:46:50.851487
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # Test with gather_subset=['network', '!all', '!min']

# Generated at 2022-06-16 23:46:59.170365
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:47:06.111750
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector1(BaseFactCollector):
        _platform = 'Linux'
        name = 'test1'

    class TestCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Linux'
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _platform = 'Linux'
        name = 'test5'

    class TestCollector6(BaseFactCollector):
        _platform = 'Linux'
        name = 'test6'

    class TestCollector7(BaseFactCollector):
        _platform = 'Linux'

# Generated at 2022-06-16 23:47:16.530004
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        required_facts = frozenset(['system'])

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'fake': [FakeCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved

# Generated at 2022-06-16 23:47:24.556942
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts import collector
    all_fact_subsets = collector.get_collector_subsets()
    collector_names = ['all']
    dep_map = build_dep_data(collector_names, all_fact_subsets)
    assert dep_map['all'] == set(['all'])
    assert dep_map['network'] == set(['network'])
    assert dep_map['system'] == set(['system'])
    assert dep_map['virtual'] == set(['virtual'])
    assert dep_map['fips'] == set(['fips'])
    assert dep_map['pkg_mgr'] == set(['pkg_mgr'])
    assert dep_map['distribution'] == set(['distribution'])
    assert dep_map['selinux'] == set

# Generated at 2022-06-16 23:47:35.924861
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['test2'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = frozenset(['test3'])


# Generated at 2022-06-16 23:47:45.757753
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:47:57.537667
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set()

    all_fact_subsets = {
        'A': [A],
        'B': [B],
        'C': [C],
        'D': [D],
    }

    # test that we can find an unresolved require
    collector_names = ['A']

# Generated at 2022-06-16 23:48:07.999068
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set()
        _platform = 'Generic'
        name = 'test4'
        required_facts = set()

    class TestCollector5(BaseFactCollector):
        _fact_

# Generated at 2022-06-16 23:48:17.826584
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['test'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['test2'])


# Generated at 2022-06-16 23:49:51.462506
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c', 'd']
    all_fact_subsets = {
        'a': [
            FakeCollector('a', ['b', 'c']),
            FakeCollector('a', ['b', 'c', 'd']),
        ],
        'b': [
            FakeCollector('b', ['c']),
        ],
        'c': [
            FakeCollector('c', ['d']),
        ],
        'd': [
            FakeCollector('d', []),
        ],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:50:03.488682
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
    }

    def _get_requires_by_collector_name(collector_name, all_fact_subsets):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['c', 'd'])
        if collector_name == 'c':
            return set(['d'])
        if collector_name == 'd':
            return set(['e'])
        if collector_name == 'e':
            return set(['f'])

# Generated at 2022-06-16 23:50:12.522831
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        _fact_ids = set(['test_fact_id'])
        name = 'test_collector'
        required_facts = set()

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id2'])
        name = 'test_collector2'
        required_facts = set()

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id3'])
        name = 'test_collector3'
        required_facts = set()

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id4'])
        name = 'test_collector4'
        required_facts = set()


# Generated at 2022-06-16 23:50:23.316108
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mounts import MountsCollector
    from ansible.module_utils.facts.collector.selinux import SELinuxCollector
   