

# Generated at 2022-06-16 23:40:42.017479
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set([])), ('b', set(['c'])), ('a', set(['b']))]

    # Test a graph with a cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        tsort(dep_map)
        assert False, 'Expected CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-16 23:40:53.874020
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # test with gather_subset=['network']
    assert get_collector_names(gather_subset=['network']) == frozenset(['network'])

    # test with gather_subset=['network', '!all']
    assert get_collector_names(gather_subset=['network', '!all']) == frozenset(['network'])

    # test with gather_subset=['network', '!all', 'min']

# Generated at 2022-06-16 23:41:04.537556
# Unit test for function build_dep_data
def test_build_dep_data():
    collector_names = ['a', 'b', 'c', 'd', 'e']
    all_fact_subsets = {
        'a': [BaseFactCollector(name='a', required_facts=['b', 'c'])],
        'b': [BaseFactCollector(name='b', required_facts=['d'])],
        'c': [BaseFactCollector(name='c', required_facts=['d'])],
        'd': [BaseFactCollector(name='d', required_facts=['e'])],
        'e': [BaseFactCollector(name='e', required_facts=['f'])],
    }
    dep_map = build_dep_data(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:41:16.248425
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=None,
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(['all', 'network'])

    # test with gather_subset=['all']

# Generated at 2022-06-16 23:41:27.784636
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class A(BaseFactCollector):
        name = 'a'
    class B(BaseFactCollector):
        name = 'b'
    class C(BaseFactCollector):
        name = 'c'
    class D(BaseFactCollector):
        name = 'd'
    class E(BaseFactCollector):
        name = 'e'
    class F(BaseFactCollector):
        name = 'f'

    all_fact_subsets = {
        'a': [A, B, C],
        'b': [B, C, D],
        'c': [C, D, E],
        'd': [D, E, F],
        'e': [E, F],
        'f': [F],
    }

# Generated at 2022-06-16 23:41:39.675777
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with empty gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!all', 'min']

# Generated at 2022-06-16 23:41:48.550721
# Unit test for function tsort
def test_tsort():
    # Test 1: Simple
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test 2: Cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        sorted_list = tsort(dep_map)
        assert False, 'tsort should have thrown an exception'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-16 23:41:59.735957
# Unit test for function tsort
def test_tsort():
    # Test a simple graph
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set(),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [('c', set()), ('b', set(['c'])), ('a', set(['b', 'c']))]

    # Test a graph with a cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['c']),
        'c': set(['a']),
    }
    try:
        tsort(dep_map)
        assert False, 'tsort should have raised CycleFoundInFactDeps'
    except CycleFoundInFactDeps:
        pass



# Generated at 2022-06-16 23:42:11.320457
# Unit test for function tsort
def test_tsort():
    # Test 1: Simple
    dep_map = {
        'a': set(['b', 'c']),
        'b': set(['c']),
        'c': set([]),
    }
    sorted_list = tsort(dep_map)
    assert sorted_list == [
        ('c', set([])),
        ('b', set(['c'])),
        ('a', set(['b', 'c'])),
    ]

    # Test 2: Cycle
    dep_map = {
        'a': set(['b']),
        'b': set(['a']),
    }
    try:
        tsort(dep_map)
    except CycleFoundInFactDeps:
        pass
    else:
        assert False, 'Expected CycleFoundInFactDeps'

    # Test 3

# Generated at 2022-06-16 23:42:15.950958
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!all', 'hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None
    ) == frozenset(['network', 'devices', 'dmi'])

    # Test with minimal options

# Generated at 2022-06-16 23:42:27.378559
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    all_fact_subsets = {
        'a': [object()],
        'b': [object()],
        'c': [object()],
        'd': [object()],
        'e': [object()],
        'f': [object()],
        'g': [object()],
    }

    def _get_requires_by_collector_name(collector_name):
        if collector_name == 'a':
            return set(['b', 'c'])
        if collector_name == 'b':
            return set(['d', 'e'])
        if collector_name == 'c':
            return set(['f', 'g'])
        if collector_name == 'd':
            return set(['a'])
        if collector_name == 'e':
            return set(['b'])

# Generated at 2022-06-16 23:42:38.182862
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=None) == frozenset(['network'])

    # Test with gather_subset=all
    assert get_collector_names(valid_subsets=frozenset(['all', 'network', 'hardware']),
                               minimal_gather_subset=frozenset(['network']),
                               gather_subset=['all']) == frozenset(['all', 'network'])

    # Test with gather_subset=network

# Generated at 2022-06-16 23:42:45.384525
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    # Test 1: no unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector([])],
    }
    assert find_unresolved_requires(collector_names, all_fact_subsets) == set()

    # Test 2: one unresolved requires
    collector_names = ['a', 'b', 'c']
    all_fact_subsets = {
        'a': [MockCollector(['b'])],
        'b': [MockCollector(['c'])],
        'c': [MockCollector(['d'])],
    }
    assert find_unres

# Generated at 2022-06-16 23:42:53.529252
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all options
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware', 'devices', 'dmi']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!network', 'hardware'],
        aliases_map=defaultdict(set, {'hardware': frozenset(['devices', 'dmi'])}),
        platform_info=None
    ) == frozenset(['hardware', 'devices', 'dmi'])

    # Test with minimal options

# Generated at 2022-06-16 23:43:00.949468
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min']
    assert get_collector_names(gather_subset=['all', '!min']) == frozenset(['all'])

    # Test with gather_subset=['all', '!min', '!network']
    assert get_collector_names(gather_subset=['all', '!min', '!network']) == frozenset(['all', '!network'])

    # Test with gather_subset=['all', '!min',

# Generated at 2022-06-16 23:43:10.498735
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxCollector
    from ansible.module_utils.facts.collector.mount import MountCollector

# Generated at 2022-06-16 23:43:20.389332
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_id'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test2_id'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = set(['test3_id'])

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = set(['test4_id'])

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = set(['test5_id'])


# Generated at 2022-06-16 23:43:33.285992
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector

    # This is a list of all the collectors that we have
    all_collector_classes = [
        NetworkCollector,
        HardwareCollector,
        SystemCollector,
        VirtualCollector,
    ]

    # This is a list of all the collectors that we have
    all_fact_subsets = defaultdict(list)
    for collector_class in all_collector_classes:
        all_fact_subsets[collector_class.name].append(collector_class)

    #

# Generated at 2022-06-16 23:43:41.774544
# Unit test for function find_unresolved_requires

# Generated at 2022-06-16 23:43:54.221395
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b', 'c'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        _fact_ids = set(['f'])


# Generated at 2022-06-16 23:44:10.515047
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no subset
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=None,
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(['all'])

    # Test with subset 'all'
    assert get_collector_names(valid_subsets=frozenset(['all']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(['all'])

    # Test with subset 'min'
    assert get_

# Generated at 2022-06-16 23:44:23.235272
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test gather_subset=['all']
    assert get_collector_names(gather_subset=['all'],
                               valid_subsets=frozenset(['network', 'hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network', 'hardware'])

    # Test gather_subset=['network']
    assert get_collector_names(gather_subset=['network'],
                               valid_subsets=frozenset(['network', 'hardware']),
                               minimal_gather_subset=frozenset(['network'])) == frozenset(['network'])

    # Test gather_subset=['!network']

# Generated at 2022-06-16 23:44:32.594244
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        _platform = 'Linux'
        name = 'test'

    class TestCollector2(BaseFactCollector):
        _platform = 'Linux'
        name = 'test2'

    class TestCollector3(BaseFactCollector):
        _platform = 'Linux'
        name = 'test3'

    class TestCollector4(BaseFactCollector):
        _platform = 'Generic'
        name = 'test4'

    class TestCollector5(BaseFactCollector):
        _platform = 'Generic'
        name = 'test5'

    class TestCollector6(BaseFactCollector):
        _platform = 'Generic'
        name = 'test6'

    class TestCollector7(BaseFactCollector):
        _platform = 'Linux'

# Generated at 2022-06-16 23:44:46.377805
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with all parameters
    assert get_collector_names(
        valid_subsets=frozenset(['all', 'network', 'hardware']),
        minimal_gather_subset=frozenset(['network']),
        gather_subset=['!all', 'hardware'],
        aliases_map=defaultdict(set, {'hardware': ['devices', 'dmi']}),
        platform_info=None
    ) == frozenset(['network', 'hardware', 'devices', 'dmi'])

    # Test with minimal parameters

# Generated at 2022-06-16 23:44:56.850757
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'test'
        required_facts = set(['a', 'b'])

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        required_facts = set(['b', 'c'])

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        required_facts = set(['c', 'd'])

    all_fact_subsets = {
        'test': [TestCollector],
        'test2': [TestCollector2],
        'test3': [TestCollector3],
    }

    collector_names = ['test', 'test2', 'test3']

    dep_map = build_dep

# Generated at 2022-06-16 23:45:08.793064
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set()
    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['C'])
    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['D'])


# Generated at 2022-06-16 23:45:19.733067
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class A(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class B(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class C(BaseFactCollector):
        name = 'C'
        required_facts = set()

    class D(BaseFactCollector):
        name = 'D'
        required_facts = set(['B'])

    class E(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class F(BaseFactCollector):
        name = 'F'
        required_facts = set(['G'])

    class G(BaseFactCollector):
        name = 'G'
        required_facts = set(['H'])



# Generated at 2022-06-16 23:45:32.820436
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['b'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['e'])

    class CollectorG(BaseFactCollector):
        name = 'g'

# Generated at 2022-06-16 23:45:46.223326
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        name = 'test1'
        _fact_ids = {'test1', 'test1_alias'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = {'test2', 'test2_alias'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _fact_ids = {'test3', 'test3_alias'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'
        _fact_ids = {'test4', 'test4_alias'}

    class TestCollector5(BaseFactCollector):
        name = 'test5'
        _fact_ids = {'test5', 'test5_alias'}

# Generated at 2022-06-16 23:45:53.987498
# Unit test for function build_dep_data
def test_build_dep_data():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file_system import FileSystemCollector
    from ansible.module_utils.facts.collector.mount import MountCollector

# Generated at 2022-06-16 23:46:11.173886
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts import collector

    all_fact_subsets = collector.get_collector_subsets()

    # test no unresolved requires
    collector_names = ['all', 'network']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert not unresolved

    # test unresolved requires
    collector_names = ['all', 'network', 'facter']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)
    assert unresolved == set(['facter'])

    # test unresolved requires
    collector_names = ['all', 'network', 'facter', 'ohai']
    unresolved = find_unresolved_requires(collector_names, all_fact_subsets)

# Generated at 2022-06-16 23:46:19.474906
# Unit test for function select_collector_classes
def test_select_collector_classes():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    all_fact_subsets = {
        'network': [NetworkCollector],
        'system': [SystemCollector],
        'virtual': [VirtualCollector],
        'base': [BaseFactCollector],
    }

    collector_names = ['network', 'system', 'virtual', 'base']
    selected_collector_classes = select_collector_classes(collector_names, all_fact_subsets)
    assert len(selected_collector_classes) == 4

    collector_names

# Generated at 2022-06-16 23:46:28.937197
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collectors import network

    all_fact_subsets = {
        'network': [network.NetworkCollector],
        'network_all': [network.NetworkAllCollector],
    }

    assert find_unresolved_requires(['network'], all_fact_subsets) == set()
    assert find_unresolved_requires(['network_all'], all_fact_subsets) == set(['network'])
    assert find_unresolved_requires(['network', 'network_all'], all_fact_subsets) == set()



# Generated at 2022-06-16 23:46:38.910298
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # test with gather_subset=['!all', '!min']
    assert get_collector_names(gather_subset=['!all', '!min']) == frozenset()

    # test with gather_subset=['!all', '!min', 'min']

# Generated at 2022-06-16 23:46:51.460417
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        _fact_ids = set(['a', 'b'])
        name = 'a'

    class CollectorB(BaseFactCollector):
        _fact_ids = set(['b', 'c'])
        name = 'b'

    class CollectorC(BaseFactCollector):
        _fact_ids = set(['c', 'd'])
        name = 'c'

    class CollectorD(BaseFactCollector):
        _fact_ids = set(['d', 'e'])
        name = 'd'

    class CollectorE(BaseFactCollector):
        _fact_ids = set(['e', 'f'])
        name = 'e'

    class CollectorF(BaseFactCollector):
        _fact_ids = set(['f', 'g'])
        name

# Generated at 2022-06-16 23:46:59.504897
# Unit test for function collector_classes_from_gather_subset
def test_collector_classes_from_gather_subset():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.vmware
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.lxc
    import ansible.module_utils.facts.virtual.openvz
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.bhyve
    import ansible.module_utils.facts.virtual.hyperv

# Generated at 2022-06-16 23:47:11.234017
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])
    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])
    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])
    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set()

    all_fact_subsets = {
        'A': [CollectorA],
        'B': [CollectorB],
        'C': [CollectorC],
        'D': [CollectorD],
    }


# Generated at 2022-06-16 23:47:20.276171
# Unit test for function get_collector_names
def test_get_collector_names():
    # test with no args
    assert get_collector_names() == frozenset(['all'])

    # test with empty args
    assert get_collector_names(valid_subsets=frozenset(),
                               minimal_gather_subset=frozenset(),
                               gather_subset=None,
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozenset(['all'])

    # test with 'all'
    assert get_collector_names(valid_subsets=frozenset(['foo', 'bar']),
                               minimal_gather_subset=frozenset(['min']),
                               gather_subset=['all'],
                               aliases_map=defaultdict(set),
                               platform_info=None) == frozens

# Generated at 2022-06-16 23:47:31.518610
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    from ansible.module_utils.facts.collectors import (
        BaseFactCollector,
        NetworkFactCollector,
        HardwareFactCollector,
        VirtualizationFactCollector,
        CloudFactCollector,
        SystemFactCollector,
        NetworkFactCollector,
        DistributionFactCollector,
        LocalFactCollector,
    )
    collectors_for_platform = [
        NetworkFactCollector,
        HardwareFactCollector,
        VirtualizationFactCollector,
        CloudFactCollector,
        SystemFactCollector,
        NetworkFactCollector,
        DistributionFactCollector,
        LocalFactCollector,
    ]
    fact_id_to_collector_map, aliases_map = build_fact_id_to_collector_map(collectors_for_platform)
    assert fact_id_to_collector

# Generated at 2022-06-16 23:47:43.006277
# Unit test for function get_collector_names
def test_get_collector_names():
    # Test with no gather_subset
    assert get_collector_names() == frozenset(['all'])

    # Test with gather_subset=['all']
    assert get_collector_names(gather_subset=['all']) == frozenset(['all'])

    # Test with gather_subset=['!all']
    assert get_collector_names(gather_subset=['!all']) == frozenset(['min'])

    # Test with gather_subset=['!min']
    assert get_collector_names(gather_subset=['!min']) == frozenset(['all'])

    # Test with gather_subset=['!min', '!all']

# Generated at 2022-06-16 23:48:05.290894
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['fact1', 'fact2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['fact3', 'fact4'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['fact5', 'fact6'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['fact7', 'fact8'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        _fact_ids = set(['fact9', 'fact10'])


# Generated at 2022-06-16 23:48:15.592840
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class CollectorA(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['a', 'b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['b', 'c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        _fact_ids = set(['c', 'd'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        _fact_ids = set(['d', 'e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        _fact_ids = set(['e', 'f'])

    class CollectorF(BaseFactCollector):
        name = 'f'

# Generated at 2022-06-16 23:48:21.870584
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        _fact_ids = set(['collector1', 'collector1_alias'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        _fact_ids = set(['collector2', 'collector2_alias'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        _fact_ids = set(['collector3', 'collector3_alias'])

    class Collector4(BaseFactCollector):
        name = 'collector4'
        _fact_ids = set(['collector4', 'collector4_alias'])

    class Collector5(BaseFactCollector):
        name = 'collector5'

# Generated at 2022-06-16 23:48:33.868494
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'A'
        required_facts = set(['B'])

    class CollectorB(BaseFactCollector):
        name = 'B'
        required_facts = set(['C'])

    class CollectorC(BaseFactCollector):
        name = 'C'
        required_facts = set(['D'])

    class CollectorD(BaseFactCollector):
        name = 'D'
        required_facts = set(['E'])

    class CollectorE(BaseFactCollector):
        name = 'E'
        required_facts = set(['F'])

    class CollectorF(BaseFactCollector):
        name = 'F'
        required_facts = set()


# Generated at 2022-06-16 23:48:41.849675
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    class TestCollector(BaseFactCollector):
        name = 'test'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'
        _platform = 'Generic'
        def collect(self, module=None, collected_facts=None):
            return {'test3': 'test3'}

    class TestCollector4(BaseFactCollector):
        name = 'test4'

# Generated at 2022-06-16 23:48:54.249086
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set()


# Generated at 2022-06-16 23:49:04.722086
# Unit test for function build_fact_id_to_collector_map
def test_build_fact_id_to_collector_map():
    class TestCollector1(BaseFactCollector):
        _fact_ids = set(['test_fact_id_1'])
        name = 'test_collector_1'

    class TestCollector2(BaseFactCollector):
        _fact_ids = set(['test_fact_id_2'])
        name = 'test_collector_2'

    class TestCollector3(BaseFactCollector):
        _fact_ids = set(['test_fact_id_3'])
        name = 'test_collector_3'

    class TestCollector4(BaseFactCollector):
        _fact_ids = set(['test_fact_id_4'])
        name = 'test_collector_4'


# Generated at 2022-06-16 23:49:16.246156
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set(['b'])

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['c'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['d'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['e'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['f'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set(['g'])

    class CollectorG(BaseFactCollector):
        name = 'g'
       

# Generated at 2022-06-16 23:49:27.749408
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    import pytest
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class CollectorA(BaseFactCollector):
        name = 'a'
        required_facts = set()

    class CollectorB(BaseFactCollector):
        name = 'b'
        required_facts = set(['a'])

    class CollectorC(BaseFactCollector):
        name = 'c'
        required_facts = set(['a'])

    class CollectorD(BaseFactCollector):
        name = 'd'
        required_facts = set(['b', 'c'])

    class CollectorE(BaseFactCollector):
        name = 'e'
        required_facts = set(['d'])

    class CollectorF(BaseFactCollector):
        name = 'f'
        required_facts = set

# Generated at 2022-06-16 23:49:39.413898
# Unit test for function collector_classes_from_gather_subset

# Generated at 2022-06-16 23:50:07.105393
# Unit test for function find_unresolved_requires
def test_find_unresolved_requires():
    class Collector1(BaseFactCollector):
        name = 'collector1'
        required_facts = set(['collector2'])

    class Collector2(BaseFactCollector):
        name = 'collector2'
        required_facts = set(['collector3'])

    class Collector3(BaseFactCollector):
        name = 'collector3'
        required_facts = set()

    class Collector4(BaseFactCollector):
        name = 'collector4'
        required_facts = set(['collector5'])

    class Collector5(BaseFactCollector):
        name = 'collector5'
        required_facts = set(['collector6'])

    class Collector6(BaseFactCollector):
        name = 'collector6'
        required_facts = set(['collector7'])

   

# Generated at 2022-06-16 23:50:15.273750
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.hardware

    all_collector_classes = [
        ansible.module_utils.facts.collector.platform.LinuxDistribution,
        ansible.module_utils.facts.collector.platform.GenericPlatform,
        ansible.module_utils.facts.collector.network.Network,
        ansible.module_utils.facts.collector.hardware.DMI,
        ansible.module_utils.facts.collector.hardware.CPU,
    ]

    compat_platforms = [
        {'system': 'Linux'},
        {'system': 'Generic'},
    ]

    found_collectors = find_collectors

# Generated at 2022-06-16 23:50:26.468570
# Unit test for function find_collectors_for_platform
def test_find_collectors_for_platform():
    from ansible.module_utils.facts.collector.linux import LinuxFactCollector
    from ansible.module_utils.facts.collector.generic import GenericFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.collector.solaris import SolarisFactCollector
    from ansible.module_utils.facts.collector.bsd import BSDFactCollector
    from ansible.module_utils.facts.collector.windows import WindowsFactCollector
    from ansible.module_utils.facts.collector.freebsd import FreeBSDFactCollector
    from ansible.module_utils.facts.collector.openbsd import OpenBSDFactCollector