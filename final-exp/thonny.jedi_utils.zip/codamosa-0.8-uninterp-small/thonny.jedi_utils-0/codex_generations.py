

# Generated at 2022-06-26 07:23:21.408729
# Unit test for function get_script_completions
def test_get_script_completions():
    x = get_script_completions("im",0,2)
    assert len(x)==0


# Generated at 2022-06-26 07:23:26.561058
# Unit test for function get_definitions
def test_get_definitions():
    string_0 = 'def1\n'
    row_0 = 0
    column_0 = 9
    string_1 = 'file'
    var_0 = get_definitions(string_0, row_0, column_0, string_1)
    string_2 = 'def1\n'
    row_1 = 0
    column_1 = 9
    string_3 = 'file'
    var_1 = get_definitions(string_2, row_1, column_1, string_3)



# Generated at 2022-06-26 07:23:30.985588
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'pri'
    row = 1
    column = 4
    filename = 'C:\\Users\\Pavan\\Downloads\\pyjedi\\test.py'
    script = get_script_completions(source, row, column, filename)



# Generated at 2022-06-26 07:23:40.819081
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python.tree import Leaf
    source = """class Foo:
    def bar(self):
        return self.
    """

    completions = get_script_completions(source, row=3, column=18, filename='')
    assert len(completions) > 0

    def_item = completions[0]
    assert def_item.name == "bar"
    assert def_item.complete == def_item.name
    assert len(def_item.line) > 0
    assert def_item.parent == "Foo"
    assert def_item.full_name == "Foo.bar"
    assert isinstance(def_item.line, Leaf)
    assert def_item.type == "def"



# Generated at 2022-06-26 07:23:42.814003
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('import sys\nsys\n', 2, 1, '<stdin>') == []



# Generated at 2022-06-26 07:23:45.903862
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = {}
    source = '#co'
    expect = []
    actual = get_interpreter_completions(source, namespaces)
    assert expect == actual # Unable to get completion results


# Generated at 2022-06-26 07:23:53.437590
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:23:59.798849
# Unit test for function get_definitions
def test_get_definitions():
    source = """
foo = "bar"
foo.upper()
"""
    filename = "test.py"

    result = get_definitions(source, 3, 2, filename)
    assert result[0]._name.value == "upper"

    result = get_definitions(source, 1, 0, filename)
    assert result[0]._name.value == "foo"

# Generated at 2022-06-26 07:24:00.785264
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:24:11.813397
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Script

    script = Script(
        code="a = 5\nx = a",
        line=1,
        column=4,
        project=_get_new_jedi_project(None),
    )
    completions = script.complete(line=2, column=4)
    assert len(completions) == 1
    assert "a" in [c.name for c in completions]

# Generated at 2022-06-26 07:24:27.679464
# Unit test for function get_script_completions
def test_get_script_completions():

    import jedi

    completions = get_script_completions("a = float(", 0, 8, "", [])
    assert set([c.complete for c in completions]) == {"float()", "float(", "float"}
    assert completions[0].type == "function"
    assert completions[1].type == "function"
    assert completions[2].type == "statement"

    completions = get_script_completions("def foo(", 0, 8, "", [])
    assert set([c.complete for c in completions]) == {"foo()", "foo(", "foo"}
    assert completions[0].type == "function"
    assert completions[1].type == "function"
    assert completions[2].type == "statement"


# Generated at 2022-06-26 07:24:32.007859
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # testing with and without sys_path
    assert 'get_interpreter_completions' == get_interpreter_completions("get_in", [{}], [])[0]['name']
    assert 'get_interpreter_completions' == get_interpreter_completions("get_in", [{}])[0]['name']


# Generated at 2022-06-26 07:24:40.437961
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Unit test for get_script_completions
    """
    test_0 = "import math\nimport os\n\nif True:\n    ma"
    test_1 = "import math\nimport os\n\nif True:\n    ma"
    test_2 = None
    test_3 = None
    test_4 = None

    result_0 = get_script_completions(test_0, 4, 0, test_1, [])
    result_1 = get_script_completions(test_2, 4, 0, test_3, [])
    result_2 = get_script_completions(test_4, 4, 0, test_3, [])

    # should return 5 completions
    assert len(result_0) == 5
    assert result_0 == result_1

# Generated at 2022-06-26 07:24:47.587174
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Setup
    interpreter = get_interpreter_completions("", [], None)

    # Assertions
    assert (
        hasattr(interpreter, "completions")
        or hasattr(interpreter, "complete")
    ), "interpreter does not have method completions"



# Generated at 2022-06-26 07:24:57.640822
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.tree import Module
    from parso import parse
    from jedi.parser_utils import get_statement_of_position
    from jedi.api.classes import Completion
    import jedi
    from jedi.evaluate.helpers import FakeName

    # Test for python 3.x
    source = """
    class TestClass:
        def __init__(self, x):
            self.x = x

    def func(x, y):
        return x + y

    x = TestClass(10)
    y = TestClass(20)

    x.
    """

    namespaces = [{"TestClass": FakeName("TestClass", parse(source, 'x.py')),
                   "func": FakeName("func", parse(source, 'x.py'))}]

# Generated at 2022-06-26 07:25:06.084780
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    script = jedi.Script("import jedi\njedi.jedi.Script", 1, 15)

    script_defs = script.goto_definitions()
    print("script_defs: ", script_defs)
    print("script_defs[0].line: ", script_defs[0].line)
    print("script_defs[0].column: ", script_defs[0].column)
    print("script_defs[0].module_path: ", script_defs[0].module_path)
    print("script_defs[0].in_builtin_module: ", script_defs[0].in_builtin_module)
    print("script_defs[0].type: ", script_defs[0].type)



# Generated at 2022-06-26 07:25:06.735541
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:25:11.010207
# Unit test for function get_script_completions
def test_get_script_completions():
    source = '''x.y.z'''
    row = 0
    column = 1
    filename = 'test1.txt'
    completions = get_script_completions(source, row, column, filename)
    if len(completions) != 4:
        raise Exception('Failed to get completions')



# Generated at 2022-06-26 07:25:16.004476
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    sys_path = None
    source = "if True:\n    pass"
    namespaces = [{}]
    assert get_interpreter_completions(source, namespaces, sys_path) == _tweak_completions(jedi.Interpreter(source, namespaces).completions())


# Generated at 2022-06-26 07:25:28.327424
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return
    # Setup
    source = 'import os\nos.makedirs("/tmp/abc")'
    namespaces = []
    sys_path = []

    # Exercise
    result = get_interpreter_completions(source, namespaces, sys_path)

    # Verify
    assert (ThonnyCompletion(name="os", complete="os", type="module", description=None, parent=None, full_name="os")) == result[0]
    assert (ThonnyCompletion(name="abspath", complete="abspath", type="function", description=None, parent="os", full_name="os.abspath")) == result[2]

# Generated at 2022-06-26 07:25:56.277841
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")
        var_0 = get_definitions("import sys\n\nsys.stdout.content", 0, 0, "")


# Generated at 2022-06-26 07:26:01.582878
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys

    sys.path.insert(1, os.path.dirname(os.path.abspath(__file__)))
    import test.jedi_utils_test

    assert not test.jedi_utils_test.test_get_interpreter_completions("interp_compl")


# Generated at 2022-06-26 07:26:03.120797
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # TODO: write me
    pass


# Generated at 2022-06-26 07:26:11.711815
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    from thonny.plugins.jedi_backend import utils

    float_0 = u"2.2"
    int_0 = None
    str_0 = "b'AGICAwQHCAkKDAsNDxAQERISExUUFRgW'8.0"
    var_0 = utils.get_interpreter_completions(float_0, int_0, str_0)
    int_1 = "abc"
    str_1 = None
    var_1 = utils.get_interpreter_completions(int_1, str_1, int_0)
    str_2 = "int"
    var_2 = utils.get_interpreter_completions(str_2, int_0, str_1)

# Generated at 2022-06-26 07:26:14.699927
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("b=5\nx.y.", [
        {"x": 0},
        {'time': time}],
        []
    )
    return completions



# Generated at 2022-06-26 07:26:15.497223
# Unit test for function get_definitions

# Generated at 2022-06-26 07:26:24.565635
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso
    import jedi
    from parso.python.tree import Leaf, Name, NamePart

    try:
        from parso.tree import import_from, alias
    except ImportError:
        from parso.python.tree import import_from, alias

    float_0 = "import math\nfrom math import sqrt\nmath.sqrt(8)\n"
    var_0 = parse_source(float_0)

    def test_func_0():
        var_1 = var_0
        var_2 = row = var_1.children[2].children[0].children[0].get_code_range()[0]
        var_3 = column = var_1.children[2].children[0].children[0].get_code_range()[1]
        var_4 = filename = ""
       

# Generated at 2022-06-26 07:26:33.036140
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    from jedi.evaluate import imports
    from jedi.evaluate import representation as er
    from jedi.evaluate import helpers
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.context import Context
    from jedi import settings
    import sys
    import os
    import struct
    import platform
    sys_path = sys.path


# Generated at 2022-06-26 07:26:38.715090
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_cached_code
    from jedi.api.helpers import get_cached_stmt
    var_0 = test_get_script_completions()
    var_1 = var_0.get_script_completions()
    var_2 = "".join(var_1)


# Generated at 2022-06-26 07:26:49.399738
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter

    # Completions with no namespace
    namespaces = []
    line = 0
    column = 0
    source = '''\
    import os
    import sys
    import re
    def foo():
        "str"
        123
    '''
    # str.replace(old, new[, count])
    # str.split(sep=None, maxsplit=-1)
    # str.splitlines([keepends])
    # str.startswith(prefix[, start[, end]])
    # str.rstrip([chars])
    # str.rsplit(sep=None, maxsplit=-1)
    # str.rpartition(sep)
    # str.rfind(sub[, start[, end]])
    # str.replace(

# Generated at 2022-06-26 07:27:16.591190
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    completions = Script("foo", 1, 1).completions()
    assert len(completions) > 0
    assert completions[0].name == "foo"
    assert completions[0].complete == "foo"


# Generated at 2022-06-26 07:27:19.168560
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-26 07:27:27.271442
# Unit test for function get_definitions
def test_get_definitions():
    import os

    try:
        import tests.test_utils

        tests.test_utils.configure_test_sys_path()
        import get_definitions_test_data
    except ImportError:
        return

    from jedi import Script

    test_dir = os.path.dirname(get_definitions_test_data.__file__)
    for file_name in os.listdir(test_dir):
        if file_name.endswith(".py"):
            script = Script(path=os.path.join(test_dir, file_name))
            test_doc = get_definitions_test_data.__dict__[file_name.split(".")[0]]
            test_doc = test_doc.strip()
            lines = test_doc.splitlines()

# Generated at 2022-06-26 07:27:28.976953
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:27:38.049339
# Unit test for function get_definitions
def test_get_definitions():
    def get_definitions(source, row, column, filename):
        import jedi
        if _using_older_jedi(jedi):
            script = jedi.Script(source, row, column, filename)
            return script.goto_definitions()
        else:
            script = jedi.Script(code=source, path=filename)
            return script.infer(line=row, column=column)

    float_0 = "dummy = float()"
    var_0 = get_definitions(float_0, 0, 0, "test_case_0")
    var_0 = get_definitions(float_0, 0, 0, "test_case_0")
    var_0 = get_definitions(float_0, 0, 0, "test_case_0")



# Generated at 2022-06-26 07:27:43.789489
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test if input is empty parameter
    expected_output = "Unable to get completions, input is empty parameter"
    try:
        get_interpreter_completions("", [])
    except Exception as e:
        assert type(e) == Exception
        assert str(e) == expected_output

    # Test if input is not empty parameter
    expected_output = []
    try:
        get_interpreter_completions("", [{"x": 1}])
    except Exception as e:
        assert type(e) == Exception
        assert str(e).startswith("TypeError: ")

    # Test if input is not empty parameter
    expected_output = []

# Generated at 2022-06-26 07:27:48.955272
# Unit test for function get_script_completions
def test_get_script_completions():
    completion_0 = get_script_completions('def f():\n    ret', 1, 10, '<string>')
    assert completion_0[0].name == 'return'
    assert completion_0[0].complete == 'return '
    assert completion_0[0].type == 'statement'
    assert completion_0[0].description.startswith(
        'return [(expression)]'
    ), "Expected \"return [(expression)]\", got " + completion_0[0].description
    assert completion_0[0].parent == 'f'


# Generated at 2022-06-26 07:27:50.639157
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:27:59.003514
# Unit test for function get_definitions
def test_get_definitions():
    var_0 = "def foo():\n    pass\n\nfoo()"
    var_1 = get_definitions(var_0, 5, 1, None)
    assert len(var_1) == 1
    assert var_1[0].description == 'foo()\n\nReturn None.'
    assert var_1[0].name == 'foo()'
    assert var_1[0].complete == 'foo()'
    assert var_1[0].type == 'function'
    assert var_1[0].parent == 'foo'
    assert var_1[0].full_name == 'foo'


# Generated at 2022-06-26 07:28:07.785681
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [
        {"name": "test", "type": "module", "module_path": "test", "is_builtin": True}
    ]
    source = "test. "
    if _using_older_jedi(jedi):
        try:
            interpreter = jedi.Interpreter(source, namespaces, sys_path=["the", "path"])
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            interpreter = jedi.Interpreter(source, namespaces)

# Generated at 2022-06-26 07:28:43.996245
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from math import *\nf"
    row = 2
    column = 2
    filename = "test.py"
    sys_path = ['/usr/lib/python3.6', '/usr/lib/python3.6/plat-x86_64-linux-gnu', '/usr/lib/python3.6/lib-dynload', '/home/user/.local/lib/python3.6/site-packages', '/usr/local/lib/python3.6/dist-packages', '/usr/lib/python3/dist-packages']
    script_completions_0 = get_script_completions(source, row, column, filename, sys_path)
    return


# Generated at 2022-06-26 07:28:46.784669
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    interpreter_0 = None
    interpreter_1 = get_interpreter_completions(interpreter_0, interpreter_0)


# Generated at 2022-06-26 07:28:55.370293
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Bug #121 https://bitbucket.org/plas/thonny/issues/121/
    if get_interpreter_completions("_|_", [], None) != []:
        raise ValueError

    if get_interpreter_completions("_|_", [{"name": "cls", "value": 1}], None) != [{"type": "integer", "name": "cls", "complete": "cls"}]:
        raise ValueError

    if get_interpreter_completions("_|_", [{"name": "cls", "value": 1}], None) != [{"type": "integer", "name": "cls", "complete": "cls"}]:
        raise ValueError


# Generated at 2022-06-26 07:28:58.798649
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    float_0 = None
    var_0 = get_interpreter_completions(float_0, [float_0])
    float_1 = None
    var_1 = get_interpreter_completions(float_1, [float_1])


# Generated at 2022-06-26 07:29:05.714936
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    import jedi
    path = 'test_0_source.py'
    with open(path, 'r') as f:
        source = f.read()
    row = 0
    column = 0
    filename = 'test_0_source.py'
    func_node = get_definitions(source, row, column, filename)
    assert func_node[0].name == 'test_0_source.py'
    assert func_node[0].module_name == 'test_0_source'
    assert func_node[0].module_path == '/Users/pritam/Desktop/Python/test/test_0_source.py'
    assert func_node[0].line == 1
    assert func_node[0].column == 1
    assert func_node[0].in_builtin_module()

# Generated at 2022-06-26 07:29:09.489150
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "a=2\na.c"
    int_0 = 0
    int_1 = 0
    str_1 = "test_case_0"
    list_0 = []
    assert get_script_completions(str_0, int_0, int_1, str_1, list_0) == []


# Generated at 2022-06-26 07:29:16.448509
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock
    from thonny import get_shell

    Shell = get_shell(None)
    Shell._load_standard_lib = Mock()
    Shell.exec_code = Mock()
    Shell.locals_to_be_sent_to_subprocess = Mock()
    Shell.should_run_module = Mock()
    Shell.has_changed = False


# Generated at 2022-06-26 07:29:21.769502
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("import os; os.path.join('a', 'b')", 25, 19, "x.py")
    else:
        script = jedi.Script("import os; os.path.join('a', 'b')", path="x.py")
        return script.infer(line=1, column=26)
    return script.goto_definitions()

# Generated at 2022-06-26 07:29:24.878114
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = [{}]
    var_1 = "import os\n"
    var_2 = get_interpreter_completions(var_1, var_0)
    assert isinstance(var_2, list)


# Generated at 2022-06-26 07:29:28.913934
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.evaluate.base_context import Context

    c = Context()
    assert get_script_completions(c, 5, 5, float_0)
    assert get_script_completions(c, int_0, var_0, float_0)
    assert get_script_completions(c, int_0, 5, float_0)
    assert get_script_completions(c, int_0, var_0, float_0)

# Generated at 2022-06-26 07:29:55.389326
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('a = 1\na.index()', 1, 3, '', None) == ['index=']


# Generated at 2022-06-26 07:29:59.010247
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    modules = [{"test":"test"}]
    code = "import test"
    completions = get_interpreter_completions(code, modules)
    assert completions[0].name == "test"


# Generated at 2022-06-26 07:30:00.946609
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position

    get_statement_of_position(None, 0)



# Generated at 2022-06-26 07:30:01.708438
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert True



# Generated at 2022-06-26 07:30:02.574169
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi



# Generated at 2022-06-26 07:30:05.891318
# Unit test for function get_script_completions
def test_get_script_completions():
    script = "def foo(a,b,c) \nif a == 1 and b == 2 and c == 3: \n\tprint(a * b * c)\n\t"
    d = get_script_completions(script, 2, 28, "a.py")
    assert len(d) > 0
    

# Generated at 2022-06-26 07:30:07.956744
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _test_jedi_utils import test_get_interpreter_completions
    test_get_interpreter_completions(get_interpreter_completions)


# Generated at 2022-06-26 07:30:11.954700
# Unit test for function get_definitions
def test_get_definitions():
    source = '''def foo():\n    print(1)\nfoo()'''
    row = 2 # according to the code
    column = 1 # according to the code
    filename = ''
    assert get_definitions(source, row, column, filename) != []
    # Uncomment the following lines to visualize the result.
    # for i in get_definitions(source, row, column, filename):
        # print(i.name, i.complete, i.line, i.column)


# Generated at 2022-06-26 07:30:12.796316
# Unit test for function get_definitions
def test_get_definitions():
    assert(True)



# Generated at 2022-06-26 07:30:22.628474
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("def f", 0, 6, "") == []
    assert get_definitions("f", 0, 0, "") == []
    assert get_definitions('import ', 0, 7, "") == []
    assert get_definitions("def f():\n    pass\nf()", 3, 0, "") == []
    assert get_definitions("def f():\n    pass\nf()", 1, 4, "") == []
    assert get_definitions("def f():\n    pass\nf()", 3, 4, "") == []
    assert get_definitions("def f():\n    pass\nf()", 1, 8, "") != []
    assert get_definitions("def f():\n    pass\nf()", 3, 8, "") != []

# Unit test

# Generated at 2022-06-26 07:30:47.206028
# Unit test for function get_definitions
def test_get_definitions():
    filename = "test.py"

# Generated at 2022-06-26 07:30:54.880139
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def try_completion(source, namespace, expected_type, expected_name):
        results = get_interpreter_completions(source, namespace)
        assert len(results) == 1
        actual_completion = results[0]
        actual_type = actual_completion.type
        actual_name = actual_completion.name

        assert actual_type == expected_type
        assert actual_name == expected_name

    try_completion("int", [], "int", "int")
    try_completion("int", [globals()], "int", "int")
    try_completion("re.", [globals()], "function", "re.match")

    import re

    try_completion("re.", [globals(), re.__dict__], "function", "re.match")
    try_com

# Generated at 2022-06-26 07:30:56.530265
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    from jedi.evaluate import Evaluator


# Generated at 2022-06-26 07:30:58.299541
# Unit test for function get_script_completions
def test_get_script_completions():
    assert _tweak_completions("test 1") == "test 1"


# Generated at 2022-06-26 07:31:00.812587
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    sys_path = ['c:\\test_folder']
    namespaces = []
    completions = get_interpreter_completions('', namespaces, sys_path)
    assert completions != None
    assert len(completions) == 0


# Generated at 2022-06-26 07:31:08.385195
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # python version: 3.5.5
    # jedi version: 0.16.0
    # parso version: 0.6.1
    # key: value
    namespace = {}
    source_code = "float_0 = None\nvar_0 = parse_source(float_0)\nvar_0.get_interpreter_completions(source_code, namespace)"
    # name: value
    row = 0
    column = 0
    filename = ""
    sys_path = None

# Generated at 2022-06-26 07:31:18.445094
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Jedi version control and test case
    import jedi
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]

    # Test simple case
    test_input = """
a=3
b=a

b==
"""
    result = get_interpreter_completions(test_input, [], None)
    if jedi.__version__[:4] == "0.13":
        assert len(result) == 1
    else:
        assert len(result) == 2
    assert result[0].name == "!="
    assert result[0].complete == "!="
    assert result[0].type == "operator"

    # Test list comprehension case

# Generated at 2022-06-26 07:31:26.223591
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test a normal 'basic' case
    print("EXECUTING test_get_interpreter_completions")
    int_0 = 0
    float_0 = float(int_0)

    interpreter_0 = get_interpreter_completions(float_0, [{}])
    var_0 = len(interpreter_0)
    print("EXPECTED: length of completions, GOT: %d" % var_0)
    dict_0 = {float_0}
    var_1 = len(dict_0)
    print("EXPECTED: length of set, GOT: %d" % var_1)
    # Test a non-comprehensive 'basic' case
    int_1 = 1
    float_1 = float(int_0)

    interpreter_0 = get_interpreter

# Generated at 2022-06-26 07:31:30.848697
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions('import logging\nlogging.', [])
    assert len(completions) == 5

    completions = get_interpreter_completions('import logging\nlogging.foo_', [])
    assert len(completions) == 0

# Generated at 2022-06-26 07:31:37.482140
# Unit test for function get_script_completions
def test_get_script_completions():
    from types import ModuleType
    from jedi import Script

    script = Script('from math import cei', 1, 11, '/tmp/test.py')
    completion = script.completions()[0]
    assert completion.name == 'ceil'
    assert completion.complete == 'ceil('
    assert completion.type == 'function'
    assert completion.description == 'ceil(${1:x})'
    assert isinstance(completion.parent, ModuleType)
    assert completion.parent.__name__ == 'math'
    assert completion.full_name == 'math.ceil'


# Generated at 2022-06-26 07:32:45.293267
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    completions = get_script_completions(
        source="", row=1, column=1, filename="", sys_path=[]
    )
    assert completions == []


# Generated at 2022-06-26 07:32:45.950701
# Unit test for function get_definitions

# Generated at 2022-06-26 07:32:51.161687
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = '''def f(a, b):
    a = 1
    return a
a = 0
f(a, 3)
'''
    row = 9
    column = 0
    namespaces = []
    result = get_interpreter_completions(source, namespaces, sys_path="test_path")
    expected = []
    assert result == expected


# Generated at 2022-06-26 07:33:00.952017
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from thonny.globals import get_workbench

    view = get_workbench().get_editor_notebook().active_editor_tab().textwidget
    view.insert('1.0', 'def f():\n    print(a')
    iterpreter = Interpreter('a', [{'a': 1}])
    completions = get_interpreter_completions(view.get('1.0', 'insert'), [{'a': 1}])
    assert (len(completions) == 0)
    view.delete('1.0', 'end')
    view.insert('1.0', 'a = 10\ndef f():\n    print(a')
    completions = get_interpreter_complet

# Generated at 2022-06-26 07:33:06.762887
# Unit test for function get_definitions

# Generated at 2022-06-26 07:33:15.117560
# Unit test for function get_script_completions
def test_get_script_completions():
    if _using_older_jedi(jedi):
        print("Older jedi. No test for get_script_completions")
    else:
        # This tests that the additional sys_path, if provided (see issue #630), works as
        # expected. Without this, the completion of import_relative_name in the below
        # source will fail.
        source = 'import import_relative_name'
        row = 0
        column = 20
        filename = "test.py"
        sys_path = "/home/david/projects/jedi/jedi"

        completions = get_script_completions(source, row, column, filename, sys_path)

        assert (completions[0].name == "import_relative_name")
    return

