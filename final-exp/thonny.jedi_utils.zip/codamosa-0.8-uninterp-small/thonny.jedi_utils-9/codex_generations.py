

# Generated at 2022-06-26 07:23:38.162176
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "str"
    str_1 = str_0 + " + "
    int_0 = 1
    int_1 = -3
    float_0 = float(int_0)
    float_1 = float(int_1)
    str_2 = str_0 + str_0
    list_0 = []
    dict_0 = {}
    dict_1 = dict_0.copy()
    str_3 = str_0.join(list_0)
    assert get_script_completions((str_0),
                                  int_0,
                                  int_0,
                                  (str_1),
                                  sys_path=[str_0, str_1]) == (str_0, str_1)

# Generated at 2022-06-26 07:23:44.379005
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    # Keep these, they are used in test
    all_completions = []
    all_complete = []
    all_files = []

    import os
    import jedi
    from thonny.misc.pathutils import get_thonny_python_executable

    if _using_older_jedi(jedi):
        test_dir = "C:/Users/Fooman/Documents/GitHub/thonny_legacy_jedi"
        root = os.path.join(test_dir, "jedi_tests")
        sys_path = [os.path.join(root, "stubs"), "."]

# Generated at 2022-06-26 07:23:52.657779
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # This method only gets executed if "python3 -m unittest jedi_utils.py" is executed
    # If run from inside thonny, it is inside of the unittest package,
    # which prevents the jedi package from being imported
    # A workaround is to run the test suite as "python3 /path/to/jedi_utils.py"
    # As a side-effect, the original debugger could be called to debug this method,
    # which wouldn't work inside of the unittest package
    filename = "test_jedi_utils.py"
    source = "import re\nx = re.compile\nx('abc')\n"
    completions = get_script_completions(source, 3, 9, filename)
    assert len(completions) > 0

    completions = get_interpreter

# Generated at 2022-06-26 07:24:03.155683
# Unit test for function get_script_completions
def test_get_script_completions():
    name_1 = "a"
    int_1 = 10
    script_1 = "a=int_1"
    source_1 = script_1
    result_1 = get_script_completions(source_1, 1, 2, "thonny/jedi_utils.py")
    def_1 = result_1[0]
    assert def_1.name == name_1
    assert def_1.complete == "a="
    assert def_1.type == "statement"
    assert def_1.description == "a"
    assert def_1.parent == "<module>"
    assert def_1.full_name == "a"


# Generated at 2022-06-26 07:24:10.187487
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    # TODO: deal with parso changes
    if _using_older_jedi(Interpreter):
        from parso import ParserSyntaxError

        try:
            parse_source("")
        except ParserSyntaxError as e:
            print(e)
    else:
        from parso.python import ParserSyntaxError

        try:
            parse_source("")
        except ParserSyntaxError as e:
            print(e)



# Generated at 2022-06-26 07:24:11.606142
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_42 = get_interpreter_completions()


# Generated at 2022-06-26 07:24:13.956359
# Unit test for function get_script_completions
def test_get_script_completions():
    pass
    # TODO: write a unit test for get_script_completions


# Generated at 2022-06-26 07:24:21.208461
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api import Script

        script = Script('import matp', path='/home/thonny/')
        completions = script.completions()
    else:
        from jedi.api import Script

        script = Script(code='import matp', path='/home/thonny/')
        completions = script.complete(line=1, column=9)
    assert completions is not None



# Generated at 2022-06-26 07:24:28.563981
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'for i in range(10):\n    print(i, end="*")\n'
    namespaces = [
        {
            "end": "",
            "i": "int(1)",
            "print": "<built-in function print>",
            "range": "<class 'range'>",
        }
    ]
    completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-26 07:24:35.551167
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    # Test for case: 0
    from parso.python import tree
    from parso.python import errors
    from parso.python import merge
    from parso.python.tree import Module
    from parso.python.tree import PythonNode
    from parso.python.tree import PythonErrorNode
    from parso.python.tree import ErrorLeaf
    from parso.python.tree import ErrorNode
    from parso.python.tree import PythonLeaf
    from parso.python.tree import Leaf
    from parso import parse
    from parso.python.tree import search_ancestor_with_type
    from parso.python.tree import type_from_value
    from parso.python.tree import PythonErrorLeaf
    from parso.python.tree import BaseNode

# Generated at 2022-06-26 07:24:59.442636
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        raise NotImplementedError("This test is only available for recent Jedi")
    else:
        source = 'import jedi\njedi.\n'
        completions = get_interpreter_completions(source, [])
        assert any(c.name == "Script" for c in completions)


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--pytest":
        pytest.main(__file__)
    else:
        import timeit

        print(timeit.timeit(test_case_0, number=10000))

# Generated at 2022-06-26 07:25:03.617515
# Unit test for function get_script_completions
def test_get_script_completions():
    # TODO: unit test method
    variables = {}
    test_code = 'def foo1():\n  xxx = 3\n  xxx.upper()\n\ndef foo2():\n   xxx.upper()'
    test_code = 'import math\nmath'
    get_script_completions(test_code, 3, 2, "<string>")
    get_script_completions(test_code, 5, 8, "<string>")


# Generated at 2022-06-26 07:25:09.220505
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = {}
    source = 'a = "string"'
    sys_path = ["/home/thonny/workdir/thonny/thonny/plugins/thonny_jedi/jedi_utils.py"]
    var_0 = get_interpreter_completions(source, namespaces, sys_path)
    var_1 = []
    for completion in var_0:
        if completion.type == "statement":
            var_1.append(completion)
        else:
            pass
    var_2 = []
    for completion in var_0:
        if completion.type == "function":
            var_2.append(completion)
        else:
            pass
    var_3 = []
    for completion in var_0:
        if completion.parent == "string":
            var_

# Generated at 2022-06-26 07:25:10.298083
# Unit test for function get_definitions

# Generated at 2022-06-26 07:25:16.546144
# Unit test for function get_script_completions
def test_get_script_completions():
    var_1 = 'TEST_STRING'
    var_2 = get_script_completions(var_1)
    assert var_2 == [
        ThonnyCompletion(
            name='TEST_STRING',
            complete='TEST_STRING',
            type=None,
            description=None,
            parent=None,
            full_name='TEST_STRING',
        )
    ]


# Generated at 2022-06-26 07:25:18.214359
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    int_0 = -7
    var_0 = get_interpreter_completions(int_0, int_0)


# Generated at 2022-06-26 07:25:25.448558
# Unit test for function get_definitions
def test_get_definitions():
    var_0 = "a"
    source = "import sys\n\nsys.path"
    row = 2
    column = 2
    filename = None
    var_1 = get_definitions(source, row, column, filename)
    var_2 = var_1[0].type
    expected = "module"
    assert var_2 == expected


# Generated at 2022-06-26 07:25:29.804182
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    from jedi import Script
    from parso.python.tree import Leaf

    test_leaf = Leaf(0, 0, "test_leaf", False)
    completions = [ThonnyCompletion("jedi_completions", "", 0, "", None, "")]
    with patch.object(Script, "completions") as mock_completions:
        mock_completions.return_value = completions
        with patch.object(Script, "_get_module") as mock_get_module:
            mock_get_module.return_value = test_leaf
            result = get_script_completions("", 1, 1, "")
            assert result == completions

    # Using older jedi (pre 0.18)

# Generated at 2022-06-26 07:25:33.149580
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions('int_0 = 2+1\nint_1 = int_0.numerator', 0, 9, 'test')
    assert completions[0].name == 'numerator'


# Generated at 2022-06-26 07:25:43.512953
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_shell
    from thonny.languages.python import PythonProxy
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from tkinter import Tk, TclError
    import jedi
    import parso
    import urllib.request
    import urllib.error
    import webbrowser
    import os
    import sys

    # Set up Tk
    root = Tk()
    root.withdraw()

    # Initialize variables
    # Param: source: the code source.
    # Param: row: The row index.
    # Param: column: The column index.
    # Param: filename: The file name
    # Param: sys_path: The system path
    source = "import os\n"


# Generated at 2022-06-26 07:26:08.547739
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    test_completions = get_interpreter_completions(
        "from math import *\nfrom math import ", [{"namespace": {}}, {"namespace": math}]
    )

# Generated at 2022-06-26 07:26:14.090209
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    # Base change
    result = get_definitions("from foo import \n", 0, 0, "test")
    print(result)
    assert(isinstance(result, jedi.api.classes.Definition))
    assert(result.module_name == "foo")
    assert(result.name == "foo")
    assert(result.line == 0)
    

# Generated at 2022-06-26 07:26:16.408615
# Unit test for function get_script_completions
def test_get_script_completions():
    int_0 = 900771
    var_0 = get_script_completions(int_0, int_0, int_0, int_0)


# Generated at 2022-06-26 07:26:22.070806
# Unit test for function get_script_completions
def test_get_script_completions():
    # Input parameters
    source = """func"""
    row = 1
    column = 5
    filename = "test.py"
    sys_path = ["D:\\Thonny\\thonny\\updater"]

    # Expected output
    expected_result = []

    actual_result = get_script_completions(source, row, column, filename, sys_path)
    assert actual_result == expected_result



# Generated at 2022-06-26 07:26:24.342290
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree
    from jedi import Script
    assert_equals = "__builtins__"
    assert Script("__builtins__").definitions()[0].full_name == assert_equals


# Generated at 2022-06-26 07:26:29.577090
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source_0 = "b = [x for x in range(10)]"
    row_0 = 0
    column_0 = 9
    filename_0 = "test_jedi.py"

    source_1 = "b = [x for x in range(10)]"
    row_1 = 0
    column_1 = 10
    filename_1 = "test_jedi.py"

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert (get_script_completions(source_0, row_0, column_0, filename_0) == ['for',
                'b', 'range'])

# Generated at 2022-06-26 07:26:31.979194
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        assert get_script_completions("""
import math
math.
""", 3, 6, "test.py")
    except:
        raise AssertionError("Empty error message")


# Generated at 2022-06-26 07:26:33.251968
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("print()", 0, 0, "") is not None


# Generated at 2022-06-26 07:26:45.569615
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.parser.python import tree
    from jedi.parser import ParserSyntaxError
    import parso
    from parso.python import tree as parso_tree

    float_0 = -1.28E-05
    float_1 = 0.0
    int_0 = -18
    int_1 = -18
    int_2 = -7
    int_3 = 0
    int_4 = -4
    int_5 = -5
    int_6 = -2
    int_7 = 1
    str_0 = 'Oe'
    str_1 = 'o'
    str_2 = '0'
    str_3 = '1'

    # Testing branch coverage
    # Functional coverage: 100%

# Generated at 2022-06-26 07:26:53.591711
# Unit test for function get_script_completions
def test_get_script_completions():
    # Make the following code testable
    """
    import math
    import random
    import string
    """

    source = """
from math import *
import random
from string import *
from random import choice
from random import *
from math import floor
from string import ascii_letters
a = ascii_letters
from math import 0
"""
    import jedi

    script = jedi.Script(source, 1, 1, "")
    completions = script.completions()
    import jedi

    script = jedi.Script(source, 1, 1, "")
    completions = script.completions()
    import jedi

    script = jedi.Script(source, 1, 1, "")
    completions = script.completions()
    import jedi


# Generated at 2022-06-26 07:27:13.333563
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    script = jedi.Script(source = """
                       def foo():
                           foo().foo
                       """)

    completions = script.complete()
    print(completions)


# Generated at 2022-06-26 07:27:15.630558
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("", 1, 1, "")
    assert result is not None


# Generated at 2022-06-26 07:27:22.504651
# Unit test for function get_script_completions
def test_get_script_completions():
    # Python code for test_get_script_completions
    script_0 = '''script_0'''
    row_0 = 72
    column_0 = 1
    filename_0 = "script_0.py"
    sys_path_0 = None
    res_0 = get_script_completions(script_0, row_0, column_0, filename_0, sys_path_0)



# Generated at 2022-06-26 07:27:26.321019
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Setup
    source = "import math\nmath.sin"
    namespaces = [{}]

    # Exercise
    completions = get_interpreter_completions(source, namespaces)

    # Verify
    assert len(completions) == 2
    names = [comp.name for comp in completions]
    assert "sin(" in names
    assert "sinh(" in names

# Generated at 2022-06-26 07:27:37.067500
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    if "Thonny" in __name__:
        # this is being run as a part of tests
        # run jedi module
        import_jedi_module()
        jedi = sys.modules["jedi"]
    else:
        # test is being directly run - import jedi from path
        from importlib import reload
        import jedi

        reload(jedi)


# Generated at 2022-06-26 07:27:47.424865
# Unit test for function get_script_completions
def test_get_script_completions():
    source = u'import os\naval = os.at'
    row = 2
    column = 15
    filename = "test_file.py"
    result = get_script_completions(source, row, column, filename)
    assert any(c.type == "function" for c in result)
    assert any(c.type == "module" for c in result)
    source = u'import os\nget_script_completions(source, row, column, filename)\naval = os.at'
    row = 3
    column = 15
    result = get_script_completions(source, row, column, filename)
    assert any(c.type == "function" for c in result)
    assert any(c.type == "module" for c in result)

# Generated at 2022-06-26 07:27:59.164302
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "import json\njson.lo"
    str_1 = "json.lo"
    line_0 = 1
    column_0 = 17
    str_2 = "dummy"

    # Call function "get_script_completions"
    result = get_script_completions(str_0, line_0, column_0, str_2)
    print("Output for function get_script_completions:")
    print("    %s" % result)

    # Call function "get_script_completions"
    result = get_script_completions(str_1, line_0, column_0, str_2)
    print("Output for function get_script_completions:")
    print("    %s" % result)


# Generated at 2022-06-26 07:28:02.647547
# Unit test for function get_definitions
def test_get_definitions():
    # Cases 0 - 1
    int_0 = __name__
    int_1 = __package__
    str_0 = '""'
    str_1 = ''
    str_2 = '""""""""""'


# Generated at 2022-06-26 07:28:06.133712
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import base64"
    row = 0
    column = 0
    filename = ""
    completions = get_script_completions(source, row, column, filename)
    assert completions[0].name == "base64"  # Ensure first completion is 'base64'



# Generated at 2022-06-26 07:28:11.111792
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.representation import Instance

    namespaces = [
        {
            "float_0": Instance(
                "__builtin__", "float", datetime.datetime(2019, 2, 12, 20, 50, 44, 243314)
            ),
            "var_0": Instance(
                "parso",
                "Module",
                datetime.datetime(2019, 2, 12, 20, 50, 44, 132311),
                ("__file__",),
            ),
        }
    ]

    with pytest.raises(ValueError):
        get_interpreter_completions("", [], [])

# Generated at 2022-06-26 07:28:51.465678
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi


# Generated at 2022-06-26 07:28:58.797710
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert not get_interpreter_completions("", [], [])
    assert not get_interpreter_completions("a", [], [])
    assert not get_interpreter_completions("a.", [], [])
    assert get_interpreter_completions("a", [{"x": "y"}], [])
    assert get_interpreter_completions("a.", [{"x": "y"}], [])

if __name__ == "__main__":
    for test_case in [
        test_case_0
    ]:
        test_case()

# Generated at 2022-06-26 07:29:04.738464
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source_0 = set()
    source_0.add("@")
    source_1 = ()
    source_1 = get_interpreter_completions(source_0, source_1)
    test_value_0 = get_script_completions("-1", 4, 12, "", "", "")
    test_value_1 = get_script_completions("1", 4, 12, "", "", "")
    var_0 = parse_source("@")
    var_1 = parse_source("_")
    test_value_2 = get_script_completions("@", 0, 0, "", "", "")
    var_2 = get_interpreter_completions("_", [locals()])
    var_3 = parse_source("_")
    test_value_3

# Generated at 2022-06-26 07:29:09.317816
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    try:
        int_0 = parse_source("15").end_pos <= jedi.__version__[:4]
        def_0 = get_script_completions("s = 1", int_0, 1, "test", "/home/user1/regression_output/file")
    except Exception as e:
        print(str(e))
    else:
        assert False



# Generated at 2022-06-26 07:29:13.046749
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    import jedi

    namespaces_0 = [ {"f"} ]
    parso_0 = parso.parse("x = f")
    var_0 = get_interpreter_completions(parso_0, namespaces_0)


# Generated at 2022-06-26 07:29:15.311916
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    int_0 = -20
    var_0 = get_interpreter_completions(int_0, None)


# Generated at 2022-06-26 07:29:18.201120
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Testing get_interpreter_completions")
    namespaces = [{'a': 1, 'b': 2}]
    source = 'a'
    completions = get_interpreter_completions(source, namespaces)
    assert completions[0].complete == 'a'


# Generated at 2022-06-26 07:29:27.354673
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    from jedi.api.classes import Completion

    # TODO: check for "str" and "int" completions
    script = Script("def foo(self, foo=None):\n    self.foo = foo\n\nassert i")
    completions = script.complete()
    result = get_definitions("def foo(self, foo=None):\n    self.foo = foo\n\nassert i", line=4, column=11, filename="")
    assert isinstance(result[0], Completion)
    assert result[0].line == 3
    assert result[0].column == 4

    result = get_definitions("import math\nmath.as", line=2, column=8, filename="")
    assert isinstance(result[0], Completion)

# Generated at 2022-06-26 07:29:33.463289
# Unit test for function get_script_completions
def test_get_script_completions():
    input_1 = "import numpy\nnumpy.array([])"
    row_1 = 1
    column_1 = 14
    filename_1 = "test_file"
    test_1 = ["array"]

    result = get_script_completions(input_1, row_1, column_1, filename_1)
    output = []

    for entry in result:
        output.append(entry["name"])

    assert output == test_1



# Generated at 2022-06-26 07:29:34.320303
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:30:55.196250
# Unit test for function get_definitions
def test_get_definitions():
    assert _get_definitions() == ("{\'type\': \'statement\', \'name\': None, \'description\': None, \'docstring\': None, \'line\': 1, \'column\': 0, \'start_pos\': (1, 0), \'end_pos\': (1, 0), \'parent\': None, \'full_name\': \'\', \'module_name\': None, \'defined_names\': {}, \'is_keyword\': False, \'goto\': ()}", None, 'definitions')


# Generated at 2022-06-26 07:31:02.293208
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    b = get_interpreter_completions('asyncio.', [{}])
    ret = [x.name for x in b]

# Generated at 2022-06-26 07:31:04.258632
# Unit test for function get_script_completions
def test_get_script_completions():
    var_0 = get_script_completions('import sys\nimport os\n', 2, 1, 'file_0.py')
    assert var_0[0]['type'] == 'statement'


# Generated at 2022-06-26 07:31:13.780429
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert _get_new_jedi_project([]) is None
    assert _get_new_jedi_project([1,2,3]) is not None

    assert len(get_script_completions("", 0, 0, "", [])) > 0
    assert len(get_script_completions("", 0, 0, "", ["/usr/lib/python3.7"])) > 0

    script = jedi.Script("", 0, 0, "")
    assert len(get_script_completions(script.code, script.line, script.column, script.path)) > 0
    assert len(get_script_completions(script.code, script.line, script.column, script.path, ["/usr/lib/python3.7"])) > 0


# Generated at 2022-06-26 07:31:16.721582
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    namespaces = "dad"
    source = "dad"
    sys_path = None
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert result is None



# Generated at 2022-06-26 07:31:18.925896
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("", 0, 0, "c:/Users/lkask/pycharm/Thonny/thonny/backend.py")

# Generated at 2022-06-26 07:31:22.140938
# Unit test for function get_definitions
def test_get_definitions():
    float_0 = 'var = [12, float]'
    float_1 = float_0.index(float_0)

    # STUB begin get_definitions
    # STUB end get_definitions



# Generated at 2022-06-26 07:31:24.945027
# Unit test for function get_script_completions
def test_get_script_completions():
    code1 = "import sys\nimport math\nsys.stdout.write(str(math.sqrt(9)"
    script1 = get_script_completions(code=code1, row=1, column=1, filename="script1.py")
    assert script1


# Generated at 2022-06-26 07:31:28.165948
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    sys_path = []
    source = '''
    def foo():
    return 42
    '''
    namespaces = [{'a': 42, 'foo': foo}]
    interpreter = jedi.Interpreter(source, namespaces, sys_path)
    completions = interpreter.complete()

    assert completions[0].name == 'a'
    assert completions[1].name == 'foo'



# Generated at 2022-06-26 07:31:29.029036
# Unit test for function get_definitions