

# Generated at 2022-06-26 07:23:20.962242
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions('import sys', 1, 9, '<string>', ['/usr/lib'])
    assert completions[0].name == 'sys'
    assert completions[2].name == 'syslog'


# Generated at 2022-06-26 07:23:26.914047
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-26 07:23:38.365738
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

	# Test normal case, user input some characters
	def test_0():
	    class_0 = parse_source(
	        'import b\nb.in_\n'
	    )
	    var_0 = get_script_completions(class_0, 1, 6, './test_file')
	    assert var_0[0].name == 'insert'
	    assert var_0[0].type == 'function'

# Generated at 2022-06-26 07:23:42.624851
# Unit test for function get_script_completions
def test_get_script_completions():
    from typing import cast

    var_0 = get_script_completions('', 0, 0, '')
    if (var_0):
        cast('str', var_0[0].complete)
        cast('str', var_0[0].description)
        cast('str', var_0[0].name)
        cast('str', var_0[0].type)


# Generated at 2022-06-26 07:23:48.700071
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """import pygame\npygame.f"""
    
    expected = {"fill", "ftfont", "fastevent"}
    
    namespaces = []
    actual = set(map(lambda x: x.name, get_interpreter_completions(source, namespaces)))
    
    if expected == actual:
        return True
    else:
        print("expected: %s", expected)
        print("actual: %s", actual)
        return False


# Generated at 2022-06-26 07:23:54.606833
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os

    # Test case that shouldn't run
    dict_0 = {}
    var_0 = get_script_completions(dict_0, "row", "column", "filename")

    # Test case 1
    dict_1 = {}
    var_1 = get_script_completions("import time\n\ntime.", 2, 6, "filename")
    dict_1['name'] = "time"
    dict_1['type'] = "module"
    dict_1['full_name'] = "time"
    dict_1['parent'] = "builtins"
    dict_1['description'] = "This module provides various functions to manipulate time values."
    dict_1['complete'] = "time"
    var_2 = var_1[0].__dict__
    assert var_2 == dict_

# Generated at 2022-06-26 07:24:05.565402
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
  dict_0 = {}
  list_0 = list()

# Generated at 2022-06-26 07:24:08.965037
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "def foo(a,b)"
    print(get_script_completions(str_0, 0, 0, "filepath"))

if __name__ == "__main__":
    test_case_0()
    test_get_script_completions()

# Generated at 2022-06-26 07:24:16.039594
# Unit test for function get_script_completions
def test_get_script_completions():
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    var_0 = get_script_completions(dict_0, dict_0, dict_0, dict_0, dict_0)
    return var_0

# Generated at 2022-06-26 07:24:27.315765
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    import test_get_definitions_1

    current_path = os.path.dirname(__file__)
    test_case_path = os.path.join(current_path, 'test_get_definitions_1.py')
    test_case_code = open(test_case_path).read()

    def_1 = get_definitions(test_case_code, 1, 12, test_case_path)
    assert len(def_1) == 1
    assert def_1[0].module_name == test_get_definitions_1.__name__
    assert def_1[0].line == 1
    assert def_1[0].column == 8

    def_2 = get_definitions(test_case_code, 2, 15, test_case_path)
   

# Generated at 2022-06-26 07:24:53.660547
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    with open("/home/guangyuan/workspace/thonny/thonny/plugins/jedi_completion/test_source.py", "r") as file:
        source = file.read()
    if _using_older_jedi(jedi):
        script = jedi.Script(source, 3, 3, "/home/guangyuan/workspace/thonny/thonny/plugins/jedi_completion/test_source.py")
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path="/home/guangyuan/workspace/thonny/thonny/plugins/jedi_completion/test_source.py")

# Generated at 2022-06-26 07:25:01.660590
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    source = "import hashlib"


# Generated at 2022-06-26 07:25:08.319399
# Unit test for function get_script_completions
def test_get_script_completions():
    script_0 = '''class MyClass:\n\tdef __init__(self,*args,**kwargs):\n\t\tpass\n\tdef get_attr(self,attr):\n\t\treturn self.attr\n\tdef set_attr(self,attr,val):\n\t\tself.attr = val\nc = MyClass()\nc.get_attr('''
    result_0 = get_script_completions(script_0,3,26,'test')
    assert 'attr' in str(result_0)

# Generated at 2022-06-26 07:25:10.532647
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_get_interpreter_completions_0()
    test_get_interpreter_completions_1()


# Generated at 2022-06-26 07:25:17.709727
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    #Initializing mock objects for parameters
    code = "import re\nimport datetime\nre.match("
    row = 2
    column = 7
    filename = "test.py"
    script = jedi.Script(code, row, column, filename)
    script_completions = script.completions()
    completions = get_script_completions(code, row, column, filename)
    if completions:
    	assert 1
    else:
    	assert 0


# Generated at 2022-06-26 07:25:29.962573
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    import jedi
    import sys
    import os
    import types

    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir))
    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir))

    from thonny.globals import get_workbench
    from thonny import ui_utils, ui_utils, ast_utils
    from thonny.ui_utils import CommonTokenStream
    from thonny.ast_utils import ast_from_position, parse_position

# Generated at 2022-06-26 07:25:32.098356
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions(dict_0, (), None)


# Generated at 2022-06-26 07:25:42.737693
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import json
    with open("./testdata/jedi_completions.json", 'r') as f:
        # Do nothing
        # convert a JSON object to a Python dictionary
        d = json.load(f)
        interpreter = jedi.Interpreter(d["code"], d["namespaces"])
        completions = interpreter.complete()
        assert completions[0].name == "__class__"
        assert completions[0].complete == "__class__"
        assert completions[1].name == "__contains__"
        assert completions[1].complete == "__contains__"
        assert completions[2].name == "__delattr__"
        assert completions[2].complete == "__delattr__"
        assert completions[3].name == "__delitem__"

# Generated at 2022-06-26 07:25:54.438471
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module
    from parso.python.tree import Suite
    from parso.python.tree import ClassDef
    from parso.python.tree import FunctionDef
    from parso.python.tree import ClassOrFunc
    from parso.python.tree import ExprStmt
    from parso.python.tree import Assign
    from parso.python.tree import Operator


# Generated at 2022-06-26 07:26:05.530631
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if not _using_older_jedi(jedi):
        return

    source = "def foo():\n  pass\ndef bar():\n  def baz():\n    pass\n"

    # Case 1
    result = get_definitions(source, 0, 0, "")
    assert len(result) == 2

    # Case 2
    result = get_definitions(source, 2, 6, "")
    assert result[0].type == "function"

    # Case 3
    result = get_definitions(source, 3, 2, "")
    assert result[0].type == "function"

    # Case 4
    result = get_definitions(source, 1, 1, "")
    assert len(result) == 1
    assert result[0].line == 0 and result[0].column

# Generated at 2022-06-26 07:26:21.950639
# Unit test for function get_script_completions
def test_get_script_completions():
    # TODO: in case of an exception, it doesn't return anything => how to test it?!
    pass



# Generated at 2022-06-26 07:26:25.728008
# Unit test for function get_definitions
def test_get_definitions():
    path = '/home/dharmit/RND/test.py'
    file = open(path, 'w')
    file.write("a = 100")
    file.close()
    file = open(path, 'r')
    source = file.read()
    file.close()
    row = 0
    column = 4
    filename = path

    jedi_init_get_definitions(source, row, column, filename)


# Generated at 2022-06-26 07:26:27.405565
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions(source=None, row=None, column=None, filename=None)


# Generated at 2022-06-26 07:26:33.327745
# Unit test for function get_definitions
def test_get_definitions():
    dict_0 = {}
    dict_0[0] = []
    dict_0[0].append('test_code.py')
    dict_1 = {}
    dict_0[1] = dict_1
    dict_1[0] = 'name'
    dict_1[1] = 1
    dict_1[2] = 2
    dict_1[3] = 1
    result = get_definitions(dict_0[0], dict_0[1][1], dict_0[1][2], dict_0[1][3])
    assert result == dict_0


# Generated at 2022-06-26 07:26:45.610526
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test case 1
    source = 'import os\n'

# Generated at 2022-06-26 07:26:53.616618
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\nimport main\nprint(sys.path[0].endswith(main.__name__))"
    row = 2
    column = 18
    filename = "test.py"
    result = get_script_completions(source, row, column, filename)
    assert type(result) in [list, tuple]
    assert all([type(e) == ThonnyCompletion for e in result])
    assert len(result) == 1
    assert result[0].name == '__name__='
    assert result[0].complete == '__name__='
    assert result[0].type in ['module', 'param']
    assert result[0].description in ['str', 'str']
    assert result[0].parent in ['main', 'main']

# Generated at 2022-06-26 07:27:00.169379
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        dict_0 = {}
        var_0 = get_interpreter_completions(dict_0, [])
    else:
        dict_0 = {}
        dict_1 = {}
        var_0 = get_interpreter_completions(dict_0, dict_1, [])



# Generated at 2022-06-26 07:27:11.331552
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    dict_0 = {}
    dict_0["st"] = "import time"
    dict_0["set"] = "def set_stopwatch(stopwatch_name):"
    dict_0["s"] = "def stop_stopwatch():"
    dict_0["r"] = "def read_stopwatch(stopwatch_name):"
    dict_0["w"] = "def write_file(filename, string, mode='w'):"
    dict_0["l"] = "def read_lines(filename):"
    dict_0["ls"] = "def read_lines_from_stdin():"
    dict_0["m"] = "def copy_file(source, destination, overwrite=False):"
    dict_0["t"] = "def tail_file(filename, num_lines=10):"

# Generated at 2022-06-26 07:27:15.032615
# Unit test for function get_script_completions
def test_get_script_completions():
    assert True
    # x = parse_source("print('hello')")
    # y = parse_source("print('hello')")
    # print(x.get_code())
    # print(type(y))
    # z = x.children[0]
    # print(z.start_pos)
    # print(z.end_pos)
    # print(z.get_code())

if __name__ == "__main__":
    pytest.main(["-v", __file__])

# Generated at 2022-06-26 07:27:23.427459
# Unit test for function get_script_completions
def test_get_script_completions():
    # Initialization
    var_0 = "test"
    var_1 = 1
    var_2 = 1
    var_3 = "test"
    var_4 = None
    # Function call
    var_5 = get_script_completions(var_0, var_1, var_2, var_3, var_4)
    # Equivalence partitioning
    if (var_5 == None):
        var_6 = 1
    # Equivalence partitioning
    if (var_5 != None):
        var_6 = 1



# Generated at 2022-06-26 07:27:46.344619
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Arrange
    code = "a = 1\nb = 2\na+b"
    positions = [(2, 0), (2, 1)]
    expected = [(('a', '=', 'int'), '', 'int'), (('b', '=', 'int'), '', 'int')]
    namespaces = [ {'a': 1, 'b': 2} ]
    # Action
    result = get_interpreter_completions(code, namespaces, sys_path=None)
    # Assert
    assert result == expected


# Generated at 2022-06-26 07:27:50.520008
# Unit test for function get_definitions
def test_get_definitions():
    # This test is also used for coverage (coverage does not count unittest)
    test_get_definitions_0()


# Generated at 2022-06-26 07:27:54.255999
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    dict_0 = {}
    namespaces_0 = [dict_0]
    var_0 = get_interpreter_completions(dict_0, namespaces_0)


# Generated at 2022-06-26 07:28:04.205163
# Unit test for function get_script_completions
def test_get_script_completions():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_2['x'] = 22
    dict_3['x'] = (22, 23)
    dict_1['x'] = dict_2
    dict_1['y'] = dict_3
    dict_1['z'] = dict_2
    dict_0['x'] = dict_2
    dict_0['y'] = dict_1
    dict_0['z'] = dict_2
    var_0 = get_script_completions(dict_0, 22, 23, dict_1, dict_2)
    var_1 = get_script_completions(dict_0, dict_1, dict_2, dict_1, dict_2)
    var_2 = get_script_complet

# Generated at 2022-06-26 07:28:09.083335
# Unit test for function get_script_completions
def test_get_script_completions():
    # Extract the completion list
    # Generated code
    source = 'from _tkinter import *\nimport _tkinter\nroot = Tk()\nroot.t'

    compl_list = get_script_completions(source, 3, 11, "tk", ["/usr/lib/python3.7/tkinter"])

    assert "Tk()" in compl_list
    assert "TkVersion" in compl_list
    assert "Tkinter" in compl_list
    assert "TkVersion" in compl_list

# Generated at 2022-06-26 07:28:12.574108
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'a.isnumeric()'
    namespaces = [{'a': '3'}]
    sys_path = []

    completions = get_interpreter_completions(source, namespaces, sys_path)
    assert len(completions) == 2
    for completion in completions:
        assert 'isnumeric' in completion.complete


# Generated at 2022-06-26 07:28:20.251373
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module, Class
    import __main__
    assert(__main__.__file__ == "<stdin>")
    source = "import os\nimport sys\ndict_0 = {};\nvar_0 = parse_source(dict_0)\n"

    for i in range(3, len(source)):
        completions = get_definitions(source, 0, i, "<stdin>")
        name = source[:i]
        type = Module
        if i == 3:
            type = Class
        is_success = False
        for completion in completions:
            if completion.name == name:
                is_success = True
        assert(is_success)


# Generated at 2022-06-26 07:28:29.318009
# Unit test for function get_script_completions
def test_get_script_completions():
    script = '''
    class TestClass:
        def test_m1(self):
            pass
        def test_m2(self):
            pass
    '''
    result = get_script_completions(script, 1, 1, '<test>')
    assert len(result) == 1
    assert result[0].name == 'TestClass'

    result = get_script_completions(script, 3, 6, '<test>')
    assert len(result) == 1
    assert result[0].name == 'TestClass'

    result = get_script_completions(script, 5, 6, '<test>')
    assert len(result) == 2
    assert result[0].name == 'test_m2'
    assert result[1].name == 'test_m1'



# Generated at 2022-06-26 07:28:37.422318
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    with patch("builtins.print") as mock_print:
        with patch("sys.version_info", MagicMock(return_value=(3, 7))):
            mock_interpreter = Mock()
            mock_interpreter.complete.return_value = ["a", "b"]
            sys_path = [""]
            namespaces = [{'a': '', 'b': ''}]
            source = ""
            with patch("thonny.plugins.jediutils.jedi", autospec=True) as mock_jedi:
                mock_jedi.Interpreter.return_value = mock_interpreter
                result = get_interpreter_completions(source, namespaces, sys_path)
                mock_

# Generated at 2022-06-26 07:28:39.933208
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert isinstance(get_script_completions("", 0, 0, "a.py"), jedi.api.classes.Completion)


# Generated at 2022-06-26 07:29:01.177867
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("[i.", [{}]) == []

    assert get_interpreter_completions("a=5", [{}]) == []
    assert get_interpreter_completions("a=5", [{"a": 5}]) == []

    assert get_interpreter_completions("i.", [{}]) == []
    assert get_interpreter_completions("i.", [{"i": 5}]) == []

    assert get_interpreter_completions(
        "for x in range(10): pass; i.", [{"i": 5}]
    ) == []

    assert get_interpreter_completions("1 + i.", [{}]) != []

# Generated at 2022-06-26 07:29:03.714893
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    list_0 = []
    list_0.append(dict_0)
    list_0.append(dict_0)
    list_0.append(dict_0)
    var_0 = get_interpreter_completions(str_0, list_0, list_0)
    print((var_0))


# Generated at 2022-06-26 07:29:12.633701
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from parso.tree import Leaf, NodeOrLeaf, BaseNode

    def_var = '''
    def f(x):
        return x
    '''
    src_code = "f("

    def get_namespaces(leaf:Leaf)-> List[dict]:
        namespaces = []
        for child in leaf.get_root_node().children:
            if isinstance(child, NodeOrLeaf):
                if child.type == "simple_stmt" and not isinstance(child, BaseNode):
                    pure_name = child.get_code().strip()
                    if pure_name.startswith("def ") or pure_name.startswith("class "):
                        namespaces.append({"name": "dummy"})
        return namespaces


# Generated at 2022-06-26 07:29:13.981719
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:29:15.705369
# Unit test for function get_script_completions
def test_get_script_completions():
    # TODO:  Check return value
    assert True



# Generated at 2022-06-26 07:29:24.573301
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python import tree
    import jedi

    test_code = """
    def f(a, b, c=100):
        return 1
    """
    test_node = parse_source(test_code)
    test_script = get_script_completions(test_code, 1, 0, "test.py")
    assert len(test_script) == 1

    # The first signature should be ok
    test_signature = test_script[0]

    # Test the name
    assert test_signature.name == "f"

    # Test the complete
    assert test_signature.complete == "f()"

    # Test the type
    assert test_signature.type == "function"

    # Test the parent
    assert isinstance(test_signature.parent, tree.ExprStmt)



# Generated at 2022-06-26 07:29:30.299898
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python.tree import ParserSyntaxError
    result = get_script_completions("import  sys", 1, 7, "")
    assert len(result) > 1
    assert result[0].name == "sys"
    assert result[0].parent.name == "builtins"

    result = get_script_completions("sys.platr", 1, 5, "")
    assert result[0].name == "platform"
    assert result[0].parent.name == "sys"

    result = get_script_completions("import sys\nsys.\n", 2, 4, "")
    assert result[0].name == "platform"
    assert result[0].parent.name == "sys"

    # I'm not sure why skipping get_script_completions("import sys\nsys.pl

# Generated at 2022-06-26 07:29:40.182843
# Unit test for function get_definitions
def test_get_definitions():
    context = jedi.Script(
        "def f(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z):"
        "    return a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p + q + r + s + t + u + v + w + x + y + z"
    )
    completions = context.completions()

    completion_names = [completion.name for completion in completions]
    assert ("f" in completion_names)

    completion_names.remove("f")

    for name in completion_names:
        assert name.isalpha()


# Generated at 2022-06-26 07:29:43.455178
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = jedi.Script("import sys; sys.pat")
    completions = script.completions()
    for completion in completions:
        print("type: " + completion.type + " name: " + completion.name)
    assert completions



# Generated at 2022-06-26 07:29:50.181097
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    dict_0 = {}
    dict_1 = {}
    dict_1["namespaces"] = [parse_source('dict_0 = {}')]
    dict_1["source"] = '\nprint(dict_0)'
    dict_1["sys_path"] = []
    dict_2 = get_interpreter_completions(dict_1["source"], dict_1["namespaces"], dict_1["sys_path"])


# Generated at 2022-06-26 07:30:32.292549
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_source = (
        "import math\n"
        "a = math.fabs\n"
        "b = math.\n"
    )
    test_namespaces = [{}, {}]
    test_row = 3
    test_column = 8
    actual_completions = get_interpreter_completions(test_source, test_namespaces, test_row, test_column)

# Generated at 2022-06-26 07:30:34.264852
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    pass


# Generated at 2022-06-26 07:30:43.227121
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os

    def mock_get_interpreter_completions(source, namespaces, sys_path=None):
        if sys_path:
            return sys_path[0]
        else:
            return "sys_path is None"


# Generated at 2022-06-26 07:30:51.441587
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    import jedi

    try:
        import thonny
        import_34 = True
    except ImportError:
        import_34 = False
    if import_34 == True:
        sys_path = sys.path + [os.path.dirname(thonny.__file__)]
        jedi_version = jedi.__version__
        if jedi_version[:4] == "0.18":
            func_0 = get_interpreter_completions
            var_0 = {"list(","dict(","tuple(","set(",}
            namespaces_0 = [{},]
            sys_path_0 = sys_path
            var_1 = func_0(var_0, namespaces_0, sys_path_0)

# Generated at 2022-06-26 07:30:53.104688
# Unit test for function get_definitions
def test_get_definitions():
    var_0 = get_definitions(0, 0, 0, '')
    assert var_0 == None, 'Expected None'

# Generated at 2022-06-26 07:31:00.548655
# Unit test for function get_definitions
def test_get_definitions():
    dict_0 = {}
    var_0 = parse_source(dict_0)
    var_1 = var_0.children[0]
    var_2 = get_definitions(dict_0, 0, 0, var_1)
    var_3 = var_2[0].name
    var_4 = var_2[0].full_name
    var_5 = var_2[0].type
    var_6 = var_2[0].module_path
    var_7 = var_2[0].line
    var_8 = var_2[0].column
    var_9 = var_2[0].in_builtin_module()
    var_10 = var_2[0].description
    var_11 = var_2[0].docstring()

# Generated at 2022-06-26 07:31:02.018402
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Unit test for function get_script_completions
    """
    # Need to add a test case for 0.18
    pass

# Generated at 2022-06-26 07:31:09.272187
# Unit test for function get_definitions
def test_get_definitions():
    # TODO - maybe add test for when cursor is inside the definition?
    def get_first_definition(source: str, row: int, column: int, filename: str):
        result = get_definitions(source, row, column, filename)
        return result[0] if len(result) > 0 else None

    assert get_first_definition(
        "def foo():\n    return 1\n\nfoo()", 2, 7, "test.py"
    ).description == "foo"
    assert get_first_definition(
        "class A:\n    def foo(self):\n        return 1\n\nA().foo()", 3, 8, "test.py"
    ).description == "foo"

# Generated at 2022-06-26 07:31:19.261616
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    parser = mock.Mock()
    parser.complete = ["def", "defa", "defab"]
    interpreter = mock.Mock()
    interpreter.completions = parser.complete

    # Case1: positive case with expected result
    source = "def"
    namespaces = [{}, {"a":"a"}]

# Generated at 2022-06-26 07:31:20.758917
# Unit test for function get_script_completions
def test_get_script_completions():
    assert True



# Generated at 2022-06-26 07:32:13.498228
# Unit test for function get_script_completions
def test_get_script_completions():
    # Simple test with no arguments
    dict_0 = {}
    var_0 = parse_source(dict_0)
    get_script_completions(var_0)

    # Test with sys_path argument
    dict_1 = {}
    var_1 = parse_source(dict_1)
    list_0 = [dict_1]
    get_script_completions(var_1, list_0)



# Generated at 2022-06-26 07:32:16.453574
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test 1
    dict_0 = ""
    source_0 = dict_0
    row_0 = 0
    column_0 = 0
    filename_0 = ""
    test_get_script_completions_0 = get_script_completions(source_0, row_0, column_0, filename_0)
    assert test_get_script_completions_0



# Generated at 2022-06-26 07:32:25.853119
# Unit test for function get_script_completions
def test_get_script_completions():
    from tests.helper import _get_test_text
    # 0
    code_0 = _get_test_text("test_text_0.txt")
    row = 3
    column = 29
    filename = "test_text_0.txt"
    test_get_script_completions_0 = get_script_completions(code_0, row, column, filename)
    assert [
        ThonnyCompletion(name='A_0', complete='A_0', type='class', description='class A_0', parent='',
                         full_name='A_0'),
        ThonnyCompletion(name='A_1', complete='A_1', type='class', description='class A_1', parent='',
                         full_name='A_1')] == test_get_script_completions_0



# Generated at 2022-06-26 07:32:32.879420
# Unit test for function get_definitions
def test_get_definitions():
    # Simple case
    line_0 = "def test_case_0():\n"
    line_1 = "    dict_0 = {}\n"
    line_2 = "    var_0 = parse_source(dict_0)"
    assert get_definitions(line_0 + line_1 + line_2, 0, 0, "") == []
    assert get_definitions(line_0 + line_1 + line_2, 1, 0, "") == [
        ThonnyCompletion(
            name="test_case_0",
            complete="test_case_0",
            type="function",
            description="test_case_0",
            parent=None,
            full_name="test_case_0",
        ),
    ]

# Generated at 2022-06-26 07:32:34.525574
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{}]
    get_interpreter_completions("", namespaces)

# Generated at 2022-06-26 07:32:42.225789
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from tempfile import mkstemp
    import os
    import sys
    import inspect

    # Python 3
    if sys.version_info > (3, 0):
        tempfile = mkstemp()
        os.close(tempfile[0])
        filename = tempfile[1]
    # Python 2
    else:
        filename = mkstemp()[1]

    # Open the file
    file = open(filename, "w")

    # Write to the file
    to_write = \
    """
    def f(a):
        return a
    """
    file.write(to_write)

    # Close the file
    file.close()

    # Insert into sys.path
    sys.path.insert(0, os.path.dirname(os.path.abspath(filename)))

    # Import and reload

# Generated at 2022-06-26 07:32:46.443837
# Unit test for function get_script_completions
def test_get_script_completions():
    dict_1 = {}
    var_1 = parse_source(dict_1)
    var_2 = get_script_completions(var_1, 2, 4, "test_file.py")
    assert var_2 == []


# Generated at 2022-06-26 07:32:52.401714
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import mock

    # set up mock
    mock_source = mock.Mock()
    mock_row = mock.Mock()
    mock_column = mock.Mock()
    mock_filename = mock.Mock()


    expected_results = ""
    assert get_definitions(mock_source, mock_row, mock_column, mock_filename) == expected_results


# Generated at 2022-06-26 07:33:01.697474
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    from parso.python.tree import Keyword, Function
    from parso.python.tree import Name, Param
    from parso.python.tree import PythonNode

    # Method 1: Completing the name of a function
    def test_get_definitions_1(self):
        source = """
        def func():
            pass

        func
        """
        row = 3
        column = 6
        filename = None
        result = get_definitions(source, row, column, filename)
        reference = Function(Name("func"), None, Param(None, None, None))
        self.assertEqual(result[0].tree_node, reference, "method 1 failed")

    # Method 2: Completing a parameter of the function

# Generated at 2022-06-26 07:33:07.219470
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # FIXME: THONNY-829
    import unittest
    import unittest.mock as mock
    from thonny.globals import get_workbench
    from thonny.ui_utils import open_interpreter
    from thonny.languages.python import Python3LanguageBackend
    from thonny.plugins.jedi import backend

    mock_view = mock.Mock()
    mock_view.text.get.return_value = "#get_interpreter_completions 0"
    mock_view.get_buffer_id.return_value = "Python3"

    wb = get_workbench()
    wb.set_default("interpreter", "python3")
    wb.set_language_backend(3, Python3LanguageBackend())
    wb.set