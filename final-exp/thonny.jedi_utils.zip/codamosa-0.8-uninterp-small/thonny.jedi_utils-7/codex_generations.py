

# Generated at 2022-06-26 07:23:12.245422
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    str_0 = ""
    var_0 = get_interpreter_completions(str_0, [])
    print(var_0)




# Generated at 2022-06-26 07:23:17.755102
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = "from typing import NamedTuple\n\nclass Person(NamedTuple):\n    first_name: str\n    age: int\n\nrobert = Person('Robert', 25)\nrobert.middle_name = 'Paul'\nrobert.middle_name"
    var_0 = get_interpreter_completions(str_0, [{'middle_name': 'Paul'}])

    assert "middle_name" in [completion['name'] for completion in var_0]



# Generated at 2022-06-26 07:23:25.857131
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import mock
    from thonny_plugins.jedi_plugin import utils
    from unittest.mock import call

    script_completions = utils.get_interpreter_completions("import", [], None)


# Generated at 2022-06-26 07:23:26.605959
# Unit test for function get_definitions

# Generated at 2022-06-26 07:23:29.789958
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = "print()\n"
    list_0 = []
    result = get_interpreter_completions(str_0, list_0)


# Generated at 2022-06-26 07:23:38.888883
# Unit test for function get_script_completions
def test_get_script_completions():
    str_1 = "import math\nprint(math.ceil(10))"
    str_2 = None
    str_3 = "math.cei"
    row_1 = 2
    column_1 = 14
    sys_path_1 = []
    result_1 = get_script_completions(str_1, row_1, column_1, str_2, sys_path_1)
    assert result_1 != None
    assert result_1 != []
    assert str_3 in result_1

if __name__ == '__main__':
    test_case_0()
    test_get_script_completions()

# Generated at 2022-06-26 07:23:39.486305
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert True


# Generated at 2022-06-26 07:23:43.722666
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import w"
    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0


# Generated at 2022-06-26 07:23:44.671354
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:23:52.842826
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import datetime as d; d.da'
    namespaces = [{'__name__': '__main__', 
                   '__builtins__': {}
                  }]
    completions = get_interpreter_completions(source, namespaces)

    assert(len(completions) == 4)
    exp_outcomes = [('date', 'date', 'class', ''),
                    ('date.__init__', 'date.__init__', 'function', '**'),
                    ('date.__doc__', 'date.__doc__', 'instance', ''),
                    ('date.day', 'date.day', 'int', '')
                   ]
    for i, comp in enumerate(completions):
        assert(comp.name == exp_outcomes[i][0])

# Generated at 2022-06-26 07:24:07.105221
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = None
    var_0 = get_interpreter_completions(str_0, [], )
    return var_0


# Generated at 2022-06-26 07:24:15.830796
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = 'import numpy as np\nnp.array().re'
    namespaces = None
    sys_path = None

    if _using_older_jedi(jedi):
        try:
            interpreter = jedi.Interpreter(source, namespaces, sys_path=sys_path)
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            interpreter = jedi.Interpreter(source, namespaces)
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        interpreter = jedi.Interpreter(source, namespaces)

# Generated at 2022-06-26 07:24:27.316169
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        namespaces = None
    else:
        namespaces = []

    # This is a test for the function get_interpreter_completions
    # from thonny/workflows/jedi_utils.py, and is taken from test_get_script_completions
    # from thonny/workflows/jedi_utils.py, which the function is taken from
    # using the branch 0.18 with commit:
    # https://github.com/davidhalter/jedi/commit/c8f7a61e6e595416a9a710f8c3956acc8068b5d7
    # Original function test_get_script_completions was created by
    # Thomas Kluyver and Chris Warth, which the function

# Generated at 2022-06-26 07:24:30.673287
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"x": 1.0}]
    source = "print(x."
    result = get_interpreter_completions(source, namespaces)
    assert len(result) == 1


# Generated at 2022-06-26 07:24:33.576171
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = None
    list_0 = [None]
    var_0 = get_interpreter_completions(str_0, list_0)


# Generated at 2022-06-26 07:24:41.571839
# Unit test for function get_script_completions
def test_get_script_completions():

    assert(get_script_completions("import dja", 1, 10, "./src/jedi/api.py") == [ThonnyCompletion(name="django", complete="django", type='module', description='ImportError: No module named django\n  Complete output from command "python setup.py egg_info" failed with error code 1 in /tmp/pip-build-6ztcu6ma/django/\n', parent=None, full_name='django')])

# Generated at 2022-06-26 07:24:45.005485
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_1 = """import os"""
    var_1 = get_interpreter_completions(str_1, [])


# Generated at 2022-06-26 07:24:48.266707
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("import os\nos.", [{"os": __import__("os")}])) > 0



# Generated at 2022-06-26 07:24:58.272292
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = b"import datetie"
    var_0 = get_interpreter_completions(str_0, [], None)
    test.equal(var_0[0].name, 'datetime = <module>\n')
    test.equal(var_0[0].complete, 'datetime = <module>\n')
    test.equal(var_0[0].type, 'module')

# Generated at 2022-06-26 07:25:01.735966
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = None
    int_0 = 0
    int_1 = 0
    str_1 = None
    var_0 = None
    var_1 = get_script_completions(str_0, int_0, int_1, str_1)


# Generated at 2022-06-26 07:25:19.451438
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser.tree import Class
    from jedi import settings
    settings.case_insensitive_completion = False
    _test_get_interpreter_completions('x', [{'x': Class(None, 'X', None)}])
    settings.case_insensitive_completion = True
    _test_get_interpreter_completions('X', [{'x': Class(None, 'X', None)}])
    _test_get_interpreter_completions('X', [{'X': Class(None, 'X', None)}])



# Generated at 2022-06-26 07:25:31.245765
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    __test__ = {}  # For pytest-3.3.1
    str_0 = None
    str_1 = '""'
    tuple_0 = ()
    tuple_1 = (tuple_0,)
    dict_0 = {}
    dict_1 = {str_0: dict_0}
    list_0 = [str_0, str_0]
    list_1 = [str_1, str_1]
    list_2 = [str_0, str_1]
    list_3 = [str_0, dict_0]
    list_4 = [str_0, dict_1]
    list_5 = [list_4, list_4]
    list_6 = [dict_1, dict_1]
    list_7 = [list_6, list_6]
    list_8

# Generated at 2022-06-26 07:25:42.038428
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import jediutils
    from thonny.jediutils import ThonnyCompletion

    # Test 1
    str_1 = 'def foo():\n    print("foo")\n\nfoo(1)'
    pos = (2, 4)
    completions = jediutils.get_script_completions(str_1, pos[0], pos[1], "test.txt")
    assert completions[0] == ThonnyCompletion(
        name="upper",
        complete="upper",
        type="function",
        description="str.upper()\n\nReturn a copy of the string with all the cased characters "
        "converted to uppercase.",
        parent="str",
        full_name="str.upper",
    )

    # Test 2

# Generated at 2022-06-26 07:25:53.755359
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.pylint.pylint_support import _get_wx_compat_type
    from thonny.plugins.pylint.pylint_support import _tweak_completions
    list_0 = []
    var_0 = _tweak_completions(list_0)
    var_1 = ThonnyCompletion
    var_2 = var_1("", "", "", "", "", "")
    list_1 = [var_2]
    var_0 = _tweak_completions(list_1)
    var_3 = var_0[0].name
    var_4 = var_0[0].complete
    var_5 = var_0[0].type
    var_6 = var_0[0].description
    var_7 = var_

# Generated at 2022-06-26 07:25:58.649021
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    with open("jedi_utils.py", "r", encoding="utf-8") as f:
        result = get_script_completions(f.read(), 13, 13, filename="jedi_utils.py")
        assert len(result) >= 7
        assert result[0].name == "startswith"
        assert result[0].complete == "startswith()"
        assert result[0].description in ("startswith(...)", "startswith($self, /, *, end=None)")
        # json.dumps(result)

# Generated at 2022-06-26 07:26:08.507843
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    str_0 = """import sys\nsys.path.append(r'C:\\Users\\User\\AppData\\Local\\Programs\\Python\\Python36-32\\Lib')\nfrom random import *\nchars = '+-/*!&$#?=@<>abcdefghijklnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'\n"""
    line_0 = 11
    column_0 = 1

# Generated at 2022-06-26 07:26:18.973219
# Unit test for function get_script_completions
def test_get_script_completions():
    from pathlib import Path
    from parso.python import tree
    import jedi

    # Basic test for string as source, line and column
    source = "x = 10; y = x\nx."
    line = 2
    column = 3
    filename = "test.py"
    completions = get_script_completions(source, line, column, filename)
    assert completions[0].name == "bit_length"

    # Basic test for Path as source
    path = Path("test.py")
    completions = get_script_completions(path, line, column, filename)
    assert completions[0].name == "bit_length"

    # Simple test for file as source
    source = open("test.py", "r")

# Generated at 2022-06-26 07:26:26.367209
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = "import os"
    str_1 = "os."
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = "import "
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = "import os"
    list_0 = list()
    dict_0 = {"os" : str_2}
    list_0.append(dict_0)
    list_1 = list()
    dict_1 = {"__name__" : str_3, "__doc__" : str_4, "os" : str_6}
    list_1.append(dict_1)
    list_2 = list()
    dict

# Generated at 2022-06-26 07:26:30.986705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    # Test valid input
    completions = get_interpreter_completions("print('hello')",[],"")
    assert isinstance(completions, list)
    
    # Test invalid input
    try:
        completions = get_interpreter_completions("print('hello')",None,"")
    except jedi.NotFoundError:
        assert True
    except:
        assert False


# Generated at 2022-06-26 07:26:35.807227
# Unit test for function get_definitions
def test_get_definitions():
    for source in ["def func():", "def func() -> str: pass"]:
        var_0 = get_definitions(source, 0, 4, "test.py")
        assert len(var_0) == 1
        assert var_0[0].type == 'function'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 07:26:59.989441
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = 'def foo(argument):\n    print(argument)'
    var_0 = get_definitions(str_0, 2, 20, '<stdin>')
    for var_1 in var_0:
        print(var_1.name)


# Generated at 2022-06-26 07:27:04.894677
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = "import string\nstring.\n"
    var_0 = get_definitions(str_0, 2, 0, "test.py")
    assert var_0[0].module_name == "string"
    assert var_0[0].line == 1
    assert var_0[0].column == 0



# Generated at 2022-06-26 07:27:11.603396
# Unit test for function get_script_completions
def test_get_script_completions():
    script = 'from tkinter import *\nroot = Tk()\nbtn = Button(root, text="", command="")\nbtn'
    column = len(script)
    row = script.count("\n")
    filename = "test"
    assert get_script_completions(script, row, column, filename)
    assert get_script_completions(script, row, column, filename, ["/home/dummy/path"])


# Generated at 2022-06-26 07:27:15.485822
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = ""
    namespaces = []
    sys_path = []
    assert get_interpreter_completions(source, namespaces, sys_path) == None


# Generated at 2022-06-26 07:27:19.174071
# Unit test for function get_definitions
def test_get_definitions():
    # case 0
    source = None
    row = None
    column = None
    filename = None

    assert get_definitions(source, row, column, filename) == []


# Generated at 2022-06-26 07:27:24.600792
# Unit test for function get_definitions
def test_get_definitions():
    source = """import sys;sys.stdout.write("Hello, world")""".encode()
    row = 3
    column = 11
    filename = "hello.py"
    definitions = get_definitions(source,row,column, filename)
    assert len(definitions) == 1



# Generated at 2022-06-26 07:27:33.180959
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from unittest.mock import patch

    def mock_definitions(self, *args, **kwargs):
        return [ThonnyCompletion("name", "complete", "type", "desc", "par", "full_name")]

    with patch("jedi.Script.infer", side_effect=mock_definitions):
        source = ""
        row = 0
        column = 0
        filename = "some_file"
        result = get_definitions(source, row, column, filename)
        assert len(result) == 1

# Generated at 2022-06-26 07:27:37.939746
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = None
    row_0 = 0
    column_0 = 0
    var_1 = get_script_completions(str_0, row_0, column_0)


# Generated at 2022-06-26 07:27:42.542488
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = "def a():\n    print(b)"
    var_0 = get_definitions(str_0, 2, 14, "test.py")
    if var_0 != None:
        return False
    else:
        return True


# Generated at 2022-06-26 07:27:48.881310
# Unit test for function get_script_completions
def test_get_script_completions():
    """Test for completions
    
    """
    import jedi
    
    assert jedi.__version__[:4] in ["0.14", "0.15", "0.16", "0.17"]
    compl = get_script_completions(source='def', row=0, column=3, filename='')
    assert compl[0].name == 'def'
    assert compl[0].complete == 'def'
    assert compl[0].type == 'keyword'
    assert compl[0].description == 'def'
    assert compl[0].parent == None
    assert compl[0].full_name == 'def'



# Generated at 2022-06-26 07:28:43.609550
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python import tree
    from thonny.plugins.jedi_utils import get_script_completions
    from unittest import TestCase

    test_script = """import sys
print(sys.path
"""

    script_row = 2
    script_column = 12

    script_completions = get_script_completions(test_script, script_row, script_column, "test.py")

    class TestGetScriptCompletions(TestCase):
        def test_function_name(self):
            self.assertEqual(script_completions[0].name, "assertEqual")
            self.assertEqual(script_completions[1].name, "assertNotEqual")


# Generated at 2022-06-26 07:28:50.447779
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Leaf

    assert get_module_path("sys")
    assert not get_module_path("no_such_module")
    for path in get_module_paths():
        assert os.path.exists(path)
    assert isinstance(get_statement_of_position(Leaf(0, 0), (0, 0)), Leaf)
    assert isinstance(parse_source(""), tree.Module)
if __name__ == '__main__':
    test_case_0()  # test parse_source
    test_get_definitions()

# Generated at 2022-06-26 07:28:51.334846
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:28:57.192336
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = 'from tkinter import *'
    int_0 = 1
    int_1 = 1
    str_1 = 'test.py'
    list_0 = []
    var_0 = get_script_completions(str_0, int_0, int_1, str_1, list_0)
    assert len(var_0) >= 8 or len(var_0) == 0



# Generated at 2022-06-26 07:29:01.977003
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "def f(x): pass\nf(1)\n"
    row = 1
    column = 5
    namespaces = [{'a': 7}, {'b': 'str'}]

    completions = get_interpreter_completions(
        source, row, column, namespaces, None)
    comp = completions[0]
    assert comp.name == 'f'
    assert comp.full_name == 'f'
    assert comp.type == 'function'



# Generated at 2022-06-26 07:29:07.846620
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test for arg 0 : source
    str_0 = "import turtle\nimport tkinter\nturtle.Turtle.fd"
    namespaces = [
        {
            "turtle": __import__("turtle"),
            "tkinter": __import__("tkinter"),
            "__name__": "__main__",
        }
    ]
    sys_path = []
    output = get_interpreter_completions(str_0, namespaces, sys_path)
    assert output[0].name == "forward"
    assert output[0].complete == "forward"
    assert output[0].type == "function"
    assert output[0].description == "turtle.forward(distance)\nMove the turtle forward by the specified distance, in the direction the turtle is headed.\nAliases: forward | fd"


# Generated at 2022-06-26 07:29:10.130001
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions(None, None)
    if not var_0:
        var_0 = []


# Generated at 2022-06-26 07:29:13.134179
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = None
    list_0 = []
    list_0.append({})
    get_interpreter_completions(str_0, list_0)


# Generated at 2022-06-26 07:29:15.954724
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "def tester():\n    print(12)\n    "
    var_0 = get_script_completions(str_0, 2, 9, "")


# Generated at 2022-06-26 07:29:24.879581
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = 'import sys\n'-1
    str_1 = 'print()\n'-8
    str_2 = 'import con.derp\n'-8
    list_0 = ['hello']
    dict_0 = {'hello': 5}
    tuple_0 = (1, 2, 3)
    list_1 = [1, 2, 3]
    list_2 = ['hello']
    dict_1 = {'hello': 5}
    tuple_1 = (1, 2, 3)
    list_3 = [1, 2, 3]
    list_4 = ['hello']
    dict_2 = {'hello': 5}
    tuple_2 = (1, 2, 3)
    list_5 = [1, 2, 3]


# Generated at 2022-06-26 07:30:22.191251
# Unit test for function get_script_completions
def test_get_script_completions():    
    str_0 = "import os"
    var_0 = parse_source(str_0)
    test_get_script_completions_0 = get_script_completions(str_0, 3, 7, "", [])
    # Assertion for get_script_completions.
    assert test_get_script_completions_0 == [], "expected: %s, actual: %s" % (
        [], test_get_script_completions_0)



# Generated at 2022-06-26 07:30:28.611134
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = "from sys import path\n"
    row_0 = 2
    row_1 = 2
    column_0 = 1
    column_1 = 0
    filename = None
    sys_path_0 = ["C:\\tmp\\jedi\\test_data\\test_jedi\\test_completions\\test_api.py"]
    get_script_completions(str_0, row_0, column_0, filename, sys_path_0)
    
    get_script_completions(str_0, row_1, column_1, filename, sys_path_0)



# Generated at 2022-06-26 07:30:30.822745
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = None
    int_0 = None
    var_0 = get_definitions(str_0, int_0, int_0, str_0)


# Generated at 2022-06-26 07:30:33.043235
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Function, Definition
    from parso.python import tree

    def_0 = Function("str(object='')", (2, 3), "/home/user/test.py", None, None, None)

# Generated at 2022-06-26 07:30:42.592387
# Unit test for function get_definitions
def test_get_definitions():
    s = """
from turtle import *
"""

    res = get_definitions(s, 2, 9, "")
    assert len(res) == 1
    assert res[0].type == "module"

    res = get_definitions(s, 2, 11, "")
    assert len(res) == 1
    assert res[0].type == "import"

    # --

    res = get_definitions("import turtle", 0, 7, "")
    assert len(res) == 1
    assert res[0].type == "module"

    res = get_definitions("import turtle", 0, 8, "")
    assert len(res) == 1
    assert res[0].type == "module"

    res = get_definitions("import turtle", 0, 0, "")
    assert len(res) == 1

# Generated at 2022-06-26 07:30:48.296351
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench

    completions = get_script_completions(
        "def f():\n\tpa", 3, 3, "/tmp/test.py", sys_path=get_workbench().get_python_path()
    )
    assert len(completions) > 5
    pprint(completions)


if __name__ == "__main__":
    from pprint import pprint

    test_case_0()
    test_get_script_completions()

# Generated at 2022-06-26 07:30:52.781539
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = '\r\nx = 1\r\n\r\ny = x + 1\r\n'
    var_1 = parse_source(str_0)
    var_2 = get_definitions(str_0, 2, 5, '/home/nina/bin/jedi/test.py')
    assert var_2[0].module.path == '/home/nina/bin/jedi/test.py'

# Generated at 2022-06-26 07:30:54.477015
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('import os',1,7,'test.py')[0].name == 'os'


# Generated at 2022-06-26 07:31:01.742418
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    str_0 = 'import inspect\nimport os\nos.path\n'
    str_1 = None
    list_0 = list()
    list_0.append(dict())
    list_0.append(dict())
    list_1 = list()
    list_0[1]['locals'] = list_1
    list_0[0]['globals'] = list_1
    list_0[0]['globals'].append(jedi)
    list_0[1]['locals'].append(jedi)
    list_0[1]['locals'].append(inspect)
    list_0.append(dict())
    list_0[2]['globals'] = list_1
    list_0[2]['locals'] = list_1


# Generated at 2022-06-26 07:31:07.705245
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test 1
    mock_source = "from datetime import dat"
    mock_namespaces = [{}]
    result = get_interpreter_completions(mock_source, mock_namespaces)

# Generated at 2022-06-26 07:32:07.503797
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:32:14.987194
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi import Script
    from jedi._compatibility import u
    from jedi import settings
    from jedi.evaluate import compiled
    from jedi import cache
    from jedi import parser
    from jedi.evaluate.cache import evaluator_function_cache
    from thonny.jediutils import _get_new_jedi_project
    from jedi.evaluate.sys_path import get_sys_path
    from jedi.evaluate.dynamic import search_params
    settings.case_insensitive_completion = False
    cache.parser_cache.clear()
    cache.module_cache.clear()
    cache.completion_cache.clear()
    evaluator_function_cache.clear()
    search_params.clear()
    settings._completion_filters = settings.CompletionFilters

# Generated at 2022-06-26 07:32:18.531729
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = None
    var_0 = get_script_completions(str_0)


# Generated at 2022-06-26 07:32:26.544717
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Test 1")
    str_0 = "import os"
    var_0 = get_interpreter_completions(str_0, [])
    print(var_0)
    print("Test 2")
    str_0 = 'import os\nos.remove("nf_test_2")'
    var_0 = get_interpreter_completions(str_0, [])
    print(var_0)
    print("Test 3")
    str_0 = "import os\nos.system()"
    var_0 = get_interpreter_completions(str_0, [])
    print(var_0)
    print("Test 4")
    str_0 = "import os\nos.remove"

# Generated at 2022-06-26 07:32:33.237043
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import main

    from .test_completion import get_test_cases

    for case in get_test_cases():
        result = get_script_completions(
            case["source"], case["row"], case["column"], case["filename"]
        )
        expected_result = case["expected_result"]
        diff_line_num = 1
        found = False
        if len(expected_result) != len(result):
            print("Difference in completions number" + " --- Case #" + diff_line_num)

# Generated at 2022-06-26 07:32:41.489626
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api import classes

    str_0 = None
    var_0 = get_script_completions(str_0,0,0, "test_file")

    assert isinstance(var_0, list)

    var_1 = get_script_completions("\"a",0,2, "test_file")

    assert isinstance(var_1[0], ThonnyCompletion)
    assert "\"a\"" in var_1[0].name

    var_2 = get_script_completions("\"a",0,2, "test_file", ["/root/thonny/src/thonny/plugins/"])

    assert isinstance(var_2[0], ThonnyCompletion)
    assert "\"a\"" in var_2[0].name

   

# Generated at 2022-06-26 07:32:52.711925
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso

    str_0 = "import\n"
    str_1 = "import sys\n"
    str_2 = "import sys\nimport "
    str_3 = "if 1:\n    print("
    str_4 = "if 1:\n    print()\n"
    str_5 = "if 1:\n    print(1)\n"
    str_6 = "if 1:\n    print('hello')\n"
    str_7 = "if 1:\n    print('hello')\nelse:\n"
    str_8 = "if 1:\n    print('hello')\nelse:\n  print()\n"
    str_9 = "if 1:\n    print('hello')\nelse:\n  print(1)\n"

# Generated at 2022-06-26 07:33:01.966575
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi._compatibility import use_metaclass
    else:
        from jedi.api.classes import use_metaclass

    source = """import math
import sys

sys.path.append("math")

print(math.pi)
print(pi)
print(p)

"""
    namespaces = [{"locals": {"math": math}}, {"locals": {"sys": sys}}]

    completions = get_interpreter_completions(source, namespaces)

    assert len(completions) == 2  # both math.pi and sys.path
    assert completions[0].name == "pi"
    assert completions[0].full_name == "math.pi"