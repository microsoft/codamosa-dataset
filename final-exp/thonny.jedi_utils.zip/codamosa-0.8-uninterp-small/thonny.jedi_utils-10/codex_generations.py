

# Generated at 2022-06-26 07:23:40.708462
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import jedi.parser.python
    source = 'import math\ndef test(): pass\ntest()'
    # Test default namespace
    completions_default_ns = get_interpreter_completions(source, [])

    assert len(completions_default_ns) == 4
    assert completions_default_ns[0].name == "math"
    assert completions_default_ns[1].name == "test"
    assert completions_default_ns[2].name == "help"
    assert completions_default_ns[3].name == "exit"

    # Test custom namespace
    completions_custom_ns = get_interpreter_completions(source, [{'i': 1}])
    assert len(completions_custom_ns) == 4
    assert completions_

# Generated at 2022-06-26 07:23:41.664639
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    raise NotImplementedError


# Generated at 2022-06-26 07:23:44.631882
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = jedi.Script("this_is_a_test_for_completions_string")
    completions = script.completions()
    assert completions



# Generated at 2022-06-26 07:23:48.988709
# Unit test for function get_script_completions
def test_get_script_completions():
    assert isinstance(get_script_completions('', 1, 1, ''), list)
    assert isinstance(get_script_completions('', 1, 1, '', ['']), list)
    assert isinstance(get_script_completions('', 1, 1, '', 1), list)
    

# Generated at 2022-06-26 07:23:52.736816
# Unit test for function get_definitions
def test_get_definitions():
    logger.info("get_definitions")
    func_1 = get_definitions
    var_0 = "this is source code"
    var_1 = 0
    var_2 = 15
    var_3 = "test/test_file.py"
    var_4 = func_1(var_0, var_1, var_2, var_3)
    return var_4



# Generated at 2022-06-26 07:24:04.368968
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    # Setup jedi script
    script = jedi.Script("print('hi', )", 3, 8, "")
    assert isinstance(script, jedi.api.Script)
    # Invoke function under test
    completions = script.completions()
    assert isinstance(completions, list)
    assert len(completions) > 0
    completion = completions[0]
    assert isinstance(completion, jedi.api.classes.Completion)
    assert completion.name == "end"
    assert completion.complete == "'end'"
    assert completion.type == "str"

# Generated at 2022-06-26 07:24:06.491368
# Unit test for function get_definitions
def test_get_definitions():
    result = get_definitions("# This is a comment\nimport math\nprint(math.sin(0.5))")
    assert result == get_definitions("# This is a comment\nimport math\nprint(math.sin(0.5))")

# Generated at 2022-06-26 07:24:08.978802
# Unit test for function get_definitions
def test_get_definitions():
    file_0 = "C:\\Users\\jason\\Desktop\\file_0.py"

    # get_definitions(file_0, 0, 0)

# Generated at 2022-06-26 07:24:12.921665
# Unit test for function get_script_completions
def test_get_script_completions():
    assert (
        get_script_completions(
            """import math
math.cos(a)""",
            row=1,
            column=2,
            filename="my_file.py",
            sys_path=["."],
        )
        == []
    )

# Generated at 2022-06-26 07:24:18.201823
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    code = 'a = 1 + 1\na.\n'
    completions = get_script_completions(code, 2, 3, '<unknown>')

    assert completions[0].name == 'real'
    return completions



# Generated at 2022-06-26 07:24:35.199853
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        try:
            interpreter = jedi.Interpreter("import sys", None, sys_path=["/usr/lib/python3.6/"])
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            interpreter = jedi.Interpreter("import sys", None)
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        interpreter = jedi.Interpreter("import sys", None)


# Generated at 2022-06-26 07:24:37.650206
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    float_0 = -614.327
    var_0 = get_interpreter_completions(float_0, [])
    assert not var_0


# Generated at 2022-06-26 07:24:45.411174
# Unit test for function get_definitions
def test_get_definitions():
    # Running an example from the original repository
    source = "import dateti"
    row = 0
    column = 8
    filename = "/home/kubic/Projects/Python/Python_Test"

    # A list of definitions should be returned
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) > 0
    assert definitions[0].module_path.endswith('datetime/__init__.py')
    assert definitions[0].start_pos == (0, 0)
    assert definitions[0].description == 'datetime'


# Generated at 2022-06-26 07:24:55.696446
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import thonny\nthonny.run_file('D:\\modules\\jedi.py')"
    namespaces = [{'type_path': ['jedi', 'api', 'environment', 'zip_environment'], 'type': 'type', 'is_generator': False, 'name': 'zip_environment', 'is_function': False, 'docstr': 'A module level variable holding an instance of :class:`Environment` for a zip file.', 'is_magic': False, 'module_path': ['jedi', 'api', 'environment'], 'module_name': 'jedi.api.environment'}]
    sys_path = ["D:\\thonny\\modules"]

    # NOTE: first use of jedi initializes a cache file
    # which takes some time.
    # If you will

# Generated at 2022-06-26 07:24:56.854571
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions()


# Generated at 2022-06-26 07:25:02.760032
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from .parser_utils import get_interpreter_completions
    import jedi
    var_0 = get_interpreter_completions("Debugging", [{}, {}, {}])
    for i in var_0:
        if jedi.__version__[0:4] == "0.18":
            assert i.name in ["Debugging", "__debug__"]
        else:
            assert i.name in ["Debugging", "__debug__", "__package__"]




# Generated at 2022-06-26 07:25:05.704853
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import os
    os.path"""
    row = 1
    column = 18
    filename = 'example_0.py'

    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0


# Generated at 2022-06-26 07:25:15.991303
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import os\n" + "import os.path\n" + "os.path.dirname(o"
    row = 3
    column = 24
    filename = "/home/vsts/work/1/s/thonny/thonnycontrib/jeditheme.py"

# Generated at 2022-06-26 07:25:17.601641
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_parent_scope

    # Test params

# Generated at 2022-06-26 07:25:26.361636
# Unit test for function get_definitions
def test_get_definitions():

    import random

    var_0 = 0
    var_1 = ""
    var_2 = 20
    var_3 = ""
    var_4 = ""
    var_5 = get_definitions(var_0, var_1, var_2, var_3)
    var_6 = []
    for var_7 in var_5:
        var_4 += str(var_7.module_path)
        var_6.append(len(var_6))
    return var_4


# Generated at 2022-06-26 07:25:44.259064
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    source = """
import random

random.rand"""
    row = 4
    column = 19
    filename = ""
    completions = get_script_completions(source, row, column, filename)
    assert isinstance(completions, list)
    print("Completions are: " + str(completions))
    assert all(isinstance(x, ThonnyCompletion) for x in completions)
    assert set([x['name'] for x in completions]) == {"randint", "randrange", "randbits", "random", "uniform", "rand", "sample", "choice", "seed"}


# Generated at 2022-06-26 07:25:50.299029
# Unit test for function get_script_completions
def test_get_script_completions():
    float_0 = -614.327
    float_2 = float_0
    float_1 = float_2
    float_3 = float_1
    float_4 = float_3
    float_5 = float_4
    float_6 = float_5
    float_7 = float_6
    float_8 = float_7


# Generated at 2022-06-26 07:25:52.959547
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test that method works without sys.path parameter
    # (sys_path will be set to None by default, see int_completions.py)
    _get_interpreter_completions()


# Generated at 2022-06-26 07:25:55.830376
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions('with open("numbers.txt", "w") as f:\n\tf.write("")\n', 0, 37, "jedi_test.py"))


# Generated at 2022-06-26 07:26:06.957886
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions(
        "Pa", 0, 2, "test.py"
    ) == get_definitions(
        "Pa", 0, 2, "test.py"
    )  # Random comment
    assert get_definitions(
        "Pa", 0, 2, "test.py"
    ) == get_definitions(
        "Pa", 0, 2, "test.py"
    )  # Random comment
    assert get_definitions(
        "Pa", 0, 2, "test.py"
    ) == get_definitions(
        "Pa", 0, 2, "test.py"
    )  # Random comment

# Generated at 2022-06-26 07:26:11.233158
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    if _using_older_jedi(jedi):
        assert get_script_completions("abs", 0, 3, "", ["C:/Program Files", "..\\test.py"]) == "abs"
    else:
        assert get_script_completions("abs", 0, 3, "", ["C:/Program Files", "..\\test.py"]) == "abs"



# Generated at 2022-06-26 07:26:20.505178
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    #  Before 0.15
    if _using_older_jedi(jedi):
        source = "import math\nm = math\n"
        row = 2
        column = 2
        filename = "example_file.py"
        script = jedi.Script(source, row, column, filename)
        assert len(script.goto_definitions()) >= 1

    #  Newer than 0.15
    else:
        source = "import math\nm = math\n"
        row = 2
        column = 2
        filename = "example_file.py"
        script = jedi.Script(code=source, path=filename)
        assert len(script.infer(line=row, column=column)) >= 1


# Generated at 2022-06-26 07:26:25.315350
# Unit test for function get_script_completions
def test_get_script_completions():
    logger.debug("start test get_script_completions")
    names = ('C','c','d','D','f','F','o','O','x','X','\0')
    var_0 = get_script_completions(names[0], names[1], names[2], names[3], names[4])
    assert var_0 is None, 'assertion failed'
    logger.debug("end test get_script_completions")



# Generated at 2022-06-26 07:26:30.948149
# Unit test for function get_script_completions
def test_get_script_completions():
    script_str = '''def test_get_script_completions():
    str_0 = 'string'
    float_0 = -614.327
    str_0 += float_0
    str_0
    '''
    completions = get_script_completions(script_str, 4, 6, "")

    assert(len(completions) > 0)
    assert(completions[0]['complete'] == "str_0 += float_0")


# Generated at 2022-06-26 07:26:31.912648
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions()

# Generated at 2022-06-26 07:26:57.459986
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("\"\"", 0, 0, "")
    assert get_script_completions("\"\"", 0, 0, "")
    assert get_script_completions("\"\"", 1, 1, "")
    assert get_script_completions("\"\"", 1, 1, "")


# Generated at 2022-06-26 07:27:04.262809
# Unit test for function get_definitions
def test_get_definitions():
    # Do not include the parse_source here
    # This will be done by the unit test
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script('4', 1, 1, 'test.py')
        script.goto_definitions()
    else:
        script = jedi.Script(code='4', path='test.py')
        script.infer(line=1, column=1)



# Generated at 2022-06-26 07:27:13.734012
# Unit test for function get_script_completions
def test_get_script_completions():
    import random
    import string
    try:
        # generate data
        float_0 = random.uniform(-50, 50)
        index_0 = random.randrange(0, 9)
        source_0 = ''.join(random.choice(string.ascii_letters) for i in range(random.randint(1, 100)))
        filename_0 = ''.join(random.choice(string.ascii_letters + '_') for i in range(random.randint(1, 100)))
        sys_path_0 = [''.join(random.choice(string.ascii_letters + '_') for i in range(random.randint(1, 100))) for i in range(random.randint(1, 100))]
    except:
        # catch exceptions to prevent unit test from crashing
        raise Exception


# Generated at 2022-06-26 07:27:24.748730
# Unit test for function get_definitions
def test_get_definitions():
    s = """
    def my_func(arg):
        while True:
            print("First!")
            break
        if len("First!") == 7:
            print("Second!")
        else:
            print("Third!")

    my_func("First!")

    """

# Generated at 2022-06-26 07:27:25.920075
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert (test_get_interpreter_completions_0())


# Generated at 2022-06-26 07:27:35.436231
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import inspect

    filename = "test_get_definitions.py"
    src = inspect.getsource(test_case_0)

    completions = get_script_completions(src, 1, 0, filename)
    assert len(completions) > 0
    assert completions[0].name == "float"
    assert completions[0].complete == "float"
    assert completions[0].type == "class"
    assert completions[0].description == "float(...) float(x) -> floating point number"
    assert completions[0].parent is not None
    assert completions[0].full_name == "float"



# Generated at 2022-06-26 07:27:45.588394
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'from math import *\nfrom turtle import *\ntr = Turtle()\ntr.fd(120)\ntr.lt(10)\ntr.'
    namespaces = [{"foo": 42}]
    test_get_interpreter_completions_0 = get_interpreter_completions(source, namespaces, sys_path=None)
    assert len(test_get_interpreter_completions_0) == 61
    assert test_get_interpreter_completions_0[0].name == "pos()"
    assert test_get_interpreter_completions_0[60].name == "xcor()"


# Generated at 2022-06-26 07:27:51.848110
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    test_string_0 = "print('this is a string')"
    namespaces_0 = [{}]
    var_0 = get_interpreter_completions(test_string_0, namespaces_0)
    assert(len(var_0) == 5)
    assert(var_0[0].complete == "print")



# Generated at 2022-06-26 07:27:55.233705
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "11"
    row = 4
    column = 4
    filename = "script.py"
    sys_path = None
    get_script_completions(source, row, column, filename, sys_path)


# Generated at 2022-06-26 07:28:05.220814
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_parso_0 = parse_source("""
print("hello")
""")
    var_0 = get_statement_of_position(test_parso_0, 6)
    var_1 = var_0.type
    var_2 = var_0.start_pos

    var_3 = get_interpreter_completions("""
print("hello")
""", [{}], {"/foo"})
    var_4 = var_3[0].type
    var_5 = var_3[0].start_pos

    var_6 = get_script_completions("""
print("hello")
""", 1, 6, "spam.py", ["/foo"])
    var_7 = var_6[0].type
    var_8 = var_6[0].start_pos

#

# Generated at 2022-06-26 07:28:24.931426
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_backend import jedi_utils

    # If no arguments passed
    assert len(jedi_utils.get_interpreter_completions(None, None)) == 192

    # If no third argument passed
    assert len(jedi_utils.get_interpreter_completions("", "", None)) == 192



# Generated at 2022-06-26 07:28:28.828990
# Unit test for function get_script_completions
def test_get_script_completions():
    int_0 = 77
    int_1 = 10
    var_0 = get_script_completions(int_0, int_1, int_0, int_1)
    var_1 = get_script_completions(var_0, int_1, int_0, int_1)



# Generated at 2022-06-26 07:28:34.902247
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    with open("./testcase/test_get_script_completions.py") as f:
        text = f.read()
    if _using_older_jedi(jedi):
        script = jedi.Script(text, 1, 2, "")
        completions = script.completions()
    else:
        script = jedi.Script(code=text, path="")
        completions = script.complete(line=1, column=2)

    assert completions[0].name == "import"
    assert completions[-1].name == "float"


# Generated at 2022-06-26 07:28:36.090852
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_parent_scope

# Generated at 2022-06-26 07:28:44.077277
# Unit test for function get_definitions
def test_get_definitions():
    float_0 = -614.327
    var_0 = parse_source(float_0)
    float_1 = -614.327
    var_1 = parse_source(float_1)
    float_2 = -614.327
    var_2 = parse_source(float_2)
    float_3 = -614.327
    var_3 = parse_source(float_3)
    float_4 = -614.327
    var_4 = parse_source(float_4)
    float_5 = -614.327
    var_5 = parse_source(float_5)
    float_6 = -614.327
    var_6 = parse_source(float_6)
    float_7 = -614.327
    var_7 = parse_source(float_7)
    float_8 = -614

# Generated at 2022-06-26 07:28:51.200018
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import patch
    import jedi
    
    # Patching jedi to avoid unwanted calls to jedi.Interpreter
    with patch("thonny.jediutils.jedi.Interpreter") as mocked_jediInterpreter:
        mocked_jediInterpreter.return_value.complete.return_value = "test_1"
        result = get_interpreter_completions("test_2", "test_3", "test_4", "test_5")
        assert result == "test_1"


# Generated at 2022-06-26 07:28:55.153618
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import os", 2, 8, None) == \
        [ThonnyCompletion(name='os', complete='os', type='module', description='import os', parent=None, full_name='os')]


# Generated at 2022-06-26 07:29:01.122779
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    from jedi.evaluate import sys_path
    node = parso.parse("from math import *")
    namespaces = [{"name": "__main__", "node": node, "type": "module"}]
    completions = get_interpreter_completions("", namespaces, sys_path=sys_path)
    names = [c.name for c in completions]
    assert "cos" in names
    assert "log" in names
    assert "as" not in names
    assert "assert" not in names
    assert "abs" in names



# Generated at 2022-06-26 07:29:08.002472
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-26 07:29:16.347140
# Unit test for function get_script_completions
def test_get_script_completions():
    float_0 = 5.004737787629
    float_1 = 6.441068335818
    float_2 = 6.309379127123
    float_3 = 5.966294049538
    float_4 = 8.279909292882
    float_5 = 2.247751334343
    float_6 = -6.829888905251
    str_0 = "!\u0016\u001d\u0003"
    int_0 = -36301
    float_7 = 3.872100964918
    var_0 = parse_source(float_0)
    
    
    
    
    



# Generated at 2022-06-26 07:29:44.953294
# Unit test for function get_script_completions
def test_get_script_completions():
    import os, sys
    # detect python version
    if sys.version_info.major == 3:
        from jedi.api import Script
        from jedi.api import Interpreter
        from jedi.api import ScriptWithProject
    else:
        from jedi import Script
        from jedi import Interpreter
        from jedi import ScriptWithProject
    # test on python version 3.8.3
    if sys.version_info.major == 3 and sys.version_info.minor == 8 and sys.version_info.micro == 3:
        assert Script('import datetime', row=0, column=7).completions()[0].__getitem__("name") == "datetime"

# Generated at 2022-06-26 07:29:50.668175
# Unit test for function get_definitions
def test_get_definitions():
    ctx = test_context()
    ctx.open_script("main.py", 'import math')
    ctx.open_view(ExampleCodeView, "math")
    ctx.text = "math.pi"
    ctx.execute_in_frontend(ctx.text, 'main.py', 0)
    ctx.check_expected_output(False)


# Generated at 2022-06-26 07:29:53.332475
# Unit test for function get_definitions
def test_get_definitions():
    print(get_definitions('import sys\nsys.path', 0, 18, 'test.py'))


# Generated at 2022-06-26 07:30:02.499295
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Testing get_interpreter_completions ...")

# Generated at 2022-06-26 07:30:09.689120
# Unit test for function get_script_completions
def test_get_script_completions():
    source_0 = "import os"
    row_0 = 0
    column_0 = 6
    filename_0 = "src/jedi.py"
    sys_path_0 = []
    assert get_script_completions(source_0, row_0, column_0, filename_0, sys_path_0) == []

    row_1 = 0
    column_1 = 7
    sys_path_1 = ["src/jedi.py"]
    assert get_script_completions(source_0, row_1, column_1, filename_0, sys_path_1) == []

    source_2 = "from sys import "
    row_2 = 0
    column_2 = 16
    sys_path_2 = ["C:/Users/thomas/Documents/workspace/jedi"]
    assert get

# Generated at 2022-06-26 07:30:12.758136
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    s = 'def f(param1, param2, *args, **kwargs):\n    pass\nf(1, 2, 3, 4'
    res = get_script_completions(s, 2, 13, "")
    print(res)



# Generated at 2022-06-26 07:30:16.184410
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter


# Generated at 2022-06-26 07:30:17.350218
# Unit test for function get_definitions
def test_get_definitions():
    # TODO: add tests after understanding the Jedi API better
    pass


# Generated at 2022-06-26 07:30:24.727874
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """x=2
y=3"""
    row = 1
    column = 0
    filename = "/tmp/file.py"
    sys_path = ["/home/user/lib/python2.6/dist-packages/"]
    assert_get_script_completions(source, row, column, filename, sys_path)
    source = """x=2
y=3"""
    row = 1
    column = 0
    filename = "/tmp/file.py"
    sys_path = None
    assert_get_script_completions(source, row, column, filename, sys_path)



# Generated at 2022-06-26 07:30:26.306435
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions("name", [])


# Generated at 2022-06-26 07:30:44.255421
# Unit test for function get_definitions

# Generated at 2022-06-26 07:30:47.122238
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_1 = get_interpreter_completions(var_0, [], input)
    if '__abs__' in var_1:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 07:30:49.680303
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
a = 5
a.app"""
    row = 2
    column = 5
    result = get_script_completions(source, row, column, "test.py")
    assert len(result) > 0



# Generated at 2022-06-26 07:30:55.019926
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock
    import jedi
    mock = Mock()
    mock.completions = lambda: [ThonnyCompletion('var_0', 'var_0', 'param', 'param', 'param', 'param')]
    jedi.Script = Mock(return_value=mock)
    result = get_script_completions('source', 1, 2, 'file')
    assert result == [ThonnyCompletion('var_0', 'var_0', 'param', 'param', 'param', 'param')]

# Generated at 2022-06-26 07:30:57.379271
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    script_0 = Script('', 1, 1, '')
    var_0 = get_script_completions(script_0)


# Generated at 2022-06-26 07:31:03.627087
# Unit test for function get_script_completions
def test_get_script_completions():
    from os.path import expanduser
    import sys
    import unittest

    from test.config import test_dir

    home = expanduser("~")
    sys.argv[0] = "/Users/student/Thonny/thonny/workbench.py"
    sys.path.append("/usr/local/lib/python3.7/site-packages")
    sys.path.append("/Users/student/Thonny/thonny, /Users/student/Thonny")

    class TestGetScriptCompletions(unittest.TestCase):
        def test_0(self):
            source = ""
            row = 0
            column = 0
            filename = test_dir + "test_get_script_completions.py"

# Generated at 2022-06-26 07:31:05.574227
# Unit test for function get_definitions
def test_get_definitions():
    pass
    # TODO: need real examples
    # result = get_definitions(arg_0)
    # assert isinstance(result, list)



# Generated at 2022-06-26 07:31:10.492573
# Unit test for function get_script_completions
def test_get_script_completions():
    int_0 = 0
    str_0 = "abc"
    bool_0 = True
    None_0 = None
    var_0 = (int_0, str_0, bool_0, None_0,)
    var_1 = parse_source("abc")
    var_2 = get_script_completions(var_0, var_1, var_2)
    return var_2


# Generated at 2022-06-26 07:31:17.347322
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_cached_code_lines

    code_lines = ["def f(x): return x.split()", "a = f(1)"]
    get_cached_code_lines.cache_clear()
    result = get_definitions(code_lines, 2, 7, "test.py")
    assert len(result) == 1
    assert result[0].module_name == "builtins"
    assert result[0].name == "int"
    assert result[0].line == 0
    assert result[0].column == 0


# Generated at 2022-06-26 07:31:20.866572
# Unit test for function get_definitions
def test_get_definitions():
    import ast
    import jedi

    var_0 = get_definitions(ast.Str, 0, 0, 0)
    assert var_0 == jedi.Script(ast.Str, 0, 0, 0).goto_definitions()


# Generated at 2022-06-26 07:32:13.469950
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.script import Script

    class ScriptMock(Script):
        def __init__(self, source, row, column, filename):
            pass

        def completions(self):
            return [ThonnyCompletion(name='int', complete='int', type='', description='',
                                     parent='', full_name='')]

    jedi.Script = ScriptMock
    assert get_script_completions('path.to.file', 1, 1, '') == [
        {'name': 'int', 'complete': 'int', 'type': '', 'description': '', 'parent': '', 'full_name': ''}]



# Generated at 2022-06-26 07:32:18.251832
# Unit test for function get_script_completions
def test_get_script_completions():
    def assert_completions_equal(actual, expected):
        assert actual
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected):
            assert a.name == e[0]
            assert a.complete == e[1]
            assert a.type == e[2]
            assert a.description == e[3]
            assert a.parent == e[4]

    assert_completions_equal(
        get_script_completions("import sys", 0, 0, "test.py"),
        [
            ("sys", "sys", "module", "This module provides access to some objects used or maintained by the\ninterpreter and to functions that interact strongly with the interpreter.\nDynamic objects:", "")
        ],
    )



# Generated at 2022-06-26 07:32:26.450912
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    from jedi import Script
    from jedi.evaluate.helpers import FakeName
    from jedi.evaluate import compiled
    from jedi import Interpreter
    from jedi import settings
    from jedi import parser_utils
    namespaces = [{'numbers': ['int'], '__builtins__':[]}, {'int': ['x']}]
    source = "x"
    interpreter = Interpreter(source, namespaces, sys_path=[])
    completions = interpreter.complete()
    if not isinstance(completions, list):
        raise ValueError('Wrong type of return value, expected "list", got "%s"' % (type(completions)))

# Generated at 2022-06-26 07:32:31.647168
# Unit test for function get_script_completions
def test_get_script_completions():
    import time

    start_time = time.time()
    source = "def foo(arg1, arg2):\n    print(arg1)\nfoo(1, 2)"
    row = 2
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    end_time = time.time()

    assert completions[0].name == "arg1"
    assert completions[1].name == "arg2"
    print("time taken ", end_time - start_time)



# Generated at 2022-06-26 07:32:35.837706
# Unit test for function get_definitions
def test_get_definitions():
    source = """import math\n"""
    row = 1
    column = 14
    filename = None
    definitions = get_definitions(source, row, column, filename)
    assert "math" in definitions[0].module_path
    assert "math" in definitions[0].name


# Generated at 2022-06-26 07:32:38.386435
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    data = get_interpreter_completions("pyserial", [], None)
    assert "Serial" in data and "SerialException" in data and "SerialTimeoutException" in data



# Generated at 2022-06-26 07:32:39.215390
# Unit test for function get_definitions
def test_get_definitions():
    assert False



# Generated at 2022-06-26 07:32:44.581331
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import jedi

    src = '''
    def a(x):
        ''' + '"""'
    src += '''
    """
    '''
    src += '''
    class a:
        pass
    '''
    src += '''
    def a(x):
        ''' + '"""'
    src += '''
    """
    '''
    src += '''
    class b:
        ''' + '"""'
    src += '''
    """
    '''
    src += '''
    def b(x):
        ''' + '"""'
    src += '''
    """
    '''

# Generated at 2022-06-26 07:32:51.162390
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    source = "import math\nmath.cos"
    if _using_older_jedi(jedi):
        script = jedi.Script(source, 2, 10, None)
        completions = script.goto_definitions()
    else:
        script = jedi.Script(code=source, path=None)
        completions = script.infer(line=2, column=10)
    
    assert len(completions) > 0


# Generated at 2022-06-26 07:32:54.411879
# Unit test for function get_script_completions
def test_get_script_completions():
    float_0 = float(-614.327)
    var_0 = parse_source(float_0)
    var_1 = get_script_completions(var_0, float_0, float_0, float_0, float_0)
    var_2 = get_script_completions(var_0, float_0, float_0, float_0, float_0)
    var_3 = get_script_completions(var_0, float_0, float_0, float_0, float_0)
