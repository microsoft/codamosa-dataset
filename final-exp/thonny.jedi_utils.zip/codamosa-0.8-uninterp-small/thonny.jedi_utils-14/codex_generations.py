

# Generated at 2022-06-26 07:23:31.644267
# Unit test for function get_definitions
def test_get_definitions():
    assert str(type(get_definitions("", 0, 0, ""))) == "<class 'list'>"

# Generated at 2022-06-26 07:23:41.788578
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 =  ''
    list_0 = []
    list_1 = []
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())
    list_1.append(dict())

# Generated at 2022-06-26 07:23:45.095855
# Unit test for function get_definitions
def test_get_definitions():
    int_0 = -1107
    str_0 = '4.4.3.3'
    var_0 = get_definitions(str_0, int_0, int_0, str_0)


# Generated at 2022-06-26 07:23:48.005980
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = '#cc9393'
    int_0 = -722
    var_0 = get_script_completions(str_0, int_0, int_0, str_0)



# Generated at 2022-06-26 07:23:52.155526
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    sys_path = ["/home/jenni/code/thonny"]
    str_0 = '#cc9393'
    int_0 = -722
    var_0 = get_interpreter_completions(str_0, [], sys_path)
    assert var_0 is not None


# Generated at 2022-06-26 07:24:03.942896
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = '#cc9393'
    int_0 = -722
    str_1 = 'import argparse\n\n\nif __name__ == \'__main__\':\n    parser = argparse.ArgumentParser()\n     = (\n        \"--config\",\n        '
    str_2 = '#B9BFF3'
    str_3 = 'h2'
    str_4 = '\n    import bsddb3\n    bsddb3._test()'
    data_0 = get_interpreter_completions(str_1, [{}], [str_2])
    assert len(data_0) == 0

# Generated at 2022-06-26 07:24:13.762331
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print('Testing get_interpreter_completions')
    str_0 = '#cc9393'
    int_0 = -722
    list_0 = []
    tuple_0 = (dict_0,)
    dict_0 = {}
    obj_0 = ThonnyCompletion(str_0, str_0, str_0, list_0, str_0, list_0)
    any_0 = get_interpreter_completions(str_0, tuple_0, list_0)

    # '#86aec7'
    # str_1 = get_script_completions(str_0, int_0, int_0, str_0, list_0)

    return


# Generated at 2022-06-26 07:24:24.188718
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple
    from jedi import Script

    Item = namedtuple("Item", ["name", "complete", "type", "description", "parent", "full_name"])

    source = """
        import json
        with open("myfile.txt", "w") as f:
            json.dump(data, f, ensure_ascii=False)
    """

    completions = get_script_completions(source, 4, 23, "test")
    assert len(completions) == 1
    completion: ThonnyCompletion = completions[0]
    assert completion.name == "dump"
    assert completion.complete == "dump("
    assert completion.type == "function"
    assert completion.description.startswith("dump(")
    assert completion.parent.name == "json"

    # j

# Generated at 2022-06-26 07:24:38.132432
# Unit test for function get_definitions
def test_get_definitions():
    str_0 = '@'
    int_0 = -722
    var_0 = get_definitions(str_0, int_0, int_0, str_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 0
    assert var_0 == []

    str_0 = '()['
    int_0 = -602
    var_0 = get_definitions(str_0, int_0, int_0, str_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 3
    assert var_0[0].name == '__getitem__'
    assert var_0[0].line == 1
    assert var_0[0].column == 3

# Generated at 2022-06-26 07:24:39.317689
# Unit test for function get_definitions
def test_get_definitions():
    assert test_case_0() == None

# Generated at 2022-06-26 07:25:05.118923
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from random import random
    from math import floor

    str_0 = '9'
    str_1 = 'g'
    str_2 = '"'
    str_3 = 'in5r5z'
    str_4 = '58'
    str_5 = 'i'
    str_6 = 'z'
    str_7 = 'y'
    str_8 = '1'
    str_9 = '@'
    str_10 = 'j'
    str_11 = 'hD'
    str_12 = '<'
    list_0 = []
    list_1 = [0, 1]
    list_2 = [2, 3]
    list_3 = [1, 2]
    list_4 = [0, 1, 2, 3]

# Generated at 2022-06-26 07:25:08.768603
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = '#cc9393'
    int_0 = -722
    array_0 = []
    var_0 = get_interpreter_completions(str_0, array_0)
    assert not var_0


# Generated at 2022-06-26 07:25:11.619291
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test that the first completion contains the expected string
    assert get_script_completions('1=1', 0, 0, '')[0].name == 'abstractmethod'


# Generated at 2022-06-26 07:25:14.241605
# Unit test for function get_script_completions
def test_get_script_completions():

    tested_value = get_script_completions(str_0, int_0, int_0, str_0)

    assert tested_value is None


# Generated at 2022-06-26 07:25:21.203851
# Unit test for function get_script_completions
def test_get_script_completions():
    int_0 = 0
    int_1 = 1
    str_0 = '\x1b[?1034h\n'
    str_1 = '\x1b[?1034l\x1b[?1048h\x1b[?1049h\x1b[?r\x1b[?1049l\x1b[?1048l\x1b[?1000h\x1b[?1030h\x1b[27m\x1b[?1034h\n'

# Generated at 2022-06-26 07:25:30.402687
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = '#eceff4'
    str_1 = '#eceff4'
    str_2 = '#eceff4'
    dict_0 = dict()
    dict_0['#eceff4'] = '#eceff4'
    list_0 = list()
    list_0.append(dict_0)
    var_0 = get_interpreter_completions(str_0, list_0, str_1)
    var_1 = get_interpreter_completions(str_2, list_0)


# Generated at 2022-06-26 07:25:34.622765
# Unit test for function get_script_completions
def test_get_script_completions():
    from .utils import get_test_config

    for pyscript in get_test_config("scripts"):
        for snippet in get_test_config("snippets"):
            _test_get_script_completions(pyscript, snippet)



# Generated at 2022-06-26 07:25:40.951944
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.parser_utils import get_cached_code

    user_scope = [{'x': 1}]
    results = get_interpreter_completions('x', user_scope)
    print(results)
    #assert results == [Completion(name='x', complete='x', type='statement', description='int', parent='int')]


# Generated at 2022-06-26 07:25:43.733544
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test the case where Json can't parse the argument namespaces

    # Create the expected value
    
    # The actual value is obtained
    value = get_interpreter_completions()

    # The expected and actual values are compared
    assert value == expected


# Generated at 2022-06-26 07:25:48.919141
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = '#cc9393'
    int_0 = -722
    var_0 = get_script_completions(str_0, int_0, int_0, str_0)


# Generated at 2022-06-26 07:26:11.198366
# Unit test for function get_definitions
def test_get_definitions():
    source = "from tkinter import *\r"
    row = 1
    column = 15
    filename = "test.py"
    def_0 = get_definitions(source, row, column, filename)
    # print(def_0[0].description)


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-26 07:26:12.930208
# Unit test for function get_definitions

# Generated at 2022-06-26 07:26:20.139167
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    class TestCase(unittest.TestCase):
        def test_local_variable(self):
            var_0 = get_definitions('a=1', 0, 3, 'test')
            var_1 = var_0[0]
            self.assertEqual(var_1.line, 0)
            self.assertEqual(var_1.column, 0)
            self.assertEqual(var_1.module_path, 'test')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-26 07:26:21.745387
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("from math import sqrt", 0, 18, None) != None

# Generated at 2022-06-26 07:26:29.660515
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import tempfile
    import jedi

    if _using_older_jedi(jedi):
        expected = ['print']
    else:
        expected = ['print(', 'print']

    # Test case 1
    # Create a dummy file
    tmp = tempfile.NamedTemporaryFile(mode='w', delete=False)
    tmp.write('print(5)')
    tmp.close()

    # Get the completion
    completions = get_script_completions(source='print(5)', row=1, column=0, filename=tmp.name)

    # Compute results
    completion = [completion.name for completion in completions]

    # Delete dummy file
    os.unlink(tmp.name)

    # Compare
    assert completion == expected



# Generated at 2022-06-26 07:26:33.215338
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from textwrap import dedent

    source = """
    from collections import namedtuple
    Point = namedtuple('Point', ['x', 'y'])
    Point(5, 2)
    """
    completions = get_interpreter_completions(
        source=dedent(source), namespaces=[], sys_path=["./resources/jedi_version_fix"]
    )
    assert not completions



# Generated at 2022-06-26 07:26:35.425732
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions() == []


# Generated at 2022-06-26 07:26:36.864031
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert False # Test not implemented


# Generated at 2022-06-26 07:26:47.715178
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'import os\n' \
             'os.path.g'
    row=2
    column=10
    filename=''

    result = get_script_completions(source, row, column, filename)
    assert result != None

    for item in result:
        if item.name == 'join':
            assert item.name == 'join'
            assert item.complete == 'join('
            assert item.type == 'function'
            assert item.description == 'str.join(iterable, /) --> str\n' \
                                       '    Concatenate any number of strings.\n' \
                                       '\n' \
                                       '    The string whose method is called is inserted in between each given string.\n' \
                                       '    The result is returned as a new string.\n' \
                

# Generated at 2022-06-26 07:26:48.929495
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions()



# Generated at 2022-06-26 07:27:12.615908
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test execution of function get_interpreter_completions
    assert get_interpreter_completions("", [{}]) is not None, "return value is None"


# Generated at 2022-06-26 07:27:24.280179
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from threading import Thread\nfrom time import sleep\nThread(target=sleep, args=(0.1,))"
    namespaces = [{"threading": Thread}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 7
    assert completions[0].name == "name"
    assert completions[0].complete == "name="
    assert completions[0].description == "Name of the thread."
    assert completions[0].type == "param"
    assert completions[0].parent == "threading.Thread"
    assert completions[0].full_name == "name"

    # Ensure completions work with args in a different line

# Generated at 2022-06-26 07:27:29.159170
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    Test the get_interpreter_completions function.
    """
    # Generate a string of Python code that imports math
    set_0 = {'import math'}
    # Use the function to analyze the code
    var_0 = get_interpreter_completions(set_0, [])


# Generated at 2022-06-26 07:27:33.669435
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\n"
    namespaces = []
    assert get_interpreter_completions(source, namespaces) != None

    source = "import os\n"
    assert get_interpreter_completions(source, namespaces) != None



# Generated at 2022-06-26 07:27:34.898577
# Unit test for function get_definitions

# Generated at 2022-06-26 07:27:43.273136
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        try:
            result = get_script_completions(1, 1, 2, 3)
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            result = get_script_completions(*(1, 2, 3, 4))
    else:
        result = get_script_completions(1, 2, 3, 4, sys_path=[1, 2])
    return result



# Generated at 2022-06-26 07:27:46.264435
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    script = """import sys\n"""
    namespaces = [{}]
    sys_path = ["C:\\Users\\xyz\\Desktop\\abc.txt"]
    assert get_interpreter_completions(script, namespaces, sys_path) == []

# Generated at 2022-06-26 07:27:51.575427
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "a = 1\na.real"
    row = 1
    column = 7
    filename = "test.py"
    result = get_script_completions(source, row, column, filename)
    assert result[0].name == "real"


# Generated at 2022-06-26 07:27:59.678210
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    var_0 = {'a': 5}
    var_1 = 'a.sort().reverse()'
    var_2 = get_interpreter_completions(var_1, var_0)
    var_3 = jedi.Completion()
    assert var_2[0].name == var_3.name
    assert var_2[0].complete == var_3.complete
    assert var_2[0].type == var_3.type
    assert var_2[0].description == var_3.description
    assert var_2[0].parent == var_3.parent


# Generated at 2022-06-26 07:28:08.323675
# Unit test for function get_definitions
def test_get_definitions():
    val_0: str
    val_1: str
    val_2: str
    val_3: str
    val_4: str
    val_5: str
    val_6: str
    val_7: str
    val_8: str
    val_9: str
    val_10: str
    val_11: str
    val_12: str
    val_13: str
    val_14: str
    val_15: str
    val_16: str
    val_17: str
    val_18: str
    val_19: str
    val_20: str
    val_21: str
    val_22: str
    val_23: str
    val_24: str
    val_25: str
    val_26: str
    val_27: str
    val_

# Generated at 2022-06-26 07:28:40.433655
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """ Unit test for function get_interpreter_completions
    """

    test_data_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test.py')
    test_data = open(test_data_file, 'r', encoding='utf-8')
    lines = test_data.readlines()
    last_line = lines[-1]
    pos = len(last_line) - 1 # Last character in file
    row = len(lines)         # Last row in file
    column = len(last_line)  # Last column in file
    source = ''.join(lines)

    logger.info('source = %r', source)
    logger.info('pos = %r, row = %r, column = %r', pos, row, column)
   

# Generated at 2022-06-26 07:28:42.390927
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = "hello "
    str_1 = " world"
    print(str_0 + str_1)

# Generated at 2022-06-26 07:28:47.678050
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{}]
    source = 'x = abc\nabc\nabc\nabc'
    output = [ThonnyCompletion(name='abc', complete='abc', type='statement', description='abc', parent=None, full_name='abc')]
    assert get_interpreter_completions(source, namespaces) == output, "function get_interpreter_completions does not work!"


# Generated at 2022-06-26 07:28:57.452853
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = 'd+=W"a?jM#*'
    str_1 = '4'
    int_0 = test_get_script_completions.int_0
    int_1 = test_get_script_completions.int_1
    str_2 = '!E7V{z:JlgZ'
    str_3 = 'd+=W"a?jM#*'
    list_0 = [str_3]
    set_0 = {str_3}
    def func_0():
        str_3 = 'd+=W"a?jM#*'
    str_4 = 'd+=W"a?jM#*'
    str_5 = '4'
    int_2 = test_get_script_completions.int_2
    int_3

# Generated at 2022-06-26 07:29:04.614113
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    global testcount
    testcount = 0
    print("Testing get_interpreter_completions...")
    # Basic test
    assert(get_interpreter_completions("a", []), "a")
    print("Passed basic test for get_interpreter_completions.")
    testcount += 1
    # Shouldn't complete when given different character
    assert(get_interpreter_completions("b", []), "None")
    print("Passed second test for get_interpreter_completions.")
    testcount += 1
    # Should complete on import
    assert(get_interpreter_completions("import ", []), "import ")
    print("Passed third test for get_interpreter_completions.")
    testcount += 1
    # Shouldn't complete anything

# Generated at 2022-06-26 07:29:06.983724
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'import os\n'
    row = 1
    column = 8
    filename = 'test'
    get_script_completions(source, row, column, filename)


# Generated at 2022-06-26 07:29:09.861126
# Unit test for function get_definitions
def test_get_definitions():
    source = "import math\nmath.sqrt"
    row = 1
    column = 13

    filename = ""

    script = get_definitions(source, row, column, filename)
    assert script[0].full_name == "math.sqrt"

# Generated at 2022-06-26 07:29:18.463548
# Unit test for function get_definitions
def test_get_definitions():
    from parso.utils import split_lines

    sys_path = []
    source = split_lines(
        """
    from random import randint
    from collections import namedtuple
    import unittest

    Point = namedtuple('Point', ['x', 'y'])

    def foo(a, b):
        c = a + b
        return c

    def bar(a, b):
        c = a + b
        return c

    class MyTest(unittest.TestCase):
        def test_add(self):
            my_sum = foo(1, 2)
            self.assertEqual(my_sum, 3)

        def test_add_three(self):
            my_sum = foo(1, 2)
            self.assertEqual(my_sum, 3)
    """
    )
   

# Generated at 2022-06-26 07:29:27.474973
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:29:31.952456
# Unit test for function get_definitions
def test_get_definitions():
    source = "from math import log\nlog(1)"
    
    # Verify that it works
    definitions = get_definitions(source, 2, 4, "script.py")
    assert len(definitions) == 1
    assert definitions[0].module_path == "math.py"
    assert definitions[0].line == 98
    assert definitions[0].column == 0
    

# Generated at 2022-06-26 07:30:20.114097
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    global _completions
    global _namespaces
    global _source
    global _sys_path
    global _sys_path2
    _namespaces = [{}]
    _source = ''
    _sys_path = ['q3"0\xb3MWy?', '']
    _sys_path2 = []
    _completions = get_interpreter_completions(_source, _namespaces, _sys_path)



# Generated at 2022-06-26 07:30:23.400354
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Throws exception given incorrect parameters
    try:
        get_interpreter_completions(1, 1, 1, 1)
    except TypeError:
        assert True
    except AssertionError:
        assert False
    except:
        assert False


# Generated at 2022-06-26 07:30:31.438289
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    from thonny.misc import running_on_windows
    from os.path import join as join_path
    from thonny.plugins.jedi_utils import get_definitions
    import traceback
    import time
    import re

    test_set_filename = join_path('test', 'test-files', 'test_module_1.py')
    test_single_filename = join_path('test', 'test-files', 'test_module_2.py')
    class_test_filename = join_path('test', 'test-files', 'test_module_3.py')
    no_def_test_filename = join_path('test', 'test-files', 'test_module_4.py')

# Generated at 2022-06-26 07:30:36.557428
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    import jedi
    script = jedi.Script('from math import', 9, 18, '/tmp/test.py')
    assert isinstance(get_script_completions(script), list)
    assert all(isinstance(c, Completion) for c in get_script_completions(script))

# Generated at 2022-06-26 07:30:43.479061
# Unit test for function get_script_completions
def test_get_script_completions():
    import tempfile
    import jedi

    test_file_path = tempfile.mkstemp()
    test_file = open(test_file_path, "w")
    test_file.write("print(\"hi\"")
    test_file.close()

    if _using_older_jedi(jedi):
        c = get_script_completions("", 1, 8, test_file_path)
        assert c[0]['name'] == 'input'
    else:
        c = get_script_completions("", 1, 8, test_file_path)
        assert c[0].name == 'input'

# Generated at 2022-06-26 07:30:48.086533
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys; p = sys.path_importer_cache"
    row = 1
    column = 31
    filename = "syspath.py"
    sys_path = ["/home/tomas/thonny", "/usr/lib/python3.6/"]
    completions = get_script_completions(source, row, column, filename, sys_path)
    assert completions is not None


# Generated at 2022-06-26 07:30:51.697853
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    source = 'import re\n'
    row = 1
    column = 8
    filename = 'test.py'
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].module_name == 're'


# Generated at 2022-06-26 07:30:54.208311
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = 'd+=W"a?jM#*'
    set_0 = {str_0}
    var_0 = get_script_completions(str_0, set_0)



# Generated at 2022-06-26 07:30:56.421465
# Unit test for function get_definitions
def test_get_definitions():
    source = """
        
        """
    result = get_definitions(source, 1, 2, "test_1.py")
    assert len(result) == 0



# Generated at 2022-06-26 07:31:03.054775
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso

    # Placeholder

# Generated at 2022-06-26 07:31:59.418629
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.languages.python.jedi_utils import get_interpreter_completions
    from parso.python.tree import Module
    from parso.python.tree import Node
    from parso.python.tree import Operator
    from parso.python.tree import Name
    from parso.python.tree import Array
    from parso.python.tree import Number
    from parso.python.tree import Call
    from parso.python.tree import Keyword
    import unittest
    import ast
    import jedi

    class Test(unittest.TestCase):

        def test_0(self):
            jedi.Interpreter("", [{}])


# Generated at 2022-06-26 07:32:12.101323
# Unit test for function get_script_completions
def test_get_script_completions():
    """Test case for function get_script_completions"""
    from astroid import MANAGER, parse
    from pylint.utils import get_global_option
    from astroid.builder import AstroidBuilder
    from astroid import scoped_nodes
    MANAGER.astroid_cache.clear()
    test_file = "code.py"
    test_code = "c = datetime.datetime.now()"
    test_row = 1
    test_column = 16
    expected_type = "<class 'datetime.datetime'>"
    expected_name = "now"
    expected_complete = "now"
    expected_parent = "datetime"
    expected_full_name = "datetime.datetime.now"
    expected_type_2 = "<class 'datetime.datetime'>"
    expected

# Generated at 2022-06-26 07:32:17.491967
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from os import getcwd
    from sys import path


# Generated at 2022-06-26 07:32:22.655955
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = '''import re\ndef foo(a=1):\n  return re.match'''
    completions = get_script_completions(script, 2, 20, 'test.py')
    for c in completions:
        print(c.name)
    assert len([c for c in completions if c.name == 're.match']) == 1
    return completions


# Generated at 2022-06-26 07:32:27.337593
# Unit test for function get_script_completions
def test_get_script_completions():
    def assertEqual(expected, actual):
        if expected != actual:
            raise Exception(f"expected '{expected}', but got '{actual}'")
    def call_get_script_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    #This test is to test parsing of non-ascii characters
    assertEqual([], call_get_script_completions('"öäü"', 1, 5, "test.py"))



# Generated at 2022-06-26 07:32:33.555977
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:32:41.668952
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    import jedi
    import time    

    path = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join("tests", path)
    os.makedirs(path)
    
    for i in range(10**2):
        # Create a test program
        source = "var_0 = get_interpreter_completions( int_0, int_0, int_0 )"
        nb_vars = 10**1
        for j in range(nb_vars):
            while True:
                var = "".join([random.choice(string.ascii_letters + string.digits) for n in range(random.randint(3, 12))])

# Generated at 2022-06-26 07:32:52.885680
# Unit test for function get_script_completions
def test_get_script_completions():
    int_0 = 1
    int_1 = 1
    int_2 = 1
    int_3 = 1
    int_4 = 1
    int_5 = 1
    int_6 = 1
    int_7 = 1
    str_0 = "1"
    int_8 = 1
    list_0 = [1, 1, 1, 1, 1]
    str_1 = "1"
    str_2 = "1"
    var_0 = get_script_completions(str_0, int_0, int_1, str_1, list_0)
    int_0 = 1
    str_3 = "1"
    int_1 = 1
    list_1 = [1, 1, 1, 1, 1]

# Generated at 2022-06-26 07:33:00.244904
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """async def g():
            await t
            """.splitlines(True)
    row, column = 2, 0
    filename = None
    script = get_script_completions(source, row, column, filename)
    assert script is not None
    for c in script:
        assert c.type == "keyword"


if __name__ == "__main__":
    import jedi

    print("Jedi version", jedi.__version__, "in use")
    print("Using older jedi:", _using_older_jedi(jedi))

# Generated at 2022-06-26 07:33:00.776244
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert True