

# Generated at 2022-06-26 07:23:19.948391
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    list_0 = []
    list_1 = [list_0, list_0]
    var_0 = get_interpreter_completions(list_1)


# Generated at 2022-06-26 07:23:20.978635
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import datetim", 0, 8, "")

# Generated at 2022-06-26 07:23:25.297591
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    Just check if it runs, actual test is in test_api
    """
    if get_interpreter_completions("", [{}]) == []:
        print('Unit test for function "get_interpreter_completions" ok.')
        print('')
    else:
        print('Unit test for function "get_interpreter_completions" failed.')
        print('')


# Generated at 2022-06-26 07:23:28.318433
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
data = [1, 2, 4]
"""
    # Get completions
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)

    # Check results
    assert isinstance(completions, list)
    assert len(completions) == 1
    assert completions[0].name == "data"

# Generated at 2022-06-26 07:23:37.574656
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Input arguments
    var_0 = "a = []\na.append('')\na.append('')"
    var_1 = [{"type": "module", "children": [{"name": "a", "type": "list"}]}]

    # Additional arguments
    sys_path = ["/home/thonny"]

    # Call the function
    result = get_interpreter_completions(var_0, var_1, sys_path)

    # Print result
    print(result)


if __name__ == "__main__":
    test_case_0()
    test_get_interpreter_completions()

# Generated at 2022-06-26 07:23:38.823556
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("", [], [])) == 0
    return



# Generated at 2022-06-26 07:23:40.599425
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("list_0=[]", 0, 9, "test.py") == test_case_0()

# Generated at 2022-06-26 07:23:50.159907
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_source = "import numpy; numpy.zeros(5)"
    test_namespaces = [{'numpy': 'module'}]

# Generated at 2022-06-26 07:24:02.407558
# Unit test for function get_script_completions
def test_get_script_completions():
    line_0 = 2
    str_0 = 'var_0'
    str_1 = 'test_case_0'
    str_2 = 'return'
    str_3 = 'test'
    def function_0(str_0):
        var_0 = test_case_0
        str_1 = str_0
        if (str_0 == str_1):
            var_1 = get_script_completions(str_1, line_0, line_0, str_2, str_3)
            str_2 = 'func_0'
            str_3 = 'return'
            list_0 = []
            list_1 = [list_0, list_0]
            var_2 = parse_source(list_1)
            return print(var_2)

# Generated at 2022-06-26 07:24:09.755508
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'class A(object):\n    def __init__(self, x):\n        self.x = x'
    namespaces = [{'__builtins__': __builtins__,
                   '__name__' : '__main__','__doc__' : None,
                   '__package__' : None}]
    result = get_interpreter_completions(source,namespaces)
    assert result[0].complete=="x"


# Generated at 2022-06-26 07:24:31.109630
# Unit test for function get_definitions
def test_get_definitions():
    assert len(
        list(
            get_definitions(
                """class A: pass\nclass B: def x(self): pass\nclass C: def y(self): pass\nclass D: def z(self): pass""",
                3, 1, "Foo.py"
            )
        )
    ) == 1


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:24:34.330634
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Name, Keyword
    from parso import parse
    import jedi
    from .backend.jedi_utils import get_definitions

    # Test variable

# Generated at 2022-06-26 07:24:38.423360
# Unit test for function get_script_completions
def test_get_script_completions():

    source = "if True:\n    System.out.println()"
    row = 2
    column = 22
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    print("completions = ", completions)
    assert completions is not None



# Generated at 2022-06-26 07:24:47.277868
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from parso.python import tree
    from parso.python.tree import Operator
    from jedi._compatibility import builtins, unicode
    from jedi import jedi

    list_0 = []
    list_1 = [list_0, list_0]
    var_0 = parse_source(list_1)

    var_1 = Script(var_0, 0, 0, 'test')
    var_2 = get_script_completions(var_0, 0, 0, 'test')
    assert set([isinstance(var_3, ThonnyCompletion) for var_3 in var_2]) == {True}

    # To test the number of completions in the output, 
    # var_2 = get_script_completions(var_0, 0, 0, 'test

# Generated at 2022-06-26 07:24:57.366209
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import types
    import parso.python.tree
    import parso
    import jedi

    assert isinstance(get_interpreter_completions("", [], None), list)

    list_0 = parse_source("list_0")
    list_1 = parse_source("list_1")
    var_0 = [list_0, list_1]
    var_1 = parse_source("var_1")
    var_2 = parse_source("var_2")
    var_3 = parse_source("var_3")
    var_4 = parse_source("var_4")
    var_5 = parse_source("var_5")
    var_6 = parse_source("var_6")
    var_7 = parse_source("var_7")

# Generated at 2022-06-26 07:25:05.904016
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_plugin import jedi_utils

# Generated at 2022-06-26 07:25:08.277844
# Unit test for function get_script_completions
def test_get_script_completions():
    list_0 = []
    list_1 = [list_0, list_0]
    var_0 = get_script_completions(list_1)

# Generated at 2022-06-26 07:25:17.754568
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("""a = 10; print(a)""", 2, 8, "<stdin>")
        definitions = script.goto_definitions()
    
    else:
        script = jedi.Script(code="""a = 10; print(a)""", path="<stdin>")
        definitions = script.infer(line=2, column=8)

    assert definitions
    definition = definitions[0]
    assert definition.line == 1
    assert definition.column == 1
    assert definition.module_path == "<stdin>"
    assert definition.type == "statement"
    assert definition.in_builtin_module()


# Generated at 2022-06-26 07:25:30.008712
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.evaluate import Evaluator
    from jedi.parser import ParserSyntaxError

    script = get_script_completions("__i", 0, 4, "")
    assert(str(type(script[0].parent)) == "<class 'jedi.evaluate.CompiledObject'>" and
        script[0].name == "__import__")

    # TIP: this test covers both test_case_0() and test_case_1()
    # test_case_0() covers the following line
    assert(get_script_completions("list_", 4, 5, "") == None and
        get_script_completions("list_0", 5, 5, "") == None)
    # test_case_1() covers the following line
    # assert(str(type(get_script_completions("

# Generated at 2022-06-26 07:25:40.614780
# Unit test for function get_script_completions
def test_get_script_completions():
    # Given
    source = "import sys\nsys.argv"
    row = 2
    column = 11
    filename = "test.py"
    expected = ["sys.argv", "sys.argv.append", "sys.argv.clear", "sys.argv.copy", "sys.argv.count", "sys.argv.extend", "sys.argv.index", "sys.argv.insert", "sys.argv.pop", "sys.argv.remove", "sys.argv.reverse", "sys.argv.sort"]

    # When
    actual = [c.name for c in get_script_completions(source, row, column, filename)]

    # Then
    assert actual == expected



# Generated at 2022-06-26 07:26:08.269382
# Unit test for function get_script_completions
def test_get_script_completions():
    from os import path
    from thonny import get_workbench
    from thonny.plugins.jedi.jedi_utils import parse_source, get_script_completions
    import parso.python.tree as tree

    jedi_path = path.abspath(path.join(path.dirname(__file__), '..', '..', '..', '..', '..', '..', 'libs', 'jedi.py'))
    jedi_text = "+".join(open(jedi_path, "r").readlines())
    jedi_tree = parse_source(jedi_text)

    # Test for completion of string
    completions = get_script_completions(jedi_text, 1, 0, jedi_path)
    assert completions is not None

# Generated at 2022-06-26 07:26:12.926481
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """import sys
sys.path.append("/usr/lib")

"""
    namespaces = None
    sys_path = None
    var_0 = get_interpreter_completions(source, namespaces, sys_path=None)


# Generated at 2022-06-26 07:26:15.496643
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source_0 = b'"a"\n'
    namespaces_0 = []
    var_0 = get_interpreter_completions(source_0, namespaces_0)
    assert var_0 == []


# Generated at 2022-06-26 07:26:24.566882
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test for internal function _tweak_completions
    thonny_completion_0 = ThonnyCompletion(name="0", complete="1", type="2", description="3", parent="4", full_name="5")
    thonny_completion_1 = ThonnyCompletion(name="6", complete="7", type="8", description="9", parent="10", full_name="11")
    str_0 = thonny_completion_0.full_name
    assert thonny_completion_0.name == "0"
    assert thonny_completion_0.complete == "1"
    assert thonny_completion_0.type == "2"
    assert thonny_completion_0.description == "3"

# Generated at 2022-06-26 07:26:31.967433
# Unit test for function get_definitions
def test_get_definitions():
    source = '''
from math import sin
sin(x)
'''
    filename = ''
    definitions = get_definitions(source, 3, 2, filename)
    assert len(definitions) == 1
    assert definitions[0].name == 'sin'
    assert definitions[0].module_path == 'math'
    assert definitions[0].description == "sin(x, /, out=None, *, where=True, casting='same_kind', order='K', dtype=None, subok=True[, signature, extobj])"
    assert definitions[0].line == 1
    assert definitions[0].column == 8
    assert definitions[0].path == 'math'

# Generated at 2022-06-26 07:26:36.196948
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    try:
        completions = get_interpreter_completions(
            source='text', namespaces=list(list()), sys_path=list(list())
        )
        assert completions is not None
    except Exception:
        assert False


# Generated at 2022-06-26 07:26:37.013668
# Unit test for function get_script_completions
def test_get_script_completions():
    assert True

# Generated at 2022-06-26 07:26:47.878337
# Unit test for function get_script_completions
def test_get_script_completions():
    def test_get_script_completions_0():
        import jedi

        if not _using_older_jedi(jedi):
            return None

        completion_0 = None
        var_0 = _tweak_completions(completion_0)

    def test_get_script_completions_1():
        name_0 = None
        description_0 = None
        complete_0 = None
        thonny_completion_0 = ThonnyCompletion(
            name_0, complete_0, "", description_0, "", ""
        )
        var_0 = set([thonny_completion_0])
        thonny_completion_1 = ThonnyCompletion("", "", "", "", "", "")

# Generated at 2022-06-26 07:26:52.250129
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    # Test to test the name of the completions
    source = "import sys \nsys."
    namespaces = []
    interpreter = Interpreter(source, namespaces)
    completions = interpreter.completions()
    if completions[0].name == "exec_prefix":
        sys.exit(0)
    else:
        sys.exit(1)


# Generated at 2022-06-26 07:26:55.005990
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("source", 0, 5, "filename") is not None



# Generated at 2022-06-26 07:27:15.837591
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:27:22.393769
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    if True:
        stderr_0 = None
        bytes_0 = None
        str_0 = 'get_interpreter_completions'
        thonny_completion_0 = None
        var_0 = get_interpreter_completions(
            stderr_0, bytes_0, str_0, thonny_completion_0,
        )


# Generated at 2022-06-26 07:27:25.335148
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    sys_path = None
    namespaces = None
    source = "import thonny"
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert result.__class__.__name__ == 'list'


# Generated at 2022-06-26 07:27:26.384194
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions('print', [])


# Generated at 2022-06-26 07:27:37.066279
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    source = "def f()\n pass"
    row = 1
    column = 4
    filename = "test.py"
    sys_path=None
    try:
        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
    except Exception as e:
        logger.info("Could not get completions with given sys_path", exc_info=e)
        script = jedi.Script(source, row, column, filename)

    completions = script.completions()
    # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
    # since 0.16 it does. Need to ensure similar result for all supported versions.
    result = []
    for completion in completions:
        name = completion.name

# Generated at 2022-06-26 07:27:40.058798
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 't'
    namespaces = ['t', 't']
    get_interpreter_completions(source, namespaces)


# Generated at 2022-06-26 07:27:41.611540
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:27:45.926211
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from collections import OrderedDict\nOrdered"
    namespaces = []
    thonny_completions = get_interpreter_completions(source, namespaces)
    assert(thonny_completions[0].name == "OrderedDict")


# Generated at 2022-06-26 07:27:53.130901
# Unit test for function get_script_completions
def test_get_script_completions():
    thonny_completion_0 = ThonnyCompletion(
        name="name",
        complete="complete",
        type=None,
        description="description",
        parent=None,
        full_name="full_name",
    )
    list_0 = [thonny_completion_0]
    # AssertionError
    assert get_script_completions(None, 0, 0, None) == "0f2df55681a3b3a3d88362686c9b794d"


# Generated at 2022-06-26 07:27:57.062701
# Unit test for function get_script_completions
def test_get_script_completions():
    script = """
from io import StringIO
s = StringIO("föö")
s."""

    completions = get_script_completions(script, 5, 11, "test.py", sys_path=[])
    assert "__iter__" in [c.name for c in completions]



# Generated at 2022-06-26 07:28:18.621768
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert _tweak_completions([]) == get_interpreter_completions("", [])


# Generated at 2022-06-26 07:28:28.434205
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    class jedi_0:
        def Interpreter(self, str_0, list_0):
            var_0 = self
            var_1 = var_0
            return var_1

    class jedi_1:
        def Interpreter(self, str_1, list_1, ):
            var_2 = self
            var_3 = var_2
            return var_3

    class jedi_2:
        def Interpreter(self, str_2, list_2, sys_path: object = None):
            var_4 = self
            var_5 = var_4
            return var_5

    class jedi_3:
        def Interpreter(self, str_3, list_3, sys_path=None):
            var_6 = self
            var_7 = var_6
            return

# Generated at 2022-06-26 07:28:35.393478
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    # Setting up call
    code = '"""\nPowiększa liczbę\n"""\ndef powieksz(liczba):\n    return liczba + 1\n'
    line = 5
    column = 4
    interpreter = jedi.Interpreter(code, [])
    # Making the call
    result = get_interpreter_completions(code, interpreter, line, column)
    # Asserting the output
    assert len(result) == 3
    assert result[0].name == 'powieksz'
    assert result[1].name == 'CodeIO'
    assert result[2].name == 'codeIO'


# Generated at 2022-06-26 07:28:43.357916
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test 1
    assert get_interpreter_completions('complete(source="123", completions=2)', [], None) is not None

    # Test 2
    assert get_interpreter_completions('complete(source="123", completions=2)', [], None) is not None

    # Test 3
    assert get_interpreter_completions('complete(source="123", completions=2)', [], None) is not None

    # Test 4
    assert get_interpreter_completions('complete(source="123", completions=2)', [], None) is not None

    # Test 5
    assert get_interpreter_completions('complete(source="123", completions=2)', [], None) is not None


# Generated at 2022-06-26 07:28:46.309823
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    int_0 = None
    dict_0 = None
    var_0 = get_interpreter_completions(int_0, dict_0)



# Generated at 2022-06-26 07:28:48.863924
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('import o', 1, 2, '') == _tweak_completions(
        jedi.Script('import o', 1, 2, '').completions()
    )


# Generated at 2022-06-26 07:28:58.628605
# Unit test for function get_script_completions
def test_get_script_completions():
    from .test_utils import get_test_script_path

    filename = get_test_script_path("get_statement_of_position.py")
    with open(filename) as fp:
        source = fp.read()

        row = 35
        column = 7
        bytes_0 = parse_source(source)
        completions = get_script_completions(source, row, column, filename)
        position = get_statement_of_position(bytes_0, (row, column - 2))
        assert completions[0].type == "statement"
        assert position.type == "statement"

        row = 49
        column = 8
        completions = get_script_completions(source, row, column, filename)
        position = get_statement_of_position(bytes_0, (row, column - 2))

# Generated at 2022-06-26 07:28:59.703820
# Unit test for function get_definitions
def test_get_definitions():
    class_0 = get_definitions("mjnfdfgidlcbmbk", 1, 1, "fjmrvl")


# Generated at 2022-06-26 07:29:06.390612
# Unit test for function get_script_completions
def test_get_script_completions():
    source1 = "class vehicle():\n    pass\n\nclass car(vehicle):\n    def __i"
    row1 = 4
    column1 = 29
    filename1 = "test_module17.py"
    sys_path1 = ["/Users/james/Documents/GitHub/thonny-ide/thonny/backend/thonny/plugins/autocomplete/tests/test_module17.py"]
    sys_path2 = None

# Generated at 2022-06-26 07:29:09.599335
# Unit test for function get_script_completions
def test_get_script_completions():
    bytes_0 = None
    var_0 = get_script_completions(bytes_0, 0, 0, "")
    bytes_1 = None
    var_1 = get_script_completions(bytes_1, 0, 0, "", [])


# Generated at 2022-06-26 07:29:40.587145
# Unit test for function get_definitions
def test_get_definitions():
    var_0 = """class Example:
    def __init__(self):
        self.data_attribute = 1

    def test_method(self):
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()
        self.test_method()

example = Example()
example.test_method()
"""
    from parso.python.tree import Module
    from parso.python.node import Statement
    from parso.python.tree import Class
    from parso.python.tree import Function
    from parso.python.tree import ExprStmt

    var_1 = get_definitions

# Generated at 2022-06-26 07:29:45.696751
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = 'import command'
    completions = get_interpreter_completions(source, [], sys_path=[])
    assert len(completions) == 43
    assert completions[0].name == 'command'
    assert completions[0].complete == 'command'


"""
Tests for function _get_new_jedi_project
"""



# Generated at 2022-06-26 07:29:51.063097
# Unit test for function get_definitions
def test_get_definitions():
    local_var_0 = "def frobnicate() -> str: pass\nfrobnicate"
    local_var_1 = 1
    local_var_2 = 16
    local_var_3 = ""
    local_var_4 = get_definitions(local_var_0, local_var_1, local_var_2, local_var_3)
    assert local_var_4[0].line_nr == local_var_1
    assert local_var_4[0].description == "frobnicate() -> str"
    assert local_var_4[0].module_path == local_var_3
    assert local_var_4[0].column == local_var_2
    assert local_var_4[0].type == "function"
    assert local_var_4[0].in_builtin

# Generated at 2022-06-26 07:30:01.172317
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_2 = b'from math import '
    var_3 = []
    try:
        get_interpreter_completions(var_2, var_3)
    except TypeError as var_4:
        var_5 = '\nIn {} line {}:\n{}'
        if sys.version_info < (3,):
            var_5 = var_5.format(
                os.path.basename(__file__), sys.exc_info()[2].tb_lineno, '{0}'.format(var_4)
            )
        else:
            var_5 = var_5.format(
                os.path.basename(__file__), sys.exc_info()[2].tb_lineno, '{}'.format(var_4)
            )

# Generated at 2022-06-26 07:30:08.576989
# Unit test for function get_definitions
def test_get_definitions():
    #
    # case 1
    #
    import jedi
    script = jedi.Script("import os")

# Generated at 2022-06-26 07:30:12.982134
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("import sys\nsys.stdo\n", 1, 10, "test")[0].type=='module'
    assert get_definitions("def f(a,b):\n    pass\n\nf(1,b=1)\n", 4, 5, "test")[0].type=='instance'
    assert get_definitions("def f():\n    a=1\na=2\na\n", 3, 1, "test")[0].type=='statement'
    assert get_definitions("def f():\n    a=1\na=2\na\n", 5, 1, "test")[0].type=='instance'

# Generated at 2022-06-26 07:30:15.401864
# Unit test for function get_script_completions
def test_get_script_completions():
   import jedi
   script = jedi.Script('print', 0, 5, '')
   completion = script.get_completions()
   assert(len(completion) == 2)

# Generated at 2022-06-26 07:30:24.762499
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = "from datetime import dat"
    var_1 = "from datetime import dat"
    var_2 = get_interpreter_completions(var_0, var_0)
    var_3 = "from datetime import date"
    var_4 = get_interpreter_completions(var_3, var_3)
    var_5 = "from datetime import *"
    var_6 = get_interpreter_completions(var_5, var_5)
    var_7 = "import datetime"
    var_8 = get_interpreter_completions(var_7, var_7)
    var_9 = "import datetime"
    var_10 = get_interpreter_completions(var_9, var_9)



# Generated at 2022-06-26 07:30:32.573607
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("from", 0, 5, "test_file.py") == []
    assert get_script_completions("from sys imp", 0, 12, "test_file.py") == ['import', 'importlib', 'imp']
    assert get_script_completions("from sys import ", 0, 15, "test_file.py") == ['__name__']
    assert get_script_completions("from sys import i", 0, 15, "test_file.py") == ['imp']
    assert get_script_completions("from sys import im", 0, 16, "test_file.py") == ['import', 'importlib']
    assert get_script_completions("import sys; sys.", 0, 14, "test_file.py") == ['__name__']
    assert get_script

# Generated at 2022-06-26 07:30:36.939366
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_1 = None
    var_2 = get_interpreter_completions(var_1, var_1)
    var_3 = None
    var_4 = get_interpreter_completions(var_1, var_1, var_3)


# Generated at 2022-06-26 07:31:25.936987
# Unit test for function get_definitions
def test_get_definitions():
    import parso

    """
        Test case for get_definitions function
        Returns:
         Number of lines when any error appears.
    """
    print('Starting unit test for function get_definitions')
    with open('tests/utils/test_get_definitions.py') as f:
        code = f.read()
        root_node = parse_source(code)
        error_counter = 0
        add_counter = 1
        line_counter = 1
        for statement in root_node.iter_funcdefs():
            line_counter += 1
            if statement.name.value == 'test_get_definitions':
                continue

# Generated at 2022-06-26 07:31:36.158254
# Unit test for function get_script_completions
def test_get_script_completions():
    import pytest


# Generated at 2022-06-26 07:31:41.188385
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__

    if __version__[:4] not in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        return

    script_completions_1 = get_script_completions(
        """class MyClass():
  def func():
    self.name""",
        4,
        11,
        "",
    )

    assert script_completions_1[0].name == "name"



# Generated at 2022-06-26 07:31:48.369334
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Should return completion options for this line
    input_0 = "import os; os.path"
    expected_0 = [
        ThonnyCompletion(
            name="abspath",
            complete="abspath()",
            type="function",
            description="absoluutpõhi",
            parent="os.path",
            full_name="posixpath.abspath",
        ),
        ThonnyCompletion(
            name="exists",
            complete="exists()",
            type="function",
            description="kontrolli teatud asukohas olevat faili",
            parent="os.path",
            full_name="exists",
        ),
    ]
    if _using_older_jedi(__import__("jedi")):
        expected_0.extend

# Generated at 2022-06-26 07:31:50.463718
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("for i in range(10):", 1, 17, "<input>")) == 2


# Generated at 2022-06-26 07:32:00.977784
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("", []) == []
    assert get_interpreter_completions("import datetime", [])
    assert get_interpreter_completions("def a(param", [])
    assert get_interpreter_completions("def a(): return", [])
    assert get_interpreter_completions("def a(): return 1", [])
    assert get_interpreter_completions("def a(): return 1 + ", [])
    assert get_interpreter_completions("def a(): return r'\n'", [])
    assert get_interpreter_completions("from datetime import datetime; datetime.", [])
    assert get_interpreter_completions("from datetime import datetime; datetime.date", [])

# Generated at 2022-06-26 07:32:03.798587
# Unit test for function get_script_completions
def test_get_script_completions():
    var_0 = ""
    var_1 = 0
    var_2 = 0
    var_3 = ""
    var_4 = None
    var_5 = get_script_completions(var_0, var_1, var_2, var_3, var_4)



# Generated at 2022-06-26 07:32:05.175539
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:32:13.609414
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def test_0():
        # expected:
        #     [(<ThonnyCompletion name=[str, repr, a] complete=[str, repr, a] type=[<class 'type'>] description=[None] parent=[<class 'object'>] full_name=[str]>]
        # actual:
        #     [<ThonnyCompletion name=[str, repr, a] complete=[str, repr, a] type=[<class 'type'>] description=[None] parent=[<class 'object'>] full_name=[str]>]
        var_0 = None
        var_1 = str
        var_2 = get_interpreter_completions(var_1, var_0)
        var_3 = None
        var_4 = ThonnyCompletion

# Generated at 2022-06-26 07:32:24.335822
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree
    from parso.python.tree import Leaf

    source = "def foo():\n    print('bar')\nfoo()"


    if hasattr(tree, "Function"):
        leaf = Leaf(0, "foo", start_pos=(3, 5), prefix="")
    else:
        leaf = Leaf(0, "foo", start_pos=(3, 5), prefix="", parent=None)

    print(get_definitions(source, 3, 5, filename="test.py"))
    assert get_definitions(source, 3, 5, filename="test.py")[0].description == "def foo():"
