

# Generated at 2022-06-26 07:23:40.708652
# Unit test for function get_script_completions
def test_get_script_completions():
    filename = "script.py"
    row = 3
    column = 4
    source = "print('hello\nworld)'"
    sys_path = []

    result = get_script_completions(source, row, column, filename, sys_path)
    return True



# Generated at 2022-06-26 07:23:50.160492
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    bool_0 = bool()
    bool_1 = bool()

    bool_0 = bool_0 / bool_1

    bool_2 = bool()
    bool_1 = bool()
    bool_2 = bool_2 + bool_1

    bool_1 = bool()
    bool_2 = bool()
    bool_1 = bool_1 - bool_2

    try:
        bool_1 = bool_2 > bool_2
    except:
        pass

    bool_2 = bool()
    bool_0 = bool()
    bool_2 = bool_2 * bool_0

    bool_0 = bool()
    bool_2 = bool()
    bool_0 = bool_0 - bool_2

    bool_2 = bool()
    bool_0 = bool()
    bool_2 = bool_2 - bool_0

   

# Generated at 2022-06-26 07:23:55.667737
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    code = """\
import os
os"""

    completions = get_interpreter_completions(
        code, namespaces=[{"os": os}],
    )
    assert len(completions) >= 10  # at least path, sep, linesep, exit etc.
    assert "path" in [c.name for c in completions]



# Generated at 2022-06-26 07:23:59.565996
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import'
    namespaces = ['import']
    sys_path = ['import']
    assert type(get_interpreter_completions(source, namespaces, sys_path)) is list


# Generated at 2022-06-26 07:24:07.490723
# Unit test for function get_script_completions
def test_get_script_completions():
    filename = "C:\\Users\\zubair\\Desktop\\Thonny\\data\\tst\\jedi\\test_get_script_completions.py"
    source = "# Unit test for function get_script_completions\ndef test_get_script_completions():\n    filename = \"C:\\\\Users\\\\zubair\\\\Desktop\\\\Thonny\\\\data\\\\tst\\\\jedi\\\\test_get_script_completions.py\"\n    source = \"\"\n    row = 3\n    column = 15\n    sys_path = ['C:\\\\Users\\\\zubair\\\\Desktop\\\\Thonny\\\\data\\\\tst\\\\jedi']\n    result = get_script_completions(source, row, column, filename, sys_path)\n    print(result)\n"
    row = 3
   

# Generated at 2022-06-26 07:24:11.595592
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # 1. Check exception when code is not a string
    # 2. Check exception when namespaces is not a list of dictionaries
    # 3. Check exception when sys_path is not a list
    # 4. Check completions for valid parameters
    pass


# Generated at 2022-06-26 07:24:17.145384
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'foo'
    namespaces = [{}]
    sys_path = ['/usr/lib/python3.6/site-packages']
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert result is not None


# Generated at 2022-06-26 07:24:27.182277
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:24:28.234525
# Unit test for function get_definitions
def test_get_definitions():
    assert True


# Generated at 2022-06-26 07:24:33.540670
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import numpy
    from unittest import mock

    interpreter = mock.MagicMock()
    interpreter.backend.get_completions.side_effect = [["attr1", "attr2"], ["attr3"]]
    interpreter.backend.eval.return_value = numpy
    assert get_interpreter_completions(interpreter, "numpy.arcta") == ["attr1", "attr2", "attr3"]


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:24:46.708711
# Unit test for function get_script_completions
def test_get_script_completions():
    source = ""
    row = 1
    column = 1
    filename = "test.py"
    # sys_path = [""]
    # completions = get_script_completions(source, row, column, filename, sys_path)
    completions = get_script_completions(source, row, column, filename)
    return completions


# Generated at 2022-06-26 07:24:48.408913
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.Script(code="", path="")



# Generated at 2022-06-26 07:24:58.396643
# Unit test for function get_definitions

# Generated at 2022-06-26 07:25:02.479429
# Unit test for function get_definitions
def test_get_definitions():
    script = "x = 3\nprint(x+y)"
    result = get_definitions(script, 1, 1, "")
    assert isinstance(result, list) and len(result) == 1
    assert result[0].name == "x"
    assert result[0].line == 1
    assert result[0].column == 1



# Generated at 2022-06-26 07:25:05.994246
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso

    try:
        get_interpreter_completions(' while s:', [{'locals': {}, 'globals': {'s': 1}}, {'locals': {'s': 2}, 'globals': {}}], ('',))
    except TypeError:
        pass



# Generated at 2022-06-26 07:25:16.377454
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from parso.python import tree

    example1 = "a=5; a."
    example2 = "import datetime; datetime."
    example3 = "from datetime import *; datetime."

    completions = get_script_completions(example1, 1, 5, "get_script_completions_example1.py")

# Generated at 2022-06-26 07:25:28.964588
# Unit test for function get_definitions
def test_get_definitions():
    source = "import math\nmath.d"
    row = 2
    column = 13
    filename = None
    definitions = get_definitions(source, row, column, filename)

    # Check that the result has the correct length
    if len(definitions) != 1:
        raise RuntimeError("The number of definitions is incorrect, expected 1 but got ", len(definitions))

    # Check that the result is of the correct type
    definitions_type = type(definitions[0])
    if definitions_type.__module__ == 'builtins':
        raise RuntimeError("The definitions type is incorrect, expected 'jedi.api.classes.Definition', got ", definitions_type)

# Generated at 2022-06-26 07:25:36.032774
# Unit test for function get_script_completions
def test_get_script_completions():
    str_0 = 'C8(0\x0cZo-\x0c\x0c'
    str_1 = '\x0ce\x0ct\x0c'
    var_0 = get_script_completions(str_0, 100, 96, str_1)
    str_2 = ''
    str_3 = 'S\x0c\x0c\x0cq\x0cX'
    var_1 = get_script_completions(str_2, 100, 87, str_3)
    str_4 = ''
    str_5 = '\x0c1\x0c\x0c\x0c'
    var_2 = get_script_completions(str_4, 100, 30, str_5)

# Generated at 2022-06-26 07:25:40.218694
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("no_such_module_in_the_universe", [], [])
    assert len(completions) == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:25:46.220604
# Unit test for function get_definitions

# Generated at 2022-06-26 07:26:06.744525
# Unit test for function get_script_completions
def test_get_script_completions():
    # NB! In later Jedi versions there is a bug and they don't return any completions
    # https://github.com/davidhalter/jedi/issues/1868
    if "0.16.0" <= jedi.__version__ <= "0.17.0":
        # This test seems to be broken since 0.17
        return

    source = """var = 1
var_"""
    completions = get_script_completions(source, 1, 6, "test.py")

    assert len(completions) == 1
    assert completions[0].name == "var"
    assert completions[0].description == "int"
    assert completions[0].complete == ""
    assert completions[0].type == "statement"


# Generated at 2022-06-26 07:26:13.313790
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    value = get_interpreter_completions("print(1)", [], sys_path=None)
    # Check type of return value from function
    assert isinstance(value, list)
    # Check length of return value from function
    assert len(value) == 1
    # Check value of return value from function
    assert value[0].complete == "print("
    assert value[0].name == "print("
    assert value[0].type == 'statement'
    assert value[0].description == "print(value, ..., sep=' ', end='\\n', file=sys.stdout)"
    assert value[0].parent == "builtins"
    assert value[0].full_name == "print"


# Generated at 2022-06-26 07:26:22.541520
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str_0 = 'x\x0ccmf\x0c(.IK\x0cd\x07^C\x0b`\x0cU\x0c\x0b\x0b'
    var_0 = get_interpreter_completions(str_0, None)
    assert len(var_0) == 5

    str_0 = '\x07\x86\x1b\x1e\x93\x8b\x19\x9c\x88\x1e\x9a'
    var_1 = get_interpreter_completions(str_0, None)
    assert len(var_1) == 5


# Generated at 2022-06-26 07:26:28.349939
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    source_0 = 'def foo ():\n    return foobar\n\na = foo ()\n'
    row_0 = 4
    column_0 = 7
    filename_0 = 'f.py'
    var_0 = get_script_completions(source_0, row_0, column_0, filename_0)
    assert var_0 == Script(code=source_0, path=filename_0).complete(line=row_0, column=column_0)


# Generated at 2022-06-26 07:26:31.754216
# Unit test for function get_definitions
def test_get_definitions():
    def test_case_0():
        bool_0 = True
        str_0 = "w$dW7@m\x0cLIm\x0c9zSoG"
        var_0 = get_definitions(bool_0, str_0, str_0, str_0)



# Generated at 2022-06-26 07:26:37.510260
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "// Comment line 1"
    row = 0
    column = 1
    filename = ""
    sys_path = [
        "/home/praneeth/Documents/Code/thonny-backend/venv/lib/python3.8/site-packages/jedi"
    ]
    get_script_completions(source, row, column, filename, sys_path)


# Generated at 2022-06-26 07:26:41.953037
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = '4'
    namespaces = [{}]
    sys_path = None
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert result == _tweak_completions([])


# Generated at 2022-06-26 07:26:43.396071
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    pass


# Generated at 2022-06-26 07:26:49.677405
# Unit test for function get_script_completions
def test_get_script_completions():
    # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
    # since 0.16 it does. Need to ensure similar result for all supported versions.
    import jedi

    if _using_older_jedi(jedi):
        assert False
    else:
        assert '=' in _tweak_completions(jedi.Script('print(set')[0].name)
        assert '=' in _tweak_completions(jedi.Script('import sys; sys.')[0].name)



# Generated at 2022-06-26 07:26:53.508013
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = 'if True:\n    #|\n'
    row = 2
    column = 4
    sys_path = None

    interpreter = jedi.Interpreter(source, [], sys_path=sys_path)
    completions = interpreter.complete()

    assert(get_interpreter_completions(source, [], sys_path=sys_path) == completions)


# Generated at 2022-06-26 07:27:11.404157
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # using positional argument for function call
    assert get_interpreter_completions('d', [{}]) == []
    # using keyword argument for function call
    assert get_interpreter_completions(namespaces=[{}], source='d') == []
    # using partial positional argument for function call
    assert get_interpreter_completions('d', [{}]) == []

# Generated at 2022-06-26 07:27:14.736982
# Unit test for function get_definitions
def test_get_definitions():
    source = 'import datetime\ndatetime.m$mana'
    filename = 'random.py'
    row = 2
    column = 13
    result = get_definitions(source=source, row=row, column=column, filename=filename)

    assert len(result) == 1
    d = result[0]

    # Definition is datetime.tzinfo
    assert d.full_name == 'datetime.tzinfo'



# Generated at 2022-06-26 07:27:21.130975
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    bool_0 = True
    list_0 = []
    str_0 = 'w$dW7@m\x0cLIm\x0c9zSoG'
    result = get_interpreter_completions(bool_0, list_0, str_0)
    if result != bool_0:
        raise RuntimeError('test failed')


# Generated at 2022-06-26 07:27:33.494617
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test 1
    source = "def foo():\n    pass\n\nfoo(\n\nf"
    row = 4
    column = 1
    filename = "test_file_0.py"
    jedi_completions = get_script_completions(source, row, column, filename)
    assert len(jedi_completions) == 1
    assert jedi_completions[0].complete == "foo"

    # Test 2
    source = "import sys\nsys."
    row = 2
    column = 6
    filename = "test_file_1.py"
    jedi_completions = get_script_completions(
        source, row, column, filename, sys_path=["/home/tkh/dev/thonny"]
    )

# Generated at 2022-06-26 07:27:37.988275
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.languageservice import jedi_utils
    assert jedi_utils.get_interpreter_completions("'".split("\n"),[])



# Generated at 2022-06-26 07:27:43.753776
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from termcolor import colored

    logging.getLogger("thonny.jediutils").setLevel(logging.DEBUG)
    logging.getLogger("jedi.api.classes").setLevel(logging.DEBUG)
    logging.getLogger("jedi.api.script").setLevel(logging.DEBUG)
    logging.getLogger("jedi.evaluate").setLevel(logging.DEBUG)
    logging.getLogger("parso.parser").setLevel(logging.DEBUG)
    logging.getLogger("parso.python").setLevel(logging.DEBUG)
    source = "import pandas as pd; pd.\n"
    source_line_index = 1
    source_column_index = 7
    # str_0 = '\x17\x1c^\x04Bm\x1

# Generated at 2022-06-26 07:27:47.484028
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = "import threading"
    namespaces = []
    sys_path = None
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert len(result) == 1
    assert result[0].name == "threading"



# Generated at 2022-06-26 07:27:59.161457
# Unit test for function get_definitions
def test_get_definitions():
    dict_0 = {}
    dict_1 = {}
    dict_0 = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3', 'key_4': 'value_4', 'key_5': 'value_5', 'key_6': 'value_6', 'key_7': 'value_7', 'key_8': 'value_8', 'key_9': 'value_9', 'key_10': 'value_10'}

# Generated at 2022-06-26 07:28:07.921722
# Unit test for function get_definitions
def test_get_definitions():
    filename = './test_data/test1.py'

    with open(filename) as f:
        source = f.read()

    # Test 1.1
    ret = get_definitions(source, 1, 6, filename)
    assert len(ret) == 1
    assert ret[0].description == "class Test1"
    assert ret[0].full_name == "Test1"
    assert ret[0].line == 1
    assert ret[0].column == 6

    # Test 1.2
    ret = get_definitions(source, 10, 4, filename)
    assert len(ret) == 1
    assert ret[0].description == "def run"
    assert ret[0].full_name == "Test1.run"
    assert ret[0].line == 10
    assert ret[0].column == 4

   

# Generated at 2022-06-26 07:28:14.859135
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\nos"
    namespaces = [None]
    namespaces[0] = {
        'sys': {
            '__name__': 'sys',
        },
        'os': {
            '__name__': 'os',
        },
    }
    namespaces[0]['sys']['modules'] = {
        'os': namespaces[0]['os'],
        'sys': namespaces[0]['sys'],
    }
    result = get_interpreter_completions(source, namespaces)
    if len(result) == 0:
        raise Exception("Expected not empty")
    return


if __name__ == '__main__':
    test_case_0()
    test_get_interpreter_completions()
    print("OK")

# Generated at 2022-06-26 07:28:51.285440
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Test case get_interpreter_completions")
    code = """
    import os
    os.path.isdir(
    """

# Generated at 2022-06-26 07:28:55.816272
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import os\nos.path'  # The code you're doing autocompletion on.
    namespaces = [{'__builtins__': None, }]  # A list of dictionaries, one for each namespace.
    print(get_interpreter_completions(source, namespaces))  # Get the completions.



# Generated at 2022-06-26 07:29:00.906354
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Testing get_interpreter_completions ...")
    bool_0 = bool
    str_0 = 'zzz'
    list_0 = [True, 'string', 1, 1.0]
    list_1 = ['string', 1, 1.0, None]
    dict_0 = dict(zip(list_0, list_1))
    get_interpreter_completions(bool_0, str_0, dict_0)
    

# Generated at 2022-06-26 07:29:05.371292
# Unit test for function get_script_completions
def test_get_script_completions():
    test_script_completions_0()
    test_script_completions_1()
    test_script_completions_2()
    test_script_completions_3()
    test_script_completions_4()
    test_script_completions_5()
    test_script_completions_6()
    test_script_completions_7()
    test_script_completions_8()
    test_script_completions_9()


# Generated at 2022-06-26 07:29:14.082108
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python import tree

    import parso

    # Test with script_1.py
    source = """def cross_off(matrix, row, col):
    num_rows = len(matrix)
    num_cols = len(matrix[0])
    
    for r in range(num_rows):
        matrix[r][col] = 0
        
    for c in range(num_cols):
        matrix[row][c] = 0
        
    return matrix

matrix = [[0, 1, 0],
          [1, 1, 1],
          [1, 0, 1]]

cross_off(matrix, 0, 0)
print(matrix)"""
    source = source.split("\n")

    script = parso.parse(source)

# Generated at 2022-06-26 07:29:15.809699
# Unit test for function get_definitions
def test_get_definitions():
    # TODO: create a small test file with big enough tree
    pass

# Generated at 2022-06-26 07:29:19.310772
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_str = "import"
    test_namespace = [{}, {}, {}, {}, {}, {}]
    test_sys_path = None
    result = get_interpreter_completions(test_str, test_namespace, test_sys_path)
    assert len(result) == 0



# Generated at 2022-06-26 07:29:20.526296
# Unit test for function get_script_completions

# Generated at 2022-06-26 07:29:28.552582
# Unit test for function get_script_completions
def test_get_script_completions():
    filename = "test_script"
    source = "import os\nos.path.join("
    row = 0
    column = 20

    script = jedi.Script(source=source, row=row, column=column, filename=filename)
    completions = script.completions()

    assert completions[0].name == "os.path.join"
    assert completions[0].type == "function"

    source = "import os\nos.path"
    row = 0
    column = 14

    script = jedi.Script(source=source, row=row, column=column, filename=filename)
    completions = script.completions()

    assert completions[1].name == "os.path.join"
    assert completions[1].type == "function"


# Generated at 2022-06-26 07:29:31.056111
# Unit test for function get_script_completions
def test_get_script_completions():
    a = [1, 2]
    b = 'hello'
    res = get_script_completions(b, 1, 6, "")
    assert res is not None
    assert len(res) == 2


# Generated at 2022-06-26 07:30:32.835109
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import datetime\ndatetime.datet"
    namespaces = [{'datetime': datetime}]
    sys_path = []
    result = get_interpreter_completions(source, namespaces, sys_path)
    assert(result[0].name == "datetime")
    assert(result[0].complete == "datetime")
    assert(result[0].type == "module")
    assert(result[0].parent == None)
    assert(result[0].full_name == "datetime")
    assert(result[0].description == "Fast implementation of the datetime type.")
    assert(result[1].name == "datetime_CAPI")
    assert(result[1].complete == "datetime_CAPI")

# Generated at 2022-06-26 07:30:42.592291
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    line = 'str_0 = "w$dW7@mLImczSoG"'
    var_0 = get_interpreter_completions(line, [])

    # format of var_0
    # var_0 = [
    #   'endswith',
    #   'endswith',
    #   'expandtabs',
    #   'expandtabs',
    #   'find',
    #   'find',
    #   'format',
    #   'format',
    #   'index',
    #   'index',
    #   'islower',
    #   'isspace',
    #   'isupper',
    #   'join',
    #   'join',
    #   'lower',
    #   'lower',


# Generated at 2022-06-26 07:30:44.616494
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Throws TypeError!
    # get_interpreter_completions(str_0, var_0)
    return


# Generated at 2022-06-26 07:30:52.494730
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'import os\nos.pat'
    row = 1
    column = 12
    filename = ''
    sys_path=None


# Generated at 2022-06-26 07:30:58.019365
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import datetime\ndatetime.datetime.now().year"
    row = 2
    column = 27
    filename = "/path/to/file.py"
    completions = get_script_completions(source, row, column, filename)
    assert completions
    assert "year" in [c["name"] for c in completions]
    assert "weekday" in [c["name"] for c in completions]
    assert "utcnow" in [c["name"] for c in completions]


# Generated at 2022-06-26 07:31:03.960535
# Unit test for function get_script_completions
def test_get_script_completions():
    with open(os.path.join(TEST_DIRECTORY, 'test_jedi_helper_get_script_completions.py'), 'r') as expected_output_file:
        expected_output = expected_output_file.read()
    with open(os.path.join(TEST_DIRECTORY, 'test_jedi_helper_get_script_completions_input.py'), 'r') as input_file:
        actual_output = get_script_completions(input_file.read(), 5, 2, 'test_jedi_helper_get_script_completions_input.py')
    assert str(actual_output) == expected_output


# Generated at 2022-06-26 07:31:12.699558
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\nsys.s"
    row = 1
    column = 9
    filename = "example.py"
    result = get_script_completions(
        source, row, column, filename
    )  # Call tested function

# Generated at 2022-06-26 07:31:20.072081
# Unit test for function get_script_completions
def test_get_script_completions():
    # Print statements are added to check issue #149
    print("_using_older_jedi in test " + str(_using_older_jedi))
    # Variable declaration
    source = ''
    # Variable initialization
    row = 0
    # Variable initialization
    column = 0
    # Variable initialization
    filename = 'JediUtils.py'
    # Print statements are added to check issue #149
    print("sys_path in test " + str(sys_path))
    # Variable initialization
    test_0 = get_script_completions(source, row, column, filename, sys_path)


# Generated at 2022-06-26 07:31:22.275093
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions('', [], None)
    assert completions == _tweak_completions([])

# Generated at 2022-06-26 07:31:27.560724
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print('testing function get_interpreter_completions')
    source = 'a = "Hello"'
    namespaces = [{}]
    sys_path = ['C:\\Users\\Uday\\OneDrive\\Documents\\Thonny\\thonny\\lib\\thonny\\plugins\\syntaxchecker.py']
    expected_result = 'syntaxchecker'
    result = get_interpreter_completions(source, namespaces, sys_path)[0]
    #print(result)
    if(result.name == expected_result):
        print('Completions are okay')
    else:
        print('Completions are not okay')


# Generated at 2022-06-26 07:32:42.162784
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """x=i
    y=in
    z=in
    """
    assert get_script_completions(source, 0, 2, "") == [
        ThonnyCompletion(name="int", complete="int", type="int", description="", parent="", full_name="int")
    ]
    assert get_script_completions(source, 1, 4, "") == [
        ThonnyCompletion(name="int", complete="int", type="int", description="", parent="", full_name="int")
    ]
    assert get_script_completions(source, 2, 4, "") == [
        ThonnyCompletion(name="int", complete="int", type="int", description="", parent="", full_name="int")
    ]



# Generated at 2022-06-26 07:32:47.689871
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    source_0 = 'co\n'
    row_1 = 1
    column_2 = 0
    filename_3 = 'C:/Users/admin/Desktop/jedi-test/test/test-simple.py'
    print(test_get_script_completions(source_0, row_1, column_2, filename_3))


# Generated at 2022-06-26 07:32:58.389657
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # TODO: replace with a better test case
    def foo(x):
        a = 10
        return x * a

    namespaces = [
        {
            "__name__": "__main__",
            "a": 10,
            "foo": foo,
            "Foobar": int,
            "sys": {
                "path": [],
                "argv": [],
                "exit": lambda x: None,
                "exc_info": lambda: (None, None, None),
            },
        }
    ]
    get_interpreter_completions(
        "Foobar(a).real",
        namespaces,
        None
    )


# Generated at 2022-06-26 07:32:58.926391
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert True

# Generated at 2022-06-26 07:33:03.980407
# Unit test for function get_script_completions
def test_get_script_completions():
    test_code = 'class P:\n  def foo():\n    pass\n  def __init__():\n    pass\n\n'
    source = 'P.'
    row = 0
    column = 4
    filename = 'test_jedi.py'

    completions = get_script_completions(source, row, column, filename)

    assert len(completions) == 2
    for name in [c.name for c in completions]:
        assert name in ['__init__()', 'foo()']


# Generated at 2022-06-26 07:33:04.700436
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert callable(get_interpreter_completions)



# Generated at 2022-06-26 07:33:09.108830
# Unit test for function get_definitions
def test_get_definitions():
    completions = (get_definitions('abc = ', 0, 8, 'tmp.py'))
    if [completions[0].name, completions[0].type, completions[0].description, completions[0].parent, completions[0].full_name] != ['abc', 'statement', '', None, 'abc']:
        print('Failed in test_get_definitions')
    elif [completions[1].name, completions[1].type, completions[1].description, completions[1].parent, completions[1].full_name] != ['abc.append', 'function', 'abc.append(object) -> None -- append object to end', 'abc', 'abc.append']:
        print('Failed in test_get_definitions')

# Generated at 2022-06-26 07:33:14.773568
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Change the following values to test
    source = 'shutil.copynfile(src, dst, *, follow_symlinks=True)'
    row = 0
    column = 18
    filename = ''
    sys_path = []
    namespaces = []

    result = get_interpreter_completions(source, row, column, filename, sys_path, namespaces)
    return result



# Generated at 2022-06-26 07:33:21.490815
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    This should be of type 'array'
    """

# Generated at 2022-06-26 07:33:22.340367
# Unit test for function get_script_completions
def test_get_script_completions():
    # This test makes no sense, just so pytest doesn't complain
    assert True