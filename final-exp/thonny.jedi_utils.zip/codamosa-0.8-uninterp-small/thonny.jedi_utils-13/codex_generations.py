

# Generated at 2022-06-26 07:23:32.558490
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    for _ in range(5):
        var_0 = test_get_interpreter_completions_0()


# Generated at 2022-06-26 07:23:42.277050
# Unit test for function get_definitions
def test_get_definitions():
    test_get_definitions.counter = 0
    def test_get_definitions_0():
        class_0 = Foo()
        script_0 = get_script_completions(class_0, 3.2, 0, '/home/ben/Dropbox/jedi-project/jedi/tests/uses/absimport.py')
        var_0 = get_definitions(script_0, 0.5, class_0)

    def test_get_definitions_1():
        str_0 = 'Nw6hxN6T3T'
        script_0 = get_script_completions(str_0, 6.878, 7, '/home/ben/Dropbox/jedi-project/jedi/tests/uses/absimport.py')

# Generated at 2022-06-26 07:23:43.849755
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions(0, 0)
    assert not result

# Generated at 2022-06-26 07:23:50.454691
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test case 1
    source = '    class Foo(ob'
    row = 1
    column = 23
    filename = None
    assert get_script_completions(source, row, column, filename) == ([{'complete': 'Object', 'description': 'class Object(builtins.object)', 'name': 'Object', 'type': 'class'}], None)
    assert get_script_completions(source, row, column, filename) == ([{'complete': 'object', 'description': 'class object', 'name': 'object', 'type': 'class'}], None)

# Generated at 2022-06-26 07:23:57.665486
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "\"\"\"This is a test file.\"\"\"\nvar_0 = \\\"Hello\nvar_1 = 1\n"
    list_0 = [{}]
    list_1 = get_interpreter_completions(source, list_0)
    assert (len(list_1) == 4)
    assert (list_1[0].name == "var_0")
    assert (list_1[1].name == "var_1")



# Generated at 2022-06-26 07:24:04.085816
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    from thonny.plugins.thonny_jedi import get_interpreter_completions

    try:
        assert get_interpreter_completions(
            "import sys", [{"sys": sys}], ["./tests/test_thonny_jedi/fixtures/resources"]
        )
    except:
        assert False
    return True



# Generated at 2022-06-26 07:24:11.115122
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import "
    row = 0
    column = 7
    filename = ""
    # Completions for a source string
    _completions = get_script_completions(source, row, column, filename)

    assert _completions is not None
    assert len(_completions) > 0
    for completion in _completions:
        assert completion.name is not None
        assert completion.complete.startswith("import ")
        assert completion.type in ["module", "keyword"]
        assert len(completion.description) > 0



# Generated at 2022-06-26 07:24:13.343703
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-26 07:24:22.169864
# Unit test for function get_definitions
def test_get_definitions():
    source = 'from collections import namedtuple\nPerson = namedtuple("Person", "name age")\n'
    source_1 = 'from collections import namedtuple\nPerson = namedtuple("Person", "name age")\nPerson\n'
    row = 1
    column = 11
    filename = "D:\GITHUB\HITB-XCTF-GM-2018\jedi-api-master\jedi-api-master\jediapi\jedi_api\test.py"
    result = get_definitions(source,row,column,filename)
    assert len(result) != 0
    assert result[0].full_name == "namedtuple"

# Generated at 2022-06-26 07:24:25.739563
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import math\nten = math.log10(100)"
    row = 1
    column = 8
    filename = None
    sys_path = None
    completions = get_script_completions(source, row, column, filename, sys_path)
    assert completions[0].name == 'log10'



# Generated at 2022-06-26 07:24:48.364930
# Unit test for function get_script_completions
def test_get_script_completions():
    script_code = """
import os
import sys
"""
    source = script_code
    cursor_start = script_code.index("import os")
    cursor_end = script_code.index("import sys")

    completions = get_script_completions(source, cursor_start, cursor_end, 'test.py')

    assert completions == "test.py"

# Generated at 2022-06-26 07:24:58.354078
# Unit test for function get_script_completions
def test_get_script_completions():
    import textwrap

    code = textwrap.dedent(
        '''
        import numpy as np
        foo = {"a": "xyz", "b": "abc"}
        foo["
        '''
    )
    source = 50
    row = 60
    column = 70

    # NB! filename must end with .py for completions to work
    filename = "test.py"
    if _using_older_jedi(jedi):
        completions = _tweak_completions(jedi.Script(code, source, row, column, filename).completions())
    else:
        completions = _tweak_completions(jedi.Script(code, path=filename).complete(line=row, column=column))

    assert completions[0].name == "a"
    assert completions[1].name

# Generated at 2022-06-26 07:24:59.614326
# Unit test for function get_script_completions
def test_get_script_completions():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 07:25:04.557757
# Unit test for function get_definitions
def test_get_definitions():
    source = parse_source("sys.argv")

    # For row = 1 and column = 5, get_definitions returns class 'jedi.api_classes.Completion', but is expected to be 'class 'jedi.api_classes.BaseDefinition'
    row = 1; column = 5; filename = "test_file.py"
    result = get_definitions(source, row, column, filename)
    expected =  []; assert result == expected


# Generated at 2022-06-26 07:25:09.648960
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import ast

    source = "if True: print(True)\r\nif True: print(True)"
    row = 2
    column = 10
    filename = ""
    expected = ast.If()
    result = get_definitions(source, row, column, filename)
    assert result == expected
    pass



# Generated at 2022-06-26 07:25:18.346397
# Unit test for function get_script_completions
def test_get_script_completions():
    def test_case_1():
        float_0 = 107.12386
        var_0 = parse_source(float_0)

    def test_case_2():
        float_0 = 107.12386
        var_0 = parse_source(float_0)

    def test_case_3():
        float_0 = 107.12386
        var_0 = parse_source(float_0)

    def test_case_4():
        float_0 = 107.12386
        var_0 = parse_source(float_0)

    def test_case_5():
        float_0 = 107.12386
        var_0 = parse_source(float_0)

    pass



# Generated at 2022-06-26 07:25:30.661500
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    float_0 = 107.12386
    var_0 = parse_source(float_0)

# Generated at 2022-06-26 07:25:33.351157
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_linux
    if not running_on_linux():
        return


# Generated at 2022-06-26 07:25:43.679727
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    int_0 = -56
    int_1 = 90
    dict_0 = {}
    dict_0[int_1] = int_0
    dict_0[int_0] = int_0
    str_0 = "b"
    dict_0[str_0] = str_0
    dict_0[int_1] = "d"
    var_0 = get_interpreter_completions(int_0, dict_0)
    get_interpreter_completions(int_1, dict_0)
    dict_0[str_0] = int_0
    dict_0["f"] = "d"
    get_interpreter_completions(int_1, dict_0)
    dict_0["f"] = int_0

# Generated at 2022-06-26 07:25:55.178407
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 5, 'test_file.py')
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 8, 'test_file.py')
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 9, 'test_file.py') is None
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 10, 'test_file.py') is None
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 11, 'test_file.py') is None
    assert get_definitions('class Foo: def foo(): pass\nFoo', 2, 12, 'test_file.py')

# Generated at 2022-06-26 07:26:13.341303
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = '''int('''
    namespaces = [{'var_0': 3}]
    ns = jedi.Interpreter(source, namespaces)
    result = get_interpreter_completions(source, namespaces)
    # Verify c0
    c0 = result[0]
    assert c0.name == 'x'
    assert c0.complete == 'x'
    assert c0.type == 'param'
    assert c0.description == 'param'
    assert c0.parent == '{}.{}'.format(ns.compiled_subprocess.modules['__main__'].path, 'int')
    assert c0.full_name == 'x'
    # Verify c1
    c1 = result[1]
    assert c1.name == 'base'


# Generated at 2022-06-26 07:26:19.656177
# Unit test for function get_script_completions
def test_get_script_completions():
    filename = '/home/mb/Thonny/thonny/plugins/jedi_plugin.py'
    source = """import importlib
import sys
from tkinter import font as font_module
from thonny.common import InlineCommand
from thonny.languages import tr
from thonny.misc_utils import running_on_mac_os"""
    row = 7
    column = 43
    test_0 = get_script_completions(source, row, column, filename)
    print(test_0)


# Generated at 2022-06-26 07:26:26.803386
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("sys.path_hooks", 1, 1, "")
        # Returns a list of definitions
        defs = script.goto_definitions()
        assert len(defs) == 6
        assert defs[0].type == "class"
        assert defs[0].line == 1
        assert defs[0].column == 5
        assert defs[0].in_builtin_module()
        assert defs[0].module_path == '__main__'
    else:
        script = jedi.Script(code="sys.path_hooks", path="")
        # Returns a list of definitions
        defs = script.infer(line=1, column=1)
        assert len(defs) == 7

# Generated at 2022-06-26 07:26:27.595093
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-26 07:26:30.797575
# Unit test for function get_definitions
def test_get_definitions():
    source = "import sys"
    row = 0
    column = 10
    filename = "sys.py"
    result = get_definitions(source, row, column, filename)
    assert result != None
    assert type(result) == list
    assert len(result) == 1


# Generated at 2022-06-26 07:26:41.365426
# Unit test for function get_script_completions
def test_get_script_completions():
    source_0 = 'print("hello")\n'
    row_0 = 0
    column_0 = 11
    filename_0 = "thonny/completion.py"
    result_0 = get_script_completions(source_0, row_0, column_0, filename_0)
    source_1 = "f = open('test_file.txt')\n"
    row_1 = 0
    column_1 = 13
    filename_1 = "test.py"
    result_1 = get_script_completions(source_1, row_1, column_1, filename_1)
    source_2 = "5/5"
    row_2 = 0
    column_2 = 1
    filename_2 = "test.py"

# Generated at 2022-06-26 07:26:49.357663
# Unit test for function get_script_completions
def test_get_script_completions():
    from pprint import pprint
    from jedi import Script

    script = Script("import math\nprint(ma")
    completions = script.completions()
    pprint([(c.name, c.module_path) for c in completions])

    completions = get_script_completions("import math\nprint(ma", 0, 0, "test_file.py")
    pprint([(c.name, c.module_path) for c in completions])

    assert len(completions) == 1
    assert completions[0].name == "math"
    assert completions[0].module_path == "math"



# Generated at 2022-06-26 07:26:53.547428
# Unit test for function get_script_completions
def test_get_script_completions():
    float_0 = 107.12386
    s = "import sys\nimport os\n"
    s += "print('hello')\n"
    s += "if \n"
    s += "else:\n"
    row = 6
    column = 4
    filename = "text.py"
    completion_0 = get_script_completions(s, row, column, filename)
    assert completion_0[0].name == "sys"

# Generated at 2022-06-26 07:27:04.144586
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Testing get_interpreter_completions")
    var_0 = get_interpreter_completions("int(coeff = 1, base = 2)", [], [])
    var_1 = get_interpreter_completions("int(coeff = 1, base = 2)", [], None)
    var_2 = get_interpreter_completions("", [], [])
    var_3 = get_interpreter_completions("", [], None)
    var_4 = get_interpreter_completions("", [{}], [])
    var_5 = get_interpreter_completions("", [{}], None)
    var_6 = get_interpreter_completions("", None, [])
    var_7 = get_interpreter_complet

# Generated at 2022-06-26 07:27:13.652270
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser import parser
    from jedi.evaluate import sys
    from jedi.evaluate.context import Context
    from jedi import Interpreter
    from jedi.parser_utils import get_cursor_pos_in_parent
    from jedi import completion
    from jedi.evaluate.cache import evaluator_function_cache
    from jedi.evaluate.cache import inference_state_cache
    from jedi import Evaluator
    from jedi import debug
    from jedi.evaluate.context.module import ModuleContext

    def _get_completions(source, namespace):

        # Get completions from the interpreter
        interpreter = Interpreter(source, namespace)
        return interpreter.completions()

    # Get the definitions for task 1
    _get_completions = get_interpreter_completions

   

# Generated at 2022-06-26 07:27:27.195771
# Unit test for function get_script_completions
def test_get_script_completions():
    assert None



# Generated at 2022-06-26 07:27:37.421651
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    test_source = """
    class TestClass:
        def __init__(self):
            self.test_field = 12
    
        def test_method(self):
            return self.test_field
    
    test_instance = TestClass()
    z = test_instance.test_method()
    """
    test_offset = test_source.find("z")
    script = jedi.Script(test_source, len("    "), test_offset, "test.py")
    first_definition = script.goto_definitions()[0]

    # Test the API of the jedi definition
    assert first_definition.line == len("    ") + 3
    assert first_definition.start_pos == test_source.find("test_instance")
    assert first_definition.end_pos == first_

# Generated at 2022-06-26 07:27:41.374576
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test for function get_interpreter_completions
    test_get_interpreter_completions_0()
    test_get_interpreter_completions_1()



# Generated at 2022-06-26 07:27:48.965348
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_0 = get_interpreter_completions('float_0 = 107.123', [])
    print(var_0[0].name)
    var_1 = get_interpreter_completions('import math', [])
    print(var_1[0].name)
    var_2 = get_interpreter_completions('math.flo', [])
    print(var_2[0].name)
    var_3 = get_interpreter_completions('math.floor(3.14)', [])
    print(var_3[0].name)
    var_4 = get_interpreter_completions('math.floor2(', [])
    assert(len(var_4) == 0)


# Generated at 2022-06-26 07:27:53.921858
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    float_0 = 107.12386
    var_0 = parse_source(float_0)
    float_1 = float_0

    # This is the line that causes the issue
    float_1 = float_1.as_integer_ratio()[0]

    var_1 = parse_source(float_1)

# Generated at 2022-06-26 07:28:03.797643
# Unit test for function get_interpreter_completions

# Generated at 2022-06-26 07:28:09.527019
# Unit test for function get_script_completions
def test_get_script_completions():
    print("\nTest case 0:")
    string_0 = "123456789009876543211234567890"
    int_0 = 500
    var_0 = get_script_completions(string_0,int_0,int_0,string_0)
    print("var_0: ", var_0)
    print("len(var_0): ", len(var_0))


# Generated at 2022-06-26 07:28:13.961329
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    import tempfile
    import contextlib

    def test_path():
        return os.path.join(tempfile.gettempdir(), "temp_module_for_jedi_testing.py")

    def module_content():
        return "b=42\n"

    def test_source():
        return "import temp_module_for_jedi_testing\ntemp_module_for_jedi_testing.b"

    @contextlib.contextmanager
    def add_and_remove_module():
        with open(test_path(), "w") as fp:
            fp.write(module_content())
        sys.path.append(os.path.dirname(test_path()))

        yield

        os.remove(test_path())
        sys.path.pop()


# Generated at 2022-06-26 07:28:16.301720
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    var_1 = get_interpreter_completions("a = 1\nprint(a)\nb", [], [])
    var_2 = get_interpreter_completions("a = 12\nprint(a)\nb", [], [])
    pass



# Generated at 2022-06-26 07:28:26.192892
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    if _using_older_jedi(jedi):
        raise Exception("Unsupported Jedi version")
    else:
        source = """
from math import radians, cos, sin, asi
for x in range(0, 11):
    print("{:2} {:4} {:4}".format(x, round(radians(x), 2),
                                  round(sin(radians(x)), 2)))
                                """
        filename = "/home/user/py/test_jedi.py"
        row = 6
        column = 24
        sys_path = ["/home/user/py"]
        script = jedi.Script(code=source, path=filename, project = _get_new_jedi_project(sys_path))
    #    completions = script.complete(line=row, column=column

# Generated at 2022-06-26 07:29:03.984462
# Unit test for function get_script_completions
def test_get_script_completions():
    # This example is part of a file named 'test.py' at the root of a project
    # named 'thonny-debug'.
    float_0 = 10.123456
    # Get completions for the current position.
    # Note: Jedi's API is 0-based.
    script_0 = get_script_completions("test.py", 25, 5, "/home/thonny-debug")
    print(script_0)
    # Expected output: [Completion(name='__abs__', complete='__abs__()', type='definition', description='__abs__(${1:self}, /)', parent='builtins.float', full_name='builtins.float.__abs__')]


# Generated at 2022-06-26 07:29:06.491200
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    var_0 = get_script_completions(float_0, row, column, filename, sys_path=None)


# Generated at 2022-06-26 07:29:08.367705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert not get_interpreter_completions("", [], None)

# Unit test fucntion get_script_completions

# Generated at 2022-06-26 07:29:13.103978
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions
    assert get_interpreter_completions("import os\n", [])
    assert get_interpreter_completions("a\n", [{"a": 1}])
    assert not get_interpreter_completions("b\n", [{"a": 1}])



# Generated at 2022-06-26 07:29:16.312606
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import random

    assert _using_older_jedi(jedi) == False

# Generated at 2022-06-26 07:29:17.031363
# Unit test for function get_definitions

# Generated at 2022-06-26 07:29:25.974063
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.sh import ShBackend
    import parso

    # Class under test
    script = parse_source("print(123")
    # Known input
    source = "print(123"
    row = 1
    column = 9
    filename = "test.py"
    sys_path = ["foo", "bar"]

    # Expected output
    if _using_older_jedi(parso):
        return get_script_completions(source, row, column, filename, sys_path)
    else:
        script = parso.parse(source)
        completions = get_script_completions(source, row, column, filename, sys_path)

# Generated at 2022-06-26 07:29:27.796945
# Unit test for function get_definitions
def test_get_definitions():
    filename = __file__
    get_statement_of_position(filename, filename)
    get_script_completions(filename, filename, filename, filename)
    get_definitions(filename, filename, filename, filename)
    completions = get_interpreter_completions(filename, filename)

# Generated at 2022-06-26 07:29:33.617950
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Arrange
    source = 'import os;import sys; os.path.joi'
    namespaces = [{'__name__': '__main__', 'os': {}, 'sys': {}}]

    # Act
    result = get_interpreter_completions(source, namespaces)
    
    # Assert
    result_names = [x.name for x in result]
    assert 'join' in result_names


# Generated at 2022-06-26 07:29:39.870954
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "spam = Spam"
    namespaces = [{
        "foo": "spam",
        "bar": 1
    }]
    result = get_interpreter_completions(source, namespaces)
    assert result is not None
    # In older Jedi versions e.g. 0.16.0 result is not a list
    assert isinstance(result, list)
    assert isinstance(result[0], ThonnyCompletion)



# Generated at 2022-06-26 07:30:54.610478
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    assert get_interpreter_completions('import os', [], None) == get_interpreter_completions(
        'import os', [], None
    )
    assert get_interpreter_completions('import os', [], None)[0]['name'] == 'openslide'
    assert get_interpreter_completions('import os', [], None)[0]['complete'] == 'openslide'
    assert get_interpreter_completions('import os', [], None)[0]['type'] == 'module'
    assert (
        get_interpreter_completions('import os', [], None)[0]['description']
        == 'openslide - High-resolution whole slide image python library'
    )

# Generated at 2022-06-26 07:30:59.082223
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import"
    namespaces = [
        {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__loader__": None,
            "__spec__": None,
            "__builtins__": None,
        }
    ]

    assert get_interpreter_completions(source, namespaces) is not None   


# Generated at 2022-06-26 07:31:03.183926
# Unit test for function get_script_completions
def test_get_script_completions():
    string_0 = '"print" in get_script_completions(string_0,42,32,string_3)'
    string_1 = '"print" in get_script_completions(string_1,85,51,string_2)'
    assert "print" in get_script_completions(string_0, 42, 32, string_3)
    assert "print" in get_script_completions(string_1, 85, 51, string_2)



# Generated at 2022-06-26 07:31:11.417280
# Unit test for function get_definitions
def test_get_definitions():
    # These two fail in parso 0.7
    test_0 = get_definitions('import math\nm=math.radians;m(', 12, 4, '')
    test_1 = get_definitions('class Z:\n def m(self):\n  pass\n\nclass X:\n  def __init__(self):\n   self.z=Z()\nx=X()\nz=x.z', 42, 3, '')
    # These two fail in jedi 0.19.0, pass in 0.20.0
    test_2 = get_definitions('from math import radians\nradians\n', 21, 6, '')

# Generated at 2022-06-26 07:31:16.386279
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # Test 1
    var_0 = get_interpreter_completions("float", [{"float": float}])
    assert var_0[0].name == "from", "Name != `from`"
    assert var_0[0].complete == "from __future__ import barry_as_FLUFL"


# Generated at 2022-06-26 07:31:18.257757
# Unit test for function get_definitions
def test_get_definitions():
    float_0 = float(107.12386)
    var_0 = get_definitions(float_0, 2, 0, 2)


# Generated at 2022-06-26 07:31:19.529257
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    assert not _using_older_jedi(jedi)



# Generated at 2022-06-26 07:31:26.672057
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    source = """
    a = 1
    b = 2
    c = 3
    my_sum = a + b + c
    """
    row = 5
    col = 16
    filename = "t.py"
    sys_path = ['/home/user/example']
    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, col, filename, sys_path=sys_path)
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path=filename)
        completions = script.complete(line=row)
    for completion in completions:
        print(completion.name)



# Generated at 2022-06-26 07:31:34.242094
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = ""
    for name in ["float", "int", "str", "list", "set", "tuple"]:
        source += f"{name}("

    namespaces = [{"float": float, "int": int, "str": str, "list": list, "set": set, "tuple": tuple}]

    result = get_interpreter_completions(source, namespaces)
    if jedi.__version__[:3] != "0.7":
        assert len(result) == 15
    else:
        assert len(result) == 14



# Generated at 2022-06-26 07:31:35.987155
# Unit test for function get_script_completions
def test_get_script_completions():
    return get_script_completions("", 1, 1, "", [])
