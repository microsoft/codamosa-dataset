

# Generated at 2022-06-12 12:44:32.022864
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    source = "import os; os.path"
    completions = get_script_completions(source, 1, 16, "")
    assert len(completions) > 0
    for completion in completions:
        assert completion.complete == completion.name

    if _using_older_jedi(jedi):
        source = "from ast import literal_eval as le; le("
        completions = get_script_completions(source, 1, 30, "")
        assert len(completions) == 1
        assert completions[0].complete == "le("
        assert completions[0].name == "le"
    else:
        source = "from ast import literal_eval as le; le("
        completions = get_script_completions(source, 1, 30, "")
        assert len

# Generated at 2022-06-12 12:44:36.020461
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions(
        "import datetime\n\ndatetime.timedelta", 0, 0, "source_path"
    )
    assert len(defs) == 1
    assert "timedelta" in defs[0].description



# Generated at 2022-06-12 12:44:44.173107
# Unit test for function get_script_completions
def test_get_script_completions():
    # Try both versions
    import jedi

    if _using_older_jedi(jedi):
        assert not _using_older_jedi(jedi)
    else:
        assert _using_older_jedi(jedi)

    # Try parameter sys_path
    completions = get_script_completions("import ", 0, 7, "", ["."])  # Replace empty string in sys_path with dot
    assert len(completions) > 0

    # Try with trailing dot
    completions = get_script_completions("import ", 0, 7, "", ["."])  # Replace empty string in sys_path with dot
    assert len(completions) > 0



# Generated at 2022-06-12 12:44:51.362142
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    import jedi
    source = "import os\nos.listdir()\n"
    script = jedi.Script(source, 1, 3, __file__, sys_path=[os.getcwd()])
    defs = script.goto_definitions()
    for d in defs:
        print(d.docstring())

# Generated at 2022-06-12 12:44:56.845002
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        completions = get_script_completions("impor", 1, 1, __file__)
    else:
        completions = get_script_completions("impor", 1, 1, __file__)


# Generated at 2022-06-12 12:45:06.509035
# Unit test for function get_script_completions
def test_get_script_completions():
    test_cases = [
        ("""import os, sys
print(os.p)
""", ["path", "pathsep", "pipe", "popen"]),
        ("""if True:
    print(os.p)
""", ["path", "pathsep", "pipe", "popen"]),
        ("""def f():
    print(os.p)
""", ["path", "pathsep", "pipe", "popen"]),
        ("""print(os.p)
""", ["path", "pathsep", "pipe", "popen"]),
    ]

    for case in test_cases:
        assert [c.name for c in get_script_completions(case[0], 2, 12, "foo.py")] == case[1]

# Generated at 2022-06-12 12:45:16.178782
# Unit test for function get_definitions
def test_get_definitions():
    def test(source, row, column, expected):
        from jedi.parser_utils import get_statement_of_position

        source = source.replace("\n", "\r\n")
        node = parse_source(source)
        node = get_statement_of_position(node, (row, column))
        print(str(node))
        print(str(node.children))
        print(str(node.parent))
        print(str(node.start_pos))
        print(str(node.end_pos))
        print(str(node.get_parent_function()))
        obs = get_definitions(source, row, column, "buffer")
        obs = "[%s]" % (", ".join(map(repr, obs)))
        if obs != expected:
            print(obs, expected)
            # assert

# Generated at 2022-06-12 12:45:16.997194
# Unit test for function get_definitions
def test_get_definitions():
    import ast


# Generated at 2022-06-12 12:45:22.228682
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import jedi
    except ImportError:
        print("Jedi is not installed")
        return

    import jedi

    completions = get_script_completions("def test():\n    pass\n\ntest", 3, 2, "test.py")
    for completion in completions:
        assert completion.parent is not None
        assert completion.full_name is not None

    completions = get_script_completions("def test():\n    pass\n\ntest", 3, 2, "test.py", sys_path=[])
    for completion in completions:
        assert completion.parent is not None
        assert completion.full_name is not None


# Generated at 2022-06-12 12:45:32.103830
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import queue", 1, 7, "<string>")[0].name == "Queue"
    assert get_script_completions("from queue import Priori", 1, 24, "<string>")[0].name == "PriorityQueue"
    assert get_script_completions("print(1, end=\"\")", 1, 12, "<string>")[0].name == "end="
    assert get_script_completions("print(1, end='')", 1, 12, "<string>")[0].name == "end="
    assert get_script_completions("def f(end", 1, 9, "<string>")[0].name == "end="


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:45:52.381691
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import collections
    import jedi


# Generated at 2022-06-12 12:45:57.132069
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("'hello'.upper().st", 1, 5, "test.py")
    assert len(result) > 0
    for entry in result:
        assert entry.complete == "startswith(" or entry.complete == "strip("
        assert entry.description.startswith("str.")
        assert entry.type == "function"

# Generated at 2022-06-12 12:46:09.237247
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.evaluate import compiled

    script = """
from tkinter import *
x = Tk()
x.icon""".strip()

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        interpreter = jedi.Interpreter(script, [{}, compiled.builtins.__dict__])
        completions = interpreter.completions()
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        interpreter = jedi.Interpreter(script, [{}, compiled.builtins.__dict__])
        completions = interpreter.complete()


# Generated at 2022-06-12 12:46:19.314841
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from thonny.jedi_utils import get_script_completions

    completions = get_script_completions("print(", 1, 6, "")
    #print(completions)
    assert completions[0].name == "print"
    completions = get_script_completions("import sys", 1, 7, "")
    assert completions[0].name == "sys"
    completions = get_script_completions("import sys", 1, 8, "")
    assert completions[0].name == "sys"

    # ensure the same result with jedi on the path
    import sys
    import os
    sys.path.insert(0, os.path.dirname(__file__))
    jedi_before = sys.modules.pop("jedi", None)

# Generated at 2022-06-12 12:46:30.407343
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    import jedi

    # test with older jedi
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "src"))
    namespaces = [{"os": os}, {}, {}, {}]
    result = get_interpreter_completions("os.", namespaces, sys_path=[])
    assert len(result) > 0
    assert "getcwd" in result[0].name
    assert len(result[0].complete) > len(
        result[0].name
    )  # complete is longer than name in older jedi

    # test with newer jedi
    result = get_interpreter_completions("os.", namespaces, sys_path=[])
    assert len(result) > 0
   

# Generated at 2022-06-12 12:46:41.054583
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # jedi 0.16.0
    text = """def foo():
    print("hello")

#|    
"""
    completions = get_script_completions(text, 4, 4, "")
    assert len(completions) == 1
    assert completions[0].name == "foo"

    # jedi 0.17.1
    text = """def foo():
    print("hello")

#|    
"""
    completions = get_script_completions(text, 4, 4, "")
    assert len(completions) == 1
    assert completions[0].name == "foo"
    assert completions[0].complete == "foo()"

    # jedi 0.18.0

# Generated at 2022-06-12 12:46:51.269771
# Unit test for function get_definitions
def test_get_definitions():
    def check(source, cursor, expected_def_row, expected_def_col, expected_def_text, expected_def_filename):
        definitions = get_definitions(source, cursor[0], cursor[1], "?")

        if len(definitions) > 0:
            definition = get_definitions(source, cursor[0], cursor[1], "?")[0]
            print(definition.line)
            print(definition.column)
            print(definition.get_code())
            print(definition.filename)
        else:
            return False

        if expected_def_row == definition.line and expected_def_col == definition.column and expected_def_text == definition.get_code() and expected_def_filename == definition.filename:
            return True
        else:
            return False
    

# Generated at 2022-06-12 12:47:00.332043
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import jedi
    from thonny.globals import get_workspace
    import os
    import os.path

    workspace = get_workspace()
    assert os.path.isdir(workspace)

    os.chdir(workspace)
    source = 'import sys\nsys.path.append("'+workspace+'")\n'
    source += 'import thonny\n'
    source += 'thonny.glo'
    completions = get_script_completions(source, 3, 14, 'test.py')

    assert (completions[0].complete == 'thonny.globals()')
    assert (completions[0].description == '<function> globals()')

# Generated at 2022-06-12 12:47:09.246213
# Unit test for function get_definitions

# Generated at 2022-06-12 12:47:18.345907
# Unit test for function get_script_completions
def test_get_script_completions():
    # test if trailing = was added to completion.name
    import jedi
    if _using_older_jedi(jedi):
        source = "class A: def method(self): pass\na = A()\na.method("
        row, column = 4, 12
    else:
        source = "class A: def method(self): pass\na = A()\na.method"
        row, column = 4, 11

    completions = get_script_completions(source, row, column, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "self=" and completions[0].complete == "self="

    # test use of sys_path
    from thonny import get_workbench, get_runner
    import os
    import jedi

    runner = get_

# Generated at 2022-06-12 12:47:37.295239
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        completions = get_interpreter_completions(
            "import os\nimport sys\nos.chdir(sys.path[0])\n",
            [{"name": "os", "module": os}, {"name": "sys", "module": sys}],
        )
    else:
        completions = get_interpreter_completions(
            "import os\nimport sys\nos.chdir(sys.path[0])\n",
            [{"name": "os", "module": os}, {"name": "sys", "module": sys}],
        )

    assert "path" in {c.complete for c in completions}
    assert "chdir" in {c.complete for c in completions}



# Generated at 2022-06-12 12:47:47.781590
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # https://github.com/davidhalter/jedi/issues/1635
    # Before this JIRA was fixed, the following code would return 'f' & 'o'
    # completions
    import json

    namespaces = []
    source = "import json\njson.lo"
    completions = get_interpreter_completions(source, namespaces)
    assert completions == [
        ThonnyCompletion(
            name="load",
            complete="load",
            type="function",
            description="load(fp, cls=None, object_hook=None, parse_float=None, parse_int=None, parse_constant=None, object_pairs_hook=None, **kw)",
            parent="builtins:json",
            full_name="json.load",
        )
    ]

# Generated at 2022-06-12 12:47:55.880621
# Unit test for function get_definitions
def test_get_definitions():
    def test_code(code, filename, expected_results):
        for row, col, definitions in expected_results:
            result = get_definitions(
                code, row, col, filename
            )  # returns an iterator of Definition objects
            definition_names = [d.name for d in result]
            assert definition_names == definitions, (
                "Failed at "
                + str(row)
                + ":"
                + str(col)
                + " for "
                + code
                + " at "
                + str(filename)
            )


# Generated at 2022-06-12 12:48:07.394737
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_windows

    def compare_expected_actual(expected, actual):
        assert len(expected) == len(actual)
        for e, a in zip(expected, actual):
            assert sorted(e.items()) == sorted(a.items())

    import jedi

    (jedi_version,) = jedi.__version__.split(".")[:1]
    if jedi_version in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
        completions = get_script_completions(
            source='import re; re.f', row=0, column=12, filename='test.py'
        )

# Generated at 2022-06-12 12:48:15.498338
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock
    from jedi.api.classes import Completion

    def get_completions(code, pos, filename, sys_path):
        name = Completion("name_only", "complete")
        name_with_equals = Completion("name_with_equals", "complete_with_equals=")
        name_with_object = Completion("name_with_object", "complete", object="object")

        if code == "import sys\nsys.stderr.wr" and pos == (2, 25) and filename == "test.py":
            return [name, name_with_equals, name_with_object]
        else:
            raise AssertionError("Unexpected call: " + repr((code, pos, filename)))

    jedi = MagicMock()
   

# Generated at 2022-06-12 12:48:24.774754
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    import jedi

    if _using_older_jedi(jedi):
        return

    # Current directory
    cwd = os.getcwd()
    # Directory of this test file
    test_dir = os.path.dirname(__file__)
    # Directory to add to sys.path temporarily
    add_to_path = os.path.join(test_dir, "../jedi_completions_test")

    # Remove from sys.path if exists
    if add_to_path in sys.path:
        sys.path.remove(add_to_path)


# Generated at 2022-06-12 12:48:35.326144
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:48:45.318539
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test case 1:
    completions = get_interpreter_completions(
        """
import sys
sys.get
""",
        [{"sys": sys}],
    )
    assert len(completions) > 0
    assert completions[0].name == "getdefaultencoding"
    assert completions[0].complete == "getdefaultencoding()"
    assert completions[0].type == "function"
    assert completions[0].full_name == "sys.getdefaultencoding"

    # Test case 2:
    completions = get_interpreter_completions(
        """
import sys
sys.get
""",
        [{"sys": {}}, {"sys": sys}, {"sys": {"modules": {}}}],
    )
    assert len(completions) == 0

    # Test case

# Generated at 2022-06-12 12:48:51.771410
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    jedi.__version__ = "0.17"
    import jedi.api
    assert get_script_completions("pr", 0, 2, "") == jedi.api.Script("pr").completions()
    jedi.__version__ = "0.18"
    import parso
    import jedi.api
    assert get_script_completions("pr", 0, 2, "") == jedi.api.Script(
        code="pr", path="", project=parso.Project()
    ).complete(0, 2)



# Generated at 2022-06-12 12:48:55.244340
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi._compatibility import unicode
    from jedi.api import classes
    from jedi.api.helpers import PreloadObject, sequence_to_str_list


# Generated at 2022-06-12 12:49:10.369367
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.globals import get_runner
    from thonny.config import get_workbench

    interpreter = get_workbench().get_editor_notebook().get_current_editor().interpreter
    get_runner().load_test_helper()
    completions = get_interpreter_completions("from thonny.globals import get_runner\n"
                                              + "from thonny.plugins.test_helper import on_random_float_event\n"
                                              + "get_runner().load_test_helper()\n"
                                              + "on_random_float_event(",
                                              [interpreter.get_namespace()])
    translations = [completion.name for completion in completions]
    assert "format_float" in translations
   

# Generated at 2022-06-12 12:49:13.314513
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:49:21.400427
# Unit test for function get_definitions
def test_get_definitions():
    def get_definitions_at(source, row, col):
        definitions = get_definitions(source, row, col, "test.py")
        return [(d.line, d.column) for d in definitions]

    assert get_definitions_at("import math\nmath.sin\n", 2, 5) == [(1, 7)]
    assert get_definitions_at("import math\ndef f():\n   x = math.sin\n   x\n", 4, 2) == [(1, 7)]



# Generated at 2022-06-12 12:49:29.923495
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os
    import traceback
    import warnings
    warnings.simplefilter("error")

    sys.path.append(os.path.dirname(__file__))
    import test_script_completions_old_jedi
    import test_script_completions_new_jedi

    try:
        try:
            test_script_completions_old_jedi.test()
        except AttributeError:
            test_script_completions_new_jedi.test()
    except BaseException as e:
        print("test_get_script_completions failed")
        traceback.print_exc()
        raise e
    finally:
        sys.path.pop()

# Generated at 2022-06-12 12:49:40.915859
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert len(get_interpreter_completions("datetime", [])) > 100
    assert len(get_interpreter_completions("datetime.", [])) > 10
    assert len(get_interpreter_completions("datetime.datetime.now", [])) > 10
    assert len(get_interpreter_completions("datetime.datetime.now().", [])) > 10
    assert len(get_interpreter_completions("math.sin", [])) > 10

    assert len(get_interpreter_completions("class C: pass\n x = C()\n x.", [])) > 10

    # trying to import

# Generated at 2022-06-12 12:49:42.501204
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest


# Generated at 2022-06-12 12:49:49.082099
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # Newest jedi returns different values for some reasons
    # TODO: check on deeper level

    assert get_script_completions("open", 0, 4, "x.py")[0].name == "open"
    assert get_script_completions("open", 0, 5, "x.py")[0].name == "open"

    # Take extra care for missing '=' problem
    assert get_script_completions("open('x')", 0, 10, "x.py")[0].name == "open("
    assert get_script_completions("open('x')", 0, 11, "x.py")[0].name == "open("



# Generated at 2022-06-12 12:49:58.932322
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    from thonny.misc_utils import running_on_windows
    completions = get_script_completions("pri", 0, 3, "script.py")
    for c in completions:
        if c.name == "print":
            break
    else:
        assert False, "No print completion found!"

    completions = get_script_completions("r'.'.jo", 0, 8, "script.py")
    for c in completions:
        if c.name == "join":
            break
    else:
        assert False, "No join completion found!"

    completions = get_script_completions("r'.'.jo", 0, 8, "script.py", [])

# Generated at 2022-06-12 12:49:59.784850
# Unit test for function get_definitions

# Generated at 2022-06-12 12:50:07.854309
# Unit test for function get_script_completions
def test_get_script_completions():
    def check(source, column, expected_result):
        result = get_script_completions(source, 0, column, "example.py")
        result = {c.name for c in result}
        assert result == expected_result

    check('s = "abc"\ns.u', 7, {"upper"})
    check('s = "abc"\ns.up', 8, {"upper", "upper"})
    check('s = "abc"\ns.upper', 9, {"upper", "upper"})
    check('s = "abc"\ns.upper(', 11, {"upper", "upper"})
    check('s = "abc"\ns.upper().i', 14, {"isupper", "isupper"})

# Generated at 2022-06-12 12:50:28.295222
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    completions = get_interpreter_completions("1 + b", [{}])
    assert completions[0].name == completions[0].complete

# Generated at 2022-06-12 12:50:30.867247
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import sys"""

    completions = get_script_completions(source, 0, 7, "<stdin>")
    assert len(completions) == 295



# Generated at 2022-06-12 12:50:39.268770
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import sys,os\nimport sys.os", 1, 17, "<test>")
    assert len(completions) > 0
    # 1.13 - 0.17 returns two completions, one with and one without '.'
    if _using_older_jedi(completions[0].__class__.__module__):
        assert all(c.name == "sys." for c in completions)
    else:
        assert all(c.name in ("sys.", "sys") for c in completions)
    assert all(c.complete == "sys" for c in completions)


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:50:43.396009
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("Strin", 1, 6, "")) > 0
    assert len(get_script_completions("foo.is", 1, 5, "")) > 0
    assert len(get_script_completions("foo.isl", 1, 6, "")) > 0

# Generated at 2022-06-12 12:50:54.119065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from parso.python.tree import ListComprehension
    from parso.python.tree import GeneratorExpression
    from parso.python.tree import DictComprehension
    from parso.python.tree import SetComprehension
    from parso.python.tree import Lambda

    s = "from tkinter import *\n"
    s += "widget = Button()\n"
    s += "widget.grid()\n"
    s += "widget.pack()\n"
    s += "widget.place()\n"
    s += "widget.config(text='hello world')\n"
    s += "def foo():\n"
    s += "    widget.foo()\n"
    s += "foo()\n"
    s += "import sys\n"

# Generated at 2022-06-12 12:51:01.607045
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_windows
    completions = get_interpreter_completions(
        "import os; os.",
        get_workbench().get_builtins_checker().get_namespaces(),
        sys_path=get_workbench().get_local_sys_path()
    )
    assert len(completions) > 0
    # 0.18 returns `ma' in Unix, but `path' in Windows
    if running_on_windows():
        assert any(c.name == "path" for c in completions)
    else:
        assert any(c.name == "ma" for c in completions)

# Generated at 2022-06-12 12:51:11.711424
# Unit test for function get_script_completions
def test_get_script_completions():
    from textwrap import dedent
    from collections import namedtuple
    TestCase = namedtuple("TestCase", ["source", "row", "column", "completion_name"])


# Generated at 2022-06-12 12:51:15.374344
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # https://github.com/davidhalter/jedi/blob/
    # 0.17/test/test_completion/test_keyword.py#L168-L180
    namespaces = [{'__name__': '__main__', '__file__': '/path/to/file'}]

# Generated at 2022-06-12 12:51:16.918806
# Unit test for function get_script_completions
def test_get_script_completions():
    for _ in get_script_completions("1", 1, 0, "xxx"):
        pass

# Generated at 2022-06-12 12:51:26.229686
# Unit test for function get_script_completions
def test_get_script_completions():
    # TODO: fix this test
    if _using_older_jedi(jedi):
        pass
    else:
        source = "import sys\n"
        source += "\n" * 11
        source += "sys"
        row = 12
        column = 4
        filename = "x.py"
        print(get_script_completions(source, row, column, filename))

    if _using_older_jedi(jedi):
        pass
    else:
        source = "import sys\n"
        source += "\n" * 11
        source += "sys"
        row = 12
        column = 4
        filename = "x.py"
        print(get_script_completions(source, row, column, filename))


if __name__ == "__main__":
    test_get_script

# Generated at 2022-06-12 12:52:18.819500
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"a": 1}]
    source = "a."
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "bit_length"

# Generated at 2022-06-12 12:52:26.342096
# Unit test for function get_definitions

# Generated at 2022-06-12 12:52:28.985129
# Unit test for function get_definitions

# Generated at 2022-06-12 12:52:36.205657
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completion.jedi_utils import get_script_completions
    completions = get_script_completions(
        source="print(1)\n", row=1, column=7, filename="test.py"
    )
    assert len(completions) == 1
    assert completions[0].name == "print"
    assert completions[0].complete == "print("
    assert completions[0].type == "statement"
    assert completions[0].full_name == "builtins.print"



# Generated at 2022-06-12 12:52:40.485887
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    print("jedi version: "+str(jedi.__version__))

    source = """
import x
x.
"""
    [res] = get_script_completions(source, 4, 2, "test.py")
    assert res["name"] == "environ"



# Generated at 2022-06-12 12:52:43.591893
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions(source='''
    import random
    r = random.ra''', row=3, column=8, filename = "")
    assert len(defs) == 1
    assert defs[0].module_name == 'random'


# Generated at 2022-06-12 12:52:49.525319
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # This is a tricky test for completions in case when the following is created in REPL:
    # - new module
    # - class
    # - instance of the class
    # - insert attribute to the class (via __setattr__)
    # - insert attribute to the instance (via __setattr__)
    # - insert method to the class (via __setattr__)
    # - insert method to the instance (via __setattr__)
    # - and finally call the method from the instance
    #
    # So, the test first creates module, class and instance for the class (vs.namespaces)
    # Then calls get_interpreter_completions and checks the result.
    # After that inserts attr/methods to the class and instance, and at the end checks result again.

    import jedi, sys

    vs = {}
   

# Generated at 2022-06-12 12:52:55.382340
# Unit test for function get_script_completions
def test_get_script_completions():
    def completions_for(code):
        return get_script_completions(code, len(code.splitlines()), len(code.splitlines()[-1]), "")

    print(completions_for("spam = 4"))
    print(completions_for('spam = "spam"'))
    print(completions_for('spam.sp'))

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:53:01.393881
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    # In some situations jedi could not infer completions.
    # For example, in case when you try to infer parameter from other parameters
    # or from global scope.
    # In such situations as in case when jedi is not able to infer completions,
    # it rises Exception.
    # In order to avoid such situations we need to override function
    # completions in jedi.Script class which can return empty array
    # for such situation
    def get_completions(self):
        try:
            completions = self._get_completions()
        except Exception:
            completions = []
        completions.sort(key=lambda d: d.name)
        return completions
    jedi.Script.completions = get_completions


# Generated at 2022-06-12 12:53:10.611035
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import random
    import string
    import sys
    from thonny.jedi_utils import get_interpreter_completions

    rnd = random.Random()
    rnd.seed(42)

    # Random for the built-in namespace
    def rnd_builtins():
        return rnd.choices(string.ascii_lowercase, k=rnd.randint(3, 10))

    # Random for user-defined namespace
    def rnd_user():
        return "".join(
            c if i > 1 else c.upper()
            for i, c in enumerate(rnd.choices(string.ascii_lowercase, k=rnd.randint(3, 10)))
        )

    def generate_user_namespace():
        d = {}