

# Generated at 2022-06-12 12:44:31.344402
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api import Script as S

    assert get_script_completions('foo', 1, 1, 'xxx') == S('foo', 1, 1, 'xxx').completions()
    assert get_script_completions('foo', 1, 1, 'xxx', sys_path=('/tmp/xxx',)) == S('foo', 1, 1, 'xxx', sys_path=('/tmp/xxx',)).completions()

    if int(jedi.__version__.split('.')[1]) <= 17:
        try:
            get_script_completions('foo', 1, 1, 'xxx', sys_path=('/tmp/xxx-unknown',))
            assert False
        except Exception:
            # should fail due to lookup failure
            pass

    # Nothing should happen if sys_path is passed

# Generated at 2022-06-12 12:44:40.455871
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script

    source = "import math\nmath.f"
    script = Script(source)
    completions = script.completions()
    assert len(completions) == 1
    assert completions[0].name == "math.factorial"
    assert completions[0].complete == "math.factorial"
    assert completions[0].type == "function"
    assert completions[0].description == "factorial(x) -> Integral\n\nFind x!. Raise a ValueError if x is negative or non-integral."
    assert completions[0].parent.type == "module"
    assert completions[0].full_name == "math.factorial"

# Generated at 2022-06-12 12:44:40.896656
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:44:47.866896
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = dedent(
        """\
    class Outer:
    
        class Inner:
            pass
        
        def method(self):
            pass
    
    outer = Outer()
    outer.
    """.rstrip()
    )
    completions = get_interpreter_completions(source, [])
    assert "method" in [c.name for c in completions]
    assert "Inner" in [c.name for c in completions]
    assert "Inner" not in [c.complete for c in completions]
    assert "method" not in [c.complete for c in completions]

# Generated at 2022-06-12 12:44:56.917644
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import math\n\nm = math."
    row = 2  # zero based
    column = 10  # zero based
    filename = "foobar.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    for completion in completions:
        assert len(completion.complete) > 0
        assert len(completion.type) > 0
        assert len(completion.description) > 0
        assert len(completion.name) > 0
        assert len(completion.full_name) > 0


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:45:06.909879
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock
    import jedi
    from jedi import api_classes
    import sys
    import os

    completions = [api_classes.Completion("test1", "test1", "TYPE", "description", "parent", "full name")]
    script = MagicMock()
    script.complete = MagicMock(return_value=completions)
    script.completions = MagicMock(return_value=completions)
    jedi.Script = MagicMock(return_value=script)

    jedi_version = jedi.__version__[:4]

# Generated at 2022-06-12 12:45:16.214158
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import jedi

    if _using_older_jedi(jedi):
        return

    # This test depends on the version of Python
    if sys.version_info < (3, 5):
        directory_dict = {}
    else:
        directory_dict = {'2.py': 'import three\nthree.Vector2D',
                          '3.py': 'from six import Vector3D, Vector4D'}


# Generated at 2022-06-12 12:45:20.511992
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{'__name__': '__main__', '__builtins__': __builtins__}]
    result = get_interpreter_completions("", namespaces)

    assert isinstance(result, list)
    assert all(isinstance(x, ThonnyCompletion) for x in result)

# Generated at 2022-06-12 12:45:30.732336
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # code = "import os\nos.remo"
        # completions = get_interpreter_completions(code, [])
        # assert len(completions) == 1
        # assert completions[0].complete == "os.remove"

        code = "import os\n os.remo"
        completions = get_interpreter_completions(code, [])
        assert len(completions) == 0

    else:
        code = "import os\nos.remo"
        completions = get_interpreter_completions(code, [])
        assert len(completions) == 1
        assert completions[0].complete == "os.remove"
        assert completions[0].name == "remove"

# Generated at 2022-06-12 12:45:36.371637
# Unit test for function get_definitions
def test_get_definitions():
    print()
    print("get_definitions.py")
    print()
    print(get_definitions("a = 1", 0, 3, "test1.py"))
    print()
    print(get_definitions("a = 1\nb = a", 1, 5, "test2.py"))
    print()
    print(get_definitions("a = 1\nprint(a)", 1, 8, "test3.py"))
    print()
    print(get_definitions("def foo():\n    pass", 0, 4, "test4.py"))
    print()
    print(get_definitions("def foo():\n    pass", 1, 4, "test5.py"))
    print()
    print(get_definitions("print", 0, 5, "test6.py"))
    print()

# Generated at 2022-06-12 12:45:50.883523
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions("", [{"x": "100"}])
    assert [c.name for c in result] == ["x"]



# Generated at 2022-06-12 12:46:01.348926
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    from unittest import mock

    this_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, this_dir)
    from test_utils.capture import capture_output

    lines = [
        "import os",
        "os.path.exists('')",
        "os.path.exists(    '')",
        "os.path.join(    '','')",
        "os.path.join('','')",
        "os.path.join('','').",
        "os.path.join('','').r",
    ]


# Generated at 2022-06-12 12:46:13.239940
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import jedi

    if _using_older_jedi(jedi):
        expected_candidates = ["_", "__", "__author__", "__build_class__"]
        script = Script("__", line=0, column=2)
        candidates = get_script_completions(script.source, 0, 2, "/dev/null")
        assert len(candidates) >= len(expected_candidates), candidates
        for c in candidates:
            assert c.name in expected_candidates, c.name
    else:
        expected_candidates = ["_", "__", "__author__"]
        script = Script("__", path="/dev/null")
        candidates = get_script_completions(script.source, 0, 2, "/dev/null")
        assert len(candidates)

# Generated at 2022-06-12 12:46:18.812262
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    script_text = "import os; o"
    completions = get_interpreter_completions(script_text, [])
    assert len(completions) >= 2
    assert any([c.name == "os" and not c.complete.endswith("o") for c in completions])
    assert any([c.name == "os." and c.complete.endswith("o") for c in completions])



# Generated at 2022-06-12 12:46:29.967481
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import os
    script = Script("import sys", 1, 7, "", sys_path=["/usr/lib/python3.6"])
    completions = script.completions()
    assert completions
    for c in completions:
        assert c.startswith("sys.")
        assert c.endswith(" ") or c.endswith("(") or c.endswith(".") or c.endswith("=")

    script = Script("import os", 1, 7, "", sys_path=["/usr/lib/python3.6"])
    completions = script.completions()
    assert completions
    for c in completions:
        assert c.startswith("os.")
        assert c.endswith(" ") or c.endswith("(")

# Generated at 2022-06-12 12:46:33.049997
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    script = jedi.Script("logging.info", 1, 11)
    defs = script.goto_definitions()
    print(defs)

# Generated at 2022-06-12 12:46:42.448329
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.case

    import sys
    from pathlib import Path
    from typing import List

    from jedi.parser.tree import Node
    from parso import tree as parso_tree

    from thonny.plugins.backend.jedi_utils import get_definitions
    from thonny.plugins.backend.python_backend import PythonBackend
    from thonny.plugins.backend.simple_backend import SimpleBackend

    class TestCase(unittest.case.TestCase):
        def run_test(self, source, target_nodes):
            result = get_definitions(source, 1, 1, "")
            self.assertEqual(len(result), len(target_nodes))
            result_nodes = set([r.name for r in result])

# Generated at 2022-06-12 12:46:50.959596
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi._compatibility import _force_unicode

    source = _force_unicode("""
import datetime
datetime.date""")

    completions = get_script_completions(source, 1, 12, "")
    assert len(completions) > 0
    for c in completions:
        print(c.name)
        assert c.name != "date="
    assert "date" in dict(completions)

    # This doesn't work in jedi < 0.16
    # completions = get_script_completions(source, 3, 5, "")
    # assert "date" in dict(completions)

# Generated at 2022-06-12 12:47:00.184539
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.plugins.jedi_utils import get_definitions
    from thonny.plugins.jedi_utils import _tweak_completions
    from jedi.api.project import Project
    import jedi

    if _using_older_jedi(jedi):
        return

    Project._get_path_to_python = lambda x: "/usr/bin/python3"

    # test with none sys_path
    definitions = get_definitions('a = env.active_text_editor()\na.text', row=1, column=1, filename='test_file.py')
    test_name = 'a'
    test_description = 'foo'
    test_type = 'statement'
    test_fullname = 'a'


# Generated at 2022-06-12 12:47:07.600330
# Unit test for function get_script_completions
def test_get_script_completions():
    import inspect
    import sys
    import jedi

    filename = inspect.getfile(test_get_script_completions)
    source = open(filename, encoding="utf-8").read()
    row = 19
    column = 7
    sys_path = [os.path.dirname(os.path.dirname(os.path.dirname(jedi.__file__)))]
    completions = get_script_completions(source, row, column, filename, sys_path)
    for comp in completions:
        if comp.name == "sys.argv":
            return
    raise Exception("Completion not found")


# Generated at 2022-06-12 12:47:27.861116
# Unit test for function get_script_completions
def test_get_script_completions():
    
    import re
    import jedi
    from thonny.python_toplevel import PythonToplevel
    
    if jedi.__version__[0:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        return
    
    toplevel = PythonToplevel()
    source = "import math\n" \
             "math.\n" \
             "math."
    row = 1
    column = 7
    filename = "math_test.py"

    comps = get_script_completions(source, row, column, filename, sys_path=[])
    assert len(comps) == 80
    assert comps[0].name == "acos"

# Generated at 2022-06-12 12:47:38.162815
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.misc_utils import running_on_windows
    import sys
    import os
    import unittest

    class JediCompletionsTest(unittest.TestCase):
        @unittest.skipIf(running_on_windows(), "Currently broken on Windows")
        def test_basic(self):
            completions = get_interpreter_completions(
                source="sys.std", namespaces=[{"name": "__main__", "path": __file__}]
            )
            self.assertTrue(any([c.name == "stdin" for c in completions]))


# Generated at 2022-06-12 12:47:41.643016
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script

    assert len(Script(code='x=1').goto_definitions()) == 0
    assert len(Script(code='x=1\nx=2').goto_definitions()) == 1

# Generated at 2022-06-12 12:47:51.336634
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        source="a=1", row=0, column=2, filename="test.py"
    )
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "="

    completions = get_script_completions(
        source="a = 1", row=0, column=4, filename="test.py"
    )
    assert len(completions) == 1
    assert completions[0].name == "a"

    completions = get_script_completions(
        source="a = 1", row=0, column=5, filename="test.py"
    )
    assert len(completions) == 0


# Generated at 2022-06-12 12:47:54.714339
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("str.st", 0, 6, "")
    assert len(completions) == 19
    assert completions[0].name == "strip"
    assert completions[0].full_name == "str.strip"



# Generated at 2022-06-12 12:48:01.170065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_jedi_utils import get_interpreter_completions as old_function
    from unittest.mock import MagicMock

    old_interpreter_class = MagicMock()
    old_interpreter_class.return_value.complete.return_value = [
        {"name": "int", "type": "int", "description": "blah blah", "complete": "int"}
    ]
    old_function(old_interpreter_class)

    new_interpreter_class = MagicMock()

# Generated at 2022-06-12 12:48:05.901799
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    source = "import matplotlib\n"
    namespaces = [Interpreter("", []).namespace]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0

# Generated at 2022-06-12 12:48:14.721467
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def get_completions(code, row, column, pos_to_complete,
                        namespaces=[{"poop": "penis"}]):
        return [
            c.complete for c in get_interpreter_completions(code, namespaces, row, column)
        ]

    assert "poop = penis" in get_completions("import poop\npoop.", 0, 10, 10)
    assert "poop = penis" in get_completions("import poop\npoop.", 1, 0, 0)
    assert "test_get_interpreter_completions(code, row, column)" in get_completions(
        "test_get_interpreter_completions", 0, 0, 0
    )

# Generated at 2022-06-12 12:48:20.765098
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    import collections

    def check(deffun, expected):
        funcname, filename, lineno = expected
        assert deffun.description == funcname
        assert os.path.basename(deffun.module_path) == filename
        assert deffun.line == lineno

    # check that function works with unittest

# Generated at 2022-06-12 12:48:31.627227
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import prepare_namespaces
    from jedi.parser_utils import get_parent_scope

    source="open('hello.txt')"
    row = 1
    column=6
    namespaces = prepare_namespaces(False)

    # walk through the code and find the node that the current cursor
    # is in
    outer_module = Interpreter(source, namespaces).get_module()
    node = get_parent_scope(outer_module.tree, row, column)

    assert(node.start_pos[0] == row and node.start_pos[1] == column)

    assert(get_interpreter_completions(source, namespaces, sys_path=None) != [])

    # test with sys_path
    #

# Generated at 2022-06-12 12:48:44.374420
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    script = "import math\nmath."
    print(get_script_completions(script, 1, len(script), 'test.py'))



# Generated at 2022-06-12 12:48:49.631532
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import unittest
    import builtins

    sys.path.append("../Lib")
    sys.path.append("../../Lib")
    import test.test_completion

    suite = unittest.TestLoader().loadTestsFromTestCase(test.test_completion.GetDefinitionTestCase)
    result = unittest.TextTestRunner().run(suite)

    print("Errors and failures:")
    for error in result.errors:
        print("[ERROR]", error[0])
        for line in error[1].splitlines():
            print(line)
    for failure in result.failures:
        print("[FAIL]", failure[0])
        for line in failure[1].splitlines():
            print(line)
    if not result.wasSuccessful():
        raise Assertion

# Generated at 2022-06-12 12:49:00.559971
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python.tree import Module, Import, Imports
    from parso.python.parser import ParserError
    from parso.cache import parser_cache
    from parso import parse
    import jedi
    from parso.python import tree
    from jedi._compatibility import ModuleNotFoundError

    # Parse code
    code = 'import os\nimport par\nimport sys\n'
    parser = parse(code)
    # Add imaginary sys.path
    parser.children[0] = Imports((Import(tree.NamePart('sys', True)),))
    parser.children.insert(0, Module(name='sys', doc=None))

    # Import
    def _import_module(module_name, *args, **kwargs):
        if module_name == 'sys':
            return parser.children[0]

# Generated at 2022-06-12 12:49:08.777412
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple

    class MyCompletion:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

        def __getitem__(self, key):
            return self.__dict__[key]

        def __eq__(self, other):
            return (
                isinstance(other, MyCompletion)
                and self.name == other.name
                and self.complete == other.complete
                and self.type == other.type
                and self.description == other.description
                and self.parent == other.parent
                and self.full_name == other.full_name
            )

# Generated at 2022-06-12 12:49:18.792577
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\nos"  # when this source is passed, jedi can't find os.path, os.name, etc.
    namespaces = [{"os": {"path": "", "name": ""}}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 3
    assert set(["path", "name", "os"]) == set([c.name for c in completions])

    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 3  # in addition to above
    assert set(["path", "name"]) <= set([c.name for c in completions])



# Generated at 2022-06-12 12:49:29.001669
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("from tkinter import *", 0, 0, "test_filename.py")
    result.sort(key=lambda c: c.name)
    assert result[0].name == "_"
    assert result[0].complete == "_"
    assert result[0].type == "name"
    assert result[0].parent == "tkinter"
    assert result[0].full_name == "tkinter._"
    assert result[-1].name == "ttk"
    assert result[-1].complete == "ttk"
    assert result[-1].type == "module"
    assert result[-1].parent == "tkinter"
    assert result[-1].full_name == "tkinter.ttk"


# Generated at 2022-06-12 12:49:39.292247
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    import platform

    def fix_path(path):
        if platform.system() == "Windows":
            return path.replace("/", os.path.sep)
        else:
            return path

    # TODO: which version of jedi is this test written for?
    # Reason: jedi.Script('from typing import Optional').goto_definitions()
    # returns [] in recent versions of jedi, but ['Optional'] in older jedis
    # (see above)

# Generated at 2022-06-12 12:49:48.019424
# Unit test for function get_script_completions
def test_get_script_completions():
    for jedi_version in ["0.13.1", "0.14.1", "0.15.1", "0.16.0", "0.17.2", "0.18.0"]:
        print("Testing get_script_completions with jedi version " + jedi_version)
        import importlib.util

        spec = importlib.util.spec_from_file_location(
            "jedi", "/usr/local/lib/python3.7/site-packages/jedi/__init__.py"
        )
        # spec = importlib.util.spec_from_file_location("jedi", "/home/eero/.local/lib/python3.7/site-packages/jedi/__init__.py")
        module = importlib.util.module_from_spec(spec)
       

# Generated at 2022-06-12 12:49:58.537116
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = get_script_completions("pri", 0, 2, '')
    assert len(script) == 3
    assert isinstance(script[0], ThonnyCompletion)
    assert script[0].name == "print"
    assert script[0].complete == "print()"
    assert script[0].type == "statement"
    assert script[0].description == "print(value, ..., sep=' ', end='\n', file=sys.stdout, flush=False)"
    assert script[0].parent == "builtins"
    assert script[0].full_name == "builtins.print"
    assert script[1].name == "property"
    assert script[2].name == "private"

# Generated at 2022-06-12 12:50:07.001379
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions
    from pathlib import Path
    import json
    import os

    # load data
    data_path = Path(__file__).resolve().parent.parent
    filenames = json.loads(
        (data_path / "jedi-completion-cli/complete-filenames.json").read_text()
    )
    namespaces = json.loads((data_path / "jedi-completion-cli/complete-namespaces.json").read_text())

    for filename in filenames:
        with open(os.path.join(data_path, filename), "r") as file:
            source = file.read()

        completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-12 12:50:40.586645
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Each version of Jedi can give different completions.
    So this test should be run with different versions of Jedi.
    This can be achieved by running with different virtualenvs.
    """
    import sys
    assert sys.version_info[0] == 3
    jedi_version = sys.modules["jedi"].__version__
    assert jedi_version.startswith("0.") and not jedi_version.startswith("0.16")
    assert jedi_version.startswith("0.18") or jedi_version.startswith("0.19")


# Generated at 2022-06-12 12:50:43.548562
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"a": 1, "b": 3}]
    result = get_interpreter_completions("a.", namespaces)
    assert result[0].name == "a" and result[0].complete == "a" and result[0].type == "int"

# Generated at 2022-06-12 12:50:45.718432
# Unit test for function get_definitions
def test_get_definitions():
    if _using_older_jedi(jedi):
        print("old jedi")
    else:
        print("new jedi")

# Generated at 2022-06-12 12:50:51.072643
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert get_interpreter_completions("a = 'ab'\na.u", namespaces=[{}])[0].complete == "upper"
    assert get_interpreter_completions("a = 'ab'\na.u", namespaces=[])[0].complete == "upper"
    # Before 0.13, namespaces was not a list
 

# Generated at 2022-06-12 12:50:57.745138
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import thonny.python_shell

    source = """import os.path
os.path.st
"""

    namespaces = [{"os": os}]

    completions = get_interpreter_completions(source, namespaces)

    assert len(completions) >= 3
    assert any(c.name == "stat" for c in completions)
    assert any(c.name == "stat_float_times" for c in completions)
    assert any(c.name == "statvfs_result" for c in completions)

# Generated at 2022-06-12 12:50:58.300355
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:51:04.737929
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # set of test cases to test against
    test_set = [
        ("st", [("startswith", "")]),
        ("stat", [("stat", "")]),
        ("stat.", [("S_IFMT", ""), ("S_IFREG", ""), ("S_IFSOCK", "")]),
        ("import os; os.stat.", [("S_IFMT", ""), ("S_IFREG", ""), ("S_IFSOCK", "")]),
    ]

    with open("print_info.py", "w") as f:
        f.write("print('hello')\n")

    sys_path = [_normalize_path(os.path.dirname(__file__))]
    for source, set in test_set:
        completions = get_interpreter_completions

# Generated at 2022-06-12 12:51:13.836465
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_windows
    from jedi import Interpreter

    if running_on_windows():
        # jedi doesn't work on windows
        return

    # Test to get completions
    interpreter = Interpreter("import sys", [])
    if hasattr(interpreter, "completions"):
        # up to jedi 0.17
        interpreter_completions = interpreter.completions()
    else:
        interpreter_completions = interpreter.complete()
    start_len_completions = len(interpreter_completions)

    # Test if completions works
    get_workbench().test_cursor_position = ["get_completions_test", (1, 1)]
    get_work

# Generated at 2022-06-12 12:51:18.077199
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    code = """
import os
os.path"""

    completions = get_interpreter_completions(
        source=code, namespaces=[{"os": os}, {"sys": sys}, {"a": 1}]
    )
    assert len(completions) > 0


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:51:21.572934
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    >>> from jedi.api.interpreter import Interpreter
    >>> import sys
    >>> isinstance(get_interpreter_completions('', [{'name': 'sys', 'value': sys}])[0], Interpreter)
    True
    """
    assert True

# Generated at 2022-06-12 12:51:54.981518
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api.classes import Completion

    assert type(get_script_completions("", 1, 1, "")[0]) == Completion
    assert len(get_script_completions("import sys\n", 1, 1, "")) == 1
    assert len(get_script_completions("import sys\n", 2, 1, "")) > 10

    if _using_older_jedi(jedi):
        # older jedi returns completions in slightly different form
        assert get_script_completions("import sys\n", 2, 1, "")[0].name == "sys"
        assert get_script_completions("import sys\n", 2, 1, "")[0].complete == "sys."

# Generated at 2022-06-12 12:52:05.775287
# Unit test for function get_definitions
def test_get_definitions():
    try:
        import jedi
    except ImportError:
        return

    import os
    import sys
    import unittest

    current_dir = os.path.dirname(__file__)
    sys.path.append(os.path.join(current_dir, "jedi_test_data", "dir1"))
    sys.path.append(os.path.join(current_dir, "jedi_test_data", "dir2"))


# Generated at 2022-06-12 12:52:17.134935
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    completions = get_script_completions("import sys; sys.path.append('xxx');import", 3, 30, "test.py")
    assert any([comp.name == "sys" for comp in completions])
    assert any([comp.name == "test" for comp in completions])
    assert not any([comp.name == "append" for comp in completions])
    # print(completions)
    assert completions[0].complete == "sys.path"
    assert completions[3].complete == "test.py"
    assert completions[4].complete == "test.pyc"

    completions = get_script_completions("import sys, datetime, test", 0, 7, "test.py")
    assert any([comp.name == "sys" for comp in completions])
   

# Generated at 2022-06-12 12:52:25.203850
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import unittest
    import types

    class TestGetDefinitions(unittest.TestCase):
        def test_func_definitions(self):
            names = get_definitions("def foo():\n    pass\nfoo()\n", 2, 0, "")
            self.assertEqual(len(names), 1)
            self.assertEqual(names[0].type, "function")
            self.assertEqual(names[0].module_name, "<string>")

        def test_no_args_func_definitions(self):
            names = get_definitions("def foo():\n    pass\nfoo", 2, 0, "")
            self.assertEqual(len(names), 1)
            self.assertEqual(names[0].type, "function")
            self.assertE

# Generated at 2022-06-12 12:52:35.137414
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.api.classes import Interpreter
    if _using_older_jedi(jedi):
        source = '''
            def test_function(self):
                test = self.get_test()
                '''
        line = 4
        column = 14
        filename = ""
        namespaces = [locals()]
    else:
        source = '''
            def test_function(self):
                test = TestScript().get_test()
                '''
        line = 4
        column = 29
        filename = ""
        namespaces = [Interpreter(source).get_names()]
    completions = get_interpreter_completions(
        source=source, namespaces=namespaces, sys_path=None
    )
    assert len(completions) > 0
   

# Generated at 2022-06-12 12:52:42.031624
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """def foo(a, b, c):\n  pass\n\nprint(fo"""
    completions = get_script_completions(source, 3, 8, "test.py")
    assert len(completions) == 1
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == 'foo'
    assert completions[0].complete == 'foo('
    assert completions[0].description is None
    assert completions[0].parent is None
    assert completions[0].full_name is None



# Generated at 2022-06-12 12:52:48.601701
# Unit test for function get_definitions
def test_get_definitions():
    # here path to jedi is not loaded (will generate an error if not installed)
    import importlib.util
    import sys

    from thonny.common import get_runner

    # check if jedi is installed
    if not importlib.util.find_spec("jedi"):
        return
    # check for version<0.18
    elif hasattr(importlib.util.find_spec("jedi"), "version") and importlib.util.find_spec("jedi").version >= "0.18":
        return
    sys.path.append(get_runner().get_options()["python_path"])
    source = "a=1"
    row, column = (0, 0)
    filename = ""
    assert test_get_definitions_work() == get_definitions(source, row, column, filename)

# Generated at 2022-06-12 12:52:57.626069
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock
    from thonny.languageserver.jedi_utils import get_interpreter_completions
    from thonny.languageserver.jedi_utils import get_script_completions

    # Mock namespaces to simulate get_interpreter_completions
    namespaces = [
        {"globals": {"test1": "test1"}},
        {"globals": {"test2": "test2"}},
        {"globals": {"test3": "test3"}},
    ]

    # Mock jedi Script class
    class Script:
        def __init__(self, code, filename):
            self.code = code
            self.filename = filename

    # Mock jedi Interpreter class

# Generated at 2022-06-12 12:52:59.718793
# Unit test for function get_definitions
def test_get_definitions():
    if get_definitions("x", 0, 0, "") == get_definitions("print", 0, 0, ""):
        raise Exception(
            "Please overwrite this function in jediutils.py with correct implementation"
        )

# Generated at 2022-06-12 12:53:09.121585
# Unit test for function get_definitions
def test_get_definitions():
    # jedi before 0.18
    src = "import sys\n\nsys"
    result = get_definitions(src, 3, 4, "testfile")
    assert len(result) == 1
    assert result[0].name == "sys"
    assert result[0].full_name == "sys"
    assert result[0].module_name == "sys"
    assert result[0].type == "module"

    # jedi from 0.18
    src = "import sys\n\nsys"
    result = get_definitions(src, 3, 4, "testfile")
    assert len(result) == 1
    assert result[0].name == "sys"
    assert result[0].full_name == "sys"
    # assert result[0].module_name == "sys" # module_name is not there

# Generated at 2022-06-12 12:54:04.247622
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_script_completions("from tkinter", 0, 0)