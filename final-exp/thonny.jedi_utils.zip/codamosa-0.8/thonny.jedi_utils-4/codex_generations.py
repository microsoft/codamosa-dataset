

# Generated at 2022-06-12 12:44:24.456536
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:44:28.586486
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("te\n", 1, 2, "")
    assert len(completions) > 0
    assert all(completion.name == "test()" for completion in completions)



# Generated at 2022-06-12 12:44:35.480269
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "impo"
    script = jedi.Script(source, 0, 0)
    # expexted result of completion
    results = [('import', 'import', 'statement', 'import ...'), ('importlib', 'importlib', 'module', '')]
    completions = script.completions()
    for c, r in zip(completions, results):
        assert (c.name, c.complete, c.type, c.description) == r



# Generated at 2022-06-12 12:44:38.933266
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("""\
a=1
b=2

import sys
sys.path.append(
""", 3, 15, "test.py"))


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:44:45.948486
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.ast_utils import parse_source

    def get_completions(source, namespaces):
        try:
            return get_interpreter_completions(source, namespaces)
        except Exception as e:
            print(str(e))
            raise e

    def get_completion_names(source, namespaces):
        return [c.name for c in get_completions(source, namespaces)]

    assert "eval" in get_completion_names("eval", [])
    assert "1+1" in get_completion_names("eval('1+1')", [])
    assert "<class 'math.log2'>" in get_completion_names("math.log2", [])

# Generated at 2022-06-12 12:44:53.184345
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "x = foo.bar(foobar)\n"
    namespaces = [{
        '__builtins__': {
            'Bar': 'Bar',
            'Baz': 'Baz',
            'foo': {
                'bar': 'bar',
                'foobar': 'foobar'
            }
        }
    }]
    completions = get_interpreter_completions(source, namespaces)
    assert [c.name for c in completions] == ["Bar", "Baz", "bar", "foobar"]

# Generated at 2022-06-12 12:44:54.204873
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:45:04.597620
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert all(
        get_interpreter_completions("prin", namespaces=[])[0]["name"] == "print"
    ), "not imported"
    assert all(
        get_interpreter_completions("from math import sin", namespaces=[])[0]["name"] == "sin"
    ), "imported"
    assert all(
        get_interpreter_completions("from math import sin", namespaces={"sin": 3})[0]["name"]
        == "sin"
    ), "already in namespace"
    assert all(
        get_interpreter_completions("from math import sin as s", namespaces={"sin": 3})[0][
            "name"
        ]
        == "s"
    ), "already in namespace with alias"



# Generated at 2022-06-12 12:45:08.951115
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    from types import SimpleNamespace

    completions = get_interpreter_completions(
        "import json\njson.l", [{"json": SimpleNamespace(__name__="json", __file__="json.py")}]
    )
    assert "loads" in [c.name for c in completions]
    assert "dumps" in [c.name for c in completions]



# Generated at 2022-06-12 12:45:12.572951
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from tkinter import *\n"
    i = get_interpreter_completions(source, [])
    assert len(i) > 0
    for c in i:
        assert c.name.startswith("Tk")



# Generated at 2022-06-12 12:45:32.192243
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Ensure that the completions works as expected.
    """
    from unittest import TestCase

    # Given
    source = """
    a = 10
    b = 10
    c = 10

    def f(a,b,c):
        a = 1
        b = 2
        c = 3
        return a + b + c

    def g(a,b,c=5):
        return a + b + c
    """
    line = 5
    column = 11
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6/site-packages", "/home/user/mylib"]

    # When
    completions = get_script_completions(source, line, column, filename, sys_path)

    # Then

# Generated at 2022-06-12 12:45:37.591868
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        print("testing get_interpreter_completions: old Jedi version")
        sys_path = ["/test/test_path"]
        namespaces = [{"a": 1, "b": 2, "c": {"d": {"e": 10}}}]
        source = "c.d"

        completions = get_interpreter_completions(source, namespaces, sys_path=sys_path)
        assert len(completions) == 1
        assert completions[0].complete == "c.d"
    else:
        print("testing get_interpreter_completions: new Jedi version")
        sys_

# Generated at 2022-06-12 12:45:50.467420
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    from unittest.mock import MagicMock

    class Test(unittest.TestCase):
        def test_get_definitions_for_dict(self):
            source = """
try:    
    import numpy as np
except:
    import numpy
            
res1 = numpy.array([])
res2 = numpy.array([], dtype=numpy.float64)
res3 = np.array([], dtype=np.float64)
"""
            line = 10
            column = 14

            defs = get_definitions(source, line, column, "")
            self.assertEqual(2, len(defs))
            first_def = defs[0]
            self.assertEqual("try", first_def.name)


# Generated at 2022-06-12 12:45:54.793670
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # on jedi 0.15.1 get_interpreter_completions raises exception
    completions = get_interpreter_completions("import os",[],"")
    assert completions[0].type == "module"
    assert completions[0].name == "os"
    assert completions[0].description == "os module"
    
    

# Generated at 2022-06-12 12:46:06.641193
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.micropython.plugin import MicroPythonProxy

    # todo: update test code to take into account that the commit causing the change of
    #       return value of get_script_completions was reverted
    #       https://github.com/davidhalter/jedi/commit/9f3a2f93c48eda24e2dcc25e54eb7cc10aa73848
    #       https://github.com/davidhalter/jedi/commit/6180eef6d5f6fc68b5cfa076e9d6c5e8aca3e1c2
    completions = get_script_completions("v", 1, 2, "")

# Generated at 2022-06-12 12:46:17.292475
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.ast_utils import get_fake_completion_data
    from thonny.jedi_utils import get_script_completions

    test_data = get_fake_completion_data()
    print(test_data)
    for i in range(len(test_data)):
        # expected, code, pos in the code
        got = get_script_completions(
            test_data[i][1], test_data[i][2][0], test_data[i][2][1]
        )
        expected = test_data[i][0]
        print ("Got:")
        print (got)
        print ("Expected:")
        print (expected)
        assert (got == expected), "completions differ from expected"



# Generated at 2022-06-12 12:46:28.907549
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    def _get_names(defs):
        return [d.name for d in defs]

    jedi_version = jedi.__version__
    print("Testing get_definitions() with {}".format(jedi_version))

    source1 = """
        class K():
            def __init__(self, a):
                self.f = a
        k = K('asdf')
        b = k.f
        b = k.f
        """
    jedi_defs = get_definitions(source1, row=9, column=8, filename="xxx")
    assert len(jedi_defs) == 3
    assert _get_names(jedi_defs) == ['__init__', 'f', 'f']


# Generated at 2022-06-12 12:46:37.983481
# Unit test for function get_script_completions
def test_get_script_completions():
    # 1.
    res = get_script_completions("\nprint('haha')\n", 1, 0, "abc.py")
    assert res[0]["name"] in ["print", "open"]

    # 2.
    res = get_script_completions("print(", 0, 6, "abc.py")
    assert res[0]["name"] == "print"

    # 3.
    res = get_script_completions("\"\"\"\ntest\n\"\"\"", 1, 0, "abc.py")
    assert len(res) == 0


# Generated at 2022-06-12 12:46:47.607522
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.api.interpreter import Interpreter
    import os
    import sys

    source = "import datetime\ndatetime.datetime"
    sys_path = [os.path.join(sys.executable, "Lib", "datetime.py")]

    # Check that older jedi versions are handled correctly
    interpreter = Interpreter(source, sys_path)
    completions = get_interpreter_completions(source, interpreter.namespaces, sys_path)
    assert completions[0].name == "datetime"
    assert completions[1].name == "datetime"
    assert completions[0].complete == "datetime"
    assert completions[1].complete == "datetime."

    # Check that newer and current jedi versions are handled correctly

# Generated at 2022-06-12 12:46:52.299392
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from thonny.jedi_utils import get_script_completions

    def tc(source, row, column, filename, sys_path=None):
        """Compare results"""
        old_result = Script(source, row, column, filename, sys_path=sys_path).completions()
        new_result = get_script_completions(source, row, column, filename, sys_path=sys_path)
        assert len(old_result) == len(new_result)

        for old_comp in old_result:
            names = [c.name for c in new_result]
            assert old_comp.name in names
            if old_comp.name == "__name__":
                continue

# Generated at 2022-06-12 12:47:04.705246
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = 'import re; re.s'
    namespaces = [{'re': re}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == 'sub'
    assert completions[0].complete == 'sub'
    assert completions[0].description == 'sub(...)'

# Generated at 2022-06-12 12:47:12.057896
# Unit test for function get_script_completions
def test_get_script_completions():
    # For some reason, jedi 0.15 suggests "False" only once
    assert get_script_completions(
        "if Fa\n", 0, 3, "<stdin>", sys_path=[__file__]
    ) == [
        ThonnyCompletion(
            name="False",
            complete="False",
            type="keyword",
            description="False",
            parent=None,
            full_name="False",
        )
    ]
    #     ThonnyCompletion(
    #         name="FastNode",
    #         complete="FastNode",
    #         type="class",
    #         description="",
    #         parent=None,
    #         full_name="ast.FastNode",
    #     )
    # ]

    # # For some reason jedi 0.14 and 0.

# Generated at 2022-06-12 12:47:17.386983
# Unit test for function get_definitions
def test_get_definitions():
    source = """
import math as m
print(m.sqrt(3))
    """
    result = get_definitions(source, 0, 0, "")
    assert len(result) == 2
    assert result[0].desc_with_module == "def sqrt(x: int) -> float"
    assert result[1].desc_with_module == "def sqrt(x: float) -> float"

# Generated at 2022-06-12 12:47:25.471345
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module

    source = """
import parso
node = parso.parse("x = 1")
"""

    tree = parse_source(source)
    module = tree.get_first_leaf()
    node = get_statement_of_position(module, source.index("parse") - 1)
    assert isinstance(node, Module)
    defs = get_definitions(source, row=2, column=8, filename="")
    assert len(defs) == 1
    assert defs[0].full_name == "parso.parse"
    assert defs[0].module_name == "parso"



# Generated at 2022-06-12 12:47:35.588270
# Unit test for function get_definitions
def test_get_definitions():
    # If there is no unit test for get_definitions, then why is this function here?
    # This function is a copy of def _copy_of_get_statement_of_position(node, pos)
    # But this is not the best place for it.
    from parso.python import tree

    # FIXME: move this function to a better place

    # https://github.com/davidhalter/jedi/commit/9f3a2f93c48eda24e2dcc25e54eb7cc10aa73848

# Generated at 2022-06-12 12:47:40.203265
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Script
    from jedi.parser.python import parse
    from jedi.evaluate import Interpreter

    # Jedi changed its API some time before 0.17
    source = "import os\nos.pa"
    row = 1
    column = len(source)
    namespaces = [parse(source).get_root_node()]

    # Get completions without sys_path
    completions = get_interpreter_completions(source, namespaces)

    # Get completions with sys_path
    completions_with_syspath = get_interpreter_completions(source, namespaces, sys_path=["."])


# Generated at 2022-06-12 12:47:50.228619
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock
    import jedi

    class Completion(object):
        def __init__(self, name, parent):
            self.name = name
            self.parent = parent
            self.complete = name
            self.type = "function"
            self.description = ""
            self.full_name = ""

    # Up to jedi 0.17
    if hasattr(jedi, "_get_prefix_for_completion"):
        class Interpreter(object):
            def __init__(self, source, namespaces):
                pass

            def completions(self):
                mock_fun = MagicMock()
                mock_fun.name = "mock_fun"
                mock_fun.parent = "mock_mod"

# Generated at 2022-06-12 12:47:52.675718
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert get_interpreter_completions("se", [], []) == _tweak_completions(jedi.Interpreter("se").complete())


# Generated at 2022-06-12 12:47:55.120235
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_interpreter import test_namespace

    get_interpreter_completions("1", [test_namespace], sys_path=["."])


# Generated at 2022-06-12 12:48:00.934368
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Script
    source = "import random; random.random(5.)"
    row = 1
    column = len(source) + 1
    namespaces = Script(source, row, column).goto_assignments()
    completions = get_interpreter_completions(source, namespaces)
    assert "ran" in [c.name for c in completions]

# Generated at 2022-06-12 12:48:12.893973
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    s = """import sys; x = sys.modules["os"].path"""
    
    # Check that get_interpreter_completions() returns anything
    # This test might fail when os.path changes in CPython
    # It may also fail because of performance - in which case we'll need to change 
    # the test.
    assert len(get_interpreter_completions(s, [])) > 100

# Generated at 2022-06-12 12:48:22.688938
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"foobar": [0, 0, 0]}]
    assert get_interpreter_completions("foobar", namespaces)
    assert not get_interpreter_completions("foobar", [])

    assert not get_interpreter_completions("foobar", namespaces)
    assert get_interpreter_completions("foobar", namespaces)
    assert get_interpreter_completions("foobar", [], sys_path=["/foobar"])
    if _using_older_jedi(jedi):
        assert get_interpreter_completions("foobar", [{"barfoo": [0, 0, 0]}], sys_path=["/foobar"])
        # if given sys_path doesn't exist jedi_lib.Interpreter

# Generated at 2022-06-12 12:48:29.492677
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Module
    source = 'import sys; a = sys.path'
    row = 0
    column = 3
    filename = "test"
    script = jedi.Script(source, row, column, filename)
    path_def = script.goto_definitions()[0]
    assert isinstance(path_def, Module)
    assert path_def.__name__ == 'sys'

# Generated at 2022-06-12 12:48:30.737135
# Unit test for function get_script_completions
def test_get_script_completions():
    import inspect
    import jedi

# Generated at 2022-06-12 12:48:34.634015
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import", 0, 6, "")[0].name == "sys"
    assert len(get_script_completions("foo = 12\nimport", 1, 6, "")[0].name) > 0



# Generated at 2022-06-12 12:48:44.630700
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    from unittest.mock import patch

    class Test(TestCase):
        @patch("thonny.jediutils.jedi")
        def test(self, jedi):
            jedi.Interpreter = lambda source, namespaces, module=None, sys_path=None: None

            source = "import math\nm"
            get_interpreter_completions(source, [], [])
            self.assertEqual(jedi.Interpreter.call_args[0][0], source)
            self.assertEqual(jedi.Interpreter.call_args[0][1], [])

            source = "import math\nm"
            get_interpreter_completions(source, [], ["test"])

# Generated at 2022-06-12 12:48:51.635626
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser.python import parse
    from jedi.parser_utils import get_statement_of_position, load_grammar, clean_scope
    from parso.python.tree import search_ancestor, Leaf
    from parso.python import tree
    import parso
    import jedi
    import sys
    import os

    def get_namespace_type(grammar, namespace, pos):
        if isinstance(namespace, tree.ExprStmt):
            expr = namespace[1][0]
            return(expr.value.name.value)
        else:
            return(namespace.value.name.value)


# Generated at 2022-06-12 12:49:00.516049
# Unit test for function get_script_completions
def test_get_script_completions():
    import os

    import jedi.api

    test_data_dir = os.path.join(os.path.dirname(__file__), "jedi_test_data")
    source = open(os.path.join(test_data_dir, "sys_path_completion.py"), "r", encoding="utf-8").read()
    completions = get_script_completions(source, 2, 0, os.path.join(test_data_dir, "test.py"), sys_path=[test_data_dir])
    assert len(completions) == 1
    assert completions[0].full_name == "sys"

# Generated at 2022-06-12 12:49:03.886300
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.languages.utils import get_definitions

    defs = get_definitions("1+1", 0, 2, "<input>")
    assert defs[0].description == "int"
    assert defs[0].in_builtin_module()



# Generated at 2022-06-12 12:49:11.783996
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:49:29.686609
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import os

os.
    """

# Generated at 2022-06-12 12:49:39.356951
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.languages import helpers
    source = """

import os
os.

"""
    row=4
    column=5
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)

    #result should be an array of DefinitionType
    assert isinstance(definitions, list)

    # The module os should be returned
    assert "os" == definitions[0].full_name
    assert 1 == len(definitions)

    # For Python 3.7, there is also "posix"
    if helpers.get_python_version_tuple() >= (3, 7):
        assert "posix" == definitions[1].full_name
        assert 2 == len(definitions)

# Generated at 2022-06-12 12:49:41.805167
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("impo", 1, 5, "test.py")[0].name == "re"


# Generated at 2022-06-12 12:49:44.763154
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    print("jedi version", jedi.__version__)
    if _using_older_jedi(jedi):
        print("using older jedi")
    else:
        print("using newer jedi")


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:49:51.130140
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi

    class Test(unittest.TestCase):
        def test_simple_input(self):
            namespace = get_interpreter_completions(
                """def f():
            pass
            """, [{"f" : f}]
            )
            assert len(namespace) == 1
            assert namespace[0].name == "f"


# Generated at 2022-06-12 12:50:00.162769
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    with open("../test_data/completion/interpreter_completions.txt") as fp:
        lines = []
        for line in fp:
            lines.append(line.rstrip())


# Generated at 2022-06-12 12:50:08.063204
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import datetime
datetime.datetime(
    """
    completions = get_interpreter_completions(source, sys_path=[])
    assert len(completions) == 39  # there is "year" in output
    assert completions[0]["name"] == "year"
    assert completions[0]["description"].startswith("year(${1:int=")
    assert completions[0]["description"].endswith("})\nA 4-digit year.")
    assert completions[0]["complete"] == "year="
    assert completions[0]["type"] == "param"
    assert completions[0]["parent"].startswith("class datetime.datetime(builtins.object)")

# Generated at 2022-06-12 12:50:16.231997
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:50:26.138911
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test function for jedi version 0.17 or earlier
    if _using_older_jedi(jedi):
        l = get_script_completions(
            "import sys\nprint(sys.path", 12, 12, "", ["/fake_sys_path"]
        )
        assert len(l) == 1, l[0].name
        assert l[0].name == "path"
    # Test function for jedi version 0.18 or after
    else:
        l = get_script_completions(
            "import sys\nprint(sys.path", 12, 12, "", ["/fake_sys_path"]
        )
        assert len(l) == 1, l[0].name
        assert l[0].name == "path"



# Generated at 2022-06-12 12:50:34.839832
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_str = """
    class ImprovedInheritor(object):
        def __init__(self, name):
            self.name = name

    obj = ImprovedInheritor("Tom")
    """
    namespaces = [{"tom": 1}, {"obj": obj}]

    completions = get_interpreter_completions(test_str, [1, 3], namespaces)
    assert ['tom'] == [completion.name for completion in completions]

    completions = get_interpreter_completions(test_str, [1, 6, 2], namespaces)

# Generated at 2022-06-12 12:50:52.359010
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completion_names = [c.name for c in get_interpreter_completions("", [])]
    assert "print" in completion_names

# Generated at 2022-06-12 12:51:01.389903
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    from unittest.mock import MagicMock, patch
    from jedi import Script

    class FakeCompletion:

        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    # patch method
    def _fake_tweak_completions(completions):
        return completions

    with patch("thonny.globals.JediUtils._tweak_completions", _fake_tweak_completions):

        jedi_utils = JediUtils()

        # patch method

# Generated at 2022-06-12 12:51:11.474923
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree
    from parso.python.tree import Leaf
    from parso.python.token import Token

    def get_completions(code, row, column, namespaces):
        return get_interpreter_completions(
            source=code, row=row, column=column, namespaces=namespaces
        )
    assert len(get_completions("import s", 0, 8, [])) > 0

    # Issue #5
    ast = parse_source("""import math\nmath.exp""")
    node = get_statement_of_position(ast, (2, 9))
    assert isinstance(node, tree.Import)

    node = get_statement_of_position(ast, (2, 10))

# Generated at 2022-06-12 12:51:19.536988
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = get_script_completions("i", 0, 1, "test.py")
    assert len(script) == 1, "i gives us __init__"

    script = get_script_completions("im", 0, 2, "test.py")
    assert len(script) == 1, "im gives us imp"

    script = get_script_completions("imp", 0, 3, "test.py")
    assert len(script) == 1, "imp gives us import"

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        script = get_script_completions("imp.", 0, 4, "test.py")

# Generated at 2022-06-12 12:51:23.171753
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        source="from math import asinh", row=0, column=16, filename="dummy.py"
    )
    assert len(completions) == 79
    assert [x["name"] for x in completions] == ["asinh"]



# Generated at 2022-06-12 12:51:32.224784
# Unit test for function get_script_completions
def test_get_script_completions():
    jedi = __import__("jedi", fromlist=[])
    if _using_older_jedi(jedi):
        from jedi import Script
        from jedi.api.classes import Completion

        def get_completions(code, pos):
            script = Script(code, pos[0], pos[1], "test")
            return script.completions()

    else:
        from jedi import Script, completion

        def get_completions(code, pos):
            script = Script(code=code, path="test")
            return script.complete(line=pos[0], column=pos[1])

    completions = get_completions("open('', 'w').write('H')", [0, 10])
    assert completions[0].name == "name"

# Generated at 2022-06-12 12:51:41.726216
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import random
    import string
    import tempfile

    iface = globals()

    namespaces = [
        {
            "name": "".join(random.choice(string.ascii_letters) for _ in range(10)),
            "type": "".join(random.choice(string.ascii_letters) for _ in range(10)),
            "doc": "".join(random.choice(string.ascii_letters) for _ in range(10)),
        }
        for _ in range(10)
    ]

    with tempfile.TemporaryDirectory() as tempdir:
        iface["sys"] = [tempdir]
        iface["test"] = sys


# Generated at 2022-06-12 12:51:46.271120
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    sys.path.append("../")
    import unittest
    from thonny.globals import get_workbench

    test_file_path = get_workbench().get_local_cwd() + '/test_get_definitions.py'


# Generated at 2022-06-12 12:51:50.546464
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    from _jedi_utils import get_definitions

    completions = get_definitions(  # noqa
        "import math\nmath.sqrt", 1, 4, "dummy.py"
    )
    assert len(completions) == 1
    assert completions[0].description == "Builtin function"

# Generated at 2022-06-12 12:52:00.366635
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    from unittest.mock import Mock, patch
    from thonny.plugins.jedi_completion import get_definitions, jedi
    from unittest import mock

    def _mock_class_definition(name, file_name):
        class_def = Mock()
        class_def.name = name
        class_def.file_name = file_name
        class_def.line = 1
        class_def.column = 1
        class_def.docstring = "Class {} definition".format(name)
        return class_def

    def _mock_func_definition(name, file_name):
        func_def = Mock()
        func_def.name = name
        func_def.file_name = file_name
        func_def.line = 1

# Generated at 2022-06-12 12:52:24.117621
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """from os import *
from pathlib import *
from math import *"""

    # check if all imports are included
    import_completions = get_interpreter_completions(source, namespaces=[{}])
    assert len(import_completions) == 16, "There should be 16 imports"
    assert (
        len(
            [
                1
                for completion in import_completions
                if completion["name"] == "Path" and completion["parent"] == "pathlib"
            ]
        )
        == 1
    ), "Path object not imported from pathlib"

    # check if namespace filtering works
    namespace_completions = get_interpreter_completions(source, namespaces=[{"a": 1, "b": 2}])
    assert len(namespace_completions) == 2

# Generated at 2022-06-12 12:52:33.640583
# Unit test for function get_script_completions
def test_get_script_completions():
    # Check that module completion works for two cases, for simple and for relative import
    # module name
    import jedi

    from thonny import get_runner
    from test.test_jedi import sample_code_1, sample_code_2

    if _using_older_jedi(jedi):
        expected_results_1 = [ThonnyCompletion(*x) for x in [
            ('datetime.datetime', 'datetime.datetime', 'class', 'datetime.datetime', 'datetime', 'datetime.datetime'),
            ('datetime', 'datetime', 'module', 'Fast implementation of the datetime type', 'jedi', 'datetime')
        ]]

# Generated at 2022-06-12 12:52:43.175537
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    def assert_complete_equal(left, right):
        assert left.name == right.name
        assert left.complete == right.complete
        assert left.type == right.type

    try:
        from jedi.api import Script

        assert_complete_equal(
            get_script_completions("pri", 0, 3, "test_file")[0],
            ThonnyCompletion("print", "print", "statement", None, None, None),
        )
    except ImportError:
        pass


# Generated at 2022-06-12 12:52:48.927285
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "froz"
    # source = "froz = 'froz'"
    # source = "froz = 'froz'\nimpor"
    # source = "froz = 'froz'\nimpor sys"

    completions = get_script_completions(source, 0, len(source), "<string>")
    print(completions)


# Generated at 2022-06-12 12:52:57.842862
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock

    def check_definitions(source, expected_definitions, expected_process_calls):
        import subprocess

        with unittest.mock.patch("subprocess.Popen") as popen_mock:
            process_mock = unittest.mock.Mock()
            process_mock.stdout = unittest.mock.Mock()
            process_mock.stdout.readlines.return_value = [
                "! '" + d + "'" for d in expected_definitions
            ]
            popen_mock.return_value = process_mock

            def side_effect(*args, **kwargs):
                process_mock.communicate.side_effect = subprocess.TimeoutExpired(
                    cmd="", timeout=0
                )

           

# Generated at 2022-06-12 12:53:05.485484
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from collections import Counter"
    filename = "<test_filename>"
    completions = get_script_completions(source, 1, 8, filename)
    assert completions == [
        ThonnyCompletion(
            name="collections",
            complete="collections",
            type="module",
            description="collections - Container datatypes",
            parent="",
            full_name="collections",
        ),
        ThonnyCompletion(
            name="Counter",
            complete="Counter",
            type="classobj",
            description="class Counter(dict)",
            parent="collections",
            full_name="collections.Counter",
        ),
    ]



# Generated at 2022-06-12 12:53:10.880585
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    import jedi

    # Before jedi 0.17, Interpreter had a bug that caused it to mismatch
    # the number of completions with the number of `namespaces`.
    # In this case, it should have returned 6 completions and 5 namespaces,
    # but would return 5 completions and 4 namespaces.
    # Additionally, in jedi 0.16, the `type` attribute is not available.


# Generated at 2022-06-12 12:53:18.867957
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            completions = get_script_completions('def my_func():\n    f=open("test.txt")', 1, 5, None)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "open=")
            self.assertEqual(completions[0].complete, "open(file, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None)")
            self.assertEqual(completions[0].type, "function")

# Generated at 2022-06-12 12:53:28.943955
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase, main


# Generated at 2022-06-12 12:53:31.285362
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("import logging; logging", [])
    assert {c.complete for c in completions} == {"logging.basicConfig", "logging.CRITICAL"}

# Generated at 2022-06-12 12:53:57.608991
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(
        get_script_completions(
            "print(", 0, 6, "", ["/home/thonny/lib/python3.5/site-packages"]
        )
    ) > 0
    assert len(
        get_script_completions(
            "import os\nos.rem", 2, 10, "", ["/home/thonny/lib/python3.5/site-packages"]
        )
    ) > 0

# Generated at 2022-06-12 12:54:06.398354
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock

    fake_completion = MagicMock(
        name="fake_completion",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    def _tweak_completions(completions):
        return [fake_completion]

    old_tweak_completions = _tweak_completions
    _tweak_completions = _tweak_completions
    result = get_script_completions("bla bla", 2, 10, "fake.py")
    assert result == [fake_completion]
    _tweak_completions = old_tweak_completions

# Generated at 2022-06-12 12:54:13.622777
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi_utils
    import jedi

    def _create_source(text: str):
        source = jedi.Script("import py", 1, 1, "sample.py").source
        source += "\n" + text
        return source

    def _assert_completions(
        source: str,
        completion_sources: List[str],
        completion_names: List[str] = None,
        row: int = 1,
        col: int = 8,
    ):
        script_completions = jedi_utils.get_script_completions(source, row, col, "sample.py")
        completion_names = completion_names or []
        if completion_names:
            assert completion_sources == [c.complete for c in script_completions]
        else:
            assert completion_sources