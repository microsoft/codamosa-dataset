

# Generated at 2022-06-12 12:44:16.261282
# Unit test for function get_definitions

# Generated at 2022-06-12 12:44:19.642665
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    >>> new_version = get_script_completions('print', 0, 5, '<test>')[0].name
    >>> old_version = get_script_completions('print', 0, 5, '<test>')[0].complete
    >>> assert new_version == old_version
    """
    pass

# Generated at 2022-06-12 12:44:30.853096
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_completions, get_interpreter_completions

    import os
    import sys
    import jedi

    if _using_older_jedi(jedi):
        sys.path.append("test")
    else:
        sys.path.append("test/test_pypi_jedi_project")
    import test_module_jedi_complete

    def check_completions(source, row, column, expected):
        completions = get_completions(source, row, column, "untitled")
        completions_dict = {item.complete: item.name for item in completions}
        print(source, row, column, completions_dict)
        for key, value in expected.items():
            assert key in completions_dict

# Generated at 2022-06-12 12:44:40.329912
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import unittest

    class TestJediUtils(unittest.TestCase):
        def test_get_interpreter_completions(self):
            interpreter = Interpreter("import os", [{"os": os}])
            completions = get_interpreter_completions("import os", [{"os": os}])
            for comp in completions:
                self.assertIsInstance(comp, ThonnyCompletion)
                self.assertIn(comp.name, dir(os))
                self.assertIn(comp.complete, dir(os))
                self.assertEqual(comp.type, interpreter.completions()[0].type)

    unittest.main(verbosity=2)

# Generated at 2022-06-12 12:44:48.495152
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\nimport asdf\nsys.path.append('')"
    expected = [
        ThonnyCompletion(name="append", complete="append", type="function", description="append(object, /)"),
        # Does not work when ran by itself, but works in real editor
        ## ThonnyCompletion(name="pop",  complete="pop", type="function", description="pop(${1:index=-1})"),
        ThonnyCompletion(
            name="insert", complete="insert", type="function", description="insert(${1:index}, ${2:object})",
        ),
    ]
    assert get_script_completions(source, 2, 7, "test.py") == expected



# Generated at 2022-06-12 12:44:58.989499
# Unit test for function get_definitions
def test_get_definitions():
    import re

    def get_definition_position(definition):
        return (definition.line, definition.column)

    assert get_definition_position(get_definitions("foo = None", 0, 4, "")[0]) == (0, 4)
    assert get_definition_position(get_definitions("foo.bar", 0, 7, "")[0]) == (0, 4)
    assert get_definition_position(get_definitions("foo.bar", 0, 0, "")[0]) == (0, 4)
    assert get_definition_position(get_definitions("foo.bar", 0, 1, "")[0]) == (0, 4)

# Generated at 2022-06-12 12:45:02.869050
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("int", [{}], sys_path=[__file__])) == 0
    assert len(get_interpreter_completions("int.", [{}], sys_path=[__file__])) == 60



# Generated at 2022-06-12 12:45:07.871104
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import sys\nsys."
    namespaces = [{"name": "namespace", "locals": {"sys": "sys"}}]

    completions = get_interpreter_completions(source, namespaces)
    assert completions

    # Prior to jedi 0.16.0, trailing '=' was *not* included in the name of completions
    assert "flags=" in [comp.name for comp in completions]

# Generated at 2022-06-12 12:45:15.698048
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    import jedi
    import textwrap

    # TODO: repeat for all supported jedi versions

    source = textwrap.dedent(
        """
    def foo():
        pass
    def bar():
        pass
    
    """
    )

    completions = get_interpreter_completions(source, [])
    TestCase().assertNotEqual(None, completions)
    TestCase().assertEqual(len(completions), 2)
    TestCase().assertEqual(completions[0].type, "function")
    TestCase().assertEqual(completions[1].type, "function")

# Generated at 2022-06-12 12:45:26.013691
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from parso.python import tree
    from parso.parser import ParserSyntaxError
    from parso.tree import ParentNode

    # test_case = "im"
    # test_case = "0."
    # test_case = "import"
    # test_case = "os."
    # test_case = "import os"
    # test_case = "os.path"
    test_case = "import os\nos.path."
    code_tree = parse_source(source=test_case)
    # print("\n".join("{}:{}".format(x.start_pos[0],x) for x in code_tree.children))

    def is_valid_position(offset):
        # if offset is outisde of code_tree, return False
        return offset >= code_

# Generated at 2022-06-12 12:45:52.972694
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__ as jedi_version
    from jedi.api.classes import Completion
    from jedi.api.helpers import unit

    if jedi_version[:4] == "0.13":
        assert (
            get_script_completions(
                "import datetime",
                row=0,
                column=11,
                filename="test.py",
                sys_path=["/test"],
            )[0].complete == "datetime"
        )
    else:
        assert (
            get_script_completions(
                "import datetime",
                row=0,
                column=11,
                filename="test.py",
                sys_path=["/test"],
            )[0].complete == "datetime."
        )

# Generated at 2022-06-12 12:45:57.962012
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import test; test.__radd__", 0, 20, "test.py")
    assert completions
    assert len(completions) > 0
    # Test for python 3.6 and 3.7
    assert ("__radd__") in [x.name for x in completions]

# Generated at 2022-06-12 12:46:08.770566
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "from unittest import Test"
        namespaces = [{"parent": None, "namespaces": []}]
        result = get_interpreter_completions(source, namespaces)
        assert len(result) == 1
        assert result[0].complete == "Test"
    else:
        source = "from unittest import TestCase"
        namespaces = [{"parent": None, "namespaces": []}]
        result = get_interpreter_completions(source, namespaces)
        assert len(result) == 1
        assert result[0].complete == "TestCase"



# Generated at 2022-06-12 12:46:19.015285
# Unit test for function get_definitions
def test_get_definitions():
    import re
    import jedi
    if _using_older_jedi(jedi):
        print("jedi version < 0.18")
    else:
        print("jedi version >= 0.18")
    source = """
import os
os.path.exists('abc')
"""
    res = get_definitions(source, row=2, column=5, filename="abc.py")
    for i in res:
        print(i.name)
        print(i.module_name)

    with open("jedi_utils.py", 'r') as f:
        lines = f.readlines()
        new_lines = []

# Generated at 2022-06-12 12:46:23.754389
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import collections

import os

os.path.a""".lstrip()

    namespaces = [
        {"collections": collections}
    ]

    completions = get_interpreter_completions(source, namespaces)

    assert completions
    assert completions[0].complete == "os.path.abspath"

# Generated at 2022-06-12 12:46:24.403797
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:46:25.456083
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:46:37.439441
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.representation import InterpreterObject
    from jedi.evaluate.filters import DictFilter

    class DummyCompletion(object):
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    fake_completion1 = DummyCompletion(
        "name1", "complete1", "type1", "description1", "parent1", "full_name1"
    )
    fake_completion2 = DummyCompletion(
        "name2", "complete2", "type2", "description2", "parent2", "full_name2"
    )


# Generated at 2022-06-12 12:46:46.178816
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("a", [], None)[0].name == "abs"
    assert get_interpreter_completions("a", [], None)[0].complete == "abs"
    assert get_interpreter_completions("a", [], None)[0].type == "function"
    assert get_interpreter_completions("a", [{"b": 1}], None)[0].name == "b"
    assert get_interpreter_completions("a", [{"b": 1}], None)[0].complete == "b"
    assert get_interpreter_completions("a", [{"b": 1}], None)[0].type == "statement"



# Generated at 2022-06-12 12:46:51.077726
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "datetime.da"
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)
    for completion in completions:
        if completion.name == "datetime.date":
            return
    raise AssertionError("Function get_interpreter_completions did not return datetime.date as completion")

# Generated at 2022-06-12 12:47:32.205846
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """def function(a, b, c):
    pass
"""
    row = 0
    column = 5
    filename = ""

    completions = get_script_completions(source, row, column, filename)

    assert len(completions) > 0
    assert completions[0].complete == "function("
    assert completions[0].name == "function("

# Generated at 2022-06-12 12:47:37.089619
# Unit test for function get_definitions
def test_get_definitions():
    import parso

    source = 'def f():\n    pass\nf()\n'
    line, column = 3, 1
    got = get_definitions(source, line, column, 'test.py')
    assert len(got) == 1
    assert got[0].type == 'function'
    assert got[0].description == 'def f()'
    assert isinstance(got[0].parent, parso.tree.Function)

    source = 'import math\nm=math.pi\n'
    line, column = 2, 2
    got = get_definitions(source, line, column, 'test.py')
    assert len(got) == 1
    assert got[0].type == 'float'
    assert got[0].description.startswith('float')

# Generated at 2022-06-12 12:47:47.602122
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple
    from jedi.api import Script
    from jedi.api.project import Project
    from jedi import jedi

    class MockScript:
        def __init__(self, source="", line=1, column=1, filename="", project=None):
            self.source = source
            self.line = line
            self.column = column
            self.filename = filename
            self.project = project


# Generated at 2022-06-12 12:47:54.967205
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{
        "a": 1,
        "b": 1.2,
        "c": "c",
        "d": True,
        "e": {
            "f": "f"
        },
        "g": ["h", "i", "j"],
        "k": [1, 2, 3],
    }]
    source = "a."
    print(get_interpreter_completions(source, namespaces))
    source = "b."
    print(get_interpreter_completions(source, namespaces))
    source = "c."
    print(get_interpreter_completions(source, namespaces))
    source = "d."
    print(get_interpreter_completions(source, namespaces))
    source = "e."

# Generated at 2022-06-12 12:48:04.970999
# Unit test for function get_script_completions
def test_get_script_completions():
    # Run with 0.14
    source = "import random\nimport subprocess\nrandom."
    completions = get_script_completions(source, 3, 10, "test.py")
    assert any(c.name == "random" for c in completions)
    assert any(c.name == "seed" for c in completions)

    # Run with 0.16
    source = "import random\nrandom."
    completions = get_script_completions(source, 2, 10, "test.py")
    assert any(c.name == "random" for c in completions)
    assert any(c.name == "seed" for c in completions)

# Generated at 2022-06-12 12:48:08.543285
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import s\n"

    completions = jedi_utils.get_script_completions(source, 1, 1, "")
    assert "subprocess" in [c["name"] for c in completions]



# Generated at 2022-06-12 12:48:16.159400
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        current_dir = __file__.replace("\\", "/")
        # .replace("/tests/utils.py", "")
        current_dir = current_dir[: current_dir.rindex("/")]
        current_dir = current_dir[: current_dir.rindex("/")]
        current_dir = current_dir[: current_dir.rindex("/")]
        sys_path = [current_dir]
    else:
        sys_path = None

    assert (
        "my_string" in [comp.name for comp in get_interpreter_completions("my_s", [], sys_path)]
    )

# Generated at 2022-06-12 12:48:18.650506
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions('import os', 1, 6, 'test_get_definitions.py')) == 1



# Generated at 2022-06-12 12:48:26.530873
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import jedi

    # some of the tests below may fail, if more than one version of jedi is installed
    test_version = int(jedi.__version__[0])

    def _check(script, completion_text, is_keyword_completion, expected_completion):
        completions = get_script_completions(script, len(script.splitlines()), len(script.splitlines()[-1]), "")

        completion = None
        for c in completions:
            if c.complete == completion_text:
                completion = c
                break

        assert completion is not None

        if is_keyword_completion:
            assert completion.name == "break"
            assert completion.complete == "break"
            assert completion.type == "keyword"
            assert completion.description is not None
           

# Generated at 2022-06-12 12:48:28.777360
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from typing import List
    import jedi

    # given

# Generated at 2022-06-12 12:49:11.789840
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"a": 5}]
    if _using_older_jedi(jedi):
        completions = get_interpreter_completions("a.", namespaces=namespaces)
    else:
        completions = get_interpreter_completions(source="a.", namespaces=namespaces)
    assert len(completions) == 2
    assert any(completion.name == "__abs__" for completion in completions)



# Generated at 2022-06-12 12:49:16.549947
# Unit test for function get_script_completions
def test_get_script_completions():
    res = get_script_completions("""from math import c""", 1, 17, "xx.py")
    assert len(res) == 1
    assert res[0]["name"] == "ceil"


from unittest import main

if __name__ == "__main__":
    main()

# Generated at 2022-06-12 12:49:27.552988
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import parso
    from jedi.common import tree_name_to_context_name

    source = """def f():
    pass

f()
"""
    filename = "whatever.py"
    bpos = source.find("()")
    node = parse_source(source)
    stmt = get_statement_of_position(node, bpos)
    node = stmt.parent
    while node.type not in ["simple_stmt", "funcdef"]:
        node = node.parent
    prefix = stmt.get_first_leaf().value

    completions = get_script_completions(source, stmt.start_pos[0] - 1, stmt.start_pos[1] - 1, filename)


# Generated at 2022-06-12 12:49:38.023178
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os.path
    import sys

    py_path = os.path.dirname(sys.executable)
    sys_path = [py_path, py_path + "/Lib", py_path + "/site-packages"]

    # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
    # since 0.16 it does. Need to ensure similar result for all supported versions.
    if _using_older_jedi(jedi):
        assert(
            get_script_completions(
                "import datetime\ndatetime.date.fromisoformat()",
                1,
                24,
                filename="",
                sys_path=sys_path,
            )[0].name == "date"
        )

# Generated at 2022-06-12 12:49:45.773477
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, main

    class Test(TestCase):
        def runTest(self):
            result = get_interpreter_completions(
                "def a():\n    a.",
                [],
                sys_path=["c:\\tmp"]
            )
            self.assertEqual(result[0].name, "abs")

            result = get_interpreter_completions(
                "a.",
                [{"a":1}],
            )
            self.assertEqual(result[0].name, "a")

    test = Test()
    test.runTest()
    main(verbosity=2)

# Generated at 2022-06-12 12:49:52.465884
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import compiled
    from thonny.misc import Concept
    from thonny.languages import tr
    import ast

    namespace = compiled.create(
        ast.parse("x=5"), "__main__", source="x=5", is_eval=False
    )._namespace
    # method is ast.AST but has __dict__ so ok to be in namespace
    namespace["some_method"] = Concept(tr("method"))
    result = get_interpreter_completions("x.", [namespace])
    assert len(result) == 3

# Generated at 2022-06-12 12:49:54.254090
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module
    

# Generated at 2022-06-12 12:50:02.196685
# Unit test for function get_script_completions
def test_get_script_completions():
    logger.info("Using jedi version: %s", __import__("jedi").__version__)
    # print(get_script_completions("print(r'C:\\', end='')", 0, 12, ""))
    # print(get_script_completions(" a = [1,2,3].co", 0, 13, ""))
    # print(get_script_completions("def f(x: int, y=1):\n    pass\n\nf(", 0, 11, ""))
    # print(get_script_completions("def f(x: int, y=1):\n    pass\n\nf(y=", 0, 12, ""))
    # print(get_script_completions("import sys; sys.stdout.write(b'c%s' %

# Generated at 2022-06-12 12:50:11.692461
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.globals import get_workbench

    get_workbench().subprocess_args_for_debugging.update({"CMD": ["python", "-u"]})
    get_workbench().subprocess_args_for_debugging.update({"CMD": ["python", "-u"]})
    get_workbench().subprocess_args_for_debugging.update({"CMD": ["python", "-u"]})

    # Example from issue #1580
    results = get_interpreter_completions(
        "import pandas\n" + "df = pandas.DataFrame(columns=['a', 'b'])\n" + "df.",
        [],
    )
    names = [result.name for result in results]
    assert "a" in names and "b" in names

   

# Generated at 2022-06-12 12:50:12.305626
# Unit test for function get_definitions

# Generated at 2022-06-12 12:51:39.085148
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import classes
    from _test_helper import _get_script_completions

    def assert_completions(txt, result):
        completions = _get_script_completions(txt)
        assert completions == result

    assert_completions("int(", [classes.Completion("int(", "int", "int() -> integer\nint(x[, base]) -> integer")])
    assert_completions("int", [classes.Completion("int", "int", "class int(object)")])
    assert_completions("int.", [classes.Completion("int.bit_length", "bit_length", "bit_length() -> int")])

# Generated at 2022-06-12 12:51:45.103373
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # GIVEN 
    import jedi

    # WHEN
    completions = get_interpreter_completions("None", [])

    # THEN
    assert len(completions) == 1
    completion = completions[0]
    expected_completion = ThonnyCompletion(
        name="None", complete="None", type="keyword", description="", parent="", full_name=""
    )
    assert completion == expected_completion

    assert completions[0].parent == ""
    assert completions[0].full_name == ""
    assert completions[0].description == ""



# Generated at 2022-06-12 12:51:50.257693
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import set_debug_function
    from thonny import get_workbench

    set_debug_function(get_workbench().log_debug)
    get_definitions("class X: pass\nX", row=2, column=1, filename="a.py")
    get_definitions("class X: pass\nX", row=2, column=2, filename="a.py")



# Generated at 2022-06-12 12:51:59.864584
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Unit tests for function get_interpreter_completions
    from jedi.api import Interpreter

    source = "import math\nmath"
    namespaces = [{"name": "__main__", "path": "", "type": "module"}]
    old_jedi_completions = Interpreter(source, namespaces).completions()
    new_jedi_completions = get_interpreter_completions(source, namespaces)
    assert len(old_jedi_completions) == len(new_jedi_completions)
    assert old_jedi_completions[0].name == new_jedi_completions[0].name
    assert old_jedi_completions[0].complete == new_jedi_completions[0].complete
    assert old

# Generated at 2022-06-12 12:52:09.601420
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser import ParserSyntaxError

    # Prepare jedi
    source = "x = 1"
    namespaces = []
    interpreter = Interpreter(source, namespaces, sys_path=None)
    completions = interpreter.complete()

    # Test function get_interpreter_completions
    returned_c = get_interpreter_completions(source, namespaces)
    assert returned_c == completions

    for c_ret, c_orig in zip(returned_c, completions):
        assert c_ret == c_orig



# Generated at 2022-06-12 12:52:15.793484
# Unit test for function get_definitions
def test_get_definitions():
    source = "import random"
    row = 0  # dummy value
    column = 0  # dummy value
    filename = "/tmp/dummy.py"  # dummy value
    definitions = get_definitions(source, row, column, filename)
    import os
    assert any(d.module_path == os.path.realpath("random.py") for d in definitions)

# Generated at 2022-06-12 12:52:21.206676
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    for jedi_version in ["0.11", "0.13", "0.14", "0.15", "0.16", "0.17", "0.18", "0.20.2"]:
        result = get_interpreter_completions("int", [], [])
        assert result[0].name == "int"
        assert result[0].complete == "int()"
        assert result[0].type == "instance"



# Generated at 2022-06-12 12:52:25.378564
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("print('a' in 'abc')", 1, 0, "")
    assert len(result) == 3
    assert result[0].name == "print" and result[0].type == "statement"
    assert result[1].name == "from" and result[1].type == "keyword"
    assert result[2].name == "import" and result[2].type == "keyword"


# Generated at 2022-06-12 12:52:29.414375
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("", 0, 0, "")) > 200
    assert len(get_script_completions("import \n", 1, 0, "")) > 10
    assert len(get_script_completions("from sys import path\npath.", 2, 5, "")) > 10



# Generated at 2022-06-12 12:52:31.776996
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert get_interpreter_completions("type('abc').", [{}])[0].name == "'abc'.capitalize"
