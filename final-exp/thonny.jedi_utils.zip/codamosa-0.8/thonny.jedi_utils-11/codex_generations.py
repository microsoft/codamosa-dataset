

# Generated at 2022-06-12 12:44:28.537170
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi_version = jedi.__version__[:4]
    if jedi_version not in ("0.13", "0.14", "0.15"):
        return

    from test.jedi_test_case import JediTestCase


# Generated at 2022-06-12 12:44:33.689486
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions(
        "print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'abc.txt'))",
        1,
        15,
        "test.py"
    )[0].full_name == 'os.path.abspath'


test_get_definitions()

# Generated at 2022-06-12 12:44:43.020190
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    from thonny.plugins.jedi_utils import get_interpreter_completions, ThonnyCompletion

    namespaces = [
        # jedi before 0.17
        {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__loader__": None,
            "__spec__": None,
            "__annotations__": {},
            "__builtins__": __builtins__,
            "__file__": "/test/test/test.py",
            "__cached__": None,
        },
        # jedi version 17
        parso.utils.DummyModule("__main__"),
    ]
    source = "while"

# Generated at 2022-06-12 12:44:47.437846
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert get_interpreter_completions("object", [], []) == getattr(
        jedi.Interpreter("object"), "completions"
    )()
    assert get_interpreter_completions("object", "object", []) == getattr(
        jedi.Interpreter("object"), "completions"
    )()

# Generated at 2022-06-12 12:44:57.703015
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Interpreter
    import parso
    from parso.python import tree
    from parso.utils import ParserSyntaxError
    import unittest
    import sys

    if sys.version_info < (3, 6):
        class TestCase(unittest.TestCase): pass
    else:
        class TestCase(unittest.TestCase):
            def assertLess(self, a, b, msg=None):
                self.assertTrue(a < b, msg)
        

    class TestGetDefinitions(TestCase):

        def test_regex(self):
            # jedi issue 1276
            source = "b = re.compile('.*')\n"
            source += "b.match('foo')."

# Generated at 2022-06-12 12:45:02.248175
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import turtle\nturtle.Turtle."
    namespaces = [{"turtle": __import__("turtle")}]
    completions = get_interpreter_completions(source, namespaces)
    assert any("turtle.Turtle.circle(" in comp.complete for comp in completions)

# Generated at 2022-06-12 12:45:10.352645
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os
    import jedi
    from unittest import TestCase

    class ThonnyJediTest(TestCase):
        def setUp(self):
            self.maxDiff = None
            self.script_path = os.path.join(os.path.dirname(__file__), "test")

        def test_completions_1(self):
            source = 'import s'
            row = 1
            column = 9
            filename = os.path.join(self.script_path, 'completions_1.py')
            result = get_script_completions(source, row, column, filename)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].name, 'string')


# Generated at 2022-06-12 12:45:18.092642
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    if _using_older_jedi(Interpreter):
        # check version for older jedi
        namespaces = [{'a': 1}]
        source = 'a'
        interpreter = Interpreter(source, namespaces)
        completions = interpreter.completions()

        assert len(completions) == 1
        assert completions[0].name == 'a'

    else:
        # check version for newer jedi
        namespaces = [{'a': 1}]
        source = 'a'
        interpreter = Interpreter(source, namespaces)
        completions = interpreter.complete()

        assert len(completions) == 1
        assert completions[0].name == 'a'

    # check that completions are tweaked in the end


# Generated at 2022-06-12 12:45:28.446391
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.backends import readline_grammar

    def print_jedi_version():
        print("jedi.__version__=", jedi.__version__)
        print("readline_grammar.VERSION=", readline_grammar.VERSION)

    #
    # Test complete() function
    #
    test_complete_completions()

    #
    # Test Interpreter(source, namespaces, **kwargs)
    #
    interpreter = jedi.Interpreter(source="numpy.zeros(1", namespaces=[], **{})
    completions = interpreter.completions()
    print_jedi_version()
    assert len(completions) == 1
    assert completions[0].complete == "numpy.zeros(1, "

# Generated at 2022-06-12 12:45:34.316999
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("pri", 1, 3, "mymodule.py")
    assert completions == [
        ThonnyCompletion(name="print", complete="print", type="statement", description=None, parent=None, full_name=None),
        ThonnyCompletion(name="private", complete="private", type="statement", description=None, parent=None, full_name=None),
    ]
    assert all([isinstance(c, Completion) for c in completions])

# Generated at 2022-06-12 12:45:53.431393
# Unit test for function get_definitions
def test_get_definitions():
    from dataclasses import dataclass
    from jedi import Interpreter
    import jedi
    import unittest
    import parso

    # jedi>=0.17.0
    def _get_definition_17(namespace: Interpreter, position: Tuple[int, int]) -> Definition:
        s = namespace.source
        script = jedi.Script(code=s, path='', project=_get_new_jedi_project())
        (row, column) = position
        return script.infer(line=row, column=column)

    # jedi <0.17.0
    def _get_definition_16(namespace: Interpreter, position: Tuple[int, int]) -> Definition:
        s = namespace.source

# Generated at 2022-06-12 12:46:05.358308
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:46:05.959580
# Unit test for function get_definitions

# Generated at 2022-06-12 12:46:12.968814
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import inspect
    import jedi


# Generated at 2022-06-12 12:46:21.659549
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi import __version__

    namespaces = [{"name":"str","path":"","type":"type","description":"str(object='') -> str\nstr(bytes_or_buffer[, encoding[, errors]]) -> str"},
                  {"name":"list","path":"","type":"type","description":"list(iterable=(), /)"}]

    source = "x = [1,2,3]"
    row = 1
    column = 2
    filename = "1"
    result = get_interpreter_completions(source,namespaces,filename)
    interpreter = Interpreter(source, namespaces)
    if __version__ < "0.17":
        completions = interpreter.completions()
        assert len(result) == len(completions)

# Generated at 2022-06-12 12:46:25.608961
# Unit test for function get_script_completions
def test_get_script_completions():
    program = 'import os\nos.path.join()'

    print(get_script_completions(program, 1, 13, 'simple_program.py'))


if __name__ == '__main__':
    test_get_script_completions()

# Generated at 2022-06-12 12:46:37.588389
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from jedi import api

    # Before jedi 0.16, this was the relevant code,
    # https://github.com/davidhalter/jedi/commit/750a375f79a9d9baf1075ef7cceb2b1d0f8a2a1a
    namespaces = [Mock(globals={"helpy": Mock()})]
    source = "helpy."
    completions = get_interpreter_completions(source, namespaces)

    namespaces = [Mock(globals={"helpy": Mock(__dict__={"__len__": lambda: 42})})]
    source = "helpy."
    completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-12 12:46:47.160722
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        def _tweak_definition(definition):
            if hasattr(definition, "goto"):
                # older jedi
                return definition.goto()
            else:
                # newer jedi
                return definition

        assert len(_tweak_definition(get_definitions("x=5", 0, 2, "/home/somebody/a.py"))) == 1
        assert len(_tweak_definition(get_definitions("x=5\nx=6", 1, 2, "/home/somebody/a.py"))) > 1
        assert len(_tweak_definition(get_definitions("x=5\nx=6", 0, 0, "/home/somebody/a.py"))) > 1


# Generated at 2022-06-12 12:46:54.792266
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi

    ns = [{
        "a": 1,
        "b": "abc",
        "c": {"foo": []}
    }]

    if not _using_older_jedi(jedi):
        expected = ["a", "b", "c"]
        result = get_interpreter_completions("", ns, [])
        assert set([c.name for c in result]) == set(expected)

        expected = ["foo", "append"]
        result = get_interpreter_completions("c['foo'].appen", ns, [])
        assert set([c.name for c in result]) == set(expected)

    interpreter = Interpreter("", ns)
    expected = ["a", "b", "c"]
    result = get_interpre

# Generated at 2022-06-12 12:46:58.810899
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import matplotlib.pyplot as plt\n"
                                         "plt.figure.add_axes.__\n", 1, 36, "")
    assert len(completions) >= 1
    assert any(c['name'] == '__init__' for c in completions)



# Generated at 2022-06-12 12:47:17.221166
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import sys\nimport os.path\nfrom math import *\n"""
    completions = get_script_completions(source, 1, 4, "", [])
    print(completions)
    assert len(completions) == 3
    assert completions[0].name == "sys"
    assert completions[1].name == "os"
    assert completions[2].name == "math"
    assert completions[0].type == "module"
    assert completions[1].type == "module"
    assert completions[2].type == "module"

    completions = get_script_completions(source, 2, 9, "", [])
    print(completions)
    assert len(completions) == 2
    assert completions[0].name == "path"

# Generated at 2022-06-12 12:47:26.534351
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    from os.path import dirname
    import unittest

    sys.path.append(os.path.join(dirname(__file__), "..", "..", "helpers"))

    import jedi

    class TestJediGetDefinitions(unittest.TestCase):
        def test_no_definitions(self):
            res = get_definitions("f = 101\nf", 1, 4, "test.py")
            self.assertEqual(len(res), 0)

        def test_one_definition(self):
            res = get_definitions("def hello():\n  pass", 1, 1, "test.py")
            self.assertEqual(len(res), 1)
            self.assertEqual(res[0].parent, "<module>")

# Generated at 2022-06-12 12:47:32.805561
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import unittest.mock
    import jedi

    def _get_completions(source: str, namespaces):
        return get_interpreter_completions(source=source, namespaces=namespaces)

    # jedi 0.16
    with unittest.mock.patch("jedi.Script.complete") as mock_complete:
        _get_completions('abc', [{'abc': 1}])
        mock_complete.assert_called_once()
        args, kwargs = mock_complete.call_args
        assert args == ()
        assert kwargs == {}

    # jedi 0.17

# Generated at 2022-06-12 12:47:33.395432
# Unit test for function get_definitions

# Generated at 2022-06-12 12:47:44.296481
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import namedtuple

    DummyType = namedtuple("DummyType", "name docstring bases")
    dt = DummyType(name="Name", docstring="Docstring", bases=(1, 2, 3))

    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions(
            'a = [0, 1, 2]\na[1]',
            [{"type": "literal", "string": "Type", "description": "desc"}],
            sys_path=["/tmp"],
        ) == [ThonnyCompletion(name="Name", complete="Name", type=dt, description="desc", parent=None, full_name="Name")]

# Generated at 2022-06-12 12:47:50.714866
# Unit test for function get_script_completions
def test_get_script_completions():

    # Older versions of jedi need more arguments
    if _using_older_jedi(jedi):
        script = get_script_completions(
            "import sys", 1, 10, "test_script_completions.py", sys_path=["/tmp"]
        )
    else:
        script = get_script_completions("import sys", 1, 10, "test_script_completions.py")

    for completion in script:
        assert completion.name.startswith("sys")



# Generated at 2022-06-12 12:47:58.929538
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_cases = []

    # case 0
    source = """
    class C:
        def method(self, x, y=1):
            print("x is %d and y is %d" % (x,y))
    c = C()
    c.method(10,
    """
    namespaces=[{"c": None}]
    expected_completions = ["y="]
    test_cases.append((source, namespaces, expected_completions))

    # case 1
    source = """
    class C:
        def method(self, x, y=1):
            print("x is %d and y is %d" % (x,y))
    C().metho
    """
    namespaces=[{"C": None}]
    expected_completions = ["method("]
    test_cases

# Generated at 2022-06-12 12:48:10.388209
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    from thonny.common import TESTS_DIR

    class WinError(Exception):
        def __init__(self, message):
            self.message = message

    class VimModule:
        class error:
            pass

    class FakeVimModule:
        class error:
            class VimError(Exception):
                def __init__(self, message):
                    self.message = message

    vim_execs = ["import vim"]
    magic_execs = ["from thonny.shell import EmbeddedConsole"]
    win_execs = [
        "import winerror",
        "import pywintypes",
        "from pywintypes import error as WinError",
    ]

# Generated at 2022-06-12 12:48:14.998263
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    >>> completions = get_script_completions('[1, 2, 3].in', 0, 7, '<stdin>')
    >>> len(completions) > 0
    True
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 12:48:24.413649
# Unit test for function get_definitions
def test_get_definitions():
    """Test a few goto_definitions cases"""

    def test_case(src, pos, expect, err_msg=None):
        # Get all definitions
        got = get_definitions(src, pos[0], pos[1], "")
        # Grab full names
        got = [g.full_name for g in got]
        # Fail if expected full names are not in result
        for g in expect:
            assert g in got, err_msg

    test_case(
        "int",
        (0, 0),
        ["builtins.int"],
        "{int: (0, 0)}, no results found!",
    )

# Generated at 2022-06-12 12:48:43.043033
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import datetime\ndatetime"

    sys_path = ['/usr/lib/python3.8/site-packages']
    completions = get_interpreter_completions(source, [], sys_path)
    assert any([c.complete == "datetime" for c in completions])

    source = "import datetime\ndatetime.time"

    completions = get_interpreter_completions(source, [], sys_path)
    assert any([c.complete == "datetime.time" for c in completions])

    source = "import datetime\ndatetime.time"

    namespace = {'datetime': jedi.Interpreter('datetime', []).names()[0]}

# Generated at 2022-06-12 12:48:50.780570
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import compiled
    from jedi.evaluate.context import ClassContext
    from jedi.evaluate.context import ModuleContext
    from jedi.evaluate.names import Name

    code = "import sys\na = sys.path"
    namespaces = [{"__builtins__": compiled.builtin.builtins}]
    completions = get_interpreter_completions(code, namespaces, ["/"])
    assert len(completions) == 2
    assert completions[0].name == "sys"
    assert completions[0].type == "import"
    assert isinstance(completions[0].parent, ModuleContext)
    assert completions[0].full_name == "sys"

    assert completions[1].name == "a"
    assert completions[1].type == "statement"
   

# Generated at 2022-06-12 12:49:01.497070
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from thonny.jedi_utils import get_interpreter_completions
    from thonny.jedi_utils import ThonnyCompletion

    # test case 1.
    source = "import abc"
    namespaces = [{}]
    interpreter = Interpreter(source, namespaces)
    assert get_interpreter_completions(
        source, namespaces, interpreter.options.sys_path
    ) == _tweak_completions(interpreter.complete())

    # test case 2.
    source = "print(123)"
    namespaces = []
    interpreter = Interpreter(source, namespaces)
    assert get_interpreter_completions(
        source, namespaces, interpreter.options.sys_path
    ) == _tweak_

# Generated at 2022-06-12 12:49:09.420569
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Script

    # Testing with an older version of jedi that doesn't contain support
    # for the 'project' parameter.
    if Script.complete.__code__.co_argcount == 4:
        return
    # Testing with a newer version of jedi (0.16)
    completions = get_interpreter_completions(
        "import math; print(math.pi", [{"math": math}]
    )
    assert completions[0].name == "pi"
    assert completions[0].complete == "pi"
    assert completions[0].type == "statement"
    assert completions[0].description == "Number pi = 3.1415..."
    assert completions[0].parent == "math"
    assert completions[0].full_name == "math.pi"

# Generated at 2022-06-12 12:49:20.534291
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Unit test for function get_script_completions
    """
    import jedi

    if _using_older_jedi(jedi):
        return

    c = get_script_completions("string.lo", 0, 5, "t.py")
    assert len(c) > 0
    assert type(c[0]) is ThonnyCompletion
    assert c[0].name == "lower()"
    assert c[0].complete == "lower()"
    assert c[0].description == "string.lower(s) -> str\n\nReturn a copy of the string s converted to lowercase."

    c = get_script_completions("import string\nstring.lo", 1, 7, "t.py")
    assert len(c) > 0
    assert type(c[0]) is Thon

# Generated at 2022-06-12 12:49:29.651353
# Unit test for function get_definitions
def test_get_definitions():
    # Verifying that get_definitions works with both versions of jedi
    import sys
    import unittest
    from thonny.jedi_utils import get_definitions

    if sys.version_info.major == 2:
        return

    class TestJedi(unittest.TestCase):
        def test_get_definitions(self):
            import logging

            logger = logging.getLogger()
            logger.setLevel("DEBUG")
            logger.addHandler(logging.StreamHandler(sys.stderr))

            # Since the methods of get_definitions is different for both jedi versions
            # the returned results are different:
            print("Getting definitions...")

# Generated at 2022-06-12 12:49:40.589639
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test with non-existing sys_path
    completions = get_script_completions("", 1, 1, "", sys_path=["/tmp/does/not/exist"])
    assert not completions

    # Test with existing sys_path
    code = "import sys\nimport os.path\nos.path.expanduser('')"
    completions = get_script_completions(code, 3, 11, "")
    assert len(completions) == 1
    assert completions[0]["name"] == "expanduser(path)"
    assert completions[0]["type"] == "function"
    assert completions[0]["description"]
    assert "str" in completions[0]["description"]
    assert "Expand paths starting with ~ or ~user" in completions[0]["description"]

# Generated at 2022-06-12 12:49:43.450765
# Unit test for function get_script_completions
def test_get_script_completions():
    assert (
        get_script_completions(
            "print('huhu'", row=0, column=10, filename="/home/koodi.py"
        )[0].name
        == "__name__"
    )

# Generated at 2022-06-12 12:49:50.531295
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if sys.version_info[0] == 2:
        logger.info("Skipping jedi tests for Python 2")
        return

    def call_and_check_result(code, row, column, filename, sys_path=None):
        result = get_script_completions(code, row, column, filename, sys_path)
        result = list(result)
        assert result
        assert all(isinstance(item, ThonnyCompletion) for item in result)
        for item in result:
            assert "name" in item.__dict__
            assert "complete" in item.__dict__
            assert "type" in item.__dict__
            assert "description" in item.__dict__
            assert "parent" in item.__dict__

# Generated at 2022-06-12 12:49:59.990804
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions(
        "import sys\n sys.",
        [{"type": "module", "name": "sys", "is_namespace": True}],
    )


# Generated at 2022-06-12 12:50:22.325333
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from test.test_runner import get_runner
    assert "print" in [c.name for c in get_script_completions("prin", 1, 5, get_runner())]


# Generated at 2022-06-12 12:50:32.205306
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import json; json.'
    assert "loads" in [comp["complete"] for comp in get_interpreter_completions(source, [])]
    source = "import json; json.l"
    assert "loads" in [comp["complete"] for comp in get_interpreter_completions(source, [])]
    source = 'import json; json.dumps("abc").up'
    assert "upper" in [comp["complete"] for comp in get_interpreter_completions(source, [])]
    source = '# my comment\nimport json; json.dumps("abc").up'
    assert "upper" in [comp["complete"] for comp in get_interpreter_completions(source, [])]
    source = 'import json; json.dumps("abc").upper().l'

# Generated at 2022-06-12 12:50:41.999447
# Unit test for function get_script_completions
def test_get_script_completions():
    def test():
        for version in ["0.11", "0.12", "0.13", "0.14", "0.15", "0.16"]:
            jedi.__version__ = version
            completions = get_script_completions("list.app", 1, 5, "temp.py")

            assert len(completions) > 0

            names = [c.name for c in completions]

            assert "append" in names

            append_c = [c for c in completions if c.name == "append"][0]
            assert append_c.complete == "append"
            assert "append" in append_c.description

    import sys
    from types import ModuleType

    from unittest.mock import patch

    backup_jedi = sys.modules.pop("jedi")
    backup_

# Generated at 2022-06-12 12:50:50.716940
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    sys_path = ["/home/myuser/myrepo/myapp"]
    script = _get_script("""
in_sys_path = "yes"
""", row=1, column=0, filename="/home/myuser/myrepo/myapp/my_module.py", sys_path=sys_path)
    completions = script.completions()
    assert completions[0].name == "in_sys_path"
    assert completions[0].parent() is not jedi.api.classes.Module
    assert completions[1].name == "in_sys_path"
    assert completions[1].parent() is jedi.api.classes.Module



# Generated at 2022-06-12 12:50:52.137115
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("pri", 0, 3, ""))



# Generated at 2022-06-12 12:51:01.206631
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions(
        source="str", namespaces=[{}], sys_path=[]) == [
        ThonnyCompletion(name='split', complete='split', type='function', description='str.split(...) method of builtins.str instance\n    S.split(sep=None, maxsplit=-1) -> list of strings\n\n    Return a list of the words in S, using sep as the\n    delimiter string.  If maxsplit is given, at most maxsplit\n    splits are done. If sep is not specified or is None, any\n    whitespace string is a separator and empty strings are\n    removed from the result.', parent='builtins.str', full_name='str.split')]

# Generated at 2022-06-12 12:51:10.269928
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.__version__ = "0.12.2"
    completions = get_script_completions("impor", 0, 0, "")
    assert len(completions) == 1
    assert completions[0].name == "import"
    assert completions[0].description.startswith("import ")

    jedi.__version__ = "0.18.2"
    completions = get_script_completions("impor", 0, 0, "")
    assert len(completions) == 1
    assert completions[0].name == "import"
    assert completions[0].description.startswith("import ")


# Generated at 2022-06-12 12:51:16.624406
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    script = Script("bo", 1, 1)
    sc = get_script_completions("bo", 1, 1, "")
    assert sc == script.completions()
    script = Script("bo", 0, 1)
    sc = get_script_completions("bo", 0, 1, "")
    assert sc == script.completions()
    script = Script("bo", 1, 0)
    sc = get_script_completions("bo", 1, 0, "")
    assert sc == script.completions()
    script = Script("1", 0, 1)
    sc = get_script_completions("1", 0, 1, "")
    assert sc == []



# Generated at 2022-06-12 12:51:25.723535
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions, _using_older_jedi

    import jedi

    source = "import sys\n\nsys."
    namespaces = [{"__builtins__": __builtins__}]
    completions = get_interpreter_completions(source, namespaces)
    assert "sys.argv" in [c.name for c in completions]
    assert "sys.path" in [c.name for c in completions]
    assert "sys.stdout" in [c.name for c in completions]

    if _using_older_jedi(jedi):
        script = jedi.Interpreter(source, namespaces)
        jedi_completions = script.completions()
        assert len(completions) == len

# Generated at 2022-06-12 12:51:34.736917
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    source_code = """
    '''
    This is a multiline comment
    '''
    from math import cos
    class A:
        pass
    a = A()
    """
    #Namespaces is a list of dictionaries
    namespaces = [{'a': a}]

    result = get_interpreter_completions(source_code,namespaces)

    #Interpreter is a jedi class so we can use it for testing
    right_result = Interpreter(source_code,namespaces).completions()
    for i in range(len(result)):
        assert result[i].name == right_result[i].name
        assert result[i].complete == right_result[i].complete
        assert result[i].type == right_result[i].type

# Generated at 2022-06-12 12:52:04.138001
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    logger.debug("test_get_interpreter_completions: IN")
    # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
    # since 0.16 it does. Need to ensure similar result for all supported versions.
    # NB! The order sometimes differs with older versions
    var_completions = get_interpreter_completions(
        "a = 'asdf'\n", [{"x": "xxx"}, {"a": "aaa"}]
    )
    assert var_completions[0].name == "x"
    assert var_completions[1].name == "a"
    assert var_completions[0].complete == "xx"
    assert var_completions[1].complete == "asdf"

    arg_completions = get_inter

# Generated at 2022-06-12 12:52:13.332730
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _tkinter import Tcl

    import jedi
    from jedi.interpreter import Interpreter, names

    if _using_older_jedi(jedi):
        interpreter = Interpreter("import _tkinter; tk = _tkinter.Tcl(); tk.", [], sys_path=None)
        completions = interpreter.completions()
    else:
        interpreter = jedi.Interpreter("import _tkinter; tk = _tkinter.Tcl(); tk.")
        completions = interpreter.complete()

    assert len(completions) == len(dir(Tcl))

# Generated at 2022-06-12 12:52:20.230604
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    if _using_older_jedi(jedi):
        namespaces = [{"my_str": "hello world"}]
        completion = get_interpreter_completions("my_str.upper", namespaces)[0]
        assert completion.full_name == "str.upper"
    else:
        namespaces = [{"my_str": "hello world"}]
        completion = get_interpreter_completions("my_str.upper", namespaces)[0]
        assert completion.full_name == "str.upper"



# Generated at 2022-06-12 12:52:24.308666
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree

    source = '"""Module docstring"""\n\nimport math\n\nclass A(object):\n    "A.__init__ docstring"\n    def __init__(self):\n        pass\n\n    def test_x(self, x):\n        return x\n\n    def test_y(self, y):\n        return y\n\n    def test_z(self, z):\n        return z\n\ny = A()\ny.test_z(y.test_y(math.sin(y.test_x(1.0))))\n'
    node = parse_source(source)
    position = get_statement_of_position(node, node.end_pos - 1).start_pos


# Generated at 2022-06-12 12:52:33.861736
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import jedi
    from thonny.misc import running_on_mac_os
    from thonny.plugins.jedi_helper import _get_plugin_dir

    if _using_older_jedi(jedi):
        sys_path = [os.path.join(_get_plugin_dir(), "test_get_definitions")]
        script = jedi.Script("import my_module", 2, 6, "", sys_path=sys_path)
        result = script.goto_definitions()
    else:
        sys_path = [os.path.join(_get_plugin_dir(), "test_get_definitions")]
        project = jedi.Project(path=sys_path[0], added_sys_path=sys_path)

# Generated at 2022-06-12 12:52:39.830385
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    python_code = "value = 'something'"
    namespace = [{"value": "value"}]
    if _using_older_jedi(getattr(test_get_interpreter_completions, "jedi")):
        assert len(get_interpreter_completions(python_code, namespace)) == 3
    else:
        assert len(get_interpreter_completions(python_code, namespace)) == 2


# Generated at 2022-06-12 12:52:48.776704
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Class, Function, Module
    from jedi.evaluate.compiled import CompiledObject

    def get_module_class_func(source: str):
        # create a mock module
        module = Module("test_module", None)
        module.path = "test_module.py"

        # create a mock class
        cls = Class("TestClass", "None")
        cls.name = "TestClass"
        cls.start_pos = (1, 0)
        cls.end_pos = (2, 0)
        module.children.append(cls)

        # Create a function in the class
        func = Function("test_function", "None")
        func.start_pos = (2, 0)
        func.end_pos = (3, 0)
        cls.children

# Generated at 2022-06-12 12:52:55.065142
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "a = 4\nb = 5\n"
    namespaces = [{"a": 1}, {"b": 2}]

    assert get_interpreter_completions(source, namespaces) == [
        ThonnyCompletion(name="b", complete="b", type="int", description="int", parent=None, full_name="b"),
        ThonnyCompletion(name="a", complete="a", type="int", description="int", parent=None, full_name="a"),
    ]



# Generated at 2022-06-12 12:53:01.361205
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("lst = [2, 3, 4]\nlst.", [], None)

# Generated at 2022-06-12 12:53:10.611519
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from unittest.mock import Mock
    import unittest.mock

    sys_path = ["thonny_root", "thonny_root\\Lib"]
    box = unittest.mock.MagicMock()
    box.__getattribute__.return_value.__dict__ = {}
    boxes = [box, box]
    namespaces = [{"sys": None, "box": box, "boxes": boxes}]
    interpreter = Mock()

    def infer(source, line, column):
        import jedi.evaluation.compiled

        if _using_older_jedi(jedi):
            interpreter.infer.return_value = [
                jedi.api.classes.Class("int", path="thonny_root\\Lib\\abc.py")
            ]

# Generated at 2022-06-12 12:54:00.041677
# Unit test for function get_definitions
def test_get_definitions():
    sys_path = ["/home/user/myproject"]

    source = """
        import numpy
        numpy.
    """
    row = 3
    column = 11

    defns = get_definitions(source, row, column, sys_path)
    assert len(defns) > 0
    assert "numpy" in defns[0].full_name
    assert defns[0].module_path.startswith("/usr/lib/")



# Generated at 2022-06-12 12:54:08.708050
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    response = get_interpreter_completions(source="import time; time.t", namespaces=[{}])
    assert len(response) > 0
    assert response[0].name == "time"
    assert not response[0].complete.endswith("=")

    response = get_interpreter_completions(
        source="def f(x, y, z): pass\nf(", namespaces=[{}]
    )
    assert len(response) == 3
    assert response[0].name == "x="
    assert response[0].complete.endswith("=")

    response = get_interpreter_completions(source="", namespaces=[{}])
    assert len(response) > 0
    assert response[0].name == "time"
    assert not response[0].complete.endsw