

# Generated at 2022-06-12 12:44:33.591557
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi
    class TestInterpreterCompletions(unittest.TestCase):
        def test_get_completions(self):
            completions = get_interpreter_completions("import sys\nsys.\n", [], sys_path=[])
            self.assertEqual(1, len(completions))
            self.assertEqual("path", completions[0].name)
            self.assertEqual("path", completions[0].complete)

    if jedi.__version__[:4] == "0.13":
        # jedi 0.13 has a bug which prevents this test from passing
        # https://github.com/davidhalter/jedi/issues/953
        pass

# Generated at 2022-06-12 12:44:37.309745
# Unit test for function get_script_completions
def test_get_script_completions():
    items = get_script_completions('"hell"', 0, 5, '')
    found = False
    for item in items:
        if item.name == 'upper':
            found = True
            break
    assert found

# Generated at 2022-06-12 12:44:43.051860
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    jedi = __import__("jedi")
    namespaces = [{"x": 1, "y": 2}]
    completions = get_interpreter_completions("x.", namespaces, sys_path=[])
    assert len(completions) == 2
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert completions[0].name == "x"
    else:
        assert completions[0].name == "x="

# Generated at 2022-06-12 12:44:49.761059
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    # get_definitions should not change behavior with this simple test case,
    # but I'm still adding a test case, just to make sure.
    source = "from math import sqrt\nroot = sqrt"
    script = jedi.Script(source, line=1, column=9, path="test.py")
    definitions = script.goto_definitions()
    definition = definitions[0]
    assert str(definition.parent) == "def sqrt(x):"
    assert str(definition.type) == "func"



# Generated at 2022-06-12 12:45:01.785620
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def test(source, row, column, filename, sys_path, expected_names):
        assert expected_names == [
            c.name for c in get_script_completions(source, row, column, filename, sys_path)
        ]

    # https://github.com/thonny/thonny/wiki/Jedi#jediscript-param_source
    test('"".le', 1, 6, "", [], ["len"])
    test("from math import *; pi", 1, 20, "", [], ["pi"])
    test("", 1, 1, "", [], [])

    # https://github.com/thonny/thonny/wiki/Jedi#jediscript-param_path

# Generated at 2022-06-12 12:45:10.030932
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import InternalDictProject
    from jedi.api.classes import Completion
    from jedi.parser.python import tree as pt

    def _get_completion_from_script(source, row, column):
        return get_script_completions(source, row, column, "test.py", sys_path=["C:\\"])

    def _get_completion_from_interpreter(source, row, column, namespaces):
        return get_interpreter_completions(source, namespaces)

    def test_simplest_completion():
        source = "datetime."
        row = 1
        column = 10
        completions = _get_completion_from_script(source, row, column)
        assert len(completions) == 1

# Generated at 2022-06-12 12:45:11.816974
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("", [{}], [])) > 0

# Generated at 2022-06-12 12:45:17.409459
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("import sys", [])
        completions = interpreter.completions()
    else:
        interpreter = jedi.Interpreter("import sys")
        completions = interpreter.complete()

    names = [c.name for c in completions]
    assert "sys.path" in names  # this is fixed as a result of tweaking completions

# Generated at 2022-06-12 12:45:22.576810
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions('x=10', 1, 1, 'my_file.py')
    assert len(result) == 0

    result = get_script_completions('x=10\nx.+1', 2, 2, 'my_file.py')
    assert len(result) == 1
    assert result[0].name == '__add__' and result[0].complete == '__add__'
    assert result[0].type == 'function'
    assert result[0].parent == 'int'
    assert result[0].full_name == 'int.__add__'

    result = get_script_completions('y = {1:10, 2:20}', 0, 0, 'my_file.py')
    assert len(result) == 0

    result = get_script_complet

# Generated at 2022-06-12 12:45:32.441531
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    input_text = "import os; print(os.path."
    jedi_version = jedi.__version__
    if _using_older_jedi(jedi):
        expected = [
            "altsep",
            "curdir",
            "defpath",
            "devnull",
            "extsep",
            "linesep",
            "pardir",
            "pathsep",
            "sep",
        ]

# Generated at 2022-06-12 12:45:52.122454
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import jedi

    # myname = os.path.basename(__file__)
    # mydir = os.path.dirname(__file__)
    mydir = "/home/andri/workspace/thonny/thonny/plugins/thonny-jedi"
    # mydir = os.path.join(os.path.split(mydir)[0], "plugins", "thonny-jedi")
    myname = os.path.join(mydir, "__init__.py")

    # row, column
    cursor = (1, 3)

    content = open(myname, "r").read()


# Generated at 2022-06-12 12:45:59.591952
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    source = """class A:
        pass
    
    a = A()
    
    a.b = 1   # <-- cursor here
    """
    lines = source.split("\n")
    col = lines[-1].index("#")
    result = get_definitions(source, 3, col, "test")
    assert len(result) == 1
    assert jedi.common.property_descriptors.get_docstring(result[0]) == "Class `A` defined at test, 1"

# Generated at 2022-06-12 12:46:05.702047
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_mac_os
    if running_on_mac_os():
        # On OS X (at least on Travis), we have no tcl/tk installed
        # so jedi would fail with "no display name and no $DISPLAY environment variable"
        # Thus I'm skipping this test for the time being
        return


# Generated at 2022-06-12 12:46:16.868406
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from parso.python.tree import ExprStmt
    from parso.python.tree import ImportName
    from parso.python.tree import ImportFrom
    from parso.python.tree import Name

    source_code = """
    import json
    import os
    import re


    def foo(json_path):
        '''Docstring of foo function'''
        json_data = json.loads(open(json_path).read())
        assert isinstance(json_data, dict)
        os.path.join(json_data["app_node_name"], "common")


    if __name__ == "__main__":
        foo("/tmp/jedi_test")
    """

# Generated at 2022-06-12 12:46:20.717744
# Unit test for function get_script_completions
def test_get_script_completions():
    def assertEqual(x, y):
        if x != y:
            raise AssertionError("%s != %s" % (x, y))


# Generated at 2022-06-12 12:46:32.110597
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    import datetime

    # The current version of jedi has a bug and cannot process the module
    # of datetime, so we need to import
    # https://github.com/davidhalter/jedi/issues/1710
    jedi.Interpreter('import datetime', [{'datetime': datetime}])

    result = _tweak_completions(get_interpreter_completions('import datetime; datetime.date', [{'datetime': datetime}]))
    assert isinstance(result, list)
    assert len(result) > 0
    assert isinstance(result[0], ThonnyCompletion)
    assert result[0].complete == 'date'
    assert result[0].name == 'date'



# Generated at 2022-06-12 12:46:42.015934
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    import os
    import sys
    import tempfile

    temp_path = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_path, "x"))
    open(os.path.join(temp_path, "x", "y.py"), "w").write("")

    sys.path.insert(0, temp_path + "/x")

    namespaces = [{"foo": 1}, {"bar": 2}]
    result = get_interpreter_completions("", namespaces=namespaces)
    result_names = set([result[i]["name"] for i in range(len(result))])
    assert result_names == set(["foo", "bar", 0, 1, 2])


# Generated at 2022-06-12 12:46:51.816618
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions("import mypackage, mypackage.subpackage1.subpackage2", [])
    assert len(completions) > 0
    assert "mypackage" in [completion.name for completion in completions]

    source = "input("
    completions = get_interpreter_completions(source, [])
    assert len(completions) > 0
    assert "end=" in [completion.name for completion in completions]

    source = "import re\nre.f"
    completions = get_interpreter_completions(source, [])
    assert len(completions) > 0
    assert "sub" in [completion.name for completion in completions]

    source = "import re\nre.sub(''"
   

# Generated at 2022-06-12 12:47:00.445848
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    from unittest.mock import Mock

    class TestCase(unittest.TestCase):
        def assertCompletionsEqual(self, actual, expected, namespaces=[]):
            for a, e in zip(actual, expected):
                self.assertEqual(a.name, e.name)

    class Test_get_interpreter_completions(TestCase):
        def test_without_namespaces_and_sys_path(self):
            self.assertIn("os", get_interpreter_completions("import os;os.path.c", [], None))
            self.assertIn(
                "os.path",
                get_interpreter_completions("from os import path;path.c", [], None),
            )
            # module members

# Generated at 2022-06-12 12:47:05.359126
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"os": jedi.Interpreter("import os", [], sys_path=["/usr"]).namespace}]
    completions = get_interpreter_completions(
        "from os import ", namespaces=namespaces, sys_path=["/usr"]
    )
    assert completions
    assert "path" in [c.name for c in completions]

# Generated at 2022-06-12 12:47:16.026866
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate.finder import get_definitions
    from parso.python import tree
    from parso import parse


# Generated at 2022-06-12 12:47:16.731098
# Unit test for function get_definitions
def test_get_definitions():
    assert _using_older_jedi() == False


# Generated at 2022-06-12 12:47:26.173943
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    import parso
    import matplotlib

    class TestGetDefinitions(unittest.TestCase):

        def _run_test(self, source, row, column):
            definitions = get_definitions(source, row, column, "")
            return [
                (x.start_pos, x.type, x.full_name, x.line, x.column) for x in definitions
            ]

        def test_no_defs(self):
            source = "42"
            row, column = 0, 1
            result = sorted(self._run_test(source, row, column))
            self.assertEqual(result, [])

        def test_simple_defs(self):
            source = "a = 1\ndef f(): pass\nclass C: pass"


# Generated at 2022-06-12 12:47:36.198746
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter, Script
    import parso

    # The following tests are to make sure that the functionality of thonny.jediutils.get_interpreter_completions
    # is at least as good as of jedi.Interpreter.complete().
    # The tests are done at the same level of inputs that the real function requires.

    # test completions with no namespaces
    # NB! The docstring of Interpreter.complete() is unclear. It says that the namespaces argument should
    # be a list of dictionaries, but actually a single dictionary is enough
    interpreter = Interpreter('import os, sys', namespaces=[])
    _test_completions(interpreter.complete(), ['os.curdir', 'sys.hexversion', 'sys.maxsize', 'sys.maxunicode'])
    interpreter

# Generated at 2022-06-12 12:47:45.187631
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest.mock as mock

    with mock.patch("thonny.jedi_utils.get_interpreter_completions") as mocked_get_interpreter_completions:
        mocked_get_interpreter_completions.return_value = []
        get_interpreter_completions(
            'a = b + 1\nprint(a)',
            [{"b": 1}],
            sys_path=None,
        )
    mocked_get_interpreter_completions.assert_called_with(
        "a = b + 1\nprint(a)", [{"b": 1}], sys_path=None
    )

# Generated at 2022-06-12 12:47:53.471357
# Unit test for function get_definitions
def test_get_definitions(): # noqa

    def assert_equal(a, b): 
        assert a == b, "%s != %s" % (a, b)

    import jedi
    from os.path import dirname, join
    from thonny.plugins.micropython.utils import get_definitions

    script_path = join(dirname(__file__), "test_microbit_utils.py")
    with open(script_path, encoding="utf-8") as script:
        source = script.read()

    result = get_definitions(source, 3, 18, script_path)
    assert_equal(len(result), 1)
    assert_equal(result[0].line, 1)
    assert_equal(result[0].column, 5)

# Generated at 2022-06-12 12:47:56.253823
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import jediutils
    import unittest.mock
    from jedi import api

    with unittest.mock.patch("jedi.api.Script.completions") as mock_completions:
        jediutils.get_script_completions("test_code", 1, 2, "test")
        mock_completions.assert_called_with()

# Generated at 2022-06-12 12:48:07.852967
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    # create a mock jedi.Script object
    comp = Mock()
    comp.name = "comp"
    comp.complete = "comp"
    comp.type = "module"
    comp.description = "comp"
    comp.parent = Mock()
    comp.parent.full_name = ""
    comp.full_name = ""

    comp2 = Mock()
    comp2.name = "comp2"
    comp2.complete = "comp2"
    comp2.type = "module"
    comp2.description = "comp2"
    comp2.parent = Mock()
    comp2.parent.full_name = ""
    comp2.full_name = ""

    script = Mock()
    script.completions = Mock(return_value = [comp, comp2])



# Generated at 2022-06-12 12:48:08.935880
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:48:14.476230
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import sys

    current_dir = os.path.dirname(__file__)
    source = 'import os,sys\nprint(os.path.join(sys.executable, "test", "test"))\n'
    completions = _tweak_completions(
        get_script_completions(source, 2, 27, os.path.join(current_dir, "test.py"))
    )
    assert len(completions) == 1
    assert completions[0].name == "join"

# Generated at 2022-06-12 12:48:30.989469
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("", [])
    assert isinstance(completions, list)
    assert len(completions) > 0
    for c in completions:
        assert isinstance(c, ThonnyCompletion)

# Generated at 2022-06-12 12:48:35.240471
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import os'
    namespaces = [{'__name__': '__main__', 'os': None}]
    completions = get_interpreter_completions(source, namespaces)
    assert 'remove' in [c.name for c in completions]


# Generated at 2022-06-12 12:48:44.202524
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{
        '__builtins__': {},
        'os': {
            'sep': '\\'
        }
    }, {
        '__builtins__': {},
        'os': {
            'sep': '\\'
        }
    }]
    print(get_interpreter_completions("os.sep", namespaces))
    print(get_interpreter_completions("os.sep + os.sep", namespaces))
    print(get_interpreter_completions("os.sep + 'x'", namespaces))

if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:48:49.535202
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi

    class TestGetDefinitions(unittest.TestCase):

        def test_get_definitions(self):

            source = """from math import *
import os
from tkinter import *
from os import name as osname
from tkinter import Frame as TkFrame
from tkinter import Frame

root = Tk()
frame1 = TkFrame(root)
frame2 = Frame(root)

button = Button(frame1, text="OK")
label = Label(frame1, text="Hello")
myLabel = Label(frame2, text="Hello")

tmp = os.getenv("TMPDIR")
tmp = osname"""
            script = jedi.Script(source, 2, 8, "test_get_definitions.py")
            defs = script.goto_

# Generated at 2022-06-12 12:48:53.412510
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import mypackage\nmypackage."
    completions = get_script_completions(source, 2, 15)
    print(completions)
    print(source)


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:48:58.803818
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("1 + 1", 0, 0, "<stdin>")) == 1
    assert len(get_script_completions("1 + 1", 0, 0, "<stdin>", ["/tmp"])) == 1
    assert len(get_script_completions("1 + 1", 0, 0, "<stdin>", [])) == 1

# Generated at 2022-06-12 12:49:07.727011
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    src = """\
import datetime as foo
try:
    print(f-oo.date.today().year)
except:
    pass
"""
    completions = get_script_completions(src, 5, 9, "/home/foo/test.py")

    assert len(completions) > 10

    if not running_on_mac_os() and not running_on_windows():
        assert "FooClass" in [c.complete for c in completions]
        assert "FooFunc" in [c.complete for c in completions]

    assert "class" in [c.type for c in completions if c.complete == "FooClass"]

# Generated at 2022-06-12 12:49:10.584618
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("os.", [{"os": None}]) == [
        ThonnyCompletion("__name__=", "os.__name__=", "class", "", None, "")
    ]

# Generated at 2022-06-12 12:49:21.741747
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import unittest.mock

    def get_definitions(self, row, column):
        import jedi

        if _using_older_jedi(jedi):
            return self.goto_definitions()
        else:
            return self.infer(line=row, column=column)

    # Testing in jedi version 0.13.2
    class JediScript13:
        def __init__(self, source, row, column, filename):
            self.source = source
            self.row = row
            self.column = column
            self.filename = filename

        def goto_definitions(self):
            pass

    class JediScript14:
        def __init__(self, code, path):
            self.code = code
            self.path = path


# Generated at 2022-06-12 12:49:30.982884
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    Test result of get_interpreter_completions()
    """
    import jedi

    if _using_older_jedi(jedi):
        from test.test_jedi_interpreter import Variable

        source = "__builtins__"
        namespaces = [{"__builtins__": [Variable(name, "int") for name in ["int", "str"]]}]
        completions = get_interpreter_completions(source, namespaces)
        assert [c.name for c in completions] == ["int", "str"]
    else:
        from parso.python import tree

        source = "__builtins__"
        namespaces = [{"__builtins__": {"int": tree.Name(None), "str": tree.Name(None)}}]
        completions = get_interpre

# Generated at 2022-06-12 12:50:56.223384
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from os.path import dirname, join

    from thonny import get_workbench
    from thonny.languages.python.jedi_utils import get_interpreter_completions

    get_workbench().set_option("run.force_system_python", True)

    script_dir = dirname(__file__)
    source = open(join(script_dir, "autocomplete_test.py")).read()

    namespaces = [{}]

    completions = get_interpreter_completions(source, namespaces)

    assert len(completions) >= 2

    # test stdlib path

# Generated at 2022-06-12 12:51:03.748030
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    # This is how to test it with normal import mechanism
    # from jedi import jedi
    # completions = get_script_completions('import sys\nsy', 4, 3, '/home/krister/Desktop/thonny/thonny/plugins/run.py')
    source = 'import sys\nsy'
    row = 4
    column = 3
    filename = '/home/krister/Desktop/thonny/thonny/plugins/run.py'
    completions = get_script_completions(source, row, column, filename)

    assert completions[0].name == 'sys'
    assert completions[0].complete == 'sys'
    assert completions[0].full_name == 'sys'
    assert comple

# Generated at 2022-06-12 12:51:13.419968
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completer import jediutils

    completions = jediutils.get_script_completions("x = 1", 0, 1, "")
    assert len(completions) == 1
    assert completions[0].type == "statement"

    completions = jediutils.get_script_completions("x = 1", 1, 0, "")
    assert len(completions) == 1
    assert completions[0].type == "statement"

    completions = jediutils.get_script_completions("def foo():\n    x.n\n    x.n", 2, 6, "")
    assert len(completions) == 3, completions
    assert set(c.type for c in completions) == {"import", "statement", "param"}




# Generated at 2022-06-12 12:51:22.074037
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions('a = 1', 0, 0, 'test') == []
    assert get_definitions('a = 1\na', 1, 0, 'test') == []
    assert get_definitions('a = 1\ndef foo():', 1, 0, 'test') == [
        ThonnyCompletion(name='foo()', complete='foo()', type='function', description='', parent='<module>', full_name='<module>.foo')
    ]
    assert get_definitions('a = [1]\na[0]', 1, 1, 'test') == [
        ThonnyCompletion(name='0', complete='0', type='int', description='', parent='list', full_name='list.int')
    ]


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-12 12:51:31.092471
# Unit test for function get_definitions
def test_get_definitions():
    source = """
    x = 0
    def f(a):
        return a
    f(x)
    """

    row = 3
    column = 5
    import jedi
    jedi.debug.set_debug_function("stuff")

    jedi.debug.debug_function(source, row, column)

    print("Definitions:")
    definitions = get_definitions(source, row, column, "test.py")
    for item in definitions:
        print("type: %s" % item.type)
        print("description: %s" % item.description)
        print("docstring: %s" % item.docstring())
        print("module_path: %s" % item.module_path)
        print("name: %s" % item.name)

# Generated at 2022-06-12 12:51:37.915811
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'from math import *\nx = sin(3'
    result = get_script_completions(source, 2, 9, '/tmp/file.py')

    assert len(result) == 1
    assert result[0].name == 'sin'
    assert result[0].complete == 'sin'
    assert result[0].type == 'definition'
    assert result[0].description == 'sin(x)'
    assert result[0].parent == 'math'
    assert result[0].full_name == 'math.sin'

# Generated at 2022-06-12 12:51:45.820171
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context import ClassContext

    class ClassDummy(ClassContext):
        def __init__(self, class_name, name, full_name, description):
            super().__init__(ClassDummy, None)
            self._class_name = class_name
            self._name = name
            self._full_name = full_name
            self._description = description

        def py__getattribute__(self, name):
            if name == "name":
                return self._name
            elif name == "full_name":
                return self._full_name
            elif name == "description":
                return self._description
            else:
                raise NotImplementedError


# Generated at 2022-06-12 12:51:50.756654
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    try:
        completions = get_interpreter_completions(
            source="import sys; sys.pat",
            namespaces=[{"__name__": "__main__", "__doc__": None, "__builtins__": __builtins__}],
        )
    except jedi.NotFoundError:
        # happens if no source file is found
        pass



# Generated at 2022-06-12 12:52:00.532651
# Unit test for function get_definitions
def test_get_definitions():
    def t(source, row, column, expected):
        actual = get_definitions(source, row, column, "source.py")
        assert len(actual) == 1
        assert actual[0].module_path == expected

    t(
        "import io\nx = io.StringIO('')\nx.r",
        2,
        17,
        "io",
        # _io.StringIO does not show up because of filtering by module_path
    )

    t(
        "import io\nx = io.StringIO('')\nx.wri",
        2,
        17,
        "io",
        # _io.StringIO does not show up because of filtering by module_path
    )

    t("import io\nio.StringIO('')", 2, 9, "io")
    t

# Generated at 2022-06-12 12:52:01.875430
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:54:07.577890
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("", 1, 1, "")) != 0

# Generated at 2022-06-12 12:54:14.848342
# Unit test for function get_interpreter_completions