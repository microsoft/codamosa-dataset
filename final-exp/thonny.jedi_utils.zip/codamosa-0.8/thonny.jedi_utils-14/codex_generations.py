

# Generated at 2022-06-12 12:44:39.912677
# Unit test for function get_definitions
def test_get_definitions():
    # Test case 1 - test import string
    source = "import string"
    row = 1
    column = 7
    filename = "dummy.py"
    definitions = get_definitions(source, row, column, filename)
    assert definitions[0].in_builtin_module()
    assert definitions[0].type is "module"
    assert definitions[0].desc_with_module == "string"
    assert definitions[0].line == 1
    assert definitions[0].column == 7
    assert definitions[0].full_name == "string"

    # Test case 2 - test from math import *
    source = "from math import *"
    row = 1
    column = 11
    filename = "dummy.py"
    definitions = get_definitions(source, row, column, filename)
    assert definitions[0].in_built

# Generated at 2022-06-12 12:44:48.153467
# Unit test for function get_script_completions
def test_get_script_completions():
    script = """import os.path
from os import """
    import jedi

    completions = get_script_completions(script, row=2, column=14, filename="")
    completions = sorted(completions, key = lambda c: c.name)
    assert (completions[0].name == "path")
    assert (completions[0].complete == "path")
    assert (completions[0].type == "module" or completions[0].type == "import")
    assert (completions[0].description == "Library for ea" or completions[0].description == "Module for interfacing with the operating system")
    assert (completions[0].parent == "os")
    assert (completions[0].full_name == "os.path")

# Generated at 2022-06-12 12:44:58.088286
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    source = "import os; os.path.relpath"
    namespaces = [
        {
            "a": 1,
            "b": {
                "c": 2,
                "d": 3,
            },
        }
    ]
    sys_path = ["/some/path"]

    with mock.patch("thonny.jediutils.get_interpreter_completions") as mock_method:
        mock_method.side_effect = get_interpreter_completions
        result = get_interpreter_completions(source, namespaces, sys_path)
        mock_method.assert_called_with(source, namespaces, sys_path)
        assert len(mock_method.mock_calls) == 1

# Generated at 2022-06-12 12:45:07.719508
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import unittest.mock
    jedi = unittest.mock.MagicMock()
    setattr(jedi, "__version__", "0.17.1")
    source = "def f(x):\n    pass\n\nf(x=7)\n"
    row = 3
    col = 6
    filename = "/tmp/test.py"
    completions_mock = unittest.mock.MagicMock()
    completions_mock.infer.return_value = ["x"]
    script_mock = unittest.mock.MagicMock()
    script_mock.infer.return_value = completions_mock
    jedi.Script.return_value = script_mock

# Generated at 2022-06-12 12:45:11.192540
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "x = 'a test s'\nx"
    completions = get_script_completions(source, 2, 3, "t.py")
    assert completions[0].complete == "strip"



# Generated at 2022-06-12 12:45:12.133149
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

# Generated at 2022-06-12 12:45:22.060030
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi


# Generated at 2022-06-12 12:45:31.934976
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def _complete(jedi_module, code, row, column):
        if _using_older_jedi(jedi_module):
            try:
                return jedi_module.Script(code, row, column).completions()
            except Exception as e:
                logger.info("Could not get completions with given sys_path", exc_info=e)
                return jedi_module.Script(code, row, column).completions()
        else:
            script = jedi_module.Script(code=code, path=filename)
            return script.complete(line=row, column=column)

    filename = __file__
    with open(filename, "r", encoding="utf-8") as fp:
        code = fp.read()

    row = 3
    column = 15
    completions

# Generated at 2022-06-12 12:45:35.808772
# Unit test for function get_definitions
def test_get_definitions():
    # for jedi < 0.18
    # 
    assert get_definitions("import sys; sys.getrefc", 0, 20, "")[0].description == "getrefcount(...) getrefcount(object) -> integer\nReturn the reference count of object.  The count returned is generally\none higher than you might expect, because it includes the (temporary)\nreference as an argument to getrefcount()."

# Generated at 2022-06-12 12:45:39.147977
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions('import sys\nsys.', [])
    assert len(completions) > 0
    assert any(c.name == "__stdout__" for c in completions)

# Generated at 2022-06-12 12:45:56.058830
# Unit test for function get_definitions

# Generated at 2022-06-12 12:46:07.277995
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    try:
        import jedi
    except ImportError:
        print("Skipping test_get_interpreter_completions, because Jedi not installed")
        return
    completions = get_interpreter_completions(
        source="import sys\n",
        namespaces=[
            {"type": "module", "name": "sys", "is_stub": True, "module": None}
        ],
        sys_path=["."],
    )
    assert len(completions) > 0
    # print([(c.name, c.full_name, c.type) for c in completions])
    assert ("path", None, "property") in [
        (c.name, c.full_name, c.type) for c in completions
    ]

# Generated at 2022-06-12 12:46:14.282169
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions("a = b", 1, 4, "<input>")
    get_definitions("a.b", 1, 4, "<input>")
    get_definitions("a.b", 1, 3, "<input>")
    get_definitions("a.b.c", 1, 6, "<input>")
    get_definitions("a.b", 1, 5, "<input>")
    get_definitions("a().b", 1, 6, "<input>")



# Generated at 2022-06-12 12:46:22.358090
# Unit test for function get_definitions
def test_get_definitions():
    from thonny import misc_utils
    import jedi

    # jedi 0.16.0, no definitions
    completions = get_definitions(
        '"""Module docstring."""\n\n\ndef f():\n    """Function docstring."""\n    first = 1\n    \n    a = 2\n    b = 3\n    \n    print(first)\n    \nprint(__name__)\n',
        1, 0, "jedi_test_script.py"
    )
    print(completions)
    print(completions[0].type)
    assert len(completions) == 0
    assert isinstance(completions, list)
    assert isinstance(completions[0], jedi.api._parser.PyDef)

    # jedi 0.17

# Generated at 2022-06-12 12:46:34.259619
# Unit test for function get_definitions
def test_get_definitions():
    from collections import namedtuple
    from thonny import get_workbench
    from thonny.languages import tr

    Definition = namedtuple("Definition", "desc name module_name")
    test_cases = [
        ("class Dummy: pass\nDummy", "Dummy", "dummy_class.py"),
        ("def f(): pass\nf", "f()", "dummy_func.py"),
        ("class Dummy: pass\nDummy()", "Dummy", "dummy_inst.py"),
    ]

    for source, exp_desc, fname in test_cases:
        fname = get_workbench().get_local_cwd() + "/" + fname
        exp_def = Definition(desc=exp_desc, name=exp_desc, module_name=fname)
        act

# Generated at 2022-06-12 12:46:42.902168
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    if _using_older_jedi(jedi):
        namespaces = [
            {
                "__builtins__": globals()["__builtins__"],
                "a": 1,
                "b": "2",
                "c": ["1", "2", "3"],
            }
        ]
    else:
        # Since jedi >= 0.18.0 namespaces are structured as follows:
        # variables are of type jedi.InterpreterVariable
        # lists and dicts are of type jedi.InterpreterContainer
        # builtins are of type jedi.InterpreterContainer (e.g. "__builtins__")
        class InterpreterVariable(jedi.InterpreterVariable):
            def __init__(self, value):
                self.obj = value


# Generated at 2022-06-12 12:46:47.605975
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completer import utils

    completions = utils.get_script_completions("foo", 0, 1, "test_file")
    assert (
        set(c.name for c in completions) == set(["foo", "foob", "foobar", "foobaz"])
    )

# Generated at 2022-06-12 12:46:51.194216
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    source = "import thonny\ntho"
    completions = get_script_completions(source, 2, 5, "")
    assert len(completions) == 1



# Generated at 2022-06-12 12:46:59.837471
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.python_shell import InterpreterCompletion

    # Setup
    print("Starting test_get_interpreter_completions()")
    test_str = "import random; random."
    test_namespaces = [{"random": random}]
    test_col = len("import random; random.")
    test_row = 0
    completions = get_interpreter_completions(test_str, test_namespaces, None)
    print("Completions: " + str(completions))

    #Assert
    assert len(completions) > 0
    for completion in completions:
        assert isinstance(completion, InterpreterCompletion)
    print("test_get_interpreter_completions() finished")

# Generated at 2022-06-12 12:47:03.676261
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.environment import get_stdlib_path
    for name, path in get_stdlib_path().items():
        source = open(path, encoding="utf-8").read()
        definitions = get_definitions(source, 0, 0, path)
        assert len(definitions) > 0

# Generated at 2022-06-12 12:47:39.573057
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from math import *; f"
    completions = get_interpreter_completions(
        source, [{"mat": __import__("math")}], sys_path=[]
    )
    assert completions[0].full_name == "math.factorial"
    assert len(completions) > 0

# Generated at 2022-06-12 12:47:49.689910
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions(
        "print(",
        [],
    ) == [
        ThonnyCompletion(
            name="print",
            complete="print",
            type="statement",
            description="Defined in builtins",
            parent="",
            full_name="print",
        )
    ]
    assert get_interpreter_completions("print(", [{"a": 1}]) == [
        ThonnyCompletion(
            name="print",
            complete="print",
            type="statement",
            description="Defined in builtins",
            parent="",
            full_name="print",
        )
    ]

# Generated at 2022-06-12 12:47:54.995226
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    >>> get_script_completions("import datetime; datetime.dateti", 16,21, "test.py")
    [ThonnyCompletion(name='datetime', complete='datetime', type='module', description='Python standard library', parent='', full_name=''), ThonnyCompletion(name='datetime', complete='datetime', type='module', description='Python standard library', parent='', full_name='')]
    """
    pass

# Generated at 2022-06-12 12:48:06.578067
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from thonny import ui, codeview, get_runner

    from thonny.config import get_workbench_configuration

    workbench_config = get_workbench_configuration()

    workbench_config.set("runner", "default_python", "python")

    from thonny.languages import tr
    from thonny.misc import get_virtual_env, running_on_mac_os

    tr.install("en")
    runner = get_runner()
    runner.start_backend()
    sys.path.insert(0, ".")

    if running_on_mac_os():
        import platform

       

# Generated at 2022-06-12 12:48:10.472105
# Unit test for function get_script_completions
def test_get_script_completions():
    source="""import os
os.path.abspath()
"""
    completions = get_script_completions(source, 3, 17, "")
    assert len(completions) > 0 and completions[0].complete == "abspath("



# Generated at 2022-06-12 12:48:18.800664
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench

    try:
        import parso
    except ImportError:
        return
    else:
        if parso.__version__ < "0.6.1":
            return

    import unittest


# Generated at 2022-06-12 12:48:26.638324
# Unit test for function get_definitions
def test_get_definitions():
    source = """
    a = 1
    a = 2
    """
    row, column = 1, 2
    assert len(get_definitions(source, row, column, "test_file.py")) == 2
    assert get_definitions(source, row, column, "test_file.py")[0].in_builtin_module() == False
    assert get_definitions(source, row, column, "test_file.py")[0].module_name == "test_file.py"
    assert get_definitions(source, row, column, "test_file.py")[0].line == 1
    assert get_definitions(source, row, column, "test_file.py")[0].column == 0
    assert get_definitions(source, row, column, "test_file.py")[0].module_

# Generated at 2022-06-12 12:48:35.283355
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Test the autocompletion functionality.
    """
    # Tuple of (code, row, column, expected result)
    test_values = [
        ('"foo".cap', 0, 8, ["capitalize"]),
        ('"foo".upper', 0, 10, ["upper"]),
        ('def foo():\n pass\n\nfoo', 3, 2, ["foo"]),
        ('import sys\n\nsys.exit', 2, 5, ["exit"]),
    ]
    for value in test_values:
        result = get_script_completions(*value[:-1])
        names = [x.name for x in result]
        assert names == value[-1], result



# Generated at 2022-06-12 12:48:39.894335
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import unittest
    def check_completions(source, row, column, expected):
        script = Script(source, row, column)
        completions = script.completions()
        assert set(c.name for c in completions) == set(expected)


# Generated at 2022-06-12 12:48:48.872545
# Unit test for function get_script_completions
def test_get_script_completions():
    from operator import itemgetter
    from test.fixtures import jedi_test_data
    from test.test_jedi import get_scripts

    for id in range(0, 42):
        (
            file_path,
            source,
            row,
            column,
            expected_completions,
        ) = jedi_test_data.get_completion_test_data(id)

        script = get_scripts(file_path, source, row, column)
        completions = script.completions()

        if completions:
            completion_names = [completion["name"] for completion in completions]


# Generated at 2022-06-12 12:49:27.711553
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import sys
    import os

    import jedi

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.source = "class SampleClass:\n    pass\n\nsam"
            self.row = 3
            self.column = 4
            self.filename = "/home/finki/test/testproject/test.py"

        def test_get_script_completions(self):
            if _using_older_jedi(jedi):
                jediScriptCompletions = jedi.Script(
                    self.source, self.row, self.column, self.filename
                ).completions()

# Generated at 2022-06-12 12:49:38.205672
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api import InterpreterCompletion
    from collections import namedtuple
    from jedi.parser import tree
    import re

    class DummyInterpreterCompletion(InterpreterCompletion):
        def __init__(self, desc):
            self.description = desc

        @property
        def name(self):
            return re.search('(.*)\(', self.description).group(1)

        @property
        def complete(self):
            return re.search('"(.*)"', self.description).group(1)

        @property
        def type(self):
            return ''

        @property
        def parent(self):
            return tree.Name()


# Generated at 2022-06-12 12:49:42.582721
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    source = "pri"
    row = 0
    column = 3
    filename = "/file"

    completions = get_script_completions(source, row, column, filename)
    assert completions[0].complete == "print"

# Generated at 2022-06-12 12:49:49.802938
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    dirname = os.path.dirname(os.path.realpath(__file__))
    file_name = os.path.join(dirname, "sample_file.py")
    with open(file_name) as f:
        source = f.read()
    completions = []
    completions = get_script_completions(source, row=8, column=4, filename=file_name)

    assert len(completions) > 0
    assert completions[0].name == "EOL"

    if _using_older_jedi(jedi):
        assert completions[0].complete == "EOL"
    else:
        assert completions[0].complete == "EOL = "


# Generated at 2022-06-12 12:49:57.583571
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate.compiled import CompiledObject

    defs = get_definitions("import re\ns = re.compile('')", 1, 6, "<stdin>")

    # Check that the output is essentially a list of Module objects
    assert isinstance(defs, list)
    assert len(defs) == 2
    assert isinstance(defs[0], CompiledObject) and defs[0].get_qualified_names() == ("re",)
    assert isinstance(defs[1], CompiledObject) and defs[1].get_qualified_names() == ("_sre",)

# Generated at 2022-06-12 12:49:59.129330
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:50:01.757406
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_definitions(self):
            self.maxDiff = None


# Generated at 2022-06-12 12:50:11.097929
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # First verify that no completions are recommended for a completely random source string
    source = "for i in range(5): print(i)"
    completions = get_interpreter_completions(source, [])
    assert completions == []

    # Complete the name of a variable
    source = "my_varia"
    completions = get_interpreter_completions(source, [{"my_variable": "spam"}])
    assert len(completions) == 1
    assert completions[0].name == "my_variable"

    # Complete the name of a variable even if there is a function of the same name
    source = "def my_function(x): print(x)\nmy_varia"

# Generated at 2022-06-12 12:50:20.169488
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        pass

    suite = unittest.TestSuite()

    names = [name for name in dir(TestCase) if "test" in name]
    for name in names:
        delattr(TestCase, name)
        

# Generated at 2022-06-12 12:50:26.429253
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\nimport re\nsys.p\nre.c"
    completions = get_script_completions(source, 3, 5, "test.py")
    assert len(completions) == 1
    assert completions[0].type == "module"
    assert completions[0].name == "re"
    assert completions[0].complete == "re"
    assert completions[0].full_name == "re"



# Generated at 2022-06-12 12:51:39.791778
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import inspect
    import os

    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.18.0+ has changed the API
        return

    this_file = inspect.getfile(test_get_interpreter_completions)
    position_in_test_file = (
        inspect.getsourcelines(test_get_interpreter_completions)[0][0] + 7
    )
    code = inspect.getsource(test_get_interpreter_completions)
    completions = get_interpreter_completions(code, [{"os": os}], [os.path.dirname(this_file)])
    assert completions

    for c in completions:
        if c.type == "statement":
            continue


# Generated at 2022-06-12 12:51:46.959514
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        namespaces = [
            {
                "a": 1,
                "b": 2,
                "subdict": {
                    "sub_a": 3,
                    "sub_b": 4,
                    "sub_subdict": {
                        "subsub_a": 5,
                        "subsub_b": 6,
                    },
                },
            },
        ]
    else:
        namespaces = [
            jedi.names(
                a=1,
                b=2,
                subdict=jedi.names(
                    sub_a=3,
                    sub_b=4,
                    sub_subdict=jedi.names(subsub_a=5, subsub_b=6),
                ),
            )
        ]

   

# Generated at 2022-06-12 12:51:56.531936
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test empty string
    assert get_script_completions("", 1, 1, "") == []

    # Test import statement
    completions = get_script_completions("import", 1, 7, "")
    assert len(completions) > 0
    for completion in completions:
        assert completion.complete.startswith("import ")
        assert completion.name.endswith(" as ")

    # Test module name
    assert get_script_completions("import sys", 1, 16, "") == []

    # Test completion after "."
    assert len(get_script_completions("import sys; sys.", 1, 15, "")) > 0

    # Test completion after "("
    assert len(get_script_completions("import time; time.sleep(", 1, 22, "")) > 0



# Generated at 2022-06-12 12:52:06.003623
# Unit test for function get_definitions
def test_get_definitions():
    source = """
from tkinter import *

root = Tk()
root.mainloop()
    """
    # Python 3.8
    d = get_definitions(source, line=3, column=5, filename="asd")
    assert len(d) == 1
    assert d[0].line == 1
    assert d[0].column == 17

    # Python 3.6
    d = get_definitions(source, line=3, column=5, filename="/usr/lib/python3.6/tkinter/__init__.py")
    assert len(d) == 1
    assert d[0].line == 686
    assert d[0].column == 4



# Generated at 2022-06-12 12:52:06.689330
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:52:09.111531
# Unit test for function get_definitions
def test_get_definitions():
    source = "import json\njson."
    defs = get_definitions(source, 2, 7, None)
    assert len(defs) == 1

# Generated at 2022-06-12 12:52:19.846978
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "import sys; sys.path.append('/home/user/'); import numpy as np; a = np.array(42); a."
    row = 5
    column = 27
    filename = "test_pos.py"
    sys_path = ["/home/user/"]

    # Remove any old jedi version
    [c for c in sys.modules if "jedi" in c][::-1]

    # The test is expected to fail with jedi version 0.17

# Generated at 2022-06-12 12:52:24.156117
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from parso.python import tree

    def _get_completions(source: str, row: int, col: int, filename: str, sys_path=None):
        completions = get_script_completions(source, row, col, filename, sys_path)
        return [c.name for c in completions]

    # check source code with parser

# Generated at 2022-06-12 12:52:33.687929
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    from thonny.ui_utils import add_line_number_string

    _test_code = """
import sys
print(sys)
"""

    def check_completions(completions):
        # Not a real test
        print()
        print()
        print("-" * 70)
        print("Completions:")
        for completion in completions:
            print(add_line_number_string(completion.description))
            print(completion.name)
            print(completion.complete)
            print(completion.description)
            print(completion.type)
            print(completion.parent)
            print(completion.full_name)
            print()


# Generated at 2022-06-12 12:52:41.283237
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    import jedi
    code = "import datetime\n datetime.d"
    line = 2
    pos = 20
    namespaces = [{"datetime": datetime}]
    completions = get_interpreter_completions(code, namespaces)
    assert [c.name for c in completions] == [
        "datetime.date",
        "datetime.datetime",
        "datetime.datetime_CAPI",
        "datetime.time",
        "datetime.timedelta",
        "datetime.tzinfo",
    ]

