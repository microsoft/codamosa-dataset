

# Generated at 2022-06-12 12:44:33.642496
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('with open("abc") as f: f.read(1)', 0, 1, '') == []
    assert get_script_completions('with open("abc") as f: f.read(1)', 0, 20, '') == []
    assert get_script_completions('with open("abc") as f: f.read(1)', 0, 29, '') == []
    assert get_script_completions('with open("abc") as f: f.read(1)', 1, 26, '') == []

# Generated at 2022-06-12 12:44:37.399208
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import unittest


# Generated at 2022-06-12 12:44:44.550702
# Unit test for function get_script_completions
def test_get_script_completions():
    # NB! For this test to work, there must be two versions of jedi installed
    import jedi

    if jedi.__version__[:3] == "0.8":
        print("Unit test for function get_script_completions")
        print("For this test, jedi 0.8 or 0.9 must be installed, but got version " + jedi.__version__)
        assert False

    result = get_script_completions("pri", 1, 2, "")
    assert len(result) > 0, "Expected some results"
    for r in result:
        assert isinstance(r, ThonnyCompletion)


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:44:51.455121
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import Script
    result = get_script_completions("for a in b:", 1, 7, "")

    assert result is not None
    assert len(result) > 0
    assert isinstance(result[0], ThonnyCompletion)
    assert isinstance(result[0]["name"], str)
    assert isinstance(result[0]["complete"], str)
    assert result[0]["type"] in [
        "statement",
        "keyword",
        "import",
        "function",
        "module",
        "class",
        "instance",
        "param",
    ]
    assert isinstance(result[0]["description"], str)
    assert isinstance(result[0]["parent"], Completion)

# Generated at 2022-06-12 12:45:01.885840
# Unit test for function get_definitions
def test_get_definitions():
    """
    Ensure correct functioning of get_definitions.
    This test will only work if a local installation
    of jedi is present.
    """
    import jedi
    import os
    import sys
    import unittest

    def get_testfile_path():
        """
        Get the path of the testfile.
        """
        if getattr(sys, "frozen", False):
            # frozen
            base_folder = os.path.dirname(sys.executable)
        else:
            # normal
            base_folder = os.path.dirname(__file__)
        return os.path.join(base_folder, "testfiles", "jedi_test.py")

    ################################################################################
    # get_definitions test
    ################################################################################

# Generated at 2022-06-12 12:45:10.118905
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    print(get_script_completions('print(1)\npr', 2, 3, "<stdin>"))
    print(get_script_completions('print(1)\npr', 2, 3, "<stdin>", sys_path=['/']))

    # call function defined in this file
    print(get_script_completions('get_script_completions', 1, 0, __file__))

    # call function defined in this file with absolute path
    print(get_script_completions('get_script_completions', 1, 0,
                                 "file://" + __file__))

    # call function defined in this file with non-existing path

# Generated at 2022-06-12 12:45:17.129395
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("frozsetr(m", 2, 9, "")
    assert len(completions) > 1

    completions = get_script_completions("frozsetr(m", 2, 9, "", ["/usr/local/lib/python3.6/site-packages"])
    assert len(completions) > 1

    completions = get_script_completions("frozsetr(m", 2, 9, "", ["/home/invalid/path"])
    assert len(completions) > 1


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:45:26.576382
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    # Without namespaces
    code = "print('Hello')"
    completions = get_interpreter_completions(code, [])
    assert len(completions) == 1
    assert completions[0].name == "print"
    assert completions[0].complete == "print("

    # With namespaces
    namespaces = [locals(), globals()]
    completions = get_interpreter_completions(code, namespaces)
    assert len(completions) >= 200
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "print"
    assert completions[0].complete == "print("

# Generated at 2022-06-12 12:45:35.035667
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api import classes

    script = jedi.Script("import sys")
    assert script is not None
    definitions = script.goto_definitions()
    assert len(definitions) == 1

    definition = definitions[0]
    assert isinstance(definition, classes.Module)
    assert definition.name == "sys"
    assert definition.full_name == "sys"
    assert definition.is_builtin()
    assert definition.file_path.endswith("sys.py")

    script = jedi.Script("import sys\nsys")
    assert script is not None
    definitions = script.goto_definitions()
    assert len(definitions) == 1

    definition = definitions[0]
    assert isinstance(definition, classes.Module)
    assert definition.name == "sys"
   

# Generated at 2022-06-12 12:45:38.057716
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:46:06.898471
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled import CompiledObject

    class DummyNamespace:
        def __init__(self, name, completions):
            self.name = name
            self.completions = lambda: completions

    class DummyCompletion:
        def __init__(self, complete):
            self.complete = complete

    dummy_completions = [DummyCompletion("dummy_name")]

    completions = get_interpreter_completions(
        source="a", namespaces=[DummyNamespace("dummy", dummy_completions)]
    )
    assert len(completions) == 1
    assert completions[0].complete == "dummy_name"


# Generated at 2022-06-12 12:46:17.850348
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    with patch('os.getcwd', return_value='/home/user'):
        res = get_script_completions("time.", 4, 5, "test_utils.py")
        assert res == [ThonnyCompletion(name='time', complete='time', type='module', description='time \x1b[1;33mmodule\x1b[0m\n\nThe time module provides various time-related functions. For related functions,\nsee also the datetime and calendar modules.', parent='', full_name='time')], res
        res = get_script_completions("time.", 4, 5, "test_utils.py", sys_path=['/path/to/somenething'])

# Generated at 2022-06-12 12:46:22.114992
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from os import\n"
    completions = get_script_completions(source, 2, 10, "test.py")
    assert [x.name for x in completions] == ["path", "pathconf", "pathconf_names", "stat"]

# Generated at 2022-06-12 12:46:34.009202
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import MIXIN_NAMES  # for testing

    source = "import math; math.sqrt(4)"
    namespaces = [{"__builtins__": __import__("builtins")}]
    completions = get_interpreter_completions(source, namespaces)
    # unittest.TestCase.assertEqual(completions, [])

    source = "import math; math.sqrt(4)"
    namespaces = [{"__builtins__": __import__("builtins")}, {"math": __import__("math")}]
    completions = get_interpreter_completions(source, namespaces)
    assert any([c.name == "sqrt" for c in completions])

    source = "import math; math."

# Generated at 2022-06-12 12:46:38.401933
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test values:
    source = "print()"
    row = 1
    column = 2
    filename = "test.py"

    script_completer = get_script_completions(source, row, column, filename)
    assert script_completer[0].name == "print"



# Generated at 2022-06-12 12:46:48.328933
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    from unittest.mock import MagicMock

    import jedi

    class MockInterpreter:
        def __init__(self, source, namespaces):
            self.source = source
            self.namespaces = namespaces

        def complete(self):
            return [MockCompletion("1"), MockCompletion("2")]

    class MockCompletion:
        def __init__(self, name):
            self.name = name

    jedi.Interpreter = MockInterpreter
    jedi.__version__ = "0.16"

    completions = get_interpreter_completions("foo", [], sys_path=[])
    TestCase.assertListEqual(TestCase(), completions, [{"name": "1"}, {"name": "2"}])

# Generated at 2022-06-12 12:46:55.005868
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    SOURCE = """
from tkinter import *

root = Tk()
frame = Frame(root)
frame.pack()

label = Label(frame, text="Hello")
label.pack()

button = Button(frame, text="Press me")
button.pack()

root.mainloop()
"""
    completions = get_script_completions(SOURCE, row=7, column=22, filename="test.py")
    assert len(completions) > 0
    for completion in completions:
        assert completion.name == "text"
        assert completion.complete == "text="
        assert completion.type == "param"
        assert completion.description == "text : string"
        assert completion.parent == "__init__"



# Generated at 2022-06-12 12:46:56.770572
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("", [{}], [])) > 0



# Generated at 2022-06-12 12:47:05.908787
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import jedi
    from jedi import interpreter
    from jedi.api.classes import Definition

    def get_imported_modules(source):
        """
        Get the list of modules imported in the source code
        """
        script = jedi.Script(code=source)
        return [s.module_name for s in script.completions()]

    def get_test_path():
        """
        The path to the folder containing unit tests,
        i.e. the path to the folder containing the
        test_get_definitions.py file
        """
        from os.path import dirname, realpath, join
        return dirname(realpath(__file__))


# Generated at 2022-06-12 12:47:09.077437
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys; sys.p"
    completions = get_script_completions(source, 0, 16, "")
    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].type == "param"

# Generated at 2022-06-12 12:47:41.241156
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.micropython import MicroPythonBackend

    backend = MicroPythonBackend(None)

    source = """
from turtle import *
from tkinter import *
from tkinter.ttk import *
from tkinter.messagebox import *
from tkinter.filedialog import *
from tkinter.colorchooser import *
from math import *
import os
import sys
import time
import json
import random

speed(0)
tracer(0, 0)

lc = Listbox(Tk())
r = Radiobutton(Tk())
cb = Checkbutton(Tk())

"""
    # after "from tkinter import *"
    completions = backend.get_completions(source, "script", 4, 3)
    assert len(completions) == 56

# Generated at 2022-06-12 12:47:51.033498
# Unit test for function get_script_completions
def test_get_script_completions():
    from types import ModuleType
    import unittest

    class FakeJedi:
        __version__ = "0.12.0"

        class Script:
            def __init__(self, *args, **kwargs):
                pass

            def completions(self):

                class FakeCompletion:
                    def __init__(self, name, complete, type, description, parent, full_name):
                        self.name = name
                        self.complete = complete
                        self.type = type
                        self.description = description
                        self.parent = parent
                        self.full_name = full_name

                    def __getitem__(self, key):
                        return self.__dict__[key]


# Generated at 2022-06-12 12:47:59.159076
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    script = Script("import re\nre.compi", 1, 10, "main.py")
    assert script.completions()[0].name == "compile"

    script = Script("import sys\n\nsys.exi", 2, 8, "main.py")
    assert script.completions()[0].name == "exit"

    script = Script("import sys\n\nsys.exi", 2, 10, "main.py")
    assert script.completions()[0].name == "exit"

    script = Script("import sys\nsys.getdefaul", 2, 16, "main.py")
    assert script.completions()[0].name == "getdefaultencoding"


# Generated at 2022-06-12 12:48:09.918645
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\nos.path"
    import os
    import sys
    namespaces = [{"__builtins__": __builtins__}, {"os": os}, {"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 10
    assert any(c.full_name for c in completions)
    assert any(c.description for c in completions)
    assert any(c.complete for c in completions)
    assert any(c.type == "function" for c in completions)
    assert any(c.type == "statement" for c in completions)
    assert any(c.type == "import" for c in completions)

# Generated at 2022-06-12 12:48:12.055606
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(source, row, column, filename, sys_path)
    for completion in completions:
        print(completion)


# Generated at 2022-06-12 12:48:22.031551
# Unit test for function get_definitions
def test_get_definitions():
    import os
    from parso.python.tree import PythonNode

    path = os.path.dirname(os.path.realpath(__file__))

    source = "from logging import DEBUG\n" + \
        "def f(a, b, c): pass\n" + \
        "s = 'Hello'\n" + \
        "d = {}\n" + \
        "f(s, DEBUG, d)\n" + \
        "b = [1, 2, 3]\n" + \
        "f(s, b[0], d)\n" + \
        "f(s, DEBUG, d) # comment"

    jedi_defs = get_definitions(
        source, 5, 1, os.path.join(path, 'get_definitions_test.py')
    )



# Generated at 2022-06-12 12:48:32.866034
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    from parso.python import tree

    def mocked_interpreter_complete(*args, **kwargs):
        return [
            ThonnyCompletion(name="a", complete="a", type="a", description="", parent=None, full_name=""),
            ThonnyCompletion(name="b", complete="b", type="b", description="", parent=None, full_name=""),
            ThonnyCompletion(name="c", complete="c", type="c", description="", parent=None, full_name=""),
            ThonnyCompletion(name="d", complete="d", type="d", description="", parent=None, full_name=""),
            ThonnyCompletion(name="e", complete="e", type="e", description="", parent=None, full_name=""),
        ]


# Generated at 2022-06-12 12:48:42.942923
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from jedi.parser_utils import get_statement_of_position

    source = "def f_name(p1): pass\nf_name(1)"
    tree = parso.parse(source)

    assert len(tree.children) == 2
    
    func = tree.children[0]
    call = tree.children[1]
    
    func_stmt = get_statement_of_position(tree, func.end_pos)
    call_stmt = get_statement_of_position(tree, call.end_pos)
    
    assert func_stmt == func
    assert call_stmt == call
    
    func_def = func.children[1]
    call_func = call.children[0]
    
    call_func_stmt = get_statement_of_position

# Generated at 2022-06-12 12:48:50.810377
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi_version = jedi.__version__
    if jedi_version in ["0.13.2", "0.14.0", "0.14.1", "0.14.2"] or jedi_version.startswith("0.15"):
        # There is a known incompatibility with this specific version
        return
    
    source = "from m"
    row = 1
    column = len(source)
    filename = "dummy_filename"
    completions = get_script_completions(source, row, column, filename, sys_path=[])
    assert [c.name for c in completions] == ["math", "multiprocessing"]

    source = "from ma"
    row = 1
    column = len(source)
    filename = "dummy_filename"


# Generated at 2022-06-12 12:49:01.538289
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_interpreter_completions
    from jedi.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi import Script
    from jedi.parser import ParserSyntaxError
    import time

    # test case 1
    source_1 = "import string\nstring."
    expected_names_1 = [
        "ascii_letters",
        "ascii_lowercase",
        "ascii_uppercase",
        "capwords",
        "digits",
        "hexdigits",
        "octdigits",
        "printable",
    ]
    namespaces_1 = []  # empty namespace
    interpreter = Interpreter(source_1, namespaces_1, column=12)
    completions = interpreter

# Generated at 2022-06-12 12:49:48.154088
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import jedi
    from jedi.parser import ParserSyntaxError

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(cur_dir, "..")
    sys_path = [cur_dir, parent_dir]

    # test1
    source = """for i in "d":
        print("hello")"""
    line = 1
    column = 4
    filename = ""
    assert get_script_completions(source, line, column, filename, sys_path) == []

    # test2
    source = """import os

def"""
    line = 2
    column = 5
    filename = ""
    completions = get_script_completions(source, line, column, filename, sys_path)

# Generated at 2022-06-12 12:49:51.696216
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    assert get_definitions("f()", 0, 0, "test.py") == jedi.Script("f()",0, 0, "test.py").goto_definitions()

# Generated at 2022-06-12 12:50:00.828817
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import jedi

    class Test(unittest.TestCase):
        def test_get_script_completions_with_sys_path(self):
            result = get_script_completions(
                source= 'd="""\nimport ',
                row=1,
                column=12,
                filename="example.py",
                sys_path=["/home/user/example", "/home/user/example2"],
            )
            self.assertEqual(len(result), 32)

        def test_get_script_completions_without_sys_path(self):
            result = get_script_completions(
                source= 'd="""\nimport ',
                row=1,
                column=12,
                filename="example.py",
            )

# Generated at 2022-06-12 12:50:08.334367
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import ui_utils

    source = 'import threading\nthreading.Th.'
    completions = get_script_completions(source, 2, 22, 'test_file')
    assert len(completions) == 1
    assert completions[0].name == "Thread"
    assert completions[0].type == "class"
    assert completions[0].description == "Thread(group=None, target=None, name=None, args=(), kwargs={}, *, daemon=None)"
    assert completions[0].parent == "threading"
    assert completions[0].full_name == "threading.Thread"

    source = 'import threading\nx = threading.Th'
    completions = get_script_completions(source, 2, 26, 'test_file')


# Generated at 2022-06-12 12:50:14.414011
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # check whether it works outside a running process
    # (in which case interpreter will be None)
    namespaces = [None]
    comps = get_interpreter_completions("__", namespaces)
    assert "__builtins__" in [c.name for c in comps]

    # check whether it works inside a running process
    import sys

    namespaces = [sys.modules]
    comps = get_interpreter_completions("__", namespaces)[:3]
    for c in comps:
        assert c.name.startswith("__")

# Generated at 2022-06-12 12:50:17.100845
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\nos.path."
    namespaces = [{"os": {"path": {"foo": "foo", "bar": "bar"}}}]
    completions = get_interpreter_completions(source, namespaces)
    assert [c.name for c in completions] == ["foo", "bar"]

# Generated at 2022-06-12 12:50:27.097253
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from pathlib import Path
    import jedi

    examples_dir = Path(__file__).parent.parent / "examples"
    example_name = "test_get_definition.py"
    example_path = examples_dir / example_name
    example_text = example_path.read_text()
    assert isinstance(example_text, str)
    example_ast = parso.parse(example_text)
    example_root_node = example_ast.get_root_node()

    for node, line_number in _get_nodes_with_given_line_number(example_root_node):
        if line_number >=0:
            print("For line: {}".format(line_number))
            definitions = get_definitions(example_text, line_number, 0, example_name)

# Generated at 2022-06-12 12:50:35.342125
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, mock

    from thonny.jedi_utils import get_interpreter_completions

    class TestJediUtils(TestCase):
        @mock.patch("thonny.jedi_utils._using_older_jedi")
        def test_get_interpreter_completions_returns_tweaked_completions(self, mock_using_older_jedi):
            mock_using_older_jedi.return_value = False
            expected_completions = [ThonnyCompletion(name="test=", complete="test=", type="", description="", parent="", full_name="")]
            source = mock.Mock(__contains__=mock.Mock(return_value=True))
            namespaces = [{"test": "foo"}]

# Generated at 2022-06-12 12:50:44.666610
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest

    class CompletionsTests(unittest.TestCase):
        def test_complete_attribute(self):
            code = "import os; os.path.join('', '')."
            completions = get_script_completions(code, 2, 30, "test.py")
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].complete, "split")

        def test_complete_nonexistent_attribute(self):
            code = "import os; os.nonexistent."
            completions = get_script_completions(code, 2, 27, "test.py")
            self.assertEqual(completions, [])


# Generated at 2022-06-12 12:50:55.378247
# Unit test for function get_definitions
def test_get_definitions():
    def check(input_text, result, row, column):
        definitions = get_definitions(input_text, row, column, "")
        assert len(definitions) == 1
        assert definitions[0].line == result["line"]
        assert definitions[0].column == result["column"]
        assert definitions[0].module_path == result["module_path"]

    check(
        "L = []\nL.append",
        {"line": 1, "column": 1, "module_path": ""},
        2,
        len("L.append"),
    )
    check(
        "L = [1,2,3]\nL.count",
        {"line": 1, "column": 1, "module_path": ""},
        2,
        len("L.count"),
    )

# Generated at 2022-06-12 12:52:26.907008
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    source1 = "import sys; print(sys.version)"
    row1 = 1
    column1 = 22
    filename1 = "/home/user/Python-3.8.2/thonny/backend_jedi.py"

    results1 = get_script_completions(source1, row1, column1, filename1)
    assert len(results1) > 0



# Generated at 2022-06-12 12:52:37.185373
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python.tree import Module, Leaf
    from parso.python import tree
    import jedi
    from jedi.evaluate.compiled import MixedCode

    # TODO: add test for Jedi Version 1.0
    # This tests needs to be fixed for Jedi version 1.0, because in 1.0 get_interpreter_completions()
    # does not have a valid version.
    # For now I just comment this test out because it fails with an error in the jedi code
    # error: AttributeError: 'Script' object has no attribute 'complete'
    # return

    # Use the jedi stubs to create a test node

# Generated at 2022-06-12 12:52:45.604188
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.ast_utils import get_ast, is_name_node, get_definition_names, is_assignment, \
        get_names, get_lhs_of_assignment
    from thonny.jedi_utils import get_script_completions
    from os import path
    import inspect

    def test(source, row, col, filename, sys_path):
        return get_script_completions(source, row, col, filename, sys_path)

    ast = get_ast(inspect.getsource(test))
    params = get_names(ast)

    # Let's do a sanity check, that the function is properly defined
    assert len(params) == 5
    assert params[0] == 'source'
    assert params[1] == 'row'

# Generated at 2022-06-12 12:52:50.559218
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    test function get_script_completions
    """
    from thonny.plugins.jedi_completer import jedi_utils

    completion_list = get_script_completions("a = []\na.", 1, 4, "")
    assert len(completion_list) > 0



# Generated at 2022-06-12 12:52:56.766409
# Unit test for function get_definitions
def test_get_definitions():
    defi = get_definitions(
        'foo="bar"; foo[0].upper()', 1, 21, 'foo.py')
    assert len(defi) == 1
    assert defi[0].module_path == 'string'
    assert defi[0].line == 575
    assert defi[0].column == 0
    assert defi[0].description == 'upper($self, /)'
    assert defi[0].docstring() == "S.upper() -> str\n\nReturn a copy of S converted to uppercase."
    assert defi[0].description_with_module == "'str'.upper()"
    assert defi[0].type == "function"
    assert defi[0].full_name == "str.upper"

# Generated at 2022-06-12 12:53:05.139489
# Unit test for function get_script_completions
def test_get_script_completions():
    from .test.test_jedi_utils import check_expected_completions

    assert check_expected_completions(
        test_get_script_completions,  # function to test
        "s = 'abc'\nc = s.upper()\n",  # variable s is expected to appear in completions
        's.lower()\nc = s.lower()\n',  # this is the code where to find s
        2,  # row
        11,  # column
        "test.py",  # file name
    )


# Generated at 2022-06-12 12:53:14.146441
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    path = os.path.join(os.path.dirname(__file__), "jedi_completion_data")
    sys.path.append(path)
    from test_completion_data import get_namespaces

    if _using_older_jedi(jedi):
        result = get_interpreter_completions("from test_completion_data import *; test_compl", get_namespaces())
    else:
        result = get_interpreter_completions("from test_completion_data import *; test_compl")

    print("\n".join(str(c) for c in result))


# Generated at 2022-06-12 12:53:20.806577
# Unit test for function get_definitions
def test_get_definitions():
    import tkinter as tk

    def some_function():
        return 42

    tk = some_function()

    assert len(get_definitions("tk = some_function()", 1, 0, __file__)) == 1, "One definition expected"
    assert len(get_definitions("tk = some_function()", 1, 0, __file__)) == 1, "One definition expected"
    assert get_definitions("tk = some_function()", 1, 0, __file__)[0].module_name == "tkinter", "Module name must be tkinter"
    assert len(get_definitions("some_function()", 1, 0, __file__)) == 1, "One definition expected"
    assert get_definitions("some_function()", 1, 0, __file__)[0].line == 5, "Wrong line"

# Generated at 2022-06-12 12:53:30.284122
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert get_interpreter_completions("print(3.", [{}])[0].complete == "print("
    # https://github.com/davidhalter/jedi/issues/1742
    assert get_interpreter_completions("print(3.0)", [{}])[0].complete == "print"
    assert get_interpreter_completions("print(3.0)", [{"a": 3}])[0].complete == "print"

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("a.", [{"a": 3}])[0].complete == "a"
    else:
        assert get_interpreter_completions("a.", [{"a": 3}])[0].complete == "a."

# Generated at 2022-06-12 12:53:37.632142
# Unit test for function get_script_completions