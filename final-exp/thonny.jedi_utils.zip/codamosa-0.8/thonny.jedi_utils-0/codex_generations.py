

# Generated at 2022-06-12 12:44:29.404961
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\nsys.exit()"
    assert get_interpreter_completions(source, [], []) == []
    assert get_interpreter_completions(source, [{"sys": sys}], []) == [
        ThonnyCompletion(
            name="exit",
            complete="exit",
            type="statement",
            description="Built-in functions, exceptions, and other objects.\n\nNoteworthy: None is the `nil' object; Ellipsis represents `...' in slices."
            ,
            parent=sys,
            full_name="sys.exit",
        )
    ]

    python2_namespaces = [{"__builtins__": __builtins__, "sys": sys}]

# Generated at 2022-06-12 12:44:39.869779
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Overloaded function
    print_matches(
        get_interpreter_completions(
            source="print", namespaces=[{"__builtins__": __builtins__}]
        )
    )
    # Function with no args
    print_matches(
        get_interpreter_completions(
            source="min", namespaces=[{"__builtins__": __builtins__}]
        )
    )
    # Function with more than one argument
    print_matches(
        get_interpreter_completions(
            source="float", namespaces=[{"__builtins__": __builtins__}]
        )
    )
    # Class member

# Generated at 2022-06-12 12:44:48.447301
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import unittest
    import parso
    import jedi

    PROJECT_DIR = os.path.dirname(__file__)
    sys.path.insert(0, PROJECT_DIR)

    class Test(unittest.TestCase):
        def assert_definitions(self, source_code, row, column, expected_defined_paths):
            defined_paths = [d.module_path for d in get_definitions(source_code, row, column, "test_file.py")]
            self.assertCountEqual(expected_defined_paths, defined_paths)

        def test_local_function(self):
            source_code = "def f():\n  pass\nf()"
            row = 0
            column = 3

# Generated at 2022-06-12 12:44:58.939103
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock
    import jedi
    # will mock jedi.Script.completions
    completions = [MagicMock()]
    completions[0].name = "name"
    completions[0].type = "type"
    completions[0].description = "description"
    completions[0].parent = "parent"
    completions[0].complete = "complete"
    completions[0].full_name = "full_name"
    jedi.Script.completions = lambda self: completions
    # will mock jedi.Script.__init__
    jedi.Script.__init__ = lambda self: None

    source = "_"
    row = 0
    column = 0
    filename = "file"

# Generated at 2022-06-12 12:45:08.248990
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python.tree import SubModule, Leaf
    def build_module(parent = None, module_name = "module", children = []):
        module = SubModule(module_name, None, None)
        for child in children:
            module.children.append(child)
        module.parent = parent
        return module
    def build_leaf(value, parso_type, start_pos, end_pos, prefix = "", parent = None):
        leaf = Leaf(parso_type, value, start_pos, end_pos)
        leaf.prefix = prefix
        leaf.parent = parent
        return leaf

    # Build namespaces
    namespace_foo = build_module(None, "foo")
    namespace_foo_end = build_leaf("", "endmarker", (1, 1), (1, 1))
    namespace

# Generated at 2022-06-12 12:45:16.980624
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "pri"
    row = 0
    column = 3
    filename = "program.py"

    completions = get_script_completions(source, row, column, filename)

    script = jedi.Script(source, row, column, filename)
    script_completions = script.completions()

    assert len(completions) == len(script_completions)
    for i, completion in enumerate(completions):
        assert completion.name == script_completions[i].name
        assert completion.complete == script_completions[i].complete
        assert completion.description == script_completions[i].description
        assert completion.parent == script_completions[i].parent
        assert completion.full_name == script_completions[i].full_name



# Generated at 2022-06-12 12:45:27.521462
# Unit test for function get_script_completions
def test_get_script_completions():
    # testing conflict with parso.parse() and jedi.Script()
    import parso
    import jedi
    import os
    pos = os.path.normpath(__file__)
    pos = os.path.split(pos)[0]
    pos = os.path.join(pos, 'complete.py')
    with open(pos, encoding='utf-8') as f:
        data = f.readlines()

    source = ''.join(data)

    # test conflict with parso
    try:
        parso.parse(source)
    except Exception:
        print('error 01')

    # test conflict with jedi
    try:
        completions = jedi.Script(source, 1, 0, pos).completions()
    except Exception:
        print('error 02')

    # test conflict with parso.

# Generated at 2022-06-12 12:45:35.689265
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import namedtuple

    from jedi import Interpreter

    from thonny import ui_utils

    sys_path = ["/path/to/foo.py"]

    # no exception if jedi class Interpreter has no attribute completions
    try:
        Interpreter.completions.__delete__(Interpreter)
    except AttributeError:
        pass

    # older jedi with completions

# Generated at 2022-06-12 12:45:42.697114
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock
    from jedi.api.classes import Completion

    p = MagicMock()
    p.complete.return_value = [Completion("my_completion", Mock(), Mock(), Mock())]
    completions = get_interpreter_completions("", [{}], sys_path=None)
    assert completions[0].name == "my_completion"



# Generated at 2022-06-12 12:45:53.193669
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, mock
    import jedi
    import unittest

    TestCase.assertIn = TestCase.assertIn if hasattr(TestCase, "assertIn") else TestCase.assertTrue

    class TestJedi(TestCase):
        @mock.patch("jedi.Interpreter.__init__")
        def test_without_sys_path(self, init_func):
            init_func.return_value = None
            completions = get_interpreter_completions("dict()", [], None)
            TestCase.assertIn("copy", completions[0].complete)

        @mock.patch("jedi.Interpreter.__init__")
        def test_with_sys_path(self, init_func):
            init_func.return_value = None

# Generated at 2022-06-12 12:46:13.793534
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import Interpreter
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import builtin
    from jedi.api.helpers import infer
    import jedi

    env = get_default_environment()
    interpreter = Interpreter(env.get_cached_code(), [builtin.get_namespace()])
    completion = infer(interpreter, "datetime.")[0]
    assert completion.name == "datetime", completion.name

    if jedi.__version__[:3] in ["0.1", "0.2", "0.3", "0.4"]:
        return

    completion = infer(interpreter, "datetime.date")[0]
    assert completion.name == "date", completion.name
    completion

# Generated at 2022-06-12 12:46:14.384620
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:46:22.406978
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if jedi.__version__ >= '0.16':
        assert get_script_completions(
            'import sys; sys.path.append("")\n'
            's = "ex"\n'
            's.',
            2, 6, "t.py") == [ThonnyCompletion(name='expandtabs', complete='expandtabs(', type='function', description='S.expandtabs([tabsize]) -> str', parent='str'), ThonnyCompletion(name='endswith', complete='endswith(', type='function', description='S.endswith(suffix[, start[, end]]) -> bool', parent='str')]


# Generated at 2022-06-12 12:46:34.307052
# Unit test for function get_script_completions
def test_get_script_completions():
    
    import jedi
    from jedi.parser_utils import get_statement_of_position
    source = "import sys\n import re\n import socket\n\nre."
    row = 5
    column = 4
    completions = get_script_completions(source, row, column, '')
    print(completions)
    result = jedi.Script(source).completions()
    print(result)
    completions = get_interpreter_completions(source, [])
    print(completions)
    if _using_older_jedi(jedi):
        print('Using older jedi')
        result = jedi.Interpreter(source).completions()
    else:
        print('Using newest jedi')
        result = jedi.Interpreter(source).complete()

# Generated at 2022-06-12 12:46:42.926830
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test(self):
            completions = get_interpreter_completions(
                source="import pygame\npygame.locals.",
                namespaces=[{"pygame": "pygame"}, {"pygame.locals": "pygame.locals"}],
            )
            self.assertEqual(len(completions), 28)
            self.assertEqual(completions[0].name, "K_0")
            self.assertEqual(completions[0].complete, "K_0")
            self.assertEqual(completions[0].type, "int")
            self.assertEqual(completions[0].description, "pygame.locals.K_0")
            self

# Generated at 2022-06-12 12:46:50.153339
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("import random; ra", [{}])[0]["complete"] == "random."
    assert get_interpreter_completions("import random; ra", [{}])[0]["name"] == "random."

    assert get_interpreter_completions("random.randint", [{}])[0]["complete"] == "random."
    assert get_interpreter_completions("random.randint", [{}])[0]["name"] == "random."

# Generated at 2022-06-12 12:46:51.958898
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions(source="", row=0, column=0, filename="")

# Generated at 2022-06-12 12:47:00.552185
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def get_completions(source):
        namespaces = [
            {
                "__builtins__": {
                    "sum": sum,
                    "globals": globals,
                    "__import__": __import__,
                },
                "__name__": "__main__",
                "__doc__": None,
                "__package__": None,
            }
        ]
        return get_interpreter_completions(source, namespaces)

    assert get_completions("sum") == []

# Generated at 2022-06-12 12:47:09.411882
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from itertools import islice

    # jedi 0.15
    result = get_script_completions(
        source="i=5\nif i == 5:\n    print(i)", row=2, column=4, filename=""
    )
    assert len(result) == 1
    assert result[0] == ThonnyCompletion(
        name="print",
        complete="print",
        type="statement",
        description="print(value, ..., sep=' ', end='\\n', file=sys.stdout, flush=False)",
        parent="compiled",
        full_name="print",
    )

    # jedi 0.16

# Generated at 2022-06-12 12:47:17.811135
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import builtins as builtinModule
    autocomp = get_interpreter_completions('',[{'locals': locals(), 'globals': globals(), 'builtins': builtinModule}])
    assert isinstance(autocomp, list)
    assert len(autocomp) > 0
    for it in autocomp:
        assert it['type'] == 'name' or it['type'] == 'function' or it['type'] == 'class'
        assert isinstance(it['name'], str) and isinstance(it['complete'], str) and isinstance(it['type'], str)

if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:47:38.359680
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "test"))
    import interp_test_mod

    # test1
    result = get_interpreter_completions(
        "interp_test_mod.test1().",
        namespaces=[{"test1": interp_test_mod.test1}],
        sys_path=[os.path.dirname(os.path.abspath(__file__))],
    )
    assert len(result) == 2
    assert result[0].name == "var1"
    assert result[0].complete == "var1"
    assert result[0].type == "instance"
    assert result[0].description == "var1 (int)"

# Generated at 2022-06-12 12:47:48.714233
# Unit test for function get_definitions
def test_get_definitions():
    import re
    import unittest
    import textwrap

    SOURCE = textwrap.dedent(
        r"""
    class Foo:
        pass

    print(Foo)
    """
    )

    result = get_definitions(SOURCE, 3, 7, "dummy.py")
    # print("Got:" + str(result))
    # jedi version 0.13:
    # Script(source=SOURCE, line=3, column=7, source_path='dummy.py').goto_definitions()
    # [<Name: Foo>, <Class: Foo>]
    # jedi version 0.18:
    # Infer(source=SOURCE, line=3, column=7, source_path='dummy.py').infer()
    # [<Name: Foo>, <Class: Foo>]

# Generated at 2022-06-12 12:47:57.068163
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest.mock as mock
    import jedi

    _jedi = mock.MagicMock()
    _jedi.__version__ = "0.17.1"

    def _mock_jedi_script_completions(source, row, col, filename):
        if filename.endswith("completions.py"):
            if row == 1 and col == 5:
                assert source[row - 1][col - 1] == "F"
                return ["FooBar()", "FooBar1(", "FooBar2", "FooBar3()"]
            # elif row == 2 and col == 6:
            #     assert source[row - 1][col - 1] == "E"
            #     return ["EError()", "EError1", "EError2(", "EE

# Generated at 2022-06-12 12:48:08.492251
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso import parse
    import jedi
    from jedi.evaluate.names import NamespaceName
    from jedi.evaluate.context import ModuleContext

    def test_namespace_name(node, name, completions):
        """Returns True if completions in 'completions' are present in completions for
        namespace 'name' in node"""
        namespace = ModuleContext(NamespaceName(name), node)
        got_completions = []
        for completion in get_interpreter_completions(
            source="", namespaces=[namespace.get_namespace_vars()]
        ):
            got_completions.append(completion["name"])

        return got_completions == completions


# Generated at 2022-06-12 12:48:12.999267
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Interpreter

    jedi.api.Interpreter = get_script_completions
    script = jedi.Script("import os.path; os.pa", 1, 12, "test.py")
    completions = script.completions()
    assert any(x.name == "path" for x in completions)
    jedi.api.Interpreter = Interpreter

# Generated at 2022-06-12 12:48:14.620225
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("int", 0, 3, "")[0].module_path == 'builtins'



# Generated at 2022-06-12 12:48:22.949631
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import jedi

    # test behavior with Jedi < 0.18
    assert _using_older_jedi(jedi)

    completions = get_script_completions(
        "import sys", row=0, column=7, filename="test.py", sys_path=sys.path
    )
    assert len(completions) > 0
    assert completions[0].name == "sys"

    completions = get_script_completions(
        "sys.", row=0, column=4, filename="test.py", sys_path=sys.path
    )
    assert len(completions) > 0
    assert completions[0].name == "version"

# Generated at 2022-06-12 12:48:34.027819
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest.mock

    completions = get_script_completions('"Pi".form', 0, 5, '/tmp/test.py')
    assert len(completions) > 0
    assert completions[0]["name"] == "format"
    assert completions[0]["complete"] == "format("

    # using newer jedi
    with unittest.mock.patch("jedi.__version__", new="0.18.0"):
        # plain
        completions = get_script_completions('"Pi".form', 0, 5, '/tmp/test.py')
        assert len(completions) > 0
        assert completions[0]["name"] == "format"
        assert completions[0]["complete"] == "format("

        # with project
        completions = get_

# Generated at 2022-06-12 12:48:38.753862
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "\nimport pymysql as my\nmy.con"

    expected = [
        ThonnyCompletion(
            name='"pymysql.connections"',
            complete='"pymysql.connections"',
            type='module',
            full_name='pymysql.connections',
            parent=None,
            description=None,
        ),
        ThonnyCompletion(
            name='connect',
            complete='connect',
            type='function',
            full_name='pymysql.connections.connect',
            parent='pymysql.connections',
            description=None,
        ),
    ]

    assert get_interpreter_completions(source, [], sys_path=None) == expected



# Generated at 2022-06-12 12:48:45.936595
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    if sys.version_info[:2] >= (3, 6):
        namespaces = [{'__builtins__': jedi.Interpreter("", []).builtins.__dict__}]
        completions = get_interpreter_completions("import time, time as tim", namespaces)
        assert len(completions) == 3, "len(completions) is %d" % len(completions)
        assert completions[0].name == "time"
        assert completions[1].name == "time="

# Generated at 2022-06-12 12:49:13.946370
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    if _using_older_jedi(__import__("jedi")):
        return

    source = "\"\"\"\nDocstring\n\"\"\"\ndef foo(a, b, c) -> Tuple[int, int]:\n    pass\nfoo(1,"

    namespaces = [
        {"type": "module", "name": "__main__", "start_pos": (1, 0), "end_pos": (100, 0)}
    ]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    assert completions[0].type == "function"
    assert completions[1].type == "statement"



# Generated at 2022-06-12 12:49:14.778160
# Unit test for function get_definitions

# Generated at 2022-06-12 12:49:20.683715
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    old = _using_older_jedi(jedi)
    assert (not old) == (get_definitions('from random import randint\nrandint(1,2)', 1, 0, '')[0].line == 1)
    assert (old) == (get_definitions('from random import randint\nrandint(1,2)', 1, 0, '')[0].line == 4)

# Generated at 2022-06-12 12:49:30.232596
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    from thonny.misc import running_on_linux
    
    if (running_on_linux()):
        jedi_test_file = os.path.join(os.path.dirname(__file__), 'jedi_test.py')
        with open(jedi_test_file, "r") as fp:
            source = fp.read()
        row,column = 3, 9
        definitions = get_definitions(source, row, column, jedi_test_file)
        assert len(definitions) == 1
        assert definitions[0].line == 1
        assert definitions[0].column == 1
        assert definitions[0].module_path == jedi_test_file
        assert definitions[0].module_name == 'jedi_test'

# Generated at 2022-06-12 12:49:41.294006
# Unit test for function get_script_completions
def test_get_script_completions():
    from typing import List

    completions = get_script_completions(
        "import numpy as np\nnp.\n",
        3, 5, "", ["/Users/martin/Library/Python/3.7/lib/python/site-packages/numpy"]
    )
    assert len(completions) > 0, completions

    completions = get_script_completions(
        "import numpy as np\nnp.\n",
        3, 5, "", ["/Users/martin/Library/Python/3.7/lib/python/site-packages/numpy"]
    )
    assert len(completions) > 0, completions


# Generated at 2022-06-12 12:49:47.374194
# Unit test for function get_definitions
def test_get_definitions():
    logger.info("Running get_definitions test")
    import jedi

    defs = get_definitions("import datetime; datetime.", 1, 14, "")
    if jedi.__version__[:4] == "0.17":
        logger.info("get_definitions works with single result")
        assert len(defs) == 1
    else:
        logger.info("get_definitions works with multiple results")
        assert len(defs) > 1
        assert isinstance(defs, list)


if __name__ == "__main__":
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.WARN)
    test_get_definitions()

# Generated at 2022-06-12 12:49:52.504747
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python.tree import Module

    mod = Module("a = \"a\"", "<module>")
    namespaces = [{"foo": mod}]
    comps = get_interpreter_completions("foo.", namespaces)
    assert len(comps) == 1
    assert comps[0].name == "a"
    assert comps[0].complete == "a"
    assert comps[0].description == "str"
    assert comps[0].parent == mod
    assert comps[0].full_name == "a"
    assert comps[0].type == "statement"


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:50:01.301601
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    from thonny.jedi_utils import _using_older_jedi
    source = "import json\njson.dumps(None)"
    completions = get_script_completions(source, 2, 13, "my_file.py")
    assert sorted(c.complete for c in completions) == ["default", "encoding", "sort_keys"]
    if _using_older_jedi(None):
        assert sorted(c.description for c in completions) == [
            "default(...",
            "encoding=..., default=...)",
            "sort_keys=..., default=...)",
        ]

# Generated at 2022-06-12 12:50:02.774536
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    script = jedi.Script("",0,0,"")
    print(script)

# Generated at 2022-06-12 12:50:12.038413
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions("""\
import os
os.path""", [{},{}])
    assert isinstance(completions, list)

    # make sure get_interpreter_completions handles old and new jedi API
    jedi.Interpreter = lambda *args, **kwargs: None
    get_interpreter_completions("""\
import os
os.path""", [{},{}])
    jedi.Interpreter.complete = lambda *args, **kwargs: None
    get_interpreter_completions("""\
import os
os.path""", [{},{}])
    jedi.Interpreter.completions = lambda *args, **kwargs: None

# Generated at 2022-06-12 12:50:41.873646
# Unit test for function get_definitions
def test_get_definitions():
    import os

    path = os.path.join(
        os.path.dirname(__file__), "_test_data", "get-definitions-results", "jedi_17"
    )
    with open(path) as fp:
        expected_lines = fp.readlines()

    for i in range(len(expected_lines)):
        if "\\n" in expected_lines[i]:
            expected_lines[i] = expected_lines[i].replace("\\n", "\n")

    source = """import sys
import unittest
import threading
import PySide2.QtCore
    """
    defs = get_definitions(source, 3, 11, "/tmp/aaa.py")
    actual = []

# Generated at 2022-06-12 12:50:46.141221
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import"
    completions = get_interpreter_completions(
        source, namespaces=[jedi.Interpreter([], []).namespace]
    )
    assert completions[0].name == "importlib"


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:50:56.558559
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # import jedi

# Generated at 2022-06-12 12:50:57.788338
# Unit test for function get_definitions
def test_get_definitions():
    print(get_definitions("os.path", 0, 0, "myfile.py"))

# Generated at 2022-06-12 12:51:03.667410
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import tkinter as tk
    from idlelib.colorizer import ColorDelegator
    
    work_dir = os.path.join(os.path.dirname(__file__), "..")
    sys_path = [work_dir]
    namespaces = [{"tkinter": tk, "ColorDelegator": ColorDelegator}]
    source = "tkinter.Tk()."
    line = 1
    column = len(source)
    completions = get_script_completions(source, line, column, "", sys_path)
    for completion in completions:
        pass



# Generated at 2022-06-12 12:51:11.752048
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import threading\nthreading.Th"
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    namespaces = [{"name": "__main__", "path": "<input>"}]
    completions = get_interpreter_completions(source=source, namespaces=namespaces)
    assert completions[0].name == "Thread"
    assert completions[0].description == "Thread(group=None, target=None, name=None, args=(), kwargs={}, *, daemon=None)"

# Generated at 2022-06-12 12:51:19.964412
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
x = "aaa"
y = "bbb"

x.
y.
"""
    namespaces = [{
        "x": "aaa",
        "y": "bbb",
    }]

    completions = get_interpreter_completions(source, namespaces)

    # Check that x. and y. can be found
    assert completions

    # Check that there are completions for x
    assert "x." in [comp.name for comp in completions]

    # Check that there are completions for y
    assert "y." in [comp.name for comp in completions]

    # Only one x. and one y. should have been found
    assert "x." not in [comp.name for comp in completions[1:]]

# Generated at 2022-06-12 12:51:29.137602
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    # Old jedi
    c1 = Completion(name="pow", complete="pow", type="func", description="pow(x, y)", parent="", full_name="")
    c2 = Completion(name="print", complete="print", type="func", description="print(value, ...)", parent="", full_name="")
    completions = [c1, c2]

    expected = [
        ThonnyCompletion(name="pow", complete="pow", type="func", description="pow(x, y)", parent="", full_name=""),
        ThonnyCompletion(name="print", complete="print", type="func", description="print(value, ...)", parent="", full_name="")
    ]


# Generated at 2022-06-12 12:51:35.848883
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.interpreter import Interpreter
    global script, namespaces
    script = Interpreter("[x for x in range(5)]", [{}])
    namespaces = script.get_namespaces()
    global completions
    completions = get_script_completions(
        """import os
os.stat("")
""",
        1,
        5,
        "test.py"
    )
    assert len(completions) > 0, "get_script_completions missing"



# Generated at 2022-06-12 12:51:37.453354
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions('min', 0, 2, "")


# Generated at 2022-06-12 12:52:08.327801
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("x.c", [], sys_path=[]) == []
    assert get_interpreter_completions("x.c", [{"x": 1}], sys_path=[]) == []
    assert get_interpreter_completions("x.", [{"x": 1}], sys_path=[]) == []
    assert get_interpreter_completions("x.", [{"x": 1}], sys_path=[]) == []
    assert get_interpreter_completions("x.c", [{"x": object()}], sys_path=[]) == []
    assert get_interpreter_completions("x.", [{"x": object()}], sys_path=[]) == []

    # No completions for unknown modules

# Generated at 2022-06-12 12:52:19.467382
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.completion_db import get_completions, get_script_completions
    from unittest.mock import Mock

    def _get_completions(source: str, row: int, column: int, filename: str, sys_path=None):
        completions = get_script_completions(source, row, column, filename, sys_path)
        return [c.name for c in completions]

    # Mock `get_completion_calls` and `get_completions` for 200+ lines
    # to save time in testing
    mock_get_completions = Mock(get_completions, side_effect=_get_completions)
    get_script_completions.get_completions = mock_get_completions
    get_script_completions

# Generated at 2022-06-12 12:52:26.673650
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.python_shell import _get_completions
    # import jellyfish
    # from unittest.mock import patch


# Generated at 2022-06-12 12:52:34.574908
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def check(source, expected_results):
        results = get_interpreter_completions(source, [{}, {}])
        assert isinstance(results, list)
        assert results
        assert isinstance(results[0], dict)
        assert set(results[0].keys()) == {"name", "complete", "type", "description", "parent",
                                          "full_name"}
        assert len(results) == len(expected_results)
        assert [tuple(r) for r in results] == expected_results

    # check that '=' is present in name for argument completions

# Generated at 2022-06-12 12:52:43.744649
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    completions = get_script_completions("print('''", 1, 8, "")

    if jedi.__version__[:4] in ["0.13", "0.14"]:
        assert completions == [
            ThonnyCompletion(
                name="print",
                complete="print",
                type="statement",
                description="print(value, ..., sep=' ', end='\\n', file=sys.stdout, flush=False)",
                parent=None,
                full_name="print",
            )
        ]

# Generated at 2022-06-12 12:52:54.327349
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from jedi.api.classes import Completion

    namespaces = [{"x": "1"}]

    mock_completion = Mock(Completion)
    mock_completion.name = "foo"
    mock_completion.complete = "foo"
    mock_completion.type = ""
    mock_completion.description = None
    mock_completion.full_name = None
    mock_completion.parent = None

    # up to jedi 0.17
    result = [mock_completion]
    assert get_interpreter_completions("foo", namespaces) == result

    # from jedi 0.18
    result = {(0, 0): [mock_completion]}

# Generated at 2022-06-12 12:52:58.561435
# Unit test for function get_definitions
def test_get_definitions():
    # regression test for https://bitbucket.org/plas/thonny/issues/1613/jedi-returns-incorrect-definitions
    source = """
    class A():
        pass
    a = A()
    a.b
    """
    definitions = get_definitions(source, 4, 1, filename="a.py")
    assert definitions[0].docstring() == "(A instance) b = None\n"

# Generated at 2022-06-12 12:53:03.551955
# Unit test for function get_definitions
def test_get_definitions():
    source = """
import math

from math import sqrt

sqrt(2)
    """
    script = get_definitions(source, row=5, column=7, filename="test.py")
    assert script
    assert len(script) == 2
    assert script[0]._name == "math.sqrt"
    assert script[1]._name == "numpy.lib.scimath.sqrt"



# Generated at 2022-06-12 12:53:12.658403
# Unit test for function get_definitions
def test_get_definitions():
    from unittest.mock import Mock
    from jedi.api import classes

    class _ClassDef(Mock):
        type = "statement"
        name = "C"
        start_pos = (2, 3)
        end_pos = (3, 4)
        raw_doc = ""

        def __init__(self):
            super().__init__()

        def get_parents(self):
            return []  # without this jedi.api raises TypeError

    class_def = _ClassDef()

# Generated at 2022-06-12 12:53:19.855445
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso


    def namespaces_from_node(module):
        from jedi import Interpreter


        class _Namespace(object):
            pass

        ns = _Namespace()

        for stmt in module.iter_classes():
            setattr(ns, stmt.name.value, stmt.name.value)

        for stmt in module.iter_funcdefs():
            setattr(ns, stmt.name.value, stmt.name.value)

        for stmt in module.iter_imports():
            for name in stmt.get_defined_names():
                setattr(ns, name.value, name.value)


# Generated at 2022-06-12 12:53:50.428143
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso
    import jedi.evaluate.compiled
    import sys

    code = """
import sys
sys.argv
"""

    module = parso.parse(code)
    script = jedi.Script(code=code, path="<stdin>")
    completions = script.complete(line=2, column=9)
    assert completions[0].name == "argv"
    assert completions[0].complete == "argv"
    assert completions[0].description == "sys.argv\n"
    assert completions[0].type == "attribute"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.argv"

    # check class attributes

# Generated at 2022-06-12 12:53:55.378311
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from jedi import Script
    import os
    import sys

    sys_path = sys.path.copy()
    sys_path.insert(0, os.path.join(os.path.dirname(__file__), "testdata"))

    comp = get_interpreter_completions("from testdata import *", [], sys_path)
    assert "submodule_from_testdata" in [c.name for c in comp]
    assert "function_from_testdata" in [c.name for c in comp]
    assert "class_from_testdata" in [c.name for c in comp]
    assert "OLD_global" in [c.name for c in comp]
    

# Generated at 2022-06-12 12:53:59.239504
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # test data
    source = "import pandas as pd"
    namespaces = [{"pd": {}}]
    # call function and get result
    completions = get_interpreter_completions(source, namespaces)
    # assert
    assert completions != []
    assert all(type(item) == ThonnyCompletion for item in completions)

# Generated at 2022-06-12 12:54:08.072060
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os.path
    from jedi._compatibility import is_py33

    from_path = os.path.dirname(os.path.realpath(sys.argv[0]))
    sys.path.append(from_path)
    test_file = "test_get_definitions.py"
    with open(test_file, "w") as f:
        f.write("def f():\n    pass\n\nclass C:\n    def g(self):\n        pass\n")

    def test_case(line, column, expected):
        res = get_definitions(source, line, column, test_file)
        if is_py33:
            res = list(res)

        assert len(res) == len(expected)