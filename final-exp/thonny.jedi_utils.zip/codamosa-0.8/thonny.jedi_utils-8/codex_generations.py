

# Generated at 2022-06-12 12:44:37.913212
# Unit test for function get_script_completions
def test_get_script_completions():
    print("get_script_completions")
    from jedi import Script as jediScript

    source = "import sys\n" "sys.std"
    row, column = 1, 11
    filename = "<untitled>.py"
    sys_path = ["."]

    script = get_script_completions(source, row, column, filename, sys_path)
    orig_script = jediScript(source, row, column, filename)
    print("script: ")
    print(script)
    print("orig_script: ")
    print(orig_script.completions())

# Generated at 2022-06-12 12:44:44.848702
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os
    import jedi

    def test(source, row, column, sys_path, expected_completion_names):
        filename = os.path.join(os.path.dirname(__file__), "test_get_completions.py")
        completions = get_script_completions(
            source, row, column, filename, sys_path=sys_path
        )
        assert [c.name for c in completions] == expected_completion_names

    def _test_with_no_import_completions(
        source, row, column, sys_path, expected_completion_names
    ):
        if jedi.__version__ >= "0.17":
            test(source, row, column, sys_path, expected_completion_names)
        else:
            test

# Generated at 2022-06-12 12:44:50.212991
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    namespaces = [{"x": "hello"}]
    completions = get_interpreter_completions("x", namespaces)
    assert completions[0].name == completions[0].complete == "x"
    assert completions[0].description == "str"

# Generated at 2022-06-12 12:44:56.802655
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python.tree import Leaf
    
    def query_result_from_completions(completions):
        from jedi.api.classes import Completion
        import parso.python.tree as jedi_parse
        
        def get_completion_parent(comp):
            if not isinstance(comp, Completion):
                raise ValueError(f"Expected Completion, got {comp}")
            try:
                return get_completion_parent(comp.parent()).name
            except:  # noqa
                return ""

        def get_completion_full_name(comp):
            if not isinstance(comp, Completion):
                raise ValueError(f"Expected Completion, got {comp}")

# Generated at 2022-06-12 12:44:58.839901
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import cut_code


# Generated at 2022-06-12 12:44:59.857105
# Unit test for function get_definitions

# Generated at 2022-06-12 12:45:08.915082
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions
    from thonny.misc_utils import running_on_windows

    namespaces = [
        # Mocking environment
        {
            "os": {
                "environ": {
                    "HOME": "/home/testuser",
                    "PATH": "/usr/bin:/bin",
                }
            }
        },
        # Mocking stdin and stdout
        {
            "__stdin__": "stdin",
            "__stdout__": "stdout",
            "__name__": "__main__"
        },
    ]

    completions = get_interpreter_completions("pr", namespaces)

    assert len(completions) == 3
    assert "print" in [c.name for c in completions]

# Generated at 2022-06-12 12:45:17.326741
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from parso.python import tree

    def create_test_script(source, row, column, filename, sys_path=None):
        if _using_older_jedi(jedi):
            try:
                script = jedi.Script(source, row, column, filename, sys_path=sys_path)
            except Exception as e:
                logger.info("Could not get completions with given sys_path", exc_info=e)
                script = jedi.Script(source, row, column, filename)
            return script
        else:
            script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))
            return script


# Generated at 2022-06-12 12:45:22.395231
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # check that there are no superfluous completions
    # and that function name ends with "="
    completions = get_interpreter_completions(
        "import sys", [{"name": "sys", "module": sys, "is_namespace": False}]
    )
    assert len(completions) > 0
    assert completions[0].complete.endswith("=")

# Generated at 2022-06-12 12:45:32.275592
# Unit test for function get_script_completions
def test_get_script_completions():
    # First try with older jedi (0.16)
    import tempfile
    import sys
    from thonny.config import get_workbench

    get_workbench().set_option("editor.real_jedi_path", None)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_file = temp_dir + "/test.py"
        with open(temp_file, "w") as f:
            f.write("a = 'some string'\n")

        completions = get_script_completions(
            source="a.", row=0, column=2, filename=temp_file, sys_path=[temp_dir]
        )
        assert len(completions) == 1
        assert completions[0].name == "capitalize"

# Generated at 2022-06-12 12:45:55.287391
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("import sys", 0, 7, "")
    assert len(result) == 1
    assert result[0].name == "sys"
    assert result[0].complete == "sys."
    assert result[0].type == "module"

    result = get_script_completions("import sys", 0, 7, "", sys_path=["/home/foo"])
    assert len(result) == 1
    assert result[0].name == "sys"
    assert result[0].complete == "sys."
    assert result[0].type == "module"

    result = get_script_completions(
        "import sys; sys.getdef", 1, 12, "", sys_path=["/home/foo"]
    )
    assert len(result) == 1

# Generated at 2022-06-12 12:46:07.040436
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("int(", [{"a": "b"}]) == []
    assert get_interpreter_completions("int()", [{"a": "b"}]) == []
    assert set(x.name for x in get_interpreter_completions("a.", [{"a": "b"}])) == {"a"}
    assert (
        set(x.name for x in get_interpreter_completions("int(", [{"int": "b"}])) == {"b"}
    )
    assert (
        set(x.name for x in get_interpreter_completions("int()", [{"int": "b"}])) == {"b"}
    )

# Generated at 2022-06-12 12:46:14.089887
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import random

    code="""
import random
random.ch"""

    completions = get_interpreter_completions(code, [{}])
    assert "choice" in [item["name"] for item in completions]

    code="""
import random
random.ch"""

    completions = get_interpreter_completions(code, [{'random': random}])
    assert "choice" in [item["name"] for item in completions]

# Generated at 2022-06-12 12:46:17.892157
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = 'from math import ce'
    completions = get_interpreter_completions(source, [])
    assert completions == _tweak_completions(jedi.Interpreter(source, [], cache=False).complete())

# Generated at 2022-06-12 12:46:24.198695
# Unit test for function get_definitions
def test_get_definitions():
    source = "assert False, 'test'\n"
    source += "def f(x):\n"
    source += "    return x.upper()\n"
    source += "f('a')\n"

    filename = "test.py"

    definition = get_definitions(source, 2, 15, filename)[0]

    assert definition.line == 1 and definition.column == 5
    assert definition.module_path == filename



# Generated at 2022-06-12 12:46:36.235447
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test set up
    import sys
    import os
    from thonny.misc import running_on_ci
    from thonny.config import get_python_executable

    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_dir = os.path.join(root_dir, "tests")
    env_path = os.path.join(test_dir, "venv") if not running_on_ci() else None
    sys_path = [os.path.join(root_dir, "lib")]
    if env_path:
        sys_path.append(os.path.join(env_path, "lib"))
        sys_path.append(os.path.join(env_path, "lib", "python3.8"))

# Generated at 2022-06-12 12:46:40.721227
# Unit test for function get_script_completions
def test_get_script_completions():
    # older jedi
    completions = get_script_completions(
        "import sys\n import \nimport sys", 1, 7, "untitled"
    )
    assert len(completions) == 1
    assert completions[0].name == "sys"

    # 0.17

# Generated at 2022-06-12 12:46:41.242522
# Unit test for function get_definitions

# Generated at 2022-06-12 12:46:51.457879
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _thonny import get_workbench

    wb = get_workbench()
    backend_python_exe = wb.get_system_python()
    if not backend_python_exe:
        logger.warning("Failed testing completions")
        return

    from subprocess import Popen, PIPE

    completed_names = set()


# Generated at 2022-06-12 12:46:58.695930
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    if _using_older_jedi(jedi):
        source = "import sys as a\na"
        row=1
        column=8
    else:
        source = "import sys as a\nprint(a)"
        row=1
        column=9
    definitions=get_definitions(source, row, column, "test")
    assert definitions[0].name == "sys"
    assert definitions[0].full_name == "sys"
    assert definitions[0].line == 0
    assert definitions[0].column == 0
    assert definitions[0].type == "module"

# Generated at 2022-06-12 12:47:22.207820
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    js = jedi.Interpreter("import os\nos.", [{"os": jedi.Interpreter("", [])}])
    result = get_interpreter_completions("import os\nos.", [{"os": jedi.Interpreter("", [])}])
    assert result == _tweak_completions(js.completions())


# Generated at 2022-06-12 12:47:24.884911
# Unit test for function get_definitions
def test_get_definitions():
    # TODO: some tests
    return



# Generated at 2022-06-12 12:47:30.672664
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.support.jedi_mock_jedi import jedi

    jedi.Interpreter.complete = lambda self: [
        ThonnyCompletion("a", "a", "a", "a", "a", "a"),
        ThonnyCompletion("b", "b", "b", "b", "b", "b"),
    ]
    assert get_interpreter_completions("asdf", [{}], []) == [
        ThonnyCompletion("a", "a", "a", "a", "a", "a"),
        ThonnyCompletion("b", "b", "b", "b", "b", "b"),
    ]



# Generated at 2022-06-12 12:47:41.190709
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    class MyNamespace:
        pass

    source = "__n"
    namespaces = [MyNamespace()]

    def _test_output(expected):
        completions = get_interpreter_completions(source, namespaces)
        assert [c.name for c in completions] == expected

    # these are built-in names for which we expect completions
    _test_output(["__name__", "__import__", "__package__", "__loader__", "__spec__"])

    # these are built-in names for which we expect no completions
    for name in ["__file__", "__cached__"]:
        # when the name is already defined, then there should be no completions
        setattr(namespaces[0], name, None)
        _test_output([])


# Generated at 2022-06-12 12:47:50.993530
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso
    from parso.python import tree

    def get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def check(source, row, column, completions):
        completions_at_pos = get_completions(source, row, column, "editor.py")
        names = [comp.name for comp in completions_at_pos]
        wrong = [comp for comp in names if not comp in completions]
        if wrong:
            raise ValueError("Unexpected completions for %s: %s" % (source, wrong))
        missing = [comp for comp in completions if not comp in names]

# Generated at 2022-06-12 12:47:56.037056
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert 'a = 1' in get_interpreter_completions("a=1", [{}])[0].complete
    assert 'b = 2' in get_interpreter_completions("import math\nb=2", [{}, {}])[1].complete
    assert 'c = 3' in get_interpreter_completions("from math import *\nc=3", [{}, {}])[1].complete


# Generated at 2022-06-12 12:48:07.584295
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("def foo():\n    pass\n\nfoo", 1, 0, "") == []
    assert get_script_completions("def foo():\n    pass\n\nfoo(", 3, 5, "") == []

    completions = get_script_completions("def foo():\n    pass\n\nfoo(", 3, 4, "")
    assert completions == [ThonnyCompletion(name='()', complete='()', type='function',
            description='foo()', parent='', full_name='foo()')]

    completions = get_script_completions("from os import fo", 1, 0, "")

# Generated at 2022-06-12 12:48:14.371356
# Unit test for function get_definitions
def test_get_definitions():
    # This should fail without the correct line/col mapping
    # See https://github.com/davidhalter/jedi/issues/1902
    from unittest.mock import patch

    with patch("thonny.plugins.jedi_utils._get_new_jedi_project") as mock_jedi:
        results = get_definitions("import numpy; numpy.ma.arange(1)", 8, 0, "test_get_definitions_jedi.py")

    mock_jedi.assert_called_once_with(["/test/directory"])
    assert len(results) == 1



# Generated at 2022-06-12 12:48:15.593936
# Unit test for function get_definitions

# Generated at 2022-06-12 12:48:24.837533
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    from jedi import Interpreter
    from jedi.api.classes import Completion

    if not _using_older_jedi(Interpreter):
        return

    # Version before 0.18
    code = 'import collections\nd = collections.OrderedDict()\nd["'
    completions1 = get_interpreter_completions(code, [], sys_path=[])
    completions2 = get_interpreter_completions(code, [], sys_path=None)
    completions3 = Interpreter(code, [], sys_path=[])
    completions4 = Interpreter(code, [], sys_path=None)
    assert all([isinstance(x, Completion) for x in completions1])

# Generated at 2022-06-12 12:48:45.895196
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'class Foo(object):\n  def __init__(self, a, b):\n    self.a = a\n    self.b = b\nx = Foo(1, "2")\nx.a'
    print(get_script_completions(source, 5, 5))
    print(get_script_completions(source, 5, 6))

# Generated at 2022-06-12 12:48:55.820363
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi._compatibility import use_metaclass

    class _FakeInterpreter(Interpreter, metaclass=use_metaclass(ABCMeta=ABCMeta)):
        def __init__(self, code, namespaces):
            super().__init__(code, namespaces)

        @classmethod
        def builtins(cls):
            return ["__builtins__"]

        def _create_definitions(self, namespaces):
            return [
                JediDefinition(
                    self,
                    None,
                    "__builtins__",
                    None,
                    "Fake type",
                    None,
                    None,
                    False,
                )
            ]


# Generated at 2022-06-12 12:49:05.435086
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    import parso
    from thonny.plugins.jedi_utils import get_interpreter_completions

    # testcase : source, row, col, expected_output

# Generated at 2022-06-12 12:49:11.830954
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test for older versions of jedi
    assert len(get_script_completions("'".split("\n"), 0, 1, "test.py")) == 1
    assert len(get_script_completions("\n".split("\n"), 1, 0, "test.py")) == 1

    # Test for newer version of jedi
    assert len(get_script_completions("'".split("\n"), 0, 1, "test.py")) == 1
    assert len(get_script_completions("\n".split("\n"), 1, 0, "test.py")) == 1

# Generated at 2022-06-12 12:49:23.016696
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    from jedi.api import Interpreter

    path = os.path.join(os.path.dirname(os.getcwd()), "tests")
    code = "impo"
    namespaces = [
        {"type": "module", "name": "tests", "description": "tests", "full_name": "tests"}
    ]
    path.split(os.sep)[:-2]
    sys_path = path.split(os.sep)[:-2]
    location = (path, "test_jedi_utils.py", code, 0, len(code))
    interpreter = Interpreter(code, namespaces, sys_path=sys_path)
    completions = interpreter.completions()

    print("jedi>=0.17.0")

# Generated at 2022-06-12 12:49:31.723999
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from thonny.jedi_utils import get_interpreter_completions

    # The following provides a valid sys_path
    def _get_sys_path(script_dir):
        import os


# Generated at 2022-06-12 12:49:42.621691
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.interpreter import Interpreter


# Generated at 2022-06-12 12:49:49.542975
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import sys

from collections import OrderedDict
from enum import Enum
from functools import reduce
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple, Type, Union, Callable
"""
    result = get_script_completions(
        source, row=2, column=5, filename="c.py", sys_path=["dir1", "dir2"]
    )

    result2 = get_script_completions(
        source, row=2, column=5, filename="c.py", sys_path=["dir1", "dir2"]
    )

    print(result[:10])


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:49:54.688985
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    import sys
    import os

    path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(path)
    sys.path.append(os.path.split(os.path.split(path)[0])[0])
    import common


# Generated at 2022-06-12 12:50:02.002941
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_statement_of_position
    from thonny.plugins.micropython.utils import parse_source

    source = """
    def show_msg(s):
        print(s)

    sh"""
    tree = parse_source(source)
    row = 2
    column = 6
    statements = get_statement_of_position(tree, row, column)

    assert statements.name == "show_msg"


if __name__ == "__main__":
    import os
    import sys

    sys.path.append(os.getcwd())
    test_get_definitions()

# Generated at 2022-06-12 12:50:15.233887
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions('a=5\na.', [])
    a = ThonnyCompletion('append', 'append', 'statement', 'append(object) -> None -- append object to end', 'a', 'a.append') # noqa
    assert completions[0] == a
    assert len(completions) == 99

# Generated at 2022-06-12 12:50:25.215250
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from unittest import TestCase

    class ModuleMock:
        def __init__(self, name):
            self.__name__ = name

    class Namespace:
        def __init__(self, module):
            self.get_root_context = Mock()
            self.get_root_context.return_value = module

    class Test(TestCase):
        def test_completions_ok(self):
            module = ModuleMock("hello.world")
            namespace = Namespace(module)

            completions = get_interpreter_completions("", [namespace])
            self.assertEqual(
                set([c.complete for c in completions]),
                set(["world", "hello", "hello.world"]),
            )


# Generated at 2022-06-12 12:50:33.062503
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_script = "import sys\nimport json\njson."
    ns = [
        {"docstring": "namespace for sys (built-in)", "description": "module 'sys'", "name": "sys"},
        {"docstring": "namespace for json (built-in)", "description": "module 'json'", "name": "json"},
    ]
    completions = get_interpreter_completions(test_script, ns)
    assert [c.name for c in completions] == ["dump", "dumps", "load", "loads"]


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:50:42.493306
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from types import ModuleType
    from unittest.mock import patch

    import jedi

    __name__ = "__main__"
    __builtins__ = ModuleType("__builtins__")
    __builtins__.__dict__["c"] = 3
    __builtins__.__dict__["a"] = 2
    __builtins__.__dict__["b"] = 1

    # See if completions are returned in alphabetical order
    with patch.object(jedi, "__version__", "0.13"):
        assert get_interpreter_completions("a", [__builtins__.__dict__])[0].name == "a"
        assert get_interpreter_completions("a", [__builtins__.__dict__])[1].name == "b"
        assert get_inter

# Generated at 2022-06-12 12:50:52.530450
# Unit test for function get_script_completions
def test_get_script_completions():
    def check_completions(script, row, col, expected_completions, sys_path=None):
        completions = get_script_completions(script, row, col, "tmp.py", sys_path)
        actual = [c.name for c in completions]
        if actual != expected_completions:
            print("Completions:", completions)
            print("Expected:", expected_completions)
            raise AssertionError("Incorrect completions: " + repr(actual))

    check_completions("import datetim", 1, 6, ["date", "datetime"])
    check_completions("import datetime\ndatetime.", 1, 100, ["datetime"])

# Generated at 2022-06-12 12:51:00.323938
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from unittest.mock import MagicMock

    # test that jedi.Script was called with correct project
    sys_path = ["/home/user/path/"]
    source = "something"
    namespaces = None
    old_script = Mock()
    jedi.Script.return_value = old_script
    old_script.complete = MagicMock()
    old_script.complete.return_value = []

    get_interpreter_completions(source, namespaces, sys_path)

    jedi.Script.assert_called_once_with(source, namespaces, sys_path=sys_path)



# Generated at 2022-06-12 12:51:10.367876
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.parser_utils import get_statement_of_position, split_lines
    from parso.python import tree
    import jedi
    # a simple test
    src = "import collections\ncollections.namedtuple"
    namespaces = []
    comp = get_interpreter_completions(src, namespaces) # jedi >= 0.18 (included)
    assert comp[0].name == 'namedtuple'
    assert comp[0].full_name == 'collections.namedtuple'
    # a test to see if the docstring is evaluated to get the completions
    src = "'''Dummy docstring'''\nprint('abc')"
    namespaces = []
    comp = get_interpreter_completions(src, namespaces) # jedi >= 0.18 (included)

# Generated at 2022-06-12 12:51:17.609605
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    def assertCompletions(namespaces, actual, expected):
        completions = get_interpreter_completions("", namespaces)
        actual = [c.name for c in completions if c.name.startswith(actual)]
        assert actual == expected

    assertCompletions([], "", ["for", "if", "elif"])
    assertCompletions([{"a": 1}], "a", ["a"])
    assertCompletions([{"a": 1}], "A", [])
    assertCompletions(
        [
            {"a1": 1},
            {"a2": 1},
        ],
        "a",
        ["a1", "a2"],
    )

    # Jedi 0.10.2 always returns a list

# Generated at 2022-06-12 12:51:20.885848
# Unit test for function get_definitions
def test_get_definitions():
    source = "import os; os."
    row = 0
    column = len(source)
    filename = "[test]"
    definitions = get_definitions(source, row, column, filename)

    assert definitions
    assert definitions[0].module_name == "os"

# Generated at 2022-06-12 12:51:21.725436
# Unit test for function get_script_completions
def test_get_script_completions():
    assert True, "not implemented yet"

# Generated at 2022-06-12 12:51:40.390008
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """test the function get_interpreter_completions"""
    import types
    import jedi
    if hasattr(types, "FunctionType"):
        completions = get_interpreter_completions("FunctionType", [])
        assert any("FunctionType" == t.name for t in completions)
    else:
        warnings.warn("types.FunctionType not found, execution of test skipped")
    completions = get_interpreter_completions("jedi.Script", [])
    no_attributes = ["__weakref__", "__dict__", "__dict__", "__module__", "__doc__"]
    names = sorted([t.name for t in completions])
    assert jedi.Script.__dict__.keys() == names

# Generated at 2022-06-12 12:51:49.690413
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # NOTE: this test only works if function is not shadowed
    from jedi.api import Interpreter, Script
    import jedi
    from unittest.mock import Mock

    # Test that get_interpreter_completions returns a jedi api compatible list of completions
    # Test completions for function
    completions = get_interpreter_completions("from unittest.mock import Mock; Mock().", [])
    completion_names = {c.name for c in completions}
    assert "side_effect" in completion_names

    # Test completions for builtin
    completions = get_interpreter_completions("list().", [])
    completion_names = {c.name for c in completions}
    assert "append" in completion_names
    assert "count" in completion_names

# Generated at 2022-06-12 12:51:59.292003
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os.path
    import sys

    test_path = os.path.dirname(os.path.abspath(__file__))
    main_path = os.path.join(test_path, "..", "..")
    sys.path.insert(0, os.path.abspath(main_path))
    from thonny.misc_utils import running_on_windows

    if running_on_windows():
        filename = os.path.join(main_path, "thonny", "backend", "thonny_backend.py").replace(
            os.sep, "\\"
        )
    else:
        filename = os.path.join(main_path, "thonny", "backend", "thonny_backend.py")

    completions = get

# Generated at 2022-06-12 12:52:11.277862
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test(self):
            from thonny.plugins.micropython.backend import MicroPythonProxy

            proxy = MicroPythonProxy(None, None)
            interpreters = proxy.find_all_interpreters()
            for interpreter in interpreters:
                res = get_script_completions(
                    'form=Button(text="1", foo=1).pack()',
                    0,
                    15,
                    filename="main.py",
                    sys_path=[interpreter.get_interpreter_path()],
                )
                self.assertTrue(len(res) > 0)

# Generated at 2022-06-12 12:52:14.565924
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions(
        source="x=2;x.", namespaces=[{'x': 2}]
    )
    assert result[0].name == 'mro'

# Generated at 2022-06-12 12:52:22.195215
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    test_source = """
import os
os.path.abspath
os.path.abspath(
"""
    completions = get_interpreter_completions(test_source, [], [])
    assert len(completions) == 1
    assert completions[0].name == 'path'
    assert completions[0].complete == 'path'
    assert not completions[0].type == jedi.api.types.Function
    assert completions[0].description == 'posixpath'
    assert completions[0].parent.module_name == 'os'
    assert completions[0].full_name == 'os.path'

# Generated at 2022-06-12 12:52:25.547395
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.settings.case_insensitive_completion = False
    jedi.settings.add_bracket_after_function = False
    # jedi.settings.use_similar_names = False
    jedi.settings.no_completion_duplicates = True


# Generated at 2022-06-12 12:52:35.529664
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:52:44.550850
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple

    Completion = namedtuple("Completion", "name complete type description parent full_name")
    script_completions = get_script_completions(
        "x = 25\nimport ", 0, 13, ""
    )

# Generated at 2022-06-12 12:52:55.064271
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """Only for local debugging"""
    import json
    import sys
    import os

    conf_file = os.getenv("CONF_PATH", "../conf/conf.json")
    conf = json.load(open(conf_file))

    if "backend_python_interpreter" not in conf:
        print("skipping test because missing conf['backend_python_interpreter']")
        return

    sys.path.insert(0, conf["backend_python_interpreter"])
    import thonny_backend
    import jedi
    os.remove("c.pyc")
    namespaces = [{"__name__": "__main__", "__file__": "c", "thonny_backend": thonny_backend}]
    # noinspection PyUnresolvedReferences
    comple

# Generated at 2022-06-12 12:53:14.686812
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.names import NameWrapper

    # test a completely empty namespace
    namespace = [{}]
    completions = get_interpreter_completions("from os import path", namespace, sys_path=["."])
    assert len(completions) == 4
    assert [c["complete"] for c in completions] == [
        "path",
        "path.exists(",
        "path.isfile(",
        "path.join(",
    ]

    # test with a namespace with os.path
    namespace = [{"path": NameWrapper(["path"], "path")}]
    completions = get_interpreter_completions("from os import path", namespace, sys_path=["."])
    assert len(completions) == 4

# Generated at 2022-06-12 12:53:15.642667
# Unit test for function get_definitions

# Generated at 2022-06-12 12:53:25.991597
# Unit test for function get_definitions
def test_get_definitions():
    def check(source, row, column, expected):
        from jedi import Script, NotFoundError
        from jedi import api as jedi_api
        from jedi.evaluate import compiled

        s = Script(source)
        definitions = get_definitions(source, row, column, "")
        if not definitions:
            definitions = []

        # Check number
        assert len(definitions) == len(expected), "Number of definitions different: got %d, expected %d" % \
            (len(definitions), len(expected))

        # Check name
        for d, e in zip(definitions, expected):
            assert d.name == e[0] and d.type == e[1], d.name + ", " + d.type + " != " + e[0] + ", " + e[1]


# Generated at 2022-06-12 12:53:30.775606
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = '''a = [1, 2, 3]
a.app'''

    completions = get_script_completions(
        source, 2, 7, filename="<unittest>", sys_path=["/tmp"]
    )

    found = False
    for completion in completions:
        if completion.name == "append":
            found = True
            break

    assert found, "append"
    assert len(completions) > 2



# Generated at 2022-06-12 12:53:38.031847
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # check if using an older version of jedi
    using_older_jedi = _using_older_jedi(jedi)

    # check if get_script_completions returns the right data structures
    if using_older_jedi:
        test_script_completions = jedi.Script("x = ").completions()
        test_script_completions_type = type(test_script_completions)
    else:
        test_script_completions = jedi.Script("x = ").complete()
        test_script_completions_type = type(test_script_completions[0])

    if test_script_completions_type is jedi.api_classes.Completion:
        # jedi 0.14 and newer
        isinstance_test = test_

# Generated at 2022-06-12 12:53:44.438141
# Unit test for function get_script_completions
def test_get_script_completions():
    jedi = __import__('jedi')
    completions = get_script_completions('import json\njson.', 0, 9, '<panel>')
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]
    assert len(completions) == 2
    completions = get_script_completions('import json\njson.', 1, 5, '<panel>')
    assert len(completions) == 2

    completions = get_script_completions('import json\njson.l', 1, 6, '<panel>')
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]

# Generated at 2022-06-12 12:53:50.888516
# Unit test for function get_script_completions
def test_get_script_completions():
    completion_list = get_script_completions("def x(a, b=1):\n    a.islower()\na.islower()", 3, 3, "tests/examples/example1.py")
    assert completion_list[0].name == "islower"
    assert completion_list[0].complete == "islower"
    assert completion_list[0].description == "islower(...) method of builtins.str instance\n S.islower() -> bool\n\nReturn True if all cased characters in S are lowercase and there is\nat least one cased character in S, False otherwise."
    assert completion_list[0].full_name == "str.islower"
    assert completion_list[1].name == "islower"
    assert completion_list[1].complete == "islower="
    assert completion

# Generated at 2022-06-12 12:53:55.630499
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-12 12:54:03.888070
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import sentinel

    jedi_completions = [
        ThonnyCompletion(name="def1", complete="def1", type=sentinel.type1, description="description1",
                         parent=sentinel.parent1, full_name="fullname1"),
        ThonnyCompletion(name="def2", complete="def2=", type=sentinel.type2, description="description2",
                         parent=sentinel.parent2, full_name="fullname2"),
        ThonnyCompletion(name="def3", complete="def3=", type=sentinel.type3, description="description3",
                         parent=sentinel.parent3, full_name="fullname3"),
    ]

    import parso


# Generated at 2022-06-12 12:54:11.639100
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api import Interpreter
    import os
    import sys
    sys.path.append(os.getcwd())
    path = "example/getdefinitions_example.py"
    with open(path, "r") as f:
        source = f.read()
    paths = [os.path.dirname(path)]
    namespaces = [dict()]
    row = 12
    column = 3
    interpreter = get_interpreter_completions(source, namespaces, sys_path=paths)
    completions = get_script_completions(source, row, column, filename=path, sys_path=paths)
    if completions:
        first_completion = completions[0]
        print(first_completion.name)
