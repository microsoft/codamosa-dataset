

# Generated at 2022-06-12 12:44:21.083913
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import json
    import sys
    import shutil
    import tkinter as tk
    import tempfile
    from idlelib.idle_test.mock_idle import Func
    from unittest import main

    addition_code = ""

    # example from #620
    code1 = "def my_function(value):\n"
    code1 += "    print(value)\n"
    code1 += "my_function"

    # example from #620
    code2 = "my_function(value=1)"

    # example from #620
    code3 = "my_function(va"

    # function defined in idlelib.run (to get more than one completion)
    code4 = "r"

    # example from #200

# Generated at 2022-06-12 12:44:22.905482
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_parent_scope


# Generated at 2022-06-12 12:44:33.840205
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import jedi

    jedi.settings.fast_parser = True
    script = Script("import sys; sy", path=".", line=1, column=15)
    completions = script.completions()

    assert len(completions) == 0

    jedi.settings.fast_parser = False
    script = Script("import sys; sy", path=".", line=1, column=15)
    completions = script.completions()
    print(completions)

    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys (built-in module)"
    assert completions[0].parent()



# Generated at 2022-06-12 12:44:43.118669
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = "import datetime"
    namespaces = []
    test_name = 'test_interpreter_completions'
    
    def modify_completions(completions):
        # check that type and description attributes are defined
        assert len(completions) > 0
        assert completions[0].type != ""
        assert completions[0].description != ""
        return [completion for completion in completions if completion.name != "time"]

    script = jedi.Interpreter(source, namespaces)
    completions = get_interpreter_completions(source, namespaces)
    assert test_name in set([c.name for c in completions])
    assert test_name in set([c.name for c in script.completions()])
    
    # This is a check

# Generated at 2022-06-12 12:44:51.363331
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_utils import get_interpreter_completions

    try:
        import numpy
    except ImportError:
        numpy = None

    namespaces = [{}]
    if numpy is not None:
        namespaces.append({"numpy": numpy})

    completions = get_interpreter_completions("np.as", namespaces)
    assert len(completions) >= 1
    assert any([c.name == "array" for c in completions])
    if numpy is not None:
        assert any([hasattr(c, "type") and "ufunc" in c.type for c in completions])

# Generated at 2022-06-12 12:44:55.027862
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    ns = [{"name": "module1", "module": __name__}, {"name": "locals", "locals": {"var1": 42}}]
    completions = get_interpreter_completions("var1.", ns, [])
    assert len(completions) == 1, completions
    assert completions[0].name == "var1", completions


if __name__ == "__main__":
    test_get_interpreter_completions()
    print("OK")

# Generated at 2022-06-12 12:45:05.304422
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:45:14.280639
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    from jedi import Script, Interpreter
    import jedi_utils

    with patch.object(Script, 'completions') as mock_method:
        jedi_utils.get_script_completions('source', 0, 0, 'filename', ['sys_path'])
        mock_method.assert_called_once_with()

    with patch.object(Interpreter, 'completions') as mock_method:
        jedi_utils.get_interpreter_completions('source', [{}], ['sys_path'])
        mock_method.assert_called_once_with()

# Generated at 2022-06-12 12:45:17.040134
# Unit test for function get_definitions
def test_get_definitions():
    for i in range(1, 18):
        assert get_definitions("def f(): pass", 0, i, "test.py") is not None


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-12 12:45:23.163076
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta"""
    namespaces = [{"date": date, "datetime": datetime, "time": time, "timedelta": timedelta}]

    completions = get_interpreter_completions(source, namespaces)

    for completion in completions:
        assert completion.parent == "datetime"
        assert completion.type == "class"

# Generated at 2022-06-12 12:45:37.196329
# Unit test for function get_definitions
def test_get_definitions():
    try:
        import jedi
    except ImportError:
        print("Could not run unit test. Please make sure that jedi is installed.")
        return

    assert get_definitions("import os; os.path.isdir('')", 0, 0, "")[0].description == "isdir(path: Union[pathlike, str]) -> bool"
    assert get_definitions("import os.path; os.path.isdir('')", 0, 0, "")[0].description == "isdir(path: Union[pathlike, str]) -> bool"
    assert get_definitions("import os; os.path.isdir('').upper()", 0, 0, "")[0].description == "upper() -> str"

# Generated at 2022-06-12 12:45:50.002937
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:46:00.380311
# Unit test for function get_script_completions
def test_get_script_completions():
    # Using older jedi
    import sys
    import jedi
    if sys.version_info >= (3, 5):
        from unittest import mock

        with mock.patch("jedi.__version__", "0.13.1"):
            from thonny.jedi_utils import get_script_completions
            import parso
            # Needs to be source code with only name, or jedi will treat it as module
            source = parso.parse("x = 1")
            completions = get_script_completions(str(source), 0, 1, "dummy.py")
            assert completions[0].name == "x"
            assert completions[0].complete == "x "

    # Using recent jedi
    else:
        from unittest import mock


# Generated at 2022-06-12 12:46:04.354940
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    c = get_interpreter_completions("i = 0\ni.", [{}])
    assert len(c) == 1
    assert c[0].name == "imag"



# Generated at 2022-06-12 12:46:12.110296
# Unit test for function get_script_completions
def test_get_script_completions():
    jedi = __import__("jedi")
    if _using_older_jedi(jedi):
        source = """import sys
sys.std"""
        script = get_script_completions(source, 2, len(source), "dummy.py")
        found = False
        for completion in script:
            if completion.name == "stdin":
                found = True
                break

        assert found
    else:
        # With newer jedi, stdin is filtered out, so we can't test
        pass


# Generated at 2022-06-12 12:46:21.150958
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("1+2; 3+4; 5+6", 1, 1, "test.py") == []
    assert get_script_completions("1+2; 3+4; 5+6", 2, 1, "test.py") == []
    assert get_script_completions("1+2; 3+4; 5+6", 3, 1, "test.py") == []
    assert get_script_completions("1+2; 3+4; 5+6", 4, 1, "test.py") == []
    assert get_script_completions("1+2; 3+4; 5+6", 1, 3, "test.py") == []

# Generated at 2022-06-12 12:46:25.509159
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "assert"
    row = 0
    column = 6
    filename = "sample.py"

    completions = get_script_completions(source, row, column, filename)
    assert completions[0]["complete"] == "assert "



# Generated at 2022-06-12 12:46:27.416797
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("x = 5\n", 1, 4, "UNKNOWN")) > 0


# Generated at 2022-06-12 12:46:39.140623
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    completions = get_interpreter_completions("'__'.startswith('__')", [])
    found_magic = False
    for completion in completions:
        if completion.name == "__name__":
            found_magic = True
    assert not found_magic

    completions = get_interpreter_completions("'__'.startswith('__')", [{}])
    found_magic = False
    for completion in completions:
        if completion.name == "__name__":
            found_magic = True
    assert found_magic

    completions = get_interpreter_completions("'__'.startswith('__')", [{"__name__": "__main__"}])
    found_magic = False

# Generated at 2022-06-12 12:46:40.818398
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:46:58.850006
# Unit test for function get_script_completions
def test_get_script_completions():
    def run_test(source, expected):
        actual_result = []
        actual = get_script_completions(source, 1, len(source) - 1, "test.py")
        for item in actual:
            actual_result.append(item.complete)
        assert actual_result == expected

    run_test("x=1\ny=2\n", ["open", "x", "y"])
    run_test("import sys\n", ["sys"])
    run_test("import sys\nsys.", ["api_version", "argv", "base_exec_prefix", "base_prefix", "builtin_module_names"])



# Generated at 2022-06-12 12:47:08.258784
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench

    workbench = get_workbench()
    workbench.create_command("CompletionTest")

    for jedi_version in [
        "0.16.0",
        "0.17.0",
        "0.18.0",
        "0.19.0",
        "0.20.0",
        "0.21.0",
        # "0.22.0", # no go
    ]:
        print("Testing with version %s" % jedi_version)


# Generated at 2022-06-12 12:47:15.627623
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import datetime, time

    source_code = """
        import datetime, time
        datetime.date(1969, 7, 21).
        time.time()
    """

    # jedi 0.17
    completions = get_interpreter_completions(source_code, [{"datetime": datetime}])
    assert completions[0].complete == "replace("
    assert completions[1].complete == "resolution"

    # jedi 0.16
    completions = get_interpreter_completions(source_code, [{"datetime": datetime}])
    assert completions[0].complete == "replace("

# Generated at 2022-06-12 12:47:25.511309
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import os; os.path"
    row = 1
    column = 13

    expected = [
        ThonnyCompletion(
            name="path",
            complete="os.path",
            type="module",
            description="os.path",
            parent=None,
            full_name="os.path",
        ),
        ThonnyCompletion(
            name="path",
            complete="os.path",
            type="module",
            description="os.path",
            parent=None,
            full_name="os.path",
        )
    ]

    assert get_script_completions(source, row, column) == expected

    source = "import os; os.path.ex"

# Generated at 2022-06-12 12:47:27.259667
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-12 12:47:37.439086
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("import mymod.myclass", 0, 9, "test_get_definitions.py")
    assert get_definitions("import mymod.myclass", 0, 0, "test_get_definitions.py")
    assert get_definitions("import mymod.myclass\nimport mymod", 2, 0, "test_get_definitions.py")
    assert get_definitions("import mymod.myclass\nmyclass", 1, 0, "test_get_definitions.py")
    assert get_definitions("myClass", 0, 0, "test_get_definitions.py")
    assert get_definitions("myclass", 0, 0, "test_get_definitions.py")

# Generated at 2022-06-12 12:47:44.041034
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            # type: () -> None
            completion = get_interpreter_completions("import sys", [{"sys": sys}])[0]
            self.assertEqual(completion.name, "sys")
            self.assertEqual(completion.type, "module")

    unittest.main(module="thonny.jedi_utils", exit=False)



# Generated at 2022-06-12 12:47:52.805623
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase
    import tempfile
    import os
    import os.path

    class UnitTest(TestCase):
        def test_function(self):
            """
            Test simple function definition
            """
            self._test_simple_definition(
                given="def foo():\n    pass\n\nfoo()",
                expected_name="foo",
                expected_module_name="",
                expected_lineno=1,
                expected_column=4,
            )

        def test_function_in_class(self):
            """
            Test function definition inside class
            """

# Generated at 2022-06-12 12:48:00.306046
# Unit test for function get_definitions
def test_get_definitions():
    from parso import ParserSyntaxError

    buf = """import abc
abc.
"""
    # cursor is after "ab"
    lines = buf.splitlines()
    line = lines[1]
    column = line.find("ab") + 2
    filename = "buf.py"
    defs = get_definitions(buf, 1, column, filename)
    assert len(defs) == 1
    assert defs[0].module_path.endswith("abc.py")
    assert defs[0].line == 1
    assert defs[0].column == 0
    assert defs[0].description == '"' + defs[0].module_path + '"'
    assert defs[0].type == "module"
    assert defs[0].module_name == "abc"

    # now test with error

# Generated at 2022-06-12 12:48:11.404463
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    def test(source, namespaces, sys_path):
        if _using_older_jedi(jedi):
            try:
                interpreter = jedi.Interpreter(source, namespaces, sys_path=sys_path)
            except Exception as e:
                interpreter = jedi.Interpreter(source, namespaces)
        else:
            interpreter = jedi.Interpreter(source, namespaces)
        return interpreter.completions()
    
    # Test with "import datetime". Should find datetime.datetime.
    source = "datetime."
    namespaces = [{"datetime": "datetime"}]
    completions = test(source, namespaces, None)
    assert len(completions) == 1
    assert "datetime" in completions[0].name

# Generated at 2022-06-12 12:48:42.743391
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    input = 'import socket\n'
    interpreter = get_interpreter_completions(input, [], [])
    has_socket = False
    for x in interpreter:
        if x.name == 'socket':
            has_socket = True
        #print(x.complete)
    assert(has_socket)



# Generated at 2022-06-12 12:48:50.612184
# Unit test for function get_definitions
def test_get_definitions():
    def run_get_definitions_test(source, row, column, filename):
        import sys

        assert get_definitions(
            source, row, column, filename
        ) == get_definitions_with_python(source, row, column, filename, sys.executable)

        source = source.replace("line", "l1n3")
        assert get_definitions(
            source, row, column, filename
        ) == get_definitions_with_python(source, row, column, filename, sys.executable)

        source = source.replace("l1n3", "\xe2\x98\x81")
        assert get_definitions(
            source, row, column, filename
        ) == get_definitions_with_python(source, row, column, filename, sys.executable)


# Generated at 2022-06-12 12:49:01.324088
# Unit test for function get_script_completions
def test_get_script_completions():
    def check(source, row, column, expected_completions):
        completions = get_script_completions(source, row, column, "test.py")
        assert len(completions) == len(expected_completions)
        for completion, expected in zip(completions, expected_completions):
            assert (
                completion.name == expected[0]
                and completion.complete == expected[1]
                and completion.type == expected[2]
            )

    # Tkinter

# Generated at 2022-06-12 12:49:09.301868
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled import create_simple_object
    from jedi import settings

    ns = [create_simple_object("__builtins__"), {"s": create_simple_object("s", "foo", "b")}]
    settings.allow_module_completion = False
    settings.add_dot_after_module_completion = False

    completions = get_interpreter_completions("s.", ns)
    assert len(completions) == 1
    assert completions[0]["name"] == "s"

    completions = get_interpreter_completions("import sys; s.", ns)
    assert len(completions) == 1
    assert completions[0]["name"] == "s"


# Generated at 2022-06-12 12:49:20.382816
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi


# Generated at 2022-06-12 12:49:23.360634
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("'123'.upper(", 5, 4, "anonymous-1"))

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:49:30.175559
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    This test is not part of the "testall" because it requires jedi >= 0.17

    For function get_interpreter_completions,

    it should throw a NameError for undefined objects and functions,
    and return correct completions for basic functions and classes.
    """
    from unittest import mock

    from jedi import Interpreter
    from jedi.api.classes import Completion
    from thonny.jediutils import get_interpreter_completions

    # Use the mock package to simulate the behavior of jedi.Script

# Generated at 2022-06-12 12:49:40.817541
# Unit test for function get_script_completions
def test_get_script_completions():
    def get_completions(source, sys_path=None) -> List[ThonnyCompletion]:
        return get_script_completions(source, len(source.splitlines()), len(source), "<stdin>", sys_path)

    # sys_path=None
    assert "foo" in [x.name for x in get_completions("foo")]
    assert "str" in [x.name for x in get_completions("str")]

    # sys_path=[]
    assert "str" not in [x.name for x in get_completions("str", sys_path=[])]
    assert "str" in [x.name for x in get_completions("str", sys_path=["/home/foo/bar"])]

# Generated at 2022-06-12 12:49:48.778070
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # pre-0.16 jedi can't complete without filename
    #import jedi
    #jedi.Interpreter("str().", [])
    assert set(c.name for c in get_interpreter_completions("str().", [], [])).issuperset(
        {"strip", "upper", "replace", "isdecimal"}
    )
    assert (
        set(c.name for c in get_interpreter_completions("from math import *", [], []))
        == set()
    )

# Generated at 2022-06-12 12:49:58.825641
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from thonny.jedi_utils import get_interpreter_completions
    from jedi.api.keywords import Keyword
    namespace = [{'__builtins__': jedi.Interpreter('').builtins},{}]
    results = get_interpreter_completions('abs', namespace)
    
    assert len(results) == 1
    assert isinstance(results[0], ThonnyCompletion)
    assert results[0].name == 'abs'
    assert results[0].complete == 'abs'
    assert results[0].type == 'function'
    assert results[0].description == 'abs(number) -> number\n\nReturn the absolute value of the argument.'
    assert isinstance(results[0].parent, Keyword)
    assert results[0].full_name

# Generated at 2022-06-12 12:51:03.801383
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.misc_utils import running_on_windows

    if (
        running_on_windows()
        and _using_older_jedi(jedi)
        and jedi.__version__ not in ["0.10.2", "0.11.1", "0.11.2", "0.10.2"]
    ):
        return

    # Test for 0.10.2 and 0.11.1 fails if jedi is installed via pip in virtual env and
    # python 3.5 is not avilable at all
    # import sys
    # if sys.version_info[:2] == (3, 5) and not sys.executable.endswith("pythonw.exe"):
    #    return


# Generated at 2022-06-12 12:51:13.447288
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    def simulate_completion(source, completion_row, completion_column):
        # parse
        module = parso.parse(source)

        # find node
        cur_node = get_statement_of_position(module, (completion_row, completion_column))
        while isinstance(cur_node, tree.Flow):
            cur_node = get_statement_of_position(cur_node, (completion_row, completion_column))
        assert cur_node

        # populate namespaces
        namespaces = []
        cur_node.execute_evaluated_code()
        while cur_node and cur_node.parent:
            namespaces.append(cur_node.get_execution_names())
            cur_node = cur_node.parent
        # namespaces.reverse()

        # print

# Generated at 2022-06-12 12:51:22.075131
# Unit test for function get_script_completions
def test_get_script_completions():
    from traceback import print_exc

    from parso.python import tree

    try:
        from jedi import Script

        assert Script.completions
    except Exception:
        print_exc()
        skip("Jedi version too old for test_get_script_completions")

    code = "import sys\nimport os\nos.path.join(sys.path, 'some_string')"

    old_completions = Script(code, 2, 23).completions()
    new_completions = get_script_completions(code, 2, 23, "test.py")

    assert len(old_completions) == len(new_completions)

    for i, c in enumerate(old_completions):
        assert c.name == new_completions[i].name

# Generated at 2022-06-12 12:51:26.488961
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import math\nmath.pi", 1, 15, "")
    assert completions
    assert len(completions) > 0
    assert any([c['name'] == 'pi' for c in completions])
    assert any([c['name'] == 'pow' for c in completions])



# Generated at 2022-06-12 12:51:35.849218
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    from thonny import get_completions

    print("Trying to get completions for document")
    print("import sys")
    print("sys.argv[0].endswith('.')")
    print("^")

    with patch("jedi.Script", spec=True, new=MockedScript) as mocked_script:
        completions = get_completions("import sys\nsys.argv[0].endswith('.')\n", 3, 11, "")

        assert len(completions) == 1
        assert completions[0].name == "endswith"
        assert completions[0].complete == "endswith("
        assert completions[0].type == "def"
        assert completions[0].parent == "str"
        assert completions

# Generated at 2022-06-12 12:51:36.431730
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:51:42.561527
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("mystr.", 1, 8, "")

    assert len(result) == 2
    assert result[0].name == "swapcase"
    assert result[0].complete == "swapcase()"
    assert result[0].type == "function"
    assert result[0].description == "S.swapcase() -> str\n\nReturn a copy of S with uppercase characters converted to lowercase\nand vice versa."
    assert result[0].parent == "str"
    assert result[0].full_name == "str.swapcase"

    assert result[1].name == "title"
    assert result[1].complete == "title()"
    assert result[1].type == "function"

# Generated at 2022-06-12 12:51:48.374548
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions(
        'with_statement', [{"__builtins__": __builtins__}], sys_path=[]
    )
    assert len(completions) == 2
    assert completions[0].name == "with_statement"
    assert completions[0].full_name == "with_statement"
    assert completions[1].name == "import_statement"

# Generated at 2022-06-12 12:51:53.421485
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = "os.path.join('a')\n"
    pos = len(source)
    namespaces = [{'os': jedi.Interpreter(source, [], pos).goto_definitions()[0].namespace}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0, "No completions returned"

# Generated at 2022-06-12 12:52:04.091662
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    class Comp:
        type = "Comp_type"
        name = "Comp_name"
        complete = "Comp_complete"
        description = "Comp_description"
        parent = "Comp_parent"
        full_name = "Comp_full_name"

    completions = [Comp() for _ in range(3)]

    def get_completions(source, namespaces, sys_path=None):
        return completions

    from jedi import interpreter
    import sys
    import pytest
    from types import ModuleType

    jedi_mod = ModuleType("jedi")
    jedi_mod.Interpreter = lambda x, y, z=None: None
    jedi_mod.Interpreter.complete = get_completions
    sys.modules["jedi"] = jedi_mod


# Generated at 2022-06-12 12:53:09.044180
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import tkinter

    assert get_definitions(
        "from tkinter import *\n\ntkinter.Toplevel(Tk())\n",
        2,
        3,
        sys.executable,
    ) != []

# Generated at 2022-06-12 12:53:17.457258
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    import os.path
    import unittest
    import jedi
    sys.path.append(os.path.abspath(os.path.join(os.path.curdir, os.path.pardir)))
    import thonny.plugins.backend_utils as backend_utils
    from thonny import get_workbench
    from thonny.languages.utils import DummyInterpreter
    from thonny.languages.python import PythonProxy
    from thonny.globals import get_runner

    def _test_get_interpreter_completions(source: str, namespaces: List[Dict], expected: List[str], sys_path=None):
        actual = get_interpreter_completions(source, namespaces, sys_path)
       

# Generated at 2022-06-12 12:53:24.722940
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class Test(unittest.TestCase):
        def test_with_sys_path(self):
            source = "import sys\nimport os\n"
            namespaces = [{"os": os}]
            sys_path = [os.path.dirname(os.__file__)]
            completions = get_interpreter_completions(source, namespaces, sys_path)
            self.assertTrue(len(completions) > 0)

    unittest.main(module="test_get_interpreter_completions", exit=False)

# Generated at 2022-06-12 12:53:32.314558
# Unit test for function get_definitions
def test_get_definitions():
    import os.path

    stdlib_path = os.path.join(os.path.split(os.__file__)[0], "__init__.py")
    assert get_definitions('import os\nos.path', 0, 0, stdlib_path)
    assert get_definitions('from os import path\npath', 0, 0, stdlib_path)
    assert get_definitions('from os.path import join\njoin', 0, 0, stdlib_path)
    assert get_definitions('from os import path', 0, 0, stdlib_path)
    assert get_definitions('from os.path import join', 0, 0, stdlib_path)
    assert get_definitions('import os.path', 0, 0, stdlib_path)

# Generated at 2022-06-12 12:53:38.138054
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def check_result(source, expected):
        got = get_interpreter_completions(source, [])
        assert len(got) == len(expected)
        for i, got_item in enumerate(got):
            assert got_item.name == expected[i][0]
            assert got_item.complete == expected[i][1]

    check_result("a.", [("a", "a")])
    check_result("a.a", [("a", "a")])
    check_result("a.a.", [("a", "a")])
    check_result("a.a.a", [("a", "a")])

# Generated at 2022-06-12 12:53:44.462659
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os
    dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(dir, '.'))
    completions = get_script_completions('impo', 3, 5, 'example.py')
    assert len(completions) == 2
    expected_names = ['import', 'importlib']
    names = [jedi_completion.name for jedi_completion in completions]
    assert names == expected_names
    # because the name 'import' has a JEDI_TYPE_KEYWORD, it will be ranked higher in the list
    # completions returned by jedi, therefore the type of the first element in the list
    # should be 'import'

# Generated at 2022-06-12 12:53:50.916500
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    source = "import sys; sys.pa"
    completions = get_script_completions(source, 1, len(source), "<my-filename>", [])
    assert set(map(lambda x: x.name, completions)) == {
        "path",
        "path_hooks",
        "path_importer_cache",
        "platform",
        "prefix",
        "ps1",
        "ps2",
        "ps3",
        "real_prefix",
        "setrecursionlimit",
    }

    # script completions and regular completions need to be compatible
    script_completions = Script(source, 1, len(source), "<my-filename>").completions()

# Generated at 2022-06-12 12:53:54.584288
# Unit test for function get_definitions
def test_get_definitions():
    # TODO: to be moved to test_jedi
    # This is a unit test for the get_definitions.
    # It is not executed as a unit test normally.
    # To run it, type at the Thonny command prompt:
    # exec(open("/usr/lib/python3.8/site-packages/jedi/test_jedi.py").read())
    # and then type at the Thonny command prompt:
    # test_get_definitions()
    import jedi
    import inspect
    import parso


# Generated at 2022-06-12 12:53:57.001038
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions("import datetime", 1, 1, "")
    assert len(defs) == 1
    assert defs[0].module_name == "datetime"
    # print(defs[0].module_path)

# Generated at 2022-06-12 12:54:06.026959
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [
        {"print": print, "float": float, "foo": 1, "long": 1, "True": True, "type": type}
    ]
    completions = get_interpreter_completions("print.", namespaces)
    assert len(completions) == 1
    assert completions[0].complete == "print="
    assert completions[0].name == "print"
    assert completions[0].type == "statement"

    completions = get_interpreter_completions("type(", namespaces)
    assert len(completions) == 1
    assert completions[0].complete == "type="

    completions = get_interpreter_completions("type(foo", namespaces)
    assert len(completions) == 1