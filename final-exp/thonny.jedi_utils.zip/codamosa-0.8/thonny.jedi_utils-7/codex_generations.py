

# Generated at 2022-06-12 12:44:28.141331
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("x = 'ab'", [{}])
    assert len(completions) == 2
    assert [c.name for c in completions] == ["append", "append="]



# Generated at 2022-06-12 12:44:38.759511
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.utils import split_lines

    source = "def func(a, ad, adb, ade, adea, adeab):\n    a.a.a.a.a.a.a\n"
    source += "    adea.a\n    adeab.a\n"
    source += "print(\"\".join(\"a\"))\n"
    source += "print(\"\".join(\"a\"))\n"
    source += "print(\"\".join(\"a\"))\n"
    source += "print(\"\".join(\"a\"))\n"
    source += "a = 1\nad = 2\nadb = 3\nade = 4\nadea = 5\nadeab = 6\n"

# Generated at 2022-06-12 12:44:45.846728
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from os import path
    import sys

    # Get folder of this file
    this_file = path.realpath(__file__)
    this_dir = path.dirname(this_file)

    # Set up sys.path
    sys.path = [
        path.join(this_dir, "test_completion_data", "external_lib", "dir1"),
        path.join(this_dir, "test_completion_data", "external_lib", "dir2"),
        path.join(this_dir, "test_completion_data", "external_lib", "dir2", "dir3"),
        path.join(this_dir, "test_completion_data", "external_lib", "dir4"),
    ]

    # Set up interpreter for completion data

# Generated at 2022-06-12 12:44:56.418362
# Unit test for function get_definitions
def test_get_definitions():
    from unittest.mock import patch, sentinel
    
    with patch.object(__name__, "_using_older_jedi", return_value=True) as old_mock, \
         patch.object(__name__, "_get_new_jedi_project", return_value=sentinel.project) as new_mock:
        
        get_definitions("import os", 0, 0, "dummy.py")
        old_mock.assert_called_once_with(__name__)
        new_mock.assert_not_called()
        assert not new_mock.called
        
        get_definitions("import os", 0, 0, "dummy.py")
        old_mock.assert_called_once_with(__name__)
        new_mock.assert_not_called

# Generated at 2022-06-12 12:45:06.468932
# Unit test for function get_definitions
def test_get_definitions():
    text = "import os\nabcd"
    filename = "test1.py"
    ver = get_definitions(text, 2, 5, filename)
    assert len(ver) == 1
    assert ver[0].description == 'import os\nabcd'
    assert ver[0].module_path == filename
    assert ver[0].line == 1
    assert ver[0].in_builtin_module() == False
    assert ver[0].parent() == None
    assert ver[0].is_keyword == False
    assert ver[0].is_stub() == False
    assert ver[0].is_compiled() == False
    assert ver[0].is_definition() == False
    assert ver[0].is_statement() == True
    assert ver[0].is_import() == False

# Generated at 2022-06-12 12:45:16.178396
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import re
import sys
import os

from collections import *

re.match()
sys.stderr.wri
os.error.

Counter()


"""

    completions = get_script_completions(source, 10, 12, "my_script.py")

# Generated at 2022-06-12 12:45:19.542972
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import sys
sys.get_script_completions
#^
"""
    completions = get_script_completions(source, row=4, column=3, filename="")
    assert completions[0].name == "get_script_completions"

# Generated at 2022-06-12 12:45:26.795927
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # monkeypatch for older jedi versions
    import jedi
    if hasattr(jedi.Interpreter, "completions"):
        jedi.Interpreter.complete = jedi.Interpreter.completions
    if hasattr(jedi.Script, "completions"):
        jedi.Script.complete = jedi.Script.completions

    interpreter = get_interpreter_completions("import os\nos.", [], None)
    assert interpreter[0].name == "open"

# Generated at 2022-06-12 12:45:35.196742
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        source = """
import os

print(os.path.join(os.getcw"""
        completions = get_interpreter_completions(source, [])
        result = [c.name for c in completions]

        assert result == ["'", '"', "os.path.join", "os.getcwd"]
    else:
        source = """
import os

print(os.getcwd()"""
        completions = get_interpreter_completions(source, [])
        result = [c.name for c in completions]


# Generated at 2022-06-12 12:45:39.439302
# Unit test for function get_definitions
def test_get_definitions():
    source = "import string\n\nstring.split"
    result = get_definitions(source, 3, 11)
    assert len(result) == 1
    assert result[0].parent().name == "string"
    assert result[0].name == "split"
    assert result[0].type == "function"

# Generated at 2022-06-12 12:46:13.442043
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = 'import subprocess\n\nsubprocess.check_output('
    namespaces = [{'subprocess': jedi.Interpreter('import subprocess', []).namespace}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1



# Generated at 2022-06-12 12:46:21.916824
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    c = get_interpreter_completions('import re; re.', [{'re': re}])
    assert c[0].name == 'compile', c[0].name
    assert c[1].name == 'match', c[1].name
    assert c[2].name == 'search', c[2].name
    assert c[3].name == 'findall', c[3].name

    if _using_older_jedi(Interpreter):
        # in 0.17 name still matches complete
        assert c[0].name == c[0].complete, c[0].name
        assert c[1].name == c[1].complete, c[1].name
        assert c[2].name == c[2].complete, c[2].name

# Generated at 2022-06-12 12:46:33.425749
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock

    completions = get_interpreter_completions("", [])

    assert completions == []

    class Completion:
        def __init__(self, name):
            self.name = name

    jedi_completions = [Completion("abc"), Completion("abc"), Completion("abc")]

    class Interpreter:
        def __init__(self, source, namespaces, sys_path=None):
            pass

        def complete(self):
            return jedi_completions

    import jedi


# Generated at 2022-06-12 12:46:41.695014
# Unit test for function get_definitions
def test_get_definitions():
    # Check if list of completions is returned
    source = "a=7;a"
    row = 2
    column = 2
    filename = ""

    definitions = get_definitions(source, row, column, filename)
    assert isinstance(definitions, list)
    # TODO: Check if correct number of completions returned
    # Check if completions contain correct data

    assert definitions[0].complete == "a=7"
    assert definitions[0].description == "int"
    assert definitions[0].type == "statement"
    assert definitions[0].full_name == "int"
    assert definitions[0].parent == None
    assert definitions[0].name == "int"



# Generated at 2022-06-12 12:46:51.750145
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import importlib
    import ast

    jedi = importlib.import_module("jedi")
    unittest.TestCase.assertFalse(jedi.__version__.startswith("0.18"), msg="This test only works for jedi version below 0.18")

    source = '''
    def func():
        pass

    def func2():
        pass
    '''

# Generated at 2022-06-12 12:46:56.557132
# Unit test for function get_definitions
def test_get_definitions():
    """
    jedi bug has been fixed.
    """"""
    source = """
import math

# Generated at 2022-06-12 12:47:05.859713
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.evaluate.context import TreeInstance
    else:
        from jedi.api.classes import Script as ScriptClass
        from jedi.api.classes import BaseClass as BaseClassClass

    source = 'from tkinter import *\nroot = Tk()'
    row, column = 2, 11
    filename = "file.py"
    definitions = get_definitions(source, row, column, filename)

    assert len(definitions) == 1
    definition = definitions[0]
    assert _using_older_jedi(jedi) and isinstance(definition, TreeInstance) or \
           not _using_older_jedi(jedi) and isinstance(definition, ScriptClass)
    assert definition.line == 2

# Generated at 2022-06-12 12:47:12.647172
# Unit test for function get_definitions
def test_get_definitions():
    import os
    from thonny.languageserver import languageserver_proxy

    lsp = languageserver_proxy.LanguageServerProxy()
    defs = lsp.get_definitions(
        "C:/temp/test.py",
        "import datetime\ndatetime.timedelta"
    )
    assert len(defs) > 0
    assert os.path.basename(defs[0].location.uri) == "datetime.py"
    assert defs[0].range.start.line == 8

    defs = lsp.get_definitions(
        "C:/temp/test.py",
        "from datetime import datetime\ndatetime()"
    )
    assert len(defs) > 0

# Generated at 2022-06-12 12:47:20.266168
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import os\n import pandas as pd\n pd.read_'
    namespaces = [{'os': os, 'pd': pd}, {'os': os}]
    completions = get_interpreter_completions(source, namespaces)
    assert completions != []
    assert any([complete == "read_csv(filepath_or_buffer, sep=',', delimiter=None" for complete, _ in completions])
    assert any([complete == "read_excel(io, sheet_name=0, header=0" for complete, _ in completions])

# Generated at 2022-06-12 12:47:27.361005
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    import collections

    completions = get_interpreter_completions(
        "time.s",
        [
            collections.UserDict({"time": time}),
            collections.UserDict({"time": time}),
            collections.UserDict({"time": time}),
        ],
    )

    assert all(completion["complete"] == "strftime(" for completion in completions)

    completions = get_interpreter_completions("time.time.s", [collections.UserDict({})])

    assert all(completion["complete"] == "__class__" for completion in completions)



# Generated at 2022-06-12 12:48:25.168923
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from math import *; d = sin(0.5)"
    completions = get_interpreter_completions(source, [])
    assert len(completions) > 0
    assert next(c for c in completions if c.name == "sin")

    completions = get_interpreter_completions("", [])
    assert len(completions) > 0
    assert next(c for c in completions if c.name == "if")

    completions = get_interpreter_completions("", [{"__name__": "__main__", "__builtins__": __builtins__}])
    assert len(completions) > 0
    assert next(c for c in completions if c.name == "__doc__")

# Generated at 2022-06-12 12:48:35.495512
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.helpers import get_script_completions
    from parso.python.tree import Module
    from parso.tree import search_ancestor
    from importlib import import_module
    from parso.utils import split_lines

    mod = import_module("jedi")
    if _using_older_jedi(mod):
        return
    else:
        def get_definitions(script):
            nodes = []
            for defn in script.infer():
                assert defn.type == "module"
                assert defn.full_name == "jedi"
                assert defn.description == "jedi"
                assert defn.docstring() == None or defn.docstring().usage.startswith("Jedi")
                assert defn.doc is None

# Generated at 2022-06-12 12:48:42.040237
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions('str(abc', [{'abc': 'abc'}]) == \
           [ThonnyCompletion(name='capitalize', complete='capitalize', type='function',
                             description='S.capitalize() -> str\n\nReturn a capitalized version of S, '
                                         'i.e. make the first character\nhave upper case and the rest lower case.',
                             parent='str',
                             full_name='str.capitalize')]

# Generated at 2022-06-12 12:48:43.938383
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("1 + 1", [{}])) > 0

# Generated at 2022-06-12 12:48:51.259941
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Check that it handles unicode
    source_code = "import iso639\nresult = iso639.languages.get(iso639_1_code='fr')\nresult['name'][0:2]."
    completions = get_interpreter_completions(source_code, [])
    # TODO: the test fails sometimes.
    # print(completions)
    # expected_names = ['capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust

# Generated at 2022-06-12 12:48:57.932350
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return
    else:
        # ensure similar result for all supported versions.
        if jedi.__version__[:4] == "0.18":
            assert get_interpreter_completions("o.", [])[0].name == "object"
        else:
            assert get_interpreter_completions("o.", [])[0].name == "object="



# Generated at 2022-06-12 12:49:01.412650
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("max(", 0, 4, "test.py")
    assert len(completions) == 1
    completion = completions[0]
    assert completion.name == "max"



# Generated at 2022-06-12 12:49:09.360994
# Unit test for function get_definitions
def test_get_definitions():
    import tokenize, io
    from thonny.plugins.jedi_utils import get_definitions

    file_path = "test.py"
    with io.StringIO('import sys\n') as f:
        tokens = tokenize.tokenize(f.readline)
        for tkn in tokens:
            print(tkn)
    for def_item in get_definitions('import sys', 0, 0, file_path):
        print(def_item.module_name)
        print(def_item.in_builtin_module())
        print(def_item.is_keyword)
        print(def_item.type)
        print(def_item.line)
        print(def_item.column)
        print(def_item.get_line_code())
        print(def_item.description)


# Generated at 2022-06-12 12:49:17.535231
# Unit test for function get_script_completions
def test_get_script_completions():
    # this is taken from get_script_completions.py in jedi
    source = '''import os
os.path.abspath('''
    completions = get_script_completions(source, 0, len(source), "test_script.py")
    completions = {c.name for c in completions}
    assert {"dirname", "join", "abspath", "basename"}.issubset(completions)

    completions = get_script_completions("", 0, 0, "test_script.py")
    assert len(completions) > 600

# Generated at 2022-06-12 12:49:28.456634
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import datetime\ndatetime.da"
    namespaces = [{'__name__': '__main__'}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 4
    assert completions[0].name == "datetime.date"
    assert completions[0].complete == "datetime.date"

    source = "from datetime import "
    namespaces = [{'__name__': '__main__'}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 5

    source = "from datetime import (da)"
    namespaces = [{'__name__': '__main__'}]
    completions = get_interpreter_com

# Generated at 2022-06-12 12:50:08.021955
# Unit test for function get_script_completions
def test_get_script_completions():
    def _run_test(code, row, column, expected_completions):
        completions = get_script_completions(code, row, column, None)
        assert [c.name for c in completions] == expected_completions

    _run_test(
        "import sys\n\nprint(sys.platfo", 7, 8, ["platform", "platform_version"]
    )

    _run_test(
        "import sys\n\nprint(sys.platform.isupper)", 7, 8, ["isupper", "islower", "isalpha"]
    )

    _run_test(
        "import sys\n\nprint(sys.platform.isupper(", 7, 12, ["isupper", "islower", "isalpha"]
    )


# Generated at 2022-06-12 12:50:16.165005
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    import parso

    # create a workspace object to store globals
    class MyTestClass():
        pass

    workspace = MyTestClass()

    # Store the value in the workspace object
    workspace.string = "Hello World!"

    # create the namespace to provide to jedi
    namespaces = [{"builtins": parso.python.Tree(None).get_root_node()}, {"workspace": workspace}]

    # get completions
    completions = get_interpreter_completions("workspa", namespaces, sys_path=None)

    # check the result

# Generated at 2022-06-12 12:50:26.041367
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("", 0 ,0, "") == []
    script = "def foo(n):\n    p"

# Generated at 2022-06-12 12:50:26.662944
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:50:29.946767
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    logger.info("Testing with jedi %s" % jedi.__version__)
    assert len(get_script_completions("import datetime\ndatetime.da", 5, 22, "untitled")) > 0

# Generated at 2022-06-12 12:50:30.953848
# Unit test for function get_definitions
def test_get_definitions():
    import jedi



# Generated at 2022-06-12 12:50:37.462671
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions(
        source="from datetime import", namespaces=[], sys_path=[""]
    )
    assert completions
    if _using_older_jedi(jedi):
        assert "datetime" in [c.name for c in completions]
    else:
        assert "datetime" in [c.full_name for c in completions]


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:50:44.965148
# Unit test for function get_script_completions
def test_get_script_completions():
    code = """
    def foo():
        pass
    """
    print(get_script_completions(code, 3, 6, "test.py"))


import sys, os

if __name__ == "__main__":
    if os.path.isdir("../lib/jedi"):
        sys.path.insert(0, "../lib/jedi")
    elif os.path.isdir("lib/jedi"):
        sys.path.insert(0, "lib/jedi")
    else:
        print("Could not find lib/jedi")

    test_get_script_completions()

# Generated at 2022-06-12 12:50:46.137767
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:50:56.516297
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.globals import get_workbench

    source = 'import tkinter as tk\n' + 'tk.\n'

    get_workbench().set_option("editor.codecompletion", "Jedi")
    get_workbench().set_option("editor.codecompletion.delay", 0.1)

# Generated at 2022-06-12 12:51:42.232059
# Unit test for function get_definitions
def test_get_definitions():
    def check(source, row, column, filename, expected_result=None):
        import pprint

        logger.debug("Testing with " + pprint.pformat(dict(source=source, row=row, column=column)))
        import os

        script_dir = os.path.dirname(os.path.realpath(__file__))
        filename = os.path.join(script_dir, filename)

        def get_type(obj):
            if hasattr(obj, "type"):
                return obj.type
            else:
                return obj.class_name

        def get_module(obj):
            if hasattr(obj, "module"):
                return obj.module.name
            else:
                return None

        def normalize(name):
            import os


# Generated at 2022-06-12 12:51:52.580537
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest.mock
    import jedi
    import jedi.api.class_
    
    if jedi.__version__[:4] == "0.13":
        # Test to ensure that we don't request the sys_path when it's not needed
        mock_interpreter = unittest.mock.Mock()
        with unittest.mock.patch("jedi.Interpreter", return_value=mock_interpreter) as mock_class:
            completions = get_interpreter_completions("import sys", [])
            mock_class.assert_called_once_with("import sys", [])
        mock_interpreter.completions.assert_called_once_with()

        mock_interpreter = unittest.mock.Mock()

# Generated at 2022-06-12 12:51:57.523177
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os.path
    import unittest
    import jedi

    # like in test_completion.py
    sys_path = [os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))]
    sys_path.append(os.path.dirname(sys.executable))


# Generated at 2022-06-12 12:52:08.565211
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import sys

    class Test(unittest.TestCase):
        def test_get_script_completions(self):
            self.assertIsNotNone(get_script_completions("import os", 1, 7, "test.py"))
            self.assertTrue(
                get_script_completions("import os", 1, 7, "test.py")[0].full_name.startswith("os.")
            )
            self.assertIsNotNone(
                get_script_completions("import os; print(os)", 2, 8, "test.py")
            )
            self.assertIsNotNone(
                get_script_completions("import os; print(os.path.)", 2, 14, "test.py")
            )

# Generated at 2022-06-12 12:52:19.517984
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter, Completion
    from parso.python import tree
    import unittest.mock

    # Unittest setup adapted from https://github.com/davidhalter/jedi/blob/master/test/test_completion.py
    code = 'class A:\n    def f(self, arg1, arg2):\n        self.attr1 = arg1\n        self.attr2 = arg2\n    def g(self, arg1):\n        return self.test(arg1)\n\n    def test(self, arg1):\n        self.test_attr = arg1\n        return 1\n\n\nA().'

    class B(tree.BaseNode):
        pass


# Generated at 2022-06-12 12:52:20.060708
# Unit test for function get_definitions

# Generated at 2022-06-12 12:52:23.499060
# Unit test for function get_definitions
def test_get_definitions():
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "site-packages"))
    from test_thonny_jedi_interface import test_source

    source_file = os.path.join(os.path.dirname(__file__), "..", "site-packages", "test.py")
    source = test_source()
    source += source_file
    row = 1
    column = 0
    filename = source_file
    definitions = get_definitions(source, row, column, filename)
    for definition in definitions:
        print(definition)



# Generated at 2022-06-12 12:52:27.866337
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    
    source = "import math\nmath.floor().f"
    namespaces = [{}, {"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    
    assert len(completions) == 1
    assert completions[0].name == "math"
    assert isinstance(completions[0], ThonnyCompletion)

# Generated at 2022-06-12 12:52:38.211864
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # no completions
    result = get_interpreter_completions("", [{}])
    assert len(result) == 0

    # function return value
    result = get_interpreter_completions("def foo():\n    pass", [{}])
    assert len(result) == 1
    assert result[0].name == "foo"
    # assert result[0].parent == "<module>"

    # function argument
    result = get_interpreter_completions("def foo(a):\n    pass", [{}])
    assert len(result) == 1
    assert result[0].name == "a"
    # assert result[0].parent == "foo"

    # existing object
    result = get_interpreter_completions("a = object()", [{"a": object()}])


# Generated at 2022-06-12 12:52:45.445560
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from thonny.plugins.jedi_utils import get_script_completions
    import unittest

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        print(
            "test_get_script_completions() is skipped, because it's only relevant for Jedi>=0.18"
        )
        return

    class SimpleTest(unittest.TestCase):
        def test_completion_contents(self):
            completions = get_script_completions(
                source="from typing import *\nfrom _io import *",
                row=1,
                column=5,
                filename="<unknown>",
            )


# Generated at 2022-06-12 12:53:28.830823
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'class A:\n\tdef __init__(self, val):\n\t\tself.value = val\n\nA("test").'
    results = get_script_completions(source, 5, 13, "test.py")
    for r in results:
        print(r.name)

# Generated at 2022-06-12 12:53:33.336418
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi.api.classes
    assert type(get_script_completions("a=10;a.", 1, 5, "test.py")) == list
    assert type(get_script_completions("a=10;a.", 1, 5, "test.py")[0]) == jedi.api.classes.Completion

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:53:40.425876
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import parso

    class MyTestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            code = r"""
            def foobar(a):
                pass
            foobar(1).re"""
            tree = parso.parse(code)

            positions = tree.get_definition_positions(code)
            self.assertEqual(positions, [(1, 14)])
            completions = get_interpreter_completions(code, positions)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "replace")

    unittest.main(verbosity=2)


if __name__ == "__main__":
    test_get_interpreter_

# Generated at 2022-06-12 12:53:46.904216
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import sentinel

    def fake_interpreter_completions(script, **kwargs):
        return [sentinel.fake_completion1]

    from jedi.api import Interpreter
    from unittest.mock import patch
    from thonny.jedi_utils import get_interpreter_completions

    with patch.object(Interpreter, "complete", fake_interpreter_completions):
        completion = get_interpreter_completions("with open('test_file', 'r') as f: pass", [])

    assert completion == [sentinel.fake_completion1]



# Generated at 2022-06-12 12:53:52.848009
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions
    import jedi

    # Set up interpreter
    i = jedi.Interpreter("", [])
    import shutil
    i.push(shutil.__dict__)
    i.push(shutil.__dict__)

    completions = get_interpreter_completions("sh", i.namespaces)

    # Check that the completions are there
    assert "shutil.which" in [c.name for c in completions]

    # Check the type of completions
    assert ["shutil.which"] == [c.name for c in completions if c.type == "function"]



# Generated at 2022-06-12 12:53:57.370116
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import json; json.lo"

    completions = get_interpreter_completions(source, [])

    # check that the json.loads function is in the completions
    assert "loads" in [c.name for c in completions]
    assert isinstance(completions, list)
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "loads"



# Generated at 2022-06-12 12:54:06.436511
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.jedi_utils import get_definitions

    def get_names(defs):
        return [x.desc_with_module for x in defs]

    source = textwrap.dedent("""\
    from math import *
    import math
    def test(): pass
    class Test: pass
    test_value = 5
    """)

    # In case of "def", "class" no additional info is given (returned with 0)
    # In case of "import" it is the module name instead of "math"
    assert get_names(get_definitions(source, 2, 7, "test.py")) == ["test()", "Test()"]
    assert get_names(get_definitions(source, 4, 7, "test.py")) == ["test()", "Test()"]
    assert get_names

# Generated at 2022-06-12 12:54:09.867432
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions('resource.r', [], sys_path=['.'])
    assert len(completions) > 0
    assert any(c.name == 'open' for c in completions)


if __name__ == '__main__':
    test_get_interpreter_completions()