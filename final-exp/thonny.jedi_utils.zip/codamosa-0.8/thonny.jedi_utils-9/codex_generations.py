

# Generated at 2022-06-12 12:44:29.897423
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'from math import *\ncos('
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)
    assert completions[0].name == 'pi='

# Generated at 2022-06-12 12:44:30.483076
# Unit test for function get_script_completions

# Generated at 2022-06-12 12:44:32.737647
# Unit test for function get_script_completions
def test_get_script_completions():
    res=get_script_completions('print(',0,7,'')
    print(res)
    assert len(res)>0

# Generated at 2022-06-12 12:44:42.447184
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    tests if get_interpreter_completions works properly
    """
    import sys
    import os
    import jedi

    if sys.version_info > (3, 8):
        raise RuntimeError("The Python version is not suitable for this test")

    source = """import turtle
turtle.
turtle.
turtle.forward(100)"""
    source_turtle_functions = """
turtle.
turtle.
turtle.backward(100)"""

    # Test Python 3.7
    if sys.version_info > (3, 7):
        result = get_interpreter_completions(source, [], [os.getcwd()])

# Generated at 2022-06-12 12:44:52.071177
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import api


# Generated at 2022-06-12 12:45:01.386349
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso
    from parso.python import tree
    import tempfile
    import os
    import sys
    import types
    import shutil
    import unittest

    # a directory to contain the test modules
    temp_dir = tempfile.mkdtemp()
    file_names = []

    # here is a module for testing
    def create_module(mname, source_code):
        fn = os.path.join(temp_dir, mname + '.py')
        file_names.append(fn)
        with open(fn, 'w', encoding='utf-8') as f:
            f.write(source_code)


# Generated at 2022-06-12 12:45:09.719204
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def get_completions(source, column, row):
        completions = get_interpreter_completions(source, [], 1)
        return completions[column][row]

    # 1. Check whether completions work
    assert get_completions("d", 0, 0) == "def"

    # 2. Check whether the completions at different sites are different
    assert get_completions("def f(a, b): pass\nf(a=True, ", 12, 0) == "b="
    assert get_completions("def f(a, b): pass\nf(a=True, b=True, ", 17, 0) == " )"

    # 3. Check whether keywords are not returned

# Generated at 2022-06-12 12:45:10.688315
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions('foo = "bar"', 0, 6)

# Generated at 2022-06-12 12:45:16.516983
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    from jedi.api.classes import Completion

    completion_in_mock_namespace = Completion(
        "foo", "foo", "funcdef", "description", Mock(), "foo"
    )

    actual = get_interpreter_completions("foo", [{"__builtins__": {}}])

    assert len(actual) == len(completion_in_mock_namespace)
    assert actual[0].name == completion_in_mock_namespace.name

# Generated at 2022-06-12 12:45:27.019617
# Unit test for function get_definitions
def test_get_definitions():
    if not _using_older_jedi(__import__("jedi")):
        return
    from unittest import TestCase, main
    from test.util import captured_output, run_in_debug_mode

    class JediTest(TestCase):
        def setUp(self):
            self.source = """
y = 6
y = "a"
            """
            self.r, self.c = (2, 0)

        @run_in_debug_mode
        def test_basic(self):
            definitions = get_definitions(self.source, self.r, self.c, "<module>")
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_name, "<module>")


# Generated at 2022-06-12 12:45:52.761243
# Unit test for function get_script_completions
def test_get_script_completions():
    def make_source(line):
        return """\
""" + line + """
"""

    def assert_completions(source, expected):
        result = get_script_completions(source, 2, len(source.strip()) + 1, "")
        completions = []
        for completion in result:
            completions.append(completion.complete)

        assert sorted(completions) == sorted(expected)

    assert_completions(make_source("1+"), ["1 + ", "1 +="])
    assert_completions(make_source("1+1"), ["1 + ", "1 +="])
    assert_completions(make_source("1+1 "), [])
    assert_completions(make_source("1+1+"), ["1 + ", "1 +="])
    assert_com

# Generated at 2022-06-12 12:46:01.744042
# Unit test for function get_definitions
def test_get_definitions():
    # Test if get_definitions is working
    source = """
    import os
    def foo():
        pass
    d = {}
    d['key']
    """
    def_list = get_definitions(
        source, row=7, column=6, filename="file.py"
    )
    assert len(def_list) == 1
    assert def_list[0].type == "dictionary"
    assert def_list[0].description == "dictionary"
    assert def_list[0].name == "dict"
    assert def_list[0].full_name == "builtins.dict"



# Generated at 2022-06-12 12:46:13.592270
# Unit test for function get_script_completions
def test_get_script_completions():
    # Attribute completions
    source = "import json\n json.d"

# Generated at 2022-06-12 12:46:21.998294
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    int_completions = get_interpreter_completions("import sys;sys.path", [{}])
    assert int_completions == [ThonnyCompletion(name="path", complete="path", type="sys_var", description="", parent=None, full_name="sys.path")]
    int_completions = get_interpreter_completions("import sys;sys.pa", [{}])
    assert len(int_completions) == 2

# Generated at 2022-06-12 12:46:27.702133
# Unit test for function get_script_completions
def test_get_script_completions():

    source = "def f():\n  return 1"
    completions = get_script_completions(source, 2, 5, "untitled")
    assert len(completions) == 1
    assert completions[0].complete == "return"
    assert completions[0].type == "statement"
    assert completions[0].description == "return_stmt: return <\\n>"



# Generated at 2022-06-12 12:46:39.307291
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    jedi_ver = jedi.__version__
    """
    Test the function get_script_completions
    """
    source = """
        def func(arg):
            import re
            re.compile("test")

        def other_func(arg):
            pass

        for i in range(10):
            """
    # Test for completions
    row = 2
    column = 8

# Generated at 2022-06-12 12:46:49.591427
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    interpreter = jedi.Interpreter("numpy.ones((10, 10))", [{'numpy': jedi.names.Module}])
    defs = get_interpreter_completions("numpy.ones((10, 10))[1].(", [{'numpy': jedi.names.Module}])
    assert(len(defs) == 5)


if __name__ == "__main__":
    # Testing
    source = "import numpy\nnumpy.ones((10, 10))[1].max()"
    print(get_script_completions(source, 3, 15))
    print(get_script_completions(source, 3, 15, "/tmp/foo.py"))

# Generated at 2022-06-12 12:46:52.332551
# Unit test for function get_definitions
def test_get_definitions():
    Parser = __import__('parso.python.parser').python.parser.PythonParser
    parser = Parser()

# Generated at 2022-06-12 12:46:57.104016
# Unit test for function get_script_completions
def test_get_script_completions():
    assert isinstance(
        get_script_completions("import", 0, 7, "script.py"), list
    ), "Didn't recieve a list of completions"
    assert isinstance(
        get_script_completions("import math\nm", 1, 1, "script.py"), list
    ), "Didn't recieve a list of completions"



# Generated at 2022-06-12 12:47:06.388184
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch

    assert get_script_completions("Fin", 1, 4, "") == []
    assert get_script_completions("Fin", 1, 3, "") == []
    assert get_script_completions("Fin", 1, 2, "") == []
    assert get_script_completions("Fin", 1, 1, "") == []
    assert get_script_completions("FIn", 1, 3, "") == []
    assert get_script_completions("FIn", 1, 4, "") == []
    assert get_script_completions("FIn", 1, 2, "") == []


# Generated at 2022-06-12 12:47:45.464248
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os.path

    from jedi.parser_utils import get_cached_code_lines

    dir = os.path.dirname(os.path.realpath(__file__))
    # source with a class definition
    test_file = os.path.join(dir, "scripts/utils_test.py")
    source1 = get_cached_code_lines(test_file)

    # source with a function definition
    test_file = os.path.join(dir, "scripts/utils_test_func.py")
    source2 = get_cached_code_lines(test_file)

    # source with a lambda definition
    test_file = os.path.join(dir, "scripts/utils_test_lambda.py")
    source3 = get_cached_code_lines(test_file)

    #

# Generated at 2022-06-12 12:47:53.645963
# Unit test for function get_script_completions
def test_get_script_completions():
    from pathlib import Path
    from jedi import Interpreter, Script
    from jedi.api import classes

    # test for completion for variable
    source = "from math import asi"
    script = Script(source, 1, 1, "")
    completions = script.completions()
    print(type(completions[0]))
    print(completions[0].type)
    print(isinstance(completions[0], Interpreter))  # should be false
    assert(completions[0].type == "function")

    # Test that completions in autocomplete works like the completions in goto definition
    source = "from math import asi"
    script = Script(source, 1, 1, "")
    goto_definitions = script.goto_definitions()

# Generated at 2022-06-12 12:47:57.108107
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import os\n"
    source += "os.path.join('a', 'b')\n"

    completions = get_script_completions(source, 3, 2, "t.py")

    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].description == "function join(iterable, sep=None)Join a sequence of path components into a path."
    assert completions[0].type == "function"



# Generated at 2022-06-12 12:48:06.383150
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest.mock

    with unittest.mock.patch("thonny.jedi_utils.jedi.Interpreter") as m_jedi_interpreter:
        m_jedi_interpreter.completions.return_value = [
            DummyCompletion(name="foo", full_name="x.y.z.foo")
        ]
        result = get_interpreter_completions('print("foo")', [{"x":{"y":{"z": {}}}}], sys_path=[])

    assert len(result) == 1
    assert result[0].name == "x.y.z.foo"



# Generated at 2022-06-12 12:48:08.345151
# Unit test for function get_definitions

# Generated at 2022-06-12 12:48:16.084553
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"__builtins__": {}}]

    assert "int" in [c["complete"] for c in get_interpreter_completions("int", namespaces)]
    assert "int" in [c["name"] for c in get_interpreter_completions("int", namespaces)]
    assert "int" in [c["complete"] for c in get_interpreter_completions("int", namespaces)]

    assert "array_repr" in [c["complete"] for c in get_interpreter_completions("array", namespaces)]
    assert "array_repr" in [c["name"] for c in get_interpreter_completions("array", namespaces)]

# Generated at 2022-06-12 12:48:22.149066
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """Test case:
    import os
    import
    """
    source = """import os
import """
    namespaces = [{"builtins": __builtins__}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    comp_names = [c.name for c in completions]
    assert "os" in comp_names
    assert "sys" in comp_names

# Generated at 2022-06-12 12:48:28.086872
# Unit test for function get_definitions
def test_get_definitions():
    definitions = get_definitions(
        "import mock\nmock.Mock()", 0, len("import mock\nmock.Mock()"), "some_file.py"
    )

# Generated at 2022-06-12 12:48:33.886728
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    if _using_older_jedi(jedi):
        source = "str("
        namespaces = [{}]
        expected = ['str(', 'strip(', 'split(', 'splitlines(']
    else:
        source = "import'abcde'"
        namespaces = []
        expected = ["import abcde"]

    completions = get_interpreter_completions(source, namespaces)
    assert [c.complete for c in completions] == expected

# Generated at 2022-06-12 12:48:43.992513
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso.python.tree
    import unittest

    from jedi.api.classes import Completion

    if _using_older_jedi(jedi):
        assert get_interpreter_completions

    def get_completions(source, namespaces):
        if _using_older_jedi(jedi):
            # jedi before 0.16
            namespaces = [tree.Array(parso.python.tree.Name("fake"), [n]) for n in namespaces]
        return get_interpreter_completions(source, namespaces)


# Generated at 2022-06-12 12:49:43.299976
# Unit test for function get_definitions
def test_get_definitions():
    filename = "/tmp/test.py"
    source = "import numpy as np\nimport pandas as pd\nimport matplotlib.pyplot as plt\n"
    assert get_definitions(source, 1, 7, filename) == []
    assert get_definitions(source, 1, 8, filename) != []
    assert get_definitions(source, 1, 8, filename)[0]["name"] == "numpy"

# Generated at 2022-06-12 12:49:50.503961
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    from parso.python import tree

    class ThonnyTestCase(TestCase):
        def execute(self, source: str, position: int, expected: str) -> None:
            jedi_completions = get_script_completions(source, 0, position, "test.py")
            for completion in jedi_completions:
                if completion.name == expected:
                    return
            self.fail()

        def execute2(self, source: str, position: int, expected: str) -> None:
            jedi_completions = get_interpreter_completions(source, [{"foo": 2}])
            for completion in jedi_completions:
                if completion.name == expected:
                    return
            self.fail()


# Generated at 2022-06-12 12:49:56.551822
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.names import ValueName

    namespaces = [{
        "a": ValueName(name="a", parent=None, is_value=True)
    }]

    result = get_interpreter_completions("a", namespaces, [])
    assert len(result) == 1
    assert result[0]["name"] == "a"
    assert result[0]["complete"] == "a"



# Generated at 2022-06-12 12:50:05.768144
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys

    path_thonny_completions = os.path.abspath(os.path.join(sys.executable, os.pardir))
    path_thonny_completions = os.path.join(path_thonny_completions, "Lib", "thonny")
    test_file_path = os.path.join(path_thonny_completions, "thonny", "common")
    test_file_name = "source_utils.py"
    test_file = os.path.join(test_file_path, test_file_name)
    assert os.path.isfile(test_file)

    from thonny.plugins.jedi_backend import jedi_utils


# Generated at 2022-06-12 12:50:07.712833
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:50:15.950591
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    print("Testing if Jedi version is " + jedi.__version__)
    if _using_older_jedi(jedi):
        print("Testing with older Jedi")
        source = "from datetime import"
        row = 1
        column = len("from datetime import")
        filename = "tester.py"

# Generated at 2022-06-12 12:50:25.804333
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock

    interpreter = MagicMock()
    interpreter.complete = lambda: [MagicMock(type="keyword", name="a keyword")]

    namespaces = [
        {
            "name": "ns1",
            "doc": "ns1 doc",
            "type": "module",
            "module_path": "module_path",
            "module_name": "module_name",
        },
        {
            "name": "ns2",
            "doc": "ns2 doc",
            "type": "module",
            "module_path": "module_path",
            "module_name": "module_name",
        },
    ]

    completions = get_interpreter_completions(interpreter, "some source", namespaces)

# Generated at 2022-06-12 12:50:34.630007
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class TestGetInterpreterCompletions_18(unittest.TestCase):
        @unittest.skipIf(_using_older_jedi(jedi), "requires version 0.18 or newer")
        def test_vanilla(self):
            completions = get_interpreter_completions(
                source="a = 1\na", namespaces=[]
            )
            self.assertEqual(
                completions,
                [ThonnyCompletion(name="abs", complete="abs", type="statement", description="abs = <built-in function abs>", parent=None, full_name="abs")],
            )


# Generated at 2022-06-12 12:50:38.390930
# Unit test for function get_script_completions
def test_get_script_completions():

    source = "import unittest\n" "unittest."
    row = 2
    column = 13
    filename = "myfilename.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0



# Generated at 2022-06-12 12:50:46.687845
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree
    from copy import copy

    completions = get_interpreter_completions(
        source="int",
        namespaces=[{'__builtins__': __builtins__, 'a': tree.SimpleStatement('a=2')}],
    )
    first_completion = completions[0]
    assert first_completion.name == "int" and first_completion.full_name == "int"
    assert first_completion.type == "statement"

# Generated at 2022-06-12 12:52:46.165265
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock


# Generated at 2022-06-12 12:52:56.403100
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'from math import *\n'
    source += 'x = 5\n'
    source += 'y = 6\n'
    source += 'my_func = lambda x: x\n'
    source += 'my_variable = 5.6\n'
    source += 'my_string = "Hello World!"\n'
    source += 'my_list = [1,2,3]\n'
    source += 'my_dict = {"key_1": "value"}\n'
    source += 'my_tuple = ("tuple_value",)\n'
    source += 'my_class = MyClass()\n'
    source += 'my_class.my_class_attribute\n'
    source += 'my_class.my_class_attribute.my_class_attribute2\n'

# Generated at 2022-06-12 12:53:00.607005
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench
    from thonny.plugins.jedi_support import BackendProxy

    if not BackendProxy.get_completions:
        raise unittest.SkipTest("Skipping because of missing jedi")

    workbench = get_workbench()
    workbench.create_editor("foo.py", "")
    editor = workbench.get_editor_notebook().get_current_editor()
    editor.set_text("    int\n    if\n    x.is")

    BackendProxy.get_completions("foo.py", 2, 8)


# Generated at 2022-06-12 12:53:09.863704
# Unit test for function get_script_completions
def test_get_script_completions():
    assert "open" in [c.name for c in get_script_completions("import os\nos.\n", 1, 3, "")]
    assert "open" in [c.name for c in get_script_completions("import os\nos.\n", 1, 3, "", sys_path=["/tmp"])]
    assert "open" in [c.name for c in get_script_completions("import os\nos.\n", 1, 3, "", sys_path=[""])]
    assert "open" in [c.name for c in get_script_completions("import os\nos.\n", 1, 3, "", sys_path=[])]

# Generated at 2022-06-12 12:53:14.654944
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from math import sqrt"
    row = 1
    column = 16
    filename = "somefile"
    completions = get_script_completions(source, row, column, filename)
    assert completions == [ThonnyCompletion(name="sqrt", complete="sqrt", type="function", description="sqrt(...)", parent="math", full_name="math.sqrt")]

# Generated at 2022-06-12 12:53:21.102165
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    import thonny.jedi_utils
    import jedi


# Generated at 2022-06-12 12:53:30.472364
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import unittest

    def f():
        pass

    class A:
        pass
    class B:
        pass

    namespaces = [
        {"__builtins__": __builtins__, "__name__": "__main__"},
        {},
        {},
        {"f": f, "sys": sys, "A": A, "B": B, "__name__": "__main__"},
        {"C": object, "sys": sys, "__name__": "__main__"},
    ]

    class GetInterpreterCompletionsCase(unittest.TestCase):
        def test_simple_case(self):
            completions = get_interpreter_completions("", namespaces, sys.path)
            self.assertEqual(len(completions), 0)


# Generated at 2022-06-12 12:53:36.645503
# Unit test for function get_definitions
def test_get_definitions():
    from unittest.mock import Mock

    checker = Mock()
    checker.create_completion.return_value.name = "whatever"


# Generated at 2022-06-12 12:53:43.251872
# Unit test for function get_definitions
def test_get_definitions():
    import time
    from jedi.evaluate import compiled
    compiled.cache.clear()
    from jedi.evaluate.compiled import get_special_object
    print((get_special_object("None")))
    print((time.time()))
    print(get_definitions("None",1,1,"test.py"))
    print((time.time()))
    print((get_special_object("None")))
    print((time.time()))
    print(get_definitions("None",1,1,"test.py"))
    print((time.time()))
    print(get_definitions("None",1,1,"test.py"))
    print((time.time()))
    print((get_special_object("None")))
    print((time.time()))

# Generated at 2022-06-12 12:53:50.081707
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # This test is written based on jedi 0.15.2 - 0.17.1
    print("Testing jedi version: ", jedi.__version__)
    print("Using older version?", _using_older_jedi(jedi))
    print("Jedi completion: ", jedi.__version__[:4])

    import unittest
    import types
