

# Generated at 2022-06-12 12:44:29.898181
# Unit test for function get_script_completions
def test_get_script_completions():
    print("get_script_completions returns:",
          get_script_completions("x = 'a'\nx.", 2, 4))

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:44:40.289214
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    import jedi
    if not _using_older_jedi(jedi):
        return
    code = """import collections
import datetime
a = ""
a.
collections.
datetime.
"""
    namespaces = [
        {
            "type": "builtin",
            "path": "",
            "name": "__builtins__",
            "namespace": Interpreter(code, [])
            .namespace()
            .pop("__builtins__"),
        }
    ]
    completions = get_interpreter_completions(code, namespaces)
    assert completions[0].name == "split"
    assert completions[1].name == "splitlines"
    assert completions[2].name == "startswith"
    assert comple

# Generated at 2022-06-12 12:44:49.243962
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions
    import jedi

    if _using_older_jedi(jedi):
        for stmt in ["", "1", "1+", "\"\"\""]:
            completions = get_interpreter_completions(stmt, [{}, jedi.builtin_namespace])
            if completions:
                assert completions[0].name == "1"
                assert completions[0].complete == "1"
                assert completions[0].type == "literal"

    else:
        for stmt in ["", "1", "1+", "\"\"\""]:
            completions = get_interpreter_completions(stmt, [{}, jedi.typeshed.builtin_names])

# Generated at 2022-06-12 12:44:57.353175
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import sys\n", 2, 1, "test.py")
    assert len(completions) > 0
    assert any(c.name == "argv" for c in completions)

    assert get_script_completions("import sys\n", 1, 10, "test.py") == []
    assert get_script_completions("import sys\n", 2, 10, "test.py") == []



# Generated at 2022-06-12 12:45:03.760930
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__

    print(__version__)
    print(get_script_completions("import os\nos.", 3, 6, ""))
    print(get_script_completions("import os\nos.path.", 4, 11, ""))
    print(get_script_completions("import os\nos.path.exists.", 4, 20, ""))


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:45:11.277813
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-12 12:45:18.487658
# Unit test for function get_script_completions
def test_get_script_completions():
    from os.path import exists, dirname, join
    from thonny import get_runner
    from thonny.globals import get_workbench

    get_workbench().set_option("editor.current_editor_language","en")
    get_workbench().set_option("run.default_interpreter_options.infer_sys_path","no")
    get_workbench().set_option("jedi.debug_level","0")
    get_worker_connection("jedi").send_to_worker(("init",""))
    get_runner().set_default_interpreter("3.8.0")

    def check(source, row, column, expected_completions):
        """
        Testing function to check if the Jedi get_script_completions() function is working correctly
        """

# Generated at 2022-06-12 12:45:28.836498
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:45:36.565503
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock
    from jedi.api.classes import Script, Completion

    _completions = [
        Completion("a", "a", None, None, None),
        Completion("b", "b", None, None, None),
        Completion("c", "c", None, None, None),
    ]
    _completions_with_index = [
        Completion("a", "a", None, None, None),
        Completion("b", "b[i]", None, None, None),
        Completion("c", "c", None, None, None),
    ]

    _source = "a"
    _row = 1
    _column = 1
    _filename = ""

    _mock_script = Mock()

# Generated at 2022-06-12 12:45:47.432948
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"os": jedi.Interpreter("import os", [{}]).names()[0]}]
    completions = get_interpreter_completions("os.", namespaces)

    assert len(completions) == 1
    completion = completions[0]
    assert completion.name == "os."
    assert completion.complete == "os"
    assert completion.description.startswith("module")
    assert completion.full_name == "os"
    assert isinstance(completion.parent, jedi.api.classes.Namespace)


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:46:06.843225
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    namespaces = [{'x': 10, 'y': 10}]
    source = 'x.+'
    completions = get_interpreter_completions(source, namespaces)
    assert completions
    if _using_older_jedi(jedi):
        assert 'x.__ixor__' in [c.complete for c in completions]
    else:
        assert 'x.__rpow__' in [c.complete for c in completions]
    assert 'y' not in [c.complete for c in completions]

# Generated at 2022-06-12 12:46:17.808380
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import Interpreter
    import jedi

    class DummyInterpreter(Interpreter):
        def __init__(self, source: str, namespaces: List[Dict[str, str]], sys_path=None):
            super().__init__(source, namespaces)

        def get_completions(self):
            return [(1, "one", ""), (2, "two", "")]

    def dummy_evaluator(source: str, namespaces: List[Dict[str, str]], sys_path=None):
        return DummyInterpreter(source, namespaces, sys_path=sys_path)

    from thonny.plugins.completion import utils as jedi_utils
    from unittest.mock import patch


# Generated at 2022-06-12 12:46:23.353102
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position

    source = """import sys\n"""

    root = parse_source(source)
    cursor_stmt = get_statement_of_position(
        root, source.index("import")
    )

    result = get_script_completions(source, 2, 5, filename="<string>")



# Generated at 2022-06-12 12:46:26.883395
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    d = {"a": 1, "b": 2}
    print(_tweak_completions([jedi.Definition("a", "a", (), "a", "a", "a", "a", "a")]))

# Generated at 2022-06-12 12:46:28.798151
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.languages import tr_lang
    

# Generated at 2022-06-12 12:46:34.406489
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import os.pat", 0, 14, "<stdin>", []) == [
        ThonnyCompletion(
            name="path",
            complete="path",
            type="module",
            description="Module subprocess",
            parent="Module os",
            full_name="os.path",
        )
    ]

# Generated at 2022-06-12 12:46:42.953612
# Unit test for function get_definitions
def test_get_definitions():
    source = "import tkinter\ntkinter.Tk()"
    if _using_older_jedi(jedi):
        expected = [
            {"description": "class tkinter.Tk(master=None, cnf={}, **kw)\n\nWidget of Tk which is "
                            "root of windowing system.",
             "module_path": "tkinter",
             "line": "1",
             "column": "11",
             "in_builtin_module": False,
             "type": "class"}
        ]

# Generated at 2022-06-12 12:46:47.041090
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import jedi.parser.user_context
    from jedi.api.classes import Namespace

    def test(source: str, namespaces: List[Dict], expected_names: List[str]):
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == len(expected_names)
        for completion in completions:
            assert completion.name in expected_names

    # User context allows jedi to see names from standard builtins module
    user_context = jedi.parser.user_context.get_context()
    # Jedi splits the namespaces into different modules, so here
    # we need to put the names into the builtins module
    builtins_namespace = Namespace(user_context, "builtins", 0)
    builtins_namespace._

# Generated at 2022-06-12 12:46:54.717421
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import json
    import random
    import jedi
    import string

    try:
        from jedi.api.project import get_default_project
        from jedi.evaluate.analysis import Analysis
    except ImportError:
        return
    from jedi.evaluate.cache import CachedMetaClass, memoize_default
    import thonny
    import sys
    import thonny.ast_utils as ast_utils

    # tweak jedi to use thonny's python_path
    thonny_project = get_default_project(path=os.path.dirname(thonny.__file__))
    thonny_project.add_environment(sys.executable)

    Analysis.thonny_project = thonny_project

    class TestAnalysis(Analysis):
        thonny_project = thonny

# Generated at 2022-06-12 12:47:01.908719
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test for namespaces
    import jedi
    namespaces = [
        {"__name__": "__main__", "foo": "bar"},
        {"__name__": "__main__"},
        {"__name__": "__main__", "_": "helper_func", "__builtins__": True},
        {"__name__": "__main__", "__builtins__": True, "a": True, "b": False},
    ]

    source = "a."
    # NB! Can't send project for Interpreter in 0.18
    # https://github.com/davidhalter/jedi/pull/1734
    interpreter = jedi.Interpreter(source, namespaces)
    completions = interpreter.complete()

    result = []
    for completion in completions:
        name = completion.name


# Generated at 2022-06-12 12:47:29.787145
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.context import InterpreterEnvironment
    from jedi.evaluate.compiled import CompiledObject

    class MyInterpreterEnvironment(InterpreterEnvironment):
        def __init__(self, interpreter):
            super().__init__()
            self.interpreter = interpreter

        def get_value(self, name):
            if name == "exec":
                return CompiledObject(
                    "exec", "", "", "", "", "", "", "", "", "", self.interpreter
                )
            else:
                return None

    class MyInterpreter(object):
        def __init__(self, source, namespaces):
            self.source = source
            self.namespaces = namespaces


# Generated at 2022-06-12 12:47:40.137377
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from parso.python import tree

    assert _using_older_jedi(jedi)
    script = jedi.Script(source='import datetime', filename='.thonny-temp.py')
    comps = script.completions()
    assert isinstance(comps[0], jedi.api.classes.Completion)
    assert comps[0].name == 'datetime'
    assert comps[0].complete == 'datetime'
    assert comps[0].type == 'module'
    assert comps[0].description == 'datetime\nThe `datetime'

    comps = _tweak_completions(comps)
    assert isinstance(comps[0], ThonnyCompletion)
    assert comps[0].name == 'datetime'

# Generated at 2022-06-12 12:47:50.145432
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python import tree
    from jedi.parser_utils import get_statement_of_position

    source = "import sys; sys.pa"
    row = 1
    column = 13
    filename = "test.py"

    defs = get_script_completions(source, row, column, filename)
    assert len(defs) == 2

    source = "from tkinter import Canvas; Canvas."
    row = 1
    column = 28
    filename = "test.py"

    defs = get_script_completions(source, row, column, filename)
    assert len(defs) > 200
    assert defs[0].name == "Canvas"
    assert defs[0].complete == "Canvas"
    assert defs[0].type == "class"
    assert defs

# Generated at 2022-06-12 12:47:58.446114
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import sentinel
    import jedi

    completions = get_script_completions(
        source="", row=0, column=0, filename=sentinel.filename, sys_path=[sentinel.sys_path]
    )

    assert jedi.Script.called
    assert jedi.Script.call_args_list[0][0][0] == ""
    assert jedi.Script.call_args_list[0][0][1] == 0
    assert jedi.Script.call_args_list[0][0][2] == 0
    assert jedi.Script.call_args_list[0][0][3] == sentinel.filename
    assert jedi.Script.call_args_list[0][1]["sys_path"] == [sentinel.sys_path]
    assert j

# Generated at 2022-06-12 12:48:09.876241
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    def _test_get_interpreter_completions(source, namespaces, expected):
        from jedi.api.interpreter import Interpreter

        with mock.patch("jedi.api.interpreter.Interpreter") as mock_interpreter:
            mock_interpreter.return_value.complete.return_value = expected
            result = get_interpreter_completions(source, namespaces)
            assert result == expected

    def _test(source, namespaces, expected_in, sys_path=None):
        expected = [ThonnyCompletion(name, name, "", "", None, name) for name in expected_in]
        _test_get_interpreter_completions(source, namespaces, expected)

    # test for issue #548
   

# Generated at 2022-06-12 12:48:14.884351
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    interpreter = Interpreter("import datetime")
    completions = get_interpreter_completions("datetime.", [], None)
    assert len(completions) > 20
    assert "datetime.timedelta" in [c.complete for c in completions]
    assert "timedelta" in [c.name for c in completions]


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-12 12:48:17.951086
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("import os; os.path.dirname", 0, 0, "bla.py") != None
    assert get_definitions("print", 0, 0, "bla.py") != None

# Generated at 2022-06-12 12:48:26.175717
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import unittest
    import sys

    class CompletionTest(unittest.TestCase):
        # test completions for code that is located in a file
        def test_file(self):
            code = "import sys\nprint(sys.vers"
            row = 2
            column = 15
            filename = "test.py"
            completions = get_script_completions(
                code, row, column, filename, sys.path
            )
            self.assertTrue(len(completions) != 0)

        # test completions for code that is located in an editor buffer
        def test_buffer(self):
            code = "import sy\nprint(sys.vers"
            row = 2
            column = 15
            filename = "test.py"
            completions = get_script_complet

# Generated at 2022-06-12 12:48:30.943372
# Unit test for function get_script_completions
def test_get_script_completions():
    import re

    # Test completion of a local variable
    text = 'x = "test"\nx.'

    completions = get_script_completions(text, text.count("\n"), len(text), "dummy.py")
    assert len(completions) > 10
    for item in completions:
        assert re.match(r'^[a-zA-Z0-9_]+$', item['name'])
        assert item['complete'] == item['name']
        assert item['type'] == "statement"
        assert item['parent'] == "str"
        assert item['full_name'] == "str." + item['name']

    # Test for completion in a module
    text = 'import datetime; datetime.'

# Generated at 2022-06-12 12:48:36.051278
# Unit test for function get_definitions

# Generated at 2022-06-12 12:49:02.117708
# Unit test for function get_definitions
def test_get_definitions():
    def _check(code, pos, expected):
        result = get_definitions(code, pos[0], pos[1], "test.py")
        result = [[r.line, r.column, r.description] for r in result]
        assert result == expected

    _check("foo\nbar\nxyz", (2, 1), [])  # unknown
    _check("a = 1\n", (1, 1), [[1, 1, 'int']])  # defined in current module
    _check("import math\nmath.sin", (2, 1), [[1965, 4, 'sin(x, /)']], )  # module, standard library
    _check("from math import sin\nsin", (2, 1), [[1965, 4, 'sin(x, /)']], )

# Generated at 2022-06-12 12:49:09.810271
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def check_jedi_version(jedi_version, expected_result):
        if not jedi_version.startswith(tuple(expected_result.keys())):
            return
        version_result = expected_result[jedi_version[0:3]]
        for i in range(len(version_result)):
            result = get_script_completions(
                """prin""",
                1,
                5,
                "hello.py",
            )
            assert result[i].name == version_result[i]


# Generated at 2022-06-12 12:49:21.003197
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"__builtins__": __builtins__}]

    result = get_interpreter_completions("print", namespaces)
    assert len(result) == 1
    assert result[0].name == "print"
    assert result[0].type == "statement"
    assert result[0].description == "print(value, ...)\\n\\nPrints the values to a stream, or to sys.stdout by default."

    result = get_interpreter_completions("print(1, 2 + ", namespaces)
    assert len(result) == 1
    assert result[0].name == "end="
    assert result[0].type == "statement"
    assert result[0].description == "end : str, optional\\n    String appended after the last value, default a newline."

# Unit test

# Generated at 2022-06-12 12:49:28.215660
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_jediasync import jedi_completions
    from thonny.jedi_utils import get_interpreter_completions

    namespaces = [{"a": "int"}]
    source = "a."
    completions = get_interpreter_completions(source, namespaces)
    assert jedi_completions(completions) == ["bit_length", "conjugate", "denominator", "from_bytes", "imag", "numerator", "real", "to_bytes"]



# Generated at 2022-06-12 12:49:34.266711
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser import load_grammar

    grammar = load_grammar()
    source_code = "import os"
    assert source_code[13] == "o"
    source_code = source_code.splitlines()
    coms = get_script_completions(source_code[0], 1, 13, "dummy.py")
    coms = {com.name for com in coms}
    assert "os" in coms



# Generated at 2022-06-12 12:49:44.351228
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from tests.helpers import run_test_in_empty_workbench

    def check():
        assert get_interpreter_completions("int()", []) == []
        assert get_interpreter_completions("int().", [])[0].name == "bit_length"
        assert get_interpreter_completions("a = int()\na.", [{"a": 1}])[0].name == "bit_length"
        assert get_interpreter_completions("a = int()\na.", [])[0].name == "bit_length"
        assert get_interpreter_completions("os.path.join().", [])[0].name == "base_name"

# Generated at 2022-06-12 12:49:53.564596
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import parser
    from jedi.evaluate.object_.module import Module

    def parse_module(source):
        return parser.load_grammar().parse(source)

    mod = parse_module("class A: pass")
    mod = Module(
        "test",
        mod,
        sys_path=[],
        path="",
        is_package=False,
        is_builtin=False,
        use_2to3=False,
    )

    from jedi.evaluate.imports import Importer

    importer = Importer([mod], [], True, parser._create_grammar_table()[0])

    def get_definitions(module, path):
        return importer.eval_module(module, path, evaluator=None).as_context()


# Generated at 2022-06-12 12:50:01.853644
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:50:11.246045
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi import utils
    from unittest.mock import MagicMock

    mock_jedi_completion = MagicMock()

    mock_jedi_completion.name = "mock_name"
    mock_jedi_completion.complete = "mock_complete"
    mock_jedi_completion.type = "mock_type"
    mock_jedi_completion.description = "mock_description"
    mock_jedi_completion.parent = "mock_parent"
    mock_jedi_completion.full_name = "mock_full_name"


# Generated at 2022-06-12 12:50:20.340824
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if jedi.__version__[:4] in ["0.11", "0.12"]:
        # no Interpreter before jedi 0.11
        # https://github.com/davidhalter/jedi/commit/4a9a2a56a4c80d8e0fde6b1c6f7b6ab53051eb88
        return []

    import jedi.parser

    module = jedi.parser.get_default_grammar().parse(
        "import sys;sys.stderr.write('abc');sys.stderr.flush()"
    )
    statements = module.iter_funcdefs()

# Generated at 2022-06-12 12:50:58.758594
# Unit test for function get_script_completions
def test_get_script_completions():
    def run_test(sys_path, expected_names):
        completions = get_script_completions(
            "import mod_a\nmod_a.foo", row=2, column=11, filename="source.py", sys_path=sys_path
        )
        actual_names = [c.name for c in completions]
        assert actual_names == expected_names, f"{actual_names} != {expected_names}"

    with open("jedi_utils_test_files/proj_a/mod_a.py", "r") as mod_a:
        with open("jedi_utils_test_files/proj_a/mod_b.py", "r") as mod_b:
            mod_a_content = mod_a.read()
            mod_b_content = mod_b.read

# Generated at 2022-06-12 12:51:06.956377
# Unit test for function get_definitions
def test_get_definitions():
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 0, "")])
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 1, "")])
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 10, "")])
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 12, "")])
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 13, "")])
    print([d.description for d in get_definitions("import sys; sys.stderr", 0, 100, "")])

# Generated at 2022-06-12 12:51:11.553790
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
            import builtins
            builtins.
            """
    # Remove indentation
    source = source.strip()
    namespaces = [{"builtins": __builtins__}]
    assert len(get_interpreter_completions(source, namespaces)) > 100



# Generated at 2022-06-12 12:51:15.146260
# Unit test for function get_definitions
def test_get_definitions():
    d = get_definitions("import sys ; sys.argv", 0, 26, "")
    assert len(d) == 1
    assert d[0].module_name == "sys"
    assert d[0].name == "argv"


if __name__ == "__main__":
    test_get_definitions()
    print("OK")

# Generated at 2022-06-12 12:51:24.132705
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test function with older Jedi version
    import jedi
    try:
        old_jedi = jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]
    except AttributeError:
        old_jedi = True
    if old_jedi:
        from jedi.api.helpers import _get_statement_of_position

        _copy_of_get_statement_of_position(0, 0)

    # Test function with older Jedi version
    source = "print('')"
    row, column = 1, 5
    filename = "source.py"
    sys_path = ["/home/user/python_modules/"]

# Generated at 2022-06-12 12:51:33.104852
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import tempfile
    import os
    import sys

    TEST_FILE_CONTENT = "def get_definitions():\n    a = 1\n    a.split()\n"

    class TestCase(unittest.TestCase):
        def test_get_definitions(self):
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as fp:
                fp.write(TEST_FILE_CONTENT)

# Generated at 2022-06-12 12:51:40.249736
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source="""
import os
import threading
threading.Thread()
""".strip()

    try:
        completions = get_interpreter_completions(source, [{"os": os, "threading": threading}])
    except Exception as e:
        raise Exception("Failed for jedi version: " + jedi.__version__ + " => " + str(e))

    assert len(completions) > 0
    completion = completions[0]
    assert completion.name == "daemon"


cached_docstring = None


# Generated at 2022-06-12 12:51:42.030079
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\ndef foo():\n    p"
    completions = get_script_completions(source, 3, 3, "")
    assert completions[0].name == "print"



# Generated at 2022-06-12 12:51:50.715886
# Unit test for function get_definitions
def test_get_definitions():
    source = """
    class A:
        def f(self):
            pass

    class B:
        pass
    """

    defs = get_definitions(source, 2, 10, "test.py")
    assert len(defs) == 1 and defs[0].type == "class"

    defs = get_definitions(source, 4, 10, "test.py")
    assert len(defs) == 1 and defs[0].type == "class"

    defs = get_definitions(source, 6, 11, "test.py")
    assert len(defs) == 1 and defs[0].type == "instance"



# Generated at 2022-06-12 12:52:00.533903
# Unit test for function get_definitions
def test_get_definitions():
    from thonny import backends

    assert backends.utils.get_definitions("a = 5", 0, 0, "") == []
    assert backends.utils.get_definitions("a = 5", 0, 2, "") == []
    assert backends.utils.get_definitions("a = 5", 0, 3, "") == [
        backends.utils.ThonnyCompletion(
            "a", "a", "statement", "statement: a = 5", "<module>", "a"
        )
    ]
    assert backends.utils.get_definitions("a = b", 0, 3, "") == [
        backends.utils.ThonnyCompletion(
            "b", "b", "statement", "statement: b", "<module>", "b"
        )
    ]
    assert backends

# Generated at 2022-06-12 12:53:07.617773
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import unittest

    from unittest import mock

    with mock.patch("sys.path", new=sys.path[:]):  # make sure we don't add args to real sys.path
        # test normal completion
        completion = get_interpreter_completions("open()", [], ["/home/user/my_module.py"])[0]
        assert isinstance(completion, ThonnyCompletion)
        assert completion.name == "open"
        assert completion.complete == "open("
        assert completion.type == "function"

# Generated at 2022-06-12 12:53:11.906611
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("import yes", 0, 0, "/tmp/test.py")) == 1
    assert get_definitions("import yes", 0, 0, "/tmp/test.py")[0].module_name == "yes"
    assert get_definitions("from yes import no", 0, 0, "/tmp/test.py")[0].module_name == "yes"


# Generated at 2022-06-12 12:53:18.545289
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        print("jedi before 0.18")
        cpls = get_script_completions("import random; random.ra", 2, 16, "test.py")
        assert cpls[0].complete == "random.random()"
    else:
        print("jedi 0.18 and later")
        cpls = get_script_completions("import random; random.ra", 2, 16, "test.py")
        assert cpls[0].complete == "random.randint()"


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-12 12:53:23.732089
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test simple variable completion with no import
    s = """
x = 5
y = x
y.isnumeric()
a = "abc"
a.
"""
    completions = get_script_completions(s, 5, 12, filename="")
    assert completions[0].name == "isnumeric"
    assert completions[1].name == "isspace"
    assert completions[-1].name == "title"

    # Test completion with import
    s = """
import os
import sys
os.path.abspath(
"""
    completions = get_script_completions(s, 2, 21, filename="")
    assert completions[0].name == "abspath"
    assert completions[0].parent == "O"

    # Test completion on a class

# Generated at 2022-06-12 12:53:30.743339
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [
        {
            "__builtins__": {
                "abs": "foo",
                "all": "foo",
                "any": "foo",
                "ascii": "foo",
            },
        }
    ]
    source = 'a = "A"; a.'

    completions = get_interpreter_completions(source, namespaces)

    assert len(completions) > 0
    assert any(c.type == "function" and c.name == "ascii" for c in completions)
    assert any(c.type == "definition" and c.name == "a" for c in completions)

# Generated at 2022-06-12 12:53:38.003450
# Unit test for function get_script_completions
def test_get_script_completions():
    source = 'import math\nmath.'
    completions = get_script_completions(source, 2, 7, "<stdin>") # NB! Jedi considers 1 to be the first row
    names = [c.name for c in completions]

# Generated at 2022-06-12 12:53:44.437670
# Unit test for function get_interpreter_completions

# Generated at 2022-06-12 12:53:48.282249
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock

    script = MagicMock()
    result = get_script_completions(script, 0, 0, None)
    assert result == script.completions.return_value

    result = get_script_completions(script.code, script.line, script.column, script.path, script.sys_path)
    assert result == script.complete.return_value

# Generated at 2022-06-12 12:53:55.098250
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("min(", 1, 4, "test.py", [])
    assert len(completions) == 1
    completion = completions[0]
    assert completion["name"] == "min"
    assert completion["complete"] == "min()"
    assert completion["type"] == "function"
    assert completion["description"] == ""
    assert completion["parent"] == "builtins"
    assert completion["full_name"] == "builtins.min"

    completions = get_script_completions(
        "import sys\nsys.pa", 3, 9, "test.py", ["/usr/lib"]
    )
    assert len(completions) == 1
    completion = completions[0]
    assert completion["name"] == "path"

# Generated at 2022-06-12 12:54:01.990010
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test_jedi import get_fake_jedi

    jedi = get_fake_jedi()
    completions = get_interpreter_completions(
        "a = 123\na.knights", [{"a": "abc"}, {"abc": "abcd"}], jedi
    )
    assert len(completions) == 1
    c = completions[0]
    assert c.name == "knights"
    assert c.type == "instance"
    assert c.description == "abcd"
    assert c.parent == "abc"
    assert c.full_name == "abc.knights"

