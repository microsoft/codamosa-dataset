

# Generated at 2022-06-22 03:01:08.839749
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc1 = ThonnyCompletion("name1", "complete1", "type1", "description1", "parent1", "full_name1")
    assert tc1.name == "name1"
    assert tc1.complete == "complete1"
    assert tc1.type == "type1"
    assert tc1.description == "description1"
    assert tc1.parent == "parent1"
    assert tc1.full_name == "full_name1"

# Generated at 2022-06-22 03:01:11.372698
# Unit test for function parse_source
def test_parse_source():
    import parso

    module = parse_source("")
    assert type(module) is parso.tree.Module


# Generated at 2022-06-22 03:01:18.044806
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = """
if CONDITION:
    def func():
        return 1
    def func2():
        return 2

# This is a comment
    def func3():
        return 3
"""
    import parso
    root = parso.parse(source)
    node = get_statement_of_position(root, source.index("if"))
    assert node.get_kind() == "if_stmt"

    # middle of func
    node = get_statement_of_position(root, source.index("func():"))
    assert node.get_kind() == "funcdef"
    assert node.name.value == "func"

    # middle of func2
    node = get_statement_of_position(root, source.index("func2():"))
    assert node.get_kind() == "funcdef"

# Generated at 2022-06-22 03:01:23.376548
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import builtins
    import sys

    result = get_interpreter_completions("", [{"__builtins__": builtins}, {"sys": sys}])

    assert isinstance(result, list)
    assert len(result) > 100
    # print(result)



# Generated at 2022-06-22 03:01:32.262990
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    source = '''def func():\n    x = 1\n#CURSOR'''
    source = source.replace("#CURSOR", "")
    source_lines = source.splitlines(keepends=True)
    grammar = parso.load_grammar()
    module = grammar.parse(source)

    node = get_statement_of_position(module, len(source))
    assert node.start_pos == len(source_lines[0]) + len(source_lines[1])
    assert node.get_code().strip() == "#CURSOR"
    
    

# Generated at 2022-06-22 03:01:37.827435
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny import get_runner

    runner = get_runner()
    namespaces = runner.get_namespace().items()

    completions = get_interpreter_completions("import matplotlib", namespaces)
    assert len(completions) > 0
    maybematch = [c for c in completions if c["name"] == "pyplot"]
    assert maybematch is not None

# Generated at 2022-06-22 03:01:39.642135
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:01:50.157160
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock as mock

    source = """def foo():
    pass

foo()
"""
    row = 3
    column = 2

    definitions = get_definitions(source, row, column, "dummy.py")

    assert len(definitions) == 1
    defn = definitions[0]

    assert defn.module_name == "dummy.py"
    assert defn.line == 1
    assert defn.column == 5

    with mock.patch('thonny.globals.get_workbench().get_editor_notebook') as mock_get_editor_notebook:
        with mock.patch('thonny.globals.get_workbench().get_editor') as mock_get_editor:
            mock_get_editor_notebook.return_value.get_current_editor

# Generated at 2022-06-22 03:01:59.772588
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class GetDefinitionsTest(unittest.TestCase):
        def test_get_methods(self):
            import types

            # Known issue
            # methods_and_properties = get_definitions("a.a", 0, 2, types.ModuleType("<a>"), None)
            # self.assertEqual(methods_and_properties[0].type, "function")

            methods_and_properties = get_definitions("a.a", 0, 2, "<a>", [])
            self.assertEqual(methods_and_properties[0].type, "function")

    unittest.main(module="test_utils", exit=False)


# Generated at 2022-06-22 03:02:11.706434
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def check(source: str, namespaces: List[Dict], sys_path=None, expected_name=None):
        completions = get_interpreter_completions(source, namespaces, sys_path)
        if expected_name is None:
            assert len(completions) > 0
            return completions
        else:
            assert len(completions) == 1
            assert completions[0].name == expected_name

    check("sys.p", namespaces=[{"sys": sys}], expected_name="path")
    check("sys.path", namespaces=[{"sys": sys}], expected_name="path")
    check("sys.st", namespaces=[{"sys": sys}], expected_name="stdout")

# Generated at 2022-06-22 03:02:32.181754
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.tree import Leaf, Node, Line
    assert get_statement_of_position(None, None) is None

    assert get_statement_of_position(Leaf(None, None), None) is None

    node = Node(
        None,
        [
            Leaf(None, 1),
            Leaf(None, 2),
            Line([Leaf(None, 3), Leaf(None, 4)], None, 1, None),
            Leaf(None, 5),
        ],
    )
    assert get_statement_of_position(node, -1) is None
    assert get_statement_of_position(node, 0) is None
    assert get_statement_of_position(node, 1) == node.children[0]
    assert get_statement_of_position(node, 2) == node.children[1]
   

# Generated at 2022-06-22 03:02:32.752603
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:02:37.302574
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    str = 'import math\n' \
          'math.pow'
    completions = get_interpreter_completions(str, [{'math': math}])
    assert 'math.pow' in [c.name for c in completions]


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-22 03:02:43.162226
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    completions = get_script_completions("import os\nos.", 0, 10, "test")
    assert completions
    completion_names = [c.name for c in completions]
    assert "curdir" in completion_names
    assert "path" in completion_names
    assert "makedirs" in completion_names

    completions = get_script_completions("import os\nos.c", 0, 11, "test")
    assert completions
    completion_names = [c.name for c in completions]
    assert "curdir" in completion_names
    assert "path" in completion_names
    assert "makedirs" not in completion_names



# Generated at 2022-06-22 03:02:46.426224
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree
    from parso.python.diff import get_diff_info, diff_to_string


# Generated at 2022-06-22 03:02:52.736756
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name='Name',
        complete='Completion',
        type=None,
        description='Description',
        parent=None,
        full_name='Full Name',
    )

    assert completion["name"] == 'Name'
    assert completion["complete"] == 'Completion'
    assert completion["type"] == None
    assert completion["description"] == 'Description'
    assert completion["parent"] == None
    assert completion["full_name"] == 'Full Name'

if __name__ == '__main__':
    test_ThonnyCompletion___getitem__()
    print('OK')

# Generated at 2022-06-22 03:02:53.750701
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:03:00.808795
# Unit test for function get_definitions
def test_get_definitions():
    src = "import math\nm = math.cos(1)\nm"
    res = get_definitions(src, 2, 5, "")
    assert len(res) == 1
    assert res[0].line == 7
    assert res[0].column == 4
    assert res[0].module_name == "math"
    assert res[0].desc_with_module == "cos(...) method of builtins.math object"
    assert res[0].in_builtin_module
    assert res[0].full_name == "math.cos"

# Generated at 2022-06-22 03:03:11.578154
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion(name='name', complete='complete', type='type', description='description', parent='parent', full_name='full_name')
    if t['name'] != 'name':
        raise AssertionError
    if t['complete'] != 'complete':
        raise AssertionError
    if t['type'] != 'type':
        raise AssertionError
    if t['description'] != 'description':
        raise AssertionError
    if t['parent'] != 'parent':
        raise AssertionError
    if t['full_name'] != 'full_name':
        raise AssertionError

# Generated at 2022-06-22 03:03:20.659490
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock
    import importlib
    
    from test_get_definitions_data import TEST_CASES
    from test.test_utils import count_failures

    jedi = unittest.mock.Mock()
    jedi.__version__ = "0.17.0"
    
    importlib.reload(sys.modules["thonny.plugins.jedi_utils"])
    from thonny.plugins.jedi_utils import get_definitions
    from jedi import api_classes
    
    test_failures = 0
    
    for test_case in TEST_CASES:
        actual = []
        

# Generated at 2022-06-22 03:03:40.271177
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("a", 0, 1, "test.py") == []
    assert get_script_completions("a=", 0, 2, "test.py") == [
        ThonnyCompletion(name="a==", complete="a==", type="=", description="", parent="", full_name="")
    ]
    assert get_script_completions("class A:\n    def f(self):\n        a=1\n        return a", 3, 13, "test.py") == [
        ThonnyCompletion(name="a=", complete="a=", type="=", description="int", parent="", full_name="")
    ]

# Generated at 2022-06-22 03:03:52.698125
# Unit test for function get_script_completions
def test_get_script_completions():
    # make a module dummy.py
    with open("test_dummy.py", mode="w") as f:
        f.write("def foo(a,b):\n  pass\n  \nfoo(2,\n")
    # simulate parse_source
    import parso
    parse_tree = parso.parse("def foo(a,b):\n  pass\n  \nfoo(2,\n")
    # modify parse_tree
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script("def foo(a,b):\n  pass\n  \nfoo(2,\n", 4, 4)

# Generated at 2022-06-22 03:03:59.568991
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonnycontrib.jedi_utils import get_script_completions
    import jedi
    jedi_version = jedi.__version__
    def check(code, expected_results, row, column, filename, sys_path=None):
        comp = get_script_completions(code, row, column, filename, sys_path=sys_path)
        names = []
        for c in comp:
            names.append(c.name)
        assert (names == expected_results)

    # Test cases
    sys_path = ['/Users/bennett/Library/Preferences/Thonny/3.2.2/interpreters/python3.6-64bit/lib/python3.6']
    code = "os.chdir(/Users)"
    results = ['os.chdir']
    row

# Generated at 2022-06-22 03:04:08.910113
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert get_statement_of_position(None, None) == None

    from parso.python import tree

    class DummyNode(tree.PythonNode):
        def __init__(self, children = list(), start_pos = (1,2), end_pos = (3,4), type = None):
            self.children = children
            self.start_pos = start_pos
            self.end_pos = end_pos
            self.type = type

    class DummyGrandChildNode(DummyNode): pass
    class DummyChildNode(DummyNode): pass
    class DummyParentNode(DummyNode): pass

    gcnd = DummyNode()
    cnd = DummyChildNode([gcnd])
    pnd = DummyParentNode([cnd])


# Generated at 2022-06-22 03:04:17.937865
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    if completion["name"] != "name":
        raise AssertionError
    if completion["complete"] != "complete":
        raise AssertionError
    if completion["type"] != "type":
        raise AssertionError
    if completion["description"] != "description":
        raise AssertionError
    if completion["parent"] != "parent":
        raise AssertionError
    if completion["full_name"] != "full_name":
        raise AssertionError



# Generated at 2022-06-22 03:04:20.722525
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(name=1, complete=1, type=1, description=1, parent=1, full_name=1)

# Generated at 2022-06-22 03:04:32.072000
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    import jedi

    assert get_script_completions("", 0, 0, "") == []

    assert get_script_completions("a = 1", 0, 0, "") == ["a = "]
    assert get_script_completions("a = 1", 0, 1, "") == []
    assert get_script_completions("a = 1", 0, 2, "") == ["a = "]

    assert get_script_completions("a = 1", 0, 5, "") == []
    assert get_script_completions("a = 1", 1, 0, "") == []

    assert get_script_completions("a = 1\nb = 2", 1, 0, "") == ["b = "]

    assert get_script_completions

# Generated at 2022-06-22 03:04:32.831508
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = "import sys"
    assert parse_source(source) == parso.parse(source)

# Generated at 2022-06-22 03:04:44.629340
# Unit test for function get_script_completions
def test_get_script_completions():
    code = "def f(x,y): return x + y\nf(x=1, y"

    # Test older_jedi
    completions = get_script_completions(code, row=2, column=11, filename="test")
    expected = ThonnyCompletion(
        name="y=",
        complete="y=",
        type="param",
        description="parameter",
        parent="f",
        full_name="f.y",
    )
    assert len(completions) == 1
    assert completions[0] == expected

    # Test newer_jedi
    completions = get_script_completions(code, row=2, column=11, filename="test", sys_path=[])

# Generated at 2022-06-22 03:04:53.121725
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from thonny.plugins.jedi_utils import get_statement_of_position

    node = tree.Module()

    # Empty module
    assert get_statement_of_position(node, (1, 0)) is None
    assert get_statement_of_position(node, (0, 0)) is None

    # Simple module
    node.children.append(tree.String())
    assert get_statement_of_position(node, (1, 0)) is node.children[0]
    assert get_statement_of_position(node, (1, 10)) is node.children[0]
    assert get_statement_of_position(node, (0, 0)) is None
    assert get_statement_of_position(node, (10, 10)) is None

    # Simple module with newline
   

# Generated at 2022-06-22 03:05:17.889636
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import python_ast
    from parso.python.tree import Leaf

    AST = python_ast

    # stmt = AST(type='stmt',
    #            children=[AST(type='expr_stmt',
    #                         children=[Leaf(type='name', value='a'),
    #                                   Leaf(type='operator', value='='),
    #                                   AST(type='testlist',
    #                                       children=[AST(type='test',
    #                                                    children=[Leaf(type='number', value='42')])])]),
    #                     Leaf(type='newline')])
    # print(get_statement_of_position(stmt, 2))
    # assert get_statement_of_position(stmt, 2) == stmt.children[0]

    # stmt = AST

# Generated at 2022-06-22 03:05:28.606085
# Unit test for function get_definitions
def test_get_definitions():
    source = textwrap.dedent("""
    class SomeClass:
        def some_func(self, arg):
            self.arg = arg
            self.arg.split()
            self
        """
    )
    locations = [(6, 10), (6, 10), (7, 10), (8, 10)]
    expected_result = ['def some_func(self, arg)', 'def split()', 'def some_func(self, arg)', 'def __init__(self)']
    for location, expected in zip(locations, expected_result):
        assert get_definitions(source, *location)[0].description == expected


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-22 03:05:31.874768
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    keys = list(ThonnyCompletion('a', 'a', 'a', 'a', 'a', 'a').__dict__.keys())
    for key in keys:
        ThonnyCompletion('a', 'a', 'a', 'a', 'a', 'a')[key]



# Generated at 2022-06-22 03:05:44.336150
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import tkinter
    import threading
    import traceback
    import os
    import unittest
    import jedi
    import types

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.root = tkinter.Tk()

        def tearDown(self):
            self.root.destroy()
            del self.root

        def test_jedi_is_importable_and_correct_version(self):
            self.assertTrue(hasattr(jedi, "__version__"))
            self.assertTrue(
                hasattr(jedi, "Script") and isinstance(jedi.Script, types.FunctionType)
            )


# Generated at 2022-06-22 03:05:55.462104
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    Tests to see if get_interpreter_completions() returns the same results as
    get_script_completions() in the current jedi version
    """
    import jedi
    import os
    import io

    # There is a bug in older versions of jedi that causes the following test to fail
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        return

    from thonny.misc_utils import running_on_linux

    # The following test file contains all different types of completions
    test_file = "test_jedi_utils.py"
    test_file_with_path = os.path.join(os.path.dirname(__file__), test_file)

    # The

# Generated at 2022-06-22 03:06:04.239050
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    node = parse_source("# test\nprint('hello')")
    assert isinstance(node, tree.Module)
    assert node.get_code() == "# test\nprint('hello')"
    assert len(node.children) == 2
    assert node.children[0].get_code() == "# test\n"
    assert node.children[1].get_code() == "print('hello')"
    assert node.type == "file_input"
    assert node.children[0].type == "comment"
    assert node.children[1].type == "simple_stmt"

# Generated at 2022-06-22 03:06:11.976565
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "comple"
    type = "typ"
    description = "descr"
    parent = "parent"
    full_name = "full_name"

    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc.name == name
    assert tc.complete == complete
    assert tc.type == type
    assert tc.description == description
    assert tc.parent == parent
    assert tc.full_name == full_name

# Generated at 2022-06-22 03:06:21.753206
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import tkinter
root = tkinter.Tk()
root.mainloop()"""
    row = 1
    column = 4
    filename = "test.py"
    assert len(get_script_completions(source, row, column, filename)) == 1
    assert get_script_completions(source, row, column, filename)[0].name == "tkinter"
    row = 2
    column = 0
    assert len(get_script_completions(source, row, column, filename)) == 2
    assert get_script_completions(source, row, column, filename)[0].name == "root"
    assert get_script_completions(source, row, column, filename)[1].name == "tkinter"
    row = 2
    column = 4

# Generated at 2022-06-22 03:06:28.156943
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    result = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert result.name == "name"
    assert result.complete == "complete"
    assert result.type == "type"
    assert result.description == "description"
    assert result.parent == "parent"
    assert result.full_name == "full_name"

# Generated at 2022-06-22 03:06:34.278067
# Unit test for function parse_source

# Generated at 2022-06-22 03:07:11.159786
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        script = jedi.Script("1+2", 1, 3)
        assert script.goto_definitions()[0].line == 1
    else:
        script = jedi.Script("1+2", 1, 3)
        assert script.infer(line = 1, column = 3)[0].line == 1

# Generated at 2022-06-22 03:07:22.560664
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_data = [
        ("", "", "", "", "", ""),
        ("a", "a", "", "", "", "a"),
        ("b", "b=", "", "", "", "b"),
        ("c", "c", "", "", "", "c"),
        ("d", "d=", "", "", "", "d"),
    ]

    for d in test_data:
        comp = ThonnyCompletion(d[0], d[1], d[2], d[3], d[4], d[5])
        assert comp.name == d[0]
        assert comp.complete == d[1]
        assert comp.type == d[2]
        assert comp.description == d[3]
        assert comp.parent == d[4]
        assert comp.full_name

# Generated at 2022-06-22 03:07:31.412840
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

    p = jedi.Script("""
        class A:
            def __init__(self):
                self.a = 3
                self.b = 5
                self.b = 6
            def foo(self):
                self.a = 3
                self.b = 5
                self.b = 6
        """, 1, 1)._parser
    assignment = get_statement_of_position(p.module, (6, 12))
    assert isinstance(assignment, parso.python.tree.ExprStmt)
    assert assignment.start_pos == (6, 11)
    assert assignment.end_pos == (6, 13)

# Generated at 2022-06-22 03:07:34.378178
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import test
    import parso


# Generated at 2022-06-22 03:07:42.871907
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class TestHelper(unittest.TestCase):
        def setUp(self):
            self.source = "def func(x, y):\n    return x + y\nfunc"
            self.namespaces = [{"x": 1, "y": 2}]

        def test_get_interpreter_completions_without_sys_path(self):
            completions = get_interpreter_completions(self.source, self.namespaces)
            self.assertEqual(len(completions), 1)
            completion = completions[0]
            self.assertEqual(completion.name, "func")
            self.assertEqual(completion.complete, "func(")
            self.assertEqual(completion.type, "function")
            self

# Generated at 2022-06-22 03:07:52.399084
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import Interpreter

    print("Testing jedi.get_script_completions")

    # test completion in code
    completions = get_script_completions("print('test', r'\\n')", 3, 11, '/home/user/t.py')
    assert any([c.name == '\\n' for c in completions])

    # test completion in string
    completions = get_script_completions("print('test', r'\\n')", 3, 17, '/home/user/t.py')
    assert any([c.name == '\\n' for c in completions])

    # test completion in string, but not in code

# Generated at 2022-06-22 03:08:02.480033
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test module completion using 0.13
    import jedi
    import sys

    if sys.version_info >= (3, 6):
        assert len(get_script_completions("import z", 0, 7, "string.py")) > 1
    else:
        assert not get_script_completions("import z", 0, 7, "string.py")

    # Test function completion using 0.16
    if jedi.__version__[:4] != "0.13":
        assert len(get_script_completions("x = ' '.join", 0, 15, "string.py")) > 1
    else:
        assert get_script_completions("x = ' '.join", 0, 15, "string.py") == []

# Generated at 2022-06-22 03:08:13.056697
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    ThonnyCompletion('name','complete','type','description','parent','full_name')['name']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['complete']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['type']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['description']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['parent']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['full_name']
    ThonnyCompletion('name','complete','type','description','parent','full_name')['other']



# Generated at 2022-06-22 03:08:17.341590
# Unit test for function parse_source
def test_parse_source():
    import jedi.parser_utils
    import parso
    parso = parso.parse('print(1)')
    test = parse_source('print(1)')
    if parso.get_code() == test.get_code():
        return True
    return False



# Generated at 2022-06-22 03:08:23.164801
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("spam", "spam(", "function", "test description", "test", "full_name")
    assert completion.name == "spam"
    assert completion.complete == "spam("
    assert completion.type == "function"
    assert completion.description == "test description"
    assert completion.parent == "test"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:09:51.311170
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    import jedi

    class Test(TestCase):
        def test_get_script_completions(self):
            completions = get_script_completions(
                "print()", 0, 6, "tst_get_script_completions.py"
            )
            print(completions)
            self.assertGreater(len(completions), 0)

            # self.assertEqual(completions[0].name, "end")
            # self.assertEqual(completions[0].type, "keyword")
            # self.assertEqual(completions[0].description, "end")


# Generated at 2022-06-22 03:09:53.151877
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi


# Generated at 2022-06-22 03:09:58.253971
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Interpreter
    from jedi.parser_utils import get_crawler


# Generated at 2022-06-22 03:10:08.594290
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    import unittest.mock
    from unittest import mock
    import jedi
    if _using_older_jedi(jedi):
        jedi.Script.completions = mock.Mock(return_value=42)
        assert get_script_completions(
            source="", row="row", column="col", filename="foo.py"
        ) == 42
        jedi.Script.completions.assert_called_once_with()
        jedi.Script = mock.MagicMock()
        jedi.Script.completions.return_value = [Completion()]

# Generated at 2022-06-22 03:10:18.843899
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import parso
    from parso.python import tree

    def dummy_get_statement_of_position(node, pos):
        raise AttributeError()

    parser_utils = parso.parser_utils
    parso.parser_utils.get_statement_of_position = dummy_get_statement_of_position

    class TestCase(unittest.TestCase):
        def _test(self, source: str, pos: int, expected_class):
            result = get_statement_of_position(parse_source(source), pos)
            self.assertTrue(isinstance(result, expected_class))

        def test_flow(self):
            self._test(
                "(a if b else c, 1) if d else e",
                13,
                tree.IfStmt,
            )


# Generated at 2022-06-22 03:10:30.579849
# Unit test for function get_script_completions
def test_get_script_completions():
    def do():
        import os
        import json
        import unittest.mock as mock

        test_dir = os.path.dirname(os.path.abspath(__file__))

        with open(os.path.join(test_dir, "jedi_completion_tests.json"), "r", encoding="utf-8") as fp:
            test_cases = json.load(fp)

        for i, test_case in enumerate(test_cases):
            filename = "dummy_file.py"
            script = test_case["code"]
            pos = test_case["pos"]
            row = pos[0]
            column = pos[1]
            completions = get_script_completions(script, row, column, filename)


# Generated at 2022-06-22 03:10:36.453088
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi

    # If the function gets the scope, then there is no problem
    def create_pos_scope(line, column):
        return parso.parse("def foo(a):\n    a.").get_position_scope(line, column)

    assert create_pos_scope(2, 3).name == "a"

    def _test(func_name, line, column):
        return get_statement_of_position(create_pos_scope(line, column), jedi.Script("")._pos(line, column))

    # If the function is outside of scope, then it should return the function
    assert _test("foo", 0, 0).name == "foo"

    # If the function is inside of scope, then it should return the scope

# Generated at 2022-06-22 03:10:47.498080
# Unit test for function parse_source
def test_parse_source():
    import jedi
    import parso
    import jedi.parser_utils

    source_lines = ["def foo(x,y):", "  pass", "", "foo(1,3)"]
    source = "\n".join(source_lines)

    # check if parso and jedi parsers are compatible
    try:
        parso_tree = parso.parse(source)
        jedi_tree = jedi.Script(source, 0, 0)._get_module()
        assert parso_tree.__class__ is jedi_tree.__class__
        assert parso_tree.get_code() == jedi_tree.get_code()
    except NotImplementedError:
        pass

    # check if the pygram.parse_string method works the same as parso
    from parso._compatibility import is_