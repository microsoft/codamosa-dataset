

# Generated at 2022-06-22 03:01:01.218315
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():

    t_completion = ThonnyCompletion('name','complete','type','description','parent','full_name')
    assert t_completion['name'] == 'name'
    assert t_completion['complete'] == 'complete'
    assert t_completion['type'] == 'type'
    assert t_completion['description'] == 'description'
    assert t_completion['parent'] == 'parent'
    assert t_completion['full_name'] == 'full_name'

# Generated at 2022-06-22 03:01:08.948186
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    complete = "Thonny"
    type = "class"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    tc = ThonnyCompletion(complete, complete, type, description, parent, full_name)

    assert tc["name"] == complete
    assert tc["type"] == type
    assert tc["description"] == description
    assert tc["parent"] == parent
    assert tc["full_name"] == full_name

# Generated at 2022-06-22 03:01:19.618528
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import pytest
    from jedi.api.helpers import get_statement_of_position
    from parso.python.tree import ExprStmt, DictComprehension

    def assert_get_statement_of_position(
        source: str, pos: int, expected_type: type, expected_start: int, expected_end: int
    ):
        """
        Calls get_statement_of_position with source and pos and compares the result with expected_* arguments
        """
        # check both single and multi-line strings
        source = source.replace("\n", " ").replace("\\n", "\n")
        module = parse_source(source)
        node = get_statement_of_position(module, pos)
        assert isinstance(node, expected_type)
        assert node.get_start_pos_of_prefix

# Generated at 2022-06-22 03:01:29.340349
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = [
        "if True:",
        "    pass",
        "else:",
        "    for i in range(10):",
        "        pass",
        "    having= True",
        "    if having:",
        "        pass",
        "    else:",
        "        pass",
        "    not_in_tree=1",
        "pass",
    ]

    assert get_statement_of_position(parse_source("\n".join(source)), pos=(2,0))    == parse_source("if True:")
    assert get_statement_of_position(parse_source("\n".join(source)), pos=(2,7))    == parse_source("if True:")

# Generated at 2022-06-22 03:01:37.306258
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"

# Generated at 2022-06-22 03:01:45.400491
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    print(jedi.__version__)

# Generated at 2022-06-22 03:01:49.530607
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:01:56.837174
# Unit test for function get_definitions
def test_get_definitions():
    from test.cpython_mock import CPythonMock
    from test.jedi_utils import parse_source, get_definitions

    source = "foo = 42\nfoo"
    tree = parse_source(source)
    row, column = 2, 4
    definition = get_definitions(source, row, column, CPythonMock.filename)[0]
    name_node = get_statement_of_position(tree, (row, column)).get_rhs()
    assert definition.module_path == CPythonMock.filename
    assert definition.description == "int"
    assert definition.line == 1
    assert definition.column == 4
    assert definition.in_builtin_module is False
    assert definition.type == "statement"

    source = "# Comment about import\nimport os\nos"
    tree = parse_source

# Generated at 2022-06-22 03:02:04.700946
# Unit test for function get_definitions
def test_get_definitions():
    source = """
from tkinter import *
import math

root = Tk()
m = Menu(root)
root.config(menu=m)

a = math.sqrt(4)

help_menu = Menu(m)
"""


# Generated at 2022-06-22 03:02:05.676744
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

# Generated at 2022-06-22 03:02:35.169439
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    a = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert a.name == "name"
    assert a.complete == "complete"
    assert a.type == "type"
    assert a.description == "description"
    assert a.parent == "parent"
    assert a.full_name == "full_name"

# Generated at 2022-06-22 03:02:42.190807
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.jedi_utils_test import assert_completions_equal

    completions = get_script_completions(
        source="Foo", row=1, column=3, filename="some_path/somefile.py"
    )
    assert_completions_equal(
        completions,
        [
            ThonnyCompletion(
                name="Foo",
                complete="Foo",
                type="class",
                description="class Foo",
                parent="object",
                full_name="Foo",
            )
        ],
    )

    completions = get_script_completions(
        source="Foo().", row=1, column=5, filename="some_path/somefile.py"
    )

# Generated at 2022-06-22 03:02:48.848826
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        # 'as' is not yet available
        if "as" in get_script_completions("a=1+2\na", 2, 2, ""):
            return False
    else:
        # 'as' is already there
        if "as" not in get_script_completions("a=1+2\na", 2, 2, ""):
            return False

    return True

# Generated at 2022-06-22 03:02:51.786380
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree
    from parso.python.tree import ClassOrFunc
    from parso.python.tree import Flow
    from parso.python import parse


# Generated at 2022-06-22 03:03:03.200316
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class GetInterpreterCompletionsTests(unittest.TestCase):
        def test_none(self):
            result = get_interpreter_completions("", [])

            self.assertEqual([], result)

        def test_empty_namespace(self):
            result = get_interpreter_completions("import sys", [{}])

            self.assertNotEqual([], result)

        def test_empty_code(self):
            result = get_interpreter_completions("", [{"x": 10}])

            self.assertEqual(["x"], [c["name"] for c in result])

        def test_some_code(self):
            result = get_interpreter_completions("x", [{"x": 10}])


# Generated at 2022-06-22 03:03:15.336175
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import random
    import string

    thonnyCompletion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    for i in range(100):
        name = "".join(random.choice(string.ascii_letters) for x in range(random.randint(1, 10)))
        complete = "".join(
            random.choice(string.ascii_letters) for x in range(random.randint(1, 10))
        )
        type = "".join(random.choice(string.ascii_letters) for x in range(random.randint(1, 10)))

# Generated at 2022-06-22 03:03:20.985110
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import math"
    namespaces = [jedi.create_namespace()]
    completions = get_interpreter_completions(source, namespaces)
    names = [c["name"] for c in completions]
    assert "math" in names
    assert "print" not in names


# Generated at 2022-06-22 03:03:26.589657
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import sys
    import unittest

    from _test_helper import captured_output

    abs_test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, abs_test_dir)
    sys.path.insert(0, os.path.join(abs_test_dir, "json_data"))

    import jedi
    import json_data
    import builtins


# Generated at 2022-06-22 03:03:34.069469
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"x": "i_am_an_int_not_a_string"}]
    completions = get_interpreter_completions("x", namespaces, sys_path=None)
    assert len(completions) == 1
    assert completions[0].name == "x"
    assert completions[0].complete == "x"
    assert completions[0].type == "int"
    assert completions[0].description == "i_am_an_int_not_a_string"

# Generated at 2022-06-22 03:03:35.973192
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")


# Generated at 2022-06-22 03:04:07.615311
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    from thonny.jedi_utils import _using_older_jedi
    from thonny.jedi_utils import ThonnyCompletion
    from thonny.jedi_utils import get_definitions
    from thonny.jedi_utils import test_get_definitions

    class TestJediUtils(unittest.TestCase):
        def test_version(self):
            self.assertFalse(_using_older_jedi(jedi))

        def test_class_name(self):
            self.assertEqual(ThonnyCompletion("name", "complete", "type", None, None, None).name, "name")


# Generated at 2022-06-22 03:04:16.332180
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc.name == name
    assert tc.complete == complete
    assert tc.type == type
    assert tc.description == description
    assert tc.parent == parent
    assert tc.full_name == full_name

# Generated at 2022-06-22 03:04:27.737017
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    
    comp = ThonnyCompletion("name","complete","type","description","parent","full_name")
    jedi_comp = jedi.Completion("name","complete","type","description","parent","full_name")
    assert comp.__dict__["name"] == jedi_comp.name
    assert comp.__dict__["complete"] == jedi_comp.complete
    assert comp.__dict__["type"] == jedi_comp.type
    assert comp.__dict__["description"] == jedi_comp.description
    assert comp.__dict__["parent"] == jedi_comp.parent
    assert comp.__dict__["full_name"] == jedi_comp.full_name
    assert comp.name == jedi_comp.name
    assert comp.complete == jedi_comp.complete
    assert comp

# Generated at 2022-06-22 03:04:38.403755
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion(name="test", complete="test", type="test", description="test", parent="test", full_name="test")
    assert tc.name == "test"
    assert tc.complete == "test"
    assert tc.type == "test"
    assert tc.description == "test"
    assert tc.parent == "test"
    assert tc.full_name == "test"
    assert tc["name"] == "test"
    assert tc["complete"] == "test"
    assert tc["type"] == "test"
    assert tc["description"] == "test"
    assert tc["parent"] == "test"
    assert tc["full_name"] == "test"

# Generated at 2022-06-22 03:04:39.334226
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletio

# Generated at 2022-06-22 03:04:40.915932
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("print('hello')").type == "file_input"


# Generated at 2022-06-22 03:04:52.192316
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    source = """if __name__ == '__main__':
    import sys
    import tkinter as tk
    root = tk.Tk()
    root.title("Hello World!")
    root.geometry("400x300+100+100")

    def start():
        pass

    def stop():
        pass

    start_button = tk.Button(
        root, text="Start", command=start, width=6, height=1)
    start_button.grid(row=0, column=0, sticky="e")
    stop_button = tk.Button(
        root, text="Stop", command=stop, width=6, height=1)
    stop_button.grid(row=0, column=1, sticky="e")
    root.mainloop()
    """


# Generated at 2022-06-22 03:04:57.069335
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    tree = parso.parse("foo()")
    root = tree.children[0]
    call = root.children[0]
    assert get_statement_of_position(root, 3) is call
    assert get_statement_of_position(root, 10) is root



# Generated at 2022-06-22 03:04:59.135603
# Unit test for function parse_source
def test_parse_source():
    code = "import sys;"
    tree = parse_source(code)

    assert(tree.type == "file_input")

# Generated at 2022-06-22 03:05:05.965063
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = (
        "def foo(x):\n"
        "    if x>0:\n"
        "        return x**2\n"
        "    else:\n"
        "        return x"
    )
    tree1 = parse_source(source)
    tree2 = parso.parse(source)
    assert tree1.get_root_node() == tree2.get_root_node()

# Generated at 2022-06-22 03:05:30.719546
# Unit test for function parse_source
def test_parse_source():
    source = "def foo(x, y=1): # comment\n     pass\n"
    parse_source(source)



# Generated at 2022-06-22 03:05:41.951311
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def get_names(completions):
        return [c.name for c in completions]

    assert get_names(get_script_completions("", 0, 0, "")) == []
    assert get_names(get_script_completions("imp", 0, 3, "")) == ["import"]
    assert get_names(get_script_completions("import ", 0, 7, "")) == get_names(
        jedi.Script("import ", 1, 8).completions()
    )
    assert get_names(
        get_script_completions("import ne", 0, 9, "", sys_path=["/"])
    ) == []

# Generated at 2022-06-22 03:05:52.335157
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import jedi

    # Create fake module
    sys.modules["mymodule"] = "mymodule"

    # Test if module is found
    script = jedi.Script("import mymodule", 1, 6)
    results = script.goto_definitions()
    assert len(results) == 1
    assert results[0].description == "mymodule"

    # Get function defs
    script = jedi.Script("def my_func(): pass", 1, 7)
    results = script.goto_definitions()
    assert len(results) == 1
    assert results[0].description == "my_func"

    script = jedi.Script("def my_func(): pass\nmy_func", 2, 7)
    results = script.goto_definitions()
    assert len(results) == 1
    assert results

# Generated at 2022-06-22 03:06:01.007005
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate.compiled import CompiledObject

    buf = "\nsin(0)\n"
    pos = 4
    definitions = get_definitions(buf, 1, pos, "test.py")
    # jedi.Script.goto_definitions and jedi.Script.infer return different objects.
    # So this test is designed to work with both cases.
    assert len(definitions) == 1
    assert isinstance(definitions[0], (CompiledObject, ThonnyDefinition))
    assert definitions[0].full_name == "math.sin"



# Generated at 2022-06-22 03:06:06.634812
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "description"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-22 03:06:12.660741
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Test for function get_script_completions
    """
    completions = get_script_completions('a = [1,3,5]\na[|', 2, 6, 'script.py')
    assert completions[0]["name"] == '__getitem__'
    assert completions[0]["complete"] == '__getitem__'

# Generated at 2022-06-22 03:06:13.273407
# Unit test for function get_definitions

# Generated at 2022-06-22 03:06:22.551395
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    import jedi
    _using_older_jedi(jedi)
    old_jedi_version = _using_older_jedi(jedi)
    simple_code = "import math; math."
    m = Interpreter(simple_code, [locals()])
    completions = get_interpreter_completions(simple_code, [locals()])

    # check completions
    if not old_jedi_version:
        math_completions = m.complete()
    else:
        math_completions = m.completions()

    # equality check
    for i in range(len(completions)):
        assert completions[i].name == math_completions[i].name
        assert completions[i].complete == math_completions

# Generated at 2022-06-22 03:06:32.439998
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.evaluate import compiled

    import traceback
    import sys

    namespace = [{"__builtins__": __builtins__, "__name__": "__main__", "__doc__": None, "__file__": None}]

    def is_equal_namespace(namespace1, namespace2):
        if len(namespace1) != len(namespace2):
            return False

        for n1, n2 in zip(namespace1, namespace2):
            for k, v in n1.items():
                if k not in n2 or (v != n2[k] and k != "__builtins__"):
                    return False
        return True


# Generated at 2022-06-22 03:06:43.234983
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module, Name, Function, Operator, Array, SimpleStatement
    from parso.python.tree import Class
    from parso.python.parser import Parser

    for code, line, column, wanted in [
        ("def f():\n    pass\n", 2, 10, Module),
        ("def f():\n    pass\n", 1, 10, Function),
        ("yield\n", 1, 6, SimpleStatement),
        ("class A:\n    pass\n", 2, 9, Class),
        ("yield (1, 2)", 1, 9, Array),
        ("yield 1 + 2", 1, 6, Name),
        ("yield 1 + 2", 1, 8, Operator),
    ]:
        parser = Parser(code)
        module = parser.module()
        assert get_

# Generated at 2022-06-22 03:07:40.685562
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import unittest
    # name = "a"
    # complete = "a"
    # type = "str"
    # description = ""
    # parent = ""
    # full_name = "a"
    name, complete, type, description, parent, full_name = ("a", "a", "str", "", "", "a")
    ob = ThonnyCompletion(
        name, complete, type, description, parent, full_name
    )
    unittest.TestCase().assertEqual(
        (
            ob.name,
            ob.complete,
            ob.type,
            ob.description,
            ob.parent,
            ob.full_name,
        ),
        (name, complete, type, description, parent, full_name),
    )
    unittest.TestCase().assertE

# Generated at 2022-06-22 03:07:51.612861
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import __version__


# Generated at 2022-06-22 03:07:52.735082
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script


# Generated at 2022-06-22 03:08:00.323806
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert thonny_completion["name"] == "name"
    try:
        # 'test' does not exist
        thonny_completion["test"]
    except KeyError:
        assert True
        return
    assert False

# Generated at 2022-06-22 03:08:06.864887
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_string = "thonnyCompletionTest"
    expected1 = "thonnyCompletionTest"
    expected2 = "Completion(thonnyCompletionTest)"
    expected3 = "Completion(thonnyCompletionTest)"
    expected4 = "thonnyCompletionTest"
    expected5 = "thonnyCompletionTest"
    expected6 = "thonnyCompletionTest"

    test_object = ThonnyCompletion("thonnyCompletionTest", "Completion(thonnyCompletionTest)", "Completion(thonnyCompletionTest)", "thonnyCompletionTest", "thonnyCompletionTest", "thonnyCompletionTest")
    assert expected1 == test_object.name
    assert expected2 == test_object.complete
    assert expected3 == test_object.type
    assert expected

# Generated at 2022-06-22 03:08:10.931705
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    node = parso.parse("a\na.b\na\\\n  .b")
    if_node = node.children[2]
    assert get_statement_of_position(if_node, (3, 4)) == if_node.children[1]

# Generated at 2022-06-22 03:08:22.315186
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):


        def test_get_interpreter_completions(self):
            from jedi import Interpreter, Script

            ns = [
                {
                    "__name__": "builtins",
                    "__builtins__": Interpreter.builtins_module,
                    "__doc__": None,
                    "__file__": None,
                }
            ]
            comps = get_interpreter_completions("import sys\nsys", ns)
            self.assertTrue(len(comps) > 0)

        def test_get_interpreter_completions_after_import(self):
            from jedi import Interpreter, Script


# Generated at 2022-06-22 03:08:29.889833
# Unit test for function get_definitions
def test_get_definitions():
    try:
        import jedi
        import textwrap
        import sys
        import os
        from parso.python import tree
    except Exception as e:
        logging.debug(e)
        logging.debug("get_definitions unit test is ignored.")
        return

    thonny_path = os.path.dirname(os.path.dirname(__file__))
    sys.path.insert(0, thonny_path)

    # Precondition:
    #   - current path is the same as jedi.__file__

# Generated at 2022-06-22 03:08:38.789371
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    assert get_statement_of_position(tree.Module(None, []), (1, 0)) is None
    module = tree.Module(None, [tree.ExprStmt(None, tree.Name(None, "a"))])
    assert get_statement_of_position(module, (1, 0)) is module.children[0]
    assert get_statement_of_position(module, (1, 1)) is module.children[0]
    assert get_statement_of_position(module, (1, 3)) is module.children[0]
    assert get_statement_of_position(module, (2, 3)) is None

    # Test with multiple children

# Generated at 2022-06-22 03:08:43.036056
# Unit test for function parse_source
def test_parse_source():
    jedi = __import__("jedi")

    if hasattr(jedi.parser_utils, "parse_source"):
        assert parse_source("1 + 2") is not None
    else:
        assert parse_source("1 + 2").get_code() == "1 + 2"

# Generated at 2022-06-22 03:09:43.744615
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from types import ModuleType
    import sys
    
    module = ModuleType('test_module', 'fake doc string')
    module.attr1 = "String attribute"
    module.attr2 = 1

    completions = []
    for name in dir(module):
        c = ThonnyCompletion(
            name=name, 
            complete=name, 
            type='module', 
            description='fake description',
            parent=sys.modules, 
            full_name='test_module.' + name
        )
        completions.append(c)

    assert len(completions) == 3
    assert completions[0].name == '__builtins__'
    assert completions[0].complete == '__builtins__'
    assert completions[0].type == 'module'

# Generated at 2022-06-22 03:09:44.269012
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:09:54.167416
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # Use jedi 0.16.0 and newer since they return ThonnyCompletion instances.
    source = "import os; os.path.abspath("
    namespaces = [{}]
    assert _using_older_jedi(jedi) == False
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path="
    assert completions[0].full_name == "path"
    assert completions[0].parent == "os.path"
    assert completions[0].type == "param"
    assert completions[0].description.startswith("The path/file to be examined.")
   

# Generated at 2022-06-22 03:10:01.773761
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_obj = ThonnyCompletion("name", "complete", "type", "desc", None, "full_name")
    assert test_obj.name == "name"
    assert test_obj.complete == "complete"
    assert test_obj.type == "type"
    assert test_obj.description == "desc"
    assert test_obj.parent is None
    assert test_obj.full_name == "full_name"

# Generated at 2022-06-22 03:10:07.219441
# Unit test for function get_definitions
def test_get_definitions():
    # thonny/ui/__init__.py line: 12
    source = """from thonny.ui import get_workbench
get_workbench()
"""
    locations = get_definitions(source, row = 2, column = 6)
    assert len(locations) == 1

    location = locations[0]
    assert location.module_path.endswith("thonny/ui/__init__.py")
    assert location.line == 11
    assert location.column == 21

# Generated at 2022-06-22 03:10:18.195166
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    script = jedi.Script("import os\nos.sep")
    completions = script.completions()
    assert completions[0].name == "sep"
    assert completions[0].complete == "sep"

    completion = ThonnyCompletion(
        name=completions[0].name,
        complete=completions[0].complete,
        type=completions[0].type,
        description=completions[0].description,
        parent=completions[0].parent,
        full_name=completions[0].full_name,
    )
    assert completion.name == "sep"
    assert completion.complete == "sep"
    assert completion.full_name == "os.sep"


# Generated at 2022-06-22 03:10:24.743508
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    completions = get_interpreter_completions("foo.bar", namespaces=[])
    assert completions == jedi.Interpreter("foo.bar", namespaces=[]).complete()
    assert len(completions) == 1

    completions = get_interpreter_completions("foo.bar.", namespaces=[])
    assert len(completions) >= 5
    for completion in completions:
        assert completion.name != "bar"

# Generated at 2022-06-22 03:10:31.829158
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    obj = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    obj.__getitem__("name") == "a"
    obj.__getitem__("complete") == "b"
    obj.__getitem__("type") == "c"
    obj.__getitem__("description") == "d"
    obj.__getitem__("parent") == "e"
    obj.__getitem__("full_name") == "f"

# Generated at 2022-06-22 03:10:39.379238
# Unit test for function get_script_completions
def test_get_script_completions():
    source = '''def foo(x):
    x.fro'''
    completions = get_script_completions(source=source, row=1, column=9, filename="")
    assert(len(completions) == 1)
    assert(completions[0].name == "from")
    assert(completions[0].complete == "from")
    assert(completions[0].type == "keyword")
    assert(completions[0].description == "Import some objects from a module")
    assert(completions[0].parent == None)
    assert(completions[0].full_name == "from")