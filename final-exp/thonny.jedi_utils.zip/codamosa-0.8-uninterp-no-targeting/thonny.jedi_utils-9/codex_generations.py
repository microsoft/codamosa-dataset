

# Generated at 2022-06-22 03:00:42.878026
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:00:51.613995
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position as jedi_gsp

    def gsp(text, pos):
        node = parse_source(text)
        return str(get_statement_of_position(node, pos))

    def jgsp(text, pos):
        node = parse_source(text)
        return str(jedi_gsp(node, pos))

    assert gsp("\nx", 0) == gsp("\nx", 1) == gsp("\nx", 2) == "expr_stmt"
    assert gsp("x", 0) == gsp("x", 1) == gsp("x", 2) is None

# Generated at 2022-06-22 03:00:54.090609
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-22 03:01:00.207398
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module

    mod = parse_source(
        """
    a = 1
    b = 2
    """
    )
    assert get_definitions(mod, "a") == [mod.children[1].children[1]]
    assert get_definitions(mod, "b") == [mod.children[2].children[1]]
    assert get_definitions(mod, "nonsense") == []



# Generated at 2022-06-22 03:01:01.173256
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-22 03:01:12.309968
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    source = """assert.that('python')"""
    module = parse_source(source)
    assert module.type == "module"
    assert len(module.children) == 1
    assert module.children[0].type == "simple_stmt"
    assert len(module.children[0].children) == 3
    assert module.children[0].children[0].type == "assert_stmt"
    assert len(module.children[0].children[0].children) == 2
    assert module.children[0].children[0].children[0].type == "power"
    assert module.children[0].children[0].children[1].type == "trailer"
    assert len(module.children[0].children[0].children[1].children) == 1

# Generated at 2022-06-22 03:01:15.681755
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree
    source = "import math"
    assert isinstance(parse_source(source), parso.python.tree.Module)

# Generated at 2022-06-22 03:01:26.089159
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import sys
    from parso.python import tree

    sys.path.append("somedir")
    code = """
    dfsdgfsgdf
    def myfunc(x, y, z=1, *args, **kwargs):
        print("Some statement")
        x = 5
        y = 6
    """
    tree = parse_source(code)
    assert isinstance(tree, tree.Module)
    print(tree.children)
    assert len(tree.children) == 2

    assert get_statement_of_position(tree, (1, 1)) == tree
    assert get_statement_of_position(tree, (2, 1)) == tree.children[0]
    assert get_statement_of_position(tree.children[0], (2, 1)) == tree.children[0]
    assert get_

# Generated at 2022-06-22 03:01:34.659481
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    import parso
    source = """
    def foo(x,y,baz=1,*args,**kwargs):
        print(x,y)
        print(baz)
        print(*args)
        print(**kwargs)
    """
    module = parso.parse(source)
    assert (
        isinstance(
            get_statement_of_position(module, module.get_position_info(module.start_pos)),
            tree.Node,
        )
        == False
    )
    assert isinstance(module.children[1], tree.ExprStmt)
    assert isinstance(
        get_statement_of_position(module, module.get_position_info(module.end_pos)), tree.Node
    )

# Generated at 2022-06-22 03:01:42.363878
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import jedi
    except ImportError:
        print("cannot run get_script_completions test -- jedi not installed")
        return
    if _using_older_jedi(jedi):
        print("cannot run get_script_completions test -- jedi older than 0.18 installed")
        return

    source = "def __repr__():\n    pass\n\nthis_var\n"
    script = get_script_completions(source, 1, 1, "test.py")
    if len(script) == 0:
        print("get_script_completions test failed:")
        print("  expected 1 completion, got 0")
        return
    if script[0].complete != 'this_var':
        print("get_script_completions test failed:")
       

# Generated at 2022-06-22 03:01:57.634043
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name11", "complete22", "type33", "description44", "parent55", "full_name66")
    assert completion.__getitem__("name") == "name11"
    assert completion.__getitem__("complete") == "complete22"
    assert completion.__getitem__("type") == "type33"
    assert completion.__getitem__("description") == "description44"
    assert completion.__getitem__("parent") == "parent55"
    assert completion.__getitem__("full_name") == "full_name66"

# Generated at 2022-06-22 03:02:09.423113
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return
    else:
        # With the release of jedi 0.17 this test has been updated to test the new
        # behavior of jedi completions
        defs = get_interpreter_completions("import os\nos.", [], sys_path=["."])
        assert len(defs) == 1
        assert defs[0].name == "sep"
        assert defs[0].complete == "sep"
        assert defs[0].type == "str"
        assert defs[0].description == "sep"
        assert defs[0].parent == "<module 'os' (built-in)>"
        assert defs[0].full_name == "os.sep"

# Generated at 2022-06-22 03:02:14.498665
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert test['name'] == test.name
    assert test['complete'] == test.complete
    assert test['type'] == test.type
    assert test['description'] == test.description
    assert test['parent'] == test.parent
    assert test['full_name'] == test.full_name

# Generated at 2022-06-22 03:02:20.023566
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    from parso.python import tree
    
    def iter_self_and_parent_nodes(node):
        """yield the given node and each of its parents"""
        while True:
            yield node
            if node.parent is not None:
                node = node.parent
            else:
                break
    

# Generated at 2022-06-22 03:02:25.341706
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    t = ThonnyCompletion(
        name="name",
        complete="complete",
        type=jedi.api.keywords.Keyword,
        description="description",
        parent=None,
        full_name="full_name",
    )

    assert t.name == "name"
    assert t.complete == "complete"
    assert t.type == jedi.api.keywords.Keyword
    assert t.description == "description"
    assert t.parent is None
    assert t.full_name == "full_name"


if __name__ == "__main__":
    test_ThonnyCompletion()

# Generated at 2022-06-22 03:02:30.908573
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert tc.name == 'name'
    assert tc.complete == 'complete'
    assert tc.type == 'type'
    assert tc.description == 'description'
    assert tc.parent == 'parent'
    assert tc.full_name == 'full_name'

# Generated at 2022-06-22 03:02:34.946213
# Unit test for function parse_source
def test_parse_source():
    import parso
    
    s = "var = 1"
    
    try:
        parso.parse(s)
    except NameError as e:
        if "parso.parse" in str(e):
            assert True
        else:
            assert False
    else:
        assert False


# Generated at 2022-06-22 03:02:38.471178
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("a", None, None, None, None, None)
    assert tc.name == "a"
    assert tc.complete is None
    assert tc.type is None
    assert tc.description is None
    assert tc.parent is None
    assert tc.full_name is None

# Generated at 2022-06-22 03:02:50.228989
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_parent_scope
    from jedi import Interpreter
    
    def test_completions(before_text, before_cursor, after_text, after_cursor, rows, namespaces, sys_path=None):
        interpreter = get_interpreter_completions(before_text, namespaces, sys_path=sys_path)
        assert len(interpreter) == rows
        for completion in interpreter:
            assert completion.name in after_text
            assert completion.complete in after_text
            assert completion.type == 'statement'
            assert completion.description.startswith('module ')
            assert hasattr(completion.parent, 'type')
            assert completion.full_name == completion.name


# Generated at 2022-06-22 03:02:57.988054
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"


# Generated at 2022-06-22 03:03:18.760755
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import unittest.mock
    import jedi
    import test
    # simulating some filename
    filename = "import pygame.mouse; pygame.mouse."
    # Create an object of jedi.Script with some mock parameters
    # and get completions
    script = jedi.Script(
        source="",
        line=0,
        column=len(filename),
        path=os.path.join(test.test_dir, "test.py"),
    )

    # We need to patch one of jedi._compile functions to add
    # a custom sys.path for our python module.
    def load_module(module, path):
        with unittest.mock.patch("sys.path", [path]):
            return super().load_module(module)


# Generated at 2022-06-22 03:03:29.729106
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api import Script
    jedi_completion = Script('from datetime import date').completions()[0]
    completion = ThonnyCompletion(name=jedi_completion.name,
                                  complete=jedi_completion.complete,
                                  type=jedi_completion.type,
                                  description=jedi_completion.description,
                                  parent=jedi_completion.parent,
                                  full_name=jedi_completion.full_name)
    assert completion.name == jedi_completion.name
    assert completion.complete == jedi_completion.complete
    assert completion.type == jedi_completion.type
    assert completion.description == jedi_completion.description
    assert completion.parent == jedi_completion.parent

# Generated at 2022-06-22 03:03:41.485135
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_jedi_utils import parse_source_on_position
    from test.test_completion import run_asserts

    def assert_completions(source, expected, namespaces, sys_path=None):
        completions = get_interpreter_completions(source, namespaces, sys_path=sys_path)
        run_asserts(completions, expected)


    assert_completions(
        "import os; cmd=os.exi",
        ["exit(", "execv(", "execve(", "execl(", "execlp(", "execvp(", "execvpe("],
        [{"os": parse_source_on_position("import os; os", "os")}],
    )

# Generated at 2022-06-22 03:03:53.311420
# Unit test for function parse_source
def test_parse_source():
    import parso
    from jedi.parser_utils import get_statement_of_position

    source = "import turtle\n\nturtle.right"
    tree = parse_source(source)
    assert isinstance(tree, parso.python.tree.Module)
    import_node = tree.children[0]
    assert isinstance(import_node, parso.python.tree.Import)
    assert import_node.get_first_leaf().prefix == "import"
    turtle_node = import_node.children[0]
    assert isinstance(turtle_node, parso.python.tree.ImportFrom)
    assert turtle_node.get_first_leaf().value == "turtle"
    assert turtle_node.get_first_leaf().end_pos == (1, 10)

# Generated at 2022-06-22 03:04:05.139283
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.jedi_utils_test import get_completions_equal

    import jedi

    jedi_version = jedi.__version__

    # The following are completions for string "test.test_jedi_utils.test_get_script_completions()".

# Generated at 2022-06-22 03:04:12.294935
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter

    import sys
    import _io

    result = get_interpreter_completions('"hello".', [{'__builtins__': __builtins__, 'sys': sys, 'io': _io}])
    assert result, "No completions found"
    assert len(result) > 0, "No completions found"



# Generated at 2022-06-22 03:04:21.059255
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module
    from parso.python.tree import Function
    from parso.python.tree import Class
    from parso.tree import Node
    from parso.tree import Leaf

    class FakeNode(Node):
        def __init__(self):
            super().__init__(children=[Leaf(type=None, value=None, parent=self)])

    class FakeClass(Class):
        def __init__(self):
            super().__init__(
                name=Leaf(type=None, value=None, parent=self),
                children=[FakeNode()],
                parent=None,
            )


# Generated at 2022-06-22 03:04:22.983775
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion_member = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion_member["name"] == "name"


# Generated at 2022-06-22 03:04:28.273874
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "test_name"
    complete = "test_complete"
    type = "test_type"
    description = "test_description"
    parent = "test_parent"
    full_name = "test_full_name"
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc.name == name
    assert tc.complete == complete
    assert tc.type == type
    assert tc.description == description
    assert tc.parent == parent
    assert tc.full_name == full_name



# Generated at 2022-06-22 03:04:40.299214
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import builtins

    # Ensure get_interpreter_completions returns the value from jedi/Interpreter.complete()
    # when the jedi version is >= 0.18
    value_of_jedi_core_Interpreter_complete = type(builtins)
    value_of_jedi_core_Interpreter_completions = type(int)
    assert value_of_jedi_core_Interpreter_complete == ThonnyCompletion
    assert value_of_jedi_core_Interpreter_completions == int
    # Ensure get_interpreter_completions returns the value from jedi/Interpreter.completions()
    # when the jedi version is < 0.18
    assert value_of_jedi_core_Interpreter_completions == ThonnyCompletion


# Generated at 2022-06-22 03:04:51.443695
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

# Generated at 2022-06-22 03:04:58.967364
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnycompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "fullname")
    assert thonnycompletion["name"] == "name"
    assert thonnycompletion["complete"] == "complete"
    assert thonnycompletion["type"] == "type"
    assert thonnycompletion["description"] == "description"
    assert thonnycompletion["parent"] == "parent"
    assert thonnycompletion["full_name"] == "fullname"

# Generated at 2022-06-22 03:05:08.025106
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import json\njson."
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)

    from jedi.api.classes import Completion

    expected = [
        Completion(
            "JSONDecodeError",
            "JSONDecodeError",
            "class",
            "BuiltinExceptions",
            "json.JSONDecodeError",
            "json",
        )
    ]
    assert sorted(completions, key=lambda x: x.name) == sorted(expected, key=lambda x: x.name)

# Generated at 2022-06-22 03:05:18.478652
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    from jedi.api.classes import Completion
    from jedi.api.keywords import KeywordName

    completion_obj = Completion(
        name="if",
        complete="if",
        type=KeywordName.IF,
        description="if statement",
        parent=None,
        full_name=None,
    )

    completion = ThonnyCompletion(
        name=completion_obj.name,
        complete=completion_obj.complete,
        type=completion_obj.type,
        description=completion_obj.description,
        parent=completion_obj.parent,
        full_name=completion_obj.full_name,
    )

    assert isinstance(completion, ThonnyCompletion)
    assert completion.name == completion_obj.name
    assert completion

# Generated at 2022-06-22 03:05:20.852743
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("print('hi')") is not None


# Generated at 2022-06-22 03:05:25.050822
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.python.parser import PythonParser
    parsed = parse_source("print('Hello'")
    assert isinstance(parsed, PythonParser)
    assert parsed.version[0] == 3


# Generated at 2022-06-22 03:05:26.786081
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("foo", "foo", "function", "fun fun fun", None, "foo")



# Generated at 2022-06-22 03:05:33.997380
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    def get_completions(source, namespaces, sys_path=None):
        return get_interpreter_completions(source, namespaces, sys_path)


# Generated at 2022-06-22 03:05:40.861607
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    if not _using_older_jedi(jedi):
        code = """
import sys
sys.ex"""
        completions = get_interpreter_completions(code, [{
            "name": "sys",
            "value": "sys"
        }])
        assert "exit" in [c.name for c in completions]

# Generated at 2022-06-22 03:05:46.466279
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(None, None, None, None, None, None)
    assert(tc.name == tc['name'])
    assert(tc.complete == tc['complete'])
    assert(tc.type == tc['type'])
    assert(tc.description == tc['description'])
    assert(tc.parent == tc['parent'])
    assert(tc.full_name == tc['full_name'])
    return

# Generated at 2022-06-22 03:06:07.255541
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi

# Generated at 2022-06-22 03:06:14.599387
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type=str,
        description="description",
        parent=1,
        full_name='fullname'
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == str
    assert completion.description == "description"
    assert completion.parent == 1
    assert completion.full_name == 'fullname'

    

# Generated at 2022-06-22 03:06:18.854314
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:06:29.698055
# Unit test for function get_definitions
def test_get_definitions():
    """
    >>> from ast import parse
    >>> from parso import parse
    >>> ast = parse("import math, ast\\na = math.factorial(3)")
    >>> pos = ast.children[2][1].children[0].children[0].children[1].end_pos
    >>> defs = get_definitions(ast, pos)
    >>> len(defs)
    1
    >>> defs[0].module_name
    'math'
    >>> defs[0].start_pos
    (0, 0)
    >>> str(defs[0]).strip().endswith("def factorial(x: int) -> int: ...")
    True
    """
    pass


# Generated at 2022-06-22 03:06:41.664569
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module

    def test(text, pos, expected_start, expected_end):
        node = parse_source(text)
        statement = get_statement_of_position(node, pos)
        check(statement, expected_start, expected_end)

    def check(statement, expected_start, expected_end):
        if statement is None:
            assert expected_start == expected_end == 0
        else:
            assert expected_start == statement.start_pos
            assert expected_end == statement.end_pos

    def check_none(text, pos):
        node = parse_source(text)
        assert get_statement_of_position(node, pos) is None

    test("a = 1; b = 2; c = 3; d = 4", 2, (1, 1), (1, 3))

# Generated at 2022-06-22 03:06:52.648487
# Unit test for function get_script_completions
def test_get_script_completions():
    def check(source, row, column, filename, sys_path, expected_completions):
        print(source)
        result = get_script_completions(source, row, column, filename, sys_path)
        result = list(result)
        #print([c.name for c in result])
        assert [c.name for c in result] == expected_completions

    check("import datetime", 0, 4, "bla.py", [], ["datetime"])
    check("import datetim", 0, 4, "bla.py", [], ["datetime"])
    check("import datetim", 0, 4, "bla.py", [r"C:\Python38\lib"], [])


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-22 03:06:57.807903
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    inp = "ThonnyCompletion(name, complete, type, description, parent, full_name)"
    result = eval(inp)
    assert result.name == "name"
    assert result.complete == "complete"
    assert result.type == "type"
    assert result.description == "description"
    assert result.parent == "parent"
    assert result.full_name == "full_name"

# Generated at 2022-06-22 03:07:04.261403
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    T = ThonnyCompletion
    assert T("name", "complete", "type", "description", "parent", "full_name") == {"name": "name", "complete": "complete", "type": "type", "description": "description", "parent": "parent", "full_name": "full_name"}
    assert "full_name" in T("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-22 03:07:06.207761
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python.tree import ClassOrFunc


# Generated at 2022-06-22 03:07:12.714591
# Unit test for function parse_source
def test_parse_source():
    import parso
    import ast

    source = "s = '''\n  qqq'''"
    tree = parse_source(source)
    assert isinstance(tree, parso.tree.Module)
    assert isinstance(tree.children[0].children[0], parso.tree.ExprStmt)
    assert isinstance(tree.children[0].children[0].children[0].children[1], parso.tree.JoiningString)

    try:
        ast_node = ast.parse(source)
    except SyntaxError:
        logger.debug("Failed to parse ast for '%s'", source)
    else:
        assert isinstance(tree, parso.tree.Module)
        assert isinstance(tree.children[0].children[0], parso.tree.ExprStmt)

# Generated at 2022-06-22 03:07:37.911493
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    ids = get_interpreter_completions('from collections import namedtup', [], [])
    assert isinstance(ids, list)
    assert isinstance(ids[0], ThonnyCompletion)
    assert ids[0].name == "Iterable"
    assert ids[0].full_name == "collections.abc.Iterable"

# Generated at 2022-06-22 03:07:44.288117
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def assert_is_correct_statement(node, pos):
        assert get_statement_of_position(node, pos) is node

    def assert_is_not_statement(node, pos):
        assert get_statement_of_position(node, pos) is None

    # Test open ranges
    node = tree.Node(children=[tree.Node(), tree.Node(), tree.Node()])
    assert_is_not_statement(node, 0)
    assert_is_not_statement(node, 1)
    assert_is_not_statement(node, 3)
    assert_is_not_statement(node, 4)

    # Test single nodes
    node = tree.Node(children=[tree.Node(start_pos=(0, 0), end_pos=(1, 0))])
    assert_is

# Generated at 2022-06-22 03:07:49.977444
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion['name'] == completion.name
    assert completion['complete'] == completion.complete
    assert completion['type'] == completion.type
    assert completion['description'] == completion.description
    assert completion['parent'] == completion.parent
    assert completion['full_name'] == completion.full_name

# Generated at 2022-06-22 03:07:52.335430
# Unit test for function parse_source
def test_parse_source():
    parse_source("def test(): print('test')")


# Generated at 2022-06-22 03:07:58.864709
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    ) == {
        "name": "name", "complete": "complete", "type": "type", "description": "description", "parent": "parent", "full_name": "full_name"
    }

# Generated at 2022-06-22 03:08:03.322184
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    completions = get_interpreter_completions(
        "import hashlib; hashlib.sha",
        [{"name": "hashlib", "module": sys.modules["hashlib"]}],
    )

    assert len(completions) == 2
    assert completions[0].complete == "hashlib.sha1"
    assert completions[1].complete == "hashlib.sha224"



# Generated at 2022-06-22 03:08:09.736681
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys, os, base64"
    row = 2
    column = 20
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].complete == "base64"


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-22 03:08:15.942825
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions(
        "a = list(map(",
        [
            jedi.Interpreter("a = [1, 2, 3]", []).namespaces[0],
            jedi.Interpreter("def myfunc(x): return x", []).namespaces[0],
        ],
        [],
    )
    assert completions[0].complete == "map("



# Generated at 2022-06-22 03:08:25.618507
# Unit test for function get_script_completions
def test_get_script_completions():
    def _test(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def _test_and_check(source, row, column, filename, result, sys_path=None):
        real_result = _test(source, row, column, filename, sys_path)
        print(real_result)
        print(result)
        assert set([c.name for c in real_result]) == set(result)

    _test_and_check(
        "import math\nmath.cos(", 5, 8, "<string>", ["cos", "acos", "cosh"]
    )

# Generated at 2022-06-22 03:08:37.212006
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser.utils import get_statement_of_position

    def get_completions(source: str, row: int, column: int) -> List[ThonnyCompletion]:
        return get_script_completions(source, row, column, filename="")

    # Intentional incomplete line
    assert get_completions("a", 1, 1) == get_completions("", 1, 1)

    # No completion at the end of line
    assert get_completions("", 1, 1) == []

    # No completion in comments
    assert get_completions("# Some comment", 1, 1) == []
    assert get_completions("# Some comment", 1, 9) == []
    assert get_completions("a # Some comment", 1, 3) == []

    # Completion only for

# Generated at 2022-06-22 03:09:11.905316
# Unit test for function parse_source
def test_parse_source():
    # See issue #858
    import parso
    source = "foo, bar"
    tree = parse_source(source)
    # Check positions of children
    assert tree.children[0].start_pos == (1, 0)
    assert tree.children[0].end_pos == (1, 3)
    assert tree.children[1].start_pos == (1, 4)
    assert tree.children[1].end_pos == (1, 10)
    # Check position of the whole node
    assert tree.start_pos == (1, 0)
    assert tree.end_pos == (1, 10)

# Generated at 2022-06-22 03:09:19.755018
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc1["name"] == "name"
    assert tc1["complete"] == "complete"
    assert tc1["type"] == "type"
    assert tc1["description"] == "description"
    assert tc1["parent"] == "parent"
    assert tc1["full_name"] == "full_name"



# Generated at 2022-06-22 03:09:23.785242
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module

    source = 'print("Hello World")'
    assert isinstance(parse_source(source), Module)
    return "OK"


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.DEBUG)

    print(test_parse_source())

# Generated at 2022-06-22 03:09:31.586804
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"


if __name__ == "__main__":
    test_ThonnyCompletion___getitem__()

# Generated at 2022-06-22 03:09:41.245704
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonny_completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )

    assert thonny_completion.name == "name"
    assert thonny_completion.complete == "complete"
    assert thonny_completion.type == "type"
    assert thonny_completion.description == "description"
    assert thonny_completion.parent == "parent"
    assert thonny_completion.full_name == "full_name"
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"

# Generated at 2022-06-22 03:09:44.528944
# Unit test for function parse_source
def test_parse_source():
    source = """import os.path
os.path.abspath(
"""
    result = parse_source(source)
    assert result is not None

# Generated at 2022-06-22 03:09:49.494896
# Unit test for function parse_source
def test_parse_source():
    source = """def foo(a="""
    module = parse_source(source)

    defs = module.children
    assert len(defs) == 1
    assert defs[0].name == "foo"

    assert len(defs[0].children) == 2
    assert defs[0].children[1].name == "a"

# Generated at 2022-06-22 03:09:53.690779
# Unit test for function parse_source
def test_parse_source():
    from parso import parse
    import jedi

    if _using_older_jedi(jedi) == True:
        try:
            assert parse_source('print("Hello world!")') == parse('print("Hello world!")')
        except AssertionError:
            print("parse_source is not working")



# Generated at 2022-06-22 03:10:04.944003
# Unit test for function get_definitions
def test_get_definitions():
    source = "from math import sin, fabs, exp\n\nprint(sin)\nsin(1)\nprint(fabs)\nfabs(3)\nprint(exp)\nexp(1)"
    row = 8
    column = 9
    filename = "test.py"

    # jedi 0.15.2

# Generated at 2022-06-22 03:10:15.967543
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions(
        "import array\narray.",
        [
            {
                "name": "array",
                "docstr": "Create an array.\n\n    The type code can be specified as a string of\n    a single character, like ``d`` for float,",
                "type": "type",
                "module_name": "array",
                "full_name": "array",
                "call_sig": "array(typecode[, initializer])",
            }
        ],
    )

    assert completions == _tweak_completions(
        jedi.Interpreter("import array\narray.", [{"name": "array"}]).complete()
    )

