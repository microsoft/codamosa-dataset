

# Generated at 2022-06-22 03:01:09.782553
# Unit test for function get_definitions
def test_get_definitions():
    from test.helper import run_in_python_process
    from test.test_jedi_utils import _test_get_definitions

    def _test_callable_in_another_process(code, row, col, filename, expected):
        process_result = run_in_python_process(_test_get_definitions, code, row, col, filename, expected)
        # print('returncode:', process_result.returncode)
        # print('output:', process_result.output)
        # print('error:', process_result.error)
        assert process_result.error is None
        assert process_result.returncode == 0

    def test_1():
        code = "import os\nos.path.jo\n"
        row, col = code.splitlines().index("os.path.jo") + 1,

# Generated at 2022-06-22 03:01:11.551798
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-22 03:01:19.702343
# Unit test for function get_script_completions
def test_get_script_completions():
    logger.info("Testing old vs new style completions")
    source = "import datetime;datetime.datetime."
    row = 1
    column = len(source)

    # old style completions
    completions = get_script_completions(source, row, column, "testdata/foo.py")
    assert any(c.name == "date" for c in completions)
    assert any(c.name == "now" for c in completions)



# Generated at 2022-06-22 03:01:29.772536
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.parser import ParserSyntaxError

    tree = parse_source("if True:\n    a=1\n")

    # cursor is before node
    n = get_statement_of_position(tree, (1, 4))
    assert isinstance(n, tree.ExprStmt)

    # cursor is after node
    n = get_statement_of_position(tree, (2, 0))
    assert n is None

    # cursor is on node
    n = get_statement_of_position(tree, (1, 8))
    assert isinstance(n, tree.ExprStmt)

    # cursor is on keyword
    n = get_statement_of_position(tree, (1, 0))
    assert isinstance(n, tree.Keyword)

    # cursor

# Generated at 2022-06-22 03:01:34.061669
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completions = get_script_completions("", 0, 0, "")
    assert isinstance(completions, list)

    completion = completions[0]
    assert isinstance(completion, ThonnyCompletion)
    assert completion.name is not None
    assert completion.complete is not None
    assert completion.type is not None

# Generated at 2022-06-22 03:01:43.660743
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    tc1 = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc1.__getitem__("name") == name
    assert tc1.__getitem__("complete") == complete
    assert tc1.__getitem__("type") == type
    assert tc1.__getitem__("description") == description
    assert tc1.__getitem__("parent") == parent
    assert tc1.__getitem__("full_name") == full_name

# Generated at 2022-06-22 03:01:50.331686
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('''def f(x):
    print(x)
    print(x)
    print(x)''').get_code() == 'def f(x):\n    print(x)\n    print(x)\n    print(x)'



# Generated at 2022-06-22 03:02:00.937076
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check_result(source, pos, expected):
        root = parse_source(source)
        result = get_statement_of_position(root, pos)
        if result is None:
            assert expected is None
        else:
            assert result.type == expected

    # TODO: add more tests once this function is stabilized

    check_result(
        """def foo():
            pass
            pass""",
        (1, 12),
        "pass_stmt",
    )

    check_result(
        """def foo():
            pass
            # comment
            pass""",
        (1, 29),
        "pass_stmt",
    )

    check_result(
        """def foo():
# comment
            pass
            pass""",
        (2, 12),
        "pass_stmt",
    )



# Generated at 2022-06-22 03:02:02.206957
# Unit test for function get_definitions

# Generated at 2022-06-22 03:02:14.250475
# Unit test for function parse_source
def test_parse_source():
    source = "def f(x):\n  s=0\n  for i in range(x):\n    s+=x\n  return s\n"
    tree = parse_source(source)

    # Unit test for function get_statement_of_position
    def test_get_statement_of_position():
        print("Testing function get_statement_of_position")
        assert get_statement_of_position(tree, (1, 0)) is not None
        assert get_statement_of_position(tree, (2, 2)) is not None
        assert get_statement_of_position(tree, (4, 0)) is not None
        assert get_statement_of_position(tree, (5, 4)) is not None


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:02:33.595550
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny import get_work_dir
    from thonny.misc_utils import running_on_windows

    from thonny.plugins.micropython import MicroPythonProxy, MicroPythonConfigPage
    from thonny.languages.utils import _copy_of_get_statement_of_position

    sys_path = get_work_dir() + "/../../tests/micropython/lib"
    MicroPythonConfigPage(None).add_sys_path(sys_path)
    if running_on_windows:
        sys_path = [sys_path.replace("\\", "/")]

    source = "import network\nnetwork.WLAN().connect("
    res = get_interpreter_completions(
        source, MicroPythonProxy.get_namespaces(), sys_path=sys_path
    )

    assert len

# Generated at 2022-06-22 03:02:38.758298
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion(name="something", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert tc['name'] == "something"
    assert tc['complete'] == "complete"
    assert tc['type'] == "type"
    assert tc['description'] == "description"
    assert tc['parent'] == "parent"
    assert tc['full_name'] == "full_name"


# Generated at 2022-06-22 03:02:48.846806
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    code = "import typing\n\n"
    script = Script(code, line=1, col=0)
    assert script.completions() == []

    script = Script(code, line=1, col=5)
    assert script.completions() == []

    script = Script(code, line=2, col=0)
    assert script.completions() == []

    script = Script(code, line=1, col=10)
    assert len(script.completions()) != 0

    script = Script(code, line=2, col=10)
    assert len(script.completions()) != 0



# Generated at 2022-06-22 03:02:57.997255
# Unit test for function get_definitions
def test_get_definitions():
    script = get_script_completions("import sys; sy", 1, 10, "")
    script2 = get_script_completions("import sys; sy", 1, 13, "")
    assert len(script) == len(script2)
    # 14 Apr 2020: script is a list, script2 is a generator
    assert [c.name for c in script] == [c.name for c in script2]
    assert [c.complete for c in script] == [c.complete for c in script2]



# Generated at 2022-06-22 03:03:06.780303
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Completion:
        def __init__(self, name: str, complete: str, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    assert ThonnyCompletion(
        'name', 'complete', 'type', 'description', 'parent', 'full_name'
    ) == Completion('name', 'complete', 'type', 'description', 'parent', 'full_name')

# Generated at 2022-06-22 03:03:18.214535
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    assert not _using_older_jedi(jedi)

    source = "import os"
    row = 0
    column = 10
    filename = "<test file>"

    script = jedi.Script(code=source, path=filename)
    definitions = script.infer(line=row, column=column)
    assert len(definitions) == 1
    assert definitions[0].type == "module"

    source = "import os\nimport sys"
    row = 1
    column = 10
    filename = "<test file>"

    script = jedi.Script(code=source, path=filename)
    definitions = script.infer(line=row, column=column)
    assert len(definitions) == 1
    assert definitions[0].type == "module"

    source = "import os; import sys"


# Generated at 2022-06-22 03:03:29.254499
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock
    from thonny import get_workbench, get_shell
    from thonny.shell import ShellView
    from thonny.languages import tr

    def complete_source(source, line, column):
        wb = get_workbench()
        wb.options_manager.set_option("editor.jedi_completion", True)
        shell = get_shell()
        shell.add_directive("@jedi_completions")
        shell.append_text(source)
        shell.exec_pending_commands()


# Generated at 2022-06-22 03:03:38.430071
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = "complete"
    name = "name"
    description = "description"
    type = "type"
    parent = "parent"
    full_name = "full_name"

    test = ThonnyCompletion(
        name=name,
        complete=complete,
        type=type,
        description=description,
        parent=parent,
        full_name=full_name,
    )

    assert test.complete == complete
    assert test.name == name
    assert test.description == description
    assert test.type == type
    assert test.parent == parent
    assert test.full_name == full_name



# Generated at 2022-06-22 03:03:50.056808
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    if not _using_older_jedi(import_jedi()):
        # This test is only relevant for older jedi
        return
    import json
    import os
    import sys
    import traceback
    import typing
    import types

    import jedi
    from jedi.parser_utils import get_parent_scope

    # type: typing.Optional
    mod = None
    # type: typing.Optional
    parent = None

    try:
        # XXX: this should be more flexible
        mod = types.ModuleType("mymodule")
        parent = get_parent_scope(mod.__dict__)
    except:
        traceback.print_exc()
    for line in sys.stdin.readlines():
        line = line.strip()
        if not line:
            continue

# Generated at 2022-06-22 03:03:56.954153
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="__name__", complete="__name__", type="name", description="description", parent=None, full_name="__name__")
    completion.__getitem__("name") == "__name__"
    completion.__getitem__("complete") == "__name__"
    completion.__getitem__("type") == "name"
    completion.__getitem__("description") == "description"
    completion.__getitem__("parent") == None
    completion.__getitem__("full_name") == "__name__"

# Generated at 2022-06-22 03:04:12.955368
# Unit test for function parse_source
def test_parse_source():
    import parso
    if parse_source("print()") is not None:
        logger.debug("Expected Nothing Return on parse_source")


# Generated at 2022-06-22 03:04:17.139160
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    completion = jedi.Completion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert ThonnyCompletion(completion.name, completion.complete, completion.type, completion.description, completion.parent, completion.full_name)
    return completion

# Generated at 2022-06-22 03:04:23.287210
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    # in jedi 0.13, function get_statement_of_position is located in module parser_utils
    assert get_statement_of_position is jedi.parser_utils.get_statement_of_position
    from parso.python import tree


# Generated at 2022-06-22 03:04:33.690705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions(source="", namespaces=[], sys_path=None)
    assert len(completions) == 0

    completions = get_interpreter_completions(source="", namespaces=[{}], sys_path=None)
    assert len(completions) == 0

    completions = get_interpreter_completions(
        source="x = 100", namespaces=[{}], sys_path=None
    )
    assert len(completions) == 1
    assert completions[0].complete == "x = 100"

    completions = get_interpreter_completions(
        source="x =", namespaces=[{}], sys_path=None
    )
    assert len(completions) > 0

# Generated at 2022-06-22 03:04:38.808945
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    
    if _using_older_jedi(jedi):
        assert False

# Generated at 2022-06-22 03:04:48.715791
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api import projects
    from jedi.api.helpers import clear_caches

    clear_caches()  # clear caches from previous actions

    # Get complete jedi environment
    project = projects.get_default_project()
    sys_path = project.sys_path

    # Prepare test data
    code = """class Test:
    def __init__(self):
        pass

    def test_f1(self):
        pass
"""
    row = 1
    column = 1
    filename = "main.py"


# Generated at 2022-06-22 03:04:51.080773
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    from unittest import TestCase


# Generated at 2022-06-22 03:04:52.404646
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.helper import test_python_subprocess


# Generated at 2022-06-22 03:04:59.916385
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    test = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert test.name == name
    assert test.complete == complete
    assert test.type == type
    assert test.description == description
    assert test.parent == parent
    assert test.full_name == full_name

# Generated at 2022-06-22 03:05:08.232100
# Unit test for function get_script_completions
def test_get_script_completions():
    def completions_eq(c1, c2):
        return c1.name == c2.name and c1.complete == c2.complete and c1.description == c2.description
    assert all(
        completions_eq(c1, c2)
        for c1, c2 in zip(
            get_script_completions("123456789\n", 1, 5, ""), [ThonnyCompletion("zip", "zip", "func", "builtins.zip", None, 'zip')]
        )
    )

# Generated at 2022-06-22 03:05:30.109333
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions("import math\nmath", [])
    assert len(completions) == 1, completions
    assert completions[0].name == "math", completions[0].name
    assert completions[0].complete == "math", completions[0].complete
    assert completions[0].type == "module", completions[0].type
    assert completions[0].description == "This module is always available.\nIt provides access to the mathematical functions defined by the C standard.", completions[0].description
    assert completions[0].parent == "", completions[0].parent
    assert completions[0].full_name == "math", completions[0].full_name

    if _using_older_jedi(jedi):
        import sys

        # this

# Generated at 2022-06-22 03:05:34.202015
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions('x = "ab"\nx.up', 1, 4, __file__)
    assert len(defs) > 0
    assert any(d.name == 'upper' for d in defs)
    assert any(d.name == 'upper' and d.full_name == 'str.upper' for d in defs)
    assert any(
        d.name == 'upper' and d.full_name == 'str.upper' and d.type == 'function' for d in defs
    )


# Generated at 2022-06-22 03:05:46.129155
# Unit test for function get_definitions
def test_get_definitions():
    """Test jedi.get_definitions"""
    from jedi.api.environment import get_default_environment


# Generated at 2022-06-22 03:05:51.223833
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions_with_local_imports(self):
            test_file_path = os.path.join(
                os.path.dirname(__file__), "test_jedi_utils", "get_definitions_with_local_imports.py"
            )
            with open(test_file_path) as f:
                source = f.read()
                row = 2
                column = 4
                definitions = get_definitions(source, row, column, test_file_path)
                self.assertEqual(len(definitions), 7)

        def test_get_definitions_with_local_imports_2(self):
            test_file_path = os

# Generated at 2022-06-22 03:06:02.921220
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "import s\ns."
    filename = "t.py"
    row, column = 1, 6
    completions = get_script_completions(source, row, column, filename)
    assert type(completions) == list
    assert all([isinstance(item, ThonnyCompletion) for item in completions])
    assert len(completions) >= 1
    assert completions[0].name == "exit"
    assert completions[0].complete == "exit()"

    # test completion for imported module
    source = "import sys\nsys."
    filename = "t.py"
    row, column = 1, 10
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) >= 1

# Generated at 2022-06-22 03:06:14.599561
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    if __name__ != "__main__":
        from thonny.plugins.jedi_backend import jedi_utils
        import jedi

        #ThonnyCompletion is a class in jedi_utils, using ThonnyCompletion instead of jedi_utils.ThonnyCompletion
        #to avoid cyclic dependency.
        completions = jedi.Script('def f').completions()
        tc = ThonnyCompletion(
            name=completions[0].name,
            complete=completions[0].complete,
            type=completions[0].type,
            description=completions[0].description,
            parent=completions[0].parent,
            full_name=completions[0].full_name,
        )
        assert tc.name == completions[0].name


# Generated at 2022-06-22 03:06:23.306117
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    if _using_older_jedi(jedi):
        test_complete = "test_completion"
        test_name = "test_name"
        test_type = "type"
        test_description = "description"
        test_parent = "parent"
        test_full_name = "full_name"
    else:
        test_complete = "test_completion="
        test_name = "test_name="
        test_type = "type"
        test_description = "description"
        test_parent = "parent"
        test_full_name = "full_name"


# Generated at 2022-06-22 03:06:31.861341
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion(name="a", complete="b", type="c", description="d", parent="e", full_name="f")
    assert x.name == "a"
    assert x.complete == "b"
    assert x.type == "c"
    assert x.description == "d"
    assert x.parent == "e"
    assert x.full_name == "f"
    assert x["name"] == "a"
    assert x["complete"] == "b"
    assert x["type"] == "c"
    assert x["description"] == "d"
    assert x["parent"] == "e"
    assert x["full_name"] == "f"



# Generated at 2022-06-22 03:06:42.701740
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from tests.jedi_utils import ThonnyCompletion
    tc_object = ThonnyCompletion(
        name='get',
        complete='get(',
        type='KeywordArgument',
        description='get(url, params=None, headers={}, cookies=None, stream=None, verify=None, cert=None, timeout=None, allow_redirects=True, proxies=None, hooks=None, return_response=False, session=None, trust_env=True)',
        parent='<function>',
        full_name='<function>.get',
    )
    assert tc_object["name"] == 'get'
    assert tc_object["complete"] == 'get('
    assert tc_object["type"] == 'KeywordArgument'

# Generated at 2022-06-22 03:06:47.056719
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    nodes = [tree.Module(None, None), tree.ForStmt(None, None), tree.ExprStmt(None, None)]
    for node in nodes:
        stmt = get_statement_of_position(node, (1, 1))
        assert node == stmt

    expr = tree.ExprStmt(None, [tree.Name(None, "myvar"), tree.Operator(None, "+=")])
    stmt = get_statement_of_position(expr, (1, 2))
    assert expr == stmt

    stmt = get_statement_of_position(expr, (1, 1))
    assert expr[0] == stmt

    stmt = get_statement_of_position(expr, (1, 3))
    assert expr[1] == stmt



# Generated at 2022-06-22 03:07:21.323919
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    root = parso.parse(
        """
        def func():
            pass

        class Foo:
            pass
        """
    )

    assert get_statement_of_position(root, (1, 0)) is None
    assert get_statement_of_position(root, (8, 0)) is None

    assert (1, 2) <= get_statement_of_position(root, (1, 2)).start_pos < (1, 8)
    assert (1, 2) <= get_statement_of_position(root, (1, 5)).start_pos < (1, 8)
    assert (1, 2) <= get_statement_of_position(root, (1, 8)).start_pos < (1, 8)

# Generated at 2022-06-22 03:07:23.825804
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    left_namespace = [
        {"__name__": "builtins", "__builtins__": {"range": range}},
    ]

# Generated at 2022-06-22 03:07:36.105781
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    from thonny import get_workbench
    from thonny.plugins.jedi_support import jediutils

    workbench = get_workbench()

# Generated at 2022-06-22 03:07:38.984507
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    ThonnyCompletion(name = "name", complete = "complete", type = "type", description = "description", parent = "parent", full_name = "full_name")['name']


# Generated at 2022-06-22 03:07:44.573574
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import numpy", 1, 1, "")
    else:
        assert get_script_completions("import numpy", 1, 1, "", [])

# Generated at 2022-06-22 03:07:53.459026
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.parser import ParserError
    import parso

    parsers = ["normal", "eval", "single", "exec", "execfile"]
    for parser_type in parsers:
        try:
            p = parso.parse("a = 1\nb = 2", parser_type)
        except ParserError:
            continue
        stmt_a = get_statement_of_position(p, 1)
        stmt_a2 = get_statement_of_position(p, 2)
        stmt_b = get_statement_of_position(p, 5)
        stmt_b2 = get_statement_of_position(p, 6)

        assert stmt_a.get_code() == "a = 1"
        assert stmt_a2.get_code() == "a = 1"

# Generated at 2022-06-22 03:08:03.773385
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module, Expr
    from parso.python import tree
    import parso

    source = "a = 1\nb = 2"
    tree = parse_source(source)
    assert get_statement_of_position(tree, len(source)) is tree.get_leaf_for_position(
        (5, 5)
    )

    tree = parse_source("a = b + c + d\n")
    assert get_statement_of_position(tree, len("a = b +")) is tree.get_leaf_for_position(
        (1, 7)
    )

    source = "a = 1\n\n"  # Empty statment after newline
    tree = parse_source(source)
    assert get_statement_of_position(tree, len(source)) is tree.get

# Generated at 2022-06-22 03:08:15.490368
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.python_shell import kernel_utils as ku
    import jedi
    s = """import os
os.path"""
    result = get_script_completions(s, 1, 11, "/tmp/foo")
    assert len(result) > 0
    name = [x.name for x in result]
    assert "path" in name

    s = """import os
os.path"""
    sys_path = ku.get_sys_path()
    result = get_script_completions(s, 1, 11, "/tmp/foo", sys_path)
    assert len(result) > 0
    name = [x.name for x in result]
    assert "path" in name

    s = """import os, sys
os.path"""

# Generated at 2022-06-22 03:08:18.322660
# Unit test for function parse_source
def test_parse_source():
    source = "import math\nfrom math import *\nfrom math import pow\n"
    source += "a = pow(3, 4)\nprint(a)"
    print(parse_source(source))



# Generated at 2022-06-22 03:08:28.922844
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi as old_jedi
    import jedi.api as new_jedi

    # we need to use a name that is not present in jedi
    incomplete_script = "list(m"
    row = 0
    column = len(incomplete_script)

    completions = get_script_completions(incomplete_script, row, column, "test")
    assert len(completions) == 1
    assert [completion.name for completion in completions] == ["map"]
    assert completions[0].complete == "map("

    if _using_older_jedi(old_jedi):
        assert type(completions[0]) == old_jedi.api.Completion
    else:
        assert type(completions[0]) == new_jedi.Completion

# Generated at 2022-06-22 03:09:31.539392
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso

    module_node = parso.parse("import math\nmath.c")
    comps = get_script_completions("import math\nmath.", 3, 3, "")

# Generated at 2022-06-22 03:09:41.216924
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion("qwerty", "qwerty", "qwerty", "qwerty", "qwerty", "qwerty")
    assert x["name"] == "qwerty"
    assert x["complete"] == "qwerty"
    assert x["type"] == "qwerty"
    assert x["description"] == "qwerty"
    assert x["parent"] == "qwerty"
    assert x["full_name"] == "qwerty"
    assert x.name == "qwerty"
    assert x.complete == "qwerty"
    assert x.type == "qwerty"
    assert x.description == "qwerty"
    assert x.parent == "qwerty"
    assert x.full_name == "qwerty"

# Generated at 2022-06-22 03:09:43.182718
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import ClassContext, CompiledInstance
    from jedi.parser import node_classes

    # An example class with and instance method

# Generated at 2022-06-22 03:09:53.193507
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_utils import get_interpreter_completions
    from thonny.ast_utils import parse_text

    namespaces = [{"__name__": "__main__", "__file__": "main.py", "x": 1, "A": 2}]
    completions = get_interpreter_completions("import numpy as np; np.", namespaces)
    completions_names = [c["name"] for c in completions]
    assert "arange" in completions_names
    assert "array" in completions_names

    assert sum(1 for c in completions if c["description"] == "subpackage") == 0

    # test namespaces
    completions = get_interpreter_completions("x; A.", namespaces)

# Generated at 2022-06-22 03:10:00.307373
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    result = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert result["name"] == "name"
    assert result["complete"] == "complete"
    assert result["type"] == "type"
    assert result["description"] == "description"
    assert result["parent"] == "parent"
    assert result["full_name"] == "full_name"


# Generated at 2022-06-22 03:10:05.852496
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

    assert test_completion["name"] == "name"
    assert test_completion["complete"] == "complete"
    assert test_completion["type"] == "type"
    assert test_completion["description"] == "description"
    assert test_completion["parent"] == "parent"
    assert test_completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:10:11.199175
# Unit test for function parse_source
def test_parse_source():
    import jedi

    assert jedi.__version__[:5] == "0.17."
    node = parse_source("def foo(x):\n    return x")
    assert node.children[1].children[1].children[0].children[0].children[2].value == "return"

# Generated at 2022-06-22 03:10:17.702180
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_obj = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert test_obj[0] == 'name'
    assert test_obj[1] == 'complete'
    assert test_obj[2] == 'type'
    assert test_obj[3] == 'description'
    assert test_obj[4] == 'parent'
    assert test_obj[5] == 'full_name'

# unit test for method get_definitions of module util

# Generated at 2022-06-22 03:10:29.754083
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__ as jedi_version

    if jedi_version[:4] > "0.17":
        # Unit test for function get_script_completions
        import mock

        import jedi

        jedi.Script = mock.Mock()
        jedi.Script.complete.return_value = "mock"
        result = get_script_completions("code", 1, 2, "filename", ["sys_path1", "sys_path2"])
        assert result == "mock"
        jedi.Script.assert_called_once_with(
            "code", 1, 2, "filename", project="mock project"
        )
        jedi.Script.complete.assert_called_once_with(line=1, column=2)
        jedi.Project.assert_called_once_

# Generated at 2022-06-22 03:10:34.151387
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    _t = ThonnyCompletion("int", "int", "", "", None, "int")
    assert(_t["name"] == "int")
    assert(_t["complete"] == "int")
    assert(_t["type"] == "")
    assert(_t["description"] == "")
    assert(_t["parent"] == None)
    assert(_t["full_name"] == "int")