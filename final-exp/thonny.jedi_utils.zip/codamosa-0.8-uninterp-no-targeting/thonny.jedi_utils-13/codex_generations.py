

# Generated at 2022-06-22 03:01:04.327242
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import jedi
    import parso
    from parso.python import tree
    import jedi.parser_utils
    import jedi.api.helpers


# Generated at 2022-06-22 03:01:12.890147
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnyCompletion.__getitem__("name") == "name"
    assert thonnyCompletion.__getitem__("complete") == "complete"
    assert thonnyCompletion.__getitem__("type") == "type"
    assert thonnyCompletion.__getitem__("description") == "description"
    assert thonnyCompletion.__getitem__("parent") == "parent"
    assert thonnyCompletion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-22 03:01:19.145961
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'


# Generated at 2022-06-22 03:01:22.646958
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    assert isinstance(parse_source("\n"), tree.Module)
    assert isinstance(parse_source("a"), tree.Module)

# Generated at 2022-06-22 03:01:30.159247
# Unit test for function parse_source
def test_parse_source():
    source = "def inc (x):\n  return x + 1\n"
    import parso
    from parso.tree import SearchScope
    from parso_helper import find_name_node

    module = parse_source(source)
    scope = SearchScope(module, (1, 0))
    def_node = find_name_node(scope, "inc")
    assert def_node is not None
    assert def_node.start_pos == (1, 4)


# Generated at 2022-06-22 03:01:37.359906
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class TestGetCompletions(TestCase):
        def test_completions(self):
            import jedi


# Generated at 2022-06-22 03:01:45.402996
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Interpreter

    def get_def_info(source: str, row: int, col: int, filename: str):
        return get_definitions(source, row, col, filename)

    source = """
if 1:
    def a():
        pass
"""
    defs = get_def_info(source, 2, 12, "test.py")
    assert len(defs) == 1
    assert defs[0].module_name == "test"
    assert defs[0].line == 2

    defs = get_def_info(source, 3, 14, "test.py")
    assert len(defs) == 1
    assert defs[0].module_name == "test"
    assert defs[0].line == 2


# Generated at 2022-06-22 03:01:55.897759
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api import classes, names

    test_obj = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_obj.name == "name"
    assert test_obj.complete == "complete"
    assert test_obj.type == "type"
    assert test_obj.description == "description"
    assert test_obj.parent == "parent"
    assert test_obj.full_name == "full_name"


"""
random code from jedi

from jedi.parser_utils import get_statement_of_position

from jedi import Script
from jedi import Interpreter

from jedi.api import classes, names
from jedi.api import use_2to3
"""

# Generated at 2022-06-22 03:02:04.367980
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import sys
    import parso
    import jedi

    cls = get_interpreter_completions.__code__
    code_version = "%d.%d" % (sys.version_info[0], sys.version_info[1])
    if code_version == "3.6":
        want = set(["__annotations__"])
    elif code_version == "3.7":
        want = set(["__annotations__", "__context__"])
    else:
        want = set(["__annotations__", "__context__", "__prog__"])
    want = want.union(set(jedi.__dict__.keys()))
    want = want.union(set(parso.__dict__.keys()))

# Generated at 2022-06-22 03:02:06.855797
# Unit test for function get_definitions

# Generated at 2022-06-22 03:02:19.781778
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    tree = parse_source("if a1 in [1,2,3]:\n pass")
    statement = get_statement_of_position(tree, (1, 4))
    assert isinstance(statement, parso.python.tree.Comparison)

    tree = parse_source("def foo():\n pass")
    statement = get_statement_of_position(tree, (1, 10))
    assert statement.type == "funcdef"

# Generated at 2022-06-22 03:02:22.927535
# Unit test for function get_script_completions
def test_get_script_completions():
    c = get_script_completions("z = 'abc'\nz.upper()", 0, 1, "")
    assert c



# Generated at 2022-06-22 03:02:34.422482
# Unit test for function get_definitions
def test_get_definitions():
    def get_module_from_source(source):
        import jedi.api

        return jedi.api.Interpreter(source=source)

    def get_module_by_path(path):
        import jedi.api

        return jedi.api.get_module_by_path(path)


# Generated at 2022-06-22 03:02:38.866558
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser

    parser = jedi.parser.Parser(
        'def foo():\n    """\n    Comment\n    """\n    pass # Comment'
    )
    statement = get_statement_of_position(parser.module, 42)
    if statement.type == "decorated":
        statement = statement.children[1]
    assert statement.type == "pass_stmt"

# Generated at 2022-06-22 03:02:44.862043
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    class TestCase(TestCase):
        def test_many_definitions(self):
            definitions = get_definitions("numpy.array([1, 2, 3])", 1, 1, "")
            self.assertGreater(len(definitions), 1)

            last_definition = definitions[-1]
            self.assertEqual(last_definition.name, "array")
            self.assertEqual(last_definition.type, "function")
            self.assertIn("numpy", last_definition.full_name)

        def test_imported_class_definition(self):
            definitions = get_definitions("from itertools import groupby", 1, 1, "")
            self.assertGreater(len(definitions), 1)

            last_definition = definitions[-1]
           

# Generated at 2022-06-22 03:02:53.406252
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import random

    test_source = """import os
import sys
from collections import namedtuple
from datetime import datetime, timedelta
from typing import Optional, List, Tuple, Set, Dict, Any, Callable
from pathlib import Path
from time import time
"""
    for i in range(1000):
        row = random.randint(1, 9)
        column = random.randint(1, 50)
        if i % 50 == 0:
            column = 0
        script = Script(test_source, row, column, "test.py")

        result = script.completions()
        result = _tweak_completions(result)
        for c in result:
            if c.name in ("from", "import"):
                print(row, column, c.name)
           

# Generated at 2022-06-22 03:03:02.398807
# Unit test for function get_script_completions
def test_get_script_completions():
    script_completions = get_script_completions("from sys import path\npath.", 1, 15, "test_file.py")
    assert len(script_completions) == 1
    assert script_completions[0].name == "path"
    assert script_completions[0].complete == "path"
    assert script_completions[0].description == "path: List[str]"
    assert script_completions[0].type == "instance"
    assert script_completions[0].parent == "sys"
    assert script_completions[0].full_name == "<sys.path: List[str]>"



# Generated at 2022-06-22 03:03:08.982222
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    input_dict = {
        'name': 'a',
        'complete': 'b',
        'type': 'c',
        'description': 'd',
        'parent': 'e',
        'full_name': 'f',
    }

    completion = ThonnyCompletion(**input_dict)
    assert completion.__dict__ == input_dict

# Generated at 2022-06-22 03:03:17.014852
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
x = "a"
x."""

    completions = get_script_completions(source, row=2, column=5, filename="")
    completions = sorted(completions, key=lambda c: c.name)
    assert completions[0].name == "capitalize"
    assert completions[0].complete == "capitalize"
    assert completions[0].description == "S.capitalize() -> str"
    assert completions[0].parent == "str"
    assert completions[0].full_name == "str.capitalize"

# Generated at 2022-06-22 03:03:23.788749
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import sys\nsys."
    namespaces = [{"a": "1", "b": "2"}]
    completions = get_interpreter_completions(source, namespaces)
    for completion in completions:
        if completion.name == "a":
            assert completion.complete == "a"
        elif completion.name == "b":
            assert completion.complete == "b"
        elif completion.name == "version":
            assert completion.complete == "version"

# Generated at 2022-06-22 03:03:50.451978
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete_1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    if complete_1.name != "name" or complete_1.complete != "complete" or complete_1.type != "type" or complete_1.description != "description" or complete_1.parent != "parent" or complete_1.full_name != "full_name": 
        raise AssertionError
    print("Test 1 passed")
    complete_2 = ThonnyCompletion("new_name", "new_complete", "new_type", "new_description", "new_parent", "new_full_name")

# Generated at 2022-06-22 03:03:58.788781
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").name == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").complete == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").type == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").description == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").parent == "parent"

# Generated at 2022-06-22 03:04:08.839506
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    from thonny.config import get_workbench_config_dir

    # Create a script with an import and the definition of an imported variable
    filename = os.path.join(get_workbench_config_dir(), "goto_test.py")
    with open(filename, "w") as f:
        f.write("import json\n")
        f.write("json.dumps")

    # Trigger go to definitions
    definitions = get_definitions(
        source='import json\njson.dumps', row=1, column=9, filename=filename
    )

    # Only a single definition should be returned
    assert len(definitions) == 1

    # Check that the correct module has been imported

# Generated at 2022-06-22 03:04:13.539711
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    script = Script("import sys; sys.pa", 3, len("sys.pa"))
    completions = script.completions()
    assert completions[0].name == "path"



# Generated at 2022-06-22 03:04:16.505061
# Unit test for function parse_source
def test_parse_source():
    actual = parse_source("1 + 1\n# A comment\nprint(42)").children
    assert len(actual) == 2
    assert isinstance(actual[0], _ast.Expr)



# Generated at 2022-06-22 03:04:27.906144
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from thonny.misc import get_jedi_version
    from thonny.misc import using_legacy_jedi
    from thonny.misc import using_jedi_16
    from thonny.misc import using_jedi_17

    source = """import tkinter
tk = tkinter.Tk()
tk.geometry("4
tk.mainloo
"""
    row = 3
    column = 4
    filename = "test.py"
    sys_path = ["/home/user/src/thonny/thonny/plugins/"]

    if using_jedi_16(jedi):
        result = get_script_completions(source, row, column, filename, sys_path)
    elif using_jedi_17(jedi):
        result = get_

# Generated at 2022-06-22 03:04:31.954067
# Unit test for function parse_source
def test_parse_source():
    source = "print('Hi')"
    ast = parse_source(source)
    assert ast.children[0].children[0].value == "print"
    assert ast.children[0].children[2].value == "Hi"

# Generated at 2022-06-22 03:04:40.130336
# Unit test for function get_definitions
def test_get_definitions():
    class Test:
        def get_definitions(source: str, row: int, column: int, filename: str):
            import jedi

            if _using_older_jedi(jedi):
                script = jedi.Script(source, row, column, filename)
                return script.goto_definitions()
            else:
                script = jedi.Script(code=source, path=filename)
                return script.infer(line=row, column=column)


# Generated at 2022-06-22 03:04:47.706443
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp_obj = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert comp_obj.name == "name"
    assert comp_obj.complete == "complete"
    assert comp_obj.type == "type"
    assert comp_obj.description == "description"
    assert comp_obj.parent == "parent"
    assert comp_obj.full_name == "full_name"

# Generated at 2022-06-22 03:04:57.120725
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position
    from jedi.api.project import jedi_cache

    test_code = """import math
number = math.p"""
    # Clean jedi cache for testing
    jedi_cache.clean()

    completions = get_script_completions(test_code, 1, 14, "UNIT_TEST", None)
    assert len(completions) == 1
    assert completions[0].complete == "pi"
    assert completions[0].description == "The mathematical constant *π*.\n\nThis is only an approximation of π, not a real constant like in geometry."

# Generated at 2022-06-22 03:05:15.118153
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')['name'] == 'name'

# Generated at 2022-06-22 03:05:27.112245
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_case = ThonnyCompletion(name="test_case", complete="test_case", type="test_case", description="test_case", parent="test_case", full_name="test_case")
    if test_case["name"] != "test_case":
        raise AssertionError
    if test_case["complete"] != "test_case":
        raise AssertionError
    if test_case["type"] != "test_case":
        raise AssertionError
    if test_case["description"] != "test_case":
        raise AssertionError
    if test_case["parent"] != "test_case":
        raise AssertionError
    if test_case["full_name"] != "test_case":
        raise AssertionError
    return True


# Generated at 2022-06-22 03:05:34.730943
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from typing import List, Dict
    
    # Using a dict to keep track of namespaces

# Generated at 2022-06-22 03:05:46.341240
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    def _test(source, pos, expected_name):
        func = getattr(
            jedi.parser_utils, "get_statement_of_position", _copy_of_get_statement_of_position
        )
        node = parse_source(source)
        result = func(node, pos)
        assert expected_name == result.children[0].value

    _test("a = [1 + 2 +\n", (1, 4), "3")
    _test("a = [1 + 2 +\n", (2, 1), "3")
    _test("a = [1 + 2 +\n", (2, 2), "3")
    _test("a = [1 + 2 +\n", (2, 3), "3")

# Generated at 2022-06-22 03:05:57.995540
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    class Tests(TestCase):
        def test_simple_assignment(self):
            def test_simple_assignment(self):
                results = get_definitions('a = 1', 0, 0, '')
                self.assertEqual(1, len(results))
                assign = results[0]
                self.assertEqual('Assign', assign.type)
                self.assertEqual('AssignStmt', assign.parent.type)

        def test_function_def(self):
            results = get_definitions('def f():\n    pass', 1, 0, '')
            self.assertEqual(1, len(results))
            f = results[0]
            self.assertEqual('Function', f.type)

# Generated at 2022-06-22 03:06:09.078147
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        example_completion = jedi.Script("import sys; sys").completions()[0]
    else:
        example_completion = jedi.Script("import sys; sys").complete()[0]

    tc = ThonnyCompletion(
        name=example_completion.name,
        complete=example_completion.complete,
        type=example_completion.type,
        description=example_completion.description,
        parent=example_completion.parent,
        full_name=example_completion.full_name,
    )
    assert tc.name == example_completion.name
    assert tc.complete == example_

# Generated at 2022-06-22 03:06:17.915148
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "ThonnyCompletion"
    complete = "ThonnyCompletion"
    type = "class"
    description = "Hello World"
    parent = "String"
    full_name = "class ThonnyCompletion"

    completion = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert completion[0] == name
    assert completion[1] == complete
    assert completion[2] == type
    assert completion[3] == description
    assert completion[4] == parent
    assert completion[5] == full_name

# Generated at 2022-06-22 03:06:18.810495
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:06:30.551888
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_cached_code

    source = """get_interpreter_completions(source: str, namespaces: List[Dict], sys_path=None):
        import jedi"""
    namespaces = [get_cached_code("", "").namespace]
    completions = get_interpreter_completions(source, namespaces)
    assert completions[0].name == "get_interpreter_completions"
    assert completions[0].complete == "get_interpreter_completions"
    assert completions[0].description == "def get_interpreter_completions"

    assert completions[1].name == "get_cached_code"
    assert completions[1].complete == "get_cached_code"

# Generated at 2022-06-22 03:06:40.822616
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"a": "hello", "b": "world"}]
    completions = get_interpreter_completions("a", namespaces)
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].description == "hello"


if __name__ == "__main__":
    import sys

    test_get_interpreter_completions()

    print(
        "Completions for %s: %s"
        % (sys.argv[1], get_interpreter_completions(sys.argv[1], [{}]))
    )

# Generated at 2022-06-22 03:06:58.929431
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso

    parent = parso.parse_string("foo=True").children[0]
    ThonnyCompletion(name="foo", complete="foo", type="completion", description="foo", parent=parent, full_name="foo")

# Generated at 2022-06-22 03:07:05.546152
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name='name', complete='complete', type='type', description='description', parent='parent', full_name='full_name')
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'


# Generated at 2022-06-22 03:07:15.305902
# Unit test for function get_script_completions
def test_get_script_completions():
    def _filter_by_prefix(completions, prefix):
        completions = [c.name for c in completions]
        print(completions)
        return [c for c in completions if c.startswith(prefix)]

    # text = 'def get_script_completions(source, line, column, filename):
    # import jedi
    # script = jedi.Script(source, line, column, filename)
    # completions = script.completions()
    # return [(c.name, c.complete) for c in completions]
    #     '

    text1 = 'import re\nre.match("").'
    text2 = 'import re\nre.match("", flags=re.'

    completions1 = get_script_completions(text1, 2, 17, "")


# Generated at 2022-06-22 03:07:27.384637
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    # The following namespace is created in order to make this test independent from any actual environment.
    # It should work in any environment.
    ns = [{
        "__name__": "__main__",
        "a": None,
        "b": None,
        "c": None,
        "d": None,
        "e": None,
        "y": None,
        "z": None,
        "r": {"r": None},
        "sys": sys,
        "print": None,
    }]
    def _complete_text(text):
        completions = get_interpreter_completions(text, ns, sys_path=["../demos"])
        return [s.complete for s in completions]

    # Corner cases:

# Generated at 2022-06-22 03:07:38.861537
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import unittest

    import jedi

    sys_path = [os.path.expanduser("~/github/thonny/thonny")]

    class InterpreterCompletionsTestCase(unittest.TestCase):
        def check_completions(self, source_lines, expected_completions, sys_path=None):
            source = "\n".join(source_lines)
            # self.assertTrue(sys_path is not None)
            completions = get_interpreter_completions(source, [], sys_path)
            self.assertEqual(set(c.name for c in completions), expected_completions)

    suite = unittest.TestLoader().loadTestsFromTestCase(InterpreterCompletionsTestCase)

# Generated at 2022-06-22 03:07:50.908230
# Unit test for function get_definitions
def test_get_definitions():
    source = """import re
re.match("", "")"""
    from collections import namedtuple
    from jedi import ParserError
    from thonny.plugins.jedi_backend import utils
    
    # initialization
    
    # mocking
    def _get_row():
        return 1
    
    def _get_column():
        return 7
    
    # mocking row and column
    utils.get_row = _get_row
    utils.get_column = _get_column
    # mocking file name
    filename = "mock.py"
    
    # test
    
    # test ParserError exception

# Generated at 2022-06-22 03:08:02.009562
# Unit test for function get_script_completions
def test_get_script_completions():
    # string need to be long enough, otherwise jedi won't find any completions
    # 50 chars are the minimum
    source = "a = 1\nb = 2\n"

    result = get_script_completions(source, 0, 2, "test.py")

# Generated at 2022-06-22 03:08:13.814397
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import time

    # The purpose of this test is to check that get_interpreter_completions
    # works with jedi 0.12 even if above other cases have been developed for
    # newer versions.
    source = "time."
    namespaces = [
        {"time": time},
        {"sys": "builtin"},
        {"os": "builtin"},
        {"shutil": "builtin"},
        {"subprocess": "builtin"},
    ]
    result = get_interpreter_completions(source, namespaces)

    # Should find all possible completions
    assert len(result) > 20

    # Check that types are correctly set
    assert result[0].type == "statement"
    assert result[1].type == "import"
    assert result[2].type == "keyword"

# Generated at 2022-06-22 03:08:24.168458
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import ast
    import traceback
    # Generate test data
    namespaces = [{"foo": 1, "bar": 2}, {"baz": 3}]
    source = "baz.f"
    # Test with source containing syntax error
    try:
        Interpreter(source, namespaces).completions()
        raise Exception("Interpreter did not throw an exception!")
    except SyntaxError:
        pass
    # Test with source not containing a syntax error
    source = "baz."
    completions = Interpreter(source, namespaces).completions()
    assert len(completions) == 1
    assert completions[0].name == "f"
    # Test with source containing syntax error

# Generated at 2022-06-22 03:08:30.653488
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:09:04.918699
# Unit test for function get_definitions

# Generated at 2022-06-22 03:09:08.939409
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__
    from jedi.parser_utils import get_cached_code_lines

# Generated at 2022-06-22 03:09:09.968618
# Unit test for function parse_source
def test_parse_source():
    parse_source("print(123)")

# Generated at 2022-06-22 03:09:15.925089
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import textwrap

    if not hasattr(parso.utils, "get_statement_of_position"):
        print('function "get_statement_of_position" is absent')
    else:
        print('function "get_statement_of_position" is present')

    source = textwrap.dedent(
        """\
        if x == 1:
            a = 1
        else:
            a = 2
        """
    )

    tree = parso.parse(source)
    node = get_statement_of_position(tree, source.index("a = 1"))
    assert node.type == "simple_stmt"

    node = get_statement_of_position(tree, source.index("a ") + 1)
    assert node.type == "simple_stmt"

# Generated at 2022-06-22 03:09:26.257801
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test with older jedi versions
    import jedi
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        completions = get_interpreter_completions("import os\nos.", [{}])
        assert "listdir(" in (c[1] for c in completions)
        assert "name" in (c[0] for c in completions)

    else:
        completions = get_interpreter_completions("import os\nos.", [{}])
        assert "listdir(" in (c.complete for c in completions)
        assert "name" in (c.name for c in completions)

    # Test with older jedi versions

# Generated at 2022-06-22 03:09:30.473640
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.settings.case_insensitive_completion = True
    jedi.settings.additional_dynamic_modules = [
        "packaging.version",
        "packaging._structures",
    ]

    # Test case to cover completion for a single character
    completion = get_script_completions(
        'import packagin', 0, 17, "", sys_path=[__file__]
    )
    assert completion[0].name == "packaging"

    completion = get_script_completions(
        'import packagin', 0, 17, "", sys_path=[__file__, "/"]
    )
    # Should have the same result with or without additional sys_path
    assert completion[0].name == "packaging"


# Generated at 2022-06-22 03:09:38.307193
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = """class A:\n\tdef __init__(self):\n\t\tpass\n\ta = A()\na.capitalize"""

    completions = get_script_completions(source, 3, 7, "test.py")
    assert completions and isinstance(completions[0], ThonnyCompletion)
    if _using_older_jedi(jedi):
        assert completions[0].name == "capitalize"
    else:
        assert completions[0].name == "capitalize="



# Generated at 2022-06-22 03:09:44.188075
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion(name="len", complete="len", type="function", description="len(object)", parent="None", full_name="len")
    assert comp.name == "len"
    assert comp.complete == "len"
    assert comp.type == "function"
    assert comp.description == "len(object)"
    assert comp.parent == "None"
    assert comp.full_name == "len"

# Generated at 2022-06-22 03:09:47.774620
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("import sys\nsy", 2, 5, "")
    assert len(result) == 1
    assert result[0]["name"] == "sys"


# Generated at 2022-06-22 03:09:58.242869
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import inspect

    cur_file = os.path.abspath(inspect.getsourcefile(test_get_definitions))
    cur_folder = os.path.dirname(cur_file)


# Generated at 2022-06-22 03:10:33.667847
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert t["name"] == "name"
    assert t["complete"] == "complete"
    assert t["type"] == "type"
    assert t["description"] == "description"
    assert t["parent"] == "parent"
    assert t["full_name"] == "full_name"

# Generated at 2022-06-22 03:10:44.655090
# Unit test for function get_definitions
def test_get_definitions():
    def test(expected, source):
        completions = get_definitions(source=source, row=source.index("^"), column=0, filename="<string>")
        assert len(expected) == len(completions)
        for i, completion in enumerate(completions):
            assert expected[i] == completion.name
            assert expected[i] == str(completion)

    test(["ft"], "ft^")
    test(["ft"], "import ft^")
    test(["ft"], "import ft\n^")
    test(["ft"], "import ft\n\n^")

    test(["ft"], "import ft\ndef f():\n    pass\n\n^")
    test(["ft"], "def f():\n    import ft\n    ^")

# Generated at 2022-06-22 03:10:51.129377
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # Test complete
    completions = get_interpreter_completions("sorted([])", [])
    assert list(c.name for c in completions) == ["sorted"]

    # Test complete using namespaces
    completions = get_interpreter_completions("a", [{"a": 1}])
    assert list(c.name for c in completions) == ["a"]

    if not _using_older_jedi(jedi):
        # Test complete with sys_path
        completions = get_interpreter_completions("d", [], ["C:\\Test"])
        assert list(c.name for c in completions) == ["demo"]
        # Test complete with sys_path not found