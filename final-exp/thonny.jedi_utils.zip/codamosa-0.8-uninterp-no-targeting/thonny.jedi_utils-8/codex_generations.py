

# Generated at 2022-06-22 03:01:04.326560
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    import parso
    import jedi

    def get_dir():
        return os.path.dirname(jedi.__file__)

    def get_test_defs(jedi):
        test_defs = jedi.api.names(
            script="""
        import jedi
        """,
            path=get_dir() + "/../../test/test_evaluator.py",
            references=True,
            all_scopes=False,
            definitions=True,
        )
        return test_defs


# Generated at 2022-06-22 03:01:10.574275
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    params = {
        "name": "param1",
        "complete": "param1",
        "type": "int",
        "description": "param1: int",
        "parent": "module1",
        "full_name": "module1.param1",
    }
    test_obj = ThonnyCompletion(**params)

    for key in params:
        assert test_obj[key] == params[key]

# Generated at 2022-06-22 03:01:24.692014
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso
    import jedi
    import re
    import pprint
    source = """import os;
os.ch"""
    pos = (1, 8)
    offset = len(source[:pos[1]])
    tree = parse_source(source)

    # Get completions from jedi
    completions = get_script_completions(source, pos[0], pos[1], "" )
    pprint.pprint(completions)

    names = [c.name for c in completions]
    assert 'chdir' in names
    assert 'chmod' in names

    source = """with magic():
        print(magi"""
    pos = (2, 17)
    offset = len(source[:pos[1]])
    tree = parse_source(source)
    completions = get_script_

# Generated at 2022-06-22 03:01:29.756394
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:01:40.415614
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent=None, full_name="full_name")["name"] == "name"
    assert ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent=None, full_name="full_name")["complete"] == "complete"
    assert ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent=None, full_name="full_name")["type"] == "type"
    assert ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent=None, full_name="full_name")["description"] == "description"

# Generated at 2022-06-22 03:01:46.853166
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils as utils
    from parso.python import tree

    class MyNode(tree.BaseNode):
        def __init__(self, children, start_pos, end_pos):
            self.children = children
            self.start_pos = start_pos
            self.end_pos = end_pos
            self.type = "this_is_node_type"

    # Test 1
    root = MyNode([], 0, 100)
    child = MyNode([], 0, 10)
    root.children = [child]
    assert utils.get_statement_of_position(root, 5) == child

    # Test 2
    root = MyNode([], 0, 100)
    child = MyNode([], 0, 10)
    root.children = [child]
    assert utils.get_statement

# Generated at 2022-06-22 03:01:52.867280
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"

# Generated at 2022-06-22 03:01:55.410967
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions(
        "from collections import defaultdict\ndefaultdict", 0, 0, "test.py"
    )


# Generated at 2022-06-22 03:02:04.251217
# Unit test for function get_script_completions
def test_get_script_completions():
    # unit test for function get_script_completions
    def assert_completions_equal(completions1, completions2):
        assert completions1 == completions2, "Expected: %s\nGot: %s" % (completions2, completions1)

    source = "class Foo:\n    pass\n\nFoo\n"
    completions = get_script_completions(source, 4, 1, filename="testfile.py")
    assert len(completions) == 1
    assert completions[0].name == "Foo"
    assert completions[0].parent == "__main__"
    assert completions[0].type == "class"
    assert completions[0].full_name == "__main__.Foo"

# Generated at 2022-06-22 03:02:05.327081
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:02:25.836623
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    item = ThonnyCompletion("", "", "", "", "", "")
    assert item["name"] == ""
    assert item["complete"] == ""
    assert item["type"] == ""
    assert item["description"] == ""
    assert item["parent"] == ""
    assert item["full_name"] == ""

# Generated at 2022-06-22 03:02:35.999634
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    # test with jedi version 0.13.1
    # returns a list of Definition objects
    # definition objects have the following attributes (see jedi source code)

    class Definition:
        def __init__(self, name, start_line, complete, type, description, parent, full_name):
            self.name = name
            self.start_line = start_line
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name


# Generated at 2022-06-22 03:02:42.575312
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert get_interpreter_completions("abs(-3)", [], []) == _tweak_completions(jedi.Interpreter("abs(-3)", []).complete())

# Generated at 2022-06-22 03:02:49.280184
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "description"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-22 03:03:01.977744
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.tree import KeywordStatement
    from jedi.parser_utils import get_statement_of_position
    from jedi.parser import ParserSyntaxError

    source = "class A:\n    def x(self, y):\n        def x(self, y):\n            pass\n"
    module = parse_source(source)
    assert isinstance(get_statement_of_position(module, 23), tree.Function)
    assert isinstance(get_statement_of_position(module, 24), tree.Function)
    assert isinstance(get_statement_of_position(module, 25), tree.Function)
    assert isinstance(get_statement_of_position(module, 26), tree.Function)

# Generated at 2022-06-22 03:03:14.198761
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completion import get_script_completions
    import json

    source = "int()\n"
    completions = get_script_completions(source, 1, 4, "dummy.py")


# Generated at 2022-06-22 03:03:22.919536
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse
    from parso.python.tree import Keyword
    from parso.python.tree import Dict
    from parso.python.tree import Name
    from parso.python.tree import Leaf
    from parso.python.tree import Array
    from parso.python.tree import Subscript
    from parso.python.tree import Call
    from parso.python.tree import Function

    node = parse("def f(x=0):\n    return x[0]")
    assert isinstance(get_statement_of_position(None, 0), Keyword)
    assert isinstance(get_statement_of_position(node, 0), Function)
    assert isinstance(get_statement_of_position(node, 11), Name)

# Generated at 2022-06-22 03:03:29.516247
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_obj = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_obj.name == "name"
    assert test_obj.complete == "complete"
    assert test_obj.type == "type"
    assert test_obj.description == "description"
    assert test_obj.parent == "parent"
    assert test_obj.full_name == "full_name"

# Generated at 2022-06-22 03:03:40.633761
# Unit test for function get_definitions
def test_get_definitions():
    def _test_common(source, expected_line, expected_column, expected_module_name):
        import os

        filename = os.path.join(os.path.dirname(__file__), "..", "..", "..", "tests", "data")
        filename = os.path.join(filename, "sample_program.py")
        definitions = get_definitions(source, 3, 3, filename)
        assert len(definitions) > 0
        definition = definitions[0]
        assert definition.line == expected_line
        assert definition.column == expected_column
        assert definition.module_name == expected_module_name

    _test_common(
        "def f():\n    e = Entry()\n    e.delete\n",
        9,
        4,
        "tkinter",
    )

   

# Generated at 2022-06-22 03:03:52.948483
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class jedi_Completion:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    completion = jedi_Completion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    result = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert completion.name == result.name
    assert completion.complete

# Generated at 2022-06-22 03:04:06.102966
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    source = "def factorial(n): return 1 if n == 0 else n * factorial(n - 1)"
    script = get_script_completions(source, 1, 12, filename="TEST", sys_path=None)
    test_completion = script[0]
    assert test_completion.name == "factorial"
    assert test_completion["name"] == "factorial"

# Generated at 2022-06-22 03:04:18.055835
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    script = """import math
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __str__(self):
            return '(' + str(self.x) + ', ' + str(self.y) + ')'

    p = Point(1, 2)
    p."""


# Generated at 2022-06-22 03:04:29.183878
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree


# Generated at 2022-06-22 03:04:33.350657
# Unit test for function get_definitions
def test_get_definitions():
    res = get_definitions("y = 5\ny", 1, 3, "testfile.py")

    assert len(res) == 1
    assert res[0].type == "statement"
    assert res[0].line == 1



# Generated at 2022-06-22 03:04:33.989572
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:37.256421
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi._compatibility import utf8_repr


# Generated at 2022-06-22 03:04:43.777607
# Unit test for function get_definitions
def test_get_definitions():
    definitions = get_definitions("x = len", 0, 7, "")
    assert len(definitions) == 1
    assert definitions[0].line == 0
    assert definitions[0].module_path == "builtins"
    assert definitions[0].column == 0
    assert definitions[0].description == textwrap.dedent(
        """
    len(obj, /)
    --
    Return the number of items in a container.
    """
    )



# Generated at 2022-06-22 03:04:49.860563
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    import parso

    code = "class Temp():\n    def x():    \n        pass"
    module = parso.parse(code)
    func_def = get_statement_of_position(module, (2, 5))
    assert jedi.parser_utils.get_statement_of_position(module, (2, 5)) == func_def
    assert func_def.name.value == "x"
    assert func_def.start_pos == (2, 4)
    assert func_def.end_pos == (3, 9)

# Generated at 2022-06-22 03:04:51.591701
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:52.194570
# Unit test for function get_definitions

# Generated at 2022-06-22 03:05:12.469123
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    s = "def f(x) -> int:\n    return x"
    result = parse_source(s)
    assert isinstance(result, tree.Module)
    assert result.children[0].type == "funcdef"

    s = "import sys"
    result = parse_source(s)
    assert isinstance(result, tree.Module)
    assert result.children[0].type == "simple_stmt"
    assert result.children[0].children[0].type == "import_from"

    s = "print()"
    result = parse_source(s)
    assert isinstance(result, tree.Module)
    assert result.children[0].type == "simple_stmt"
    assert result.children[0].children[0].type == "power"


# Generated at 2022-06-22 03:05:17.220315
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree

    node = parse_source("x = [1,2]\n")
    assert isinstance(node, parso.python.tree.Module)
    assert len(node.children) == 1
    assert isinstance(node[0], parso.python.tree.ExprStmt)



# Generated at 2022-06-22 03:05:23.155126
# Unit test for function parse_source
def test_parse_source():
    source_1 = "import os\nos.path.join(os.getcwd(), x)"
    source_2 = "import os\nos.path.join(os.getcwd(),\nx)"
    source_3 = "import os\nos.path.join(os.getcwd(),\\\nx)"
    source_4 = "import os\nos.path.join(os.getcwd()\nx)"
    source_5 = "import os\nos.path.join(\nos.getcwd(),\nx)"
    parse_object = parse_source(source_1)
    parse_object = parse_source(source_2)
    parse_object = parse_source(source_3)
    parse_object = parse_source(source_4)
    parse_object = parse_source(source_5)

# Generated at 2022-06-22 03:05:26.151337
# Unit test for function parse_source
def test_parse_source():
    import jedi

    source = "def f(x=2): pass\n"
    tree = parse_source(source)
    assert isinstance(tree, jedi.parser.tree.Module)

# Generated at 2022-06-22 03:05:30.189886
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi

    thonny_completion = ThonnyCompletion(
        name="a",
        complete="a",
        type=jedi.api_classes.Name(),
        description=None,
        parent=None,
        full_name="a",
    )
    assert thonny_completion["name"] == "a"

# Generated at 2022-06-22 03:05:37.982177
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    source = "def f():\n    pass\n    b=1\n    c=2\n"
    node = parso.parse(source)
    assert get_statement_of_position(node, len(source) - 5) is not None
    assert get_statement_of_position(node, len(source) - 5).type == "simple_stmt"


# Generated at 2022-06-22 03:05:44.605051
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    my_completion = ThonnyCompletion(name="Hello", complete="Hello World", type=jedi.types.Function, description="", parent=None, full_name="Hello World")
    assert my_completion.name == "Hello"
    assert my_completion.complete == "Hello World"
    assert my_completion.description == ""
    assert my_completion.parent is None
    assert my_completion.full_name == "Hello World"

# Generated at 2022-06-22 03:05:51.481182
# Unit test for function get_definitions
def test_get_definitions():
    module_node, _ = parse_source("import os")
    import_stmt = get_statement_of_position(module_node, pos=module_node.end_pos - 1)
    definitions = get_definitions(
        source="import os", row=import_stmt.start_pos[0], column=import_stmt.start_pos[1]
    )
    assert len(definitions) == 1
    assert definitions[0].module_path.endswith("os.py")

# Generated at 2022-06-22 03:06:03.185598
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        source='"".join(["a","b"]).rep',
        row=0,
        column=23,
        filename=None,
        sys_path=['/Users/eero/Documents/examples'])

    assert len(completions) == 1
    assert completions[0].name == "replace"
    assert completions[0].complete == "replace"
    assert completions[0].description.startswith("replace")
    assert completions[0].description.endswith("\nreplace(old, new, count)")
    assert completions[0].parent.startswith("str")
    assert completions[0].parent.endswith("str")
    assert completions[0].full_name == "str.replace"

# Generated at 2022-06-22 03:06:12.026852
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "test_ThonnyCompletion___getitem__"
    complete = name
    type = "test_ThonnyCompletion___getitem__"
    description = ""
    parent = None
    full_name = ""
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc["name"] == name
    assert tc["complete"] == complete
    assert tc["type"] == type
    assert tc["description"] == description
    assert tc["parent"] == parent
    assert tc["full_name"] == full_name

# Generated at 2022-06-22 03:06:42.700131
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion=ThonnyCompletion("name", "complete", "type", "desc", "par", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "desc"
    assert completion.parent == "par"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:06:48.059704
# Unit test for function get_script_completions
def test_get_script_completions():
    from tests.helpers import prepare_test_file
    import os

    if not os.path.exists(prepare_test_file._PATH_TEST_DATA):
        prepare_test_file.initialize_test_data()

    _test_one_test_case(prepare_test_file.PATH_TEST_DATA_COMPLETIONS)



# Generated at 2022-06-22 03:06:51.873916
# Unit test for function get_definitions

# Generated at 2022-06-22 03:06:59.284651
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.environment import Interpreter
    from jedi.api import Script
    import os
    import sys
    import parso
    
    print("Jedi version:",jedi.__version__)

    # change directory to test folder
    wd = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0,wd+"/test_files/")

    # parse .py file and create a Script object
    module = parso.parse(open(wd+"/test_files/test_definitions.py").read())
    script = Script(module=module, sys_path=[wd+"/test_files/"])
    # get line number

# Generated at 2022-06-22 03:07:09.769951
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    from unittest.mock import patch, Mock

    import jedi

    class ThonnyCompletionMock(Mock):
        def __init__(self, name, complete, type, description, parent, full_name):
            super().__init__()
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

        def __getitem__(self, key):
            return self.__dict__[key]

        def __iter__(self):  # For Python 3.5 compatibility
            return iter(self.__dict__.items())

    with patch("jedi.Script", autospec=True) as mock_script_class:
        mock_script = Mock

# Generated at 2022-06-22 03:07:21.367119
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    from thonny.jedi_utils import get_statement_of_position

    tree1 = parse_source("a = 1")
    pos = [0, 0]
    assert get_statement_of_position(tree1, pos) == tree1
    pos = [0, 1]
    assert get_statement_of_position(tree1, pos) == tree1
    pos = [0, 3]
    assert get_statement_of_position(tree1, pos) == tree1.children[0]
    pos = [0, 4]
    assert get_statement_of_position(tree1, pos) == tree1

    tree2 = parse_source("a = 1\nb = 2")
    pos = [1, 0]
    assert get_statement_of_position(tree2, pos)

# Generated at 2022-06-22 03:07:28.710604
# Unit test for function get_definitions
def test_get_definitions():
    from test.test_jedi_utils import assert_equal


# Generated at 2022-06-22 03:07:40.011998
# Unit test for function parse_source
def test_parse_source():
    # This test reflects the current behaviour of `parse_source`
    # except for the last case where we don't return a leaf node
    # instead of `None`; this should be fixed later.
    from parso.python import tree
    source = """
        def a():
            pass

        def b():
            pass

        def c():
            pass

        def d():
            pass
        """

    root = parse_source(source)

    # outside of all definitions
    result = get_statement_of_position(root, (1,0)) # top-level statement
    assert isinstance(result, tree.ExprStmt)

    # at def a()
    result = get_statement_of_position(root, (2,9)) # funcdef
    assert isinstance(result, tree.Funcdef)

    # between two definitions

# Generated at 2022-06-22 03:07:51.576159
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def assert_node_at_pos(node, position, expected_node):
        assert get_statement_of_position(node, position) == expected_node

    # import
    source = """import foo, bar"""
    node = parse_source(source)
    assert_node_at_pos(node.children[0], node.children[0].children[0].start_pos, node.children[0])

    # import_from
    source = """from foo import bar"""
    node = parse_source(source)
    assert_node_at_pos(node.children[0], node.children[0].children[0].start_pos, node.children[0])

    # class
    source = """class Foo: pass"""
    node = parse_source(source)
    assert_node_at

# Generated at 2022-06-22 03:08:00.078606
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    class_attr = "Class"
    class_obj = jedi.classes.Class(
        jedi.Script(''),
        name=class_attr,
        start_pos=(0,0),
        end_pos=(1,1)
     )
    return ThonnyCompletion(
        name=class_attr,
        complete=class_attr,
        type="class",
        description=class_obj.get_doc(),
        parent=class_obj.get_parent_until(),
        full_name=class_obj.full_name,
    )

# Generated at 2022-06-22 03:08:30.076306
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert get_statement_of_position(parse_source("def f():\n    return True"), (2, 18))

    # in case of older jedi, this would raise AttributeError because it would
    # return None which has no children
    assert get_statement_of_position(parse_source("def f():"), (1, 5))



# Generated at 2022-06-22 03:08:35.593403
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree

    parse_tree = parse_source("print('Hi, there')")
    assert isinstance(parse_tree, parso.python.tree.Module)
    assert isinstance(parse_tree.children, tuple)
    assert isinstance(parse_tree.children[0], parso.python.tree.ExprStmt)

# Generated at 2022-06-22 03:08:45.994398
# Unit test for function parse_source
def test_parse_source():
    from parso.utils import parse_version
    from parso.grammar import PythonGrammar
    from parso.grammar import ELSE, NOT_TEST, COMPARISON
    import re

    grammar_version = parse_version(PythonGrammar.version)
    if grammar_version[0] >= 3:
        # Test for Python >= 3.8.0
        test_source = 'def f():\n    a = "a" if "b" else "c"\n    a = "a" if not "b" else "c"'
    else:
        # Test for Python <= 3.7.9
        test_source = 'def f():\n    a = "a" if "b" else "c"\n    a = "a" if "b" not else "c"'

    # Parse source
    parse

# Generated at 2022-06-22 03:08:47.166311
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

# Generated at 2022-06-22 03:08:49.572907
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree

    def _get_statement_of_position(node, pos):
        return get_statement_of_position(node, pos)


# Generated at 2022-06-22 03:08:54.626610
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    def parse(code):
        node = parso.parse(code)
        return [
            (get_statement_of_position(node, pos), desired_type)
            for pos, desired_type in [(1, None), (4, "classdef"), (10, "funcdef")]
        ]

    assert parse('class A: pass\nprint()') == [
        (None, None),
        (parso.parse('class A: pass\n')[0], "classdef"),
        (parso.parse('class A: pass\nprint()')[0], "funcdef"),
    ]

# Generated at 2022-06-22 03:09:04.116508
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion=ThonnyCompletion("name",
        "complete",
        "type",
        "descr",
        "parent",
        "full_name")
    assert completion.name=="name"
    assert completion.complete=="complete"
    assert completion.type=="type"
    assert completion.description=="descr"
    assert completion.parent=="parent"
    assert completion.full_name=="full_name"
    assert completion["name"]=="name"
    assert completion["complete"]=="complete"
    assert completion["type"]=="type"
    assert completion["description"]=="descr"
    assert completion["parent"]=="parent"
    assert completion["full_name"]=="full_name"
    assert completion["some_not_existent_key"]==None

# Generated at 2022-06-22 03:09:12.281841
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"x": 3}, {"y": 2}]
    source = "x.+y"
    assert get_interpreter_completions(source, namespaces, jedi.get_default_py_path()) == [
        ThonnyCompletion(
            name="add",
            complete="add",
            type="function",
            description="int.add($self, value, /)",
            parent="builtins.int",
            full_name="builtins.int.add",
        )
    ]

# Generated at 2022-06-22 03:09:24.007384
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import thonny

    import jedi

    if jedi.__version__[:4] == "0.11":
        print("Skipping test for jedi 0.11")
    elif jedi.__version__[:4] == "0.12":
        source = """
import datetime
datetime.datetime.now()
"""
        completions = get_interpreter_completions(
            source, [{"datetime": datetime}], sys_path=[thonny.__file__]
        )
        assert any(c.full_name == "datetime.datetime.now" for c in completions)
    else:
        source = """
import datetime
datetime.datetime.now()
"""

# Generated at 2022-06-22 03:09:35.146870
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi import __version__
    import parso

    # jedi==0.17.0
    if __version__ == '0.17.0':
        script = Script("", 1, 1, "/home/user/test.py", sys_path=['/home/user/foo','.'])
        completions = script.completions()
        assert len(completions) == 11 # the number of completions given

        script = Script("", 1, 1, "/home/user/test.py", sys_path=['.','/home/user/foo'])
        completions = script.completions()
        assert len(completions) == 11 # the number of completions given


# Generated at 2022-06-22 03:10:07.115657
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.__getitem__("name") == "name"
    assert c.__getitem__("complete") == "complete"
    assert c.__getitem__("type") == "type"
    assert c.__getitem__("description") == "description"
    assert c.__getitem__("parent") == "parent"
    assert c.__getitem__("full_name") == "full_name"

# Generated at 2022-06-22 03:10:08.363731
# Unit test for function parse_source

# Generated at 2022-06-22 03:10:15.435273
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import parso
    except:
        print("Cannot execute test_get_script_completions. parso is not installed")
        return

    print("Testing module: "+__name__)
    source= """def f(x, y, z=0):
    pass

f(12, 1"""
    completions = get_script_completions(source, 4, 8, "test.py")
    assert completions[0].name == "y="


# Generated at 2022-06-22 03:10:20.817928
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    d = {
        "name": "test_name",
        "complete": "test_complete",
        "type":"type",
        "description": "description",
        "parent": "parent",
        "full_name": "full_name",
    }
    testcomplete = ThonnyCompletion(**d)
    assert testcomplete.name=="test_name"
    assert testcomplete.complete=="test_complete"
    assert testcomplete.type=="type"
    assert testcomplete.description=="description"
    assert testcomplete.parent=="parent"
    assert testcomplete.full_name=="full_name"

# Generated at 2022-06-22 03:10:22.109742
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:10:25.535709
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("a", "ak", "b", "c", "d", "e").__dict__ == {"name": "a", "complete": "ak", "type": "b", "description": "c", "parent": "d", "full_name": "e"}



# Generated at 2022-06-22 03:10:35.738740
# Unit test for function get_definitions
def test_get_definitions():
    try:
        import parso
    except ImportError:
        return
    import os
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "test_files"))
    from test_files.module import Module
    from test_files.module import OtherClass
    from test_files.module import Class
    from test_files.module import function, function_with_args
    from test_files.module import CONST, CONST2

    defs = get_definitions(
        "from test_files.module import CONST, CONST2\n"
        "OtherClass().method()\nCONST2.CONST3\nfunction_with_args(1)[0]",
        3,
        0,
        __file__,
    )

    assert len