

# Generated at 2022-06-22 03:00:47.246047
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from collections import namedtuple
    from unittest import TestCase

    FakeJediCompletion = namedtuple(
        "FakeJediCompletion",
        ["name", "complete", "type", "description", "parent", "full_name"],
    )
    completion = ThonnyCompletion(
        "name", "complete", "type", "description", "parent", "full_name"
    )
    fake_completion = FakeJediCompletion(
        "name", "complete", "type", "description", "parent", "full_name"
    )

    class TestCompletion(TestCase):
        def test_completion(self):
            self.assertEqual(completion.name, fake_completion.name)
            self.assertEqual(completion.complete, fake_completion.complete)

# Generated at 2022-06-22 03:01:00.992660
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..')))
    import unittest
    import jedi
    import jedi.api
    from thonny.jedi_utils import get_interpreter_completions
    from thonny.jedi_utils import ThonnyCompletion
    from pprint import pprint
    import thonny
    import io
    import re

    def get_correct_completion(completions, pattern):
        for completion in completions:
            if re.match(pattern + "$", completion.complete):
                return completion
        return None


# Generated at 2022-06-22 03:01:05.522998
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
from tk
from tkinter import filedialog
from tkinter.filedialog import askopenfilename
from pprint import p"""
    completions = get_script_completions(source, row=3, column=5)
    assert len(completions) == 4
    assert completions[0].name == "filedialog"



# Generated at 2022-06-22 03:01:16.368204
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys

    from _test.testing_tools import modified_module_import

    with modified_module_import("jedi", _get_sys_path_for_test=lambda: sys.path):
        from jedi import Interpreter
        from jedi.api import classes
        import jedi.api.classes as classes

        object_namespace = [
            {"name": "__builtins__", "value": {"__doc__": None, "object": object}}
        ]

        i = Interpreter("object", object_namespace)
        completions = i.completions()
        expected = [
            classes.Completion("mro", "mro", "function", full_name="mro", classes=classes),
        ]
        assert completions == expected



# Generated at 2022-06-22 03:01:23.843060
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("import sys", 0, 0, None)) == 1
    assert len(get_definitions("sys.argv", 0, 0, None)) == 1
    assert len(get_definitions("def foo():pass\nfoo", 1, 0, None)) == 1
    assert len(get_definitions("class Foo:\n    pass\nFoo", 2, 0, None)) == 1
    assert len(get_definitions("import numpy\nnumpy.argv", 1, 0, None)) == 1

# Generated at 2022-06-22 03:01:27.375832
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    script = jedi.Script("import os; os.path.join()", 3, 7, "test.py")
    definitions = script.goto_definitions()
    print("Got definitions: " + definitions)


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-22 03:01:39.284356
# Unit test for function parse_source
def test_parse_source():
    import parso
    import six

    def _equal(a, b):
        if isinstance(a, six.string_types):
            return a == b
        if isinstance(a, parso.tree.BaseNode):
            return a.__dict__ == b.__dict__
        raise NotImplementedError(type(a))

    def _check_parse_source(source):
        node = parse_source(source)
        source = source.encode("utf-8")
        ast = parso.parse(source, version="3.7")
        assert _equal(node.get_code(), ast.get_code())

    _check_parse_source("def test(): pass")
    _check_parse_source("\"\"\"abc\"\"\"")
    _check_parse_source("'''abc'''")
   

# Generated at 2022-06-22 03:01:46.094941
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.utils import split_lines

    source = """def f():
    pass
    pass"""
    
    node = parse_source(source)
    
    from jedi.parser_utils import get_statement_of_position
    
    stmt = get_statement_of_position(node, len(source)+1)
    assert isinstance(stmt, tree.ExprStmt)
    assert stmt.get_code() == "pass"

# Generated at 2022-06-22 03:01:56.234238
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions("", 0, 0, "")
    get_definitions("class A: ...", 1, 0, "")
    get_definitions("def f(): ...", 1, 0, "")
    get_definitions("def f(a): ...", 1, 0, "")
    get_definitions("def f(a, b): ...", 1, 0, "")
    get_definitions("def f(a, b=1): ...", 1, 0, "")
    get_definitions("def f(a, b=1, c=None): ...", 1, 0, "")
    get_definitions("def f(a, b=1, c=None, *, d=1): ...", 1, 0, "")

# Generated at 2022-06-22 03:02:04.545496
# Unit test for function get_script_completions
def test_get_script_completions():
    """Unit test for function get_script_completions"""

    def check_result(result, expected_names):
        assert len(result) == len(expected_names)
        assert set(map(lambda item: item.name, result)) == set(expected_names)

    # Check completions in a single line
    source = "import sys\nprint(sy"
    completions = get_script_completions(source, 1, 11, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"

    if _using_older_jedi(jedi):
        # Check completions in multiple lines
        source = "import sys\nprint(sy\n"
        completions = get_script_completions(source, 2, 1, "")

# Generated at 2022-06-22 03:02:23.850122
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import random
    import string
    
    random.seed(1234)
    random_letters = (
        ''.join(random.choices(string.ascii_letters, k=random.randint(3, 50)))
        for _ in range(10)
    )
    namespaces = [{"namespace": letter} for letter in random_letters]

    completions = get_interpreter_completions("""\
import datetime
datetime.print_function""", namespaces)

    assert len(completions) > 0
    assert len([c for c in completions if c.name == "datetime"]) > 0

# Generated at 2022-06-22 03:02:25.940759
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:02:27.764741
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python


# Generated at 2022-06-22 03:02:28.741488
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso


# Generated at 2022-06-22 03:02:38.086207
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser import tree
    from jedi.parser_utils import get_statement_of_position
    from jedi.evaluate.base_context import ContextWrapper
    from jedi.evaluate.helpers import _call_of_leaf

    source = """import re"""
    row = 1
    column = 20
    namespace = {}
    interpreter = Interpreter(source, namespace)

    def completions(self):
        leaf = self.get_leaf(self.position, include_assignment=True)
        if leaf.type in ('name', 'keyword'):
            context, name = ContextWrapper._get_context_of_position(leaf.start_pos)

# Generated at 2022-06-22 03:02:50.189649
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.settings import cache_directory
    import os
    import shutil
    import jedi

    jedi.settings.cache_directory = cache_directory


# Generated at 2022-06-22 03:02:55.857766
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import math\nmath.pi"
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    completions = [c.complete for c in completions]
    assert set(completions) == {"math.pi"}



# Generated at 2022-06-22 03:03:07.883490
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import thonnycontrib.jediutils

    # Test with jedi version < 0.17
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]:
        filename = "test_jedi_utils.py"
        source = """def foo(a):\n    return a"""
        definitions = thonnycontrib.jediutils.get_definitions(source, 2, 16, filename)
        assert definitions
        assert definitions[0].line == 1

    # Test with jedi version >= 0.17
    if jedi.__version__[:4] in ["0.17", "0.18"]:
        filename = "test_jedi_utils.py"

# Generated at 2022-06-22 03:03:18.802071
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    class DummyType2(object):
        name = "dummy"
        module_name = "dummy"
        is_compiled = False
        line = 1
        column = 1
        doc = "dummy"
        description = "dummy"
        obj = "dummy"
        py__call__ = Mock(return_value=None)
        start_pos = (1, 1)
        end_pos = (1, 1)
        is_keyword = False
        parent = None

    dummy_completion = DummyType2()

    # Full name missing
    dummy_completion.name = "dummy"
    dummy_completion.full_name = None
    dummy_completion.parent = None

# Generated at 2022-06-22 03:03:28.208640
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions('print(3)', 0, 6, "")
    assert len(defs) == 1
    assert defs[0].name == 'print'
    assert defs[0].full_name == 'builtins.print'
    
    
    defs = get_definitions('import statistics', 0, 7, "")
    assert len(defs) == 1
    assert defs[0].name == 'statistics'
    assert defs[0].full_name == 'statistics'
    assert defs[0].type == 'module'
    
    defs = get_definitions('print(statistics.', 0, 17, "")
    assert len(defs) > 20

# Generated at 2022-06-22 03:03:48.415356
# Unit test for function parse_source
def test_parse_source():
    source = "import sys;print(sys.version)"
    module = parse_source(source)
    first_stmt = module.children[0]
    assert first_stmt.type == "import_from"

# Generated at 2022-06-22 03:03:49.669763
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:03:57.022081
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from thonny import get_workbench

    get_workbench().create_test_window(globals())

    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:04:07.543698
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os

    sys_path = [os.path.expanduser('~/test')]
    source = "from cmath import phase; phase()"
    row, column = 1, 18
    filename = '<console>'

    if _using_older_jedi(jedi):
        try:
            script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            script = jedi.Script(source, row, column, filename)

        completions = script.completions()
    else:
        script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))


# Generated at 2022-06-22 03:04:19.117142
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import jedi

        if jedi.__version__.startswith("0.13"):
            # jedi 0.13.0 is not working with Python 3.8, multiple instances of
            # internal errors (see https://github.com/davidhalter/jedi/issues/1745)
            return

        script = "import math\nmath.sqrt("
        completions = get_script_completions(script, 2, len("math.sqrt("), "test.py")
        assert len(completions) > 0
        assert any("sqrt(" in x.complete for x in completions)
        assert any("sqrt" in x.name for x in completions)
        assert any("sqrt=" in x.name for x in completions)
    except ImportError:
        pass

# Generated at 2022-06-22 03:04:22.418721
# Unit test for function parse_source
def test_parse_source():
    res = parse_source("print('hello')")
    assert res.get_code() == "print('hello')"

# Generated at 2022-06-22 03:04:25.109380
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    test_code = "a = ':'\n"
    result = parse_source(test_code)
    assert isinstance(result, Module)

# Generated at 2022-06-22 03:04:37.053864
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:04:43.612020
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    if not _using_older_jedi(jedi):
        script = jedi.Script("import csv", 1, 8)
        completions = script.complete()
        #Testing constructor of class ThonnyCompletion
        for i, comp in enumerate(completions):
            assert ThonnyCompletion(comp.name, comp.complete, comp.type, comp.description, comp.parent, comp.full_name).__dict__ == comp.__dict__

# Generated at 2022-06-22 03:04:45.888441
# Unit test for function get_script_completions
def test_get_script_completions():
    assert "len(" in get_script_completions(source="", row=0, column=0, filename="foo")[0].complete


# Generated at 2022-06-22 03:05:30.529776
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions(
        "import os\nimport sys\nos.getcw", 0, len("import os\nimport sys\nos.getc"), "x.py"
    )
    assert len(defs) == 1
    assert defs[0].module_name == "os"
    assert defs[0].in_builtin_module()


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-22 03:05:43.380044
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position
    import jedi

    for jedi_version in ["0.13", "0.14", "0.15", "0.16", "0.17", "0.18", "0.19", "0.20"]:
        jedi.__version__ = jedi_version
        completions = get_script_completions("'".center(50) + "1", 1, 51)
        assert completions == [ThonnyCompletion("replace", "replace", "method", "", "str", "str.replace")]
        completions = get_script_completions("''.center(50)".center(50) + "1", 1, 51)

# Generated at 2022-06-22 03:05:47.887633
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    from _tokenize import TokenInfo
    from parso.python.token import PythonTokenTypes as ptok
    from parso.parser.token import DICT
    from parso.parser import ParserSyntaxError
    import parso.tree as parso_tree
    import parso


# Generated at 2022-06-22 03:05:51.269825
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
   ThonnyCompletion(
       name="name",
       complete="complete",
       type="type",
       description="description",
       parent="parent",
       full_name="full_name",
   )

# Generated at 2022-06-22 03:05:57.853256
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert x.name == x["name"]
    assert x.complete == x["complete"]
    assert x.type == x["type"]
    assert x.description == x["description"]
    assert x.parent == x["parent"]
    assert x.full_name == x["full_name"]
    return

# Generated at 2022-06-22 03:05:59.667922
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("print(", [{}])[0].name == "print"

# Generated at 2022-06-22 03:06:07.386706
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

    source = """
import math

foo = math.c"""

    file = "dummy.py"
    node = jedi.api.environment.get_default_environment().preload_module("math")
    pos = (3, 5)
    statement = get_statement_of_position(node, pos)

    assert statement.start_pos == (3, 4)
    assert statement.end_pos == (3, 8)


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-22 03:06:18.129427
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import mock

    obj = ThonnyCompletion(
        name='a',
        complete='b',
        type='c',
        description='d',
        parent='e',
        full_name='f',
    )
    assert obj['name'] == 'a'
    assert obj['complete'] == 'b'
    assert obj['type'] == 'c'
    assert obj['description'] == 'd'
    assert obj['parent'] == 'e'
    assert obj['full_name'] == 'f'
    with mock.patch('builtins.print') as mock_print:
        obj['something_else']
    assert mock_print.called

test_ThonnyCompletion___getitem__()

# Generated at 2022-06-22 03:06:29.980914
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

    m = jedi.Script("a=b;c=d;e=f;").goto_definitions()[0].module
    assert m.get_statement_of_position((1, 4)) == m.get_node_at_pos((1, 4))
    assert m.get_statement_of_position((1, 5)) == m.get_node_at_pos((1, 5))
    assert m.get_statement_of_position((1, 6)) == m.get_statement_of_position((1, 5))
    assert m.get_statement_of_position((1, 10)) == m.get_node_at_pos((1, 10))
    assert m.get_statement_of_position((1, 11)) == m.get_statement_of_position((1, 10))

# Generated at 2022-06-22 03:06:33.089210
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions("import sys\nprint(sys.getdefaultencoding)", row=0, column=0, filename="")



# Generated at 2022-06-22 03:07:22.022781
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate.sys_path import add_sys_path
    from jedi import Interpreter
    from parso.python.tree import Leaf

    add_sys_path("/home/david/.thonny/venv/lib/python3.8/site-packages")
    module_path = "/home/david/.thonny/venv/lib/python3.8/site-packages/pandas/core/base.py"
    interpreter = Interpreter("from pandas.core.base import *", [])
    definitions = interpreter.goto_definitions()
    assert _get_line(definitions[0].tree_node) == 12
    assert definitions[0].tree_node.start_pos == (
        module_path,
        12,
        0,
    )

# Generated at 2022-06-22 03:07:33.594131
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    from parso.utils import split_lines
    assert isinstance(parse_source('x = "abc"'), Module)
    assert isinstance(parse_source(split_lines('x = "abc"')), Module)
    assert isinstance(parse_source(split_lines('x = "abc"'), version='3.7'), Module)
    assert isinstance(parse_source(split_lines('x = "abc"'), version=(3, 7)), Module)
    assert isinstance(parse_source(split_lines('x = "abc"'), version=(3, 7, 0)), Module)
    assert isinstance(parse_source(split_lines('x = "abc"'), version=(3, 7, 0, '', '')), Module)

# Generated at 2022-06-22 03:07:36.412824
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

# Generated at 2022-06-22 03:07:43.625309
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def test_return_none(source, pos):
        node = parse_source(source)
        statement = get_statement_of_position(node, pos)
        assert statement is None

    source = "x = 1\n"
    node = parse_source(source)

    # First char of first line
    statement = get_statement_of_position(node, (1, 1))
    assert statement.start_pos == (1, 1)  # statement is x = 1

    # Inside first line
    statement = get_statement_of_position(node, (1, 2))
    assert statement.start_pos == (1, 1)  # statement is x = 1

    # Last char of first line
    statement = get_statement_of_position(node, (1, 5))

# Generated at 2022-06-22 03:07:50.347294
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    expected = "test"
    kwargs = {
        'name': expected,
        'complete': expected,
        'type': expected,
        'description': expected,
        'parent': expected,
        'full_name': expected
    }
    test = ThonnyCompletion(**kwargs)
    assert test.name == expected
    assert test.complete == expected
    assert test.type == expected
    assert test.description == expected
    assert test.parent == expected
    assert test.full_name == expected

# Generated at 2022-06-22 03:07:59.382949
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    completion = jedi.Script(source="import os; os.sep").completions()[0]

    my_completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

    assert my_completion.name == "sep"
    assert my_completion.complete == "os.sep"

# Generated at 2022-06-22 03:08:01.527934
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    from parso import parse

    code = "foo()"
    result = parse_source(code)
    assert isinstance(result, tree.Module)

# Generated at 2022-06-22 03:08:03.134472
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script, Interpreter
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-22 03:08:05.033417
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(name=None, complete=None, type=None, description=None, parent=None,full_name=None)

# Generated at 2022-06-22 03:08:10.499076
# Unit test for function parse_source
def test_parse_source():
    source = textwrap.dedent('''\
        def test():
            x = 1
            y = 2
            return x + y
        ''')

    module = parse_source(source)

    assert isinstance(module, parso.python.tree.Module)
    print(module)



# Generated at 2022-06-22 03:08:56.856361
# Unit test for function parse_source
def test_parse_source():
    import parso
    import jedi.parser_utils
    def get_node_type(node, pos):
        func = getattr(
            jedi.parser_utils, "get_statement_of_position", _copy_of_get_statement_of_position
        )
        return func(node, pos).type

    source = "def foo(x, y):\n  a = x + y"
    row = 2
    column = 7
    parsed = parse_source(source)
    parsed_source = parso.dump_tree(parsed)

# Generated at 2022-06-22 03:09:05.143859
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_parent_scope
    
    valid_input = [
        (0, 0, (0, 0)),
        (0, 1, (0, 0)),
        (0, 3, (0, 0)),
        (1, 0, (1, 0)),
        (1, 1, (1, 0)),
        (1, 3, (1, 0)),
        (2, 0, (2, 0)),
        (2, 1, (2, 0)),
        (2, 3, (2, 0)),
    ]
    
    source_code = """\
x = 0
y = 1
z = 2
"""
    
    root_node = parse_source(source_code)
    for line_col, expected_result in valid_input:
        line, col = line_col


# Generated at 2022-06-22 03:09:10.699707
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    text = "import sys"
    sys_path = sys.path
    completions = get_interpreter_completions(text, namespaces=[{"__name__": "__main__"}], sys_path=sys_path)
    assert any(c.name == "sys" for c in completions)

# Generated at 2022-06-22 03:09:20.729495
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    completions = get_script_completions("import sys\nsys.", 4, 5, "test.py")
    assert [c.name for c in completions] == ["sys"]

    completions = get_script_completions("import sys\nsys.", 4, 6, "test.py")
    assert [c.name for c in completions] == ["sys"]

    completions = get_script_completions("import sys\nsys.", 4, 7, "test.py")
    assert [c.name for c in completions] == ["path"]

# Generated at 2022-06-22 03:09:30.569383
# Unit test for function parse_source
def test_parse_source():
    src = "x = 5 + 6"
    node = parse_source(src)
    assert node.type == "file_input" and len(node.children) == 1
    stmt = node.children[0]
    assert stmt.type == "expr_stmt" and len(stmt.children) == 3
    assert stmt.children[0].type == "name" and stmt.children[0].value == "x"
    assert stmt.children[1].type == "operator" and stmt.children[1].value == "="
    assert stmt.children[2].type == "arithmetic" and len(stmt.children[2].children) == 3
    assert stmt.children[2].children[0].type == "number"
    assert stmt.children[2].children[1].type == "operator"

# Generated at 2022-06-22 03:09:39.995693
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    source = 'class C:\n    def __init__(self, x):\n        self.x = x\n\nC(2).x'
    namespaces = [Interpreter('x', []).namespace]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == 'x'
    assert completions[0].type == 'instance'
    assert completions[0].complete == 'x'
    assert completions[0].description == 'no description'
    assert completions[0].parent == 'C'
    assert completions[0].full_name == 'C.x'

# Generated at 2022-06-22 03:09:45.972116
# Unit test for function get_definitions
def test_get_definitions():
    import unittest


# Generated at 2022-06-22 03:09:53.112324
# Unit test for function parse_source
def test_parse_source():
    import os
    import sys
    
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.py')
    with open(script_path) as f:
        script_source = f.read()
    
    try:
        import parso
        script_parse = parse_source(script_source)
        assert isinstance(script_parse, parso.python.tree.Module)
    except ImportError:
        logger.warning('Cannot import parso, skippping test_parse_source')

# Generated at 2022-06-22 03:09:58.638617
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"


# Generated at 2022-06-22 03:10:04.168742
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import patch

    # with patch.object(sys, 'path', [""]):
    #     completions = get_interpreter_completions("print", [{}], sys_path=[""])
    #     assert completions

    with patch.object(sys, "path", []):
        completions = get_interpreter_completions("print", [{}], sys_path=[])
        assert completions

