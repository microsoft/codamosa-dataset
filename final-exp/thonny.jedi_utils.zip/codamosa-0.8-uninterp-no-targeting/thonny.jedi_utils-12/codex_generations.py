

# Generated at 2022-06-22 03:00:27.418055
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """import sys\n"""
    completions = get_script_completions(source, 1, 5, "test.py")
    assert len(completions) == 1
    assert completions[0].complete == "sys"
    assert completions[0].name == "sys"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-22 03:00:38.899209
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils


# Generated at 2022-06-22 03:00:49.460161
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert get_interpreter_completions(
        "import sys; sys.", [{}], sys_path=["C:\\Python"]
    )[-1].name == "path"
    assert get_interpreter_completions(
        "import sys; sys.", [{}], sys_path=["C:\\Python"]
    )[-1].complete == "path"
    assert get_interpreter_completions(
        "import sys; sys.", [{}], sys_path=["C:\\Python"]
    )[-1].type == "module"
    assert get_interpreter_completions(
        "import sys; sys.", [{}], sys_path=["C:\\Python"]
    )[-1].description == "sys : module"
    assert get_

# Generated at 2022-06-22 03:01:00.404612
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import sys

    if len(sys.argv) != 2:
        raise Exception("Usage: test_get_script_completions.py <target python version>")

    target_major_version = int(sys.argv[1])
    target_minor_version = 0

    if target_major_version == 3:
        target_minor_version = 6

    code = "import sys, os"

    script = Script(code, 3, 3)

    completions = get_script_completions(code, 3, 3, None)
    print(len(completions))

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-22 03:01:03.993825
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if jedi.__version__ < "0.18":
        raise unittest.SkipTest("No test for this jedi version")


# Generated at 2022-06-22 03:01:14.105851
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os

    def run_test(code, expected):
        original = sys.path[:]


# Generated at 2022-06-22 03:01:23.476709
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    code = "def foo():\n    pass"
    node = parso.parse(code)
    assert get_statement_of_position(node, 0) is None
    assert get_statement_of_position(node, len("def foo()")).type == "funcdef"
    assert get_statement_of_position(node, len("def foo():")) is not None
    assert get_statement_of_position(node, len("def foo():\n")).type == "simple_stmt"



# Generated at 2022-06-22 03:01:34.063135
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            # Find the first definition in a document
            self.assertEqual(
                [x.name for x in get_definitions("import os", 1, 1, "<string>")], ["os"]
            )
            # Find the second definition in a document
            self.assertEqual(
                [x.name for x in get_definitions("import os; import sys", 1, 1, "<string>")],
                ["os", "sys"],
            )
            # Find the first definition on a line
            self.assertEqual(
                [x.name for x in get_definitions("import os; import sys", 1, 10, "<string>")],
                ["os"],
            )
            # Find the first definition on a line
           

# Generated at 2022-06-22 03:01:41.857172
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    def use_function_under_test(root_node, pos):
        return get_statement_of_position(root_node, pos)

    test_root_node = parse_source(
        """def f():
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
"""
    )
    test_root_node_old = test_root_node.get_first_leaf()
    assert use_function_under_test(test_root_node_old, (1, 0)) == test_root_node_old

    test_root_node_new = test_root_node.get_first_leaf().get_next_leaf()


# Generated at 2022-06-22 03:01:47.606898
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    dummy_completion = ThonnyCompletion('name','complete','type','description','parent','full_name')
    assert dummy_completion['name'] == 'name'
    assert dummy_completion['complete'] == 'complete'
    assert dummy_completion['type'] == 'type'
    assert dummy_completion['description'] == 'description'
    assert dummy_completion['parent'] == 'parent'
    assert dummy_completion['full_name'] == 'full_name'

# Generated at 2022-06-22 03:02:02.817125
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'import os\nfrom os import\nos'

# Generated at 2022-06-22 03:02:12.564895
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    dictionary = {"name": "name", "complete": "complete", "type": "type", "description": "description", "parent": "parent", "full_name": "full_name"}
    comp = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"
    assert comp.__dict__ == dictionary

# Generated at 2022-06-22 03:02:17.591281
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__

    def test_func():
        return [1, 2, 3]

    source = 'test_func()[0].i'
    completions = get_script_completions(
        source,
        len(source) - 1,
        __version__,
        filename="test.py",
        sys_path=["/tmp"],
    )
    assert len(completions) > 1
    assert any(c.name == "imag" for c in completions)



# Generated at 2022-06-22 03:02:20.300911
# Unit test for function parse_source
def test_parse_source():
    import jedi.parser_utils
    # verify that we don't get a MemoryError for huge files
    source = "a=1\n"*1000000
    # call function under test
    parse_source(source)

# Generated at 2022-06-22 03:02:28.900670
# Unit test for function get_definitions
def test_get_definitions():
    print("Testing get_definitions(str,int,int,str)")
    src = """import os\nimport sys\n\nx = os.path.join(sys.argv[0], 'foo')"""
    definitions = get_definitions(src, 2, 7, __file__)
    assert len(definitions) == 1
    assert definitions[0].line == 3
    assert definitions[0].column == 4
    assert definitions[0].module_path == module_path_of_module("os.path")

# Generated at 2022-06-22 03:02:32.176343
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_utils import assert_in_output, set_testing_mode
    set_testing_mode(True)

# Generated at 2022-06-22 03:02:38.086064
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    x = ThonnyCompletion(name="Test", complete="a.b.Test", type="module", description="b.py", parent="b", full_name="a.b.Test")
    assert x["name"] == "Test"
    assert x["complete"] == "a.b.Test"
    assert x["type"] == "module"
    assert x["description"] == "b.py"
    assert x["parent"] == "b"
    assert x["full_name"] == "a.b.Test"

# Generated at 2022-06-22 03:02:50.189790
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script("import re")
        completions = script.completions()
    else:
        script = jedi.Script("import re")
        completions = script.complete(line=0, column=7)
    
    completion = completions[0]
    testObj = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name
    )

    assert completion.name == testObj.name
    assert completion.complete == testObj.complete
    assert completion.type == testObj.type

# Generated at 2022-06-22 03:02:58.697297
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test 1
    source = "import tensorflow as tf"
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)
    assert "tf" in list(c.name for c in completions)

    # Test 2
    source = "x = "
    namespaces = [{"y": [1, 2, 3]}]
    completions = get_interpreter_completions(source, namespaces)
    assert ["y"] == list(c.name for c in completions)

# Generated at 2022-06-22 03:03:11.323233
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("import os", 0, 0, "test.py") == []
    assert get_definitions("import os; os.path", 0, 0, "test.py") == []
    assert get_definitions("import os; os.path.abspath", 0, 0, "test.py") == []
    assert get_definitions("import os; os.path.abspath(", 0, 0, "test.py") == []
    assert get_definitions("import os; os.path.abspath(x", 0, 0, "test.py") == []

    assert len(get_definitions("import os; os.path.abspath()", 0, 0, "test.py")) == 1

    from jedi.api.classes import Definition

# Generated at 2022-06-22 03:06:14.598753
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    result = get_definitions('a = [2, 3, 4]\nprint(a[0])', 2, 7, "example.py")
    assert len(result) == 1
    assert result[0].type == "list"
    assert result[0].line == 1
    assert result[0].column == 3
    assert result[0].module_name == "example.py"

    result = get_definitions('from math import sin, cos\nsin(0)', 2, 5, "example.py")
    assert len(result) == 1
    assert result[0].type == 'function'
    assert result[0].line == 1
    assert result[0].column == 13
    assert result[0].module_name == "math"


# Generated at 2022-06-22 03:06:21.311860
# Unit test for function parse_source
def test_parse_source():
    source = "import re\nre."
    module = parse_source(source)
    assert len(module.children) == 2, "There should be two children of the module: import, re."
    assert module.children[1].type == "dotted_name", "The second child should be a dotted_name."
    assert module.children[1].get_code() == "re"
    assert module.children[1].start_pos == (3, 0)
    assert module.children[1].end_pos == (4, -1)

# Generated at 2022-06-22 03:06:31.741378
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    from thonny import get_workbench, running

    running.clear_platform()
    _get_interpreter_completions = get_workbench().get_variable_completions

    # test print()
    namespaces = [{}]
    completions = _get_interpreter_completions("print(", namespaces)
    assert len(completions) == 1
    assert completions[0].description == "print(value, ..., sep=' ', end='\\n', file=sys.stdout)"

    namespaces = [{"print": print}]
    completions = _get_interpreter_completions("print(", namespaces)
    assert len(completions) == 1

# Generated at 2022-06-22 03:06:34.504365
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    import parso
    from parso.python.tree import Module, Function
    
    # normal case

# Generated at 2022-06-22 03:06:36.294705
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    ThonnyCompletion.__getitem__('name')

# Generated at 2022-06-22 03:06:40.949900
# Unit test for function parse_source
def test_parse_source():
    import jedi

    try:
        # Some newer versions of jedi don't have a unit test
        # for parse_source (since it has always been public).
        jedi.test.test_parser.test_parse_source()
    except AttributeError:
        logger.debug("No unittest for parse_source in this version of jedi")

# Generated at 2022-06-22 03:06:47.719218
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.environment import get_cached_default_environment_set

    env_set = get_cached_default_environment_set()
    interpreter = env_set.create_interpreter()

    completions = get_interpreter_completions("int", [], sys_path=[])

    assert len(completions) > 10
    assert "abstractmethod" in [c.name for c in completions]
    assert "int" in [c.name for c in completions]



# Generated at 2022-06-22 03:06:56.102793
# Unit test for function get_definitions
def test_get_definitions():
    script = "class A:\n    def f(self, x):\n        print(x)"
    definitions = get_definitions(script, 2, 0, filename="")
    assert len(definitions) == 1
    assert definitions[0].description == "def f(self, x)"
    assert definitions[0].type == "function"
    assert definitions[0].full_name == "A.f"

    definitions = get_definitions(script, 2, 12, filename="")
    assert len(definitions) == 1
    assert definitions[0].line == 0
    assert definitions[0].column == 4
    assert definitions[0].description == "Class A"
    assert definitions[0].type == "class"



# Generated at 2022-06-22 03:07:06.588731
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import parso

    def check_result(source, row, col, exp_row, exp_col):
        assert get_definitions(source, row, col, "") == [
            parso.python.tree.Leaf(
                type="name", value="name", parent=None, start_pos=(exp_row, exp_col), end_pos=None
            )
        ]

    # case 1: definition of two variables on the same line
    check_result(
        "a = 8\nb = 5\na", 2, 0, 0, 0
    )  # TAB is not considered as symbol in jedi

    # case 2: definition of two variables on the different line
    check_result(
        "a = 8\n\nb = 5\na", 3, 0, 0, 0
    )  # T

# Generated at 2022-06-22 03:07:09.082148
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.tree import Leaf

    decorated_function = """@deco
    def f():
        pass
"""

# Generated at 2022-06-22 03:07:20.388705
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('import os.path')


# Generated at 2022-06-22 03:07:28.918849
# Unit test for function parse_source
def test_parse_source():
    names = ["module", "statement", "class", "funcdef", "async_funcdef", "decorators"]
    try:
        import parso
    except:  # noqa
        print(
            "Testing parse_source requires dependency 'parso', please install it with:"
        )
        print("\tpip install parso")
    else:
        for name in names:
            with open("test_data/{}.py".format(name)) as f:
                source = f.read()
            parse_source(source)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:07:38.364310
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name="name1", complete="complete1", type="type1", description="description1", parent="parent1", full_name="full_name1")
    assert completion.__getitem__("name") == "name1"
    assert completion.__getitem__("complete") == "complete1"
    assert completion.__getitem__("type") == "type1"
    assert completion.__getitem__("description") == "description1"
    assert completion.__getitem__("parent") == "parent1"
    assert completion.__getitem__("full_name") == "full_name1"

# Generated at 2022-06-22 03:07:44.573720
# Unit test for function get_definitions
def test_get_definitions():
    # jedi <= 0.17
    print(get_definitions('x = range(1)\nx', 1, 5, 'test.py'))
    # jedi >= 0.18
    print(get_definitions('x = range(1)\nx', 2, 0, 'test.py'))

# Generated at 2022-06-22 03:07:53.232151
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert isinstance(comp, ThonnyCompletion)
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-22 03:08:03.657660
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
# variable is not defined
a = x

# variable exists
y = 5

# variable name is a part of a word
zzzz = 5
"""
    from jedi import Interpreter

    namespaces = [
        {
            "y": 5,
            "zzzz": 5,
            "interpreter_test_completion": "test_get_interpreter_completions",
        }
    ]
    interpreter = Interpreter(source, namespaces)
    completions = _tweak_completions(interpreter.complete())
    assert len(completions) == 1
    assert completions[0]["name"] == "x"
    assert completions[0]["complete"] == "x"

    interpreter = Interpreter(source.replace("z",""), namespaces)
    comple

# Generated at 2022-06-22 03:08:15.341335
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as pytree

    tree = pytree.Module(0, 0)
    a = pytree.SimpleStatement(0, 0, [pytree.ExprStmt(0, 0, [pytree.Leaf(0, 0, "a")])])
    b = pytree.SimpleStatement(0, 0, [pytree.ExprStmt(0, 0, [pytree.Leaf(0, 0, "b")])])
    a.end_pos = (1, 0)
    b.end_pos = (2, 0)
    tree.children = [a, b]
    assert get_statement_of_position(tree, (0, 0)) is a
    assert get_statement_of_position(tree, (0, 1)) is a

# Generated at 2022-06-22 03:08:19.983758
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 1, 'description', 'parent', 'full_name')
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 1
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'


# Generated at 2022-06-22 03:08:31.096704
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "test"
    complete = "test"
    type = "T"
    description = "Test description"
    parent = "Test parent"
    full_name = "Test full_name"
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).name == name
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).complete == complete
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).type == type
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).description == description
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).parent == parent

# Generated at 2022-06-22 03:08:37.548972
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    assert tc.__getitem__("name") == "a"
    assert tc.__getitem__("complete") == "b"
    assert tc.__getitem__("type") == "c"
    assert tc.__getitem__("description") == "d"
    assert tc.__getitem__("parent") == "e"
    assert tc.__getitem__("full_name") == "f"

# Generated at 2022-06-22 03:09:09.305436
# Unit test for function get_definitions

# Generated at 2022-06-22 03:09:13.552204
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion1["name"] == "name"
    assert completion1["complete"] == "complete"
    assert completion1["type"] == "type"
    assert completion1["description"] == "description"
    assert completion1["parent"] == "parent"
    assert completion1["full_name"] == "full_name"

# Generated at 2022-06-22 03:09:22.389697
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    from jedi.api.classes import Source

    class Test(TestCase):
        def test_case_0(self):
            source = "import sys"
            row = 0
            col = 0
            filename = "<string>"
            definitions = get_definitions(source, row, col, filename)
            self.assertTrue(definitions)
            self.assertIsInstance(definitions[0], Source)
            self.assertTrue(isinstance(definitions[0].description, str))

    t = Test()
    t.test_case_0()

# Generated at 2022-06-22 03:09:27.448675
# Unit test for function parse_source
def test_parse_source():
    source = "def a(b, c):\n    pass\n"
    node_list = parse_source(source)
    param_node_list = []
    for node in node_list.children:
        if type(node) == parso.python.tree.Param:
            param_node_list.append(node)
    assert len(param_node_list) == 2, "param_node_list is not 2"

# Generated at 2022-06-22 03:09:38.659797
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import Interpreter
    from jedi.api.classes import Script

    def is_same_completion(completionsA, completionsB):
        """ Compare two completions objects. 
        This is required because Jedi 0.17.0 changed the API of completions
        """

        if len(completionsA) != len(completionsB):
            return False

        for i in range(len(completionsA)):
            if completionsA[i].complete != completionsB[i].complete:
                return False
            if completionsA[i].description != completionsB[i].description:
                return False
            if completionsA[i].full_name != completionsB[i].full_name:
                return False

# Generated at 2022-06-22 03:09:47.612247
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_ThonnyCompletion = ThonnyCompletion("name", "complete", "type",
                                             "description", "parent", "full_name")

    assert test_ThonnyCompletion["name"] == "name"
    assert test_ThonnyCompletion["complete"] == "complete"
    assert test_ThonnyCompletion["type"] == "type"
    assert test_ThonnyCompletion["description"] == "description"
    assert test_ThonnyCompletion["parent"] == "parent"
    assert test_ThonnyCompletion["full_name"] == "full_name"

# Generated at 2022-06-22 03:09:50.650080
# Unit test for function get_definitions
def test_get_definitions():
    sys_path = r"C:\Users\tahmee2\AppData\Local\Programs\Python\Python36\Lib\site-packages\jedi\api"
    # put your source code here.

# Generated at 2022-06-22 03:10:02.033927
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print(get_interpreter_completions("", [], sys_path=[]))
    print(get_interpreter_completions("import math", [], sys_path=[]))
    print(get_interpreter_completions("math.", [], sys_path=[]))
    print(get_interpreter_completions("math.sin", [], sys_path=[]))
    print(get_interpreter_completions("math.sin(", [], sys_path=[]))
    print(get_interpreter_completions("math.sin()", [], sys_path=[]))
    print(get_interpreter_completions("math.sin(1", [], sys_path=[]))

# Generated at 2022-06-22 03:10:04.054678
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert tc.__getitem__('name') == 'name'

# Generated at 2022-06-22 03:10:15.595773
# Unit test for constructor of class ThonnyCompletion