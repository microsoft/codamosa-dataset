

# Generated at 2022-06-22 03:00:48.049971
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    def compare(expected, node, pos):
        result = jedi.parser_utils.get_statement_of_position(node, pos)
        if result != expected:
            print("Expected", expected)
            print("Returned", result)
            return False


# Generated at 2022-06-22 03:00:54.692235
# Unit test for function get_script_completions
def test_get_script_completions():
    # we are testing the function get_script_completions from utils/jedi_utils
    # this function is used to retrieve the autocompletion from jedi
    import utils.jedi_utils as jedi_utils

    # this is the code to parse

# Generated at 2022-06-22 03:01:04.390260
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    test_class = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_class.name == "name"
    assert test_class.complete == "complete"
    assert test_class.type == "type"
    assert test_class.description == "description"
    assert test_class.parent == "parent"
    assert test_class.full_name == "full_name"


# Generated at 2022-06-22 03:01:12.619785
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.tree import search_ancestor

    for jedi_version in ["0.15.4", "0.16.0", "0.17.0"]:
        print("Testing with jedi " + jedi_version)
        source = """
        def a():
            class A(object):
                def foo(self, arg):
                    return 5
        """
        node = parse_source(source)
        target = search_ancestor(node, "return_stmt")
        result = get_statement_of_position(node, target.start_pos)
        assert result == target

# Generated at 2022-06-22 03:01:13.344404
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-22 03:01:25.069215
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    tree = parso.parse("funcs = [f1, f2]")

    f1_node = tree.children[1].children[0].children[0]
    assert get_statement_of_position(tree, f1_node.start_pos) == f1_node
    assert get_statement_of_position(tree, f1_node.start_pos + 1) == f1_node

    f2_node = tree.children[1].children[0].children[2]
    assert get_statement_of_position(tree, f2_node.start_pos) == f2_node
    assert get_statement_of_position(tree, f2_node.start_pos + 1) == f2_node


# Generated at 2022-06-22 03:01:26.482682
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Function, Name


# Generated at 2022-06-22 03:01:28.269944
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["name"] == "name"

# Generated at 2022-06-22 03:01:39.830160
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    if tc.__getitem__("name") != tc.name:
        raise Exception("Error")
    if tc.__getitem__("complete") != tc.complete:
        raise Exception("Error")
    if tc.__getitem__("type") != tc.type:
        raise Exception("Error")
    if tc.__getitem__("description") != tc.description:
        raise Exception("Error")
    if tc.__getitem__("parent") != tc.parent:
        raise Exception("Error")

# Generated at 2022-06-22 03:01:50.279616
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf
    import unittest.mock
    leaf = Leaf(0, 0)
    leaf.start_pos = (1, 3)
    leaf.end_pos = (5, 7)

    with unittest.mock.patch('sys.version_info[0]', new = 3):
        assert get_statement_of_position(leaf, (1, 3)) == leaf
        assert get_statement_of_position(leaf, (2, 3)) == leaf
        assert get_statement_of_position(leaf, (4, 5)) == leaf
        assert get_statement_of_position(leaf, (5, 7)) == leaf
        with unittest.mock.patch('parso.python.tree.Flow.type', new = 'async_stmt'):
            assert get_statement

# Generated at 2022-06-22 03:01:58.035833
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:02:01.240061
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = '# This is just a small test\nimport parso\ndef f(x):\n    return x**2'
    assert parse_source(source) == parso.parse(source)

# Generated at 2022-06-22 03:02:13.363820
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    import parso

# Generated at 2022-06-22 03:02:23.062204
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # replace jedi.get__name__by_path
    jedi.get__name__by_path = lambda path: "test"

    completions = get_script_completions(
        "def f(x): return  x + 1\nf(", 1, 5, ""
    )  # cursor after f(
    assert len(completions) == 1
    assert completions[0].name == "x"
    assert completions[0].complete == "x"
    assert completions[0].description == "int"
    assert completions[0].parent == "test"
    assert completions[0].full_name == "f.x"
    assert completions[0].type == "param"


# Generated at 2022-06-22 03:02:29.488113
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("import sys")
    assert parse_source("import sys\n")
    assert parse_source("import sys\nimport x")
    assert parse_source("import sys\nimport x\n")
    assert parse_source("import sys\nimport x\nprint(x)")
    assert parse_source("import sys\nimport x\nprint(x)\n")

# Generated at 2022-06-22 03:02:36.162040
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    """
    >>> import parso
    >>> node = parso.parse("""

# Generated at 2022-06-22 03:02:47.405599
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    my_ThonnyCompletion = ThonnyCompletion("1", "2", "3", "4", "5", "6")
    assert my_ThonnyCompletion["name"] == "1"
    assert my_ThonnyCompletion["complete"] == "2"
    assert my_ThonnyCompletion["type"] == "3"
    assert my_ThonnyCompletion["description"] == "4"
    assert my_ThonnyCompletion["parent"] == "5"
    assert my_ThonnyCompletion["full_name"] == "6"


# Generated at 2022-06-22 03:02:54.720265
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi._compatibility import u
    from parso.python.tree import Leaf, Node
    from parso.python import tree
    from parso.python import node

    def parse_code(code, pos):
        module = parse_source(code)
        return get_statement_of_position(module, pos)

    def assert_pos_in_statement(code, pos):
        result = parse_code(code, pos)
        assert result is not None

    def assert_pos_not_in_statement(code, pos):
        result = parse_code(code, pos)
        assert result is None

    def assert_statement(code, pos, expected):
        result = parse_code(code, pos)
        if isinstance(expected, str):
            assert expected in result.get_code()
        else:
            assert expected

# Generated at 2022-06-22 03:03:02.134391
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import mock

    with mock.patch('jedi.utils.jedi_version_info', return_value=(0,18,1,True)):
        tc1 = ThonnyCompletion(name='a', complete='b', type='c', description='d', parent='e', full_name='f')
    tc2 = ThonnyCompletion(name='a', complete='b', type='c', description='d', parent='e', full_name='f')
    assert tc1['name'] == tc2['complete'] == 'b'

# Generated at 2022-06-22 03:03:11.323353
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    source = 'my_variable = 42\nshow_message("Hello!")\n'
    row = 2
    column = 5
    filename = 'temp.py'
    completions = get_script_completions(source, row, column, filename)
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == 'show_message('
    assert completions[0].complete == 'show_message('
    assert completions[0].description == 'show_message(message)'

# Generated at 2022-06-22 03:03:39.155869
# Unit test for function get_definitions
def test_get_definitions():
    definitions = get_definitions(source="def foo(): pass\nfoo()", row=2, column=5, filename="")
    assert definitions[0].module_name == ""
    assert definitions[0].line == 1
    assert definitions[0].column == 0

    # vim: set tabstop=4 shiftwidth=4 expandtab:

# Generated at 2022-06-22 03:03:45.224885
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test1.name == "name"
    assert test1.complete == "complete"
    assert test1.type == "type"
    assert test1.description == "description"
    assert test1.parent == "parent"
    assert test1.full_name == "full_name"

# Generated at 2022-06-22 03:03:47.129760
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("p", 1, 1, "1.py"))

# Generated at 2022-06-22 03:03:57.117403
# Unit test for function get_script_completions
def test_get_script_completions():
    def check_completions(source, row, column, expected):
        completions = get_script_completions(source, row, column, "")
        names = sorted([c.name for c in completions])
        assert names == [name for name, desc in expected]

    check_completions("''.strip", 0, 5, [])
    check_completions("''.strip", 0, 5, [])
    check_completions("''.strip(", 0, 7, [("1", "int()"), ("'1'", "str()")])
    check_completions("''.stri", 0, 5, [("strip", "str.strip()")])
    check_completions("import os\nos.", 1, 2, [("name", "str")])

# Generated at 2022-06-22 03:04:06.305029
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type_ = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    self = ThonnyCompletion(name, complete, type_, description, parent, full_name)
    assert self.__getitem__("name") == name
    assert self.__getitem__("complete") == complete
    assert self.__getitem__("type") == type_
    assert self.__getitem__("description") == description
    assert self.__getitem__("parent") == parent
    assert self.__getitem__("full_name") == full_name


# Generated at 2022-06-22 03:04:07.566258
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:19.157692
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name="print"
    complete="print"
    type="statement"
    description="Prints the values to a stream, or to sys.stdout by default."
    parent=None
    full_name="print"
 
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    if (tc["name"] == "print" and 
        tc["complete"] == "print" and 
        tc["type"] == "statement" and 
        tc["description"] == "Prints the values to a stream, or to sys.stdout by default." and 
        tc["parent"] == None and 
        tc["full_name"] == "print"):
        print("Unit test for method __getitem__ of class ThonnyCompletion: ", end="")
        print("passed!")
   

# Generated at 2022-06-22 03:04:27.780357
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # For compatibility with Jedi 0.17, function __getitem__ of class
    # ThonnyCompletion is added. So, it can be used as getitem in Python.
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:04:39.843298
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # Jedi 0.13 puts completions in a list
    if _using_older_jedi(jedi):
        completions = get_script_completions("a = [1, 2, 3]", 0, 4, "test.py")
        assert completions == [
            ThonnyCompletion(
                name="a",
                complete="a",
                type="name",
                description="",
                parent="<module>",
                full_name="a",
            )
        ], completions

        completions = get_script_completions("a = [1, 2, 3]", 0, 6, "test.py")

# Generated at 2022-06-22 03:04:41.142283
# Unit test for constructor of class ThonnyCompletion

# Generated at 2022-06-22 03:05:15.841557
# Unit test for function get_definitions

# Generated at 2022-06-22 03:05:21.145598
# Unit test for function parse_source
def test_parse_source():
    source_code = """for i in range(300):
    print(i)
print("Done")    
"""
    tree = parse_source(source_code)
    assert 'for' == tree.children[0].children[0].value
    assert 'print("Done")' == tree.children[1].value

# Generated at 2022-06-22 03:05:27.208849
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__dict__ == {"name":"name", "complete":"complete", "type":"type", "description":"description", "parent":"parent", "full_name":"full_name"}
if __name__ == '__main__':
    test_ThonnyCompletion()
    print("Everything passed")

# Generated at 2022-06-22 03:05:30.148659
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    instance = ThonnyCompletion(name='name', complete='complete',
                                type='type', description='description',
                                parent = 'parent', full_name='full_name' )

    assert(instance['name'] == 'name')

# Generated at 2022-06-22 03:05:34.406000
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    item = completion[0]
    assert item == "name"


# Generated at 2022-06-22 03:05:46.297578
# Unit test for function parse_source
def test_parse_source():
    source = 'def foo(a=1, b="Abc"):\n    a += 1\n    b += "xyz"\n    print(b)'

    try:
        import jedi.parser.python as parser
        root = parser.parse(source)
    except AttributeError:
        try:
            import parso
            root = parso.parse(source)
        except AttributeError:
            raise AttributeError("Unable to find a parser for jedi versions < 0.17")

    assert root.end_pos == (1,41)
    assert root.start_pos == (1,1)

    assert root.children[-1].type == "simple_stmt"
    assert root.children[-1].children[-1].type == "trailer"

# Generated at 2022-06-22 03:05:51.354802
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    f = "http://thonny.org/tests/lib.py"
    # Python 3.7
    print(get_interpreter_completions("import os.path\nos.path.", [], sys_path=None))
    # Python 3.7
    print(
        get_interpreter_completions("import os\nos.", [], sys_path=[f])  # type: ignore[arg-type]
    )
    # Python 3.7
    print(get_interpreter_completions("os.", [], sys_path=[f])  # type: ignore[arg-type]
    )
    # Python 2.7
    print(
        get_interpreter_completions("from os.path import *\njoin(", [], sys_path=None)
    )  # type: ignore

# Generated at 2022-06-22 03:06:00.918462
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    new_ThonnyCompletion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert new_ThonnyCompletion.name == "name"
    assert new_ThonnyCompletion.complete == "complete"
    assert new_ThonnyCompletion.type == "type"
    assert new_ThonnyCompletion.description == "description"
    assert new_ThonnyCompletion.parent == "parent"
    assert new_ThonnyCompletion.full_name == "full_name"

# Generated at 2022-06-22 03:06:03.404977
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"

# Generated at 2022-06-22 03:06:15.088575
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock
    import jedi

    namespaces = [
        {
            "__name__": "__main__",
            "__builtins__": {
                "__name__": "builtins",
                "__doc__": None,
                "__package__": None,
                "__loader__": None,
            },
            "example_obj": "some_obj",
        }
    ]

    expected_completions = [
        ThonnyCompletion(name="example_ob", type=None, complete="example_obj", description=None, parent=None, full_name=None)
    ]


# Generated at 2022-06-22 03:06:57.837592
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def run(source, expected):
        result = get_interpreter_completions(source, [{"__builtins__": __builtins__}])
        actual = [c.name for c in result]
        assert actual == expected

    run("open", ["open", "bool", "bytearray", "bytes", "classmethod", "complex", "dict", "enumerate",
                 "filter", "float", "format", "frozenset", "int", "list", "map", "memoryview", "object",
                 "range", "reversed", "set", "slice", "sorted", "staticmethod", "str", "super", "tuple",
                 "type", "zip"])


# Generated at 2022-06-22 03:07:08.380233
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completion import utils
    from thonny.plugins.jedi_completion import jedi_utils

    # Simple completion
    source = "x = 3\nx"
    expected = [ThonnyCompletion(name="x", complete="x", type="statement", description="int\n", parent=None, full_name="x")]
    assert (jedi_utils.get_script_completions(source, 2, 2, filename='test.py') == expected), "Simple completion failed"

    # Complex completion
    source = "import sys\nprint(sys.ex\n"
    expected = [ThonnyCompletion(name="exit", complete="exit", type="statement", description="SystemExit(...)", parent=None, full_name="sys.exit")]

# Generated at 2022-06-22 03:07:13.000130
# Unit test for function get_definitions
def test_get_definitions():
    # jedi version < 0.16.0
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name") in get_definitions("", 0, 0, '')

    # jedi version >= 0.16.0
    assert "comp" in get_definitions("", 0, 0, '')[0].name

# Generated at 2022-06-22 03:07:22.607194
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _ast import expr
    from test.backend.utils import Interpreter
    interpreter = Interpreter()
    for completion in get_interpreter_completions("a", [globals()]):
        if completion.complete == "abs":
            assert isinstance(completion.type, type)
            assert completion.type is type(abs)
            assert completion.name == "abs"
            break

    for completion in get_interpreter_completions("open(", [globals()]):
        if completion.name == "open(" and completion.type is expr:
            break
    else:
        assert False

# Generated at 2022-06-22 03:07:27.294781
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("callable", [{}])
    assert len(completions) == 1
    assert completions[0].name == "callable"

    completions = get_interpreter_completions("str.capitalize", [{}])
    assert len(completions) == 1
    assert completions[0].name == "capitalize"
    assert completions[0].parent == "str"
    assert completions[0].full_name == "str.capitalize"

# Generated at 2022-06-22 03:07:33.487818
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    testClass = ThonnyCompletion("test","testComplete","testType","testDescription","testParent","testFullName")
    assert testClass.name == "test"
    assert testClass.complete == "testComplete"
    assert testClass.type == "testType"
    assert testClass.description == "testDescription"
    assert testClass.parent == "testParent"
    assert testClass.full_name == "testFullName"

# Generated at 2022-06-22 03:07:42.368065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def check(source, namespaces, expected_completions):
        result = get_interpreter_completions(source, namespaces)
        if result is None:
            assert expected_completions is None
        else:
            result = sorted(result, key=lambda x: x.name)
            expected_completions = sorted(expected_completions, key=lambda x: x.name)
            assert len(result) == len(expected_completions)
            for i in range(len(result)):
                for k in expected_completions[i].__dict__:
                    assert expected_completions[i].__dict__[k] == result[i].__dict__[k]


# Generated at 2022-06-22 03:07:44.211207
# Unit test for function get_definitions
def test_get_definitions():
    from types import ModuleType

# Generated at 2022-06-22 03:07:45.147750
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:07:49.102460
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    result = get_script_completions("import sys", 0, 1, "", sys_path=sys.path)
    assert len(result) == len(sys.builtin_module_names) + 1


# Generated at 2022-06-22 03:08:37.212049
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    import parso

    module = parso.parse("""
for i in range(10):
    x = 0
    print(x)
""")

    # Statement
    stmt = get_statement_of_position(module, 4)
    assert stmt.type == "simple_stmt"
    assert stmt.get_code() == "x = 0\n"

    # For-line
    stmt = get_statement_of_position(module, 0)
    assert stmt.type == "for_stmt"
    assert stmt.get_code() == "for i in range(10):\n"

    # For-block
    stmt = get_statement_of_position(module, 2)

# Generated at 2022-06-22 03:08:38.767353
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree


# Generated at 2022-06-22 03:08:45.709677
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    source = '''
    def f1(x):
        return x
        
    g = f1
    
    g(1)
    '''
    root_node = parse_source(source)
    assert isinstance(root_node, tree.Module)
    assert len(root_node.children) == 1
    first_statement = root_node.children[0]
    assert isinstance(first_statement, tree.Function)
    assert first_statement.children[1].children[0].value == 'return'

# Generated at 2022-06-22 03:08:49.406094
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion(name="b", complete="b", type="c", description="d", parent="e", full_name="f")
    assert "b" == comp.name
    assert "b" == comp.complete
    assert "c" == comp.type
    assert "d" == comp.description
    assert "e" == comp.parent
    assert "f" == comp.full_name

# Generated at 2022-06-22 03:08:53.458960
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    from jedi import api

    source = "import os\nx = os."
    namespaces = [{"name": "os", "path": "/home/user/lib/python3.7/os.py"}]

    completions = get_interpreter_completions(source, namespaces, sys_path=["/home/user/lib/python3.7"])
    assert len(completions) > 0
    assert completions[0].name in ["_execvpe", "access", "path", "pathconf", "pathconf_names"]



# Generated at 2022-06-22 03:09:01.754448
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():

    thonny_completion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:09:06.272217
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:09:12.904968
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    completions = get_script_completions("""print("Hello")""", 0, 1, "test.py")
    result = [(c.name, c.type) for c in completions]
    assert ("print", "function") in result
    assert ("help", "function") in result
    assert ("__name__", "instance") in result



# Generated at 2022-06-22 03:09:24.545379
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    import sys

    if sys.version_info[0] < 3:
        source = ("def f(abc):\n" "\tpass\n" "\n" "f(abcd)\n")
    else:
        source = ("def f(abc:int):\n" "\tpass\n" "\n" "f(abcd)\n")
    completions = get_script_completions(source, 3, 4, "x.py")
    assert len(completions) == 1
    assert completions[0].complete == "abc"
    assert completions[0].type == "param"
    assert completions[0].parent.full_name == "f"


if __name__ == "__main__":
    test_get

# Generated at 2022-06-22 03:09:27.546271
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions

    completion = get_interpreter_completions("[x for x in ra", [])
    assert completion[0].name == "range"

    completion = get_interpreter_completions("import sys; sys.", [])
    assert completion[0].name == "sys"


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-22 03:10:12.415688
# Unit test for function parse_source

# Generated at 2022-06-22 03:10:20.262720
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    def get_completions(source, namespace):
        completions = get_interpreter_completions(source, namespace)
        return [comp.name for comp in completions]

    source = "x = [[1, 2], [3, 4]]"
    namespace = [{"x": parse_source(source).get_first_leaf().get_parent_scope()}]
    assert get_completions(source, namespace) == ["x"]

    source = "x = [1, 2] + [3, 4]"
    namespace = [{"x": parse_source(source).get_first_leaf().get_parent_scope()}]
    assert get_completions(source, namespace) == ["x"]


# Generated at 2022-06-22 03:10:31.868024
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python import tree

    import jedi
    from jedi import namespaces

    def fun(source: str, row: int, column: int):
        return get_script_completions(
            source,
            row,
            column,
            filename="",
            sys_path=[str(x) for x in jedi.settings.get_default_sys_path()],
        )

    assert fun('print(os.pat', 3, 9) == [ThonnyCompletion(name='path', complete='path', type=None, description='', parent=None, full_name='os.path')]
    assert fun('import os\nos.pat', 3, 9) == [ThonnyCompletion(name='path', complete='path', type=None, description='', parent=None, full_name='os.path')]

# Generated at 2022-06-22 03:10:42.863964
# Unit test for function parse_source
def test_parse_source():
    from unittest import TestCase, main

    import parso

    class ParseSourceTest(TestCase):
        def test1(self):
            source = "x.a = 2"
            root = parse_source(source)
            self.assertIsInstance(root, parso.python.tree.Module)
            self.assertIsInstance(root.children[0], parso.python.tree.ExprStmt)
            self.assertIsInstance(root.children[0].children[0], parso.python.tree.AssignmentStmt)
            self.assertEqual(root.children[0].children[0].get_code(), source)

            source = "f.foo(x)"
            root = parse_source(source)
            self.assertIsInstance(root, parso.python.tree.Module)