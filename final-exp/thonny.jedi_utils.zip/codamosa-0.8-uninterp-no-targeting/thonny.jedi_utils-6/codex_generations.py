

# Generated at 2022-06-22 03:01:00.006638
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:01:08.947660
# Unit test for function parse_source
def test_parse_source():
    """Tests that the parse_source function works as expected"""
    from parso.python.tree import Module

    # Tests that a string is parsed into a parso.python.tree.Module object
    assert isinstance(parse_source(""), Module)

    # Tests that a string is parsed into a parso.python.tree.Module object
    assert isinstance(parse_source("some string"), Module)

    # Tests that a string is parsed into a parso.python.tree.Module object
    assert isinstance(parse_source("""some string
    with multiple lines"""), Module)

# Generated at 2022-06-22 03:01:13.794238
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:01:18.764990
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name = 'my_name',
        complete = 'my_complete',
        type = 'my_type',
        description = 'my_description',
        parent = 'my_parent',
        full_name = 'my_full_name',
    )

    assert completion.name == 'my_name'
    assert completion.complete == 'my_complete'
    assert completion.type == 'my_type'
    assert completion.description == 'my_description'
    assert completion.parent == 'my_parent'
    assert completion.full_name == 'my_full_name'
    # regression test
    assert completion['name'] == 'my_name'

# Generated at 2022-06-22 03:01:28.667476
# Unit test for function parse_source
def test_parse_source():
    source = "import time\nprint(time.localtime())\ntime.sleep(3)\n"
    root = parse_source(source)

    # Test the outcome of parse_source
    print("First test:")
    print("Test of type of root:")
    print("Type of root: {t}".format(t=type(root)))
    if type(root) != parso.python.tree.Module:
        raise Exception("Test of type of root failed!")
    else:
        print("Test of type of root passed!")

    print("Test of type of root.children:")
    print("Type of root.children: {t}".format(t=type(root.children)))
    if type(root.children) != list:
        raise Exception("Test of type of root.children failed!")

# Generated at 2022-06-22 03:01:40.067418
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def test_position(source: str, pos: int, expected_type: str):
        node = parse_source(source)
        result = get_statement_of_position(node, pos)
        print(result.type)
        assert result.type == expected_type

    test_position("def f()\n    pass", 5, "funcdef")  # body
    test_position("def f():\n    pass", 7, "simple_stmt")  # body statement
    test_position("def f(): pass", 9, "simple_stmt")  # body statement
    test_position("def f() -> int:\n    pass", 13, "simple_stmt")  # return annotation

# Generated at 2022-06-22 03:01:45.329828
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys
    import tempfile

    dir = tempfile.mkdtemp()  # os.tmpdir()
    sys.path.insert(0, dir)
    with open(os.path.join(dir, "foo.py"), "w") as fp:
        fp.write("def foo(): pass")

    assert (
        get_interpreter_completions(
            "import ", [{"name": "foo", "value": "foo"}], sys_path=[dir]
        )[0].name
        == "foo"
    )

    assert (
        get_interpreter_completions(
            "import foo", [{"name": "foo", "value": "foo"}], sys_path=[dir]
        )[0].name
        == "foo"
    )


# Generated at 2022-06-22 03:01:56.070776
# Unit test for function get_definitions
def test_get_definitions():
    """Test cases for get_definitions

    get_definitions must return the following informations of a name:
    - description
    - module name
    - full name
    - line number
    - path
    """
    import os
    import os.path
    import inspect

    def run_test(source, filename, row, column, full_name, description):
        definitions = get_definitions(source, row, column, filename)

        assert definitions[0].full_name == full_name
        assert definitions[0].description == description

    # test case 1: name = str
    source = """\
import sys

a = str([])"""
    filename = "module.py"
    full_name = "str"
    description = "class str(object=b'')"
    row = 3
    column = 5

    run_

# Generated at 2022-06-22 03:02:04.460122
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import random
    import string

    # Method to generate random number and string
    def random_int_string(strlen):
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(strlen))

    # Method to create a dictionary (namespace)
    def get_namespace(list_length):
        dict = {}
        for i in range(list_length):
            dict[random_int_string(int(random.random() * 10))] = random_int_string(
                int(random.random() * 10)
            )

        return dict

    # Method to edit the list (completions)
    def edit_completions(completions, number_of_variables):
        for completion in completions:
            completion.name = ""


# Generated at 2022-06-22 03:02:13.152847
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # instance of class ThonnyCompletion
    ThonnyCompletion_obj = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert ThonnyCompletion_obj.name == 'name'
    assert ThonnyCompletion_obj.complete == 'complete'
    assert ThonnyCompletion_obj.type == 'type'
    assert ThonnyCompletion_obj.description == 'description'
    assert ThonnyCompletion_obj.parent == 'parent'
    assert ThonnyCompletion_obj.full_name == 'full_name'

# Generated at 2022-06-22 03:02:28.261303
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name","complete","type","description","parent","full_name")


# Generated at 2022-06-22 03:02:31.961960
# Unit test for function parse_source
def test_parse_source():
    import parso

    parser_utils = parso.python.parser_utils
    parser_utils.get_statement_of_position = _copy_of_get_statement_of_position

    from thonny.plugins.backend import BackendPlugin


# Generated at 2022-06-22 03:02:40.441058
# Unit test for function parse_source
def test_parse_source():
    import parso
    import io
    import sys

    # Check that parse_source returns a parso.PythonFile
    tree = parse_source('if 1:')
    assert isinstance(tree, parso.python.tree.PythonFile)
    tree.dump(sys.stdout)
    tree = parse_source('a = 2')
    tree.dump(sys.stdout)
    # Check that parse_source can parse from file
    with io.StringIO('if 1:\n a = 2\n') as f:
        tree = parse_source(f)
    tree.dump(sys.stdout)
    # Check that parse_source can parse from bytes
    with io.BytesIO(b'a = "abc"\n') as f:
        tree = parse_source(f)

# Generated at 2022-06-22 03:02:46.067786
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    source = "import math\nmath.d"
    sys_path = []
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces, sys_path)
    assert ["math.degrees", "math.digamma"] == [c.name for c in completions]

# Generated at 2022-06-22 03:02:54.064987
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree as pt

    def get_class_names(tree):
        names = []
        for node in tree.iter_classdefs():
            names.append(
                (
                    node.name.value,
                    node.get_parent_until(pt.Scope)
                    .get_parent_until(pt.Scope)
                    .name.value,
                )
            )
        return names

    def get_module_names(tree):
        names = []
        for node in tree.iter_funcdefs():
            names.append(
                (
                    node.name.value,
                    node.get_parent_until(pt.Scope)
                    .get_parent_until(pt.Scope)
                    .name.value,
                )
            )
        return names


# Generated at 2022-06-22 03:03:02.700523
# Unit test for function get_script_completions
def test_get_script_completions():
    from test_utils import assertEqual, run_test

    def f(source, row, column):
        completions = get_script_completions(source, row, column, "test.py")
        return [c.name for c in completions]

    assertEqual(
        f("a = 1\na.bit_", 2, 4),
        ["bit_length", "bit_length.__abs__", "bit_length.__add__", "bit_length.__and__"],
    )


if __name__ == "__main__":
    import logging

    logging.basicConfig()
    test_get_script_completions()

# Generated at 2022-06-22 03:03:11.004608
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from math import f"
    namespaces = [{"name": "__main__", "locals_": {"f": 2}}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].full_name == "math.factorial"
    assert completions[0].complete == "factorial("
    assert completions[0].type == "function"



# Generated at 2022-06-22 03:03:20.377312
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys

    rootpath = os.path.join(os.path.dirname(sys.executable), "lib", "python3.5", "test")
    source_file = os.path.join(rootpath, "test_pep3107.py")
    source = ""
    with open(source_file, "r") as f:
        source = f.read()

    script = jedi.Script(source=source, path=source_file)
    tree = script._get_module().get_root_node()
    for i, line in enumerate(source.splitlines()):
        if line.strip().startswith("def"):
            break
    idx = source.splitlines()[i].find("def")
    def_node = get_statement

# Generated at 2022-06-22 03:03:21.688061
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    

# Generated at 2022-06-22 03:03:22.787055
# Unit test for function get_definitions

# Generated at 2022-06-22 03:03:43.559576
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import parso.python.tree as pytree

    source = """
import sys
sys.get
    """.strip()
    namespaces = [pytree.Namespace({"sys": "module"}, {})]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    # same as in jedi:
    assert [c.name for c in completions] == ["getdefaultencoding", "getfilesystemencoding"]



# Generated at 2022-06-22 03:03:55.151715
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import jedi
    from jedi.api.project import Project

    try:
        jedi.get_script_completions("", 1, 1)
    except TypeError:
        raise unittest.SkipTest("This is pre-0.16 jedi")
    else:
        raise AssertionError("0.16 or later Jedi should not allow calling without filename")

    try:
        jedi.get_script_completions("", 1, 1, "/tmp/test.py")
    except TypeError as e:
        assert "Missing" in str(e)
    else:
        raise AssertionError("0.17 or later Jedi should not allow calling without code")

    completions = jedi.get_script_completions("", 1, 1, "/tmp/test.py", code="")


# Generated at 2022-06-22 03:04:06.871217
# Unit test for function get_script_completions
def test_get_script_completions():
    #
    #  Test 1
    #
    source = """
    def test(a, #com
    """
    row = 2
    column = 20
    filename = "test.py"
    expected_result = [
        ThonnyCompletion(name="a", complete="", type="param", description="(Parameter) a", parent="test", full_name="a"),
        ThonnyCompletion(name="ab", complete="ab", type="statement", description="(Exception) ab", parent="", full_name="ab"),
        ThonnyCompletion(name="abs", complete="abs", type="builtin", description="(Function) abs(number) -> int or float or complex\n\nReturn the absolute value of the argument.", parent="", full_name="abs"),
    ]

# Generated at 2022-06-22 03:04:18.597760
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").name == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").complete == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").type == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").description == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").parent == "parent"
    assert ThonnyCom

# Generated at 2022-06-22 03:04:30.259611
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.tree import Leaf, Node

    parsing_node = Node(type="fob", children=[])
    parsing_node.children = [Leaf(type="ws", value="", parent=parsing_node), Leaf(type="linebreak", value="\n", parent=parsing_node)]
    parsing_node.children.append(tree.ErrorLeaf(type="error", value="mock error!", parent=parsing_node))
    parsing_node.children[1].start_pos = 8
    parsing_node.children[1].end_pos = 8
    parsing_node.children[2].start_pos = 8
    parsing_node.children[2].end_pos = 14


# Generated at 2022-06-22 03:04:34.459509
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from jedi.inference.value.namespace import NamespaceValue
    ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent=NamespaceValue(),
        full_name="full_name",
    )

# Generated at 2022-06-22 03:04:38.809858
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:04:41.814517
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    item = ThonnyCompletion("func", "func()", "function", "", "", "")
    assert item.name == "func"
    assert item.complete == "func()"
    assert item.type == "function"
    assert item.description == ""
    assert item.parent == ""
    assert item.full_name == ""


# Generated at 2022-06-22 03:04:50.666051
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # Test that it is working on older versions (tested on 0.13.2, 0.14.1)
    # and latest version (tested on 0.17.0, 0.18.1)
    jedi.__version__ = "0.13.2"
    result = get_script_completions(source="1+sum", row=0, column=3, filename="test_get_script_completions_source.py")
    assert len(result) == 1
    assert result[0].name == "sum="
    assert result[0].complete == "sum="

    jedi.__version__ = "0.17.0"

# Generated at 2022-06-22 03:04:56.024436
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python.tree import NodeOrLeaf
    from parso import parse

    import jedi
    from jedi import Script

    # Test for uncompleted function call
    source = """
import math
print(math.sqrt(4)
"""
    jedi_version=jedi.__version__
    row = 3
    col = 10
    filename = "test_filename"

    completions = get_script_completions(source, row, col, filename)

    assert(type(completions) == list)
    assert(type(completions[0]) == ThonnyCompletion)



# Generated at 2022-06-22 03:05:31.017947
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils

    source = """def foo():
    print(1)
    print(2)
    if True:
        print(3)
        print(4)
"""

    node = parso.parse(source)
    node_of_file, line_nr = jedi.parser_utils.get_root_node_and_line_for_position(node, row=4, column=4)
    assert get_statement_of_position(node_of_file, (line_nr, 4)) == node_of_file.children[1]

# Generated at 2022-06-22 03:05:35.945720
# Unit test for function parse_source
def test_parse_source():
    p = parse_source('def f(a,b):\n    pass')
    assert p.children[1] == "pass"
    assert p.get_line(2) == "    pass"

# Generated at 2022-06-22 03:05:46.592188
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser import tree

    x = tree.Function("f", tree.Name("x"), [], "")
    x.start_pos = (1, 2)
    x.end_pos = (10, 10)
    n = get_statement_of_position(x, (1, 2))
    assert n == x

    n = get_statement_of_position(x, (9, 9))
    assert n == x

    n = get_statement_of_position(x, (2, 3))
    assert n == x

    n = get_statement_of_position(x, (10, 10))
    assert n == x

    n = get_statement_of_position(x, (11, 10))
    assert n is None

    assert get_statement_of_position(x, (1, 1)) is None

# Generated at 2022-06-22 03:05:54.394885
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    s = '''from math import factorial'''
    namespaces = [
        {"x": 1, "y": [2, 3], "z": "abc"},
        {"abc": "abc", "def": "def"},
        {"a": "abc"},
        {"b": "abc"},
    ]
    completions = get_interpreter_completions(s, namespaces)
    assert sorted([c.name for c in completions]) == sorted(
        ["x", "y", "z", "abc", "def", "a", "b", "factorial"]
    )

# Generated at 2022-06-22 03:05:59.186798
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "a = 3"
    r = parse_source(source)
    assert isinstance(r, parso.python.tree.Module)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:06:01.316914
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    # Python 3.7

# Generated at 2022-06-22 03:06:02.736436
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert tc.__getitem__("name") == "name"

# Generated at 2022-06-22 03:06:14.361365
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    class Test:
        def __getitem__(self, key):
            if key == "name":
                return "name"
            if key == "complete":
                return "complete"
            if key == "type":
                return "type"
            if key == "description":
                return "description"
            if key == "parent":
                return "parent"
            if key == "full_name":
                return "full_name"
        def __setitem__(self, key, value):
            raise NotImplementedE
        def get(self, key, default):
            if key in self.__dict__:
                return self.__dict__[key]
            else:
                return default

    test = Test()

# Generated at 2022-06-22 03:06:23.166254
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    from unittest.mock import patch
    from jedi.api.environment import get_cached_default_environment


# Generated at 2022-06-22 03:06:31.831528
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench
    from thonny.plugins.jedi_utils import get_script_completions

    def _generate_suggestions(source):
        script = get_workbench().get_editor_notebook().get_current_editor()
        _, row, column = script.get_coordinates_from_pos(script.get_current_position())
        completions = get_script_completions(
            script.get_text_range(1.0, "end"), row, column, "", ["."]
        )
        assert completions

    # Test that completion works with new and old jedi
    _generate_suggestions('import os\nos.')

# Generated at 2022-06-22 03:07:40.390570
# Unit test for function get_definitions

# Generated at 2022-06-22 03:07:51.611334
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    thonny_completion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert thonny_completion.__getitem__("name") == name
    assert thonny_completion.__getitem__("complete") == complete
    assert thonny_completion.__getitem__("type") == type
    assert thonny_completion.__getitem__("description") == description
    assert thonny_completion.__getitem__("parent") == parent
    assert thonny_completion.__getitem__("full_name") == full_name



# Generated at 2022-06-22 03:07:58.280393
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-22 03:08:05.458907
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    # Source code containg the following statements:
    # a = 1
    # b = 2
    # c = 3
    source = "a = 1\nb = 2\nc = 3"

    # We should get None if position is to the left of the first statement
    node = parse_source(source)
    assert get_statement_of_position(node, 0) is None

    # We should get the innermost statement if position on the right of the statement
    assert get_statement_of_position(node, 1) is node.children[0]
    assert get_statement_of_position(node, 2) is node.children[0]

    # We should get the innermost statement if position on the left of the statement

# Generated at 2022-06-22 03:08:08.214742
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-22 03:08:18.405908
# Unit test for function parse_source
def test_parse_source():
    # TODO: check if parser can cope with CRLF
    source = parse_source("print('Hello world')\n")
    # print(source.dumps())

    assert source.type == "file_input"
    assert source.children[0].type == "simple_stmt"
    assert source.children[0].children[0].type == "small_stmt"
    assert source.children[0].children[0].children[0].type == "expr_stmt"
    assert source.children[0].children[0].children[0].children[0].type == "testlist"
    assert source.children[0].children[0].children[0].children[0].children[0].type == "atom"

# Generated at 2022-06-22 03:08:29.019225
# Unit test for function get_definitions
def test_get_definitions():
    # Simple case of pointing at a function
    source = """def foo(): pass\nfoo() + 1"""
    row, col = 1, 6
    filename = ""
    definitions = get_definitions(source, row, col, filename)
    assert len(definitions) == 1
    assert definitions[0].module_name == "<unknown>"
    assert definitions[0].line == 1
    assert definitions[0].column == 4
    assert definitions[0].type == "function"
    assert len(definitions[0].infer()) == 0

    # Simple case of pointing at a module
    source = """import os\nos.listdir()"""
    row, col = 1, 8
    filename = ""
    definitions = get_definitions(source, row, col, filename)
    assert len(definitions) == 1

# Generated at 2022-06-22 03:08:38.469777
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import re

    pattern = r"<thonny\.jediutils_1_4\.ThonnyCompletion object at 0x[0-9a-z]+>\)"
    # Python 3.x
    source = "import math\nmath.\nmath."

    # incomplete expression
    completions = get_interpreter_completions(source, [])
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert "math." in completions[0].complete
    assert re.search(pattern, repr(completions))

    # completed expression
    completions = get_interpreter_completions(source, [])
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert "math." in completions[0].complete

# Generated at 2022-06-22 03:08:39.024647
# Unit test for function parse_source

# Generated at 2022-06-22 03:08:48.238241
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert (
        get_script_completions("import numpy; numpy.", 0, 17, "")[0].complete
        == "numpy."
    )
    assert len(get_script_completions("import numpy; numpy.", 0, 17, "")) == len(
        get_script_completions("import numpy; numpy.", 0, 17, "")
    )
    assert get_script_completions("array", 0, 3, "")[0].complete == "array"
    assert (
        get_script_completions("from numpy import array", 0, 23, "")[0].complete
        == "array"
    )

# Generated at 2022-06-22 03:09:39.145696
# Unit test for function get_definitions

# Generated at 2022-06-22 03:09:45.167505
# Unit test for function get_script_completions
def test_get_script_completions():
    # assert get_script_completions("", 0, 0) == []
    assert get_script_completions("i", 0, 1) == []
    assert get_script_completions("import", 0, 7) == []
    assert get_script_completions("import os\nos", 1, 2) == []
    assert get_script_completions("import os\nos.listd", 1, 3) == []
    assert get_script_completions("import os\nos.list", 1, 10) == []
    assert get_script_completions("import os\nos.listdir()", 1, 12) == []
    assert get_script_completions("import os\nos.listdir(", 1, 17) == []

# Generated at 2022-06-22 03:09:46.093849
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi


# Generated at 2022-06-22 03:09:53.232626
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(
        name='name_of_tc',
        complete='complete',
        type='type',
        description='description',
        parent='parent',
        full_name='name_of_tc.full',
    )
    assert tc['name'] == 'name_of_tc'
    assert tc['complete'] == 'complete'
    assert tc['type'] == 'type'
    assert tc['description'] == 'description'
    assert tc['parent'] == 'parent'
    assert tc['full_name'] == 'name_of_tc.full'



# Generated at 2022-06-22 03:10:04.202969
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import get_default_project
    from jedi import __version__ as jedi_version
    # Python 3.9 has different Ast structure and is not supported
    assert __main__ is not None, "This module is not designed to be called as a script"

    tmpdir = __main__.tmpdir

    if jedi_version >= "0.18":
        project = get_default_project()
    else:
        project = None

    class_def_py = tmpdir.join("class_def.py")
    class_def_py.write(
        """
        class Foo:
            def __init__(self, x):
                self.x = x

    """
    )


# Generated at 2022-06-22 03:10:15.114065
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # test case1
    complete = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert complete.name == "name"
    assert complete.complete == "complete"
    assert complete.type == "type"
    assert complete.description == "description"
    assert complete.parent == "parent"
    assert complete.full_name == "full_name"

    # test case2
    complete2 = ThonnyCompletion("", "", "", "", "", "")
    assert complete2.name == ""
    assert complete2.complete == ""
    assert complete2.type == ""
    assert complete2.description == ""
    assert complete2.parent == ""
    assert complete2.full_name == ""

# Generated at 2022-06-22 03:10:21.791720
# Unit test for function get_script_completions
def test_get_script_completions():
    from _pytest.tmpdir import TemporaryPath
    from thonny.misc import get_python_version
    from thonny.python_shell import PyShell
    from thonny.running import get_interpreter

    with TemporaryPath() as module_dir:
        current_shell = PyShell(get_interpreter())
        current_shell.set_sys_path([str(module_dir)])
        current_shell.execute("def foo():\n   return 'bar'")

        path = module_dir / "test_module.py"
        f = path.open("w", encoding="utf-8")
        f.write("import test_module\n")
        f.write("test_module.foo()")
        f.close()


# Generated at 2022-06-22 03:10:32.397774
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest

    correct_completions = [
        ThonnyCompletion(
            name="a",
            complete="a",
            type="a",
            description="a",
            parent=None,
            full_name="a",
        ),
        ThonnyCompletion(
            name="b",
            complete="b",
            type="b",
            description="b",
            parent=None,
            full_name="b",
        ),
    ]

    class TestScript(unittest.TestCase):
        def test_completions(self):
            from mock import Mock

            script = Mock()
            script.completions = Mock(return_value=correct_completions)

# Generated at 2022-06-22 03:10:33.223368
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:10:35.988050
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from .shell import parse_source

    node = parse_source("""if True:
    pass""")
    statement = get_statement_of_position(node, 7)
    assert statement.type == "pass_stmt"

