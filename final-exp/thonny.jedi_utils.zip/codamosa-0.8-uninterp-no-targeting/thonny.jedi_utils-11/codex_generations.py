

# Generated at 2022-06-22 03:00:42.877948
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.python import tree
    source_code = "print(1)"
    tree = parso.parse(source_code)
    first_node = tree.children[0]
    assert type(first_node) is tree.ExprStmt
    assert len(first_node.children) == 1

# Generated at 2022-06-22 03:00:51.611246
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    td = {'key1': 'value1', 
       'key2': 'value2',
       'key3': 'value3',  
       'key4': 'value4'}
    tc = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert tc['name'] == 'name'
    assert tc['complete'] == 'complete'
    assert tc['full_name'] == 'full_name'
    assert tc['type'] == 'type'
    assert tc['description'] == 'description'
    assert tc['parent'] == 'parent'
    assert tc.__dict__['name'] == 'name'
    assert tc.__dict__['complete'] == 'complete'
    assert tc.__dict__['full_name'] == 'full_name'
    assert tc.__

# Generated at 2022-06-22 03:01:04.254353
# Unit test for function get_script_completions
def test_get_script_completions():
    def completions_equal(a, b):
        if len(a) != len(b):
            return False

        for i in range(len(a)):
            if a[i].name != b[i].name:
                return False

        return True

    def run_test_with_jedi(code, row, column, filename, expected_completions):
        import jedi

        # jedi.api.environment.get_default_environment
        logger.debug("======================= old jedi")
        completions = get_script_completions(
            code, row=row, column=column, filename=filename, sys_path=None
        )
        assert completions_equal(completions, expected_completions)


# Generated at 2022-06-22 03:01:14.104498
# Unit test for function get_script_completions
def test_get_script_completions():
    # recheck_test_completions is only needed for test function,
    # because it is necessary to compare completion types (str vs jedi.api.names)
    # since jedi >= 0.17
    import jedi

    def recheck_test_completions(completions):
        if _using_older_jedi(jedi):
            return [tuple(cmp) for cmp in completions]
        else:
            return [tuple(cmp) for cmp in completions]
            # [tuple(cmp.name for cmp in completions)]

    filename = ""
    row = 0
    column = 0

    source = "import"
    completions = get_script_completions(source, row, column, filename)

# Generated at 2022-06-22 03:01:25.386378
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    >>> import os.path
    >>> completions = get_interpreter_completions(
    ...    source='import sys; sys.path.append(".")\\nsys.path',
    ...    namespaces=[{'namespace': {'os': __import__('os.path')}, 'is_function': False}],
    ...    sys_path=['.'])
    >>> [(c.name, c.parent) for c in completions]
    [('path', 'sys'), ('curdir', 'os.path'), ('pardir', 'os.path'), ('sep', 'os.path'), ('extsep', 'os.path'), ('pathsep', 'os.path'), ('linesep', 'os.path'), ('defpath', 'os.path')]
    """



# Generated at 2022-06-22 03:01:31.518093
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(name="n", complete="c", type="t", description="d", parent="p", full_name="f").__dict__ == {
        "name": "n",
        "complete": "c",
        "type": "t",
        "description": "d",
        "parent": "p",
        "full_name": "f",
    }

# Generated at 2022-06-22 03:01:39.636067
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # TODO: only test the patched version
    import jedi
    logger.info("Testing get_statement_of_position...")

    grammar = """functiondef_decorated: decorators functiondef_nodecorator
functiondef_decorators: decorator+
decorator: '@' dotted_name NEWLINE
functiondef_nodecorator: 'def' NAME parameters ['->' test] ':' suite
decorators: decorator+
decorator: '@' dotted_name NEWLINE
"""  # NOQA


# Generated at 2022-06-22 03:01:41.121195
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("abc").children[0].children[0].value == "abc"



# Generated at 2022-06-22 03:01:44.961478
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    namespaces = [{}]
    result = get_interpreter_completions("a.b.c", namespaces)
    assert result == [ThonnyCompletion(name="c", complete="c", type="", description="", parent="", full_name="a.b.c")]

    # test that namespaces are not modified
    assert namespaces == [{}]



# Generated at 2022-06-22 03:01:48.191633
# Unit test for function get_definitions

# Generated at 2022-06-22 03:02:07.672189
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    get_data = ThonnyCompletion("test", "test", "test", "test", "test", "test")
    get_data.__getitem__("test")
    assert get_data.__getitem__("test") == get_data.__dict__["test"]

# Generated at 2022-06-22 03:02:18.046714
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.parser import ParserError
    from jedi.evaluate import compiled, param

    class MockNode:
        def __init__(self, _type, children=None, start_pos=None, end_pos=None):
            self.type = _type
            self.children = children if children else []
            self.start_pos = start_pos
            self.end_pos = end_pos

    class MockWithError:
        def __getattr__(self, item):
            raise ParserError()


# Generated at 2022-06-22 03:02:32.049128
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(
        name="name1",
        complete="complete1",
        type="type1",
        description="description1",
        parent="parent1",
        full_name="full_name1",
    )["name"] == "name1" and ThonnyCompletion(
        name="name1",
        complete="complete1",
        type="type1",
        description="description1",
        parent="parent1",
        full_name="full_name1",
    )["complete"] == "complete1" and ThonnyCompletion(
        name="name1",
        complete="complete1",
        type="type1",
        description="description1",
        parent="parent1",
        full_name="full_name1",
    )["type"] == "type1" and ThonnyCompletion

# Generated at 2022-06-22 03:02:40.476089
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    print("Jedi version: ", jedi.__version__)
    print("Using older jedi: ", _using_older_jedi(jedi))
    print("Completions: ", get_script_completions("impor", 1, 4, ""))
    print("Completions: ", get_script_completions("impor", 1, 5, ""))
    print("Completions: ", get_script_completions("impo", 1, 4, ""))
    print("Completions: ", get_script_completions("impo", 1, 5, ""))
    print("Completions: ", get_script_completions("foo.ba", 1, 7, ""))
    print("Completions: ", get_script_completions("foo.ba", 1, 8, ""))

# Generated at 2022-06-22 03:02:45.062359
# Unit test for function parse_source
def test_parse_source():
    # test that the function works with valid code
    assert parse_source("def foo():\n    pass")

    # test that the function works with valid code
    assert parse_source("def foo() -> None:\n    pass")

    # test that the function fails with invalid code
    try:
        assert parse_source("def foo(a, b c):")
        assert False  # this should not be executed
    except SyntaxError:
        pass

    # test that the function works with unicode
    assert parse_source("def λ():\n    pass")

    # test that the function works with unicode
    assert parse_source("def μ():\n    pass")

# Generated at 2022-06-22 03:02:55.808952
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest.mock import MagicMock

    thonny_completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert thonny_completion.__getitem__("name") == "name"
    assert thonny_completion.__getitem__("complete") == "complete"
    assert thonny_completion.__getitem__("type") == "type"
    assert thonny_completion.__getitem__("description") == "description"
    assert thonny_completion.__getitem__("parent") == "parent"

# Generated at 2022-06-22 03:03:07.883611
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import __main__ as main
    from test.test_remote import capture_output

    with capture_output() as out:
        main.main()

    source = out.getvalue()
    import jedi
    completions = get_script_completions(
        source, len(source.splitlines()), len(source.splitlines()[-1]) - 1, "out.txt"
    )
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert len(completions) == 84  # on jedi 0.13, 0.14, 0.15, 0.16 and 0.17
    elif jedi.__version__[:4] == "0.18":
        assert len

# Generated at 2022-06-22 03:03:10.260573
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    if not _using_older_jedi(jedi):
        return


# Generated at 2022-06-22 03:03:13.940135
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"

# Generated at 2022-06-22 03:03:19.153548
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    >>> import jedi
    >>> completions = get_interpreter_completions("r = re.", [])
    >>> [c.complete for c in completions]
    ['r = re.compile()', 'r = re.findall()', 'r = re.match()', 'r = re.search()', 'r = re.split()']
    """

# Generated at 2022-06-22 03:03:35.472878
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    
    script = jedi.Script("import math\nprint (math.pi)")
    completions = script.completions()
    completion = completions[0]
    
    assert isinstance(ThonnyCompletion(completion.name, completion.complete, completion.type, completion.description, completion.parent, completion.full_name), ThonnyCompletion)

# Generated at 2022-06-22 03:03:36.942560
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-22 03:03:48.165429
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    some_namespace = {'a': 2}
    source = 'a'
    completions = get_interpreter_completions(source, [some_namespace])
    assert len(completions) == 1
    assert completions[0].name == 'a'
    assert completions[0].description == 'int'

    completions = get_interpreter_completions('a, b', [some_namespace])
    assert len(completions) == 2
    assert completions[0].name == 'a'
    assert completions[1].name == 'b'

    completions = get_interpreter_completions('1, b', [])
    assert len(completions) == 1
    assert completions[0].name == 'b'


# Unit test to check that the path is used to

# Generated at 2022-06-22 03:03:53.351769
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("pri", 2, 1, "")
    assert result == [ThonnyCompletion("print", "print ", "function", "print(value, ..., sep=' ', end='\\n', file=sys.stdout)", (), 'print')]
    # print(result)


# Generated at 2022-06-22 03:03:55.114573
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    assert isinstance(parse_source(""), Module)

# Generated at 2022-06-22 03:04:06.784131
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase
    from os.path import dirname, join
    import jedi
    import sys
    sys.path.insert(0, join(dirname(__file__), "..", "jedi_stubs"))

    class TestGetDefinitions(TestCase):
        def test_get_definitions(self):
            defs = get_definitions(
                """import turtle
turtle.forward(100)"""
                , 1, 4, "test.py"
            )
            self.assertEqual(1, len(defs))
            self.assertEqual(
                "turtle.Turtle.forward(self, distance: int) -> None",
                str(defs[0]),
            )

    import test.support

    test.support.run_unittest(TestGetDefinitions)

# Generated at 2022-06-22 03:04:15.878938
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    # in jedi 0.13 - 0.15 the name and complete attributes have same value
    completion = ThonnyCompletion('name1', 'complete1', 'type1', 'description1', 'parent1', 'full_name1')
    assert completion.name == 'name1'
    assert completion.complete == 'complete1'
    assert completion.type == 'type1'
    assert completion.description == 'description1'
    assert completion.parent == 'parent1'
    assert completion.full_name == 'full_name1'

# Generated at 2022-06-22 03:04:17.583536
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script

# Generated at 2022-06-22 03:04:18.587332
# Unit test for function parse_source

# Generated at 2022-06-22 03:04:19.922771
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:49.769339
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            # TODO: this should use jedi in the test env,
            # not the jedi in the Thonny runtime
            # ...but currently, it's the same jedi, so it's ok
            import jedi
            v_19 = jedi.__version__[0:3] == "0.19"

            if v_19:
                import parso

                # Monkey patch
                parso.python.tree.Name.is_definition = lambda self: True

            as_dict = get_interpreter_completions("x=_", namespaces=[])
            names = [d["name"] for d in as_dict]

            # Older Jedi versions will show _x and _jedi


# Generated at 2022-06-22 03:04:52.191024
# Unit test for function parse_source
def test_parse_source():
    import jedi
    assert isinstance(parse_source("a = 42"), jedi.parser_utils.tree.Module)

# Generated at 2022-06-22 03:05:03.329910
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test with older jedi
    def test_get_script_completions_for_version(version):
        if version not in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
            raise ValueError("jedi with version %s is not supported for test" % version)

        import importlib
        import sys

        jedi_mod = importlib.import_module("jedi.api.jedi")
        sys.modules["jedi"] = jedi_mod
        sys.modules["jedi.api.jedi"] = jedi_mod
        jedi_mod.__version__ = version

        try:
            import jedi
        finally:
            del sys.modules["jedi"]
            del sys.modules["jedi.api.jedi"]


# Generated at 2022-06-22 03:05:10.715914
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion("m", "my_method", "method", "something", "parent", "full name")
    assert comp["name"] == "m"
    assert comp["complete"] == "my_method"
    assert comp["type"] == "method"
    assert comp["description"] == "something"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full name"
# end unit test

# Generated at 2022-06-22 03:05:22.157709
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api import Interpreter
    from thonny.jediutils import ThonnyCompletion

    interp = Interpreter("", [])
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"

# Generated at 2022-06-22 03:05:23.694004
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    
    ThonnyCompletion(name='completion', complete='completion', type='completion', description='completion', parent='completion', full_name='completion')



# Generated at 2022-06-22 03:05:32.656817
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    completion = jedi.classes.Completion()
    completion.name = "name"
    completion.complete = "complete"
    completion.type = "type"
    completion.description = "description"
    completion.parent = "parent"
    completion.full_name = "full_name"

    new_completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

    assert new_completion.name == completion.name
    assert new_completion.complete == completion.complete
    assert new_completion.type == completion.type

# Generated at 2022-06-22 03:05:40.860818
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    o1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert o1["name"] == "name"
    assert o1["complete"] == "complete"
    assert o1["type"] == "type"
    assert o1["description"] == "description"
    assert o1["parent"] == "parent"
    assert o1["full_name"] == "full_name"
    assert o1["unknown"] is None

# Generated at 2022-06-22 03:05:44.852412
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    assert x.__dict__ == {"name": "a", "complete": "b", "type": "c", "description": "d", "parent": "e", "full_name": "f"}


# Generated at 2022-06-22 03:05:56.268264
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_input = ['\nimport sys, os\n',
                  '\nimport os\n',
                  '\nimport sys\n',
                  '\nimport os as OS\n',
                  '\nimport sys as SYS\n']
    
    expected_output = [
        ['sys', 'os'],
        ['os'],
        ['sys'],
        ['OS'],
        ['SYS'],
    ]
    
    for i, input_ in enumerate(test_input):
        completions = get_interpreter_completions(input_, [], [])
        output = sorted([ c.full_name for c in completions ])

# Generated at 2022-06-22 03:06:40.780510
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    script = jedi.Script("int()")
    results = script.goto_definitions()
    assert len(results) == 1
    assert results[0].type == "class"

# Generated at 2022-06-22 03:06:41.665308
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-22 03:06:52.648723
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:06:53.715875
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

# Generated at 2022-06-22 03:06:57.405036
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions('""[0]', [{'foo': 'bar', 'spam': 42}])) > 200
    assert len(get_interpreter_completions('"".sp', [{}])) > 100
    assert len(get_interpreter_completions('42.', [{}])) > 100



# Generated at 2022-06-22 03:06:59.163471
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import parso
    import ast


# Generated at 2022-06-22 03:07:09.638067
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert len(get_script_completions('x = "test"', 1, 1, "test.py")) == 4
    assert len(get_script_completions('x = "test"', 1, 0, "test.py")) == 5
    assert len(get_script_completions('x = "test"', 1, 5, "test.py")) == 5
    assert len(get_script_completions('import math\nx = math.pi', 1, 5, "test.py")) == 1
    if _using_older_jedi(jedi):
        assert len(get_script_completions('x = "test"', 1, 7, "test.py")) == 4

# Generated at 2022-06-22 03:07:21.238979
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso

    source = """
    class Foo:
        pass

    def f(x):
        '''
        Docstring
        '''
        return x
    """

    parsed = parso.parse(source)
    definitions = jedi.evaluate.get_definitions(parsed, (3, 13))
    assert len(definitions) == 1
    assert definitions[0].description == "Docstring"
    assert definitions[0].type == "function"
    assert definitions[0].full_name == "f"

    definitions = jedi.evaluate.get_definitions(parsed, (1, 4))
    assert len(definitions) == 1
    assert definitions[0].description == "class Foo"
    assert definitions[0].type == "class"
    assert definitions[0].full_name

# Generated at 2022-06-22 03:07:28.616572
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.__getitem__("name") == "name"
    assert completion.__getitem__("complete") == "complete"
    assert completion.__getitem__("type") == "type"
    assert completion.__getitem__("description") == "description"
    assert completion.__getitem__("parent") == "parent"
    assert completion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-22 03:07:39.941198
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    source = """
if True:
    def f():
        a = 1
        [a, b] = 2
    f()
    x = 5
    """
    filename = "<test file>"
    # In jedi prior to 0.16 the cursor had to be on a different line than the
    # assignment, since editor is the other way around
    row = 8  # column = 4
    script = jedi.Script(source, row, 1, filename)
    definitions = script.goto_assignments()
    assert len(definitions) == 1
    assert definitions[0].line == 5


    # cursor on 'a' should return line 4, column 13
    row = 4
    column = 13
    node = parse_source(source)
    # print(node)
    assert get_statement_of_position

# Generated at 2022-06-22 03:09:21.792891
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_source = """
        import datetime
        datetime.
    """
    completions = get_interpreter_completions(
        test_source,
        namespaces=[{"__builtins__": {}}],
        sys_path=["/home/tira/THONNY_SRC"],
    )
    assert "utcnow" in [completion.name for completion in completions]

# Generated at 2022-06-22 03:09:23.416518
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python
    from parso.python import tree


# Generated at 2022-06-22 03:09:34.567016
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = """
if cond1:
    print("cond1")
elif cond2:
    print("cond2")
elif cond3:
    print("cond3")
else:
    print("none")

if cond4:
    print("cond4")
else:
    print("not cond4")

if cond5:
    print("cond5")
else:
    print("not cond5")

if cond6:
    print("cond6")
elif cond7:
    print("cond7")
elif cond8:
    print("cond8")
else:
    print("none"
    )
"""

    parse_tree = parse_source(source)
    node = parse_tree.children[0]

# Generated at 2022-06-22 03:09:39.522924
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check_with_code(code, start, end, expected_start=None, expected_end=None):
        node = parse_source(code)
        result = get_statement_of_position(node, (end, 0))

        if expected_start is not None:
            assert expected_start == result.start_pos
        if expected_end is not None:
            assert expected_end == result.end_pos

    chec

# Generated at 2022-06-22 03:09:50.796740
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnyCompletion.name == "name"
    assert thonnyCompletion.complete == "complete"
    assert thonnyCompletion.type == "type"
    assert thonnyCompletion.description == "description"
    assert thonnyCompletion.parent == "parent"
    assert thonnyCompletion.full_name == "full_name"
    assert thonnyCompletion["name"] == "name"
    assert thonnyCompletion["complete"] == "complete"
    assert thonnyCompletion["type"] == "type"
    assert thonnyCompletion["description"] == "description"
    assert thonnyCompletion["parent"] == "parent"
    assert th

# Generated at 2022-06-22 03:09:55.749424
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert(ThonnyCompletion(name = "name",
                            complete = "complete",
                            type="type",
                            description="description",
                            parent="parent",
                            full_name="full_name")["name"] == "name")


if __name__ == "__main__":
    test_ThonnyCompletion___getitem__()

# Generated at 2022-06-22 03:10:06.457463
# Unit test for function get_script_completions
def test_get_script_completions():
    def _test(filename, text, column, expected):
        from .token_utils import get_cursor_line_column

        line, column = get_cursor_line_column(text)
        completions = get_script_completions(text, line, column, filename)
        names = set(c.name for c in completions)
        assert names == set(expected[column].split("|"))

    # from thonny_test.test_simple_completion import *  # @UnresolvedImport

# Generated at 2022-06-22 03:10:07.106501
# Unit test for function get_definitions

# Generated at 2022-06-22 03:10:14.874009
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion('name', 'complete', 'type', 'DESCRIPTION', 'PARENT', 'FULL_NAME')
    # FIXME: write a test for the whole class
    assert c.name == 'name'
    assert c.complete == 'complete'
    assert c.type == 'type'
    assert c.description == 'DESCRIPTION'
    assert c.parent == 'PARENT'
    assert c.full_name == 'FULL_NAME'

# Generated at 2022-06-22 03:10:21.651541
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import time
    import sys
    import os
    import string

    # init
    source = "import os; os.path."
    namespaces = [{}]
    sys_path = sys.path

    # get completions
    start_time = time.time()
    completions = get_interpreter_completions(source, namespaces, sys_path)
    end_time = time.time()
    print("--- completions took %s seconds ---" % (end_time - start_time))

    # output completions
    for completion in completions:
        print(completion.name)

    # check completions
    assert len(completions) > 1  # if this is false, we possibly failed to load correct modules