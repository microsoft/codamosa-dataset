

# Generated at 2022-06-22 03:00:12.177851
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import Project
    from jedi.api.helpers import get_script, Script
    from jedi.parser.python import parse
    from parso.python import tree

    filename = "test_script.py"
    row = 2
    column = 2

    script = get_script(source="x = 123\nx.", row=row, column=column, path=filename)
    # print(script.completions())
    # print(get_script_completions(source="x = 123\nx.", row=row, column=column, filename=filename))
    # import inspect
    # print(inspect.getsource(Script))
    print(script.path)
    print(Script.__dict__)
    print(Script.get_parser(script))

# Generated at 2022-06-22 03:00:18.474260
# Unit test for function parse_source
def test_parse_source():
    res = parse_source("import math")
    assert hasattr(res, "children")
    assert len(res.children) == 1
    assert res.start_pos == 0
    assert res.end_pos == 16
    assert res.children[0].end_pos == 16
    assert res.children[0].start_pos == 0
    assert res.children[0].type == "import_from"


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:00:28.636155
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso import parse
    import jedi.parser_utils
    good_node = parse("(x + y)")
    good_pos = 1 # corresponds to start of the first child, i.e. "x"
    assert tree.ExprStmt(good_node, good_pos, good_pos) == get_statement_of_position(good_node, good_pos)
    # copied function
    assert tree.ExprStmt(good_node, good_pos, good_pos) == _copy_of_get_statement_of_position(good_node, good_pos)
    
    bad_node = parse("x + y")
    bad_pos = 1 # pos within `x`
    assert get_statement_of_position(bad_node, bad_pos) == None
   

# Generated at 2022-06-22 03:00:36.029931
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name = "name",
        complete = "complete",
        type = "type",
        description = "description",
        parent = "parent",
        full_name = "full_name",
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:00:43.625006
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from thonny.misc_utils import normalize_text
    from parso.python.tree import Function, Class, ForFlow, Imports, Alias
    from parso.python import tree
    from parso.python.parser import PythonParser
    from parso.python.diff import ParserDiff
    import jedi
    import jedi.parser_utils

    if jedi.__version__ < "0.17.0":
        print("Skipping because of old jedi version")
        return

    # Create example source

# Generated at 2022-06-22 03:00:51.932112
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from unittest import TestCase
    from parso.python import tree

    class _St(TestCase):

        def assert_node_type(self, node, types):
            return self.assertIsInstance(node, types)

    def get_node(code):
        return parse_source(code)

    source = """if True:
    if test:
        x = 42
        y = 43
    else:
        x = 44
        y = 45
x = 46
"""
    assert_nodes_equal = _St().assertEqual


# Generated at 2022-06-22 03:01:04.584358
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import Project
    from jedi.api.environment import InterpreterEnvironment
    from jedi.api.interpreter import Interpreter
    from jedi import Interpreter as JInterpreter
    from parso import parse
    import os
    import unittest
    import sys
    import importlib
    import inspect

    try:
        import jedidebug
    except ImportError:
        jedidebug = None

    class CompletionsTest(unittest.TestCase):
        def setUp(self):
            # Get the python interpreter to run this test.
            self.python_interpreter = os.path.dirname(sys.executable)
            self.python_interpreter_dir = os.path.dirname(sys.executable)

            # Needed for running jedibackend

# Generated at 2022-06-22 03:01:08.266346
# Unit test for function get_definitions
def test_get_definitions():
    source = """
a = 1
b = a
"""
    defs = get_definitions(source, 3, 0, "")
    assert len(defs) == 1
    assert defs[0].line == 1



# Generated at 2022-06-22 03:01:19.534579
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi
    import jedi.parser_utils
    import jedi.api.helpers

    def _get_statements(source):
        module = parso.parse(source)
        return jedi.api.helpers._get_statements(module)

    source = """\
if __name__ == '__main__':
    print("Start")
    print("Hello")
    """
    expected_output = [
        (1, "if __name__ == '__main__':"),
        (2, "print('Start')"),
        (3, "print('Hello')"),
    ]

    for func in [_get_statement_of_position, _copy_of_get_statement_of_position]:
        for position in range(len(source)):
            node = get_statement_of_

# Generated at 2022-06-22 03:01:23.560083
# Unit test for function parse_source
def test_parse_source():
    source = "x = 123"
    result = parse_source(source)
    assert result.type == "file_input", result
    assert result.children[0].name == "x"
    assert result.children[0].value == "123"

# Generated at 2022-06-22 03:01:38.729697
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    x = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert x.__getitem__("name") == "name"
    assert x.__getitem__("complete") == "complete"
    assert x.__getitem__("type") == "type"
    assert x.__getitem__("description") == "description"
    assert x.__getitem__("parent") == "parent"
    assert x.__getitem__("full_name") == "full_name"

    # raises a KeyError for non-existing key
    try:
        x.__getitem__("key")
    except KeyError:
        return
    raise AssertionError("KeyError not raised")


# Generated at 2022-06-22 03:01:44.937179
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree
    from parso.python.diff import ChopAst
    import parso
    import jedi
    import sys
    import os.path
    import ast
    import astor
    import astdiff
    import astunparse
    import difflib
    import traceback
    import io

    # Generate the code
    code = (
        "from tkinter import *\n"
        "def f():\n"
        "    root = Tk()\n"
        '    Button(root, text="Press me").pack(fill=X)\n'
        "    root.mainloop()\n"
        "\n"
        "f()\n"
    )


# Generated at 2022-06-22 03:01:49.821125
# Unit test for function get_script_completions
def test_get_script_completions():
    def _test_jedi_version(_using_older_jedi, expected_result):
        import jedi
        import types
        import unittest.mock

        with unittest.mock.patch.object(jedi, "__version__", "0.19"):
            with unittest.mock.patch.object(jedi, "_using_older_jedi", lambda : _using_older_jedi):
                result = get_script_completions("print('hello')", 0, 5, "")
                assert result == expected_result

    _test_jedi_version(False, [ThonnyCompletion(name="print", complete="rint", type="statement", description="", parent="", full_name="print")])

# Generated at 2022-06-22 03:01:54.428037
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # creating an object using constructor
    obj = ThonnyCompletion('ABC', 'ABC', 'def', 'GHI', 'JKL', 'MNO')
    # checking for values
    assert obj.name == 'ABC'
    assert obj.complete == 'ABC'
    assert obj.type == 'def'
    assert obj.description == 'GHI'
    assert obj.parent == 'JKL'
    assert obj.full_name == 'MNO'

# Generated at 2022-06-22 03:02:03.806072
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    import parso.python.parser as parser
    import parso.python.diff as diff
    import parso.utils as utils
    import parso.cache as cache

    def _create_node(source, start, end):
        grammar = cache.get_grammar()
        builder = utils.BuilderWithRecovery(grammar)
        builder.start = start
        builder.end = end
        builder.end_pos = end
        builder.module_node = parser.parse(source, error_recovery=True, start_symbol='file_input')
        node = builder.module_node.children[0]
        assert isinstance(node, tree.Operator)
        return node


# Generated at 2022-06-22 03:02:14.083587
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]

    source = "import math; math.sqrt(4)"
    row = 1
    column = 15
    filename = "my_module.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].raw_doc == 'sqrt(${1:num}); sqrt(x)\n\nReturn the square root of x.'

    assert hasattr(definitions[0], "in_builtin_module")
    assert definitions[0].in_builtin_module == True

# Generated at 2022-06-22 03:02:20.576310
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name='name', complete='complete', type='type', description='desc', parent='parent', full_name='full_name')
    assert completion['name'] == 'name'
    assert completion['complete'] == 'complete'
    assert completion['type'] == 'type'
    assert completion['description'] == 'desc'
    assert completion['parent'] == 'parent'
    assert completion['full_name'] == 'full_name'

test_ThonnyCompletion()

# Generated at 2022-06-22 03:02:26.455258
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions(
        """import math\n""", [{"math": math}]
    )

    assert len(completions) > 10
    assert completions[0].full_name == "__builtins__.abs"
    assert completions[0].name == "abs"
    # NB! This test case is important to detect that we have fixed the issue
    assert completions[0].complete == "abs("
    assert completions[1].description == "Return the sine of x (measured in radians)."
    assert completions[1].name == "sin"
    assert completions[1].complete == "sin("
    assert completions[1].full_name == "math.sin"


# test for function get_script_completions

# Generated at 2022-06-22 03:02:28.310762
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.parser import ParserSyntaxError


# Generated at 2022-06-22 03:02:39.235536
# Unit test for function get_definitions
def test_get_definitions():
    text = """
    class TestClass(object):
        def test_method(self):
            a = 5
            b = "abc"
            c = [1, 2, 3]
            d = {'a': 1, 'b': 2}
            e = (1, 2, 3)
            f = set([1, 2, 3])
            g = set()
            h = frozenset([1, 2, 3])
            i = bytearray([1, 2, 3])

            a.
            b.
            c.
            d.
            e.
            f.
            g.
            h.
            i.

            class NestedClass(object):
                pass

            class NestedClass2(object):
                pass

            NestedClass.
            NestedClass2.
    """

    # Find references

# Generated at 2022-06-22 03:02:57.413254
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from types import FunctionType
    completion = ThonnyCompletion('name', 'complete', FunctionType, 'description', 'parent', 'full_name')
    assert completion['name'] == 'name'
    assert completion['complete'] == 'complete'
    assert completion['type'] == FunctionType
    assert completion['description'] == 'description'
    assert completion['parent'] == 'parent'
    assert completion['full_name'] == 'full_name'

# Generated at 2022-06-22 03:03:10.052585
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_unique_named_stmt

    source = """\
import os

print(os.path.abspath)
print(os.path.join)
print(b)
print(d)
print(e)
print(g)
print(h)
"""
    completions = get_interpreter_completions(
        source,
        [{"os": None, "a": 1, "b": None, "d": 2, "e": 3, "g": 4, "h": None}],
        # sys_path=[os.path.join(os.path.dirname(__file__), "third-party")]
    )
    assert len(completions) == 2
    assert [c.name for c in completions] == ["join", "abspath"]


# Generated at 2022-06-22 03:03:18.797205
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    """
    In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions, since 0.16 it does.
    Need to ensure similar result for all supported versions.
    """
    source = "import sys; sys.stdin."
    row = 0
    column = len(source)
    namespaces = []
    s = get_interpreter_completions(source, namespaces)
    sub_s = s[3]
    assert sub_s.name == "fileno=()"
    if not _using_older_jedi(jedi):
        assert sub_s.complete == "fileno="



# Generated at 2022-06-22 03:03:23.851072
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("name", "complete", "type", "desc", "parent", "full_name")
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "desc"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-22 03:03:29.643970
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("name", "comp", "type", "descr", "parent", "full_name")
    assert tc.name == "name"
    assert tc.complete == "comp"
    assert tc.type == "type"
    assert tc.description == "descr"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-22 03:03:39.202814
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    data=ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert data.name=="name"
    assert data.complete=="complete"
    assert data.type=="type"
    assert data.description=="description"
    assert data.parent=="parent"
    assert data.full_name=="full_name"
    assert data["name"]=="name"
    assert data["complete"]=="complete"
    assert data["type"]=="type"
    assert data["description"]=="description"
    assert data["parent"]=="parent"
    assert data["full_name"]=="full_name"

# Generated at 2022-06-22 03:03:45.267926
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.config import test_dir
    from os.path import join

    source = open(join(test_dir, "data", "test_script.py")).read()
    completions = get_script_completions(source, 1, 1, "test.py")

    assert len(completions) >= 1
    assert all(isinstance(c, ThonnyCompletion) for c in completions)



# Generated at 2022-06-22 03:03:56.150484
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from parso.python import tree

    """
    tests for the `get_definition()` function.
    """

    def assert_defs(s, defs):
        """
        helper function to test definitions from source s and a list of strings defs
        """
        n = parso.parse(s)
        classes, funcdefs, vars = n.iter_classdefs(), n.iter_funcdefs(), n.iter_vars()
        names = list()
        for x in (classes, funcdefs, vars):
            for y in x:
                names.append(y.name.value)
        start = n.get_first_leaf().start_pos
        completions = get_definitions(n.as_string(), 1, 1)

# Generated at 2022-06-22 03:04:01.493765
# Unit test for function parse_source
def test_parse_source():
    # pylint: disable=assignment-from-no-return
    assert parse_source("def f(x):\n    return x\n") is not None
    assert parse_source("x = 1\n") is not None
    assert parse_source("for x in l: pass\n") is not None



# Generated at 2022-06-22 03:04:09.721665
# Unit test for function get_script_completions
def test_get_script_completions():
    # jedi>=0.18 ---------------------------------------------------------------
    from tag import __version__
    from tag.test import TagTest
    from thonny.setup import init_builtins
    from thonny.shell import Shell

    shell_backend = Shell(builtins=init_builtins())
    test = TagTest(
        "def f()\n"
        "\n"
        "def g\n"
        "g()\n"
        "def n\n"
        "n()\n",
        "f()",
        ["f()", "g()"],
        "def f()",
        get_script_completions,
        shell_backend,
    )
    test.run()

    # jedi<0.18 -----------------------------------------------------------------
    shell_backend = Shell(builtins=init_builtins())

# Generated at 2022-06-22 03:04:31.252860
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:36.989811
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import re; re."
    namespaces = [{"re": __import__("re")}]
    completions = get_interpreter_completions(source, namespaces)
    completion_names = [c.name for c in completions]
    assert "findall" in completion_names



# Generated at 2022-06-22 03:04:37.991729
# Unit test for function get_definitions

# Generated at 2022-06-22 03:04:48.053587
# Unit test for method __getitem__ of class ThonnyCompletion

# Generated at 2022-06-22 03:04:52.731431
# Unit test for function get_definitions
def test_get_definitions():
    source = "import kivy\nkivy.graphics"
    row = 2
    column = 16
    filename = ""
    definitions = get_definitions(source, row, column, filename)
    assert definitions[0].description == 'kivy.graphics.instructions.Instruction'


# Generated at 2022-06-22 03:05:00.796166
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # create a completion
    tmp = ThonnyCompletion("name", "complete", "t", "desc", "parent", "full")
    assert tmp.__getitem__("name") == tmp.name
    assert tmp.__getitem__("complete") == tmp.complete
    assert tmp.__getitem__("type") == tmp.type
    assert tmp.__getitem__("description") == tmp.description
    assert tmp.__getitem__("parent") == tmp.parent
    assert tmp.__getitem__("full_name") == tmp.full_name

# Generated at 2022-06-22 03:05:06.517824
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    def verify_definitions(source, row, col, expected_definitions):
        definitions = get_definitions(source, row, col, "")
        assert len(definitions) == len(expected_definitions)

        for i in range(len(definitions)):
            actual_def = definitions[i]
            expected_def = expected_definitions[i]

            assert isinstance(actual_def, Definition)
            # todo: verify other attributes
            assert actual_def.line == expected_def[0]
            assert actual_def.column == expected_def[1]
            assert actual_def.module_path == expected_def[2]

    verify_definitions("foo = 'bar'\nprint(foo)", 1, 5, [(0, 0, "")])
    verify

# Generated at 2022-06-22 03:05:16.785856
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    variable = Completion(
        name="a",
        complete="a",
        type="Variable",
        module_name="",
        description="",
        full_name="a",
        docstring="",
        defined_names=[],
        parent=None,
    )

    completion = ThonnyCompletion(
        name=variable.name,
        complete=variable.complete,
        type=variable.type,
        description=variable.description,
        parent=variable.parent,
        full_name=variable.full_name,
    )

    assert completion.name == variable.name
    assert completion.complete == variable.complete
    assert completion.type == variable.type
    assert completion.description == variable.description
    assert completion.parent == variable.parent
    assert completion.full

# Generated at 2022-06-22 03:05:17.193506
# Unit test for function parse_source

# Generated at 2022-06-22 03:05:28.985255
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        d = jedi.Script("st.r").completions()[0]._name.tree_name._definition
    else:
        d = jedi.Script("import string\nstring.ascii_lowercase").completions()[0]._name.tree_name._definition

    tc = ThonnyCompletion(
        name=d.name.value,
        complete=d.name.value,
        type=d.type,
        description=d._description,
        parent=d.parent,
        full_name=d._name.full_name,
    )

    assert isinstance(tc.name, str)

# Generated at 2022-06-22 03:06:07.672849
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

# Generated at 2022-06-22 03:06:08.821562
# Unit test for function get_definitions

# Generated at 2022-06-22 03:06:13.908116
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    source = """class A(): pass
A().app"""
    namespaces = Interpreter(source, []).namespaces()
    print(namespaces)
    assert get_interpreter_completions(source=source, namespaces=namespaces, sys_path=[])

# Generated at 2022-06-22 03:06:16.690133
# Unit test for function parse_source
def test_parse_source():
    source: str = """def foo():
    pass
    """
    problem_node = parse_source(source)
    assert problem_node # test for correct parsing


# Generated at 2022-06-22 03:06:24.275036
# Unit test for function get_script_completions
def test_get_script_completions():
    from textwrap import dedent

    code = dedent(
        """
    import sympy
    sympy.
    """
    )
    completions = get_script_completions(code, 3, 1, "test_code.py")

# Generated at 2022-06-22 03:06:30.270162
# Unit test for function parse_source
def test_parse_source():
    code = """def test():
    a = 1
    b = 1
    """
    module = parse_source(code)
    for stmt in module.iter_funcdefs():
        if stmt.name.value == "test":
            assert stmt.type == "funcdef"
            assert stmt.get_code() == code


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:06:40.434337
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    completion = Completion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    thonnycompletion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')

    assert completion.name == thonnycompletion.name
    assert completion.complete == thonnycompletion.complete
    assert completion.type == thonnycompletion.type
    assert completion.description == thonnycompletion.description
    assert completion.parent == thonnycompletion.parent
    assert completion.full_name == thonnycompletion.full_name

# Generated at 2022-06-22 03:06:41.664493
# Unit test for function parse_source
def test_parse_source():
    source: str = "import th"
    parse_source(source)

# Generated at 2022-06-22 03:06:42.244748
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:06:52.948908
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    import jedi

    __name__ = "thonny.jedii"
    try:
        from thonny.jedi import get_interpreter_completions
    except (ImportError, FileNotFoundError):
        from jedi import get_interpreter_completions
    try:
        from thonny.jedi import _get_new_jedi_project
    except (ImportError, FileNotFoundError):
        from jedi._compatibility import _get_new_jedi_project


# Generated at 2022-06-22 03:07:42.480130
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import SourceField

    completions = get_script_completions(
        "import datetime; datetime.date", 1, len("import datetime; datetime."), "/"
    )
    assert len(completions) == 1
    assert completions[0].type == "module"

    completions = get_script_completions(
        "import datetime; datetime.date", 1, len("import datetime; datetime.d"), "/"
    )
    assert len(completions) == 4
    assert [c.type for c in completions] == ["class", "class", "class", "class"]


# Generated at 2022-06-22 03:07:50.101223
# Unit test for function get_definitions
def test_get_definitions():
    import jedi as jedi

    if _using_older_jedi(jedi):
        source = "def f(): pass\nf()"
        definitions = get_definitions(source, 1, 4, "code.py")
        assert 1 == len(definitions)
        assert 'def f' == definitions[0].description
    else:
        source = "def f(): pass\nf()"
        definitions = get_definitions(source, 1, 4, "code.py")
        assert 1 == len(definitions)
        assert 'def f' == definitions[0].docstring()

# Generated at 2022-06-22 03:07:55.876383
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "from math import factorial"
    assert get_interpreter_completions(source, []) == []
    assert get_interpreter_completions(source, [{}]) == [
        ThonnyCompletion(name="factorial", complete="factorial", type="function", description="Return x factorial.", parent="module", full_name="math.factorial")
    ]



# Generated at 2022-06-22 03:08:02.300871
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"


# Generated at 2022-06-22 03:08:08.735589
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "test"
    complete = "test"
    type = "test"
    description = "test"
    parent = "test"
    full_name = "test"
    thonnyc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert thonnyc.__getitem__("name") == name

# Generated at 2022-06-22 03:08:15.585282
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    class JediTest(TestCase):
        def _run_goto(self, name, code, row, col):
            script = get_script_completions(code, row, col, "")
            completions = get_definitions(code, row, col, "")
            #assert completions[0].name == name
            #assert completions[0].full_name == name

            return completions[0].description


# Generated at 2022-06-22 03:08:16.873817
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree


# Generated at 2022-06-22 03:08:19.026207
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert isinstance(ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name'), ThonnyCompletion)

# Generated at 2022-06-22 03:08:29.983609
# Unit test for function get_definitions
def test_get_definitions():
    # type: () -> None
    from thonny import ast_utils

    defi = get_definitions(
        "for i in range(1, 5):\n    print(i)", 1, 4, "/home/thonny/workspace/test/demo.py"
    )
    assert len(defi) == 1
    d, = defi
    assert d.line == 1
    assert d.column == 4
    assert d.module_path == "/usr/lib/python3.7/builtins.py"
    assert ast_utils.get_name_with_colon(d.module_path) == "builtins:"


# Generated at 2022-06-22 03:08:36.702514
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """import sys\nimport pandas\ndf = pandas.DataFrame()\nprint(df.)\n"""
    namespaces = [{"name": "__main__", "path": "__main__", "namespace": {}}]
    got_completions = get_interpreter_completions(source, namespaces, sys_path=["."])
    assert "to_dict" in [c.name for c in got_completions]
