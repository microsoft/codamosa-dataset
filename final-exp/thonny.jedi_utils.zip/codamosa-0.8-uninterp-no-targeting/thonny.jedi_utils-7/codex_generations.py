

# Generated at 2022-06-22 03:01:04.326721
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions("", [])
    assert len(result) > 20



# Generated at 2022-06-22 03:01:06.479571
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from collections import def"
    completions = get_script_completions(source, 1, 27, "test")
    assert completions[0].complete == "defaultdict"


# Generated at 2022-06-22 03:01:07.126728
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:01:10.198366
# Unit test for function get_script_completions
def test_get_script_completions():
    _test_versioned(get_script_completions)


# Generated at 2022-06-22 03:01:16.808529
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
  testObject = ThonnyCompletion('testName', 'testComplete', 'testType', 'testDescription', 'testParent', 'testFullName')
  testObject.name == 'testName'
  testObject.complete == 'testComplete'
  testObject.type == 'testType'
  testObject.description == 'testDescription'
  testObject.parent == 'testParent'
  testObject.full_name == 'testFullName'
  assert testObject.name != 'testName1'
  assert testObject.complete != 'testComplete1'
  assert testObject.type != 'testType1'
  assert testObject.description != 'testDescription1'
  assert testObject.parent != 'testParent1'
  assert testObject.full_name != 'testFullName1'
  assert isinstance(testObject, ThonnyCompletion)

# Generated at 2022-06-22 03:01:25.973282
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_get_script_completions(self):
            from os.path import dirname, join

            source = open(
                join(dirname(__file__), "completion_utils.py")
            ).read()
            completions = get_script_completions(source=source, row=3, column=9, filename=__file__)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "get_statement_of_position")

    main()


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-22 03:01:34.599273
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test function with older version of jedi
    from thonny.jedi_utils import ThonnyCompletion
    from thonny.jedi_utils import get_script_completions

    # Test 'print' as complete attribute
    script = get_script_completions(source="print", row=0, column=5, filename="")
    complete = [elem.complete for elem in script]
    assert "print" in complete

    # Test '__import__' as complete attribute
    script = get_script_completions(source="__import__", row=0, column=10, filename="")
    complete = [elem.complete for elem in script]
    assert "__import__" in complete

    # Test 'int' as complete attribute

# Generated at 2022-06-22 03:01:47.806614
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    assert parse_source('').type == 'file_input'
    assert isinstance(parse_source('funcdef'), tree.Funcdef)
    assert isinstance(parse_source('classdef'), tree.ClassDef)
    assert isinstance(parse_source('if 1: pass'), tree.IfStmt)
    assert isinstance(parse_source('for x in range(10): pass'), tree.ForStmt)
    assert isinstance(parse_source('while True: pass'), tree.WhileStmt)
    assert isinstance(parse_source('try: pass'), tree.TryStmt)
    assert isinstance(parse_source('with open(): pass'), tree.WithStmt)
    assert isinstance(parse_source('await x'), tree.Operand)

# Generated at 2022-06-22 03:01:51.612242
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script, __version__

# Generated at 2022-06-22 03:02:01.948483
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_statement_of_position

    # Test for jedi==0.13.1
    source1 = "import re; re.f"
    namespaces1 = [{"re": re}]

    completions = get_interpreter_completions(source1, namespaces1)
    assert len(completions) == 3

    source2 = "import re; re"
    namespaces2 = [{"re": re}]

    completions = get_interpreter_completions(source2, namespaces2)
    assert len(completions) == 1

    # Test for jedi==0.18.0
    source3 = "import re; re.f"
    namespaces3 = [{"re": re}]


# Generated at 2022-06-22 03:02:22.139267
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    import jedi

    class CompletionTest(TestCase):
        def test_completions(self):
            actual = get_script_completions("import sys", 1, 7, "dummy.py")
            self.assertEqual(
                [c.name for c in actual], ["sys"], "Completions are not working on single word"
            )

            actual = get_script_completions("import sys; sys.pa", 2, 9, "dummy.py")
            self.assertIn(
                "sys.path",
                [c.name for c in actual],
                "Completions are not working on qualified name",
            )

            actual = get_script_completions("import sys; sys.path.ap", 2, 15, "dummy.py")
            self

# Generated at 2022-06-22 03:02:27.152792
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree
    test_source = "import numpy\nnp.array([1, 2, 3])"
    tree = parse_source(test_source)
    assert isinstance(tree, parso.python.tree.Module) == True

# Generated at 2022-06-22 03:02:36.788542
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    Function to test the default behavior of get_interpreter_completions() -
    to check completions when no sys_path argument is given.
    """
    # if the jedi version is older than 0.17, the function will work with sys_path
    # argument hence, the function will work without testing
    import jedi

    if _using_older_jedi(jedi):
        return

    from thonny.backend import jedi_utils

    source = "import math\nmath."
    row, column = 1, 8
    namespaces = [{"x": 3, "y": 4}, {"x": 5, "y": 6, "a": [1, 2, 3], "math": math}]

# Generated at 2022-06-22 03:02:42.619267
# Unit test for function parse_source
def test_parse_source():
    try:
        import parso
    except ImportError:
        print("Test skipped")
        return

    assert parse_source("print('Hello')").type == "file_input"


# Generated at 2022-06-22 03:02:43.495132
# Unit test for function parse_source
def test_parse_source():
    parse_source('2 + 2')

# Generated at 2022-06-22 03:02:50.495177
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert _using_older_jedi(jedi)

    import dis

    completions = get_interpreter_completions("dis.", [{"name": "dis", "value": dis}])
    assert len(completions) > 0
    assert "dis_" in [c.complete for c in completions]
    assert "dis_" in [c.name for c in completions]
    assert "dis." in [c.full_name for c in completions]



# Generated at 2022-06-22 03:03:01.703895
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import api
    completion = api.Completion("some_name", "some_name_complete", "some_type", "some_desription", "some_parent", "some_full_name")
    thonnyCompletion = ThonnyCompletion("some_name", "some_name_complete", "some_type", "some_desription", "some_parent", "some_full_name")
    assert completion.name == thonnyCompletion.name
    assert completion.complete == thonnyCompletion.complete
    assert completion.type == thonnyCompletion.type
    assert completion.description == thonnyCompletion.description
    assert completion.parent == thonnyCompletion.parent
    assert completion.full_name == thonnyCompletion.full_name

# Generated at 2022-06-22 03:03:03.534297
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree


# Generated at 2022-06-22 03:03:06.161897
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree
    import unittest.mock as mock


# Generated at 2022-06-22 03:03:11.011488
# Unit test for function parse_source
def test_parse_source():
    """Ensure that the function parse_source returns a ParseNode object"""
    import parso
    code = "def foo(): pass"
    node = parse_source(code)
    assert isinstance(node, parso.python.tree.Module)

# Generated at 2022-06-22 03:03:39.707108
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os

    tkinter_path = None
    for path in os.environ.get("PYTHONPATH", "").split(os.pathsep):
        path = path.strip()
        if path.endswith(os.sep + "tkinter"):
            tkinter_path = path
            break

    source = "from tkinter import "
    namespaces = [{}, {"path": tkinter_path}]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-22 03:03:41.662187
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module

# Generated at 2022-06-22 03:03:50.400709
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "test_name"
    complete = "test_complete"
    type = "test_type"
    description = "test_description"
    parent = "test_parent"
    full_name = "test_name"

    completion = ThonnyCompletion(
        name=name, complete=complete, type=type, description=description, parent=parent, full_name=full_name
    )

    assert completion.name == name
    assert completion.complete == complete
    assert completion.type == type
    assert completion.description == description
    assert completion.parent == parent
    assert completion.full_name == full_name

# Generated at 2022-06-22 03:03:54.347814
# Unit test for function parse_source
def test_parse_source():
    import parso

    a = parse_source("import s\ndef k():\n    s")
    b = parso.parse("import s\ndef k():\n    s")
    assert a.equals(b)



# Generated at 2022-06-22 03:04:06.145117
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    source = "import sys"

    script = Script(source)
    completion = script.completions()[0]
    thonnyCompletion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )
    assert completion.name == thonnyCompletion.name
    assert completion.complete == thonnyCompletion.complete
    assert completion.type == thonnyCompletion.type
    assert completion.description == thonnyCompletion.description
    assert completion.parent == thonnyCompletion.parent
    assert completion.full_name == thonnyCompletion.full_name

# Generated at 2022-06-22 03:04:12.638609
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = 'def foo(a, b=2, *c, d="hello", e=None, f, **z):'
    module = parse_source(source)
    assert isinstance(module, parso.python.tree.Module)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:04:16.982317
# Unit test for function parse_source
def test_parse_source():
    # jedi version 0.17.0
    assert parse_source("def f(x=1)")[0].type == "simple_stmt"

    # jedi version 0.17.1
    assert parse_source("def f(x=1)")[0].type in ("funcdef", "async_funcdef")

# Generated at 2022-06-22 03:04:28.176236
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import unittest
    import jedi

    version = jedi.__version__
    if version[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        test_cases = [
            ("", "", "", "", "", ""),
            ("name", "complete", "type", "description", "parent", "full_name"),
            ("name", "complete", 123, "description", "parent", "full_name"),
            ("name", "complete", "type", 123, "parent", "full_name"),
            ("name", "complete", "type", "description", 123, "full_name"),
            ("name", "complete", "type", "description", "parent", 123),
        ]

# Generated at 2022-06-22 03:04:37.762996
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import json

    test_data = {
        "name": "object",
        "complete": "object",
        "type": "class",
        "description": "The most base type",
        "parent": "object",
        "full_name": "builtins.object",
    }

    test_json = json.dumps(test_data)
    test_json_obj = json.loads(test_json)

    obj = ThonnyCompletion(**test_json_obj)
    assert obj.name == test_data["name"], "constructor of class ThonnyCompletion failed"

# Generated at 2022-06-22 03:04:47.590877
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    """
    This function tests the constructor of the ThonnyCompletion class.
    """
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    # Test the name
    assert completion["name"] == "name"
    # Test the complete
    assert completion["complete"] == "complete"
    # Test the type
    assert completion["type"] == "type"
    # Test the description
    assert completion["description"] == "description"
    # Test the parent
    assert completion["parent"] == "parent"
    # Test the full_name
    assert completion["full_name"] == "full_name"


# Generated at 2022-06-22 03:05:16.142473
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    t = ThonnyCompletion(name=name, complete=complete, type=type, description=description, parent=parent, full_name=full_name)

    assert t.name == name
    assert t.complete == complete
    assert t.type == type
    assert t.description == description
    assert t.parent == parent
    assert t.full_name == full_name



# Generated at 2022-06-22 03:05:22.480757
# Unit test for function get_definitions
def test_get_definitions():
    import datetime
    import doctest
    import jedi
    import jedi.evaluate.representation
    import parso

    try:
        version = jedi.__version__
    except:
        version = "version unknown"

    print('Executing test code for jedi version', version)


# Generated at 2022-06-22 03:05:31.938549
# Unit test for function parse_source
def test_parse_source():
    from parso.parser import ParserSyntaxError

    def parse(statement):
        return parse_source(statement)

    def get_definition(statement, pos):
        return get_statement_of_position(parse(statement), pos)

    def get_decorator(statement, pos):
        return get_definition(statement, pos).parent

    assert isinstance(parse("a=1"), tree.Module)
    assert get_definition("a=1", 2).type == "expr_stmt"
    assert get_definition("a=1", 1).type == "expr_stmt"

    assert get_definition("a=1\n", 2).type == "expr_stmt"
    assert get_definition("a=1\n", 3).type == "endmarker"


# Generated at 2022-06-22 03:05:44.381406
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    definitions = get_definitions("int", 0, 3, "")
    assert len(definitions) == 1
    assert definitions[0].name == "int"
    assert definitions[0].line == 1
    assert definitions[0].column == 2

    if _using_older_jedi(jedi):
        # with older jedi goto is defined as variable in current scope
        definitions_goto = get_definitions("x=1\ngoto", 1, 6, "")
        assert len(definitions_goto) == 1
        assert definitions_goto[0].name == "goto"
        assert definitions_goto[0].line == 1
        assert definitions_goto[0].column == 5

        # with older jedi, goto is not defined in import scope

# Generated at 2022-06-22 03:05:47.440038
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("input(", 1, 7, "input.py")
    assert len(result) == 1
    assert result[0].complete == "input(prompt=None)"


# Generated at 2022-06-22 03:05:51.963907
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    jedi = __import__('jedi')
    source = 'import re\nre.'
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)
    completions_keys = [i.name for i in completions]
    assert 'search' in completions_keys

# Generated at 2022-06-22 03:05:59.103101
# Unit test for function parse_source
def test_parse_source():
    source = "import os\nimport sys\na = 123"
    tree = parse_source(source)
    assert str(tree.children[0]) == "import_from<from:'import os'>"
    assert str(tree.children[1].children[0]) == "import_from<from:'import sys'>"
    assert str(tree.children[2].children[0]) == "expr_stmt<name:'a', value:'123'>"


# Generated at 2022-06-22 03:06:11.151284
# Unit test for function get_script_completions
def test_get_script_completions():
    def do_test(source, row, column, expected):
        completions = get_script_completions(source, row, column, "")
        matches = []
        for completion in completions:
            matches.append(completion.complete)

        assert matches == expected

    do_test('import os\nx = os.path.expanduser("~")\nx.', 2, 16, ["abspath", "expandvars"])
    do_test('x = "hello"\nx.', 1, 5, ["capitalize", "center"])
    do_test('from datetime import datetime\ndatetime.', 1, 21, ["combine", "ctime"])

# Generated at 2022-06-22 03:06:12.185387
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-22 03:06:14.059473
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import Interpreter


# Generated at 2022-06-22 03:06:38.603810
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "xyz"
    assert isinstance(parse_source(source), parso.python.tree.Module)

    source = ""
    assert isinstance(parse_source(source), parso.python.tree.Module)

# Generated at 2022-06-22 03:06:48.751835
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    parser_utils = jedi.parser_utils

# Generated at 2022-06-22 03:06:57.775065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("x.join(x for x in y)", namespaces=[]) == ["join"]
    assert get_interpreter_completions("x.join(x for x in y)", namespaces=[{"x": "str"}]) == [
        "join"
    ]
    assert get_interpreter_completions("x.join(x for x in y)", namespaces=[{"y": "list"}]) == [
        "join"
    ]
    assert get_interpreter_completions("x.join(x for x in y)", namespaces=[{"x": "str"}, {"y": "list"}]) == [
        "join"
    ]

# Generated at 2022-06-22 03:07:08.302257
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.tree import PythonNode
    test_source = """
from tkinter.constants import *
from tkinter import*
from tkinter import simpledialog
"""
    file_node = parse_source(test_source)
    assert isinstance(file_node, PythonNode)
    assert isinstance(file_node.children[0], parso.python.tree.ImportFrom)
    assert isinstance(file_node.children[1], parso.python.tree.ImportFrom)
    assert isinstance(file_node.children[2], parso.python.tree.ImportFrom)
    assert file_node.children[0].module == "tkinter.constants"
    assert file_node.children[1].module == "tkinter"

# Generated at 2022-06-22 03:07:10.821975
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "def foo(): pass"
    tree = parse_source(source)
    assert isinstance(tree, parso.python.tree.Module)



# Generated at 2022-06-22 03:07:13.386541
# Unit test for function parse_source
def test_parse_source():
    try:
        import parso
        node = parse_source('fun')
        assert isinstance(node, parso.python.tree.Module)
    except Exception:
        assert False

# Generated at 2022-06-22 03:07:22.273826
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonny_completion = ThonnyCompletion("name", "complete", "type",
                                         "description", "parent", "full_name")
    assert (thonny_completion.name == "name")
    assert (thonny_completion.complete == "complete")
    assert (thonny_completion.type == "type")
    assert (thonny_completion.description == "description")
    assert (thonny_completion.parent == "parent")
    assert (thonny_completion.full_name == "full_name")

# Generated at 2022-06-22 03:07:27.804191
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    source = 'def foo():\n    pass\n'
    parsed = parse_source(source)
    assert isinstance(parsed, tree.Module)
    assert parsed.children[0].children[0].name == 'foo'
    assert parsed.children[0].children[1].children[0].name == 'pass'

# Generated at 2022-06-22 03:07:39.260199
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import TestCase
    from unittest.mock import MagicMock

    completion = ThonnyCompletion(name="name", complete="complete", type=0, description=None, parent=None, full_name=None)
    self = TestCase
    self.assertEqual(completion.__getitem__("name"), completion.name)
    self.assertEqual(completion.__getitem__("complete"), completion.complete)
    self.assertEqual(completion.__getitem__("type"), completion.type)
    self.assertEqual(completion.__getitem__("description"), completion.description)
    self.assertEqual(completion.__getitem__("parent"), completion.parent)
    self.assertEqual(completion.__getitem__("full_name"), completion.full_name)

# Generated at 2022-06-22 03:07:51.212571
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from unittest import TestCase, main

    class TestGetInterpreterCompletions(TestCase):
        maxDiff = None

        def test_get_interpreter_completions(self):
            jedi = Mock()
            source = "import numpy as np\n" + "np.r"
            namespaces = [{"numpy": "numpy"}]

            completions = [
                Mock(full_name="numpy.random", complete="numpy.random", name="random"),
                Mock(full_name="numpy.rank", complete="numpy.rank", name="rank"),
            ]

            if _using_older_jedi(jedi):
                # NB! Does not work with older jedi
                return
            else:
                interpreter = Mock()
                interpreter

# Generated at 2022-06-22 03:09:21.708091
# Unit test for function parse_source
def test_parse_source():
    source = "import pandas as pd \n df = pd.DataFrame()"
    tokens = parse_source(source)
    assert len(tokens.children) == 2
    assert tokens.children[0].value == "import"
    assert tokens.children[1].value == "="

# Generated at 2022-06-22 03:09:24.008687
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys"
    row, column = 0, 8
    result = get_script_completions(source, row, column, filename="")
    assert len(result) > 10

# Generated at 2022-06-22 03:09:28.453636
# Unit test for function get_script_completions
def test_get_script_completions():
    import json
    import os

    script = """
    # This is a test script
    import sys
    import os
    os.
    sys"""
    output_file = "test_data/jedi_completions.json"
    row, column = 5, 5
    result_data = get_script_completions(script, row, column, "")
    print(result_data)
    with open(output_file, "w") as out_file:
        json.dump(result_data, out_file, indent=4)

    with open(output_file, "r") as in_file:
        expected_data = json.load(in_file)

    assert result_data == expected_data
    os.remove(output_file)

# Generated at 2022-06-22 03:09:29.779976
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:09:38.274400
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    original_method = getattr(jedi, "Interpreter")
    mock_method = mock.MagicMock()
    mock_method.complete.return_value = ["result"]
    setattr(jedi, "Interpreter", mock_method)

    result = get_interpreter_completions("source", 'namespaces')
    assert result == ["result"]

    result = get_interpreter_completions("source", 'namespaces', 'sys_path')
    assert result == ["result"]
    setattr(jedi, "Interpreter", original_method)

# Generated at 2022-06-22 03:09:40.485850
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import sys
sys"""

    result = get_script_completions(source, 4, 5, "file.py")
    print(result)

# Generated at 2022-06-22 03:09:51.491255
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # Test case 1
    #
    # Predefined values
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    # Expected output
    exp_name = "name"
    exp_complete = "complete"
    exp_type = "type"
    exp_description = "description"
    exp_parent = "parent"
    exp_full_name = "full_name"

    obj = ThonnyCompletion(name, complete, type, description, parent, full_name)
    # Test case 2
    #
    # Predefined values
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"


# Generated at 2022-06-22 03:10:02.872816
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check_positions(source, expected_lines):
        test_lines = []
        tree = parse_source(source)
        for line in source.splitlines():
            line += "\n"
            line_start = source.find(line)
            for pos in range(line_start, len(line) + line_start):
                node = get_statement_of_position(tree, pos)
                if node:
                    line_no = node.start_pos[0]
                else:
                    line_no = None
                test_lines.append(line_no)
        assert test_lines == expected_lines

    check_positions("def a(x):\n    return x", [None, 1, 1, 1, 1])

# Generated at 2022-06-22 03:10:07.663253
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    check_get_statement_of_position(
        """def foo(a, b):
           pass
        """,
        (13, "def foo(a, b):\n"),
    )
    check_get_statement_of_position(
        """def foo(a,
        b=1
        ):
           pass
        """,
        (22, "def foo(a,\n"),
    )
    check_get_statement_of_position(
        """def foo(a, b):
           pass
        """,
        (2, ""),
    )
    check_get_statement_of_position(
        """def foo(a, b):
           pass
        """,
        (20, "def foo(a, b):\n"),
    )

# Generated at 2022-06-22 03:10:17.368978
# Unit test for function get_definitions
def test_get_definitions():
    # Note: function definition must begin and end with triple single quotes
    script_source = """
    def func(a):
        '''
        Tripple single quoted doc string
        '''
        print(a)
               
    if __name__ == "__main__":
        func('''Hello''')
    """
    script_row = 4
    script_column = 12
    script_filename = "test.py"
    defs = get_definitions(script_source, script_row, script_column, script_filename)
    # Assert correct number of functions found
    assert len(defs) == 1
    # Assert correct function found
    assert defs[0].name == "func"
    return