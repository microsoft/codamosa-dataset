

# Generated at 2022-06-22 03:01:14.551443
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:01:18.802378
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion(): 
    thonny_completion = ThonnyCompletion(
                                        name = "name",
                                        complete = "complete",
                                        type = "type",
                                        description = "description",
                                        parent = "parent",
                                        full_name = "full_name",
                                        )

    assert thonny_completion.name == "name"
    assert thonny_completion.complete == "complete"
    assert thonny_completion.type == "type"
    assert thonny_completion.description == "description"
    assert thonny_completion.parent == "parent"
    assert thonny_completion.full_name == "full_name"

# Generated at 2022-06-22 03:01:19.701606
# Unit test for function get_definitions

# Generated at 2022-06-22 03:01:29.772131
# Unit test for function get_definitions
def test_get_definitions():
    source_code = """import json
json.dump("a", "b")
"""

    if _using_older_jedi("jedi"):
        def expect(d):
            assert len(d) == 1
            assert d[0].description.startswith("Builtin function")
    else:
        def expect(d):
            assert len(d) == 2
            assert d[0].description.startswith("json.JSONEncoder")
            assert d[1].description.startswith("Builtin function")

    expect(get_definitions(source_code, 1, 0, "/blah.py"))
    expect(get_definitions(source_code, 2, 4, "/blah.py"))
    expect(get_definitions(source_code, 2, 6, "/blah.py"))

# Generated at 2022-06-22 03:01:37.162271
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Test for function get_script_completions.
    """
    import jedi
    from thonny.plugins.micropython.jedi_utils import get_script_completions

    filename = "script.py"

    # Test case 1:
    # script.py:
    #     '''
    #     """
    #     Test simple statement.
    #     """
    #     '''
    #
    #     print('hello')
    #
    source = """
    '''
    \"\"\"
    Test simple statement.
    \"\"\"
    '''

    print('hello')
    """
    (row, column) = (5, 7)
    result = get_script_completions(source, row, column, filename)
    assert result[0].name == "print"


# Generated at 2022-06-22 03:01:41.728695
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = ThonnyCompletion("my_name", "my_complete", "my_type", "my_description", "my_parent", "my_full_name")
    assert complete.name == "my_name"
    assert complete.complete == "my_complete"
    assert complete.type == "my_type"
    assert complete.description == "my_description"
    assert complete.parent == "my_parent"
    assert complete.full_name == "my_full_name"

# Generated at 2022-06-22 03:01:51.416752
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys
    import jedi

    script = """import os
import sys

# this is the test line
os.
"""
    row = 5
    column = 7
    folder = os.path.dirname(__file__)
    filename = os.path.join(folder, "test.py")
    f = open(filename, "w")
    f.write(script)
    f.close()

    # Run the test
    completions = get_interpreter_completions(script, [locals(), globals()], sys_path=[folder])
    # Make sure that the test completed
    count = 0
    for completion in completions:
        if completion.name == "pathsep":
            count = 1
            break
    assert count == 1

    # Remove the test file
    os.remove

# Generated at 2022-06-22 03:02:01.790465
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    import jedi
    from .jedi_utils import get_definitions

    this_file_path = os.path.abspath(__file__)
    cwd = os.path.dirname(this_file_path)
    filename = os.path.join(cwd, "tester.py")


# Generated at 2022-06-22 03:02:12.410461
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest.mock import MagicMock
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = MagicMock()
    parent.full_name.return_value = "parent_full_name"
    full_name = "full_name"
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc['name'] == name
    assert tc['complete'] == complete
    assert tc['type'] == type
    assert tc['description'] == description
    assert tc['parent'] == parent
    assert tc['full_name'] == full_name

# Generated at 2022-06-22 03:02:23.362529
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class FakeJediCompletion:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    expected = "X"
    fake_jedi_completion = FakeJediCompletion(
        name="Y",
        complete="Z",
        type="A",
        description="B",
        parent="C",
        full_name="D",
    )


# Generated at 2022-06-22 03:02:43.488582
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.common import splitlines
    from jedi.parser_utils import get_cached_code_lines
    import parso
    from parso.python.parser import PythonParser
    from parso.tree import SearchScope
    from parso.pgen2 import tokenize

    code = """
if True:
    print(x)
    if True:
        pass # cursor here
    y = 3
    pass
"""

    node = parse_source(code)
    cursor_line = splitlines(code)[5]
    cursor_offset = cursor_line.index("# cursor here")
    assert cursor_line.strip() == "# cursor here"

    target_node = get_statement_of_position(node, cursor_offset)

    if sys.version_info < (3, 6):
        expected_line_no = 5


# Generated at 2022-06-22 03:02:52.826249
# Unit test for function get_definitions
def test_get_definitions():
    def assert_is_correct(source, row, col, filename, need_count):
        definitions = get_definitions(source, row, col, filename)
        assert len(definitions) == need_count, "source:{}\nrow:{}\ncol:{}\nfilename:{}\n{}".format(
            source, row, col, filename, definitions
        )

    assert_is_correct(
        "a = 'test'\na", 1, 0, "test.py", 8
    )  # test for completion for variable in the same file
    assert_is_correct(
        "import os\nos.path.join", 2, 0, "test.py", 4
    )  # test for completion for variable imported from other file

# Generated at 2022-06-22 03:02:59.273456
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("import sys; sys.getdefaultencoding()", 0, 0, "<string>")) > 0
    assert len(get_definitions("sys.getdefaultencoding()", 0, 0, "<string>")) > 0
    assert len(get_definitions("sys.getdefaultencoding", 0, 0, "<string>")) > 0
    assert len(get_definitions("os.path.abspath", 0, 0, "<string>")) > 0



# Generated at 2022-06-22 03:03:12.028936
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """def f(a, b, c):
    pass"""
    namespaces = [{"a": 1, "c": 3}]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "f("
    assert completions[0].complete == "f("
    assert completions[0].type == "function"
    assert completions[0].parent == "function"
    assert completions[0].full_name == "f"
    assert completions[0].description == "f(a, b, c) -> None"

    # This only works when there is a function, otherwise it remains "object"
    assert completions[1].parent == "function"

    # This only works when there is a function, otherwise it

# Generated at 2022-06-22 03:03:18.760795
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_object = ThonnyCompletion(name='name', complete='complete', type=1, description='description', parent='parent', full_name='full_name')
    assert test_object['name'] == 'name'
    assert test_object['complete'] == 'complete'
    assert test_object['type'] == 1
    assert test_object['description'] == 'description'
    assert test_object['parent'] == 'parent'
    assert test_object['full_name'] == 'full_name'




# Generated at 2022-06-22 03:03:24.180247
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name = "x", complete = "x", type = "", description = "", parent = "", full_name = "")
    assert tc["name"] == "x"
    assert tc["complete"] == "x"
    assert tc["type"] == ""
    assert tc["description"] == ""
    assert tc["parent"] == ""
    assert tc["full_name"] == ""



# Generated at 2022-06-22 03:03:32.758562
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(
        name = 'a name',
        complete = 'a completion',
        type = 'an type',
        description = 'a description',
        parent = 'a parent',
        full_name = 'a full name'
    ).__dict__ == {
        'name': 'a name',
        'complete': 'a completion',
        'type': 'an type',
        'description': 'a description',
        'parent': 'a parent',
        'full_name': 'a full name'
    }

# Generated at 2022-06-22 03:03:43.452167
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from unittest.mock import Mock
    import jedi

    # Completions of a list of namespaces
    completions = get_interpreter_completions("", [globals(), locals()])
    expected_completions = [
        ThonnyCompletion("abs", "abs", "function", "abs(number) -> number", "", "abs"),
        ThonnyCompletion("all", "all", "function", "all(iterable) -> bool", "", "all"),
    ]
    assert completions[:2] == expected_completions

    # Completions of a single namespace
    completions = get_interpreter_completions("", [globals()])

# Generated at 2022-06-22 03:03:50.401994
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    assert ThonnyCompletion(
        name="name",
        complete="name",
        type=jedi.api.classes.Class,
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert ThonnyCompletion(
        name="name=", complete="name=", type="type", description="description", parent="parent", full_name="full_name",
    )

# Generated at 2022-06-22 03:03:58.753831
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    class DummyCompletion:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    tc = ThonnyCompletion(
        name="name1",
        complete="complete1",
        type="type1",
        description="description1",
        parent="parent1",
        full_name="full_name1",
    )
    dc = DummyCompletion(
        name="name2",
        complete="complete2",
        type="type2",
        description="description2",
        parent="parent2",
        full_name="full_name2",
    )


# Generated at 2022-06-22 03:04:34.717735
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    a = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    assert a["name"] == "a"
    assert a["complete"] == "b"
    assert a["type"] == "c"
    assert a["description"] == "d"
    assert a["parent"] == "e"
    assert a["full_name"] == "f"

# Generated at 2022-06-22 03:04:37.109072
# Unit test for function get_statement_of_position

# Generated at 2022-06-22 03:04:47.370544
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import ExprStmt

    node = parse_source("x = 1")
    assert isinstance(get_statement_of_position(node, 0), ExprStmt)

    node = parse_source("x = 1\n\n")
    assert isinstance(get_statement_of_position(node, 0), ExprStmt)

    node = parse_source("x = 1\n\n\n")
    assert get_statement_of_position(node, 0) is None

    node = parse_source("x = 1\n\n\nprint(x)")
    assert get_statement_of_position(node, 0) is None

    node = parse_source("x = 1\nprint(x)")

# Generated at 2022-06-22 03:04:51.354535
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from thonny.jedi_utils import ThonnyCompletion
    a=ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    print(a.__getitem__('name'))


# Generated at 2022-06-22 03:05:02.423398
# Unit test for function get_definitions
def test_get_definitions():
    import os

    tests_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "test")

    def _test_get_definitions(module_name: str, line: int, column: int, num_definitions: int):
        fname = os.path.join(tests_dir, module_name)
        with open(fname) as fp:
            source = fp.read()
        definitions = get_definitions(source, line, column, fname)
        assert len(definitions) == num_definitions

    def _test_get_definitions_all(module_name: str, line_col_num_def_list: List[List[int]]):
        fname = os.path.join(tests_dir, module_name)

# Generated at 2022-06-22 03:05:14.206338
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    >>> test_get_script_completions()
    """
    result = get_script_completions("import os", 0, 3, "a.py")

# Generated at 2022-06-22 03:05:26.101136
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    print("\n inside test_ThonnyCompletion")
    completion = jedi.Script("import sys; sys.get", 4, 11, "").completions()[0]
    thonny_completion = ThonnyCompletion("a", "b", completion.type, completion.description, completion.parent, completion.full_name)
    assert thonny_completion.name == "a"
    assert thonny_completion.complete == "b"
    assert thonny_completion.type == completion.type
    assert thonny_completion.description == completion.description
    assert thonny_completion.parent == completion.parent
    assert thonny_completion.full_name == completion.full_name
    print("\n test_ThonnyCompletion pass")

# Generated at 2022-06-22 03:05:30.148787
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os\n"

    completions = get_interpreter_completions(
        source, namespaces=[{"os": os}], sys_path=[os.path.join(os.path.dirname(__file__), "jedi_stubs")]
    )

    assert "chmod" in completions

# Generated at 2022-06-22 03:05:37.611404
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion(name=1, complete=2, type=3, description=4, parent=5, full_name=6)
    assert c["name"] == 1
    assert c["complete"] == 2
    assert c["type"] == 3
    assert c["description"] == 4
    assert c["parent"] == 5
    assert c["full_name"] == 6

# Generated at 2022-06-22 03:05:40.501495
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from thonny.jedi_utils import ThonnyCompletion

    # Replace this with the code you want to test.
    assert True

# Generated at 2022-06-22 03:06:07.213733
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        """import numpy as np\nnp.array""", 1, 18, "test.py"
    )
    assert "array" in map(lambda c: c.name, completions)


# Generated at 2022-06-22 03:06:19.067570
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Project

    if hasattr(Project, "get_script"):
        source = "import datetime\n"
        row, column = 1, 5
        script = Project().get_script(source, path="untitled://test.py", line=row, column=column)

        def get_local_names(script):
            locals = set()
            for c in script.completions():
                _, local = c.name.rsplit(".", 1)
                locals.add(local)
            return locals

        assert script.completions()
        assert "datetime" in get_local_names(script)
        assert "date" in get_local_names(script)

    else:
        # For jedi versions before 2018
        from jedi import Script

        source = "import datetime\n"
       

# Generated at 2022-06-22 03:06:29.104106
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    if _using_older_jedi(jedi):
        source = "import os\nos.path"
        row = 2
        column = 8
        filename = "test.py"
    else:
        source = "import os\nos.path"
        row = 2
        column = 8
        filename = "test.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) > 0
    assert definitions[0].module_path == "os"
    assert definitions[0].start_pos[0] == 0
    assert definitions[0].start_pos[1] == 0

# Generated at 2022-06-22 03:06:34.671326
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.ui_utils import get_select_completion, get_completions

    def print_completions(completions):
        for completion in completions:
            print(completion["name"], end=" ")
        print()

    def run(source, row, column, expected):
        print(">>>", source, "-" * 20)
        print_completions(get_completions(source, row, column))
        print_completions(get_select_completion(source, row, column))
        print(
            "expected",
            expected,
            "resutls same?",
            sorted([c["name"] for c in get_completions(source, row, column)]) == sorted(expected),
        )
        print("*" * 40)


# Generated at 2022-06-22 03:06:37.627247
# Unit test for function parse_source
def test_parse_source():
    src = "def foo():"
    parsed = parse_source(src)
    assert parsed.children[0].get_code() == src

# Generated at 2022-06-22 03:06:42.774975
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    script_completions = get_script_completions("impo", 0, 0, "test.py")
    assert script_completions == [
        Completion("import ", "import ", "keyword", "import statements", None, "import"),
        Completion("impossible", "impossible", "statement", "Previous imports", None, "impossible"),
    ]

# Generated at 2022-06-22 03:06:53.680411
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest

    def _get_node(text, pos):
        node = parse_source(text)
        return get_statement_of_position(node, pos)

    class GetStatementOfPositionTest(unittest.TestCase):
        def test_simple(self):
            self.assertIsNotNone(_get_node("a=5\nb=6\n", 4))

        def test_indentation1(self):
            self.assertIsNotNone(_get_node("if True:\n    a=5\n    b=6\n", 12))

        def test_indentation2(self):
            self.assertIsNotNone(_get_node("if True:\n    a=5\n    b=6\n", 8))

        def test_indentation3(self):
            self.assertIsNot

# Generated at 2022-06-22 03:06:57.645913
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == "name"
    assert tc["complete"] == "complete"
    assert tc["type"] == "type"
    assert tc["description"] == "description"
    assert tc["parent"] == "parent"
    assert tc["full_name"] == "full_name"



# Generated at 2022-06-22 03:07:02.250660
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if not jedi:
        return
    try:
        results = get_interpreter_completions("print(", [])
        assert "print(" in [result.name for result in results]
    except Exception:
        pass
    try:
        results = get_interpreter_completions("import sys\nprint(sys.", [])
        assert "sys.platform" in [result.name for result in results]
    except Exception:
        pass
    try:
        # need to have variables in global namespace
        results = get_interpreter_completions("import tkinter\nroot = tkinter.Tk()\nroot.", [])
        assert "tkinter.Tk" in [result.name for result in results]
    except Exception:
        pass

# Generated at 2022-06-22 03:07:11.628756
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    test_cases = [
        ("x+y", (3, 4), "x", "simple_stmt"),
        ("x+y", (4, 5), "x+y", "simple_stmt"),
        ("print(x)", (6, 7), "x", "print_stmt"),
        ("def f(x):\n    pass", (1, 2), "f", "funcdef"),
    ]

    for code, pos, value, type in test_cases:
        node, _ = parse_source(code)
        result = get_statement_of_position(node, pos)
        (r_value, r_type) = (result.value, result.type)
        assert value == r_value and type == r_type

# Generated at 2022-06-22 03:07:49.515610
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"

# Generated at 2022-06-22 03:07:54.408177
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso

    node = parso.parse("import re\nre.compile").children[1].children[0].children[0]
    arg_node = node.children[0]
    complete = arg_node.get_code()
    type = arg_node.type
    description = arg_node.as_string()
    parent = arg_node.parent
    full_name = arg_node.name
    assert (
        ThonnyCompletion("pattern", complete, type, description, parent, full_name).complete
        == complete
    )



# Generated at 2022-06-22 03:08:04.368704
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.config import get_python_version
    from thonny.plugins.backend_pyplot import get_completions
    import jedi

    get_script_completions("import numpy as np; np.array(", 7, 22, "foo.py")
    get_script_completions("from numpy import array; array(", 8, 11, "foo.py")
    get_script_completions("from numpy import array; array(", 8, 12, "foo.py")
    get_script_completions("from numpy import array; array(", 8, 13, "foo.py")
    get_script_completions("from numpy import array; array(", 8, 14, "foo.py")

# Generated at 2022-06-22 03:08:06.531139
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    pass

# Generated at 2022-06-22 03:08:16.657864
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    source = """def test_func():
    ""
    print('a')
    return 'b'
"""
    parser = parse_source(source)
    # Compare it with the original parso module code
    # https://github.com/davidhalter/parso/blob/master/parso/python/parser.py#L98
    assert isinstance(parser, tree.Module)
    assert isinstance(parser.children[0], tree.FuncDef)
    assert isinstance(parser.children[0].children[3], tree.ExprStmt)
    assert isinstance(parser.children[0].children[3].children[0], tree.Call)

# Generated at 2022-06-22 03:08:18.065526
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_parent_scope


# Generated at 2022-06-22 03:08:19.741388
# Unit test for function parse_source
def test_parse_source():
    from jedi.parser_utils import get_statement_of_position

# Generated at 2022-06-22 03:08:30.861886
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test cases
    def check(source, row, column, expected):
        completions = get_script_completions(source, row, column, "test.py")
        assert [complete.complete for complete in completions] == expected

    check("", 0, 0, ["def ", "class "])
    check("class MyClass:", 0, 0, ["def ", "class "])
    check("class MyClass:", 10, 10, ["def "])


if __name__ == "__main__":
    # In case of "import *"
    from thonny.globals import get_workbench
    from thonny.plugins.jedi_completer import Completer

    get_workbench().set_default("view.show_command_in_turtle", False)

    c = Completer()
   

# Generated at 2022-06-22 03:08:39.138664
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.ast_utils import parse_source
    from thonny.ast_utils import get_interpreter_completions
    from thonny.ast_utils import get_script_completions
    from thonny.ast_utils import get_definitions
    import os
    import json
    import jedi

    if jedi.__version__[:4] in ["0.18"]:
        print("Jedi version used: " + jedi.__version__[:4])

        # script_complete
        code = "import json\njson.lo"
        row = 2
        column = len(code) - 1

        completions = get_script_completions(code, row, column, "")
        json_names = []

# Generated at 2022-06-22 03:08:48.329458
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def strip_spaces(source):
        return "\n".join([line.strip() for line in source.splitlines()])

    from parso.python import tree

    source = """\
if k:  # <1> <2> <3>
    a = 1
    if j:
        a = 2
    print(k)
"""
    source = strip_spaces(source)
    node = parse_source(source)
    assert isinstance(node, tree.Module)
    for pos in [1, 2, 3]:
        stmt = get_statement_of_position(node, pos)
        assert isinstance(stmt, tree.ExprStmt)
        assert stmt.start_pos == 1
        assert stmt.end_pos == 2
    # test selection
    stmt = get_statement_of_

# Generated at 2022-06-22 03:10:18.941574
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def verify(test_source, cursor_row, cursor_col, expected_result):
        import jedi
        import jedi.parser_utils

        node = jedi.Script(test_source).parse()
        actual_result = get_statement_of_position(node, (cursor_row, cursor_col))
        assert actual_result.type == expected_result
        

# Generated at 2022-06-22 03:10:30.703047
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys

    # Add path of the test file to sys path
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    from jedi import __version__ as jedi_version
    from jedi import Script


# Generated at 2022-06-22 03:10:31.654844
# Unit test for function parse_source

# Generated at 2022-06-22 03:10:41.803891
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    try:
        __IPYTHON__
        logger.info("Cannot run this test inside IPython")
        return
    except NameError:
        pass

    jedi.settings.case_insensitive_completion = False

    namespaces = [
        {
            "__builtins__": None,
            "foo": "foo",
            "bar": [1, 2],
            "n": 42,
        }
    ]
    completions = get_interpreter_completions("foo.", namespaces)


# Generated at 2022-06-22 03:10:50.046687
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    from unittest.mock import create_autospec

    from thonny import get_workbench, ui_utils, backends
    from thonny.languages.cpython import PythonShellView, InterpreterProxy

    workbench = get_workbench()
    workbench.set_default("shell", {})

    completion_shell = create_autospec(PythonShellView(None, backends.get_python_executable()))
    completion_shell.get_namespaces.return_value = [{}]
    completion_shell._proxy = create_autospec(InterpreterProxy)
    completion_shell.get_execution_sequence.return_value = (
        "def f():print('Hello world')\nf()",
        [0, 0],
    )

    workbench.set_