

# Generated at 2022-06-22 03:00:22.067848
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree
    import parso.python.token

    source = """# Demo source
    def func():
      pass
    """
    tree = parse_source(source)
    root = tree._root
    assert isinstance(root, parso.python.tree.Module)
    assert root.children[0].type == "simple_stmt"
    assert root.children[0].children[0].type == "small_stmt"
    assert isinstance(
        root.children[0].children[0].children[0], parso.python.tree.Function
    )
    assert isinstance(root.children[0].children[0].children[0], parso.python.tree.Function)



# Generated at 2022-06-22 03:00:27.685857
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-22 03:00:30.802534
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree

    source = "import math\nx = math.cos"
    row = 2
    column = 10
    filename = '<string>'
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    definition = definitions[0]
    assert isinstance(definition, tree.ImportName)
    assert definition.name == "cos"
    assert definition.line == 1



# Generated at 2022-06-22 03:00:41.610850
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = ("class TestClass: \n"
              "    def test_method(self): \n"
              "        pass \n"
              "    a_dict = {'b': 1} \n"
              "    a_list = [1, 2, 3] \n"
              "    a_str = 'a_str' \n"
              "    a_int = 1 \n"
              "    a_float = 1.0 \n"
              "TestClass.a_str.replace\n")
    connection = MockConnection(source)
    completions = get_interpreter_completions(source, [], None)
    completions = sorted(completions, key=lambda x: x.name)

# Generated at 2022-06-22 03:00:51.630837
# Unit test for function parse_source
def test_parse_source():
    import unittest

    class ParseSourceTest(unittest.TestCase):
        def test_parse_source(self):

            from parso.python import tree

            code = """
            def f():
                pass

            def g():
                pass

            def h():
                pass
            """

            source = parse_source(code)
            self.assertEqual(source.type, "file_input")

            functions = [node for node in source.children if isinstance(node, tree.Function)]
            self.assertEqual(len(functions), 3)
            self.assertEqual(functions[0].name.value, "f")
            self.assertEqual(functions[1].name.value, "g")
            self.assertEqual(functions[2].name.value, "h")
            self

# Generated at 2022-06-22 03:01:04.299841
# Unit test for function get_definitions
def test_get_definitions():
    source = """
a = 3
b = a
b
"""
    defs = get_definitions(source, 1, 0, "")
    assert len(defs) == 1
    assert defs[0].type == "statement"
    assert defs[0].description == "assignment"

    defs = get_definitions(source, 1, 2, "")
    assert len(defs) == 1
    assert defs[0].type == "statement"
    assert defs[0].description == "assignment"

    defs = get_definitions(source, 2, 0, "")
    assert len(defs) == 1
    assert defs[0].type == "statement"
    assert defs[0].description == "assignment"

    defs = get_definitions(source, 2, 2, "")

# Generated at 2022-06-22 03:01:14.104517
# Unit test for function get_definitions
def test_get_definitions():
    """Tests function get_definitions"""
    import os
    from unittest import TestCase
    from unittest.mock import patch

    source = "from datetime import datetime\n" + \
        "class X: \n" + \
        "    def __init__(self, x):\n" + \
        "        self.x = x\n" + \
        "    def __len__(self):\n" + \
        "        return len(self.x)\n"


    class Test(TestCase):
        @patch.object(os, "getcwd")
        def test_class(self, mock_cwd):
            mock_cwd.return_value = "/"
            defi = get_definitions(source, 0, 12, "/a")

# Generated at 2022-06-22 03:01:21.091543
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_1 = ThonnyCompletion('name_1', 'complete_1', 'type_1', 'description_1', 'parent_1', 'full_name_1')
    assert test_1.name == 'name_1'
    assert test_1.complete == 'complete_1'
    assert test_1.type == 'type_1'
    assert test_1.description == 'description_1'
    assert test_1.parent == 'parent_1'
    assert test_1.full_name == 'full_name_1'



# Generated at 2022-06-22 03:01:33.932337
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.tree import Leaf, Node

    statements = [
        Node("result", [Node("x", [Leaf(0, "x")]), Leaf(2, "="), Leaf(3, "1")]),
        Node("result", [Leaf(0, "y"), Leaf(2, "="), Leaf(3, "2")]),
        Node("result", [Leaf(0, "z"), Leaf(2, "="), Leaf(3, "3")]),
    ]
    suite = Node("suite", [Leaf(0, "("), Leaf(1, "\n")] + statements + [Leaf(2, "\n")])

# Generated at 2022-06-22 03:01:35.571134
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert type(get_interpreter_completions('import ', [{}], sys_path=[])) == list

# Generated at 2022-06-22 03:01:47.252589
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert c['name'] == 'name'
    assert c['complete'] == 'complete'
    assert c['type'] == 'type'
    assert c['description'] == 'description'
    assert c['parent'] == 'parent'
    assert c['full_name'] == 'full_name'

# Generated at 2022-06-22 03:01:50.247517
# Unit test for function parse_source

# Generated at 2022-06-22 03:01:52.091978
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert len(ThonnyCompletion("a", "a", "t", "d", "p", "f")) == 6

# Generated at 2022-06-22 03:01:57.985572
# Unit test for function get_definitions
def test_get_definitions():
    src = """class Test:
    def test():
        a = Test()
        b = Test()
        b.test()
    """
    from thonny.jedi_utils import get_definitions
    ret = get_definitions(src, 6, 11, "test.py")
    assert len(ret) == 1
    assert ret[0].name == "test"
    assert ret[0].parent == "."

# Generated at 2022-06-22 03:01:59.026738
# Unit test for function parse_source
def test_parse_source():
    parse_source("print ('hello')")

# Generated at 2022-06-22 03:02:03.414358
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions(source="", row=1, column=1, filename="")
    assert isinstance(result, list)
    assert len(result) == 0

    result = get_script_completions(
        source="open(", row=1, column=6, filename=""
    )  # Issue 652
    assert len(result) > 0
    assert result[0].name == "file"

# Generated at 2022-06-22 03:02:05.744217
# Unit test for function parse_source
def test_parse_source():
    import parso

# Generated at 2022-06-22 03:02:11.704839
# Unit test for function get_definitions
def test_get_definitions():
    source = "import sys\nsys.stderr."
    completions = get_definitions(source, 2, 14, "__main__")
    assert len(completions) > 0
    assert {c.line for c in completions} == {1}

    #  TODO: it seems that jedi returns line as 1-based
    #  TODO: should I fix it or is it somewhere a flag to fix it?

# Generated at 2022-06-22 03:02:21.670928
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position as _get_statement_of_position

    assert get_statement_of_position(
        parse_source("a = 1\nf = 42"), parse_source("a = 1\nf = 42").children[1]
    ) == _get_statement_of_position(parse_source("a = 1\nf = 42"), parse_source("a = 1\nf = 42").children[1])

    assert get_statement_of_position(parse_source("a = 1"), parse_source("a = 1").children[0]) == parse_source("a = 1").children[0]

    assert get_statement_of_position(parse_source("def f(): pass"), parse_source("def f(): pass").children[0]) == parse_source("def f(): pass").children

# Generated at 2022-06-22 03:02:28.697267
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = ThonnyCompletion("name", 'complete', "type", "description", "parent", "full_name")
    assert complete.name == "name"
    assert complete.complete == "complete"
    assert complete.type == "type"
    assert complete.description == "description"
    assert complete.parent == "parent"
    assert complete.full_name == "full_name"


# Generated at 2022-06-22 03:02:40.616122
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Arrange
    name = "abc"
    complete = "def"
    type = "str"
    description = "ghi"
    parent = object
    full_name = "jkl"

    # Act
    comp = ThonnyCompletion(name, complete, type, description, parent, full_name)

    # Assert
    assert comp.name == name
    assert comp.complete == complete
    assert comp.type == type
    assert comp.description == description
    assert comp.parent == parent
    assert comp.full_name == full_name


# Generated at 2022-06-22 03:02:42.829417
# Unit test for function get_definitions
def test_get_definitions():
    from _get_definitions import test_get_definitions
    test_get_definitions()

# Generated at 2022-06-22 03:02:44.234112
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree


# Generated at 2022-06-22 03:02:53.275708
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import jedi.parser_utils
    import textwrap
    import parso.python.tree
    from test.support import captured_stdout

    class JediUtilsTest(unittest.TestCase):
        def test_get_statement_of_position(self):
            class TestNode(parso.python.tree.PythonNode):
                def __init__(self, start_pos, end_pos, children, type, expected_statement):
                    super().__init__()
                    self.start_pos = start_pos
                    self.end_pos = end_pos
                    self.children = children
                    self.type = type
                    self.expected_statement = expected_statement


# Generated at 2022-06-22 03:03:00.408383
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "fred"
    complete = "complete"
    type = int
    description = "description"
    parent = "parent"
    full_name = "full_name"
    
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc["name"] == name
    assert tc["complete"] == complete
    assert tc["type"] == type
    assert tc["description"] == description
    assert tc["parent"] == parent
    assert tc["full_name"] == full_name

# Generated at 2022-06-22 03:03:06.163902
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions(source="from math import *; pi", row=0, column=21, filename="")
    assert len(result) == 1
    assert result[0].name == "pi"


if __name__ == "__main__":
    test_get_script_completions()
    print("OK")

# Generated at 2022-06-22 03:03:18.130838
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def assert_result(expected_result, source, pos_tuple):
        import jedi.parser_utils

        node = jedi.parser_utils.load_grammar(source)
        pos = jedi.parser_utils.position_to_number(source, *pos_tuple)
        result = get_statement_of_position(node, pos)
        assert result.get_code().strip() == expected_result

    assert_result(
        "if False:", "if False: print('a')", (1, 8)
    )  # on 'F' of False
    assert_result(
        "if False:", "if False: print('a')", (1, 5)
    )  # on 'i' of if

# Generated at 2022-06-22 03:03:23.951444
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert completion.name == name, "name incorrect"
    assert completion.complete == complete, "complete incorrect"
    assert completion.type == type, "type incorrect"
    assert completion.description == description, "description incorrect"
    assert completion.parent == parent, "parent incorrect"
    assert completion.full_name == full_name, "full_name incorrect"

# Generated at 2022-06-22 03:03:25.318047
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree


# Generated at 2022-06-22 03:03:37.458461
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Completion:
        def __init__(self, name: str, complete: str, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    old_completion = Completion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    new_completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert old_completion.name == new_

# Generated at 2022-06-22 03:03:47.031424
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    attribute=thonny.backend_jedi.utils.ThonnyCompletion("name","complete","type","description","parent","full_name")
    assert attribute.__getitem__("name")=="name"
    assert attribute.__getitem__("complete")=="complete"
    assert attribute.__getitem__("type")=="type"
    assert attribute.__getitem__("description")=="description"
    assert attribute.__getitem__("parent")=="parent"
    assert attribute.__getitem__("full_name")=="full_name"


# Generated at 2022-06-22 03:03:50.779122
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("print('hello')", 0, 0, "foo.py")
    assert len(completions) > 20
    assert any([c["complete"] == "print(" for c in completions])

# Generated at 2022-06-22 03:03:52.822820
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import parso.python.tree

# Generated at 2022-06-22 03:03:59.650043
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    result = ThonnyCompletion(
        name="test_name",
        complete="test_complete",
        type="test_type",
        description="test_description",
        parent="test_parent",
        full_name="test_full_name",
    )
    assert result["name"] == "test_name"
    assert result["complete"] == "test_complete"
    assert result["type"] == "test_type"
    assert result["description"] == "test_description"
    assert result["parent"] == "test_parent"
    assert result["full_name"] == "test_full_name"
    assert len(result.__dict__) == 6


# Unit tests for module
if __name__ == "__main__":
    def get_statements(source):
        import jedi.parser_utils

        func

# Generated at 2022-06-22 03:04:01.737623
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    ThonnyCompletion("a","b","c","d","e","f")

# Generated at 2022-06-22 03:04:09.241072
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    import jedi

    source = "import pandas\nprint(pandas)"
    node = parse_source(source)
    script = jedi.Script(source=source, path="test.py")
    row = 2
    column = 7
    pos = node.get_leaf_for_position((row, column)).end_pos

    statement = get_statement_of_position(node, pos)
    # Generate editor completions for the node.
    definitions = script.goto_definitions()
    assert len(definitions) == 1
    assert definitions[0].in_builtin_module()


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-22 03:04:11.675958
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("im", [])

# Generated at 2022-06-22 03:04:20.682696
# Unit test for function get_script_completions
def test_get_script_completions():
    for version in ["0.16.0", "0.17.2", "0.18.0"]:
        import jedi

        jedi.__version__ = version
        results = get_script_completions(
            "import sys;sys.exit",
            0,
            len("import sys;sys.e"),
            "test_get_completions.py",
            sys_path=[""],
        )
        assert len(results) > 0
        assert results[0].name == "exit"
        assert results[0].complete == "sys.exit"
        assert results[0].type == "statement"

# Generated at 2022-06-22 03:04:32.055385
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # These tests are only intended to cover the wrapper functions
    import glob
    import os
    import parso
    import pytest

    from thonny.jedi_utils import get_interpreter_completions

    # Prepare jedi tree
    source = get_source_in_folder("jedi")
    module = parse_source(source)
    # Prepare completions
    completions = get_interpreter_completions(source, [])
    # Check completions
    for completion in completions:
        # Test jedi 0.14.1
        if completion.name == "Interpreter":
            # Test jedi 0.15.2
            assert completion["complete"] == "Interpreter(source, [, locals])"
            # Test jedi 0.15.2
            assert completion["type"] == "class"


# Generated at 2022-06-22 03:04:34.163760
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-22 03:04:49.738058
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    if getattr(__builtins__, '__IPYTHON__'):
        from thonny.common import THONNY_USER_DIR
        c = ThonnyCompletion(name='my_name', 
                        complete='my_complete', 
                        type='my_type', 
                        description=THONNY_USER_DIR, 
                        parent='my_parent', 
                        full_name='my_full_name')
        assert c[0] == c['name']
        assert c[1] == c['complete']
        assert c[2] == c['type']
        assert c[3] == c['description']
        assert c[4] == c['parent']
        assert c[5] == c['full_name']

# Generated at 2022-06-22 03:05:01.458151
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from jedi import Interpreter
    from jedi.evaluate.compiled.value import ValueSet
    from jedi.cache import underscore_memoization

    @underscore_memoization
    def _completions(source, row, column, namespaces, interp):
        # Mocking Interpreter.complete() which is where we are going to test.
        # It returns list of completions which is ValueSet.
        if "_" in source:
            return ValueSet([])
        else:
            return ValueSet([interp.create_simple_object(source)])

    # Setting mocked function to Interpreter.
    Interpreter._completions = staticmethod(_completions)
    # Passing mocked function "create_simple_object()" to Interpreter().

# Generated at 2022-06-22 03:05:12.765731
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ("name" in vars(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")))
    assert ("complete" in vars(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")))
    assert ("type" in vars(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")))
    assert ("description" in vars(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")))
    assert ("parent" in vars(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")))

# Generated at 2022-06-22 03:05:15.075813
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(get_script_completions("1+", 1, 2, "test.py")) > 0

# Generated at 2022-06-22 03:05:26.865114
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    logger.warning("Running tests for get_script_completions.")

    # from jedi.api.classes import Completion

    # https://github.com/davidhalter/jedi/blob/b4a4b4de2b85e8b60d61c0562c6b5e8cbb7322b1/jedi/api/classes.py#L7-L15
    assert (
        get_script_completions(
            "str", 1, 3, filename="test.py", sys_path=["/tmp", "/usr/bin/python3"]
        )
        == []
    )

    # https://github.com/davidhalter/jedi/blob/b4a4b4de2b85e8b60d61c

# Generated at 2022-06-22 03:05:31.910612
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parser
    import textwrap
    code = textwrap.dedent("""
        def f():
            if True:
                def g(a = 1, 
                    b = 2): return 1
                
                g(
                42,
                99)
    """)
    tree = parser.parse(code)
    statement = get_statement_of_position(tree, len(code) - 1)
    assert statement.end_pos == len(code)

# Generated at 2022-06-22 03:05:39.658914
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import debug
    debug.DebugOutput().set_debug_function_calls(False)
    source = "import sys; sys.path.append(r'c:\\proj')"
    row = 1
    column = 14
    filename = "c:\\user\\thonny\\file.py"
    definitions = get_definitions(source, row, column, filename)
    print(definitions)

# Generated at 2022-06-22 03:05:43.737246
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    completions1 = get_script_completions("from datetime import da",0,0,"test.py")
    completions2 = jedi.Script("from datetime import da",0,0,"test.py").completions()
    assert completions1 == completions2


# Generated at 2022-06-22 03:05:47.523186
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.parser_utils import get_parent_scope
    from parso.python import tree
    from parso.python.tree import Name
    from thonny.misc_utils import running_on_windows


# Generated at 2022-06-22 03:05:54.086955
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf, Array
    from parso.python import tree

    leaf = Leaf(1,"x", (1,1))
    array = Array()
    for_stmt = tree.ForStmt((1,1), [], [leaf], [], "for_stmt")
    array.append(for_stmt)
    leaf.parent = array
    res = get_statement_of_position(array,(5,5))
    assert res == for_stmt

# Generated at 2022-06-22 03:06:22.101928
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # we can't import this function directly because Jedi doesn't support Python 3.5
    # so we'll try to import it "remotely" here
    import sys
    import parso
    import jedi
    jedi.api.Environment.get_default_environment(create=False)
    # modify sys.path
    sys.path.insert(0, os.path.join(os.path.dirname(jedi.__file__), '..'))
    from jedi.parser_utils import get_statement_of_position

    source = """while True:
    z()
    if x:
        pass
    for i in range(10):
        print(i)
    x = 2

    y = 1"""
    node = parso.parse(source)
    pos = len(source) - 1

    assert get_statement_of

# Generated at 2022-06-22 03:06:32.187532
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import jedi
    import os
    import jedi
    from thonny.plugins.backend_utils import get_script_completions

    def _test_sys_path():
        if "__file__" in globals():
            test_file = os.path.abspath(__file__)
            test_dir = os.path.dirname(test_file)
            return [os.path.join(test_dir, "test_data")]
        else:
            return []

    class TestCompletions(unittest.TestCase):
        jedi = jedi

        def test_has_complete(self):
            completions = get_script_completions("import _sre; _sre.", 0, 18, "")

# Generated at 2022-06-22 03:06:34.991305
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
  #test = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
  #assert 'name' == test['name']
  pass

# Generated at 2022-06-22 03:06:46.258608
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import sys

    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_local_func(self):
            source = "def f():\n    pass\n\nf()"
            result = get_definitions(source, line=3, column=4, filename="")

# Generated at 2022-06-22 03:06:53.412192
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import tempfile
    import os
    import shutil
    import jedi
    import sys
    import json

    if sys.version_info[:2] != (3, 7):
        print("Test skipped (requires Python 3.7)")
        return

    sources = [
        "import testing_utils"
    ]


# Generated at 2022-06-22 03:06:59.066137
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # There was a bug in jedi 0.16.0, fixed in 0.16.1
    # https://github.com/davidhalter/jedi/issues/1700
    code = """
    if 1:
        a = 5
        a+=
    """
    import jedi
    script = jedi.Script(code)
    completion = script.completions()[0]
    # below is the important line to test
    c = get_statement_of_position(completion.parent, completion.start_pos)
    assert c.name == "Assignment"
    assert str(c).strip().endswith("a +=")

# Generated at 2022-06-22 03:07:02.508315
# Unit test for function parse_source
def test_parse_source():
    source = """
if True:
    print("a")
    print("b")
"""
    parse_result = parse_source(source)
    assert parse_result is not None

# Generated at 2022-06-22 03:07:03.089293
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:07:09.307535
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """
    >>> from thonny.jedi_utils import get_interpreter_completions
    >>> completions = get_interpreter_completions("", [{'__builtins__': {}}])
    >>> len(completions) > 100
    True
    >>> any(c.name=='int' for c in completions)
    True
    >>> any(c.name=='__builtins__' for c in completions)
    False
    """



# Generated at 2022-06-22 03:07:17.433011
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Arrange
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    # Act
    result = ThonnyCompletion(name, complete, type, description, parent, full_name)

    # Assert
    assert result.name == name
    assert result.complete == complete
    assert result.type == type
    assert result.description == description
    assert result.parent == parent
    assert result.full_name == full_name

# Generated at 2022-06-22 03:08:33.590223
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_object1 = ThonnyCompletion("test1", "test2", "test3", "test4", "test5", "test6")
    assert test_object1.name == "test1"
    assert test_object1.complete == "test2"
    assert test_object1.type == "test3"
    assert test_object1.description == "test4"
    assert test_object1.parent == "test5"
    assert test_object1.full_name == "test6"
    
    test_object2 = ThonnyCompletion("test11", "test22", "test33", "test44", "test55", "test66")
    assert test_object2.name == "test11"
    assert test_object2.complete == "test22"

# Generated at 2022-06-22 03:08:40.041690
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnyCompletion['name'] == 'name'
    assert thonnyCompletion['complete'] == 'complete'
    assert thonnyCompletion['type'] == 'type'
    assert thonnyCompletion['description'] == 'description'
    assert thonnyCompletion['parent'] == 'parent'
    assert thonnyCompletion['full_name'] == 'full_name'
    thonnyCompletion.name = "new_name"
    thonnyCompletion.complete = "new_complete"
    thonnyCompletion.type = "new_type"
    thonnyCompletion.description = "new_description"

# Generated at 2022-06-22 03:08:45.057685
# Unit test for function get_definitions
def test_get_definitions():
    print(get_definitions("thonny", 0, 5, "test.py"))
    print(get_definitions("os.path.isdir", 0, 5, "test.py"))
    print(get_definitions("os", 0, 2, "test.py"))
    print(get_definitions("os.path.isdir(", 0, 5, "test.py"))

# Generated at 2022-06-22 03:08:51.722464
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    module_node = parse_source('print(1)\ndef f():\n    print(2)')
    print_node = module_node.children[0]
    assert get_statement_of_position(module_node, print_node.start_pos) \
        == get_statement_of_position(module_node, print_node.end_pos)

    funcdef_node = module_node.children[1]
    assert get_statement_of_position(funcdef_node, funcdef_node.start_pos) \
        == funcdef_node

    print_node_in_func = funcdef_node.children[1]

# Generated at 2022-06-22 03:08:56.219367
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import time
    start_time = time.time()
    #Testing valid input
    test_class = ThonnyCompletion("pi", "value", "variable", "This is a test input", "/test_ThonnyCompletion.py", "math.pi")
    test_class.__repr__()
    test_class.__str__()
    assert test_class.name == "pi"
    assert test_class.complete == "value"
    assert test_class.type == "variable"
    assert test_class.description == "This is a test input"
    assert test_class.parent == "/test_ThonnyCompletion.py"
    assert test_class.full_name == "math.pi"
    #Testing invalid input

# Generated at 2022-06-22 03:09:05.119567
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # Arrange
    nom = 'nom'
    complet = 'complet'
    type = 'type'
    description = 'description'
    parent = 'parent'
    full_name = 'full_name'
    comp = ThonnyCompletion(nom, complet, type, description, parent, full_name)

    # Act
    actual_nom = comp['name']
    actual_complet = comp['complete']
    actual_type = comp['type']
    actual_description = comp['description']
    actual_parent = comp['parent']
    actual_full_name = comp['full_name']

    # Assert
    assert actual_nom == nom
    assert actual_complet == complet
    assert actual_type == type
    assert actual_description == description
    assert actual_parent == parent
    assert actual_full

# Generated at 2022-06-22 03:09:14.383121
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):
        def test_completions(self):
            code = "import "
            completions = get_script_completions(
                code, 1, len(code), filepath="test.py", sys_path=["/root"]
            )

            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")


# Generated at 2022-06-22 03:09:24.939389
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def run(source, expected, sys_path=None):
        import jedi

        completions = get_interpreter_completions(source, [], sys_path=sys_path)
        names = [c.name for c in completions]
        types = [c.type if not c.type == "function" else "def" for c in completions]
        assert names == expected[0]
        assert types == expected[1]

        if _using_older_jedi(jedi):
            # With jedi older than 0.18, completions don't contain positional arguments
            assert all("(" not in c.name for c in completions)


# Generated at 2022-06-22 03:09:30.653266
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion(name="a", complete="b", type="c", description="d", parent="e", full_name="f")
    assert x.name == "a"
    assert x.complete == "b"
    assert x.type == "c"
    assert x.description == "d"
    assert x.parent == "e"
    assert x.full_name == "f"



# Generated at 2022-06-22 03:09:40.585552
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import main, TestCase

    class Test(TestCase):
        def runTest(self):
            import os

            from jedi.api.environment import find_virtualenvs

            from thonny import get_workbench

            workbench = get_workbench()
            shell = workbench.get_editor_notebook().get_current_shell()
            code = "import sys; import os; print(sys.path)"
            shell.send_input(code)