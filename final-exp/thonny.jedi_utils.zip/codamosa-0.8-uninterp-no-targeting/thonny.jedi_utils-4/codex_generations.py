

# Generated at 2022-06-22 03:01:08.839739
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import PythonNode

    class Node(PythonNode):
        # pylint: disable=unused-argument
        def __init__(self, children):
            self.children = children

        def start_pos(self):
            return self.children[0]

        def end_pos(self):
            return self.children[1]

    # Should return the leaf node
    node = Node([(1, 1), (2, 2)])
    assert get_statement_of_position(node, (1, 1)) == node
    assert get_statement_of_position(node, (2, 2)) == node

    # Should return the node which the cursor is at
    node = Node([(10, 10), (20, 20)])

# Generated at 2022-06-22 03:01:09.334956
# Unit test for function parse_source

# Generated at 2022-06-22 03:01:19.618629
# Unit test for function get_script_completions
def test_get_script_completions():
    # Up-to-date version of jedi
    competions = get_script_completions('<meta')
    assert competions[0]['name'] == '__metaclass__'
    assert competions[0]['description'] == 'builtins.type'
    assert competions[1]['name'] == '__module__'
    assert competions[1]['description'] == 'builtins.str'
    assert competions[2]['name'] == '__qualname__'
    assert competions[2]['description'] == 'builtins.str'
    assert competions[3] == '__name__'
    assert competions[4] == '__doc__'
    assert competions[5:] == ['__builtins__', '__package__']


# Generated at 2022-06-22 03:01:26.918718
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    if jedi.__version__[:4] not in ["0.16", "0.17"]:
        return
    import jedi

    recv = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert recv["name"] == "name"
    assert recv["complete"] == "complete"
    assert recv["type"] == "type"
    assert recv["description"] == "description"
    assert recv["parent"] == "parent"
    assert recv["full_name"] == "full_name"


# Generated at 2022-06-22 03:01:33.538792
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    """Copied from jedi.parser_utils.test_get_statement_of_position.

    Use get_statement_of_position instead of original function,
    because it's hard to import parso for unit tests.

    """
    from parso.python import tree


# Generated at 2022-06-22 03:01:44.140191
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = "import os\nos.\nx=0\n"
    root = parse_source(source)
    assert isinstance(root, parso.python.tree.Module)
    assert len(root.children) == 3
    for child in root.children:
        assert child.start_pos[0] == child.end_pos[0]


# Generated at 2022-06-22 03:01:55.335822
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    from parso.python.tree import ExprStmt
    from parso.python.parser import Parser

    parser = Parser(u'a = [x for x in range(5) if x % 2 == 0]')
    module = parser.module
    expr = module.children[-1]
    assert isinstance(expr, ExprStmt)
    assert get_statement_of_position(expr, expr.end_pos[0], expr.end_pos[1]) == expr
    assert get_statement_of_position(expr, expr.start_pos[0], expr.start_pos[1]) == expr
    assert get_statement_of_position(expr, 1, 0) == expr.children[1]

# Generated at 2022-06-22 03:01:56.188099
# Unit test for function get_definitions

# Generated at 2022-06-22 03:02:04.524600
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion
    from jedi import Script

    # Arrange
    completion = Completion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
        module_path="/module/path",
        line="line",
        column="column",
        module_name="module_name",
        is_keyword="is_keyword",
        is_snippet="is_snippet",
        defined_names="defined_names",
        params="params",
        is_magic="is_magic",
        is_property="is_property",
    )

    # Act

# Generated at 2022-06-22 03:02:14.167471
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.globals import get_workbench
    import thonny.jediutils as jediutils
    import os

    # No error should occur
    source = """from random import randint
n = randint(1, 100)
n
"""

    script_dir = os.path.dirname(__file__)
    file_name = os.path.join(script_dir, "test_file.py")
    definitions = jediutils.get_definitions(source, len(source.splitlines()) - 1, 2, file_name)
    assert len(definitions) == 1
    assert definitions[0].description == "randint([a, b]) -> int\n"



# Generated at 2022-06-22 03:02:32.092178
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from importlib import util

    def is_package(name: str):
        p = util.find_spec(name)
        return p and p.submodule_search_locations

    namespaces = [dict(import_name="site", name="site"), dict(import_name="os")]
    completions = get_interpreter_completions("os.path.ex", namespaces)

    assert len(completions) >= 2
    assert "exists" in [c.name for c in completions]
    assert "extsep" in [c.name for c in completions]

    # Extra tests for jedi 0.16.0

    # module
    module_completions = [c for c in completions if c.type == "module"]
    assert len(module_completions) == 1
    assert module

# Generated at 2022-06-22 03:02:40.501095
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse

    def assert_statement(node, expected):
        result = get_statement_of_position(node, node.start_pos)
        assert result.type == expected

    # Node:
    #
    # code1
    # code2
    #
    source = "code1\ncode2"
    result = parse(source)
    assert_statement(result, "simple_stmt")

    # Node:
    #
    # code1
    # code2
    #    code3
    #
    source = "code1\ncode2\n    code3"
    result = parse(source)
    assert_statement(result, "simple_stmt")

    # Node:
    #
    # code1
    # code2
    #    code3
    # code4
    #


# Generated at 2022-06-22 03:02:46.757354
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.test_run_jedi import get_jedi_version

    jedi_version = get_jedi_version()

    if jedi_version < (0, 17):
        assert get_script_completions("import os; o.", row=1, column=13, filename="test.py") == [
            ThonnyCompletion("open", "open", "function", "open(file, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None)\\n\\nOpen file and return a corresponding file object.  If the file cannot be\\nopened, an OSError is raised.", None, "os.open")
        ]

# Generated at 2022-06-22 03:02:51.476956
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == "name"
    assert tc["complete"] == "complete" 
    assert tc["type"] == "type" 
    assert tc["description"] == "description" 
    assert tc["parent"] == "parent" 
    assert tc["full_name"] == "full_name"

# Generated at 2022-06-22 03:02:56.916269
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert _using_older_jedi(jedi)

    completions = get_script_completions("pri", 0, 3, "")
    assert completions == [ThonnyCompletion('print(value, /)', 'print', 'function', 'print(value, /)', 'print', 'print')]



# Generated at 2022-06-22 03:03:09.433904
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import trees
    from parso.python.tree import Statement, KeywordStatement
    from jedi.parser_utils import get_statement_of_position

    def get_statement(row, column):
        node = tree.parse("def f():\n    pass\n")
        return get_statement_of_position(node, row, column)

    assert isinstance(get_statement(0, 0), trees.Module)
    assert isinstance(get_statement(2, 3), Statement)
    assert isinstance(get_statement(1, 15), Statement)
    assert isinstance(get_statement(0, 1), trees.Function)
    assert isinstance(get_statement(0, 7), trees.Name)
    assert isinstance(get_statement(1, 15), Statement)

# Generated at 2022-06-22 03:03:19.561916
# Unit test for function get_interpreter_completions

# Generated at 2022-06-22 03:03:22.745497
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    if __name__ == "test_jedi_utils":
        from parso import ParserSyntaxError
        from thonny.plugins.jedi_backend import utils as jedi_utils


# Generated at 2022-06-22 03:03:32.045415
# Unit test for function get_script_completions
def test_get_script_completions():
    from importlib import invalidate_caches

    invalidate_caches()
    from thonny.plugins.micropython import MicroPythonPlugin

    MicroPythonPlugin.activate()
    from thonny.plugins.micropython.backend import MicroPythonProxy, get_backend_cmdline

    proxy = MicroPythonProxy(get_backend_cmdline([]), [])
    proxy.start()
    print(get_script_completions("import micro", 1, 11, "<string>"), len(get_script_completions("import micro", 1, 11, "<string>")))
    proxy.kill()

# Generated at 2022-06-22 03:03:42.822222
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree

    node = tree.Module((0, 0), children=[
        tree.ExprStmt((0, 0), children=[
            tree.Call((0, 0), children=[
                tree.Name((0, 0), value="foo"),
                tree.ArgList((0, 0), children=[
                    tree.Operator((0, 0), value="*"),
                    tree.Name((0, 0), value="a"),
                    tree.Operator((0, 0), value="*"),
                    tree.Name((0, 0), value="b"),
                ]),
            ]),
        ]),
    ])

    # Completely outside the subtree

# Generated at 2022-06-22 03:03:57.175162
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # jedi < 0.15
    class MockCompletion:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    completions = [
        MockCompletion("__init__", "__init__", "function", "constructor", "", ""),
        MockCompletion(
            "__repr__", "__repr__", "method", "object representation", "", ""
        ),
        MockCompletion(
            "__str__", "__str__", "method", "string representation", "", ""
        ),
    ]
    tweaks = _tweak_completions(completions)

# Generated at 2022-06-22 03:04:07.614641
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # basic
    assert _tweak_completions([ _create_old_style_completion("class")]) == [_create_new_style_completion("class")]
    # remove double spaces
    assert _tweak_completions([ _create_old_style_completion("abc abc")]) == [_create_new_style_completion("abc abc")]
    # add ending =
    assert _tweak_completions([ _create_old_style_completion("abc")]) == [_create_new_style_completion("abc=", "abc")]
    # and keep existing ones
    assert _tweak_completions([ _create_old_style_completion("abc=")]) == [_create_new_style_completion("abc=")]
    # remove double spaces from end and add ending =

# Generated at 2022-06-22 03:04:15.605936
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-22 03:04:22.524692
# Unit test for function get_definitions
def test_get_definitions():
    source = 'import os\nos.path'
    row = 2
    column = 8
    filename = 'test.py'

    defs = get_definitions(source, row, column, filename)
    assert len(defs) == 1
    def0 = defs[0]
    assert def0.name == 'os.path.abspath'
    assert def0.module_name == 'os.path'
    assert def0.type == 'function'

# Generated at 2022-06-22 03:04:27.737587
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    completion = jedi.Script('import sys', 1, 8).completions()[0]
    assert ThonnyCompletion('name', 'completion', 'type', 'description', 'parent', 'full_name') == \
        ThonnyCompletion(name='name', complete='completion', type='type', description='description',
                         parent='parent', full_name='full_name')

# Generated at 2022-06-22 03:04:37.665160
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(name="name", complete="complete", type="type",
        description="description", parent="parent", full_name="full_name")
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"



# Generated at 2022-06-22 03:04:43.816823
# Unit test for function get_definitions
def test_get_definitions():
    """
    Throws error if a definition is not found.
    """
    source = "from math import *\npi"
    print(get_definitions(source, 1, 1, "test"))
    print(get_definitions(source, 1, 3, "test"))
    print(get_definitions(source, 2, 1, "test"))
    print(get_definitions(source, 3, 1, "test"))



# Generated at 2022-06-22 03:04:50.132131
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser.user_context import UserContext

    namespaces = [
        UserContext([], {}),
        ]
    completions = get_interpreter_completions("import sys; sys.", namespaces, [])
    assert(set([comp["name"] for comp in completions]) == set(["path", "stdin", "stdout"]))

    completions = get_interpreter_completions("import sys; sys.stdin.", namespaces, [])
    assert(set([comp["name"] for comp in completions]) == set(["readline", "read", "readlines"]))

# Generated at 2022-06-22 03:04:55.570506
# Unit test for function get_definitions
def test_get_definitions():
    raw = "import tkinter as tk\n\nroot = tk.Tk()\nroot.mainloop()"

    defs = get_definitions(raw, 2, len("root = tk.Tk()") + 1, "temp.py")

    assert len(defs) == 1
    assert defs[0].full_name == "Tk"
    assert defs[0].module_name == "tkinter"

    defs = get_definitions(raw, 2, len("root = tk.Tk") + 1, "temp.py")

    assert len(defs) > 1

# Generated at 2022-06-22 03:05:07.728017
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    case_dict = {
        "": [],
        "imp": ["import", "importlib", "imp"],
        "int": ["int"],
        "re": ["re"],
        "sys": ["sys"],
        "sys.std": ["sys.stdin", "sys.stdout", "sys.stderr"],
        "sys.std.": ["sys.stdin", "sys.stdout", "sys.stderr"],
        "sys.std.st": ["sys.stdin", "sys.stdout", "sys.stderr"],
        "sys..": ["sys", "sys"],
        "höhö.": [],
        "sys.höhö": [],
    }
    source = "import sys\n"

    global _tweak_completions
    tweak_

# Generated at 2022-06-22 03:05:28.267510
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import get_sys_path
    from jedi.api.project import Project
    import thonny.globals
    import os
    import os.path
    _script_path = os.path.abspath(os.path.join(os.getcwd(),os.path.dirname(__file__)))
    _thonny_root = os.path.dirname(_script_path)
    _path_thonny_contrib = os.path.join(_thonny_root,"thonny","contrib")
    _path_thonny_plugins = os.path.join(_thonny_root,"thonny","plugins")
    sys_path = [_path_thonny_contrib,_path_thonny_plugins]

# Generated at 2022-06-22 03:05:29.153286
# Unit test for function get_script_completions

# Generated at 2022-06-22 03:05:35.278744
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion('name1', 'complete1', 'type1', 'description1', 'parent1', 'full1')
    assert completion.name == 'name1'
    assert completion.complete == 'complete1'
    assert completion.type == 'type1'
    assert completion.description == 'description1'
    assert completion.parent == 'parent1'
    assert completion.full_name == 'full1'
    assert completion.__getitem__('name') == 'name1'
    assert completion.__getitem__('complete') == 'complete1'
    assert completion.__getitem__('type') == 'type1'
    assert completion.__getitem__('description') == 'description1'
    assert completion.__getitem__('parent') == 'parent1'
    assert completion.__getitem__('full_name')

# Generated at 2022-06-22 03:05:46.382771
# Unit test for function get_definitions
def test_get_definitions():
    def _test_get_definitions(source: str, row: int, column: int, expected: List[str]):
        import jedi

        script = jedi.Script(code=source, path="")
        defs = script.infer(line=row, column=column)
        names = [d.name for d in defs]
        assert names == expected

    _test_get_definitions("foo(a, b)", 1, 1, ["foo"])
    _test_get_definitions("foo(a, b)", 1, 4, [])
    _test_get_definitions("foo(a, b)", 1, 7, [])
    _test_get_definitions("foo(a, b)", 1, 8, [])

# Generated at 2022-06-22 03:05:48.823159
# Unit test for function parse_source
def test_parse_source():
    source = """import os

os.path.dirname(
    'dirname.py'
)
"""

    tree = parse_source(source)
    print(tree)

# Generated at 2022-06-22 03:06:00.920649
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        import unittest.mock
        if jedi.__version__ in ("0.15.2", "0.16.0"):
            # TODO: in 0.15.2 and 0.16.0 it throws ValueError("couldn't parse")
            # In 0.15.1 it did't have own complete method
            return

        with unittest.mock.patch("jedi.Interpreter.__init__") as init_mock:
            init_mock.return_value = None
            completions = get_interpreter_completions("def f():\n\tx = 1\n\tx.i", [])
            assert len(completions) == 2
            assert completions[0].name == "index"
           

# Generated at 2022-06-22 03:06:07.674576
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"


# Generated at 2022-06-22 03:06:19.428137
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree, token
    # generate a Node object with a subnode at given position
    def generate_node_with_subnode(pos, node_type, subnode_type):
        t = tree.Node(node_type, start_pos=(pos, 0), end_pos=(pos, 0))
        t.children.append(tree.Node(subnode_type, start_pos=(pos, 0), end_pos=(pos, 0)))
        return t

    # generate a Node object with a token at given position
    def generate_node_with_token(pos, node_type, token_type):
        t = tree.Node(node_type, start_pos=(pos, 0), end_pos=(pos, 0))

# Generated at 2022-06-22 03:06:31.000929
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    source = "def f():\n  x = 1\n  y = 2\n  z = x + y\n  return z\n\nprint(f())\n"
    row = 4
    column = 3
    filename = "test.py"
    a = get_definitions(source, row, column, filename)
    b = jedi.Script(source, row, column, filename).goto_definitions()

    assert len(a) == len(b)

    for x, y in zip(a, b):
        assert x.line == y.line
        assert x.column == y.column
        assert x.get_line_code() == y.get_line_code()
        assert x.module_path == y.module_path



# Generated at 2022-06-22 03:06:42.241721
# Unit test for function get_script_completions
def test_get_script_completions():
    print("Testing get_script_completions")
    import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]:
        print("Skipping test for older jedi")
        return

    import os
    import sys

    sys.path.insert(0, os.path.dirname(__file__))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from test_utils import get_completions

    # Get completions from mypy stubs
    completions = get_completions("import typing\ntyping.NamedTuple.__new__", "NamedTuple.py")

# Generated at 2022-06-22 03:06:59.167639
# Unit test for function get_definitions
def test_get_definitions():
    def run_test(source, offset, expected):
        from parso.python.tree import Leaf

        text = parso.parse(source)
        line, col = _get_line_col(text, offset)
        result = get_definitions(source, line, col, "")  # using empty filename for convenience
        if (
            expected
            and len(result) == 1
            and result[0].desc_with_module
            and result[0].desc_with_module == expected
        ):
            return True
        else:
            logger.info("Result: %s" % result)
            return False

    if not run_test("import json; json.dumps", 10, "json.dumps"):
        return False

# Generated at 2022-06-22 03:07:01.733807
# Unit test for function parse_source
def test_parse_source():
    source = parse_source("from abc import def\n")
    assert source is not None


# Generated at 2022-06-22 03:07:11.228407
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Dummy():
        name = "name"
        complete = "complete"
        type = "type"
        description = "description"
        parent = "parent"
        full_name = "full_name"
        def __init__(self):
            pass

    dummy = Dummy()
    completion = ThonnyCompletion(name=dummy.name, complete=dummy.complete, type=dummy.type, description=dummy.description, parent=dummy.parent, full_name=dummy.full_name)
    assert completion.name == dummy.name
    assert completion.complete == dummy.complete
    assert completion.type == dummy.type
    assert completion.description == dummy.description
    assert completion.parent == dummy.parent
    assert completion.full_name == dummy.full_name

# Generated at 2022-06-22 03:07:22.651896
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "abs("
        row = 1
        column = 4
        filename = "test.py"

        completions = get_script_completions(source, row, column, filename)

        assert len(completions) == 1
        assert completions[0]["name"] == "abs("
        assert completions[0]["complete"] == "abs("
        assert completions[0]["type"] == "function"
        assert completions[0]["description"] == "abs(number) -> number"
        assert completions[0]["parent"] == "<module>"
        assert completions[0]["full_name"] == "abs"
    else:
        source = "import datetime"
        row = 1
        column = 10
        filename

# Generated at 2022-06-22 03:07:34.278863
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest.mock as mock
    import jedi

    def create_completion(description):
        comp = mock.MagicMock()
        comp.description = description
        return comp

    assert get_script_completions("", 0, 0, "", sys_path=[]) == []

    # older versions of jedi
    with mock.patch.object(
        jedi.Script, "completions", return_value=[create_completion("abc")]
    ):
        with mock.patch.object(jedi, "__version__", "0.16.0"):
            completions = get_script_completions("", 0, 0, "", sys_path=[])
            assert completions[0]["description"] == "abc"
            assert completions[0]["name"] == ""

    # patch project to

# Generated at 2022-06-22 03:07:39.553502
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions('list', [{'__name__': '__main__', '__builtins__': __builtins__}])) == 1
    assert len(get_interpreter_completions('l', [{'__name__': '__main__', '__builtins__': __builtins__}])) == 1



# Generated at 2022-06-22 03:07:51.431494
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import unittest.mock
    import parso
    from parso.utils import split_lines, get_prefix_suffix

    class TestCase(unittest.TestCase):
        def test_get_definitions(self):
            # Def
            source = "import re\nre."

            _, prefix = split_lines(source, remove_comments_and_docstrings=True)
            line, column = get_prefix_suffix(prefix)

            definitions = get_definitions(source=source, row=line, column=column, filename="")
            self.assertEqual([definition.name for definition in definitions], ["re"])

            # Class definition
            source = "class A:\n    b = "

# Generated at 2022-06-22 03:08:02.228803
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").name == "a"
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").complete == "b"
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").type == "c"
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").description == "d"
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").parent == "e"
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f").full_name == "f"

# Generated at 2022-06-22 03:08:13.814825
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.parser import ParserSyntaxError

    from thonny import get_shell
    import jedi

    try:
        comps = get_interpreter_completions("", [], sys_path=[])
    except Exception:
        # should not fail if jedi is not available
        # but let's make sure not to mask any jedi exceptions
        import traceback

        traceback.print_exc()
        return

    if not comps:
        return

    if _using_older_jedi(jedi):
        # before 0.16, name didn't contain '='
        # and parse_source would fail
        return

    # get namespaces
    shell = get_shell()
    shell.execute("x=1")
    shell.execute("y=2")

# Generated at 2022-06-22 03:08:24.168220
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    code = "def f(a, b):\n    pass"
    unit = parso.parse(code)
    def_node = unit.children[0]  # type: parso.python.tree.Node
    x = def_node.children[1]  # type: parso.python.tree.Node
    y = def_node.children[2]  # type: parso.python.tree.Node
    pos = x.start_pos+2
    r = get_statement_of_position(def_node, pos)
    assert r is x
    r = get_statement_of_position(def_node, pos+1)
    assert r is x

    pos = y.start_pos+2
    r = get_statement_of_position(def_node, pos)

# Generated at 2022-06-22 03:08:46.470964
# Unit test for function parse_source
def test_parse_source():
    parse_source("1")
    parse_source("1\n")
    parse_source("1\n2")
    parse_source("1\n2\n")
    parse_source("1\n2\n\n")


# Generated at 2022-06-22 03:08:54.761272
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils as p
    
    def get_pos(line, column):
        return (line, column)
    

# Generated at 2022-06-22 03:08:59.792399
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = 'def f(a):\n  print(a)'
    result = parse_source(source)
    assert isinstance(result, parso.tree.Module)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-22 03:09:06.353037
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from textwrap import dedent

    code = """import os
import re
import sys
import math
import datetime
import collections
import re
import os.path
import tempfile
import errno
"""

    def test_with_jedi_version(jedi_version):
        # Test
        result = get_script_completions(code, 3, 1, "test_file.py", sys_path=["sys_path"])

        # Verify

# Generated at 2022-06-22 03:09:15.150820
# Unit test for function parse_source
def test_parse_source():
    from parso import ParserSyntaxError

    def parse(code):
        try:
            return parse_source(code)
        except ParserSyntaxError:
            return None

    assert parse("x = 0") is not None
    assert parse("+") is None
    assert parse("def f(x)") is not None
    assert parse("def f(x,y)") is not None
    assert parse("def f(x,y,)") is not None
    assert parse("def f(x,(y,z),)") is not None
    assert parse("def f(x,(y,z)") is not None
    assert parse("def f(x,(y,z") is not None
    assert parse("def f(x,(y,z,*a)") is not None

# Generated at 2022-06-22 03:09:25.500213
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions(
        "s = 'abc'\ns = [1,2]\nclass C:\n    def m(self):\n        self.x = 10\n",
        4,
        16,
        "dummy.py",
    )
    for d in defs:
        print(d.module_name, d.line, d.type, d.name)
    assert len(defs) == 1
    assert defs[0].line == 4
    assert defs[0].type == "instance"
    assert defs[0].name == "x"


# Generated at 2022-06-22 03:09:29.878852
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    jedi_version = jedi.__version__
    if jedi_version[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        script = get_script_completions(
            "if 1:",
            1,
            4,
            "test",
            sys_path=["/tmp"],
        )
        script = get_script_completions(
            "if 1:",
            1,
            4,
            "test",
        )
    else:
        script = get_script_completions(
            "if 1:",
            1,
            4,
            "test",
            sys_path=["/tmp"],
        )

# Generated at 2022-06-22 03:09:34.179833
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("import os; os.", [{}])) > 0


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-22 03:09:39.198093
# Unit test for function parse_source
def test_parse_source():
    # This test doesn't work for very old versions of parso
    # (the first release was 0.3.1, see https://github.com/davidhalter/parso/releases)
    # But I don't expect to support those
    import parso

    source = "x = 1\n"
    res = parse_source(source)
    assert isinstance(res, parso.python.tree.Module)

# Generated at 2022-06-22 03:09:50.153013
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    import jedi

    if not isinstance(jedi._jedi_cache, jedi.Script):
        # this happens when running from PyPI and jedi is not available
        return
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]:
        return

    code = """import math
math.ceil(3.14)
math.cos
"""

    # with sys_path
    completions = get_script_completions(code, 3, 5, "", sys_path=["/tmp/dummy_path"])
    assert completions[0].complete == "cos"
    assert completions[0].name == "cos"

    # without sys_path
    completions = get_script_complet

# Generated at 2022-06-22 03:10:14.308398
# Unit test for function parse_source
def test_parse_source():
    source = "def foo(y, x=1): pass"
    mod = parse_source(source)
    assert len(mod.children) == 1  # function definition

# Generated at 2022-06-22 03:10:19.162722
# Unit test for function parse_source
def test_parse_source():
    # Issue #380: Variable RNN_CELLS is not parsed as constant
    # https://github.com/thonny/thonny/issues/380
    try:
        tree = parse_source("RNN_CELLS = 1")
        assert tree.children[0].children[1].type == "constant", "Variable RNN_CELLS should be parsed as constant"
    except Exception:
        logger.exception("Exception in test_parse_source")
        raise

# Generated at 2022-06-22 03:10:28.293232
# Unit test for function parse_source
def test_parse_source():
    """Test the function parse_source()"""
    import parso.python

    ast_tree = parse_source("def first_function():pass")
    assert isinstance(ast_tree, parso.python.tree.Module)
    assert ast_tree.type == "file_input"
    found_first_function = False
    for c in ast_tree.children:
        if c.type == "funcdef" and c.name == "first_function":
            found_first_function = True
            break
    assert found_first_function == True


# Generated at 2022-06-22 03:10:32.936126
# Unit test for function parse_source
def test_parse_source():
    # OK
    parse_source("# comment\n\ndef test():\n    pass")
    parse_source("@test\nclass Test:\n    pass")
    # Error
    from parso.python.tree import PythonNode

    with pytest.raises(ParseError):
        parse_source("")
    with pytest.raises(TypeError):
        parse_source(PythonNode())



# Generated at 2022-06-22 03:10:37.967871
# Unit test for function get_definitions
def test_get_definitions():
    import inspect
    import os

    import jedi

    # jedi version dependent stuff
    if _using_older_jedi(jedi):
        def_name = "Definition"
        def_type = "class"
    else:
        def_name = "Definition"
        def_type = "definition"

    # Test 1: Get definition of function from same file
    with open(os.path.realpath(__file__)) as f:
        test_source = f.read()
    results = get_definitions(test_source, 2, 13, os.path.realpath(__file__))
    assert results[0].name == "get_definitions"
    assert results[0].module_path == os.path.realpath(__file__)
    assert results[0].line == 3
    assert results[0].column

# Generated at 2022-06-22 03:10:42.406464
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse
    from parso.python.tree import Import


# Generated at 2022-06-22 03:10:50.095248
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test for source with no import
    source = "my_test_var = 10\nmy_test_var"
    expected_completions = [
        ThonnyCompletion(
            name="my_test_var",
            complete="my_test_var",
            type="instance",
            description="int",
            parent=None,
            full_name="my_test_var",
        )
    ]
    actual_completions = get_script_completions(source, 0, 15, "my_test_file.py")
    assert len(actual_completions) == len(expected_completions)
    for i in range(len(expected_completions)):
        assert actual_completions[i].name == expected_completions[i].name