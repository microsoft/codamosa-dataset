

# Generated at 2022-06-18 09:17:50.703395
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            self.test_file_content = open(self.test_file_path).read()
            self.test_file_module = parso.parse(self.test_file_content)

        def test_get_definitions(self):
            # Test function definition
            def_node = self.test_file_module.children[0]
            def_name = def_node.children[1].value
            def_line = def_node.start_pos[0]
            def_

# Generated at 2022-06-18 09:18:01.778066
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys", "type": "module"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "argv"
    assert completions[0].complete == "argv"
    assert completions[0].type == "instance"
    assert completions[0].description == "list of command line arguments"
    assert completions[0].parent == "sys"

# Generated at 2022-06-18 09:18:09.861888
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os\nos.path.join('')"
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "join")
            self.assertEqual(completions[0].complete, "join")
            self.assertEqual(completions[0].type, "function")

# Generated at 2022-06-18 09:18:14.474230
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("a", [], None) == []
    else:
        assert get_interpreter_completions("a", [], None) == [
            ThonnyCompletion(name="abs", complete="abs", type="function", description="", parent=None, full_name="abs")
        ]

# Generated at 2022-06-18 09:18:20.134647
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.pa", 0, 15, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:18:32.096673
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Param
    from jedi.api.classes import Statement
    from jedi.api.classes import KeywordStatement
    from jedi.api.classes import ImportStatement
    from jedi.api.classes import ImportFromStatement
    from jedi.api.classes import Flow
    from jedi.api.classes import ClassOrFunc


# Generated at 2022-06-18 09:18:42.654383
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the test file
    test_file = os.path.join(tmpdir, "test_file.py")
    with open(test_file, "w") as f:
        f.write("def test_func(a, b, c):\n    pass")

    # Add the temporary directory to the python path
    sys.path.append(tmpdir)

    # Create a jedi interpreter
    interpreter = Interpreter("import test_file; test_file.test_func(a=1, b=2, c=3)", [])
    # Get the completions
    completions = get_interpreter_

# Generated at 2022-06-18 09:18:53.526885
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        print("Older jedi")
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
    else:
        print("Newer jedi")
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.complete()

    for completion in completions:
        print(completion.name)

    if _using_older_jedi(jedi):
        print("Older jedi")
        interpreter = jedi.Interpreter("import os", [{"os": os}])
        completions = interpreter.completions()
    else:
        print("Newer jedi")

# Generated at 2022-06-18 09:19:03.843790
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi import __version__ as jedi_version

    if jedi_version[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        # jedi 0.13-0.17
        assert get_script_completions(
            "import sys\nsys.pa",
            1,
            13,
            "",
            sys_path=["/home/user/my_project"],
        ) == [
            ThonnyCompletion(
                name="path",
                complete="path",
                type="module",
                description="sys.path",
                parent="sys",
                full_name="sys.path",
            )
        ]

# Generated at 2022-06-18 09:19:16.423883
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_module_names_containing_name
    from jedi.api.helpers import get_module_names_starting_with_name
    from jedi.api.helpers import get_module_names_ending_with_name
    from jedi.api.helpers import get_module_names_matching_name

# Generated at 2022-06-18 09:19:40.147904
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os


# Generated at 2022-06-18 09:19:42.395176
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase


# Generated at 2022-06-18 09:19:54.012615
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        row = 2
        column = 10
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].line == 1
        assert definitions[0].column == 7
        assert definitions[0].module_path == "sys"
    else:
        source = "import sys\nsys.path"
        row = 2
        column = 10
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].line == 1
        assert definitions[0].column == 7

# Generated at 2022-06-18 09:20:05.938393
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
    ]

    completions = get_script_completions("import sys\nsys.path", 1, 10, "")
    assert completions == [
        Completion("path", "path", "module", "", None, "sys.path"),
    ]


# Generated at 2022-06-18 09:20:12.969213
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def test_get_completions(self):
            source = "import sys\nsys.exi"
            row = 2
            column = 9
            filename = "test.py"
            completions = get_script_completions(source, row, column, filename)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "exit")
            self.assertEqual(completions[0].complete, "exit")
            self.assertEqual(completions[0].type, "function")
            self.assertEqual(completions[0].description, "sys.exit(status)")

# Generated at 2022-06-18 09:20:23.207056
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_interpreter_completions("import os", [{"os": os}])[0].name, "os"
                )
                self.assertEqual(
                    get_interpreter_completions("import sys", [{"sys": sys}])[0].name, "sys"
                )
                self.assertEqual(
                    get_interpreter_completions("import sys", [{"sys": sys}])[0].complete,
                    "sys",
                )
                self.assertE

# Generated at 2022-06-18 09:20:31.293696
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys\nsys.", 1, 6, "")
    assert completions == [Completion("sys", "sys", "module", "The Python standard library.", "", "sys")]

    completions = get_script_completions("import sys\nsys.path.", 1, 11, "")
    assert completions == [Completion("path", "path", "module", "sys.path", "sys", "sys.path")]

    completions = get_script_completions("import sys\nsys.path.append(", 1, 21, "")

# Generated at 2022-06-18 09:20:39.699365
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.helpers import get_module_names

    def _get_definitions(source: str, row: int, column: int, filename: str):
        if _using_older_jedi(jedi):
            script = jedi.Script(source, row, column, filename)
            return script.goto_definitions()
        else:
            script = jedi.Script(code=source, path=filename)
            return script.infer(line=row, column=column)

    # test for function

# Generated at 2022-06-18 09:20:45.556550
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if sys.version_info[0] == 2:
        return

    source = """
import sys
sys.path.append("/home/user/my_module")
import my_module

my_module.
"""
    completions = get_script_completions(source, row=5, column=12, filename="")
    assert len(completions) == 1
    assert completions[0].name == "my_func"
    assert completions[0].complete == "my_func("


# Generated at 2022-06-18 09:20:55.433746
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    # Test for jedi 0.13
    if _using_older_jedi(jedi):
        source = "import sys\n"
        row = 2
        column = 0
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].type == "module"
        assert definitions[0].module_name == "sys"
        assert definitions[0].line == 1
        assert definitions[0].column == 7
        assert definitions[0].module_path == "sys"

    # Test for jedi 0.18
    else:
        source = "import sys\n"
        row = 2
        column = 0
        filename = "test.py"

# Generated at 2022-06-18 09:21:13.624447
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:21:14.951729
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:21:19.931054
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/"])
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/"])

# Generated at 2022-06-18 09:21:29.856922
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import math\nmath.sqrt"
        namespaces = [{"math": math}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "sqrt"
        assert completions[0].complete == "sqrt"
        assert completions[0].type == "function"
        assert completions[0].description == "sqrt(x)\n\nReturn the square root of x."
        assert completions[0].parent == "math"
        assert completions[0].full_name == "math.sqrt"
    else:
        source = "import math\nmath.sqrt"

# Generated at 2022-06-18 09:21:41.253590
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    from thonny.misc import running_on_mac_os
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy
    from thonny.plugins.micropython.backend import MicroPythonProxy

# Generated at 2022-06-18 09:21:52.120803
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class Test(unittest.TestCase):
        def test_get_definitions(self):
            defs = get_definitions(
                "import os\nos.path.join('a', 'b')", 0, 0, "test.py"
            )
            self.assertEqual(len(defs), 1)
            self.assertEqual(defs[0].module_name, "os")
            self.assertEqual(defs[0].line, 1)
            self.assertEqual(defs[0].column, 0)
            self.assertEqual(defs[0].description, "module os")

    unittest.main(module="test_jedi_utils", exit=False)


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-18 09:22:01.568448
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\nsys.path.ap"
    row = 2
    column = 15
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert completions == Script(source, row, column, filename).completions()

    source = "import sys\nsys.path.ap"
    row = 2
    column = 15
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename, sys_path=["/tmp"])

# Generated at 2022-06-18 09:22:05.696108
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"



# Generated at 2022-06-18 09:22:15.566026
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "sys" in [c.name for c in completions]
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0

# Generated at 2022-06-18 09:22:21.548423
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import parso
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:22:44.125589
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import os", 0, 7, "")
    assert completions == [Completion("os", "os", "module", "", "", "os")]

    completions = get_script_completions("import os\nos.", 1, 3, "")
    assert completions == [Completion("path", "path", "module", "", "", "os.path")]

    completions = get_script_completions("import os\nos.path.join", 1, 12, "")
    assert completions == [Completion("join", "join", "function", "", "", "os.path.join")]

    completions = get_script_completions

# Generated at 2022-06-18 09:22:55.100989
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script

    source = "import sys\nsys.path.ap"
    row = 2
    column = 14
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "append"
    assert completions[0].complete == "append"
    assert completions[0].type == "function"
    assert completions[0].description == "append(${1:object}[, /])"
    assert completions[0].parent == "list"
    assert completions[0].full_name == "list.append"

    source = "import sys\nsys.path.ap"
    row = 2
    column = 14

# Generated at 2022-06-18 09:23:05.426670
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    from thonny.plugins.jedi_utils import get_definitions
    from thonny.plugins.jedi_utils import _using_older_jedi

    if _using_older_jedi(jedi):
        print("Skipping test_get_definitions for jedi < 0.18")
        return

    test_file = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
    source = open(test_file).read()
    definitions = get_definitions(source, 1, 1, test_file)
    assert len(definitions) == 1
    assert definitions[0].module_path == test_file
    assert definitions[0].line == 1
    assert definitions[0].column == 4

# Generated at 2022-06-18 09:23:13.688686
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:23:23.778417
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            namespaces = [{"a": 1, "b": 2}]
            source = "a."
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "b")
            self.assertEqual(completions[0].complete, "b")
            self.assertEqual(completions[0].type, "int")
            self.assertEqual(completions[0].description, "int")

# Generated at 2022-06-18 09:23:31.857127
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].type == "module"
        assert get_script_completions("import sys", 0, 7, "")[0].description == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].parent == "sys"
        assert get_script_complet

# Generated at 2022-06-18 09:23:42.070507
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:23:49.313641
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/tmp')\n"

# Generated at 2022-06-18 09:23:53.449756
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:24:03.111876
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import jedi
    import parso
    import os
    import sys
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_script_completions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)


# Generated at 2022-06-18 09:24:27.177333
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.ap", 0, 0, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"

    completions = get_script_completions("import sys; sys.path.append", 0, 0, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"

    completions = get_script_completions("import sys; sys.path.append(", 0, 0, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append("


# Generated at 2022-06-18 09:24:29.483838
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions


# Generated at 2022-06-18 09:24:38.868368
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.exceptions import NotFoundError
    from jedi.api.settings import settings
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import NamespaceName
    from jedi.api.classes import FunctionName
    from jedi.api.classes import ClassName
    from jedi.api.classes import InstanceName
    from jedi.api.classes import ImportedName
    from jedi.api.classes import ParamName

# Generated at 2022-06-18 09:24:46.453372
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.helpers import get_interpreter_completions
    from jedi.api.helpers import get_definitions
    from jedi.api.helpers import parse_source
    from jedi.api.helpers import get_statement_of_position
    from jedi.api.helpers import _using_older_jedi
    from jedi.api.helpers import _tweak_completions
    from jedi.api.helpers import _get_new_jedi_project
    from jedi.api.helpers import _copy_of_get_statement_of_position
    import jedi
    import parso
    import os
    import sys
    import unittest

# Generated at 2022-06-18 09:24:53.358548
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\nsys.path."
    namespaces = [{"__name__": "__main__", "__doc__": None, "__package__": None, "sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "append" in [c.name for c in completions]

# Generated at 2022-06-18 09:25:01.999667
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions(
        source="import os\nos.path.join(", namespaces=[{}]
    )
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "os.path.join"
    assert completions[0].complete == "os.path.join"
    assert completions[0].type == "function"
    assert completions[0].description == "os.path.join(path, *paths)"
    assert completions[0].parent == "os.path"
    assert completions[0].full_name == "os.path.join"

# Generated at 2022-06-18 09:25:11.590108
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment

    source = "import sys\n"
    row = 2
    column = 1
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert completions == [Completion(name="sys", complete="sys", type="module", description="sys", parent=None, full_name="sys")]

    # Test with jedi 0.18
    project = Project(path=sys_path[0], added_sys_path=sys_path)
   

# Generated at 2022-06-18 09:25:22.271580
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from thonny.plugins.jedi_backend import utils

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_content_with_error = self.test_file_content + "\n" + "a = b"

# Generated at 2022-06-18 09:25:30.615159
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import SourceFile
    from jedi.api.classes import SourceModule
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Keyword
    from jedi.api.classes import Statement
    from jedi.api.classes import Module
    from jedi.api.classes import Param
    from jedi.api.classes import Importer
    from jedi.api.classes import ImportPath

# Generated at 2022-06-18 09:25:40.332861
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_location
    from jedi.api.helpers import get_definition_context
    from jedi.api.helpers import get_definition_names
    from jedi.api.helpers import get_definition_description
    from jedi.api.helpers import get_definition_module_path
    from jedi.api.helpers import get_definition_line_nr
    from jedi.api.helpers import get_definition_column
    from jedi.api.helpers import get_definition_type
    from jedi.api.helpers import get_definition_full_name
    from jedi.api.helpers import get_definition_parent
    from jedi.api.helpers import get_definition_docstring

# Generated at 2022-06-18 09:26:04.864058
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert comple

# Generated at 2022-06-18 09:26:13.822037
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 1
    column = 8
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6/"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full

# Generated at 2022-06-18 09:26:21.798181
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            # Test that the function get_interpreter_completions returns the same
            # completions as jedi.Interpreter.complete()
            source = "import os"
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            interpreter = jedi.Interpreter(source, namespaces)
            self.assertEqual(completions, interpreter.complete())


# Generated at 2022-06-18 09:26:31.311442
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    import jedi

    completions = get_script_completions("import os", 0, 7, "")
    assert completions == [
        ThonnyCompletion(
            name="os",
            complete="os",
            type="module",
            description="Module os",
            parent=None,
            full_name="os",
        )
    ]

    completions = get_script_completions("import os\nos.", 1, 3, "")

# Generated at 2022-06-18 09:26:34.767329
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

# Generated at 2022-06-18 09:26:41.476759
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import SourceFile
    from jedi.api.classes import SourceModule
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import InstanceElement
    from jedi.api.classes import ClassMethod
    from jedi.api.classes import FunctionExec

# Generated at 2022-06-18 09:26:45.522936
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    def get_completions(source, row, column, filename, sys_path=None):
        completions = get_script_completions(source, row, column, filename, sys_path)
        return [c.name for c in completions]

    assert get_completions("import sys", 0, 0, "") == ["sys"]
    assert get_completions("import sys", 0, 7, "") == []
    assert get_completions("import sys", 0, 8, "") == []

# Generated at 2022-06-18 09:26:53.419598
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0

# Generated at 2022-06-18 09:26:56.363118
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Generated at 2022-06-18 09:27:06.487805
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from jedi.api.classes import Completion
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Name
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Instance
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import Param
    from jedi.api.classes import Flow
    from jedi.api.classes import ClassOrFunc
    from jedi.api.classes import Scope
   