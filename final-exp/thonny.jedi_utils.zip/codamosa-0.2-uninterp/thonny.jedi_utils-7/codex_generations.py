

# Generated at 2022-06-18 09:17:37.303760
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.__version__ = "0.17.0"
    assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

    jedi.__version__ = "0.18.0"
    assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

    jedi.__version__ = "0.19.0"
    assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

    jedi.__version__ = "0.20.0"
    assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

    jedi.__version__ = "0.21.0"

# Generated at 2022-06-18 09:17:47.453896
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    from thonny.jedi_utils import ThonnyCompletion
    import os

    test_file = os.path.join(os.path.dirname(__file__), "test_jedi_utils.py")
    with open(test_file, "r") as f:
        source = f.read()

    completions = get_script_completions(source, 1, 1, test_file)
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "test_get_script_completions"
    assert completions[0].complete == "test_get_script_completions"

# Generated at 2022-06-18 09:17:51.219584
# Unit test for function get_definitions

# Generated at 2022-06-18 09:18:02.290004
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys\n"
            namespaces = [{"name": "__main__", "path": "<input>"}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)
            self.assertTrue(completions[0].name == "sys")
            self.assertTrue(completions[0].type == "module")

        def test_get_interpreter_completions_with_sys_path(self):
            source = "import sys\n"

# Generated at 2022-06-18 09:18:10.244490
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.", 0, 0, "") == []
        assert get_script_completions("import sys; sys.", 0, 0, "", sys_path=["/"]) == []
        assert get_script_completions("import sys; sys.", 0, 0, "", sys_path=["/"]) == []
        assert get_script_completions("import sys; sys.", 0, 0, "", sys_path=["/"]) == []
        assert get_script_completions("import sys; sys.", 0, 0, "", sys_path=["/"]) == []

# Generated at 2022-06-18 09:18:14.902792
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
   

# Generated at 2022-06-18 09:18:27.531130
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-18 09:18:32.472198
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:18:42.857548
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    def _test_get_script_completions(source, row, column, filename, sys_path=None):
        script = Script(source, row, column, filename, sys_path=sys_path)
        completions = script.completions()
        completions_new = get_script_completions(source, row, column, filename, sys_path=sys_path)
        assert len(completions) == len(completions_new)
        for i in range(len(completions)):
            assert completions[i].name == completions_new[i].name
            assert completions[i].complete == completions_new[i].complete

# Generated at 2022-06-18 09:18:47.286862
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:19:14.060967
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion

    source = "import math\nmath.p"
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "pi"
    assert completions[0].complete == "math.pi"
    assert completions[0].type == "float"
    assert completions[0].description == "pi = 3.141592653589793"
    assert completions[0].parent == "math"
    assert completions[0].full_name == "math.pi"

    # Test with sys_path
    import os
    import tempfile
    import shutil

   

# Generated at 2022-06-18 09:19:26.395537
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    from thonny.jedi_utils import ThonnyCompletion

    source = "import sys\n"
    row = 2
    column = 0
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:19:28.793106
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree


# Generated at 2022-06-18 09:19:34.667197
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.path.append('/tmp'); import os; os.", [{}])[0].name == "path"
    else:
        assert get_interpreter_completions("import sys; sys.path.append('/tmp'); import os; os.", [{}], sys_path=["/tmp"])[0].name == "path"

# Generated at 2022-06-18 09:19:46.195563
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path=sys_path)

    def _get_interpreter_completions(source, namespaces, sys_path=None):
        return get_interpreter_completions(source, namespaces, sys_path=sys_path)

    def _get_definitions(source, row, column, filename):
        return get_definitions(source, row, column, filename)

    def _get_script(source, row, column, filename):
        return Script(source, row, column, filename)

# Generated at 2022-06-18 09:19:53.776512
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_utils import get_interpreter_completions

    completions = get_interpreter_completions(
        "import sys\nsys.path.append('/home/user/')\n",
        [{"name": "sys", "value": {"path": ["/home/user/"]}}],
    )
    assert len(completions) > 0
    assert any(c.name == "append" for c in completions)



# Generated at 2022-06-18 09:19:56.371826
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_location


# Generated at 2022-06-18 09:20:07.900767
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import math\nmath.sqrt(4)"
        row = 2
        column = 6
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].type == "function"
        assert definitions[0].full_name == "math.sqrt"
    else:
        source = "import math\nmath.sqrt(4)"
        row = 2
        column = 6
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)

# Generated at 2022-06-18 09:20:18.466588
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    # jedi.set_debug_function()
    # jedi.set_debug_function(jedi.debug.print_to_stdout)

    # Test for jedi 0.13
    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].type == "module"
        assert get_script_completions("import sys", 0, 7, "")[0].description == "sys"

# Generated at 2022-06-18 09:20:25.826823
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:20:50.160847
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os.path
    import sys
    import unittest


# Generated at 2022-06-18 09:21:00.318751
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment

    source = "import sys; sys.path.append('/home/user/my_module'); import my_module; my_module."
    namespaces = [
        {"type": "module", "name": "sys", "module_path": "sys", "is_compiled": False},
        {"type": "module", "name": "my_module", "module_path": "my_module", "is_compiled": False},
    ]
    sys_path = ["/home/user/my_module"]
    interpreter = Interpreter(source, namespaces, sys_path=sys_path)

# Generated at 2022-06-18 09:21:10.833820
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts

# Generated at 2022-06-18 09:21:23.642379
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.environment import find_virtualenvs
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_default_environment
    from jedi.api.environment import get_system_environment
    from jedi.api.environment import find_virtualenvs
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_default_environment
    from jedi.api.environment import get_system_environment

# Generated at 2022-06-18 09:21:27.249047
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"name": "__main__", "path": "<input>"}]
    interpreter = Interpreter(source, namespaces)
    completions = interpreter.complete()
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "__main__"
   

# Generated at 2022-06-18 09:21:37.111561
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_default_environment
    from jedi.api.settings import jedi_path
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import find_virtualenvs
    from jedi.api.environment import find_system_environments
    from jedi.api.environment import find_virtualenv_environments
    from jedi.api.environment import find_conda_environments
    from jedi.api.environment import find_environments
    from jedi.api.environment import find_pythons

# Generated at 2022-06-18 09:21:48.585416
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import inspect
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            test_dir = os.path.dirname(inspect.getfile(inspect.currentframe()))
            test_file = os.path.join(test_dir, "test_get_definitions.py")
            with open(test_file, "r") as f:
                source = f.read()
            row = 8
            column = 4
            filename = test_file
            if _using_older_jedi(jedi):
                script = jedi.Script(source, row, column, filename)
                definitions = script.goto_definitions()

# Generated at 2022-06-18 09:21:49.170674
# Unit test for function get_definitions

# Generated at 2022-06-18 09:21:54.075110
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])

# Generated at 2022-06-18 09:21:58.121785
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:22:25.166241
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].name == "join"
        assert definitions[0].type == "function"
        assert definitions[0].description == "join(path, *paths) -> str"
        assert definitions[0].parent.name == "path"
        assert definitions[0].parent.type == "module"
        assert definitions[0].parent.description == "Common pathname manipulations, "

# Generated at 2022-06-18 09:22:34.610299
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "os.path" in [c.name for c in completions]
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0

# Generated at 2022-06-18 09:22:44.277925
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import os\nos.path.join('')"
    completions = get_script_completions(source, 1, len(source), "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:22:55.275881
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "sys"

# Generated at 2022-06-18 09:23:05.591917
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    def check_definitions(source, row, column, expected_definitions):
        definitions = get_definitions(source, row, column, "test.py")
        assert len(definitions) == len(expected_definitions)
        for i in range(len(definitions)):
            assert definitions[i].line == expected_definitions[i][0]
            assert definitions[i].column == expected_definitions[i][1]

    check_definitions(
        "import os\nos.path.join(",
        1,
        20,
        [(0, 9), (0, 9), (0, 9), (0, 9), (0, 9), (0, 9), (0, 9), (0, 9), (0, 9), (0, 9)],
    )


# Generated at 2022-06-18 09:23:15.586986
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    import parso
    import os
    import sys
    import inspect
    import unittest
    import jedi
    import jedi.parser_utils
    import jedi.api.classes
    import jedi.api.helpers
    import jedi.api.keywords
    import jedi.api.project
    import jedi.api.references
    import jedi.api.usages
    import jedi.api.names
    import jedi.api.classes
    import jedi.api.helpers
    import jedi.api.keywords
    import jedi.api.project
    import jedi.api.references
    import jedi.api.usages
    import jedi.api.names
    import jedi.api.classes
    import jedi.api.helpers

# Generated at 2022-06-18 09:23:25.688497
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_module_names
    from jedi.api.project import get_sys_path
    from jedi.api.environment import get_default_environment
    from jedi.api.environment import InterpreterEnvironment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_system_environment
    from jedi.api.environment import get_cached_system_environment
    from jedi.api.environment import get_cached_environment
    from jedi.api.environment import get_cached_environments
    from jedi.api.environment import clear_caches
    from jedi.api.environment import get_environments

# Generated at 2022-06-18 09:23:33.075723
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    def _get_completions(source, namespaces, sys_path=None):
        completions = get_interpreter_completions(source, namespaces, sys_path)
        return [c.name for c in completions]

    assert _get_completions("import sys; sys.", [{}]) == ["path", "argv", "exit", "stdin"]
    assert _get_completions("import sys; sys.path", [{}]) == []
    assert _get_completions("import sys; sys.path", [{"sys": sys}]) == ["append"]
    assert _get_completions("import sys; sys.path", [{"sys": sys}, {}]) == ["append"]

# Generated at 2022-06-18 09:23:43.572460
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].type == "function"
        assert definitions[0].full_name == "os.path.join"
    else:
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)
        assert len(definitions)

# Generated at 2022-06-18 09:23:52.231944
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    namespaces = [{"a": 1, "b": 2}]
    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"
    assert completions[0].parent == get_names_of_scope(namespaces[0])
    assert completions[0].full_name == "a"

    completions = get_interpreter_completions("a.", namespaces)
    assert len(completions) == 1


# Generated at 2022-06-18 09:24:34.719208
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/usr/lib/python3.8"])
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)


# Generated at 2022-06-18 09:24:37.945271
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-18 09:24:42.008336
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 1, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:24:51.196571
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.parser_utils import get_cached_code_lines
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.subprocess import SubprocessName

    class FakeInterpreter(Interpreter):
        def __init__(self, source, namespaces, sys_path=None):
            self.source = source
            self.namespaces = namespaces
            self.sys_path = sys_path

        def _get_module(self, module_context, position=None):
            return None

        def _get_module_context(self, module_context, position=None):
            return None


# Generated at 2022-06-18 09:25:00.752386
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.compiled.access import TreeNameDefinition
    from jedi.evaluate.compiled.value import CompiledValueName
    from jedi.evaluate.compiled.value import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.value import CompiledInstance
    from jedi.evaluate.compiled.value import CompiledFunction
    from jedi.evaluate.compiled.value import CompiledValueSet
    from jedi.evaluate.compiled.value import CompiledValueName

# Generated at 2022-06-18 09:25:10.406205
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'test')"
    namespaces = [{'__name__': '__main__', '__doc__': None, '__package__': None, 'os': os, 'sys': sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    assert completions[0].name == 'os'
    assert completions[1].name == 'sys'

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'test')"

# Generated at 2022-06-18 09:25:16.634419
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": jedi.__file__}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys.argv" in [c.name for c in completions]



# Generated at 2022-06-18 09:25:25.600745
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp"])
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp"])
    assert isinstance(completions, list)

# Generated at 2022-06-18 09:25:32.520254
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.path", 1, 5, "")
    assert completions == [Completion("path", "path", "attribute", "", "", "sys.path")]

    completions = get_script_completions("import sys\nsys.path.", 1, 11, "")
    assert completions == [Completion("append", "append", "function", "", "", "sys.path.append")]


# Generated at 2022-06-18 09:25:42.509552
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    def check(source, row, column, expected):
        completions = get_script_completions(source, row, column, "test.py")
        assert len(completions) == len(expected)
        for i in range(len(completions)):
            assert completions[i].name == expected[i][0]
            assert completions[i].complete == expected[i][1]
            assert completions[i].type == expected[i][2]
            assert completions[i].description == expected[i][3]
            assert completions[i].parent == expected[i][4]
            assert completions[i].full_name == expected[i][5]


# Generated at 2022-06-18 09:26:26.068516
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    def mock_completions():
        return [
            Mock(
                name="name1",
                complete="complete1",
                type="type1",
                description="description1",
                parent="parent1",
                full_name="full_name1",
            ),
            Mock(
                name="name2",
                complete="complete2",
                type="type2",
                description="description2",
                parent="parent2",
                full_name="full_name2",
            ),
        ]

    def mock_script(source, row, column, filename, sys_path=None):
        return Mock(completions=mock_completions)


# Generated at 2022-06-18 09:26:29.758619
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.ap", 0, 23, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"

# Generated at 2022-06-18 09:26:37.321057
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    import sys
    import os
    import os.path
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_script_completions(self):
            # test with older jedi
            if _using_older_jedi(jedi):
                script = jedi.Script("import sys\nsys.pa", 1, 9, "")
                completions = script.completions()
                self.assertEqual(len(completions), 1)
                self.assertEqual(completions[0].name, "path")
                self.assertEqual(completions[0].complete, "path")
                self.assertEqual(completions[0].type, "attribute")

# Generated at 2022-06-18 09:26:44.681653
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from jedi.api.classes import Completion

    source = "import sys\n"
    namespaces = [{"name": "__main__", "locals": {}, "globals": {}}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    # Test with sys_path
    completions = get_interpreter_completions(source, namespaces, sys_path=["/"])
    assert isinstance(completions, list)
    assert len(completions) > 0

# Generated at 2022-06-18 09:26:48.033745
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.path.ap", 1, 17, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"



# Generated at 2022-06-18 09:26:56.456170
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 1, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nprint(sys.argv)", 2, 8, "")
    assert completions == [Completion("argv", "argv", "attribute", "", "", "sys.argv")]

    completions = get_script_completions("import sys\nprint(sys.argv[0])", 2, 13, "")
    assert completions == [Completion("0", "0", "int", "", "", "")]

    comple

# Generated at 2022-06-18 09:27:06.588786
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    completions = get_script_completions("print('Hello')", 0, 0, "test.py")
    assert len(completions) > 0
    assert "print" in [c.name for c in completions]

    completions = get_script_completions("print('Hello')", 0, 6, "test.py")
    assert len(completions) > 0
    assert "print" in [c.name for c in completions]

    completions = get_script_completions("print('Hello')", 0, 7, "test.py")
    assert len(completions) == 0

    completions = get_script_completions("print('Hello')", 1, 0, "test.py")
    assert len

# Generated at 2022-06-18 09:27:11.738896
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys", [{"sys": sys}])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:27:20.683756
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script

    source = "import sys\nsys.path.append('/home/user/')\n"
    row = 2
    column = 16
    filename = "test.py"
    sys_path = ["/home/user/"]

    completions = get_script_completions(source, row, column, filename, sys_path)

    assert len(completions) > 0
    assert completions[0].name == "append"
    assert completions[0].complete == "append"
    assert completions[0].type == "function"
    assert completions[0].description == "append(${1:object})"
    assert completions[0].parent == "sys.path"
    assert completions[0].full_name == "sys.path.append"