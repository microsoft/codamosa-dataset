

# Generated at 2022-06-18 09:18:27.986836
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(__file__))
    source = "import test_jedi_utils\ntest_jedi_utils.test_get_definitions()"
    row = 2
    column = 10
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].module_path == os.path.abspath(__file__)
    assert definitions[0].line == test_get_definitions.__code__.co_firstlineno
    assert definitions[0].column == 0
    assert definitions[0].type == "function"
    assert definitions[0].name == "test_get_definitions"

# Generated at 2022-06-18 09:18:39.901880
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.script import Script
    from jedi import __version__
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.script import Script
    from jedi import __version__
    import os
    import sys
    import unittest
    import j

# Generated at 2022-06-18 09:18:51.142566
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    # Test for jedi version 0.13.2
    source = "import os\nos.path.join("
    row = 1
    column = len(source)
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "dirname"
    assert completions[0].complete == "dirname="
    assert completions[0].type == "param"
    assert completions[0].description == "dirname -- path component"
    assert completions[0].parent == "os.path.join"
    assert completions[0].full_name == "os.path.join.dirname"



# Generated at 2022-06-18 09:18:58.155477
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "argv"
    assert completions[0].complete == "argv"

    completions = get_script_completions("import sys\nsys.argv[0]", 1, 10, "")
    assert len

# Generated at 2022-06-18 09:19:00.230286
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-18 09:19:04.271266
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import os", [], sys_path=["/"])
    else:
        assert get_interpreter_completions("import os", [], sys_path=["/"])

# Generated at 2022-06-18 09:19:16.777585
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    import jedi

    source = "import sys\n"
    row = 2
    column = 0
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6"]

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))
        completions = script.complete(line=row, column=column)

    assert len

# Generated at 2022-06-18 09:19:21.669138
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    import jedi


# Generated at 2022-06-18 09:19:32.237419
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import InterpreterObject
    from jedi.api.classes import InterpreterFunction
    from jedi.api.classes import InterpreterClass
    from jedi.api.classes import InterpreterModule
    from jedi.api.classes import InterpreterInstance
    from jedi.api.classes import InterpreterName
    from jedi.api.classes import InterpreterCompiledObject
    from jedi.api.classes import InterpreterStatement
    from jedi.api.classes import InterpreterParam
    from jedi.api.classes import InterpreterArray

# Generated at 2022-06-18 09:19:43.089529
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\nos.path.join('a', 'b')"
            row = 1
            column = 10
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].description, "function join")
            self.assertEqual(definitions[0].type, "function")
            self.assertEqual(definitions[0].full_name, "os.path.join")
            self.assertEqual(definitions[0].name, "join")
            self.assertEqual

# Generated at 2022-06-18 09:19:57.258466
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import os\nos.path.join"
    completions = get_script_completions(source, 0, len(source), "test.py")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "join"



# Generated at 2022-06-18 09:20:08.570674
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    from jedi.api.classes import Definition
    from jedi.api.project import Project

    class TestCase(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\nos.path.join"
            row = 1
            column = 15
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertIsInstance(definitions, list)
            self.assertIsInstance(definitions[0], Definition)
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 15)
            self.assertEqual(definitions[0].module_path, "os.path")

# Generated at 2022-06-18 09:20:18.984812
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    # Get the path of the current file
    file_path = os.path.realpath(__file__)
    # Get the directory of the current file
    dir_path = os.path.dirname(file_path)
    # Get the parent directory of the current file
    parent_dir_path = os.path.dirname(dir_path)
    # Add the parent directory to the path
    sys.path.append(parent_dir_path)

    # Get the path of the file to test
    file_to_test_path = os.path.join(parent_dir_path, "test_files", "test_get_definitions.py")
    # Open the file to test
    file_to_test = open(file_to_test_path, "r")
   

# Generated at 2022-06-18 09:20:27.961574
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os\nos.path.join"
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "join")
            self.assertEqual(completions[0].complete, "join")
            self.assertEqual(completions[0].type, "function")
            self.assertEqual(completions[0].description, "join(a, *p)")


# Generated at 2022-06-18 09:20:37.784878
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import os\nos.", 3, 4, "test.py")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "os"

    completions = get_script_completions("import os\nos.", 3, 3, "test.py")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "os"

    completions = get_script_completions("import os\nos.", 3, 2, "test.py")
    assert len(completions) > 0

# Generated at 2022-06-18 09:20:40.314637
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import unittest


# Generated at 2022-06-18 09:20:49.057248
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os; os.path.join('a', 'b')"
            namespaces = [{"os": jedi.Interpreter(source, []).goto_definitions()[0].module}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "join")

    unittest.main(module="test_jedi_utils", exit=False)

# Generated at 2022-06-18 09:20:59.212889
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from thonny.plugins.jedi_backend import utils

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_definitions.py"
            )
            self.test_file_path_2 = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_definitions_2.py"
            )

# Generated at 2022-06-18 09:21:09.529183
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    defs = get_definitions(
        "import os\nos.path.join('a', 'b')", 0, 0, "test.py"
    )  # type: List[Definition]
    assert len(defs) == 1
    assert defs[0].module_name == "os"
    assert defs[0].line == 1
    assert defs[0].column == 0

    defs = get_definitions(
        "import os\nos.path.join('a', 'b')", 1, 0, "test.py"
    )  # type: List[Definition]
    assert len(defs) == 1
    assert defs[0].module_name == "os.path"
    assert defs[0].line == 1

# Generated at 2022-06-18 09:21:17.410063
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions(
        "import sys\nsys.path.append('/home/user/')\nimport",
        3,
        7,
        "test.py",
        sys_path=["/home/user/"],
    )
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:21:37.719269
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            if _using_older_jedi(jedi):
                script = jedi.Script(source="import os", row=0, column=0, filename="")
                definitions = script.goto_definitions()
                self.assertEqual(len(definitions), 1)
                self.assertEqual(definitions[0].module_name, "os")
                self.assertEqual(definitions[0].type, "module")
                self.assertEqual(definitions[0].line, 0)
                self.assertEqual(definitions[0].column, 0)

# Generated at 2022-06-18 09:21:48.798638
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.path}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:21:59.069230
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    script = Script(source, row, column, filename)
    completions = script.completions()
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "Built-in module sys"
    assert completions[0].parent == None
    assert completions[0].full_name == "sys"
    assert isinstance(completions[0], Completion)

    source = "import sys\nsys."
    row = 2
    column

# Generated at 2022-06-18 09:22:06.689505
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_cached_value
    from jedi.api.keywords import KeywordName
    from jedi.api.names import Name
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Statement
    from jedi.api.classes import Instance
    from jedi.api.classes import Param
    from jedi.api.classes import Importation
    from jedi.api.classes import ImportName
    from jedi.api.classes import DictName
   

# Generated at 2022-06-18 09:22:16.433743
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.interpreter import Interpreter
        from jedi.api.classes import Completion

        class MockInterpreter(Interpreter):
            def __init__(self, source, namespaces, sys_path=None):
                self.completions = [
                    Completion("name", "complete", "type", "description", "parent", "full_name")
                ]

        jedi.Interpreter = MockInterpreter
    else:
        from jedi.api.project import Project
        from jedi.api.interpreter import Interpreter
        from jedi.api.classes import Completion


# Generated at 2022-06-18 09:22:25.632503
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_interpreter_completions
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definitions
    from jedi.api.classes import Script
    from jedi.api.helpers import get_script
    from jedi.api.classes import Namespace
    from jedi.api.helpers import get_namespace
    from jedi.api.classes import Source
    from jedi.api.helpers import get_source

# Generated at 2022-06-18 09:22:35.087521
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        completions = get_interpreter_completions(source, [])
        assert len(completions) == 1
        assert completions[0].name == "join"
        assert completions[0].complete == "join"
        assert completions[0].type == "function"
        assert completions[0].description == "join(a, *p) -> path\n\nJoin two or more pathname components, inserting '/' as needed.\nIf any component is an absolute path, all previous path components\nwill be discarded.  An empty last part will result in a path that\nends with a separator."
        assert completions[0].parent == "os.path"

# Generated at 2022-06-18 09:22:44.819811
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.subprocess import CompiledSubprocessModule
    from jedi.evaluate.compiled.builtin import CompiledBuiltinModule
    from jedi.evaluate.compiled.value import CompiledValueSet
    from jedi.evaluate.compiled.value import CompiledInstance
    from jedi.evaluate.compiled.value import CompiledObjectValue
    from jedi.evaluate.compiled.value import CompiledName
    from jedi.evaluate.compiled.value import CompiledValueName
    from jedi.evaluate.compiled.value import CompiledFunction
    from jedi.evaluate.compiled.value import Compiled

# Generated at 2022-06-18 09:22:55.721043
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_utils import get_interpreter_completions
    from jedi import Interpreter
    import sys


# Generated at 2022-06-18 09:23:06.011086
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import os.path
    import unittest


# Generated at 2022-06-18 09:23:27.202446
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Name
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Instance
    from jedi.api.classes import Param
    from jedi.api.classes import Flow
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import ClassOrFunc
   

# Generated at 2022-06-18 09:23:33.867239
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.16 or older
        assert get_interpreter_completions("import os; os.path.join('', '')", [])[0].name == "join"
        assert get_interpreter_completions("import os; os.path.join('', '')", [])[0].complete == "join("
        assert get_interpreter_completions("import os; os.path.join('', '')", [])[0].type == "function"

# Generated at 2022-06-18 09:23:44.052995
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import inspect
    import unittest

    # Get the path of the current file
    current_file_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    # Get the path of the test file
    test_file_path = os.path.join(current_file_path, "test_get_definitions.py")

    # Parse the test file
    with open(test_file_path, "r") as f:
        source = f.read()
    tree = parso.parse(source)

    # Get the definitions of the first class
    class_node = tree.children[0]
    class_name = class_node.name.value

# Generated at 2022-06-18 09:23:46.620218
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
    ]



# Generated at 2022-06-18 09:23:56.658350
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/home/user"])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/home/user/"])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"


# Generated at 2022-06-18 09:24:05.724620
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    completions = get_script_completions("import sys", 0, 0, "")
    assert len(completions) > 0
    assert any(c.name == "sys" for c in completions)

    completions = get_script_completions("import sys", 0, 0, "", sys_path=["/usr/lib/python3.8"])
    assert len(completions) > 0
    assert any(c.name == "sys" for c in completions)

    completions = get_script_completions("import sys", 0, 0, "", sys_path=["/usr/lib/python3.8/"])
    assert len(completions) > 0

# Generated at 2022-06-18 09:24:07.092243
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import jedi_utils


# Generated at 2022-06-18 09:24:07.756142
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:24:17.507464
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_script_completions(self):
            source = "import sys\n"
            row = 1
            column = 7
            filename = "test.py"
            completions = get_script_completions(source, row, column, filename)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")
            self.assertEqual(completions[0].complete, "sys")
            self.assertEqual(completions[0].type, "module")
            self.assertEqual(completions[0].description, "sys")
            self.assertEqual(completions[0].parent, None)

# Generated at 2022-06-18 09:24:21.968944
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:24:49.988980
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("", [{"a": 1}])
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "int"
    assert completions[0].description == "1"
    assert completions[0].parent == "a"
    assert completions[0].full_name == "a"

    completions = get_interpreter_completions("", [{"a": Mock(Completion)}])
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"

# Generated at 2022-06-18 09:24:59.792665
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope_stmt
    from jedi.api.helpers import get_names_of_scope_expr
    from jedi.api.helpers import get_names_of_scope_module
    from jedi.api.helpers import get_names_of_scope_class
    from jedi.api.helpers import get_names_of_scope_function
    from jedi.api.helpers import get

# Generated at 2022-06-18 09:25:09.298293
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            test_dir = os.path.dirname(os.path.abspath(__file__))
            test_file = os.path.join(test_dir, "test_get_definitions.py")
            with open(test_file, "r") as f:
                source = f.read()
            row = 4
            column = 5
            filename = test_file
            if _using_older_jedi(jedi):
                script = jedi.Script(source, row, column, filename)
                definitions = script.goto_definitions()

# Generated at 2022-06-18 09:25:18.300151
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:25:22.574531
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    assert isinstance(get_script_completions("", 0, 0, ""), list)
    assert isinstance(get_script_completions("", 0, 0, "")[0], ThonnyCompletion)
    assert isinstance(get_script_completions("", 0, 0, "")[0], Completion)

# Generated at 2022-06-18 09:25:30.801125
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nimport", 1, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nimport", 1, 8, "")
    assert completions == []

    completions = get_script_completions("import sys\nimport", 1, 9, "")
    assert completions == []

    completions = get_

# Generated at 2022-06-18 09:25:40.584380
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.std", 0, 14, "")
    assert len(completions) == 1
    assert completions[0].name == "stdout"
    assert completions[0].complete == "stdout"
    assert completions[0].type == "module"
    assert completions[0].description == "The standard output file object."
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.stdout"

    completions = get_script_completions("import sys; sys.std", 0, 15, "")
    assert len(completions) == 2
    assert completions[0].name == "stdout"

# Generated at 2022-06-18 09:25:49.827010
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import sys
    import os
    import os.path
    import unittest
    import parso
    import jedi

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_script_completions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_content_with_sys_path = self.test_file_content + "\nimport sys\n"

# Generated at 2022-06-18 09:25:57.658654
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    from thonny.plugins.jedi_utils import get_definitions
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import get_interpreter_completions
    from thonny.plugins.jedi_utils import parse_source
    from thonny.plugins.jedi_utils import get_statement_of_position
    from thonny.plugins.jedi_utils import _using_older_jedi
    from thonny.plugins.jedi_utils import _get_new_jedi_project
    from thonny.plugins.jedi_utils import _tweak_completions

    # Test for get_definitions
    # Test 1
    source

# Generated at 2022-06-18 09:26:07.517454
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    import jedi
    import parso
    import os
    import sys

    # Test for jedi 0.17.0
    if _using_older_jedi(jedi):
        source = "import os\nimport sys\nos.path.join(sys.path[0], 'test')"
        namespaces = [
            {"type": "module", "name": "os", "module_path": os.__file__},
            {"type": "module", "name": "sys", "module_path": sys.__file__},
        ]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "join"

# Generated at 2022-06-18 09:26:34.376346
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys; sys.path.ap", 5, 22, "test.py")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"



# Generated at 2022-06-18 09:26:40.902975
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")

        def test_get_definitions(self):
            source = open(self.test_file).read()
            row = 3
            column = 5
            filename = self.test_file
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 1)
           

# Generated at 2022-06-18 09:26:46.012029
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys"
            namespaces = [{"name": "__main__", "path": os.path.abspath(sys.argv[0])}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)

    unittest.main()

# Generated at 2022-06-18 09:26:53.894020
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
    from thonny import get_workbench

    wb = get_workbench()
    wb.create_editor_notebook()
    editor = wb.get_editor_notebook().get_current_editor()
    editor.set_text("import sys\nsys.pa")
    completions = get_script_completions(
        editor.get_text(), editor.get_current_line_number(), editor.get_insert_point(), "test.py"
    )
    assert len(completions) == 1
    assert completions[0].name == "path"

# Generated at 2022-06-18 09:27:03.851120
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    if _using_older_jedi(jedi):
        source = """
import sys
sys.path.append("/home/user/mylib")
import mylib

mylib.
"""
        script = jedi.Script(source, row=5, column=8, filename="test.py")
        completions = script.completions()
        assert len(completions) == 1
        assert completions[0].name == "mylib"
        assert completions[0].complete == "mylib"
        assert completions[0].type == "module"
        assert completions[0].description == "Module mylib"
        assert completions[0].parent == "<module>"
        assert completions[0].full_name == "mylib"

# Generated at 2022-06-18 09:27:11.819906
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.path}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == None
    assert completions[0].full_name == "sys"

#

# Generated at 2022-06-18 09:27:20.685149
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position
    from jedi import Script
    import parso
    import sys
    import os

    # Test for jedi 0.17.0
    if sys.version_info[0] == 3 and sys.version_info[1] == 8:
        # Test for jedi 0.17.0
        if sys.version_info[0] == 3 and sys.version_info[1] == 8:
            source = "import os\n"
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            assert completions[0].name == "os"

# Generated at 2022-06-18 09:27:28.801599
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:27:34.238788
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys", [{"sys": sys}])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:27:40.302362
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.interpreter import InterpreterEnvironment
    from jedi.api.project import get_default_project
    from jedi.api.project import Project
    from jedi.api.environment import find_virtualenvs
    from jedi.api.environment import get_system_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_system_environment