

# Generated at 2022-06-18 09:18:01.732921
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path=sys_path)

    def _get_completions_from_jedi(source, row, column, filename, sys_path=None):
        if _using_older_jedi(jedi):
            try:
                script = jedi.Script(source, row, column, filename, sys_path=sys_path)
            except Exception as e:
                logger.info("Could not get completions with given sys_path", exc_info=e)
                script = jedi.Script(source, row, column, filename)

            return script.completions()

# Generated at 2022-06-18 09:18:09.791861
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    namespaces = [{"a": 1, "b": 2}]
    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"
    assert completions[0].parent == "int"
    assert completions[0].full_name == "int"

    completions = get_interpreter_completions("a.", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "bit_length"
    assert completions[0].complete == "bit_length"

# Generated at 2022-06-18 09:18:19.179592
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].type == "module"
        assert get_script_completions("import sys", 0, 7, "")[0].description == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].parent == "import sys"
        assert get_script_com

# Generated at 2022-06-18 09:18:30.837162
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\nos.path.join('a', 'b')"
    namespaces = [{"os": Interpreter(source, [])}]
    completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-18 09:18:41.826160
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 8, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.argv", 0, 12, "")

# Generated at 2022-06-18 09:18:52.660276
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 1, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.", 2, 4, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.argv", 2, 9, "")
    assert completions == [Completion("argv", "argv", "list", "", "", "sys.argv")]

    completions = get_script_completions

# Generated at 2022-06-18 09:18:55.384481
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:19:07.450999
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.executable}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    # Test that completions are the same as with Interpreter
    interpreter = Interpreter(source, namespaces)
    assert completions == interpreter.complete()

    # Test that completions are the same as with Interpreter
    interpreter = Interpreter(source, namespaces)
    assert completions == interpreter.complete()

    # Test that completions are

# Generated at 2022-06-18 09:19:18.807921
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Name
    from jedi.api.classes import Definition
    from jedi.api.classes import Module
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import Param
    from jedi.api.classes import ImportName
    from jedi.api.classes import ImportedModule
    from jedi.api.classes import ImportedName
    from jedi.api.classes import ImportStatement
    from jedi.api.classes import Flow

# Generated at 2022-06-18 09:19:30.482105
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    completions = get_script_completions("import sys\nsys.", 1, 5, "")
    assert len(completions) > 0
    assert "sys.path" in [c.name for c in completions]

    completions = get_script_completions("import sys\nsys.pa", 1, 9, "")
    assert len(completions) > 0
    assert "sys.path" in [c.name for c in completions]

    completions = get_script_completions("import sys\nsys.path", 1, 10, "")
    assert len(completions) > 0
    assert "sys.path" in [c.name for c in completions]

    completions = get_script_completions

# Generated at 2022-06-18 09:19:57.945991
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        return

    get_workbench().set_option("jedi.sys_path", [])
    get_workbench().set_option("jedi.use_interpreter", False)

    source = "import os\nos.path.join("
    completions = get_script_completions(source, 1, len(source), "test.py")
    assert len(completions) == 1
    assert completions[0].name == "os.path.join("

    source = "import os\nos.path.join("

# Generated at 2022-06-18 09:20:09.171132
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = 'import os\nos.path.join("a", "b")'
            namespaces = [{'__name__': '__main__', '__doc__': None, '__package__': None, '__loader__': None, '__spec__': None, '__annotations__': {}, '__builtins__': sys.modules['builtins'], 'os': os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)

# Generated at 2022-06-18 09:20:19.674542
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp"])
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp/non-existing-path"])
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    completions

# Generated at 2022-06-18 09:20:28.607840
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_definitions_for_function(self):
            definitions = get_definitions(self.test_file_content, 2, 4, self.test_file)
            self.assertEqual(len(definitions), 1)

# Generated at 2022-06-18 09:20:38.577626
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nimport os", 1, 7, "")
    assert completions == [Completion("os", "os", "module", "", "", "os")]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]


# Generated at 2022-06-18 09:20:48.654382
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'a')"
    namespaces = [
        {"type": "module", "name": "os", "path": "os"},
        {"type": "module", "name": "sys", "path": "sys"},
    ]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:20:58.759324
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.pa", 0, 15, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"

    completions = get_script_completions("import sys; sys.path.ap", 0, 20, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"

    completions = get_script_completions("import sys; sys.path.append(", 0, 24, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)


# Generated at 2022-06-18 09:21:09.004914
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    from thonny.plugins.jedi_utils import get_definitions
    from thonny.plugins.jedi_utils import _using_older_jedi

    if _using_older_jedi(jedi):
        print("This test is not supported for jedi version < 0.18")
        return

    # Test 1: test for a function definition
    source = "def test_func():\n    pass\n"
    row = 1
    column = 4
    filename = os.path.join(sys.prefix, "test_file.py")
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].type == "function"
    assert definitions[0].name == "test_func"


# Generated at 2022-06-18 09:21:21.486969
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    from jedi.api.classes import Definition

    class TestCase(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\nos.path.join('a', 'b')"
            row = 1
            column = 2
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertIsInstance(definitions, list)
            self.assertIsInstance(definitions[0], Definition)
            self.assertEqual(definitions[0].module_name, "os")
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 0)

# Generated at 2022-06-18 09:21:31.766468
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name

# Generated at 2022-06-18 09:22:00.525180
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os

    def get_definitions_from_file(filename):
        with open(filename) as f:
            source = f.read()
        tree = parso.parse(source)
        definitions = []
        for node in tree.iter_funcdefs():
            if node.name.value == "test_get_definitions":
                definitions.append(node)
        return definitions

    def get_definitions_from_source(source):
        return get_definitions(source, 1, 1, "test.py")

    def get_definitions_from_file_with_jedi(filename):
        with open(filename) as f:
            source = f.read()
        script = jedi.Script(source, 1, 1, filename)
        return script.goto_def

# Generated at 2022-06-18 09:22:09.414369
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions(
        "import sys\n" "sys.pa", [{"sys": sys}], sys_path=["/home/user"]
    )
    assert completions == [
        Completion("path", "path", "attribute", "sys.path", "sys", "sys.path"),
        Completion("path_hooks", "path_hooks", "attribute", "sys.path_hooks", "sys", "sys.path_hooks"),
        Completion("path_importer_cache", "path_importer_cache", "attribute", "sys.path_importer_cache", "sys", "sys.path_importer_cache"),
    ]

# Generated at 2022-06-18 09:22:17.690683
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    import jedi

    source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.isdir"
    completions = get_script_completions(source, 3, 16, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "isdir"
    assert completions[0].complete == "isdir"
    assert completions[0].type == "function"
    assert completions[0].description == "isdir(path) -> bool\n\nReturn True if path is an existing directory."
    assert completions[0].parent == "os.path"

# Generated at 2022-06-18 09:22:23.037444
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("import sys", [locals()])
        completions = interpreter.completions()
    else:
        interpreter = jedi.Interpreter("import sys", [locals()])
        completions = interpreter.complete()

    assert len(completions) > 0
    assert any(c.name == "sys" for c in completions)
    assert any(c.name == "sys.argv" for c in completions)
    assert any(c.name == "sys.path" for c in completions)
    assert any(c.name == "sys.modules" for c in completions)
    assert any(c.name == "sys.stdout" for c in completions)
    assert any

# Generated at 2022-06-18 09:22:32.286221
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    defs = get_definitions("import sys", 0, 0, "")
    assert len(defs) == 1
    assert defs[0].module_name == "sys"

    defs = get_definitions("import sys\nsys.exit", 6, 4, "")
    assert len(defs) == 1
    assert defs[0].module_name == "sys"
    assert defs[0].name == "exit"

    defs = get_definitions("import sys\nsys.exit", 6, 4, "")
    assert len(defs) == 1
    assert defs[0].module_name == "sys"
    assert defs[0].name == "exit"

    defs = get_definitions("import sys\nsys.exit", 6, 4, "")

# Generated at 2022-06-18 09:22:41.709251
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        row = 2
        column = 0
        filename = "test.py"
        completions = get_script_completions(source, row, column, filename)
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "builtins"
        assert completions[0].full_name == "sys"
    else:
        source = "import sys\n"

# Generated at 2022-06-18 09:22:42.777514
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script


# Generated at 2022-06-18 09:22:50.323166
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys", [{"sys": sys}])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:23:00.871847
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Inter

# Generated at 2022-06-18 09:23:05.132962
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:23:31.739530
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    def _get_completions(source, namespaces):
        return get_interpreter_completions(source, namespaces)

    assert _get_completions("", []) == []
    assert _get_completions("", [{}]) == []
    assert _get_completions("", [{"a": 1}]) == [Completion("a", "a", "int", "", "", "a")]
    assert _get_completions("", [{"a": 1}, {"b": 2}]) == [
        Completion("a", "a", "int", "", "", "a"),
        Completion("b", "b", "int", "", "", "b"),
    ]

# Generated at 2022-06-18 09:23:42.307307
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)
            self.test_file_lines = self.test_file_content.splitlines()


# Generated at 2022-06-18 09:23:49.446421
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    source = "sys."
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    source = "sys.stdout.write"
    namespaces = [{"sys": sys}]

# Generated at 2022-06-18 09:23:59.566059
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_names_of_scope

    # Create interpreter
    interpreter = Interpreter("import sys", [], project=Project(path="."))
    # Get completions
    completions = get_interpreter_completions("sys.", [], sys_path=["."])
    # Check completions
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert comple

# Generated at 2022-06-18 09:24:08.085577
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")

# Generated at 2022-06-18 09:24:18.052524
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope_stmt
    from jedi.api.helpers import get_names_of_scope_expr
    from jedi.api.helpers import get_names_of_scope_function
    from jedi.api.helpers import get_names_of_scope_class
    from jedi.api.helpers import get_names_of_scope_module
    from jedi.api.helpers import get_names_of_scope_param

# Generated at 2022-06-18 09:24:28.067710
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    namespaces = [{"a": 1, "b": 2, "c": 3}]
    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"

    completions = get_interpreter_completions("a.", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "bit_length"
    assert completions[0].complete == "bit_length"
    assert completions[0].type == "statement"

# Generated at 2022-06-18 09:24:29.974633
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso

    if _using_older_jedi(jedi):
        return


# Generated at 2022-06-18 09:24:30.505343
# Unit test for function get_definitions

# Generated at 2022-06-18 09:24:33.179001
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:25:00.200823
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys; sys.path.append('.'); import test_utils; test_utils.test_get_interpreter_completions()"

# Generated at 2022-06-18 09:25:09.786862
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert comple

# Generated at 2022-06-18 09:25:11.672966
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import utils
    import jedi
    import parso


# Generated at 2022-06-18 09:25:22.358103
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []
        assert get_definitions("import sys", 0, 0, "") == []

# Generated at 2022-06-18 09:25:30.678711
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_line_code
    from jedi.api.helpers import get_cursor_pos_on_line
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_names_containing_name
    from jedi.api.helpers import get_module_names_starting_with_name
    from jedi.api.helpers import get_module_

# Generated at 2022-06-18 09:25:40.416080
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import jedi
    import parso
    import sys
    import os
    import unittest
    from unittest.mock import patch

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.source = "import sys\n"
            self.row = 1
            self.column = 7
            self.filename = "test.py"
            self.sys_path = [os.path.dirname(sys.executable)]


# Generated at 2022-06-18 09:25:49.353218
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\nprint(sys.path)"
    row = 2
    column = 7
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].module_name == "sys"
    assert definitions[0].line == 1
    assert definitions[0].column == 0
    assert definitions[0].type == "module"
    assert definitions[0].full_name == "sys"
    assert definitions[0].description == "Built-in module sys"
    assert definitions[0].module_path == definitions[0].module_path.replace("\\", "/")

# Generated at 2022-06-18 09:25:57.295745
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    import jedi
    import parso
    import os
    import sys

    sys.path.append(os.path.dirname(__file__))
    source = "import os\nimport sys\nimport test_jedi_utils\nos.path.join(sys.path[0], test_jedi_utils.__file__)"
    namespaces = [{"os": os}, {"sys": sys}]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "__file__"
    assert completions[0].complete == "__file__"

# Generated at 2022-06-18 09:26:05.029493
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    from thonny.languages.python import PythonProxy
    from thonny.languages.python.inspector import PythonInspector
    from thonny import get_runner
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        return

    runner = get_runner()
    inspector = PythonInspector(runner)
    proxy = PythonProxy(runner, inspector)


# Generated at 2022-06-18 09:26:11.781846
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"

    # Test that we get the same result with jedi's Interpreter
    interpreter = Interpreter(source, namespaces)
    assert len(interpreter.completions()) > 0
    assert interpreter.completions()[0].name == "sys"

# Generated at 2022-06-18 09:26:56.352557
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.parser_utils import get_parent_scope
    from jedi.parser_utils import get_statement_of_position
    from jedi.parser_utils import get_scope_at_pos
    from jedi.parser_utils import get_module_node
    from jedi.parser_utils import get_module_context
    from jedi.parser_utils import get_module_path
    from jedi.parser_utils import get_module_contexts
    from jedi.parser_utils import get_module_contexts_containing_position
    from jedi.parser_utils import get_module_contexts_containing_or_after_position
    from jedi.parser_utils import get_module_contexts_containing

# Generated at 2022-06-18 09:27:02.168068
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.path", [{}])[0].name == "path"
    else:
        assert get_interpreter_completions("import sys; sys.path", [{}])[0].name == "path="



# Generated at 2022-06-18 09:27:10.480976
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            script = jedi.Script("import os; os.path.join('a', 'b')", 1, 1, "")
            definitions = script.goto_definitions()
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].type, "function")
            self.assertEqual(definitions[0].module_name, "posixpath")
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 0)
            self.assertEqual(definitions[0].in_builtin_module(), True)


# Generated at 2022-06-18 09:27:19.278586
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)


# Generated at 2022-06-18 09:27:23.282071
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\n"
    namespaces = [{"sys": jedi.Interpreter("import sys", []).namespace}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]



# Generated at 2022-06-18 09:27:31.286429
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            if _using_older_jedi(jedi):
                source = "import os\nos.path.join"
                namespaces = [{"os": os}]
                completions = get_interpreter_completions(source, namespaces)
                self.assertEqual(len(completions), 1)
                self.assertEqual(completions[0].name, "join")
                self.assertEqual(completions[0].complete, "join")
                self.assertEqual(completions[0].type, "function")

# Generated at 2022-06-18 09:27:37.165223
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].name == "join"
        assert definitions[0].module_name == "os.path"
        assert definitions[0].line == 1
        assert definitions[0].column == 16
        assert definitions[0].description == "join(path, *paths)"
    else:
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi