

# Generated at 2022-06-18 09:18:20.495151
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter

    source = "import os\nos.path.join("
    namespaces = [{"os": Interpreter("import os", [])}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "os"
    assert completions[0].complete == "os."
    assert completions[0].type == "module"
    assert completions[0].description == "os"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os"

# Generated at 2022-06-18 09:18:32.453108
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    if _using_older_jedi(jedi):
        script = jedi.Script("import os\nos.", 1, 3, "")
        completions = script.completions()
    else:
        script = jedi.Script(code="import os\nos.", path="")
        completions = script.complete(line=1, column=3)

    assert len(completions) > 0
    assert completions[0].name == "os"
    assert completions[0].complete == "os."
    assert completions[0].type == "module"
    assert completions[0].description.startswith("Module")
    assert completions[0].parent is None
    assert completions[0].full_name == "os"


# Generated at 2022-06-18 09:18:42.855869
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from thonny.misc import get_interpreter_completions

    source = "import sys\nsys.path.append('/home/user/')\n"
    namespaces = [{"name": "__main__", "path": "<input>"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:18:53.728787
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.environment import get_system_environment
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter
    from jedi.api.environment import get_system_environment
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter

# Generated at 2022-06-18 09:18:58.409518
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_definitions("import sys", 0, 0, "")[0].module_name == "sys"
    else:
        assert get_definitions("import sys", 0, 0, "")[0].module_path == "sys"

# Generated at 2022-06-18 09:19:02.478886
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "test.py")
    assert completions == [
        Completion("sys", "sys", "module", "The Python standard library.", None, "sys")
    ]



# Generated at 2022-06-18 09:19:14.503138
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 10, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.std", 0, 13, "")

# Generated at 2022-06-18 09:19:26.842799
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    import jedi
    import parso
    import ast
    import types

    # Test for jedi 0.16.0
    if _using_older_jedi(jedi):
        # Create a dummy interpreter
        source = "import os\n"
        namespaces = [{"os": types.ModuleType("os")}]
        interpreter = Interpreter(source, namespaces)
        # Create a dummy completion
        tree = parso.parse("os.path.join")
        module = tree.get_root_node()
        completion = Completion(interpreter, module, "join", "join", "join", "join")
        completions = [completion]
        # Test the function
        assert _tweak_complet

# Generated at 2022-06-18 09:19:36.545117
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent is None
        assert completions[0].full_name == "sys"
    else:
        source = "import sys\n"

# Generated at 2022-06-18 09:19:47.944120
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    # Get the path of the test file
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "test_get_definitions.py")

    # Get the definitions of the test file
    definitions = get_definitions(open(path).read(), 0, 0, path)

    # Check that the definitions are correct
    class TestGetDefinitions(unittest.TestCase):
        def test_definitions(self):
            self.assertEqual(definitions[0].description, "class TestGetDefinitions")
            self.assertEqual(definitions[1].description, "class TestGetDefinitions")

# Generated at 2022-06-18 09:20:09.238850
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        namespaces = [{"name": "sys", "path": sys.path}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
    else:
        source = "import sys\nsys.path"
        namespaces = [{"name": "sys", "path": sys.path}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"

# Generated at 2022-06-18 09:20:19.765997
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "The Python standard library.", "", "sys")]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [Completion("sys", "sys.", "module", "The Python standard library.", "", "sys")]

    completions = get_script_completions("import sys\nsys.path", 1, 10, "")
    assert completions == [Completion("path", "path", "module", "Module wrapper for sys.path", "sys", "sys.path")]



# Generated at 2022-06-18 09:20:24.662380
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi

    if _using_older_jedi(jedi):
        interpreter = Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
    else:
        interpreter = Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.complete()

    assert len(completions) > 0

# Generated at 2022-06-18 09:20:32.251271
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys", [{}])
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_interpreter_completions("import sys\nsys.", [{}])
    assert completions == [Completion("path", "path", "attribute", "", "sys", "sys.path")]

    completions = get_interpreter_completions("import sys\nsys.path.", [{}])
    assert completions == [Completion("append", "append", "function", "", "sys.path", "sys.path.append")]


# Generated at 2022-06-18 09:20:40.232845
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"type": "module", "name": "sys", "module_path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert get_names_of_scope(completions[0].parent) == ["sys"]



# Generated at 2022-06-18 09:20:50.116054
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_script_completions.py")
            self.test_file_contents = open(self.test_file).read()

        def test_get_script_completions(self):
            completions = get_script_completions(
                self.test_file_contents, row=3, column=5, filename=self.test_file
            )
            self.assertEqual(len(completions), 1)
            self

# Generated at 2022-06-18 09:21:00.277103
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": get_default_environment().get_sys_path()}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:21:10.782416
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("import os", 1, 1, "")
        definitions = script.goto_definitions()
    else:
        script = jedi.Script(code="import os", path="")
        definitions = script.infer(line=1, column=1)

    assert len(definitions) == 1
    assert definitions[0].module_name == "os"
    assert definitions[0].line == 1
    assert definitions[0].column == 1
    assert definitions[0].type == "module"
    assert definitions[0].description == "os"
    assert definitions[0].full_name == "os"
    assert definitions[0].name == "os"

# Generated at 2022-06-18 09:21:23.602069
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = """
    import sys
    sys.path.append("/home/user/my_module")
    import my_module
    my_module.
    """

    completions = get_script_completions(source, 4, 17, "test.py", sys_path=["/home/user/my_module"])
    assert len(completions) == 1
    assert completions[0].name == "my_module"
    assert completions[0].complete == "my_module."
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:21:33.246030
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        ThonnyCompletion(name="sys", complete="sys", type="module", description="", parent="", full_name="sys")
    ]

    completions = get_script_completions("sys.", 0, 4, "")
    assert completions == [
        ThonnyCompletion(name="sys", complete="sys", type="module", description="", parent="", full_name="sys")
    ]

    completions = get_script_completions("sys.path", 0, 8, "")

# Generated at 2022-06-18 09:21:59.715220
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:22:01.301876
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import jedi_utils


# Generated at 2022-06-18 09:22:04.123379
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope


# Generated at 2022-06-18 09:22:08.689886
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os\nos.", 1, 4, "test.py")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:22:12.525855
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:22:18.207764
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestJedi(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os\nos.path.join("
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)
            self.assertTrue(completions[0].name == "os")

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-18 09:22:22.441753
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

# Generated at 2022-06-18 09:22:31.525121
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    # Test for jedi 0.13
    def _completions_13(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    # Test for jedi 0.14
    def _completions_14(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    # Test for jedi 0.15
    def _completions_15(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    # Test for jedi 0.16

# Generated at 2022-06-18 09:22:40.907559
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys

    # Check if jedi is installed
    try:
        import jedi
    except ImportError:
        print("Jedi is not installed. Please install it to run the tests.")
        return

    # Check if jedi is the correct version
    if jedi.__version__[:4] not in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        print("Jedi version is not 0.13, 0.14, 0.15, 0.16 or 0.17. Please install the correct version to run the tests.")
        return

    # Get the path to the test file
    path = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-18 09:22:51.795306
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_names_containing_name
    from jedi.api.helpers import get_module_names_starting_with_name
    from jedi.api.helpers import get_module_names_ending_with_name
    from jedi.api.helpers import get_module_names_matching_regex
    from jedi.api.helpers import get_module_names_from

# Generated at 2022-06-18 09:23:24.990235
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("import os", 1, 1, "")
        definitions = script.goto_definitions()
    else:
        script = jedi.Script(code="import os", path="")
        definitions = script.infer(line=1, column=1)

    assert len(definitions) == 1
    assert definitions[0].type == "module"
    assert definitions[0].module_name == "os"

# Generated at 2022-06-18 09:23:32.655248
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os

    get_workbench().set_option("run.use_subprocess", False)
    get_workbench().set_option("view.interactive_shell_on_startup", False)
    get_workbench().set_option("view.interactive_shell_on_error", False)
    get_workbench().set_option("view.interactive_shell_on_debug", False)

    get_workbench().set_option("view.show_debugger_ui", False)
    get_workbench().set_option("view.show_shell", False)
    get_workbench().set_option("view.show_editor", False)

# Generated at 2022-06-18 09:23:43.157415
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_docstring
    from jedi.api.helpers import get_module_members
    from jedi.api.helpers import get_module_member_names
    from jedi.api.helpers import get_module_member_names_with_root

# Generated at 2022-06-18 09:23:49.940412
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import Source
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import ScriptCompletion
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import InterpreterScript
    from jedi.api.classes import InterpreterProject
    from jedi.api.classes import InterpreterSource
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import InterpreterScriptCompletion
    from jedi.api.classes import InterpreterNames

# Generated at 2022-06-18 09:23:54.049094
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:24:03.735288
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Test with jedi 0.13.2
    if jedi.__version__[:4] == "0.13":
        sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
        from thonny import get_workbench
        from thonny.plugins.micropython import MicroPythonProxy

        wb = get_workbench()
        wb.create_editor_from_locator("test_get_interpreter_completions.py")
        wb.get_editor_notebook().select_page_with_focus()

# Generated at 2022-06-18 09:24:09.957085
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import get_sys_path
    from jedi.api.environment import get_default_environment
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter
    from jedi.api.settings import cache_directory
    from jedi.api.settings import settings
    from jedi.api.settings import set_default_project
    from jedi.api.settings import set_default_environment
    from jedi.api.settings import set_default_interpreter
    from jedi.api.settings import set_preferred_version
    from jedi.api.settings import set_cache_directory
    from jedi.api.settings import set_time_

# Generated at 2022-06-18 09:24:20.217995
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join("
        completions = get_script_completions(source, 1, len(source), "")
        assert len(completions) == 1
        assert completions[0].name == "os.path.join("
        assert completions[0].complete == "os.path.join("
    else:
        source = "import os\nos.path.join("
        completions = get_script_completions(source, 1, len(source), "")
        assert len(completions) == 1
        assert completions[0].name == "os.path.join("
        assert completions[0].complete == "os.path.join("



# Generated at 2022-06-18 09:24:26.166917
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        print("Test skipped for older jedi")
        return

    source = "import math\nmath.sqrt"
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sqrt" in [c.name for c in completions]

# Generated at 2022-06-18 09:24:34.675208
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_line_code
    from jedi.parser_utils import get_statement_of_position
    from jedi.evaluate import Evaluator
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import Context
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.instance import Instance
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.klass import ClassContext
    from jedi.evaluate.context.function import FunctionContext
    from jedi.evaluate.context.instance import TreeInstance
    from jedi.evaluate.context.iterable import AbstractSetContext
    from jedi.evaluate.context.iterable import AbstractSequenceContext

# Generated at 2022-06-18 09:25:28.511827
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 0, "")[0].complete == "sys"

# Generated at 2022-06-18 09:25:37.330476
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 2
    column = 1
    filename = "test.py"
    sys_path = ["/home/user/"]

    completions = get_script_completions(source, row, column, filename, sys_path)

    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert isinstance(completions[0].name, str)
    assert isinstance(completions[0].complete, str)
    assert isinstance(completions[0].type, str)
    assert isinstance(completions[0].description, str)
    assert isinstance(completions[0].parent, str)
    assert isinstance

# Generated at 2022-06-18 09:25:42.631454
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value

    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_path == get_cached_value(defs[0]._module_path)

# Generated at 2022-06-18 09:25:46.435147
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:25:53.684170
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "os" in [c.name for c in completions]
    else:
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "os" in [c.name for c in completions]

# Generated at 2022-06-18 09:25:58.933134
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"

    completions = Script(source, row, column, filename).completions()
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"

# Generated at 2022-06-18 09:26:09.095755
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "argv"

    completions = get_script_completions("import sys\nsys.argv.", 1, 11, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:26:16.799904
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_default_environment
    import os
    import sys

    # Create a dummy project
    dummy_project_path = os.path.join(os.path.dirname(__file__), "dummy_project")
    dummy_project = Project(dummy_project_path)
    dummy_project.add_environment(get_system_environment(), get_default_environment())

    # Create a dummy interpreter
    dummy_interpreter = Interpreter("", [], dummy_project)

    # Create a dummy completion

# Generated at 2022-06-18 09:26:21.838438
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__

    if __version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert get_script_completions("import sys; sys.path.ap", 1, 20, "")[0].name == "append"
    else:
        assert get_script_completions("import sys; sys.path.ap", 1, 20, "")[0].name == "append="

# Generated at 2022-06-18 09:26:24.054986
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    import jedi
    import parso
