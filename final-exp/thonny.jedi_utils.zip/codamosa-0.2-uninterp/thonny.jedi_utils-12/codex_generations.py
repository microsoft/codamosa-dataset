

# Generated at 2022-06-18 09:17:44.158225
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.settings import get_default_script_settings
    from jedi.parser.python import load_grammar
    from jedi.parser.python.tree import Module
    from jedi.parser.python.tokenize import Tokenizer
    from jedi.parser.python.token import Token
    from jedi.parser.python.token import Whitespace
    from jedi.parser.python.token import Newline
    from jedi.parser.python.token import Comment
    from jedi.parser.python.token import Name
    from jedi.parser.python.token import Keyword

# Generated at 2022-06-18 09:17:54.056224
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            script_path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            source = open(script_path).read()
            definitions = get_definitions(source, 3, 5, script_path)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_name, "test_get_definitions")
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 4)

# Generated at 2022-06-18 09:17:58.383814
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys"
    else:
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys="

# Generated at 2022-06-18 09:18:09.467217
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:18:18.560079
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.evaluate.compiled import CompiledObject

        class CompiledObject:
            def __init__(self, name):
                self.name = name

            def get_root_context(self):
                return self

            def get_subscope_by_name(self, name):
                return self

            def get_filters(self, *args, **kwargs):
                return []

            def get_safe_value(self, *args, **kwargs):
                return self

            def get_signatures(self):
                return []

            def get_param_names(self):
                return []

            def get_params(self):
                return []

            def get_return_types(self):
                return []


# Generated at 2022-06-18 09:18:22.427749
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.path", [], [])
    else:
        assert get_interpreter_completions("import sys; sys.path", [], [])

# Generated at 2022-06-18 09:18:34.816564
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    defs = get_definitions("import math\nmath.sin(", 0, 14, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "math"
    assert defs[0].line == 1
    assert defs[0].column == 5
    assert defs[0].in_builtin_module()

    defs = get_definitions("import math\nmath.sin(", 0, 15, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "math"
    assert defs[0].line == 1
    assert defs[0].column == 5

# Generated at 2022-06-18 09:18:43.940101
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'a')"

# Generated at 2022-06-18 09:18:53.825190
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 1
    column = 0
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:19:04.229479
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'foo')"
    namespaces = [
        {
            "type": "module",
            "module_path": "os",
            "namespace": Interpreter(source, namespaces=[]).namespace(),
        },
        {
            "type": "module",
            "module_path": "sys",
            "namespace": Interpreter(source, namespaces=[]).namespace(),
        },
    ]

    completions = get_interpreter_completions(source, namespaces)


# Generated at 2022-06-18 09:19:34.917703
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys

    # Get the path of the current file
    path = os.path.dirname(os.path.realpath(__file__))
    # Get the path of the file to be tested

# Generated at 2022-06-18 09:19:46.486354
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("import os", [{}]) == [
        ThonnyCompletion(
            name="os",
            complete="os",
            type="module",
            description="Built-in module os",
            parent=None,
            full_name="os",
        )
    ]

    assert get_interpreter_completions("import os; os.path", [{}]) == [
        ThonnyCompletion(
            name="os.path",
            complete="os.path",
            type="module",
            description="Built-in module os.path",
            parent=None,
            full_name="os.path",
        )
    ]


# Generated at 2022-06-18 09:19:47.144334
# Unit test for function get_definitions

# Generated at 2022-06-18 09:19:58.958592
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope


# Generated at 2022-06-18 09:20:09.718654
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.dirname(__file__))
    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:20:10.529918
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script


# Generated at 2022-06-18 09:20:16.659904
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # TODO: test older jedi
        return

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]



# Generated at 2022-06-18 09:20:26.227222
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

    source = "import sys\nsys."
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert comple

# Generated at 2022-06-18 09:20:33.209972
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName

# Generated at 2022-06-18 09:20:38.702283
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import os\nos.path.join("
    namespaces = [{"os": os}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "join(" in [c.complete for c in completions]



# Generated at 2022-06-18 09:21:10.213739
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
        Completion("sys", "sys", "module", "", None, "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
        Completion("sys", "sys", "module", "", None, "sys"),
    ]

    completions = get_script_completions("import sys\nsys.exit", 1, 10, "")

# Generated at 2022-06-18 09:21:23.128729
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.environment import get_default_environment
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_cached_code_lines

    source = "import sys\n"
    namespaces = [
        {"type": "module", "name": "sys", "path": get_default_environment().get_sys_path()[0]}
    ]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"

# Generated at 2022-06-18 09:21:24.605224
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]



# Generated at 2022-06-18 09:21:34.219231
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert any(c["name"] == "sys" for c in completions)

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert any(c["name"] == "path" for c in completions)

    completions = get_script_completions("import sys\nsys.path.", 1, 11, "")
    assert len(completions) > 0
    assert any(c["name"] == "append" for c in completions)


# Generated at 2022-06-18 09:21:45.119066
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    source = """
import sys
sys.path.append("/home/user/mylib")

import mylib
mylib.
"""
    row = 5
    column = 10

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, "test.py", sys_path=["/home/user/mylib"])
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path="test.py", project=_get_new_jedi_project(["/home/user/mylib"]))
        completions = script.complete(line=row, column=column)

    assert len(completions) > 0



# Generated at 2022-06-18 09:21:56.076961
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_module_names_containing_name
    from jedi.api.helpers import get_module_paths_containing_name
    from jedi.api.helpers import get_module_names_containing_str
    from jedi.api.helpers import get_module_paths_containing_str

# Generated at 2022-06-18 09:22:04.274513
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    def get_completions(source, row, column, filename, sys_path=None):
        completions = get_script_completions(source, row, column, filename, sys_path)
        return [c.name for c in completions]

    assert get_completions("import sys; sys.", 0, 12, "") == ["path", "platform"]
    assert get_completions("import sys; sys.path", 0, 17, "") == ["append", "insert"]
    assert get_completions("import sys; sys.path.append", 0, 23, "") == ["(", "]"]

# Generated at 2022-06-18 09:22:13.191093
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestJediUtils(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os\nos.path.join("
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)
            self.assertTrue(completions[0].name == "os")
            self.assertTrue(completions[0].type == "module")

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-18 09:22:16.192759
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import os; os.", [])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"



# Generated at 2022-06-18 09:22:17.191054
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso


# Generated at 2022-06-18 09:22:41.144196
# Unit test for function get_definitions

# Generated at 2022-06-18 09:22:45.840028
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"



# Generated at 2022-06-18 09:22:56.561902
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import os", [{}])[0].name == "os"
    else:
        assert get_interpreter_completions("import os", [{}])[0].name == "os"
        assert get_interpreter_completions("import os", [{}])[0].complete == "os"
        assert get_interpreter_completions("import os", [{}])[0].type == "module"
        assert get_interpreter_completions("import os", [{}])[0].description == "os module"
        assert get_interpreter_completions("import os", [{}])[0].parent == "builtins"
        assert get_interpre

# Generated at 2022-06-18 09:23:01.478346
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:23:11.330767
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_params_of_funcdef
    from jedi.api.helpers import get_params_of_scope
    from jedi.api.helpers import get_parent_scope
    from jedi.api.helpers import get_qualified_names_of_scope
    from jedi.api.helpers import get_qualified_names_of_name
    from jedi.api.helpers import get_qualified_names_of_module
    from jedi.api.helpers import get_type_of_name
    from jedi.api.helpers import get_type_of_value
    from jedi.api.helpers import get_value_of_name

# Generated at 2022-06-18 09:23:15.537785
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_definitions("import sys", 0, 0, "")[0].module_name == "sys"
    else:
        assert get_definitions("import sys", 0, 0, "")[0].module_path == "sys"

# Generated at 2022-06-18 09:23:25.645250
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\n", 1, 0, "")
    assert completions == [
        Completion("sys", "sys", "module", "", "", "sys"),
        Completion("sys.path", "sys.path", "list", "", "", "sys.path"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 5, "")
    assert completions == [
        Completion("path", "path", "list", "", "", "sys.path"),
        Completion("argv", "argv", "list", "", "", "sys.argv"),
    ]


# Generated at 2022-06-18 09:23:33.051846
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def setUp(self):
            self.source = "import sys\n"
            self.namespaces = [{"name": "__main__", "path": "<string>"}]
            self.sys_path = [os.path.dirname(sys.executable)]

        def test_get_interpreter_completions(self):
            completions = get_interpreter_completions(self.source, self.namespaces, self.sys_path)
            self.assertTrue(len(completions) > 0)

    unittest.main(module="test_get_interpreter_completions", exit=False)


# Generated at 2022-06-18 09:23:43.573111
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    source = "import os\nos.path.join("
    row = 1
    column = len(source)
    filename = "test.py"
    sys_path = ["/home/user/my_project"]

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))
        completions = script.complete(line=row, column=column)

    assert completions[0].name == "join"
    assert completions[0].complete == "join("
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:23:46.584954
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"



# Generated at 2022-06-18 09:24:20.911420
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.refactoring import inline
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Source
    from jedi.api.classes import CallDef
    from jedi.api.classes import Docstring
    from jedi.api.classes import Param
    from jedi.api.classes import UserKeyword
    from jedi.api.classes import User

# Generated at 2022-06-18 09:24:24.491876
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_statement_of_position
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    import parso
    import jedi


# Generated at 2022-06-18 09:24:26.969054
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope


# Generated at 2022-06-18 09:24:36.286076
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        row = 2
        column = 9
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].type == "module"
        assert definitions[0].module_name == "sys"
        assert definitions[0].line == 1
        assert definitions[0].column == 0
    else:
        source = "import sys\nsys.path"
        row = 2
        column = 9
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].type == "module"


# Generated at 2022-06-18 09:24:44.694044
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    script = Script(source, row, column, filename)
    completions = script.completions()
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:24:45.111886
# Unit test for function get_script_completions

# Generated at 2022-06-18 09:24:46.437653
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition


# Generated at 2022-06-18 09:24:57.118810
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import math\nmath.sq"
        completions = get_interpreter_completions(source, [])
        assert len(completions) == 1
        assert completions[0].name == "sqrt"
        assert completions[0].complete == "sqrt"
        assert completions[0].type == "function"
        assert completions[0].description == "sqrt(x)\n\nReturn the square root of x."
        assert completions[0].parent == "math"
        assert completions[0].full_name == "math.sqrt"
    else:
        source = "import math\nmath.sq"
        completions = get_interpreter_completions(source, [])
        assert len

# Generated at 2022-06-18 09:25:06.213138
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    defs = get_definitions("import os\nos.path.join", 1, 12, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os.path"
    assert defs[0].line == 1
    assert defs[0].column == 0
    assert defs[0].type == "function"
    assert defs[0].description == "join(path, *paths, sep=os.pathsep, /)"
    assert defs[0].full_name == "os.path.join"

    defs = get_definitions("import os\nos.path.join", 1, 12, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os.path"

# Generated at 2022-06-18 09:25:17.689131
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].name == "join"
        assert definitions[0].module_name == "os.path"
    else:
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)
        assert len(definitions) == 1

# Generated at 2022-06-18 09:25:50.067396
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/tmp')\n"
        namespaces = [{"name": "__main__", "path": "/tmp/test.py"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "sys"
    else:
        source = "import sys\nsys.path.append('/tmp')\n"
        namespaces = [{"name": "__main__", "path": "/tmp/test.py"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0

# Generated at 2022-06-18 09:25:54.267491
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.", 0, 0, "")
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"



# Generated at 2022-06-18 09:26:00.416497
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_names

# Generated at 2022-06-18 09:26:10.560703
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.parser_utils import get_statement_of_position
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.subprocess import CompiledSubprocessModule
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.subprocess import CompiledSubprocessModule
    from jedi.evaluate.compiled.access import CompiledObject

# Generated at 2022-06-18 09:26:17.808958
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import CompletionParts

    completions = get_script_completions("import os; os.path.ex", 1, 23, "")
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert isinstance(completions[0], Completion)
    assert isinstance(completions[0].name, str)
    assert isinstance(completions[0].complete, str)
    assert isinstance(completions[0].type, str)
    assert isinstance(completions[0].description, str)
    assert isinstance(completions[0].parent, CompletionParts)
    assert isinstance(completions[0].full_name, str)




# Generated at 2022-06-18 09:26:25.553824
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "path"
    else:
        source = "import sys\nsys."
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 1
        assert any(c.name == "path" for c in completions)

# Generated at 2022-06-18 09:26:34.518342
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from thonny.plugins.jedi_utils import get_definitions
    from thonny.plugins.jedi_utils import parse_source

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(
                os.path.dirname(os.path.realpath(__file__)), "test_get_definitions.py"
            )
            self.test_file = open(self.test_file_path, "r")
            self.test_file_content = self.test_file.read()
            self.test_file.close()

# Generated at 2022-06-18 09:26:40.367979
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            with open(path, "r") as f:
                source = f.read()

            definitions = get_definitions(source, 2, 5, path)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_path, path)
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 4)

            definitions = get_definitions(source, 3, 5, path)

# Generated at 2022-06-18 09:26:47.309311
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    sys_path = ["/usr/lib/python3.7"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."

# Generated at 2022-06-18 09:26:55.185468
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(__file__)
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_definitions(self):
            if _using_older_jedi(jedi):
                script = jedi.Script(self.test_file_content, 1, 1, self.test_file)
                definitions = script.goto_definitions()