

# Generated at 2022-06-18 09:18:15.840585
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    def assert_completions(source, row, column, expected_completions):
        completions = get_script_completions(source, row, column, "test.py")
        assert [c.name for c in completions] == expected_completions

    assert_completions("", 0, 0, ["import", "def", "class", "if", "for", "while"])
    assert_completions("", 0, 1, ["import", "def", "class", "if", "for", "while"])
    assert_completions("", 1, 0, ["import", "def", "class", "if", "for", "while"])

# Generated at 2022-06-18 09:18:27.531711
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys; sys.path.append('/home/user/thonny/lib')\n"
    source += "import thonny; thonny.get_workbench().get_editor_notebook().get_current_editor()"
    row = 2
    column = len(source) - 1
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "get_current_editor"
    assert completions[0].complete == "get_current_editor()"
    assert completions[0].type

# Generated at 2022-06-18 09:18:28.823785
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:18:40.375031
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.evaluate.compiled.access import get_string_value
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.context import Context
    from jedi.evaluate.value import ValueSet
    from jedi.evaluate.value.instance import CompiledInstance
    from jedi.evaluate.value.klass import ClassValue
    from jedi.evaluate.value.module import ModuleValue
    from jedi.evaluate.value.namespace import NamespaceValue
    from jedi.evaluate.value.instance import BoundMethod

# Generated at 2022-06-18 09:18:51.503367
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path"
        row = 1
        column = 10
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
    else:
        source = "import os\nos.path"
        row = 1
        column = 10
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)

    assert len(definitions) == 1
    assert definitions[0].name == "path"
    assert definitions[0].module_name == "os"
    assert definitions[0].full_name == "os.path"

# Generated at 2022-06-18 09:18:59.963564
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion(name="sys", complete="sys", type="module", description="", parent="", full_name="sys")
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [
        Completion(name="argv", complete="argv", type="list", description="", parent="sys", full_name="sys.argv"),
        Completion(name="path", complete="path", type="list", description="", parent="sys", full_name="sys.path"),
    ]


# Generated at 2022-06-18 09:19:03.671454
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:19:16.168448
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\nimport sys\nos.path.join"
            row = 2
            column = 16
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].type, "function")
            self.assertEqual(definitions[0].full_name, "os.path.join")
            self.assertEqual(definitions[0].description, "os.path.join(path, *paths)")
            self.assertEqual(definitions[0].module_name, "os.path")

# Generated at 2022-06-18 09:19:28.018162
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Test for jedi version 0.17.0
            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_definitions(
                        "import os\nos.path.join('a', 'b')",
                        1,
                        len("os.path.join"),
                        os.path.join(os.path.dirname(__file__), "test_get_definitions.py"),
                    )[0].module_path,
                    os.path.join(sys.prefix, "lib", "python3.7", "posixpath.py"),
                )
            else:
                self.assertE

# Generated at 2022-06-18 09:19:37.811220
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_contents = open(self.test_file).read()

        def test_get_definitions_for_function(self):
            definitions = get_definitions(
                self.test_file_contents,
                row=4,
                column=5,
                filename=self.test_file,
            )

# Generated at 2022-06-18 09:19:57.946414
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.__version__ = "0.17.0"
    assert get_script_completions("import sys; sys.", 1, 10, "")[0].name == "sys"
    assert get_script_completions("import sys; sys.", 1, 10, "")[0].complete == "sys"
    assert get_script_completions("import sys; sys.", 1, 10, "")[0].type == "module"
    assert get_script_completions("import sys; sys.", 1, 10, "")[0].description == "sys"
    assert get_script_completions("import sys; sys.", 1, 10, "")[0].parent == "sys"

# Generated at 2022-06-18 09:20:09.163376
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(
                os.path.dirname(os.path.realpath(__file__)), "test_get_definitions.py"
            )
            self.test_file_path_2 = os.path.join(
                os.path.dirname(os.path.realpath(__file__)), "test_get_definitions_2.py"
            )

# Generated at 2022-06-18 09:20:19.630667
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value

    source = "import os\nimport sys\nos.path.join(sys.path[0], 'test')"
    namespaces = [
        {"type": "module", "name": "os", "description": "os", "docstring": "os"},
        {"type": "module", "name": "sys", "description": "sys", "docstring": "sys"},
    ]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    assert completions[0].name == "join"
    assert comple

# Generated at 2022-06-18 09:20:26.600892
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os\nos.path.join"
            namespaces = [{"os": jedi.Interpreter("import os", []).namespace}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "join")

    unittest.main(module=__name__)

# Generated at 2022-06-18 09:20:36.269565
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position

    source = """
import sys
sys.path.append("/home/user/my_lib")
import my_lib
my_lib.
"""
    row = 5
    column = 11

    script = Script(source, row, column, "test.py")
    completions = script.completions()
    assert len(completions) == 1
    assert completions[0].name == "my_lib"
    assert completions[0].complete == "my_lib."
    assert completions[0].type == "module"
    assert completions[0].description == "my_lib"
    assert completions[0].parent == "sys.modules"
    assert comple

# Generated at 2022-06-18 09:20:43.829005
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)

    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:20:52.295457
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            import jedi

            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_interpreter_completions("import os", [], sys_path=["/"])[0].name,
                    "os",
                )
            else:
                self.assertEqual(
                    get_interpreter_completions("import os", [], sys_path=["/"])[0].name,
                    "os",
                )

    Test().test_get_interpreter_completions()

# Generated at 2022-06-18 09:20:57.211172
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"



# Generated at 2022-06-18 09:21:07.329462
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetInterpreterCompletions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_interpreter_completions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_content_with_sys_path = self.test_file_content + "\nimport sys\nsys.path.append('/tmp')"

# Generated at 2022-06-18 09:21:19.886918
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.classes import Name
    from jedi.api.classes import Definition
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Module
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import Importer
    from jedi.api.classes import Namespace
    from jedi.api.classes import AbstractNameDefinition
    from jedi.api.classes import AbstractName

# Generated at 2022-06-18 09:21:33.498157
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        # jedi 0.17
        assert get_interpreter_completions("import sys", [], sys.path)
    else:
        # jedi 0.18
        assert get_interpreter_completions("import sys", [], sys.path)

# Generated at 2022-06-18 09:21:44.678381
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
   

# Generated at 2022-06-18 09:21:53.199815
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = """
import os

os.path.abspath("")
"""
    namespaces = [{"os": os}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert any(c.name == "abspath" for c in completions)
    assert any(c.name == "path" for c in completions)
    assert any(c.name == "os" for c in completions)



# Generated at 2022-06-18 09:21:54.080990
# Unit test for function get_definitions

# Generated at 2022-06-18 09:22:02.836227
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.path", 1, 10, "")
    assert completions == [Completion("path", "path", "property", "", "", "sys.path")]


# Generated at 2022-06-18 09:22:12.980152
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys; sys.stdout.write('hello')", 1, 1, "")
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].module_name == "sys"
        assert definitions[0].line == 1
        assert definitions[0].column == 7
        assert definitions[0].name == "stdout"
        assert definitions[0].description == "stdout"
        assert definitions[0].type == "instance"
        assert definitions[0].full_name == "sys.stdout"
        assert definitions[0].module_path == "sys"

# Generated at 2022-06-18 09:22:20.504757
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.evaluate.compiled.context import CompiledContextName
    from jedi.evaluate.context import ContextName
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.instance import InstanceContext
    from jedi.evaluate.context.class_context import ClassContext
    from jedi.evaluate.context.function import FunctionContext
    from jedi.evaluate.context.builtin import BuiltinContext
    from jedi.evaluate.context.instance import BoundMethod, BoundFunction
    from jedi.evaluate.context.iterable import SequenceLiteralContext

# Generated at 2022-06-18 09:22:24.363980
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.", 0, 0, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:22:33.866556
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso

    if _using_older_jedi(jedi):
        # Test for jedi < 0.18
        source = "import sys\nsys.path.append('/home/user/')\nsys.path.append('/home/user/')\n"
        row = 3
        column = 10
        filename = "test.py"
        sys_path = ["/home/user/"]
        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        completions = script.completions()
        assert len(completions) == 1
        assert completions[0].name == "append"
        assert completions[0].complete == "append"
        assert completions[0].type == "function"
        assert completions[0].description

# Generated at 2022-06-18 09:22:34.439483
# Unit test for function get_definitions

# Generated at 2022-06-18 09:23:01.120616
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_module_names

    # Create a jedi Interpreter object
    interpreter = Interpreter("import sys", [], Project(path=".", added_sys_path=[]))

    # Get the completions for the interpreter
    completions = get_interpreter_completions("import sys", [], [])

    # Check if the completions are of type Completion
    assert all(isinstance(c, Completion) for c in completions)

    # Check if the completions are the same as the ones returned by the jedi Interpreter object
    assert completions == interpreter

# Generated at 2022-06-18 09:23:02.125030
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:23:12.457129
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import ClassContext, FunctionContext, ModuleContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.klass import ClassMixin
    from jedi.evaluate.context.instance import AnonymousInstance
    from jedi.evaluate.context.iterable import AnonymousIterable, AnonymousSequence
    from jedi.evaluate.context.module import ModuleWrapper
    from jedi.evaluate.context.function import FunctionMixin
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.instance import AbstractInstanceContext
    from jedi.evaluate.context.instance import AbstractLazyContext
    from jedi.evaluate.context.instance import AbstractLazyTreeContext

# Generated at 2022-06-18 09:23:17.503547
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.std", [{}])[0].name == "stdout"
    else:
        assert get_interpreter_completions("import sys; sys.std", [{}])[0].name == "stdout="

# Generated at 2022-06-18 09:23:26.978062
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    completions = get_interpreter_completions("import sys; sys.", [], [])
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "list of strings"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"

    completions = get_interpreter_completions("import sys; sys.path.", [], [])

# Generated at 2022-06-18 09:23:33.745751
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    from os.path import join
    from jedi.api.environment import get_default_environment
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter

    # Create a project with a custom sys.path
    # NB! This is not yet supported by jedi
    # https://github.com/davidhalter/jedi/issues/1626
    project = Project(path=join(os.path.dirname(__file__), ".."), added_sys_path=[])
    environment = get_default_environment()
    interpreter = Interpreter(environment=environment, project=project)

    # Check that the project's sys.path is used
    assert interpreter.get_sys_path() == project.get_sys_path()

   

# Generated at 2022-06-18 09:23:43.974501
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_cwd
    from jedi.api.helpers import get_definition
    from jedi.api.helpers import get_references
    from jedi.api.helpers import get_call_signatures
    from jedi.api.helpers import get_in_function_call

# Generated at 2022-06-18 09:23:48.084470
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions(
        source="import os; os.",
        namespaces=[{"os": os}],
        sys_path=["/usr/lib/python3.5"],
    )
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"



# Generated at 2022-06-18 09:23:52.782732
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\n"
    namespaces = [{"sys": jedi.Interpreter("import sys", [])}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert any(c.name == "sys" for c in completions)

# Generated at 2022-06-18 09:23:53.333606
# Unit test for function get_definitions

# Generated at 2022-06-18 09:24:22.229495
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert completions[0].name == "argv"

# Generated at 2022-06-18 09:24:26.453864
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:24:34.987283
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import InterpreterEnvironment

    # Create a new environment
    environment = get_default_environment()
    project = Project(environment)
    interpreter_environment = InterpreterEnvironment(environment, project)

    # Create a new interpreter
    interpreter = Interpreter("", [], interpreter_environment)

    # Get the completions
    completions = get_interpreter_completions("", [], [])

    # Check that the completions are of the correct type
    assert isinstance(completions, list)

# Generated at 2022-06-18 09:24:44.300060
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys

    # Check that we get the same completions with and without sys_path
    source = "import os\nos.path.join("
    row = 1
    column = len(source)
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)
    completions_with_sys_path = get_script_completions(source, row, column, filename, sys_path=[os.path.dirname(os.path.abspath(jedi.__file__))])
    assert len(completions) == len(completions_with_sys_path)
    for completion in completions:
        assert completion in completions_with_sys_path

    # Check that we get the same completions with and without sys_

# Generated at 2022-06-18 09:24:55.065807
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()


# Generated at 2022-06-18 09:25:04.282766
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    import jedi

    if _using_older_jedi(jedi):
        print("Using older jedi")
    else:
        print("Using newer jedi")

    sys.path.append(os.path.dirname(__file__))
    source = "from test_jedi_utils import test_get_definitions\ntest_get_definitions()"
    definitions = get_definitions(source, 2, 1, "test_jedi_utils.py")
    print(definitions)
    assert len(definitions) == 1
    assert definitions[0].line == 2
    assert definitions[0].column == 1
    assert definitions[0].module_path == os.path.abspath(__file__)
    assert definitions[0].name == "test_get_definitions"


# Generated at 2022-06-18 09:25:15.213107
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys", 1, 7, "", sys_path=[])
        completions = script.completions()
    else:
        script = jedi.Script(code="import sys", path="", project=_get_new_jedi_project([]))
        completions = script.complete(line=1, column=7)

    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."

# Generated at 2022-06-18 09:25:24.390877
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position

    source = """
    import sys
    sys.path.append("/home/user/mylib")
    import mylib
    mylib.
    """
    row = 4
    column = 9
    namespaces = [{"type": "module", "name": "sys", "path": "/usr/lib/python3.5/sys.py"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "mylib"
    assert completions[0].complete == "mylib"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:25:31.867660
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.dirname(__file__))
    source = "import test_jedi_utils\n"
    source += "test_jedi_utils.test_get_interpreter_completions()"
    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "test_get_interpreter_completions"
    assert completions[0].complete == "test_get_interpreter_completions"
    assert completions[0].type == "function"
    assert completions[0].description == "test_get_interpreter_completions()"
    assert completions

# Generated at 2022-06-18 09:25:35.870822
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:26:19.332966
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)

        def test_get_definitions_for_function(self):
            def_names = [d.name for d in get_definitions(self.test_file_content, 1, 4, self.test_file)]


# Generated at 2022-06-18 09:26:25.074178
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=["/"])[0].name == "sys"



# Generated at 2022-06-18 09:26:34.122429
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Test with jedi 0.17
    if jedi.__version__[:4] == "0.17":
        source = "import sys\nsys.path.append('" + os.path.dirname(__file__) + "')\nimport"
        completions = get_interpreter_completions(source, [{}])
        assert len(completions) == 1
        assert completions[0].name == "test_utils"
        assert completions[0].complete == "test_utils"
        assert completions[0].type == "module"
        assert completions[0].description == "Module test_utils"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys.test_utils"

# Generated at 2022-06-18 09:26:40.133391
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = 'import sys\n'
        namespaces = [{'sys': sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == 'sys'
        assert completions[0].complete == 'sys'
        assert completions[0].type == 'module'
        assert completions[0].description == 'sys'
        assert completions[0].parent == '<built-in>'
        assert completions[0].full_name == 'sys'
    else:
        source = 'import sys\n'
        namespaces = [{'sys': sys}]

# Generated at 2022-06-18 09:26:47.039102
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)
        assert any(c.name == "sys.path" for c in completions)
        assert any(c.name == "sys.version" for c in completions)
    else:
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0

# Generated at 2022-06-18 09:26:49.899483
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
    ]



# Generated at 2022-06-18 09:27:00.149115
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import math\nmath.c"
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "math.ceil"
    assert completions[0].complete == "math.ceil"
    assert completions[0].type == "function"
    assert completions[0].description == "ceil(${1:x})\n\nReturn the ceiling of x as an Integral.\nThis is the smallest integer >= x."
    assert completions[0].parent == "math"

# Generated at 2022-06-18 09:27:08.208855
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace

    # Test for jedi version 0.13
    class Completion_0_13:
        def __init__(self, name, complete, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

    class Script_0_13:
        def __init__(self, source, row, column, filename, sys_path=None):
            self.source = source
            self.row = row
            self.column

# Generated at 2022-06-18 09:27:17.278577
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    import sys
    import os

    if sys.version_info[0] == 2:
        return

    # Test for jedi 0.13
    if jedi.__version__[:4] == "0.13":
        source = "import os\nos.path.join("
        row = 1
        column = len(source)
        filename = "test.py"
        completions = get_script_completions(source, row, column, filename)
        assert len(completions) == 1
        assert completions[0].name == "os.path.join("
        assert completions[0].complete == "os.path.join("
        assert completions[0].type == "function"

# Generated at 2022-06-18 09:27:25.179447
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.interpreter import Interpreter
        from jedi.api.classes import Completion

        class FakeInterpreter(Interpreter):
            def __init__(self, source, namespaces):
                self.source = source
                self.namespaces = namespaces
