

# Generated at 2022-06-18 09:17:39.446615
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = """
import sys
sys.path.append("/home/user/my_module")
import my_module
my_module.
"""
    namespaces = [{"name": "__main__", "path": "/home/user/my_module/__main__.py"}]
    sys_path = ["/home/user/my_module"]

    completions = get_interpreter_completions(source, namespaces, sys_path)
    assert len(completions) == 1
    assert completions[0].name == "my_module"
    assert completions[0].complete == "my_module"
    assert completions

# Generated at 2022-06-18 09:17:50.190645
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Function, Class, Instance, Statement, ImportName
    from jedi.api.classes import ModuleName, ParamName, VarName, NameWrapper
    from jedi.api.classes import ClassName, FunctionName, StatementName
    from jedi.api.classes import ImportName, ImportedModuleName
    from jedi.api.classes import ImportedName, ImportedModule

# Generated at 2022-06-18 09:18:01.305525
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/tmp')\n"
        namespaces = [{"name": "sys", "path": "/tmp"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "path"
        assert completions[0].complete == "path"
        assert completions[0].type == "instance"
        assert completions[0].description == "list"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys.path"
    else:
        source = "import sys\nsys.path.append('/tmp')\n"
        names

# Generated at 2022-06-18 09:18:03.891085
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:18:11.438223
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import get_sys_path
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.helpers import get_cached_value
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope

# Generated at 2022-06-18 09:18:21.141836
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        source = "import sys\nsys."
        namespaces = [{"name": "__main__", "locals": {"sys": sys}}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "version" for c in completions)
    else:
        source = "import sys\nsys."
        namespaces = [{"name": "__main__", "locals": {"sys": sys}}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "version" for c in completions)

# Generated at 2022-06-18 09:18:33.172283
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 1, 5, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.std", 1, 10, "")
    assert isinstance(completions[0], Completion)
    assert comple

# Generated at 2022-06-18 09:18:38.418572
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("", 0, 0, "") == []
    else:
        assert get_script_completions("", 0, 0, "") == jedi.Script("").complete()



# Generated at 2022-06-18 09:18:39.459362
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:18:41.136693
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition


# Generated at 2022-06-18 09:18:52.913029
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:18:58.619029
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.15.1
        assert get_interpreter_completions("import sys; sys.path", [], sys_path=["/home/me"])
    else:
        # jedi 0.18.1
        assert get_interpreter_completions("import sys; sys.path", [], sys_path=["/home/me"])

# Generated at 2022-06-18 09:19:01.289887
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import utils
    from thonny.plugins.jedi_backend import jedi_utils


# Generated at 2022-06-18 09:19:05.222905
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from thonny.plugins.jedi_utils import get_definitions


# Generated at 2022-06-18 09:19:17.252688
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import ImportName
    from jedi.api.classes import Instance
    from jedi.api.classes import Value
    from jedi.api.classes import Array

# Generated at 2022-06-18 09:19:29.056098
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys; sys.path.append('/home/user/my_module'); import my_module; my_module."
    namespaces = [{"__name__": "__main__"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0

    # Check that completions are sorted
    prev_name = ""
    for completion in completions:
        assert completion.name >= prev_name
        prev_name = completion.name

    # Check that completions are unique
    names = set()
    for completion in completions:
        assert completion.name not in names
        names.add(completion.name)

    # Check that completions are not duplicated
    # (this was the case in jedi 0.13.2)


# Generated at 2022-06-18 09:19:39.128762
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    from unittest.mock import Mock

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            namespaces = [{"a": 1, "b": 2}]
            completions = get_interpreter_completions("a", namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "a")
            self.assertEqual(completions[0].complete, "a")
            self.assertEqual(completions[0].type, "statement")
            self.assertEqual(completions[0].description, "int")
            self.assertEqual(completions[0].parent, "int")

# Generated at 2022-06-18 09:19:51.302154
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    import jedi
    import os
    import sys
    import unittest

    class TestInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            if _using_older_jedi(jedi):
                interpreter = Interpreter("import sys", [])
                completions = interpreter.completions()
            else:
                interpreter = Interpreter("import sys")
                completions = interpreter.complete()

            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")
           

# Generated at 2022-06-18 09:20:02.574550
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)

        def test_get_definitions(self):
            if _using_older_jedi(jedi):
                script = jedi.Script(self.test_file_content, 1, 1, self.test_file)

# Generated at 2022-06-18 09:20:11.780861
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os"
    assert defs[0].line is None
    assert defs[0].column is None

    defs = get_definitions("import os\nos.path", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os"
    assert defs[0].line is None
    assert defs[0].column is None

    defs = get_definitions("import os\nos.path", 1, 0, "")
    assert len

# Generated at 2022-06-18 09:20:28.608307
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

    completions = get_script_completions("import sys; sys.", 0, 12, "")
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys; sys.path", 0, 17, "")
    assert len(completions) > 0


# Generated at 2022-06-18 09:20:38.632141
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import inspect
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file, "r").read()

        def test_get_definitions_1(self):
            definitions = get_definitions(self.test_file_content, 1, 1, self.test_file)
            self.assertEqual(len(definitions), 1)

# Generated at 2022-06-18 09:20:44.135941
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys; sys.path", [{}])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "list of strings"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"



# Generated at 2022-06-18 09:20:54.310313
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from thonny.plugins.jedi_utils import get_definitions

    class TestJediUtils(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_jedi_utils.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_definitions(self):
            if _using_older_jedi(jedi):
                self.skipTest("Test only for jedi 0.18 and later")

# Generated at 2022-06-18 09:21:04.092251
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions(
        source="import sys; sys.path.append('/home/user/'); import os; os.",
        namespaces=[{"os": os}],
        sys_path=["/home/user/"],
    )
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"
    assert completions[0].description == "os.path"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os.path"

# Generated at 2022-06-18 09:21:16.429765
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    source = "import os\nos.path.join"
    row = 1
    column = 16
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:21:18.148426
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition


# Generated at 2022-06-18 09:21:27.160596
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import utils

    source = "import os\nos.path.join()"
    completions = utils.get_script_completions(source, 1, 13, "")
    assert len(completions) > 0
    assert "join" in [c.name for c in completions]

    source = "import os\nos.path.join()"
    completions = utils.get_script_completions(source, 1, 13, "", sys_path=["/tmp"])
    assert len(completions) > 0
    assert "join" in [c.name for c in completions]



# Generated at 2022-06-18 09:21:37.012766
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.helpers import get_interpreter_completions
    from jedi.api.helpers import get_definitions
    from jedi.api.helpers import parse_source
    from jedi.api.helpers import get_statement_of_position
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_path
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_callsites
    from jedi.api.helpers import get_in_function_call

# Generated at 2022-06-18 09:21:48.479743
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert _using_older_jedi(jedi)

    completions = get_interpreter_completions("import os\nos.", [])
    assert len(completions) > 0
    assert completions[0].name == "path"

    completions = get_interpreter_completions("import os\nos.path.", [])
    assert len(completions) > 0
    assert completions[0].name == "join"

    completions = get_interpreter_completions("import os\nos.path.join.", [])
    assert len(completions) > 0
    assert completions[0].name == "__call__"

    completions = get_interpreter_completions("import os\nos.path.join(", [])

# Generated at 2022-06-18 09:22:05.581366
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import os\nos.", [], [])

# Generated at 2022-06-18 09:22:15.449737
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    import jedi
    import os

    # Test with older jedi
    if _using_older_jedi(jedi):
        interpreter = Interpreter("import os", [])
        completions = interpreter.completions()
        assert completions[0].name == "os"
        assert completions[0].complete == "os"
        assert completions[0].type == "module"
        assert completions[0].description == "os"
        assert completions[0].parent == "builtins"
        assert completions[0].full_name == "os"

    # Test with newer jedi
    else:
        interpreter = Interpreter("import os", [])
        completions = interpreter.complete()

# Generated at 2022-06-18 09:22:16.227568
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

# Generated at 2022-06-18 09:22:25.380020
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\nos.path.join"
            row = 0
            column = len(source)
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].type, "function")
            self.assertEqual(definitions[0].name, "join")
            self.assertEqual(definitions[0].full_name, "os.path.join")
            self.assertEqual(definitions[0].module_name, "os.path")

# Generated at 2022-06-18 09:22:34.821444
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:22:44.518461
# Unit test for function get_definitions
def test_get_definitions():
    def check(source, row, column, expected):
        actual = get_definitions(source, row, column, "test.py")
        assert len(actual) == len(expected)
        for i in range(len(actual)):
            assert actual[i].module_name == expected[i][0]
            assert actual[i].line == expected[i][1]
            assert actual[i].column == expected[i][2]

    check(
        "import math\nmath.sqrt(",
        2,
        12,
        [("math", None, None), ("math", None, None)],
    )
    check(
        "import math\nmath.sqrt(",
        2,
        12,
        [("math", None, None), ("math", None, None)],
    )

# Generated at 2022-06-18 09:22:55.452364
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
    else:
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)

    assert len(definitions) == 1
    assert definitions[0].description == "function join(a, *p)"
    assert definitions[0].line == 0
    assert definitions[0].column == 0

# Generated at 2022-06-18 09:23:05.755249
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # jedi 0.18
    assert get_interpreter_completions("import sys; sys.", [], sys_path=["/"])[0].name == "path"
    assert get_interpreter_completions("import sys; sys.", [], sys_path=["/"])[0].complete == "path"
    assert get_interpreter_completions("import sys; sys.", [], sys_path=["/"])[0].type == "attribute"
    assert get_interpreter_completions("import sys; sys.", [], sys_path=["/"])[0].description == "list of strings"
    assert get_interpreter_completions("import sys; sys.", [], sys_path=["/"])[0].parent == "sys"
    assert get_interpreter_com

# Generated at 2022-06-18 09:23:15.747899
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    filename = os.path.join(tmpdir, "test_module.py")
    with open(filename, "w") as f:
        f.write("def test_function():\n    pass")

    # Add the temporary directory to the system path
    sys.path.append(tmpdir)

    # Get the completions
    completions = get_interpreter_completions("import test_module\ntest_module.", [{}], sys_path=[tmpdir])

    # Remove the temporary directory from the system path
    sys.path.remove(tmpdir)

    # Remove the temporary directory
    shutil.rmtree

# Generated at 2022-06-18 09:23:25.856781
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.pa", 0, 16, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "statement"
    assert completions[0].description == "sys.path"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"

    completions = get_script_completions("import sys; sys.path.ap", 0, 20, "")
    assert len(completions) == 1

# Generated at 2022-06-18 09:23:43.694189
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 1, 5, "test.py")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.std", 1, 10, "test.py")

# Generated at 2022-06-18 09:23:52.475436
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.evaluate.compiled.access import TreeNameDefinition
    from jedi.evaluate.compiled.value import CompiledValueName
    from jedi.evaluate.compiled.context import CompiledContextName
    from jedi.evaluate.compiled.subprocess import SubprocessName
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.value import CompiledObject
    from jedi.evaluate.compiled.value import CompiledFunction
    from jedi.evaluate.compiled.value import CompiledClass
    from jedi.evaluate.compiled.value import CompiledInstance
    from jedi.evaluate.compiled.value import CompiledValueName
    from jedi.evaluate.compiled.value import CompiledValueName

# Generated at 2022-06-18 09:24:02.094312
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    import jedi

    class Test(TestCase):
        def test_get_script_completions(self):
            source = "import sys\n"
            row = 1
            column = 7
            filename = "test.py"
            completions = get_script_completions(source, row, column, filename)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")
            self.assertEqual(completions[0].complete, "sys")
            self.assertEqual(completions[0].type, "module")
            self.assertEqual(completions[0].description, "sys")
            self.assertEqual(completions[0].parent, None)
            self

# Generated at 2022-06-18 09:24:09.578763
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import os\nos.path.join('')"
    row, column = 2, 10
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:24:20.167552
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys", 1, 7, "")
        completions = script.completions()
    else:
        script = jedi.Script(code="import sys", path="")
        completions = script.complete(line=1, column=7)

    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent == "builtins"

# Generated at 2022-06-18 09:24:29.855901
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import os.path
    import unittest


# Generated at 2022-06-18 09:24:39.217222
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        completions = get_script_completions(source, 2, 0, "test.py")
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "Module sys"
        assert completions[0].parent == "builtins"
        assert completions[0].full_name == "sys"
    else:
        source = "import sys\n"
        completions = get_script_completions(source, 2, 0, "test.py")
        assert len(completions) == 1
        assert completions

# Generated at 2022-06-18 09:24:46.738040
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_cwd_context
    from jedi.api.helpers import get_call_signatures
    from jedi.api.helpers import get_in_function_call
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope

# Generated at 2022-06-18 09:24:56.752027
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions(
        "import sys\nsys.pa", row=2, column=10, filename="test.py"
    )
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "sys.path"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"



# Generated at 2022-06-18 09:25:05.942195
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 0, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 0, "")[0].complete == "sys"
        assert get_script_completions("import sys", 0, 0, "")[0].type == "module"
        assert get_script_completions("import sys", 0, 0, "")[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."

# Generated at 2022-06-18 09:25:23.411905
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project

    source = "import sys; sys.pa"
    completions = get_script_completions(source, 1, len(source), "test.py")
    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "sys.path"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"

    source = "import sys; sys.path.app"
    completions = get_script_completions

# Generated at 2022-06-18 09:25:27.390018
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import os; os.", [{}])[0].name == "path"
    else:
        assert get_interpreter_completions("import os; os.", [{}])[0].name == "path="

# Generated at 2022-06-18 09:25:33.418441
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    # Test for jedi 0.16
    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    # Test for jedi 0.17

# Generated at 2022-06-18 09:25:42.837615
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 0, 10, "")[0].name == "sys"
        assert get_script_completions("import sys\nsys.", 0, 10, "")[0].complete == "sys."
        assert get_script_completions("import sys\nsys.", 0, 10, "")[0].type == "module"
        assert get_script_completions("import sys\nsys.", 0, 10, "")[0].description == "sys"
        assert get_script_completions("import sys\nsys.", 0, 10, "")[0].parent == "sys"

# Generated at 2022-06-18 09:25:51.728583
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        print("Test skipped because of old jedi version")
        return

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

    source = "import sys\nsys."
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]


# Generated at 2022-06-18 09:25:58.933124
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import jedi_utils

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = jedi_utils.get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "builtins.sys"


# Unit test

# Generated at 2022-06-18 09:26:08.631251
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "join"
        assert completions[0].type == "function"
    else:
        source = "import os\nos.path.join"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "join"
        assert completions[0].type == "function"

# Generated at 2022-06-18 09:26:14.365771
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completion.jedi_utils import get_script_completions

    completions = get_script_completions("import sys\nsys.", 0, 9, "")
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description.startswith("Module")

    completions = get_script_completions("import sys\nsys.std", 0, 13, "")
    assert len(completions) > 0
    assert completions[0].name == "stdin"
    assert completions[0].complete == "stdin"
    assert completions[0].type == "stream"

# Generated at 2022-06-18 09:26:22.306888
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Test with older jedi
    if _using_older_jedi(jedi):
        # Test with sys_path
        sys_path = [os.path.dirname(os.path.abspath(__file__))]
        completions = get_interpreter_completions("import sys", [], sys_path)
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "builtins"

# Generated at 2022-06-18 09:26:31.882381
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.script import Script
    from jedi.api.names import Name
    from jedi.api.classes import Completion
    from jedi.api.classes import Definition
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument

# Generated at 2022-06-18 09:26:51.963130
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys"
    else:
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys."

# Generated at 2022-06-18 09:27:01.695024
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import inspect

    def get_definitions(source: str, row: int, column: int, filename: str):
        if _using_older_jedi(jedi):
            script = jedi.Script(source, row, column, filename)
            return script.goto_definitions()
        else:
            script = jedi.Script(code=source, path=filename)
            return script.infer(line=row, column=column)

    def get_script_completions(source: str, row: int, column: int, filename: str):
        if _using_older_jedi(jedi):
            script = jedi.Script(source, row, column, filename)
            completions = script.completions()

# Generated at 2022-06-18 09:27:10.201665
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "argv"

# Generated at 2022-06-18 09:27:18.963278
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\n"
    row = 2
    column = 4
    filename = "test.py"
    script = Script(source, row, column, filename)
    completions = script.completions()
    assert completions == get_script_completions(source, row, column, filename)
    assert completions[0] == Completion(
        name="sys",
        complete="sys",
        type="module",
        description="This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter.",
        parent=None,
        full_name="sys",
    )

# Generated at 2022-06-18 09:27:27.363039
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    import jedi
    import os

    # Test for older jedi versions
    if _using_older_jedi(jedi):
        completions = get_script_completions("import sys", 0, 7, "")
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "builtins"