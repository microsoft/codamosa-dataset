

# Generated at 2022-06-18 09:17:33.133271
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.classes import Script

        assert get_script_completions("", 0, 0, "") == Script("", 0, 0, "").completions()
    else:
        from jedi.api.classes import Script

        assert get_script_completions("", 0, 0, "") == Script("", path="").complete(line=0, column=0)

# Generated at 2022-06-18 09:17:42.471904
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", ".."))
    from thonny.plugins.micropython.micropython_stubs import get_stub_path

    stub_path = get_stub_path()
    sys.path.append(stub_path)

    source = """
from machine import Pin
pin = Pin(2, Pin.OUT)
pin.value(1)
"""
    row = 4
    column = 5
    filename = "test.py"

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()

# Generated at 2022-06-18 09:17:52.382734
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:18:04.852396
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import CompiledObject
    from jedi.api.classes import Instance
    from jedi.api.classes import Value
    from jedi.api.classes import Scope

# Generated at 2022-06-18 09:18:12.053162
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    import jedi
    import os

    def get_completions(source, row, column):
        return get_script_completions(source, row, column, os.path.join(os.getcwd(), "test.py"))

    assert get_completions("import sys", 0, 0) == []
    assert get_completions("import sys", 0, 7) == []
    assert get_completions("import sys", 0, 8) == []
    assert get_completions("import sys", 0, 9) == []
    assert get_completions("import sys", 0, 10) == []
    assert get_completions("import sys", 0, 11) == []

# Generated at 2022-06-18 09:18:22.072351
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(__file__)
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)
            self.test_file_ast_lines = self.test_file_ast.get_code().split("\n")


# Generated at 2022-06-18 09:18:34.515737
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join("
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "os"
        assert completions[0].type == "module"
        assert completions[0].description == "os"
    else:
        source = "import os\nos.path.join("
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "os"

# Generated at 2022-06-18 09:18:43.797242
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys; sys.path.append('/home/user/')"
        namespaces = [{"__name__": "__main__", "__doc__": None, "__package__": None}]
        completions = get_interpreter_completions(source, namespaces, sys_path=["/home/user/"])
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)
    else:
        # NB! Can't send project for Interpreter in 0.18
        # https://github.com/davidhalter/jedi/pull/1734
        source = "import sys; sys.path.append('/home/user/')"

# Generated at 2022-06-18 09:18:54.003576
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope_stmt
    from jedi.api.helpers import get_names_of_scope_expr
    from jedi.api.helpers import get_names_of_scope_name
    from jedi.api.helpers import get_names_of_scope_params
    from jedi.api.helpers import get_names_of_scope_type
    from jedi.api.helpers import get_names_of_scope_list_comp
    from jedi.api.helpers import get_names_of_scope_dict_comp
    from jedi.api.helpers import get_names_of_scope_set_comp
   

# Generated at 2022-06-18 09:19:00.638394
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # up to jedi 0.17
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/bin"])[0].name == "sys"
    else:
        # jedi 0.18
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/bin"])[0].name == "sys"

# Generated at 2022-06-18 09:19:10.965240
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:19:23.158241
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os.path", 0, 0, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import os.path", 0, 0, "", sys_path=["/tmp"])
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import os.path", 0, 0, "", sys_path=["/tmp"])
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)


# Generated at 2022-06-18 09:19:33.634758
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest
    from unittest.mock import Mock
    from thonny.plugins.jedi_utils import get_interpreter_completions

    class Test(unittest.TestCase):
        def test_get_interpreter_completions(self):
            if _using_older_jedi(jedi):
                # Test for jedi version < 0.18
                # Mock sys.path
                sys.path = ["/home/user/thonny/plugins/jedi_utils.py"]
                # Mock os.path.isdir
                os.path.isdir = Mock(return_value=True)
                # Mock os.path.isfile
                os.path.isfile = Mock(return_value=True)
                # Mock os.

# Generated at 2022-06-18 09:19:44.961460
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    # Get the path of the current file
    path = os.path.dirname(os.path.realpath(__file__))
    # Get the path of the test file
    test_file = os.path.join(path, "test_get_definitions.py")
    # Open the test file
    with open(test_file, "r") as f:
        # Read the test file
        source = f.read()
    # Get the definitions of the test file
    definitions = get_definitions(source, 1, 1, test_file)
    # Check if the definitions are correct
    assert len(definitions) == 1
    assert definitions[0].line == 1
    assert definitions[0].column == 1
    assert definitions[0].module_path == test_file
   

# Generated at 2022-06-18 09:19:56.515138
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.references import get_references
    from jedi.api.names import get_names
    from jedi.api.keywords import get_keywords
    from jedi.api.helpers import get_line_code
    from jedi.api.helpers import get_cursor_pos


# Generated at 2022-06-18 09:20:07.986712
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:20:12.399532
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:20:22.638152
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.evaluate.compiled.subprocess import SubProcessEnvironment
    from jedi.evaluate.compiled.access import create_access_path
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.value import CompiledObject
    from jedi.evaluate.compiled.value import CompiledName
    from jedi.evaluate.compiled.value import CompiledFunction
    from jedi.evaluate.compiled.value import CompiledInstance
    from jedi.evaluate.compiled.value import CompiledClass

# Generated at 2022-06-18 09:20:30.899722
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions_1(self):
            source = "import sys"
            row = 0
            column = 7
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].type, "module")
            self.assertEqual(definitions[0].description, "sys")
            self.assertEqual(definitions[0].full_name, "sys")

        def test_get_definitions_2(self):
            source = "import sys\nsys.path"
            row = 1
            column = 7

# Generated at 2022-06-18 09:20:40.669117
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].type == "module"
        assert get_script_completions("import sys", 0, 7, "")[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."

# Generated at 2022-06-18 09:21:00.537851
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 10, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.std", 0, 14, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "std"
    assert completions[0].complete == "std"
   

# Generated at 2022-06-18 09:21:08.027216
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "")[0].complete == "sys"



# Generated at 2022-06-18 09:21:20.584428
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        row = 2
        column = 1
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].name == "sys"
        assert definitions[0].type == "module"
        assert definitions[0].description == "sys"
        assert definitions[0].parent == "builtins"
        assert definitions[0].full_name == "sys"
    else:
        source = "import sys\n"
        row = 2
        column = 1
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)

# Generated at 2022-06-18 09:21:25.695223
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.classes import Script
        from jedi.api.classes import Completion
    else:
        from jedi.api.project import Project
        from jedi.api.script import Script
        from jedi.api.completion import Completion


# Generated at 2022-06-18 09:21:32.153204
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script("import os", 1, 1, "")
        definitions = script.goto_definitions()
    else:
        script = jedi.Script("import os", path="")
        definitions = script.infer(line=1, column=1)

    assert len(definitions) == 1
    assert definitions[0].type == "module"
    assert definitions[0].full_name == "os"

# Generated at 2022-06-18 09:21:37.111802
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = """
import os
os.path.join("a", "b")
"""
    completions = get_interpreter_completions(source, [])
    assert len(completions) > 0
    assert "join" in [c.name for c in completions]

# Generated at 2022-06-18 09:21:48.573694
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    import jedi
    import os
    import sys

    # get the path of the test file
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "test_get_script_completions.py")

    # get the completions
    completions = get_script_completions(
        source="import os\nos.path.join(", row=1, column=21, filename=path
    )

    # check if the completions are correct
    assert len(completions) == 1
    assert isinstance(completions[0], ThonnyCompletion)
   

# Generated at 2022-06-18 09:21:56.658635
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        namespaces = [{"__builtins__": __builtins__}]
    else:
        namespaces = [{"__builtins__": __builtins__, "__name__": "__main__"}]

    completions = get_interpreter_completions("import sys; sys.std", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "stdin"


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-18 09:22:02.664034
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.helpers import get_definition_location
    from jedi.api.helpers import get_definition_names
    from jedi.api.helpers import get_definition_type
    from jedi.api.helpers import get_definition_description
    from jedi.api.helpers import get_definition_parent
    from jedi.api.helpers import get_definition_full_name


# Generated at 2022-06-18 09:22:08.226854
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import os\nos.path.join('a', 'b')"
    namespaces = [{"os": jedi.Interpreter("import os", []).namespace}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert any(c.name == "join" for c in completions)

# Generated at 2022-06-18 09:22:25.460562
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_script_completions(self):
            from jedi import __version__

            if __version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
                self.assertEqual(
                    get_script_completions("import sys", 0, 7, ""),
                    [
                        ThonnyCompletion(
                            name="sys",
                            complete="sys",
                            type="module",
                            description="This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter.",
                            parent=None,
                            full_name="sys",
                        )
                    ],
                )
            else:
                self.assertE

# Generated at 2022-06-18 09:22:28.905937
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:22:38.537419
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if sys.version_info[0] == 3 and sys.version_info[1] < 6:
        return

    source = "import os\nos.path.join('a', 'b')"
    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "os"
    assert completions[0].type == "module"

    source = "import os\nos.path.join('a', 'b')"
    namespaces = [{"os": jedi.Interpreter("import os", [{}]).names()[0]}]
    completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-18 09:22:48.854368
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def test_get_script_completions(self):
            source = "import os\nos.path.join"
            row = 1
            column = 20
            filename = "test.py"
            sys_path = [os.path.dirname(os.path.abspath(__file__))]
            completions = get_script_completions(source, row, column, filename, sys_path)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "join")
            self.assertEqual(completions[0].complete, "join(")

# Generated at 2022-06-18 09:22:59.283506
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.16.0
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].name == "path"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].complete == "path"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].type == "list"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].description == "list"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].parent == "sys"
        assert get_interpreter_complet

# Generated at 2022-06-18 09:23:05.004514
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:23:15.025638
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    source = "from test_jedi_utils import *\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"
    source += "test_get_script_completions()\n"

# Generated at 2022-06-18 09:23:25.116846
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        completions = get_script_completions(source, 1, 1, "")
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "builtins"

# Generated at 2022-06-18 09:23:28.103058
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 8, "")
    assert completions == [Completion("sys", "sys", "module", "", None, "sys")]

# Generated at 2022-06-18 09:23:37.336965
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", ".."))

    source = "import thonny\nthonny."
    namespaces = [{"thonny": jedi.Interpreter("import thonny", [])}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "thonny.workbench" in [c.name for c in completions]



# Generated at 2022-06-18 09:23:54.406863
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value


# Generated at 2022-06-18 09:24:04.122236
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import ast

    def get_definitions_from_ast(source, row, column):
        tree = parso.parse(source)
        node = get_statement_of_position(tree, (row, column))
        if isinstance(node, parso.python.tree.ExprStmt):
            node = node.get_rhs()
        if isinstance(node, parso.python.tree.Name):
            return [node.get_definition()]
        else:
            return []

    def get_definitions_from_jedi(source, row, column):
        return get_definitions(source, row, column, "test.py")

    def get_definitions_from_ast_or_jedi(source, row, column):
        return get_definitions_from_

# Generated at 2022-06-18 09:24:10.832415
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\nimport sys\nimport math\nimport datetime\n"
    namespaces = [
        {"os": os},
        {"sys": sys},
        {"math": math},
        {"datetime": datetime},
    ]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 4
    assert completions[0].name == "os"
    assert completions[1].name == "sys"
    assert completions[2].name == "math"
    assert completions[3].name == "datetime"


# Generated at 2022-06-18 09:24:21.885915
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    source = "import sys\nsys."
    row = 2
    column = 5

# Generated at 2022-06-18 09:24:23.710314
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

# Generated at 2022-06-18 09:24:32.523912
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    def get_completions(source, row, column, filename):
        return get_script_completions(source, row, column, filename)

    def get_jedi_completions(source, row, column, filename):
        script = Script(source, row, column, filename)
        return script.completions()

    def assert_completions_equal(completions1, completions2):
        assert len(completions1) == len(completions2)

        for i in range(len(completions1)):
            assert completions1[i].name == completions2[i].name
            assert completions1[i].complete == completions2[i].complete

# Generated at 2022-06-18 09:24:42.263469
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 0
   

# Generated at 2022-06-18 09:24:51.392258
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import jedi_utils

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = jedi_utils.get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:25:00.867524
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name

# Generated at 2022-06-18 09:25:10.530595
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import InstanceElement
    from jedi.api.classes import ImportElement
    from jedi.api.classes import ClassMethod
    from jedi.api.classes import FunctionOverload

# Generated at 2022-06-18 09:25:32.592353
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # This test is not needed for jedi 0.18
    if jedi.__version__[:4] == "0.18":
        return

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write the content of the file
    with open(path, "w") as f:
        f.write("def foo():\n    pass\n")

    # Add the file to the sys.path
    sys.path.append(os.path.dirname(path))

    # Get the completions
    completions = get_interpreter_completions("foo", [{}])

    # Remove the file
    os.remove(path)

    # Remove the file from the sys.path
    sys

# Generated at 2022-06-18 09:25:42.550174
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_definitions(self):
            # Test that get_definitions returns the correct results
            # for the test file.
            script = Script(self.test_file_content, 1, 1, self.test_file)
            definitions = script.goto_definitions()

# Generated at 2022-06-18 09:25:46.353207
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:25:48.293733
# Unit test for function get_definitions
def test_get_definitions():
    import unittest


# Generated at 2022-06-18 09:25:55.336880
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.jedi_utils import get_interpreter_completions

    completions = get_interpreter_completions("import sys\n", [{"sys": sys}])
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:26:04.947569
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions(
        "import os\nos.path.join('')",
        [{"os": __import__("os")}],
    )
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"
    assert completions[0].description == "join(a, *p) -> path\n\nJoin two or more pathname components, inserting '/' as needed.\nIf any component is an absolute path, all previous path components\nwill be discarded.  An empty last part will result in a path that\nends with a separator."
    assert completions[0].parent.name

# Generated at 2022-06-18 09:26:13.895982
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.interpreter import Interpreter

        interpreter = Interpreter("import sys", [])
    else:
        interpreter = jedi.Interpreter("import sys")

    completions = get_interpreter_completions("import sys", [], [])
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == interpreter.namespaces[0]

# Generated at 2022-06-18 09:26:21.840652
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys\nimport os\n", 1, 1, "")
        completions = script.completions()
    else:
        script = jedi.Script(code="import sys\nimport os\n", path="")
        completions = script.complete(line=1, column=1)

    assert len(completions) == 2
    assert completions[0].name == "sys"
    assert completions[1].name == "os"

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys\nimport os\n", 1, 1, "", sys_path=[os.path.dirname(sys.executable)])
       

# Generated at 2022-06-18 09:26:31.377692
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path", 0, 0, "")
    assert completions == [
        Completion("import", "import ", "statement", "import ...\n\nImport a module.", None, "import"),
        Completion("sys", "sys", "import", "import sys\n\nThis module provides access to some objects used or maintained by the\ninterpreter and to functions that interact strongly with the interpreter.\n\nDynamic objects:\n\nargv -- command line arguments; argv[0] is the script pathname if known\npath -- module search path; path[0] is the script directory, else ''\nmodules -- dictionary of loaded modules\n\n", None, "sys"),
    ]

    completions = get_script_com

# Generated at 2022-06-18 09:26:38.428671
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "sys"
    assert completions[0].full

# Generated at 2022-06-18 09:27:16.495128
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Test for jedi versions 0.13.x, 0.14.x, 0.15.x, 0.16.x, 0.17.x
            if _using_older_jedi(jedi):
                source = "import os\n"
                row = 1
                column = 7
                filename = "test.py"
                definitions = get_definitions(source, row, column, filename)
                self.assertEqual(definitions[0].module_name, "os")
                self.assertEqual(definitions[0].line, 1)
                self.assertEqual(definitions[0].column, 7)
                self