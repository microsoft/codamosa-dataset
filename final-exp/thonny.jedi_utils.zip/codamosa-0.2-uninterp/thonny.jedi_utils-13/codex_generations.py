

# Generated at 2022-06-18 09:18:33.173703
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    if _using_older_jedi(jedi):
        print("Jedi version is older than 0.18")
        return

    # Get the path of the current file
    path = os.path.dirname(os.path.abspath(__file__))
    # Add the path to the sys.path
    sys.path.append(path)

    # Get the source code of the current file
    source = open(__file__).read()

    # Get the definitions of the function test_get_definitions
    definitions = get_definitions(source, 5, 4, __file__)

    # Print the name of the function
    print(definitions[0].name)

    # Print the path of the file where the function is defined

# Generated at 2022-06-18 09:18:43.304730
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    source = "import test_utils\ntest_utils.get_interpreter_completions"
    namespaces = [{"test_utils": test_utils}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "get_interpreter_completions"
    assert completions[0].complete == "get_interpreter_completions"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:18:53.754409
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.evaluate.compiled import CompiledObject
        from jedi.evaluate.context import ClassContext, FunctionContext

        class DummyCompiledObject(CompiledObject):
            def __init__(self, name, parent):
                self.name = name
                self.parent = parent

            def get_root_context(self):
                return self.parent

        class DummyClassContext(ClassContext):
            def __init__(self, name):
                self.name = name

            def py__getattribute__(self, name):
                return DummyCompiledObject(name, self)

        class DummyFunctionContext(FunctionContext):
            def __init__(self, name):
                self.name = name


# Generated at 2022-06-18 09:19:03.800610
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # Test with jedi 0.17
    if _using_older_jedi(jedi):
        return

    # Test with jedi 0.18
    completions = get_interpreter_completions(
        source="import math\nmath.sqrt(",
        namespaces=[{"math": math}],
        sys_path=[],
    )
    assert len(completions) == 1
    assert completions[0].name == "x="
    assert completions[0].complete == "x="
    assert completions[0].type == "param"
    assert completions[0].description == "x"
    assert completions[0].parent == "math.sqrt"
    assert completions[0].full_name == "x"

# Generated at 2022-06-18 09:19:16.320754
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project

    # Test for jedi 0.17
    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    interpreter = Interpreter(source, namespaces)
    completions = interpreter.complete()
    assert len(completions) > 0

    # Test for jedi 0.18
    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    interpreter = Interpreter(source, namespaces)
    completions = interpreter.complete()
    assert len(completions) > 0

    # Test for jedi 0.18 with sys_path
    source = "import sys\n"

# Generated at 2022-06-18 09:19:28.195998
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            with open(path, "r") as f:
                source = f.read()
            row = 3
            column = 4
            filename = path
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 2)
            self.assertEqual(definitions[0].column, 4)
            self.assertEqual(definitions[0].module_path, filename)

   

# Generated at 2022-06-18 09:19:38.027838
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    from thonny.plugins.jedi_utils import get_definitions

    # Get the path of the current file
    path = os.path.dirname(os.path.realpath(__file__))

    # Get the path of the test file
    test_file = os.path.join(path, "test_get_definitions.py")

    # Get the source code of the test file
    with open(test_file, "r") as f:
        source = f.read()

    # Get the ast of the test file
    ast = parso.parse(source)

    # Get the line and column of the test function

# Generated at 2022-06-18 09:19:50.272741
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os"

    defs = get_definitions("import os.path", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os.path"

    defs = get_definitions("import os.path as p", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os.path"

    defs = get_def

# Generated at 2022-06-18 09:19:54.984562
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:20:06.544286
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_cached_value

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    sys_path = ["/home/user/"]

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        completions = script.completions()
    else:
        script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))
        completions = script.complete(line=row, column=column)

    assert completions[0].name == "sys"

# Generated at 2022-06-18 09:20:30.370473
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase


# Generated at 2022-06-18 09:20:40.550210
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import __version__
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.compiled.access import CompiledValueName
    from jedi.evaluate.compiled.subprocess import SubprocessName
    from jedi.evaluate.compiled.access import CompiledValueName
    from jedi.evaluate.compiled.subprocess import SubprocessName
    from jedi.evaluate.compiled.access import CompiledValueName
    from jedi.evaluate.compiled.subprocess import SubprocessName
    from jedi.evaluate.compiled.access import CompiledValueName
    from jedi.evaluate.compiled.subprocess import SubprocessName

# Generated at 2022-06-18 09:20:41.320908
# Unit test for function get_definitions

# Generated at 2022-06-18 09:20:50.721486
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:21:01.056794
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    from thonny import get_workbench
    from thonny.languages import tr

    if _using_older_jedi(jedi):
        return

    # Get the path of the current file
    path = os.path.dirname(os.path.abspath(__file__))

    # Get the path of the test file
    test_file = os.path.join(path, "test_jedi_utils.py")

    # Get the path of the test file
    test_file_2 = os.path.join(path, "test_jedi_utils_2.py")

    # Get the path of the test file
    test_file_3 = os.path.join(path, "test_jedi_utils_3.py")

    # Get the

# Generated at 2022-06-18 09:21:11.495789
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Test for jedi 0.16.0
            if _using_older_jedi(jedi):
                # Get the path of the current directory
                path = os.path.dirname(os.path.realpath(__file__))
                # Get the path of the test file
                test_file = os.path.join(path, "test_get_definitions.py")
                # Get the path of the test file
                test_file_path = os.path.join(path, "test_get_definitions.py")
                # Get the path of the test file
                test_file_path_2 = os

# Generated at 2022-06-18 09:21:22.432824
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            import jedi

            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_interpreter_completions("import sys", [{"sys": sys}])[0].name, "sys"
                )
            else:
                self.assertEqual(
                    get_interpreter_completions("import sys", [{"sys": sys}])[0].name,
                    "sys",
                )

    Test().test_get_interpreter_completions()

# Generated at 2022-06-18 09:21:32.055924
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.helpers import _tweak_completions
    from jedi.api.helpers import _using_older_jedi
    from jedi.api.helpers import _get_new_jedi_project
    from jedi.api.helpers import _copy_of_get_statement_of_position
    from jedi.api.helpers import get_statement_of_position
    from jedi.api.helpers import parse_source
    from jedi.api.helpers import get_definitions
    from jedi.api.helpers import get_interpreter_completions
    from jedi.api.helpers import _tweak_complet

# Generated at 2022-06-18 09:21:42.889687
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os\nos.", 1, 4, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"
    assert completions[0].description == "os.path"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os.path"

    completions = get_script_completions("import os\nos.path.", 1, 10, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
   

# Generated at 2022-06-18 09:21:54.260030
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.api.classes import Completion


# Generated at 2022-06-18 09:22:35.719997
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import math\nmath."
        namespaces = [{"math": math}]
        completions = get_interpreter_completions(source, namespaces)
        assert completions[0].name == "pi"
        assert completions[0].complete == "pi"
        assert completions[0].type == "float"
        assert completions[0].description == "pi = 3.141592653589793"
        assert completions[0].parent == "math"
        assert completions[0].full_name == "math.pi"
    else:
        source = "import math\nmath."
        namespaces = [{"math": math}]
        completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-18 09:22:37.144413
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree


# Generated at 2022-06-18 09:22:39.513673
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi


# Generated at 2022-06-18 09:22:44.368311
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 1, 8, "")
    assert completions == [
        Completion("sys", "sys", "module", "", None, "sys"),
        Completion("sys.path", "sys.path", "list", "", None, "sys.path"),
    ]



# Generated at 2022-06-18 09:22:55.318396
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    sys_path = ["/usr/lib/python3.6"]
    interpreter = Interpreter(source, namespaces, sys_path=sys_path)
    completions = interpreter.completions()
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:23:05.632959
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.pa", 0, 15, "")
    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "sys.path"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import sys; sys.path.ap", 0, 19, "")
    assert len(completions) == 1
    assert completions[0].name == "append"

# Generated at 2022-06-18 09:23:09.682226
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys; sys.", [{}])
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"

# Generated at 2022-06-18 09:23:10.650614
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:23:20.825173
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench
    from thonny.plugins.jedi_support import jedi_utils
    from thonny.plugins.jedi_support import jedi_plugin
    from thonny.plugins.jedi_support import jedi_backend
    from thonny.plugins.jedi_support import jedi_completion
    from thonny.plugins.jedi_support import jedi_linting
    from thonny.plugins.jedi_support import jedi_goto

    get_workbench().set_option("jedi_support.enabled", True)
    get_workbench().set_option("jedi_support.use_jedi_backend", True)

    # Test with older jedi version
    jedi_plugin.jedi = jedi_utils.import_jedi_module

# Generated at 2022-06-18 09:23:27.899270
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_script_completions(self):
            source = "import sys\n"
            row = 1
            column = 7
            filename = "test.py"
            completions = get_script_completions(source, row, column, filename)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")

    Test().test_get_script_completions()



# Generated at 2022-06-18 09:24:08.627952
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.names import AbstractNameDefinition
    from jedi.evaluate.context import ClassContext, FunctionContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.klass import ClassContextMixin
    from jedi.evaluate.context.function import FunctionContextMixin
    from jedi.evaluate.context.instance import InstanceContextMixin
    from jedi.evaluate.context.iterable import IterableContextMixin
    from jedi.evaluate.context.namespace import NamespaceContextMixin
    from jedi.evaluate.context.naming import NamingContextMixin
    from jedi.evaluate.context.param import ParamNameMixin

# Generated at 2022-06-18 09:24:18.868627
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys; sys.path.append('/home/user/thonny/plugins')"

# Generated at 2022-06-18 09:24:28.764949
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:24:38.204369
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.api.classes import Completion

    source = "import sys\n"
    row = 2
    column = 1
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)
    assert completions == Script(source, row, column, filename).completions()

    # Test that completions are tweaked
    completions = get_script_completions("sys.", row, column, filename)

# Generated at 2022-06-18 09:24:45.959736
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)

        def test_get_definitions(self):
            defs = get_definitions(self.test_file_content, row=2, column=5, filename=self.test_file)
            self.assertEqual

# Generated at 2022-06-18 09:24:56.540593
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = """
            class A:
                pass

            class B:
                pass

            a = A()
            b = B()
            """
            row = 7
            column = 5
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 5)
            self.assertEqual(definitions[0].column, 7)
            self.assertEqual(definitions[0].module_path, filename)
            self.assertEqual(definitions[0].type, "class")

# Generated at 2022-06-18 09:25:05.692937
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os"

    defs = get_definitions("import os\nos.path", 0, 0, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os"

    defs = get_definitions("import os\nos.path", 1, 0, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os.path"

    defs = get_definitions("import os\nos.path.join", 1, 0, "")
    assert len(defs) == 1
    assert defs[0].module_name == "os.path"

    defs = get

# Generated at 2022-06-18 09:25:17.086057
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        ThonnyCompletion(
            name="sys",
            complete="sys",
            type="module",
            description="The Python interpreter.",
            parent=None,
            full_name="sys",
        )
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")

# Generated at 2022-06-18 09:25:25.998954
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        namespaces = [{"a": 1}, {"b": 2}]
    else:
        namespaces = [{"a": 1}, {"b": 2}, {"c": 3}]

    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"
    assert completions[0].parent == "int"
    assert completions[0].full_name == "int"

    completions = get_interpreter_completions("b", namespaces)

# Generated at 2022-06-18 09:25:32.753890
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_interpreter_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.names import Name
    from jedi.api.namespaces import ModuleNamespace
    from jedi.api.namespaces import FunctionNamespace
    from jedi.api.namespaces import ClassNamespace
    from jedi.api.namespaces import InstanceNamespace
    from jedi.api.namespaces import Namespace
    from jedi.api.namespaces import BuiltinNamespace
    from jedi.api.namespaces import ValueNamespace
    from jedi.api.namespaces import ParamNamespace

# Generated at 2022-06-18 09:26:48.177484
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

# Generated at 2022-06-18 09:26:56.583940
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Test with older jedi
    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('" + os.path.dirname(__file__) + "')\nimport"
        completions = get_interpreter_completions(source, [])
        assert len(completions) == 1
        assert completions[0].name == "test_jedi_utils"

        # Test with newer jedi
    else:
        source = "import sys\nsys.path.append('" + os.path.dirname(__file__) + "')\nimport"
        completions = get_interpreter_completions(source, [], sys_path=[os.path.dirname(__file__)])

# Generated at 2022-06-18 09:27:06.717425
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import ScriptCompletion
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import ScriptNamespace
    from jedi.api.classes import InterpreterProject
    from jedi.api.classes import ScriptProject
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import ScriptCompletion
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import ScriptNamespace

# Generated at 2022-06-18 09:27:14.757102
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.dirname(__file__))
    source = "import os\nos.path.join("
    row = 1
    column = len(source)
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "os.path.join("
    assert completions[0].complete == "os.path.join("
    assert completions[0].type == "function"
    assert completions[0].description == "os.path.join(path, *paths)"
    assert completions[0].parent == "os.path"

# Generated at 2022-06-18 09:27:23.614918
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value

    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert defs[0].description == "import os"
    assert defs[0].module_name == "os"
    assert defs[0].line == 0
    assert defs[0].column == 0
    assert defs[0].in_builtin_module()
    assert defs[0].is_keyword is False
    assert defs[0].is_stub() is False
    assert defs[0].is_definition() is True
    assert defs[0].is_imported() is False
    assert defs[0].is_compiled() is False

# Generated at 2022-06-18 09:27:30.432259
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.ap", 4, 21, "test.py")
    assert completions == [
        Completion("append", "append", "function", "append(${1:object})\nAppend object to the end of the list.", "list", "sys.path.append"),
        Completion("appendleft", "appendleft", "function", "appendleft(${1:object})\nAppend object to the left of the deque.", "deque", "sys.path.appendleft"),
    ]


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-18 09:27:36.705847
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_cached_completion_names
    from jedi.api.helpers import get_cached_completion_name
    from jedi.api.helpers import get_cached_completion_paths
    from jedi.api.helpers import get_cached_completion_path
    from jedi.api.helpers import get_cached_completion_module
    from jedi.api.helpers import get_cached_completion_module_path
    from jedi.api.helpers import get_cached_completion_module_paths


# Generated at 2022-06-18 09:27:39.828806
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:27:42.311155
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree
    import jedi


# Generated at 2022-06-18 09:27:47.964189
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import ClassContext, FunctionContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.instance import AnonymousInstance
    from jedi.evaluate.context.klass import ClassContext
    from jedi.evaluate.context.function import FunctionContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.instance import AnonymousInstance
    from jedi.evaluate.context.iterable import AnonymousIterable
    from jedi.evaluate.context.instance import TreeInstance
    from jedi.evaluate.context.instance import BoundMethod
    from jedi.evaluate.context.instance import TreeInstance