

# Generated at 2022-06-18 09:18:19.066166
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import get_sys_path
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.settings import settings
    from jedi.api.project import get_default_project
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment

# Generated at 2022-06-18 09:18:24.284988
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.get", 0, 17, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "getdefaultencoding"



# Generated at 2022-06-18 09:18:35.690815
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # Test for jedi 0.13.x
        source = "import os\n"
        completions = get_interpreter_completions(source, [])
        assert len(completions) == 1
        assert completions[0].name == "os"
        assert completions[0].complete == "os"
        assert completions[0].type == "module"
        assert completions[0].description == "Module os"
        assert completions[0].parent is None
        assert completions[0].full_name == "os"

        source = "import os\nos."
        completions = get_interpreter_completions(source, [])
        assert len(completions) > 1

# Generated at 2022-06-18 09:18:42.855663
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "Module sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:18:52.372620
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\nsys.path"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "list"
    assert completions[0].description == "list of strings"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.path"



# Generated at 2022-06-18 09:19:01.964107
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:19:13.910400
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "argv"
    assert completions[0].complete == "argv"

    completions = get_script_completions("import sys\nsys.argv", 1, 11, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"


# Generated at 2022-06-18 09:19:26.297703
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-18 09:19:36.015787
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 6, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.std", 0, 11, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "std"
    assert completions[0].complete == "std"
   

# Generated at 2022-06-18 09:19:47.430032
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate import compiled
    from jedi.evaluate.compiled import builtin
    from jedi.evaluate.compiled.access import get_string_value
    from jedi.evaluate.compiled.value import CompiledObject, CompiledValue

    class MockInterpreter(Interpreter):
        def __init__(self, source, namespaces):
            self.source = source
            self.namespaces = namespaces

        def complete(self):
            return self.completions()


# Generated at 2022-06-18 09:20:11.022330
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso

    # Test for jedi version 0.16.0
    if jedi.__version__[:4] == "0.16":
        # Test for function definition
        source = "def test():\n    pass"
        row = 0
        column = 3
        filename = "test.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        assert definitions[0].type == "function"
        assert definitions[0].description == "test()"
        assert definitions[0].full_name == "test"
        assert definitions[0].parent.type == "module"
        assert definitions[0].parent.description == "test.py"
        assert definitions[0].parent.full_name == "test.py"

# Generated at 2022-06-18 09:20:14.783122
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys.path)
    else:
        assert get_interpreter_completions("import sys", [], sys.path)

# Generated at 2022-06-18 09:20:19.879583
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys\nsys.", [{}])[0].name == "sys"
    else:
        assert get_interpreter_completions("import sys\nsys.", [{}])[0].name == "sys."

# Generated at 2022-06-18 09:20:20.917974
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:20:29.563029
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if sys.version_info[0] == 2:
        return

    source = "import os\nos.path.join"
    namespaces = [{"os": jedi.Interpreter("import os", [{}]).names()[0]}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:20:34.551749
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:20:37.004566
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.helpers import get_definition_location
    from jedi.api.helpers import get_definition_parent
    from jedi.api.helpers import get_definition_type
    from jedi.api.helpers import get_definition_description
    from jedi.api.helpers import get_definition_full_name


# Generated at 2022-06-18 09:20:45.965594
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso

    def get_definitions(source, row, column):
        script = jedi.Script(source, row, column)
        return script.goto_definitions()

    def get_definitions_new(source, row, column):
        script = jedi.Script(code=source, path="")
        return script.infer(line=row, column=column)

    def get_definitions_new_2(source, row, column):
        script = jedi.Script(code=source, path="")
        return script.goto(line=row, column=column)

    def get_definitions_new_3(source, row, column):
        script = jedi.Script(code=source, path="")

# Generated at 2022-06-18 09:20:55.879229
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nimport os", 1, 7, "")
    assert completions == [Completion("os", "os", "module", "", "", "os")]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")

# Generated at 2022-06-18 09:21:05.892688
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        return

    # Test with no sys_path
    source = "import os\nos.path.join("
    namespaces = [{"name": "__main__", "path": os.path.abspath(".")}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "os"

    # Test with sys_path
    source = "import sys\nsys.path.join("
    namespaces = [{"name": "__main__", "path": os.path.abspath(".")}]

# Generated at 2022-06-18 09:21:42.063015
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            from jedi import Interpreter

            source = "import os; os.path.join('a', 'b')"
            namespaces = [{"os": Interpreter(source, []).goto_definitions()[0].module}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 2)
            self.assertEqual(completions[0].name, "join")
            self.assertEqual(completions[1].name, "joinpath")

    test = Test("test_get_interpreter_completions")
    test.test_get_interpreter_completions

# Generated at 2022-06-18 09:21:53.014987
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os

    def _get_definitions(source, row, column, filename):
        return get_definitions(source, row, column, filename)

    def _get_definitions_old(source, row, column, filename):
        script = jedi.Script(source, row, column, filename)
        return script.goto_definitions()

    def _get_definitions_new(source, row, column, filename):
        script = jedi.Script(code=source, path=filename)
        return script.infer(line=row, column=column)


# Generated at 2022-06-18 09:22:02.284586
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_params_of_function
    from jedi.api.helpers import get_params_of_call
    from jedi.api.helpers import get_signature_of_function
    from jedi.api.helpers import get_signature_of_call
    from jedi.api.helpers import get_docstring
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_names

# Generated at 2022-06-18 09:22:12.613121
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import sys
    import os
    import os.path
    import unittest
    import unittest.mock
    import thonny.jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils
    import thonny.jediutils as jediutils

# Generated at 2022-06-18 09:22:19.814919
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "test.py")[0].name == "sys"
        assert get_script_completions("import sys\nsys.", 1, 4, "test.py")[0].name == "path"
        assert get_script_completions("import sys\nsys.pa", 1, 8, "test.py")[0].name == "path"
        assert get_script_completions("import sys\nsys.path.", 1, 11, "test.py")[0].name == "append"

# Generated at 2022-06-18 09:22:29.233915
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys

    def get_definitions_for_file(filename):
        with open(filename, "r") as f:
            source = f.read()
        tree = parso.parse(source)
        definitions = []
        for node in tree.iter_funcdefs():
            for name_node in node.get_used_names():
                if name_node.value == "get_definitions":
                    definitions.append(
                        (
                            name_node.start_pos[0],
                            name_node.start_pos[1],
                            name_node.end_pos[0],
                            name_node.end_pos[1],
                        )
                    )
        return definitions


# Generated at 2022-06-18 09:22:38.936218
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert len(completions) > 1
   

# Generated at 2022-06-18 09:22:44.875596
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion

    source = "import os\n"
    namespaces = [{'os': Interpreter(source, []).namespace()}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == 'os'

# Generated at 2022-06-18 09:22:54.699824
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:23:05.048297
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "test.py")

# Generated at 2022-06-18 09:23:35.752534
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]


# Generated at 2022-06-18 09:23:44.790878
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("import os", [{"os": os}])
        completions = interpreter.completions()
    else:
        interpreter = jedi.Interpreter("import os", [{"os": os}])
        completions = interpreter.complete()

    assert len(completions) > 0
    assert completions[0].name == "os"
    assert completions[0].complete == "os"
    assert completions[0].type == "module"
    assert completions[0].description == "os"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os"

# Generated at 2022-06-18 09:23:50.533896
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=["/"])[0].name == "sys"

# Generated at 2022-06-18 09:23:52.868724
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion


# Generated at 2022-06-18 09:24:02.504005
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def test_get_script_completions(self):
            if sys.version_info[0] == 2:
                self.skipTest("Jedi doesn't support Python 2")
            if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
                self.skipTest("Jedi doesn't support Python 2")

            source = "import os\nos.path.join("
            row = 1
            column = len(source)
            filename = os.path.abspath(__file__)
            sys_path = [os.path.dirname(filename)]
            completions = get

# Generated at 2022-06-18 09:24:09.876587
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os
    import os.path
    import unittest
    import tempfile
    import shutil
    import random
    import string

    class TestGetScriptCompletions(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, "test.py")
            self.test_file_content = "import os\nimport sys\nimport random\n"
            with open(self.test_file, "w") as f:
                f.write(self.test_file_content)

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-18 09:24:10.710066
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:24:21.758009
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    defs = get_definitions("import sys", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Module)
    assert defs[0].name == "sys"

    defs = get_definitions("import sys\nsys.", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Module)
    assert defs[0].name == "sys"

    defs = get_definitions("import sys\nsys.argv", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Definition)

# Generated at 2022-06-18 09:24:27.009968
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\n"
    namespaces = [{"sys": jedi.Interpreter("import sys", [])}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].type == "module"



# Generated at 2022-06-18 09:24:36.335102
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys"
    else:
        source = "import sys\n"

# Generated at 2022-06-18 09:25:42.796786
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.isdir("
        completions = get_script_completions(source, 3, 22, "test.py")
        assert completions[0].name == "path"
        assert completions[0].complete == "path"
        assert completions[1].name == "path="
        assert completions[1].complete == "path="
    else:
        source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.isdir("
        completions = get_script_completions(source, 3, 22, "test.py")

# Generated at 2022-06-18 09:25:44.870834
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_location


# Generated at 2022-06-18 09:25:47.843133
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys; sys.", [], sys_path=["/"])
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:25:56.092765
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.executable}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:26:05.942705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.evaluate.compiled import CompiledObject
        from jedi.evaluate.context import ClassContext
        from jedi.evaluate.context.instance import CompiledInstance
        from jedi.evaluate.context.module import ModuleContext
        from jedi.evaluate.context.instance import TreeInstance
        from jedi.evaluate.context.klass import ClassContext
        from jedi.evaluate.context.function import FunctionContext
        from jedi.evaluate.context.instance import AnonymousInstance
        from jedi.evaluate.context.builtins import BuiltinContext
        from jedi.evaluate.context.iterable import AnonymousInstance
        from jedi.evaluate.context.iterable import CompiledInstance
        from jedi.evaluate.context.iterable import TreeInstance

# Generated at 2022-06-18 09:26:10.160232
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:26:17.537863
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_names_of_scope
    from jedi.evaluate.compiled.subprocess import InterpreterEnvironment
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.access import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.access import Compiled

# Generated at 2022-06-18 09:26:26.712653
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class Test(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import math; math.sqrt"
            namespaces = [{"math": math}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(completions[0].name, "sqrt")
            self.assertEqual(completions[0].complete, "sqrt")
            self.assertEqual(completions[0].type, "function")
            self.assertEqual(completions[0].description, "sqrt(x)\n\nReturn the square root of x.")
            self.assertEqual(completions[0].parent, "math")

# Generated at 2022-06-18 09:26:35.348840
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.classes import Script
        from jedi.api.classes import Completion
    else:
        from jedi.api.project import Project
        from jedi.api.script import Script
        from jedi.api.completion import Completion

    source = "import os\nos.path.join('a', 'b')"
    row = 1
    column = 8
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "join"
    assert completions

# Generated at 2022-06-18 09:26:39.830274
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:27:44.600674
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # jedi 0.17
    if sys.version_info[0] == 3 and sys.version_info[1] >= 6:
        assert get_interpreter_completions("import sys; sys.path.append('.'); import os; os.", [], sys_path=["."])[0].name == "path"
    else:
        assert get_interpreter_completions("import sys; sys.path.append('.'); import os; os.", [], sys_path=["."])[0].name == "path"

    # jedi 0.18

# Generated at 2022-06-18 09:27:49.343320
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_params_of_function
    from jedi.api.helpers import get_params_of_call_signature
    from jedi.api.helpers import get_params_of_scope
    from jedi.api.helpers import get_params_of_signature
    from jedi.api.helpers import get_signatures_of_function
    from jedi.api.helpers import get_signatures_of_scope
    from jedi.api.helpers import get_signatures_of_module
    from jedi.api.helpers import get_signatures_of_class

# Generated at 2022-06-18 09:27:55.746803
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
        assert completions[0].complete == "path"
    else:
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
        assert completions[0].complete == "path="