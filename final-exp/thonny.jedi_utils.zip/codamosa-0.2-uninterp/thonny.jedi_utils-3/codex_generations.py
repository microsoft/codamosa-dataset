

# Generated at 2022-06-18 09:17:27.720426
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

# Generated at 2022-06-18 09:17:37.129364
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)
            self.test_file_ast_lines = self.test_file_ast.get_code().splitlines()
            self.test_file_ast_line_count = len

# Generated at 2022-06-18 09:17:47.454206
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Definition
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import Param
    from jedi.api.classes import Flow
    from jedi.api.classes import ClassOrFunc
    from jedi.api.classes import ImportName


# Generated at 2022-06-18 09:18:01.036211
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_sys_path
    from jedi.api.settings import jedi_path
    from jedi.api.environment import get_cached_default_environment

    # Test for jedi 0.17.0
    # Test for jedi 0.18.0
    # Test for jedi 0.19.0
    # Test for jedi 0.20.0
    # Test for jedi 0.21.0
    # Test for jedi 0.22.0
    # Test for jedi 0.23.0
    # Test for jedi 0.24.0
    #

# Generated at 2022-06-18 09:18:05.600696
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    def _mock_completion(name, complete, type, description, parent, full_name):
        completion = Mock()
        completion.name = name
        completion.complete = complete
        completion.type = type
        completion.description = description
        completion.parent = parent
        completion.full_name = full_name
        return completion

    def _mock_completions(completions):
        result = Mock()
        result.completions = Mock(return_value=completions)
        return result

    def _mock_script(completions):
        script = Mock()
        script.completions = Mock(return_value=completions)
        return script

    def _mock_script_new(completions):
        script = Mock()

# Generated at 2022-06-18 09:18:12.537207
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "", "", "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert completions == [
        Completion("argv", "argv", "attribute", "", "sys", "sys.argv"),
        Completion("exit", "exit", "function", "", "sys", "sys.exit"),
        Completion("path", "path", "attribute", "", "sys", "sys.path"),
    ]

    completions = get_script_completions("import sys\nsys.path.", 1, 11, "")
   

# Generated at 2022-06-18 09:18:14.970420
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-18 09:18:27.532621
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script

    source = "import os\nos.path.join('')"
    completions = get_script_completions(source, 2, 12, "")
    assert len(completions) > 0
    assert completions[0].name == "join"
    assert completions[0].complete == "join("
    assert completions[0].type == "function"
    assert completions[0].description == "join(a, *p) -> path\n\nJoin two or more pathname components, inserting '/' as needed.\nIf any component is an absolute path, all previous path components\nwill be discarded.  An empty last part will result in a path that\nends with a separator."
    assert completions[0].parent == "os.path"

# Generated at 2022-06-18 09:18:28.500087
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_location


# Generated at 2022-06-18 09:18:34.915309
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    source = 'import sys\n'
    row = 2
    column = 1
    filename = 'test.py'
    script = Script(source, row, column, filename)
    completions = script.completions()
    assert completions == [Completion('sys', 'sys', 'module', '', None, 'sys')]

# Generated at 2022-06-18 09:18:55.029500
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_module_names

    # Create a jedi Interpreter object
    interpreter = Interpreter("import os", [], get_system_environment())
    # Get the completions
    completions = interpreter.complete()
    # Check that the completions are of type Completion
    assert isinstance(completions[0], Completion)
    # Check that the completions are not empty
    assert len(completions) > 0

    # Create a jedi Interpreter object
    interpreter = Interpreter("import os", [], get_system_environment())
    # Get the

# Generated at 2022-06-18 09:19:02.347494
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions(
        "import sys\nsys.pa", 5, 8, "test.py", sys_path=["/home/user"]
    )
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"



# Generated at 2022-06-18 09:19:03.321585
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:19:15.774913
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = "import os\n"
            row = 1
            column = 8
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_name, "os")
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 7)
            self.assertEqual(definitions[0].description, "import os")
            self.assertEqual(definitions[0].module_path, os.__file__)

# Generated at 2022-06-18 09:19:26.150120
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            import jedi

            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_interpreter_completions("import sys; sys.path", [{}])[0].name,
                    "path",
                )
            else:
                self.assertEqual(
                    get_interpreter_completions("import sys; sys.path", [{}])[0].name,
                    "path=",
                )

    Test().test_get_interpreter_completions()

# Generated at 2022-06-18 09:19:35.858143
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_windows
    import jedi

    if _using_older_jedi(jedi):
        return

    if running_on_windows():
        sys_path = [r"C:\Users\Public\Documents\Thonny\Plugins\thonny-jedi\tests"]
    else:
        sys_path = ["/home/user/thonny/plugins/thonny-jedi/tests"]

    source = "import os\nos.path.join("
    row = 1
    column = len(source)
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename, sys_path=sys_path)
    assert len(completions) == 1

# Generated at 2022-06-18 09:19:47.242308
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "join"
        assert completions[0].complete == "join"
        assert completions[0].type == "function"
        assert completions[0].description == "join(a, *p) -> path\n\nJoin two or more pathname components, inserting '/' as needed.\nIf any component is an absolute path, all previous path components\nwill be discarded.  An empty last part will result in a path that\nends with a separator."

# Generated at 2022-06-18 09:19:58.737695
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.helpers import get_names_of_scope

    # Create a project
    project = Project(path=".")
    # Get the environment
    environment = get_default_environment(project=project)
    # Create an interpreter
    interpreter = Interpreter(environment=environment)
    # Get the names of the scope
    names = get_names_of_scope(interpreter.get_root_context())
    # Get the completions
    completions = get_interpreter_completions("", names)
    # Check that the completions are not empty
    assert completions != []

# Generated at 2022-06-18 09:20:09.537167
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.13.2
        assert get_interpreter_completions("import sys; sys.pa", [{}]) == [
            ThonnyCompletion(
                name="path",
                complete="path",
                type="module",
                description="sys.path",
                parent="sys",
                full_name="sys.path",
            )
        ]

# Generated at 2022-06-18 09:20:13.318995
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import sys

    if sys.version_info[0] == 2:
        return

    # Test for jedi 0.17
    if _using_older_jedi(jedi):
        return


# Generated at 2022-06-18 09:20:30.234386
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)
    else:
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)

# Generated at 2022-06-18 09:20:35.695857
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    defs = get_definitions("import os", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Module)
    assert defs[0].name == "os"

    defs = get_definitions("import os\nos.path.join", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Module)
    assert defs[0].name == "os"

    defs = get_definitions("import os\nos.path.join", 1, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], jedi.api.classes.Module)

# Generated at 2022-06-18 09:20:43.918761
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def _get_completions_old_jedi(source, row, column, filename, sys_path=None):
        import jedi

        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        return script.completions()

    def _get_completions_new_jedi(source, row, column, filename, sys_path=None):
        import jedi


# Generated at 2022-06-18 09:20:54.096359
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == None
    assert completions[0].full_name == "sys"

    source = "import sys\nsys.\n"
    row = 2
    column = 4
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)

# Generated at 2022-06-18 09:20:59.391353
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]

# Generated at 2022-06-18 09:21:09.739192
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys; sys.path.append('/home/user/thonny/lib')\n"
    namespaces = [{'name': '__main__', 'path': '/home/user/thonny/lib/test.py'}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:21:21.353939
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        definitions = get_definitions(source, 1, len(source), "")
        assert len(definitions) == 1
        assert definitions[0].module_name == "os.path"
        assert definitions[0].line == 0
        assert definitions[0].column == 0
    else:
        source = "import os\nos.path.join"
        definitions = get_definitions(source, 1, len(source), "")
        assert len(definitions) == 1
        assert definitions[0].module_name == "os.path"
        assert definitions[0].line == 0
        assert definitions[0].column == 0

# Generated at 2022-06-18 09:21:31.571669
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def _get_new_jedi_project(sys_path):
        if not sys_path:
            return None
        else:
            import jedi

            return jedi.Project(path=sys_path[0], added_sys_path=sys_path)

    def _tweak_completions(completions):
        # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
        # since 0.16 it does. Need to ensure similar result for all supported versions.
        result = []


# Generated at 2022-06-18 09:21:34.548483
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    import jedi
    import sys

    if _using_older_jedi(jedi):
        return


# Generated at 2022-06-18 09:21:40.827269
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/lib/python3.6"])
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/lib/python3.6"])

# Generated at 2022-06-18 09:22:05.992292
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/lib/python3.7"])
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/usr/lib/python3.7"])

# Generated at 2022-06-18 09:22:13.983316
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestJediUtils(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import os"
            namespaces = [{"os": os}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)
            self.assertTrue(completions[0].name.startswith("os."))

    unittest.main(module="test_jedi_utils", exit=False)

# Generated at 2022-06-18 09:22:22.673483
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    import jedi
    import parso
    import sys
    import os

    # Test for older jedi versions
    if _using_older_jedi(jedi):
        script = Script("import sys", 1, 1, "test.py")
        completions = script.completions()
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
        assert completions[0].parent == "builtins"
        assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:22:31.828594
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_ast = parso.parse(self.test_file_content)
            self.test_file_lines = self.test_file_content.splitlines()


# Generated at 2022-06-18 09:22:41.268593
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import ClassContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.klass import ClassContext
    from jedi.evaluate.context.function import FunctionContext
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.instance import InstanceContext
    from jedi.evaluate.context.iterable import AnonymousInstance
    from jedi.evaluate.context.builtins import BuiltinContext
    from jedi.evaluate.context.instance import TreeInstance
    from jedi.evaluate.context.instance import BoundMethod
    from jedi.evaluate.context.instance import BoundMethod
    from jedi.evaluate.context.instance import BoundMethod

# Generated at 2022-06-18 09:22:52.226729
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Test with older jedi
    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys"

    # Test with newer jedi
    else:
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.complete()

# Generated at 2022-06-18 09:23:02.599676
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        print("This test is only for jedi 0.18 and newer")
        return

    # Create a temporary file
    test_file = "test_file.py"
    with open(test_file, "w") as f:
        f.write("def test_function(a, b):\n    return a + b")

    # Add the directory of the temporary file to sys.path
    sys.path.append(os.path.dirname(os.path.abspath(test_file)))

    # Get completions

# Generated at 2022-06-18 09:23:07.288404
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\n"
    namespaces = [{"sys": jedi.Interpreter("sys", []).namespace}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert any(c.name == "sys" for c in completions)

# Generated at 2022-06-18 09:23:12.000643
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        from jedi.api.classes import Script

        assert Script
    else:
        from jedi.api.project import Project

        assert Project


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-18 09:23:21.929648
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def setUp(self):
            self.source = "import os\nimport sys\nos.path.join(sys.path[0], 'test')"
            self.namespaces = [
                {
                    "__name__": "__main__",
                    "__doc__": None,
                    "__package__": None,
                    "__loader__": None,
                    "__spec__": None,
                    "__annotations__": {},
                    "__builtins__": __builtins__,
                    "__file__": "test.py",
                    "__cached__": None,
                }
            ]


# Generated at 2022-06-18 09:23:49.341295
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    # Get the path of the test file
    test_file_path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")

    # Get the path of the test file's directory
    test_file_dir = os.path.dirname(test_file_path)

    # Add the test file's directory to the system path
    sys.path.append(test_file_dir)

    # Open the test file
    test_file = open(test_file_path, "r")

    # Read the test file
    test_file_contents = test_file.read()

    # Close the test file
    test_file.close()

    # Get the definitions

# Generated at 2022-06-18 09:23:59.427813
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.keywords import KeywordName
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_contexts_for_statement
    from jedi.api.helpers import get_module_contexts_for_name
    from jedi.api.helpers import get_module_contexts_for_position
    from jedi.api.helpers import get_module_contexts_for_scope
    from jedi.api.helpers import get_module_contexts_for_scope_node
    from jedi.api.helpers import get_module_contexts_for_scope_stmt

# Generated at 2022-06-18 09:24:07.983319
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        Completion("sys", "sys", "module", "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available.", "", "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")

# Generated at 2022-06-18 09:24:17.814240
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].description == "join(a, *p)"
    else:
        source = "import os\nos.path.join"
        row = 1
        column = 16
        filename = "test.py"
        script = jedi.Script(code=source, path=filename)
        definitions = script.infer(line=row, column=column)
        assert len(definitions) == 1

# Generated at 2022-06-18 09:24:27.901369
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import SourceFile
    from jedi.api.classes import Parser
    from jedi.api.classes import Module
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement
    from jedi.api.classes import KeywordStatement
    from jedi.api.classes import ImportStatement
    from jedi.api.classes import ImportFromStatement
    from jedi.api.classes import Flow


# Generated at 2022-06-18 09:24:37.369347
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            self.test_file_content = open(self.test_file_path).read()

        def test_get_definitions_for_class(self):
            definitions = get_definitions(self.test_file_content, 5, 5, self.test_file_path)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 4)
            self.assertE

# Generated at 2022-06-18 09:24:45.395071
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock
    import jedi

    namespaces = [
        {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__loader__": Mock(),
            "__spec__": None,
            "__annotations__": {},
            "__builtins__": jedi.Interpreter.builtins,
            "__file__": "<input>",
            "__cached__": None,
        }
    ]

    completions = get_interpreter_completions("print(", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "print"
    assert completions[0].complete == "print("

    completions = get_interpreter_completions

# Generated at 2022-06-18 09:24:55.939844
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        print("Older jedi")
        completions = get_script_completions("import sys", 0, 7, "test.py", sys.path)
        assert len(completions) > 0
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent == "builtins"
        assert completions[0].full_name == "sys"
    else:
        print("Newer jedi")
        completions = get_script_completions("import sys", 0, 7, "test.py", sys.path)

# Generated at 2022-06-18 09:25:01.475312
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
    else:
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.complete()

    assert len(completions) > 0
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:25:11.097585
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []
        assert get_definitions("import os", 0, 0, "") == []

# Generated at 2022-06-18 09:25:40.212972
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    source = "import os\nos.path.join()"
    row = 1
    column = 12
    filename = "test.py"
    script = Script(source, row, column, filename)
    completions = script.completions()
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"
    assert completions[0].description == "join(path, *paths) -> str"
    assert completions[0].parent == "os.path"
    assert completions[0].full_name == "os.path.join"

    completions = get_script_completions(source, row, column, filename)
    assert comple

# Generated at 2022-06-18 09:25:49.516016
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest

    # Test for jedi 0.17.2

# Generated at 2022-06-18 09:25:52.367926
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("import sys; sys.", [], sys_path=["/"])
    assert completions
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:25:58.473597
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os

    # Add current folder to sys.path
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    # Create a file with the following content
    # class MyClass:
    #     def __init__(self):
    #         self.my_attr = 1
    #         self.my_method = self.my_method
    #     def my_method(self):
    #         pass
    #
    # my_obj = MyClass()
    # my_obj.
    #
    # The last line is where the completions are requested

# Generated at 2022-06-18 09:26:08.461564
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.references import References
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Class
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_params_of_funcdef
    from jedi.api.helpers import get_params_of_scope
    from jedi.api.helpers import get_qualified_names


# Generated at 2022-06-18 09:26:12.687817
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_interpreter_completions

    completions = get_interpreter_completions("import sys", [{"sys": sys}])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:26:13.515417
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

# Generated at 2022-06-18 09:26:21.538184
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.keywords import KeywordName

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:26:31.079266
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.script import Script
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope


# Generated at 2022-06-18 09:26:38.247522
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import os.path
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_interpreter_completions.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_interpreter_completions(self):
            completions = get_interpreter_completions(self.test_file_content, [{}])
            self.assertTrue(len(completions) > 0)