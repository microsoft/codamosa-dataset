

# Generated at 2022-06-18 09:17:41.515464
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("", 0, 0, "") == []
    else:
        assert get_script_completions("", 0, 0, "") == jedi.Script("", 0, 0, "").complete()



# Generated at 2022-06-18 09:17:45.582739
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.path.append('.'); import os; os.", 0, 0, "")
    else:
        assert get_script_completions("import os; os.", 0, 0, "")

# Generated at 2022-06-18 09:17:55.912509
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    import jedi

    source = "import os\nos.path.join("
    completions = get_script_completions(source, 1, len(source), "test.py")
    assert len(completions) == 1
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "os.path.join("
    assert completions[0].complete == "os.path.join("
    assert completions[0].type == "function"
    assert completions[0].description == "os.path.join(a, *p) -> path"

# Generated at 2022-06-18 09:18:06.599879
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    import jedi

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    sys_path = ["/usr/lib/python3.5/"]

    if _using_older_jedi(jedi):
        try:
            script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            script = jedi.Script(source, row, column, filename)

        completions = script.completions()

# Generated at 2022-06-18 09:18:12.372015
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys\n"
            namespaces = [{"name": "__main__", "path": os.path.abspath(__file__)}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")

    if _using_older_jedi(jedi):
        unittest.main()

# Generated at 2022-06-18 09:18:21.141805
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")

    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:18:33.179037
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_string_value
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_names_containing_name
    from jedi.api.helpers import get_module_names_starting_with_name
    from jedi.api.helpers import get_module_names_ending_with_name
    from jedi.api.helpers import get_module_names_matching_regex


# Generated at 2022-06-18 09:18:38.432057
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:18:41.826831
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    from os.path import dirname, join, abspath

    sys.path.append(join(dirname(dirname(dirname(abspath(__file__)))), "test"))


# Generated at 2022-06-18 09:18:52.661023
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            import jedi

            if _using_older_jedi(jedi):
                # TODO: add test for older jedi
                pass
            else:
                completions = get_interpreter_completions(
                    source="import os\nos.path.join('')",
                    namespaces=[{"os": os}],
                    sys_path=[],
                )
                self.assertEqual(len(completions), 1)
                self.assertEqual(completions[0].name, "join")
                self.assertEqual(completions[0].complete, "join")
                self.assertEqual(completions[0].type, "function")

# Generated at 2022-06-18 09:19:19.156638
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    def check(source, row, column, expected):
        completions = get_script_completions(source, row, column, "test.py")
        assert len(completions) == len(expected)
        for i in range(len(completions)):
            assert completions[i].name == expected[i][0]
            assert completions[i].complete == expected[i][1]
            assert completions[i].type == expected[i][2]

    check(
        "import sys\nsys.path.append('/home/user/')\nimport ",
        2,
        26,
        [("sys", "sys", "module")],
    )


# Generated at 2022-06-18 09:19:30.873771
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os\nos.", 1, 5, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"
    assert completions[0].description == "os.path"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os.path"

    completions = get_script_completions("import os\nos.path.", 1, 11, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
   

# Generated at 2022-06-18 09:19:31.522609
# Unit test for function get_definitions

# Generated at 2022-06-18 09:19:42.349258
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys

    def get_definitions_test(source, row, column):
        return get_definitions(source, row, column, "test.py")

    def get_definitions_jedi(source, row, column):
        script = jedi.Script(source, row, column, "test.py")
        return script.goto_definitions()

    def get_definitions_parso(source, row, column):
        module = parso.parse(source)
        return module.get_definition_names_at_pos(row, column)

    def get_definitions_jedi_new(source, row, column):
        script = jedi.Script(code=source, path="test.py")

# Generated at 2022-06-18 09:19:53.566004
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
        assert completions[0].complete == "path"
    else:
        source = "import sys\nsys.path"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
        assert completions[0].complete == "path"

# Generated at 2022-06-18 09:20:05.481705
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition

    def check_definitions(source, row, column, expected_definitions):
        definitions = get_definitions(source, row, column, "test.py")
        assert len(definitions) == len(expected_definitions)
        for i in range(len(definitions)):
            assert definitions[i].description == expected_definitions[i][0]
            assert definitions[i].line == expected_definitions[i][1]
            assert definitions[i].column == expected_definitions[i][2]
            assert definitions[i].module_name == expected_definitions[i][3]


# Generated at 2022-06-18 09:20:06.109492
# Unit test for function get_definitions

# Generated at 2022-06-18 09:20:10.069260
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.pa", 0, 14, "")[0].name == "path"
    else:
        assert get_script_completions("import sys; sys.pa", 0, 14, "")[0].name == "path="

# Generated at 2022-06-18 09:20:13.916822
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:20:24.133199
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            # Test that get_interpreter_completions returns the same result as jedi.Interpreter.complete
            # for jedi 0.16.0 and 0.17.0
            if _using_older_jedi(jedi):
                source = "import os\nos."
                namespaces = [{"__name__": "__main__", "__doc__": None, "__package__": None, "__loader__": None, "__spec__": None, "__annotations__": {}, "__builtins__": __builtins__, "os": os, "sys": sys}]
                interpreter

# Generated at 2022-06-18 09:20:50.114087
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/home/user/')\nimport"
        namespaces = [{"type": "module", "name": "sys", "path": "/usr/lib/python3.6/sys.py"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:20:58.445450
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:21:08.594617
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Name
    from jedi.api.classes import Definition
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import Namespace
    from jedi.api.classes import Scope
    from jedi.api.classes import User

# Generated at 2022-06-18 09:21:15.781272
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])[0].name == "sys"
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])[0].name == "sys"



# Generated at 2022-06-18 09:21:20.469002
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])
    else:
        assert get_interpreter_completions("import sys", [], sys_path=["/tmp"])

# Generated at 2022-06-18 09:21:28.943468
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys\nsys."
            namespaces = [{"name": "__main__", "path": os.path.abspath(".")}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertTrue(len(completions) > 0)
            self.assertTrue(any(c.name == "path" for c in completions))

    return unittest.main(module=__name__, exit=False)

# Generated at 2022-06-18 09:21:37.163688
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return
    else:
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys"

# Generated at 2022-06-18 09:21:42.890349
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.pa", 1, 16, "test.py")[0].name == "path"
    else:
        assert get_script_completions("import sys; sys.pa", 1, 16, "test.py")[0].name == "path="

# Generated at 2022-06-18 09:21:44.869103
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions


# Generated at 2022-06-18 09:21:55.879100
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    import jedi

    completions = get_interpreter_completions("import os; os.", [], None)
    assert completions == [Completion("path", "path", "module", "", None, "os.path")]

    completions = get_interpreter_completions("import os; os.path.", [], None)
    assert completions == [Completion("abspath", "abspath", "function", "", None, "os.path.abspath")]

    completions = get_interpreter_completions("import os; os.path.abspath.", [], None)

# Generated at 2022-06-18 09:22:40.233299
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": sys.path}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "sys.path" in [c.name for c in completions]
    else:
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": sys.path}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "sys.path" in [c.name for c in completions]

# Generated at 2022-06-18 09:22:45.619427
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # up to jedi 0.17
        assert get_interpreter_completions("import os; os.", [{}])[0].name == "path"
    else:
        # jedi 0.18
        assert get_interpreter_completions("import os; os.", [{}])[0].name == "path"

# Generated at 2022-06-18 09:22:56.387792
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Project
    from jedi.api.project import get_default_project
    from jedi.api.environment import get_system_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import find_virtualenvs
    from jedi.api.environment import find_system_environments
    from jedi.api.environment import find_environments
    from jedi.api.environment import find_virtualenv
    from jedi.api.environment import find_system_environment

# Generated at 2022-06-18 09:23:06.705432
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest

    class Test(unittest.TestCase):
        def test_get_script_completions(self):
            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_script_completions("import sys", 0, 0, ""),
                    [],
                    "get_script_completions should return empty list for older jedi versions",
                )

# Generated at 2022-06-18 09:23:10.776971
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("", 0, 0, "") == []
    else:
        assert get_script_completions("", 0, 0, "") == jedi.Script("").complete()



# Generated at 2022-06-18 09:23:15.494918
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.ap", 0, 0, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"



# Generated at 2022-06-18 09:23:25.689118
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.keywords import KeywordName

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.executable}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:23:29.329850
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join('')"
        row = 1
        column = 12
        filename = "test.py"
        script = jedi.Script(source, row, column, filename)
        definitions = script.goto_definitions()
        assert len(definitions) == 1
        assert definitions[0].name == "join"
        assert definitions[0].type == "function"
        assert definitions[0].description == "join(a, *p) -> path\n\nJoin two or more pathname components, inserting '/' as needed.\nIf any component is an absolute path, all previous path components\nwill be discarded.  An empty last part will result in a path that\nends with a separator."

# Generated at 2022-06-18 09:23:33.263187
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:23:43.694279
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Get the path of the current file
            current_path = os.path.dirname(os.path.realpath(__file__))
            # Get the path of the test file
            test_file_path = os.path.join(current_path, "test_get_definitions.py")
            # Get the path of the test file
            test_file_path_2 = os.path.join(current_path, "test_get_definitions_2.py")
            # Get the path of the test file

# Generated at 2022-06-18 09:24:30.134509
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import jedi
    import parso
    import sys
    import os

    if _using_older_jedi(jedi):
        script = Script("import sys", 1, 1, "test.py")
        completions = script.completions()
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter. It is always available."
        assert completions[0].parent == parso.python.tree.Module
        assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:24:35.611159
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path"
        namespaces = [{"sys": sys}]
    else:
        source = "import sys\nsys.path"
        namespaces = [{"sys": sys}]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "attribute"
    assert completions[0].description == "List of strings that specifies the search path for modules. Initialized from the environment variable PYTHONPATH, plus an installation-dependent default."
    assert completions[0].parent == "sys"

# Generated at 2022-06-18 09:24:39.969780
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import os; os.path.", 0, 0, "") == []
    else:
        assert get_script_completions("import os; os.path.", 0, 0, "") == []



# Generated at 2022-06-18 09:24:43.558070
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"

# Generated at 2022-06-18 09:24:45.781970
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import parso
    import sys

    if _using_older_jedi(jedi):
        return


# Generated at 2022-06-18 09:24:50.445873
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os; os.", 0, 0, "")
    assert completions == []

    completions = get_script_completions("import os; os.", 1, 8, "")
    assert completions == []

    completions = get_script_completions("import os; os.", 1, 9, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import os; os.", 1, 10, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)

    completions = get_script_completions("import os; os.", 1, 11, "")
   

# Generated at 2022-06-18 09:25:00.123109
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position

    source = "import sys\nsys.path.append('/tmp')\n"
    script = Script(source, 1, len("sys.path.append('"), "test.py")
    completions = script.completions()
    assert len(completions) == 1
    assert completions[0].name == "append"
    assert completions[0].complete == "append"
    assert completions[0].type == "function"
    assert completions[0].description == "append(${1:object}[, /])"
    assert completions[0].parent.name == "path"
    assert completions[0].parent.parent.name == "sys"


# Generated at 2022-06-18 09:25:09.690110
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"

# Generated at 2022-06-18 09:25:20.293510
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import InterpreterDefinition
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import InterpreterName
    from jedi.api.classes import InterpreterFunction
    from jedi.api.classes import InterpreterClass
    from jedi.api.classes import InterpreterInstance
    from jedi.api.classes import InterpreterModule
    from jedi.api.classes import InterpreterStatement
    from jedi.api.classes import Interpreter

# Generated at 2022-06-18 09:25:22.221709
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    from parso.python import tree
    from parso.python.tree import Leaf


# Generated at 2022-06-18 09:26:08.504149
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.context import ContextSet, ClassContext
    from jedi.evaluate.context.instance import CompiledInstance
    from jedi.evaluate.context.function import FunctionExecutionContext
    from jedi.evaluate.context.module import ModuleContext
    from jedi.evaluate.context.instance import BoundMethod
    from jedi.evaluate.context.klass import ClassContext
    from jedi.evaluate.context.instance import BoundMethod
    from jedi.evaluate.context.function import FunctionExecutionContext
    from jedi.evaluate.context.instance import CompiledInstance

# Generated at 2022-06-18 09:26:16.430895
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    namespaces = [{"a": 1, "b": 2}]
    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"
    assert completions[0].parent == "int"
    assert completions[0].full_name == "int"

    completions = get_interpreter_completions("a.b", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "b"
    assert completions[0].complete == "b"
   

# Generated at 2022-06-18 09:26:25.152481
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment

    source = "import sys\n"
    row = 2
    column = 1
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6/"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."

# Generated at 2022-06-18 09:26:34.198710
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.compiled.access import get_string_value
    from jedi.evaluate.compiled.value import CompiledValue
    from jedi.evaluate.compiled.context import CompiledContext
    from jedi.evaluate.compiled.subprocess import CompiledSubprocess
    from jedi.evaluate.compiled.value import CompiledObject
    from jedi.evaluate.compiled.value import CompiledValueSet
    from jedi.evaluate.compiled.value import CompiledName
    from jedi.evaluate.compiled.value import CompiledValueName

# Generated at 2022-06-18 09:26:38.915779
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "version"

    # Test with sys_path
    completions = get_interpreter_completions(source, namespaces, sys_path=["/tmp"])
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "version"

# Generated at 2022-06-18 09:26:45.742490
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import Source
    from jedi.api.classes import Module
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement
    from jedi.api.classes import Keyword
    from jedi.api.classes import Param
    from jedi.api.classes import ImportName
    from jedi.api.classes import ImportPath
    from jedi.api.classes import ImportStatement

# Generated at 2022-06-18 09:26:46.249615
# Unit test for function get_definitions

# Generated at 2022-06-18 09:26:50.164267
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # up to jedi 0.17
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys"
    else:
        # jedi 0.18
        assert get_interpreter_completions("import sys; sys.", [{}])[0].name == "sys="

# Generated at 2022-06-18 09:26:59.268649
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = """
import sys
sys.path.append("/home/user/my_module")
import my_module
my_module.
"""
    completions = get_interpreter_completions(source, [])
    assert len(completions) == 1
    assert completions[0].name == "my_module"
    assert completions[0].complete == "my_module"
    assert completions[0].type == "module"
    assert completions[0].description == "my_module"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.my_module"



# Generated at 2022-06-18 09:27:07.867454
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    from thonny.misc import running_on_mac_os

    if running_on_mac_os():
        sys.path.append("/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7")
    else:
        sys.path.append("/usr/lib/python2.7")

    source = """
import os
os.path.join("a", "b")
"""

    defs = get_definitions(source, 3, 8, os.path.join(os.getcwd(), "test.py"))
    assert len(defs) == 1
    assert defs[0].module_name == "posixpath"
    assert defs[0].line == 1
    assert defs[0].column == 0
   