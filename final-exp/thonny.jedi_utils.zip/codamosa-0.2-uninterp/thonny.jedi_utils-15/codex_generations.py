

# Generated at 2022-06-18 09:18:10.482428
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    def get_definitions_test(source, row, column, filename):
        return get_definitions(source, row, column, filename)

    def get_definitions_jedi(source, row, column, filename):
        script = jedi.Script(source, row, column, filename)
        return script.goto_definitions()

    def get_definitions_jedi_new(source, row, column, filename):
        script = jedi.Script(code=source, path=filename)
        return script.infer(line=row, column=column)


# Generated at 2022-06-18 09:18:20.057389
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # TODO: test with older jedi
        pass
    else:
        completions = get_interpreter_completions("import sys; sys.", [], sys_path=["."])
        assert len(completions) > 0
        assert any(c.name == "path" for c in completions)
        assert any(c.name == "stdin" for c in completions)
        assert any(c.name == "stdout" for c in completions)
        assert any(c.name == "stderr" for c in completions)
        assert any(c.name == "version" for c in completions)
        assert any(c.name == "version_info" for c in completions)

# Generated at 2022-06-18 09:18:32.004278
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.helpers import ThonnyCompletion
    import jedi

    source = "import os\nos.path.join('')"
    row = 2
    column = 16
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:18:42.580672
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    def get_completions(source, row, column, filename):
        return get_script_completions(source, row, column, filename)

    def get_completions_with_sys_path(source, row, column, filename, sys_path):
        return get_script_completions(source, row, column, filename, sys_path)

    def get_completions_with_jedi(source, row, column, filename):
        script = Script(source, row, column, filename)
        return script.completions()


# Generated at 2022-06-18 09:18:53.446743
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys\nsys.", 1, 5, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.", 1, 6, "")
    assert completions == [Completion("sys", "sys", "module", "", "", "sys")]

    completions = get_script_completions("import sys\nsys.pa", 1, 8, "")
    assert completions == [Completion("path", "path", "module", "", "sys", "sys.path")]

    completions = get_script_completions

# Generated at 2022-06-18 09:18:56.155539
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import os", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "os"



# Generated at 2022-06-18 09:19:07.800470
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def _get_completions_old(source, row, column, filename, sys_path=None):
        import jedi

        script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        return script.completions()

    def _get_completions_new(source, row, column, filename, sys_path=None):
        import jedi

        script = jedi.Script(code=source, path=filename, project=_get_new_jedi_project(sys_path))


# Generated at 2022-06-18 09:19:10.174560
# Unit test for function get_definitions
def test_get_definitions():
    import unittest


# Generated at 2022-06-18 09:19:22.466452
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = """
    import sys
    sys.
    """
    script = Script(source, 1, 5)
    completions = get_script_completions(script)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"


# Generated at 2022-06-18 09:19:33.014403
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\n"
    namespaces = [{"os": os}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "os"
    assert completions[0].complete == "os"
    assert completions[0].type == "module"
    assert completions[0].description == "os"
    assert completions[0].parent == "module"
    assert completions[0].full_name == "os"

    source = "import os\nos."

# Generated at 2022-06-18 09:19:51.302315
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetInterpreterCompletions(unittest.TestCase):
        def test_get_interpreter_completions(self):
            # Test that the function get_interpreter_completions returns the same completions as
            # jedi.Interpreter.complete()
            # This test is only valid for jedi versions 0.17 and 0.18
            if _using_older_jedi(jedi):
                return
            # Get the path to the test file
            test_file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_interpreter_completions.py"
            )
            # Get the source of the test file
           

# Generated at 2022-06-18 09:20:02.575514
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi
    import sys

    class Test(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys"
            namespaces = [{"sys": sys}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")
            self.assertEqual(completions[0].complete, "sys")
            self.assertEqual(completions[0].type, "module")
            self.assertEqual(completions[0].description, "sys")
            self.assertEqual(completions[0].parent, None)
            self.assertE

# Generated at 2022-06-18 09:20:11.754727
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = """
            def foo():
                pass
            foo()
            """
            row = 3
            column = 5
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 4)
            self.assertEqual(definitions[0].module_path, filename)
            self.assertEqual(definitions[0].type, "function")
            self.assertEqual(definitions[0].full_name, "foo")

# Generated at 2022-06-18 09:20:21.995445
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Definition
    from jedi.api.classes import Name
    from jedi.api.classes import Module
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import Param
    from jedi.api.classes import KeywordArgument
    from jedi.api.classes import InstanceElement
    from jedi.api.classes import ClassMethod
    from jedi.api.classes import ClassField
    from jedi.api.classes import ClassVar
    from jedi.api.classes import FunctionExecution
    from jedi.api.classes import Anonymous

# Generated at 2022-06-18 09:20:30.162615
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)
    else:
        source = "import sys\n"
        namespaces = [{"sys": sys}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert any(c.name == "sys" for c in completions)


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-18 09:20:40.358397
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Definition

    defs = get_definitions("import os\nos.path.join", 0, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)
    assert defs[0].module_name == "os"
    assert defs[0].line == 1
    assert defs[0].column == 0
    assert defs[0].module_path == jedi.__file__.replace("__init__.py", "") + "os.py"

    defs = get_definitions("import os\nos.path.join", 1, 0, "")
    assert len(defs) == 1
    assert isinstance(defs[0], Definition)

# Generated at 2022-06-18 09:20:44.339256
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys="

# Generated at 2022-06-18 09:20:48.881005
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:20:50.493960
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position


# Generated at 2022-06-18 09:20:51.095360
# Unit test for function get_definitions

# Generated at 2022-06-18 09:21:14.832806
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_default_environment
    from jedi.api.settings import jedi_path
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment
    from jedi.api.environment import get_cached_default_environment

# Generated at 2022-06-18 09:21:25.913965
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import InterpreterEnvironment
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_path

# Generated at 2022-06-18 09:21:35.851178
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.", 0, 0, "")
    assert completions == [
        ThonnyCompletion(
            name="sys",
            complete="sys",
            type="module",
            description="The Python interpreter.",
            parent=None,
            full_name="sys",
        )
    ]

    completions = get_script_completions("import sys; sys.", 0, 0, "", sys_path=["/"])
    assert completions == [
        ThonnyCompletion(
            name="sys",
            complete="sys",
            type="module",
            description="The Python interpreter.",
            parent=None,
            full_name="sys",
        )
    ]

    completions = get_script_com

# Generated at 2022-06-18 09:21:36.964316
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:21:37.957345
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:21:43.486631
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "test.py")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:21:54.627712
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    def get_names(completions):
        return [c.name for c in completions]

    def get_completions(source, namespaces):
        return get_interpreter_completions(source, namespaces)

    # test basic completions
    assert get_names(get_completions("", [{}])) == get_names(get_script_completions("", 1, 1, ""))

    # test namespaces
    assert "a" in get_names(get_completions("", [{"a": 1}]))
    assert "a" in get_names(get_completions("", [{"a": 1}, {}]))
    assert "a" not in get

# Generated at 2022-06-18 09:22:03.245852
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # jedi 0.17
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].name == "path"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].complete == "path"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].type == "list"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].description == "list"
        assert get_interpreter_completions("import sys; sys.path", [], [])[0].parent == "sys"

# Generated at 2022-06-18 09:22:04.084573
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:22:13.982603
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:22:34.566057
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Interpreter

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == Interpreter(source, namespaces)
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:22:44.237012
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert completions == [
        ThonnyCompletion(name="sys", complete="sys", type="module", description="", parent=None, full_name="sys")
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "")

# Generated at 2022-06-18 09:22:55.230883
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import os\n"
    namespaces = [{'os': os}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == len(get_names_of_scope(Interpreter(source, namespaces).namespace))

    source = "import os\nos."
    namespaces = [{'os': os}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == len(get_names_of_scope(Interpreter(source, namespaces).namespace))


# Generated at 2022-06-18 09:23:05.550601
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].name == "sys"
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].complete == "sys"
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].type == "module"
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].description == "sys"
        assert get_script_completions("import sys\nsys.", 1, 5, "")[0].parent == "sys"

# Generated at 2022-06-18 09:23:15.539348
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project

    def _get_completions(source, row, column, filename, sys_path):
        return get_script_completions(source, row, column, filename, sys_path)

    # test for older jedi
    def _get_completions_old(source, row, column, filename, sys_path):
        return get_script_completions(source, row, column, filename, sys_path)

    # test for newer jedi
    def _get_completions_new(source, row, column, filename, sys_path):
        return get_script_completions(source, row, column, filename, sys_path)

    # test for older jedi

# Generated at 2022-06-18 09:23:24.946294
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "version" in [c.name for c in completions]
    else:
        source = "import sys\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert "version" in [c.name for c in completions]

# Generated at 2022-06-18 09:23:32.627207
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    # Get the path of the current file
    path = os.path.dirname(os.path.abspath(__file__))

    # Get the path of the test file
    test_file = os.path.join(path, "test_get_definitions.py")

    # Get the source code of the test file
    with open(test_file, "r") as f:
        source = f.read()

    # Get the definitions
    definitions = get_definitions(source, 1, 1, test_file)

    # Check the number of definitions
    assert len(definitions) == 1

    # Check the type of the definition
    assert definitions[0].type == "module"

    # Check the path of the definition
    assert definitions[0].module_path == test_

# Generated at 2022-06-18 09:23:43.157577
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 1, 5, "")
    assert completions == [
        Completion(name="sys", complete="sys", type="module", description="", parent="", full_name="sys"),
    ]

    completions = get_script_completions("import sys\nsys.path.", 1, 11, "")
    assert completions == [
        Completion(name="path", complete="path", type="module", description="", parent="sys", full_name="sys.path"),
    ]

    completions = get_script_completions("import sys\nsys.path.append(", 1, 19, "")

# Generated at 2022-06-18 09:23:45.695460
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions, list)
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"



# Generated at 2022-06-18 09:23:55.137002
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 8, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"

    completions = get_script_completions("import sys\nsys.", 1, 4, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert comple

# Generated at 2022-06-18 09:24:13.107123
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = """
import os
os.path.join("a", "b")
"""
    completions = get_interpreter_completions(source, [])
    assert len(completions) > 0
    assert "join" in [c.name for c in completions]
    assert "join" in [c.complete for c in completions]

# Generated at 2022-06-18 09:24:23.664841
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_script_completions(self):
            source = "import sys\nsys.path.ap"
            completions = get_script_completions(source, 2, 14, "test.py")
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "append")
            self.assertEqual(completions[0].complete, "append")
            self.assertEqual(completions[0].type, "function")
            self.assertEqual(completions[0].description, "append(object)")
            self.assertEqual(completions[0].parent, "list")

# Generated at 2022-06-18 09:24:32.523434
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def test_get_script_completions(self):
            # Test if the function get_script_completions returns the same
            # completions as the jedi.Script.completions() function
            # for the same source code
            source = "import sys\n"
            row = 1
            column = 7
            filename = "test.py"
            sys_path = [os.path.dirname(sys.executable)]
            completions = get_script_completions(source, row, column, filename, sys_path)
            script = jedi.Script(source, row, column, filename, sys_path=sys_path)
            script_completions = script

# Generated at 2022-06-18 09:24:42.262879
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import get_script_completions

    completions = get_script_completions("import sys\nsys.pa", 3, 10, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "path"

    completions = get_script_completions("import sys\nsys.path.ap", 3, 14, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "append"

    completions = get_script_completions("import sys\nsys.path.append(", 3, 21, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "path"

    completions = get_script_complet

# Generated at 2022-06-18 09:24:51.735314
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            test_file = os.path.join(os.path.dirname(__file__), "test_get_definitions.py")
            with open(test_file, "r") as f:
                source = f.read()
            definitions = get_definitions(source, 1, 1, test_file)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 4)
            self.assertEqual(definitions[0].module_path, test_file)


# Generated at 2022-06-18 09:25:01.218082
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    if _using_older_jedi(jedi):
        print("Older jedi")
        interpreter = jedi.Interpreter("import os", [{"os": os}])
        completions = interpreter.completions()
    else:
        print("Newer jedi")
        interpreter = jedi.Interpreter("import os", [{"os": os}])
        completions = interpreter.complete()

    for completion in completions:
        print(completion.name)

    if _using_older_jedi(jedi):
        print("Older jedi")
        interpreter = jedi.Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
    else:
        print("Newer jedi")

# Generated at 2022-06-18 09:25:10.857449
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.api.classes import Completion

    source = "import math\nmath.cos"
    namespaces = [{"math": math}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "cos"
    assert completions[0].complete == "cos"
    assert completions[0].type == "function"
    assert completions[0].description == "cos(x)\n\nReturn the cosine of x (measured in radians)."
    assert completions[0].parent == "math"
    assert completions[0].full_name == "math.cos"



# Generated at 2022-06-18 09:25:16.386584
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:25:20.962722
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_get_script_completions(self):
            from jedi.api.classes import Completion

            completions = get_script_completions("import sys", 0, 7, "")
            self.assertTrue(all(isinstance(c, Completion) for c in completions))

    Test().test_get_script_completions()

# Generated at 2022-06-18 09:25:29.639656
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import NameWrapper
    from jedi.api.classes import Completion
    from jedi.api.classes import Definition
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement


# Generated at 2022-06-18 09:25:59.984528
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.", 0, 0, "") == []
        assert get_script_completions("import sys; sys.", 1, 10, "") == []
        assert get_script_completions("import sys; sys.", 1, 11, "") == []
        assert get_script_completions("import sys; sys.", 1, 12, "") == []
        assert get_script_completions("import sys; sys.", 1, 13, "") == []
        assert get_script_completions("import sys; sys.", 1, 14, "") == []
        assert get_script_completions("import sys; sys.", 1, 15, "") == []

# Generated at 2022-06-18 09:26:10.165990
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys
    import unittest


# Generated at 2022-06-18 09:26:16.841630
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            source = "import sys\n"
            namespaces = [{"name": "sys", "path": sys.executable}]
            completions = get_interpreter_completions(source, namespaces)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "sys")
            self.assertEqual(completions[0].complete, "sys")
            self.assertEqual(completions[0].type, "module")

# Generated at 2022-06-18 09:26:25.714544
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    import unittest
    from thonny.plugins.jedi_utils import get_definitions

    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(test_dir, "test_jedi_utils.py")
    with open(test_file) as fp:
        source = fp.read()

    defs = get_definitions(source, row=1, column=1, filename=test_file)
    assert len(defs) == 1
    assert defs[0].module_path == test_file
    assert defs[0].line == 1
    assert defs[0].column == 1
    assert defs[0].description == "test_get_definitions"

    defs

# Generated at 2022-06-18 09:26:29.758481
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("", 0, 0, "") == []
    else:
        assert get_script_completions("", 0, 0, "") == jedi.Script("", 0, 0, "").complete()

# Generated at 2022-06-18 09:26:37.321151
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.evaluate.compiled.access import CompiledObject

    class MockInterpreter(Interpreter):
        def __init__(self, source, namespaces):
            self.source = source
            self.namespaces = namespaces


# Generated at 2022-06-18 09:26:42.307414
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.names import Name
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import NameWrapper
    from jedi.api.classes import Completion
    from jedi.api.classes import Definition
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Instance
    from jedi.api.classes import Statement


# Generated at 2022-06-18 09:26:42.754294
# Unit test for function get_definitions

# Generated at 2022-06-18 09:26:50.058560
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    source = "import sys\n"
    namespaces = [{"sys": sys}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

    source = "import sys\nsys."

# Generated at 2022-06-18 09:27:00.385334
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.join('')"
        namespaces = [{"name": "sys", "path": "/home/user/"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "os"
        assert completions[0].complete == "os"
        assert completions[0].type == "module"
        assert completions[0].description == "os"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys.os"

# Generated at 2022-06-18 09:27:53.018443
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    namespaces = [{"name": "sys", "path": sys.executable}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert "sys" in [c.name for c in completions]
    assert "sys" in [c.complete for c in completions]
    assert "sys" in [c.full_name for c in completions]