

# Generated at 2022-06-18 09:18:15.840585
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Definition
    from jedi.api.classes import Script
    from jedi.api.classes import Project
    from jedi.api.classes import Namespace
    from jedi.api.classes import Source
    from jedi.api.classes import Name
    from jedi.api.classes import Flow
    from jedi.api.classes import Class
    from jedi.api.classes import Function
    from jedi.api.classes import Statement
    from jedi.api.classes import KeywordStatement
    from jedi.api.classes import ImportStatement
    from jedi.api.classes import ImportFromStatement
    from jedi.api.classes import CompForStatement
    from jedi.api.classes import CompIfStatement

# Generated at 2022-06-18 09:18:27.531568
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    assert get_script_completions("", 1, 1, "") == []

    completions = get_script_completions("import sys", 1, 1, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "sys"

    completions = get_script_com

# Generated at 2022-06-18 09:18:31.217916
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_content = open(self.test_file).read()

        def test_get_definitions(self):
            if _using_older_jedi(jedi):
                script = jedi.Script(self.test_file_content, 1, 1, self.test_file)
                definitions = script.goto_definitions()

# Generated at 2022-06-18 09:18:41.983446
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Test for jedi version 0.16.0
            if _using_older_jedi(jedi):
                with patch.object(jedi, "__version__", "0.16.0"):
                    source = "import os\nimport sys\n"
                    row = 1
                    column = 1
                    filename = "test.py"
                    definitions = get_definitions(source, row, column, filename)
                    self.assertEqual(definitions[0].name, "os")
                    self.assertEqual(definitions[1].name, "sys")
                    self.assertEqual

# Generated at 2022-06-18 09:18:52.827777
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.join('/home/user/', 'a')"
    namespaces = [{"type": "module", "name": "os", "path": "/usr/lib/python3.6/os.py"}]

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"
    assert completions[0].description == "os.path"
    assert completions[0].parent == "os"
    assert completions[0].full_name == "os.path"

   

# Generated at 2022-06-18 09:18:58.698077
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    from thonny.plugins.jedi_utils import ThonnyCompletion
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import sys\n"
    completions = get_script_completions(source, 1, 0, "")
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "builtins"
    assert completions[0].full

# Generated at 2022-06-18 09:19:08.157379
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\nos.path.join('')"
        namespaces = [{}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "join"
    else:
        source = "import os\nos.path.join('')"
        namespaces = [{}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "join"

# Generated at 2022-06-18 09:19:19.474998
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi import Script
    import jedi
    import os
    import sys

    # Test for jedi 0.18.0
    if _using_older_jedi(jedi):
        return

    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for jedi 0.18.0
    # Test for j

# Generated at 2022-06-18 09:19:31.218787
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names_of_scope_stmt
    from jedi.api.helpers import get_names_of_scope_function
    from jedi.api.helpers import get_names_of_scope_class
    from jedi.api.helpers import get_names_of_scope_module
    from jedi.api.helpers import get_names_of_scope_instance
    from jedi.api.helpers import get_names_of_scope_generator
    from jedi.api.helpers import get_names_of_scope_comp_

# Generated at 2022-06-18 09:19:41.997606
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    import jedi

    if _using_older_jedi(jedi):
        script = Script("import sys; sys.pa", 3, len("sys.pa"), "test.py")
        completions = script.completions()
    else:
        script = Script(code="import sys; sys.pa", path="test.py")
        completions = script.complete(line=3, column=len("sys.pa"))

    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].type == "module"
    assert completions[0].description == "sys.path"
    assert completions[0].parent == "sys"
    assert completions[0].full_name

# Generated at 2022-06-18 09:19:55.172325
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.helpers import get_definitions
    from jedi.api.classes import Definition

    source = """
    def foo():
        pass
    foo()
    """
    definitions = get_definitions(source, 3, 4)
    assert len(definitions) == 1
    assert isinstance(definitions[0], Definition)
    assert definitions[0].line == 1
    assert definitions[0].column == 4

# Generated at 2022-06-18 09:20:06.761800
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    source = "import test_jedi_utils; test_jedi_utils.test_get_interpreter_completions()"
    namespaces = [{"a": 1, "b": 2}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == "test_get_interpreter_completions"
    assert completions[0].type == "function"
    assert completions[0].description == "test_get_interpreter_completions()"
    assert completions[0].parent == "test_jedi_utils"


# Generated at 2022-06-18 09:20:13.327817
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_path = os.path.dirname(self.test_file)
            self.test_file_name = os.path.basename(self.test_file)
            self.test_file_content = open(self.test_file).read()


# Generated at 2022-06-18 09:20:23.554453
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.", 1, 11, "")[0].name == "sys"
        assert get_script_completions("import sys; sys.", 1, 11, "")[0].complete == "sys"
        assert get_script_completions("import sys; sys.", 1, 11, "")[0].type == "module"
        assert get_script_completions("import sys; sys.", 1, 11, "")[0].description == "sys"
        assert get_script_completions("import sys; sys.", 1, 11, "")[0].parent == "sys"

# Generated at 2022-06-18 09:20:31.533029
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_definitions.py"
            )
            self.test_file_path_2 = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_definitions_2.py"
            )

# Generated at 2022-06-18 09:20:41.195001
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = "import sys\nsys.path.append('/home/user/')\nimport os\nos.path.join('/home/user/', 'test')"

# Generated at 2022-06-18 09:20:50.583613
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    def get_names(completions):
        return [c.name for c in completions]

    # Test for jedi 0.16

# Generated at 2022-06-18 09:21:00.924998
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project

    source = "import sys\nsys.path.append('/home/user/')\n"
    namespaces = [{'sys': sys}]
    sys_path = ['/home/user/']
    interpreter = Interpreter(source, namespaces, sys_path=sys_path)
    completions = interpreter.completions()
    assert completions[0].name == 'path'
    assert completions[0].complete == 'path'
    assert completions[0].type == 'module'
    assert completions[0].description == 'sys.path'
    assert completions[0].parent == 'sys'

# Generated at 2022-06-18 09:21:11.344219
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    def get_completions(source, namespaces):
        return get_interpreter_completions(source, namespaces)

    # Test 1
    source = "import os\nos.path.join('')"
    namespaces = [{"os": __import__("os")}]
    completions = get_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "join"
    assert completions[0].complete == "join"
    assert completions[0].type == "function"

# Generated at 2022-06-18 09:21:24.097765
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.interpreter import Interpreter
    from jedi.api.project import Project
    from jedi.api.environment import get_system_environment
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_contexts
    from jedi.api.helpers import get_cached_value
    from jedi.api.helpers import get_cached_value_default
    from jedi.api.helpers import get_cached_value_setdefault
    from jedi.api.helpers import get_cached_value_del
    from jedi.api.helpers import get_cached_value_pop
   

# Generated at 2022-06-18 09:21:40.928245
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys

    sys.path.append(os.path.dirname(__file__))
    source = "from test_jedi_utils import test_get_definitions\ntest_get_definitions()"
    row = 2
    column = 5
    filename = "test_jedi_utils.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1
    assert definitions[0].line == test_get_definitions.__code__.co_firstlineno
    assert definitions[0].column == 0
    assert definitions[0].module_path == os.path.abspath(__file__)

# Generated at 2022-06-18 09:21:51.764424
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api import Script
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_cached_value
    from jedi.api.helpers import get_module_context
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get_module_paths
    from jedi.api.helpers import get_script_path
    from jedi.api.helpers import get_sys_path
    from jedi.api.helpers import get_time_stamp
    from jedi.api.helpers import set_debug_function
    from jedi.api.helpers import set_script_path
    from jedi.api.helpers import set_sys_path
    from jedi.api.helpers import set_time_function


# Generated at 2022-06-18 09:22:01.293504
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.source import Source
    from jedi.api.script import Script
    from jedi.api.references import get_references
    from jedi.api.helpers import get_call_signatures
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_names
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.helpers import get_module_names
    from jedi.api.helpers import get

# Generated at 2022-06-18 09:22:11.373061
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys; sys.path.ap", 0, 0, "")
    assert len(completions) == 1
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "append"
    assert completions[0].complete == "append"
    assert completions[0].type == "statement"
    assert completions[0].description == "append(${1:object}[, /])"
    assert completions[0].parent == "list"
    assert completions[0].full_name == "list.append"

    completions = get_script_completions("import sys; sys.path.ap", 0, 0, "", sys_path=["/tmp"])

# Generated at 2022-06-18 09:22:15.264140
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.", 0, 15, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys; sys.", 0, 15, "")[0].name == "sys."

# Generated at 2022-06-18 09:22:16.052482
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:22:25.378345
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    import jedi

    source = "import sys\n"
    row = 2
    column = 1
    filename = "test.py"
    sys_path = ["/usr/lib/python3.6"]

    completions = get_script_completions(source, row, column, filename, sys_path)
    assert completions == [
        ThonnyCompletion(
            name="sys",
            complete="sys",
            type="module",
            description="This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter.",
            parent=None,
            full_name="sys",
        )
    ]

    if _using_older_jedi(jedi):
        source = "import sys\nsys."
        row = 2
       

# Generated at 2022-06-18 09:22:34.821149
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.helpers import get_names_of_scope
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import InterpreterEnvironment
    from jedi.api.settings import settings
    from jedi.api.parser import load_grammar
    from jedi.parser.python import ParserWithRecovery
    from jedi.parser.python.tree import Module
    from jedi.parser.python.tokenize import Tokenizer
    from jedi.parser.python.token import Token
    from jedi.parser.python.tokenize import PythonToken
    from jedi.parser.python.tokenize import PythonTokenType
    from jedi.parser.python.tokenize import PythonToken

# Generated at 2022-06-18 09:22:44.512994
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import sys
    import os
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            source = """
            def foo():
                pass

            foo()
            """
            row = 4
            column = 1
            filename = "test.py"
            definitions = get_definitions(source, row, column, filename)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].line, 1)
            self.assertEqual(definitions[0].column, 4)
            self.assertEqual(definitions[0].module_path, os.path.abspath(filename))


# Generated at 2022-06-18 09:22:55.497086
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\n"
    source += "sys.path.ap"
    completions = get_script_completions(source, 2, 12, "test.py")
    assert completions == [Completion(name="append", complete="append", type="function", description="append(${1:object}, /)")]

    source = "import sys\n"
    source += "sys.path.appen"
    completions = get_script_completions(source, 2, 13, "test.py")
    assert completions == [Completion(name="append", complete="append", type="function", description="append(${1:object}, /)")]


# Generated at 2022-06-18 09:23:06.542953
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import os\nos.", 1, 4, "")[0].name == "path"
    else:
        assert get_script_completions("import os\nos.", 1, 4, "")[0].name == "path"

# Generated at 2022-06-18 09:23:16.488906
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "os"
        assert completions[0].complete == "os"
        assert completions[0].type == "module"
        assert completions[0].description == "os"
        assert completions[0].parent is None
        assert completions[0].full_name == "os"
    else:
        source = "import os\n"
        namespaces = [{"os": os}]
        completions = get_interpreter_completions(source, namespaces)
        assert len

# Generated at 2022-06-18 09:23:26.575334
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment

    source = "import sys; sys.path.append('/home/user/my_module'); import my_module; my_module."
    row = 4
    column = len(source)
    filename = "test.py"
    sys_path = ["/home/user/my_module"]
    completions = get_script_completions(source, row, column, filename, sys_path)
    assert len(completions) == 1
    assert completions[0].name == "my_func"
    assert completions[0].complete == "my_func"

# Generated at 2022-06-18 09:23:33.575377
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        source = "import sys\nsys.path.append('')\n"
        namespaces = [{"name": "sys", "path": "sys"}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) > 0
        assert completions[0].name == "path"
        assert completions[0].complete == "path"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent == "sys"
        assert completions[0].full_name == "sys.path"
    else:
        source = "import sys\nsys.path.append('')\n"

# Generated at 2022-06-18 09:23:37.336483
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 6, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:23:46.651855
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import _get_script_completions_0_18
    from thonny.plugins.jedi_backend import _get_script_completions_0_17
    from thonny.plugins.jedi_backend import _get_script_completions_0_16
    from thonny.plugins.jedi_backend import _get_script_completions_0_15
    from thonny.plugins.jedi_backend import _get_script_completions_0_14
    from thonny.plugins.jedi_backend import _get_script_completions_0_13
    from thonny.plugins.jedi_backend import _get_script_completions_0_12

# Generated at 2022-06-18 09:23:56.660358
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Definition

    source = """
    class A:
        def __init__(self):
            self.x = 1
            self.y = 2
    a = A()
    a.x
    """
    row = 7
    column = 5
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)
    assert isinstance(definitions, list)
    assert len(definitions) == 1
    assert isinstance(definitions[0], Definition)
    assert definitions[0].line == 4
    assert definitions[0].column == 5
    assert definitions[0].module_path == filename
    assert definitions[0].type == "instance attribute"
    assert definitions[0].description == "x"
    assert definitions[0].full_name

# Generated at 2022-06-18 09:24:05.725119
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    sys.path.append(os.path.dirname(__file__))
    source = "import sys\nimport os\nimport math\nsys.path.append(os.path.dirname(__file__))\nimport test_utils\n"
    row = 5
    column = 5
    filename = "test_utils.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 1
    assert completions[0].name == "test_utils"
    assert completions[0].complete == "test_utils"
    assert completions[0].type == "module"
    assert completions[0].description == "Module test_utils"

# Generated at 2022-06-18 09:24:13.960129
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp"])
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"

    completions = get_script_completions("import sys", 0, 7, "", sys_path=["/tmp/non-existing"])
    assert isinstance(completions[0], Completion)

# Generated at 2022-06-18 09:24:24.492501
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions

    source = "import sys\n"
    row = 1
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert completions == [Completion(name="sys", complete="sys", type="module", description="sys", parent=None, full_name="sys")]

    source = "import sys\nsys.\n"
    row = 2
    column = 4
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)

# Generated at 2022-06-18 09:24:41.525789
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "test.py")
    assert completions == [
        Completion("sys", "sys", "module", "", "", "sys"),
    ]

    completions = get_script_completions("import sys\nsys.", 1, 4, "test.py")

# Generated at 2022-06-18 09:24:47.906018
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definitions(self):
            # Get the current directory
            dir_path = os.path.dirname(os.path.realpath(__file__))
            # Get the path of the file to be tested
            test_file_path = os.path.join(dir_path, "test_get_definitions.py")
            # Get the source code of the file to be tested
            with open(test_file_path, "r") as f:
                source = f.read()
            # Get the definitions of the function test_function
            definitions = get_definitions(source, 3, 4, test_file_path)
            # Check that the definitions are correct
            self

# Generated at 2022-06-18 09:24:58.572006
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion

    # Test for jedi 0.17
    namespaces = [{"a": 1, "b": 2}]
    source = "a"
    completions = get_interpreter_completions(source, namespaces)
    assert completions == [Completion("a", "a", "int", "int", "int", "a")]

    # Test for jedi 0.18
    namespaces = [{"a": 1, "b": 2}]
    source = "a"
    completions = get_interpreter_completions(source, namespaces)
    assert completions == [ThonnyCompletion("a", "a", "int", "int", "int", "a")]

# Generated at 2022-06-18 09:25:00.083094
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions

# Generated at 2022-06-18 09:25:04.593361
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"



# Generated at 2022-06-18 09:25:12.552958
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert isinstance(completions[0], Completion)
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent is None
    assert completions[0].full_name == "sys"



# Generated at 2022-06-18 09:25:22.882831
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_names_of_scope

    def get_completions(source, namespaces):
        return get_interpreter_completions(source, namespaces)

    def get_names(completions):
        return [c.name for c in completions]

    def get_names_of_scope(completions):
        return [c.parent().name for c in completions]

    # Test that completions are returned
    assert "int" in get_names(get_completions("int", []))

    # Test that completions are returned for namespaces
    assert "int" in get_names(get_completions("int", [{"int": int}]))

    # Test that completions are returned for namespaces

# Generated at 2022-06-18 09:25:24.209515
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso


# Generated at 2022-06-18 09:25:27.794739
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
    else:
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys="

# Generated at 2022-06-18 09:25:28.588185
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-18 09:25:45.819540
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "test_get_definitions.py"
            )

        def test_get_definitions(self):
            with open(self.test_file_path, "r") as f:
                source = f.read()
            definitions = get_definitions(source, 1, 1, self.test_file_path)
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_name, "test_get_definitions")
            self.assertE

# Generated at 2022-06-18 09:25:54.344199
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi
    import sys
    import os

    # Test for jedi 0.17
    if _using_older_jedi(jedi):
        interpreter = Interpreter("import sys", [{"sys": sys}])
        completions = interpreter.completions()
        assert len(completions) == 1
        assert completions[0].name == "sys"
        assert completions[0].complete == "sys"
        assert completions[0].type == "module"
        assert completions[0].description == "sys"
        assert completions[0].parent is None
        assert completions[0].full_name == "sys"

        interpreter = Interpreter("import sys; sys.path", [{"sys": sys}])
        completions = interpreter.completions()

# Generated at 2022-06-18 09:25:57.900019
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from jedi.api.helpers import get_definition_context
    from jedi.api.project import Project
    from jedi.api.environment import get_default_environment
    from jedi.api.interpreter import Interpreter
    from jedi.api.keywords import KeywordName
    from jedi.api.classes import Completion
    from jedi.api.classes import Function
    from jedi.api.classes import Class
    from jedi.api.classes import Module
    from jedi.api.classes import Statement
    from jedi.api.classes import Instance
    from jedi.api.classes import Param
    from jedi.api.classes import VarName
    from jedi.api.classes import Name
    from jedi.api.classes import Flow

# Generated at 2022-06-18 09:26:07.824490
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys", 0, 7, "")[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=[])[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=[""])[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=["/"])[0].name == "sys"
        assert get_script_completions("import sys", 0, 7, "", sys_path=["/", "/"])[0].name == "sys"
        assert get_script_completions

# Generated at 2022-06-18 09:26:11.133291
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys", 0, 7, "")
    assert len(completions) > 0
    assert isinstance(completions[0], Completion)



# Generated at 2022-06-18 09:26:18.163217
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetScriptCompletions(unittest.TestCase):
        def test_get_script_completions(self):
            source = "import sys\nimport os\nimport re\n"
            row = 3
            column = 6
            filename = "test.py"
            sys_path = [os.path.dirname(sys.executable)]
            completions = get_script_completions(source, row, column, filename, sys_path)
            self.assertEqual(len(completions), 2)
            self.assertEqual(completions[0].name, "re")
            self.assertEqual(completions[1].name, "random")


# Generated at 2022-06-18 09:26:27.420091
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree
    from parso.python.tree import ExprStmt, Name, Function, Class
    from parso.python.tree import ImportFrom, ImportName, Import, Module
    from parso.python.tree import KeywordStatement, ClassOrFunc
    from parso.python.tree import Flow, Statement, BaseNode
    from parso.python.tree import Leaf
    from parso.python.tree import Keyword, Operator, String, Number
    from parso.python.tree import Param, ParamName, ParamStar, ParamStarStar
    from parso.python.tree import Call, CallName, CallParam, CallStar, CallStarStar

# Generated at 2022-06-18 09:26:35.884657
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.classes import Completion

    source = "import sys\nimport os\nimport re\nimport math\nimport time\n"
    row = 6
    column = 0
    filename = "test.py"

    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 5
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "sys"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys"

    assert completions[1].name == "os"
    assert completions[1].complete

# Generated at 2022-06-18 09:26:41.301348
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    import os

    if _using_older_jedi(jedi):
        script = jedi.Script("import sys", 1, 7, "test.py")
        completions = script.completions()
    else:
        script = jedi.Script(code="import sys", path="test.py")
        completions = script.complete(line=1, column=7)

    assert len(completions) > 0
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == None
    assert completions

# Generated at 2022-06-18 09:26:48.353206
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Interpreter
    from jedi.api.classes import Completion
    from jedi.api.classes import Script
    from jedi.api.classes import Namespace
    from jedi.api.classes import Project
    from jedi.api.classes import InterpreterCompletion
    from jedi.api.classes import ScriptCompletion
    from jedi.api.classes import InterpreterNamespace
    from jedi.api.classes import ScriptNamespace
    from jedi.api.classes import ProjectNamespace
    from jedi.api.classes import InterpreterScript
    from jedi.api.classes import ScriptScript
    from jedi.api.classes import ProjectScript
    from jedi.api.classes import InterpreterProject
    from jedi.api.classes import ScriptProject

# Generated at 2022-06-18 09:27:03.421293
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_backend import jedi_utils


# Generated at 2022-06-18 09:27:07.271282
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("import sys; sys.pa", 1, 15, "")[0].name == "path"
    else:
        assert get_script_completions("import sys; sys.pa", 1, 15, "")[0].name == "path="

# Generated at 2022-06-18 09:27:16.034105
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi.api.classes import Completion
    from jedi.parser_utils import get_parent_scope
    import jedi

    source = "import sys\n"
    namespaces = [{"name": "__main__", "path": "<input>"}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 1
    assert completions[0].name == "sys"
    assert completions[0].complete == "sys"
    assert completions[0].type == "module"
    assert completions[0].description == "This module provides access to some objects used or maintained by the interpreter and to functions that interact strongly with the interpreter."
    assert completions[0].parent == "__main__"
   

# Generated at 2022-06-18 09:27:24.199932
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.project import Project

    def _get_completions(source, row, column, filename, sys_path=None):
        return get_script_completions(source, row, column, filename, sys_path)

    def _get_completion_names(completions):
        return [c.name for c in completions]

    def _get_completion_full_names(completions):
        return [c.full_name for c in completions]

    def _get_completion_completes(completions):
        return [c.complete for c in completions]

    def _get_completion_types(completions):
        return [c.type for c in completions]


# Generated at 2022-06-18 09:27:32.048261
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    def check(source, row, column, expected_completions):
        completions = get_script_completions(source, row, column, "test.py")
        assert [c.name for c in completions] == expected_completions

    check("import sys", 0, 7, ["sys"])
    check("import sys\nsys.", 1, 4, ["sys"])
    check("import sys\nsys.path", 1, 4, ["sys"])
    check("import sys\nsys.path.", 1, 11, ["path"])
    check("import sys\nsys.path.", 1, 12, ["path"])
    check("import sys\nsys.path.", 1, 13, ["path"])

# Generated at 2022-06-18 09:27:37.809693
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_jedi_utils.py")
            self.test_file_content = open(self.test_file).read()
            self.test_file_content_lines = self.test_file_content.split("\n")
            self.test_file_content_lines_length = len(self.test_file_content_lines)
            self.test_file_content_lines_length_

# Generated at 2022-06-18 09:27:45.069551
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    def _test(source, row, column, filename, sys_path=None):
        import jedi

        jedi.Script = Mock()
        jedi.Script.return_value.completions.return_value = [
            Mock(name="name1", complete="complete1", type="type1", description="desc1"),
            Mock(name="name2", complete="complete2", type="type2", description="desc2"),
        ]
        jedi.Script.return_value.infer.return_value = [
            Mock(name="name1", complete="complete1", type="type1", description="desc1"),
            Mock(name="name2", complete="complete2", type="type2", description="desc2"),
        ]


# Generated at 2022-06-18 09:27:49.695166
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    completions = get_script_completions("import sys\nsys.", 0, 7, "")

# Generated at 2022-06-18 09:27:56.044767
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    import sys
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.abspath(__file__))
            self.test_file = os.path.join(self.test_dir, "test_get_definitions.py")
            self.test_file_contents = open(self.test_file).read()
            self.test_file_lines = self.test_file_contents.splitlines()


# Generated at 2022-06-18 09:28:02.114233
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys
    import os
    import unittest

    class TestJediUtils(unittest.TestCase):
        def test_get_interpreter_completions(self):
            if _using_older_jedi(jedi):
                self.assertEqual(
                    get_interpreter_completions(
                        "import sys\nsys.path.append('" + os.path.dirname(__file__) + "')\nimport test_jedi_utils\ntest_jedi_utils.test_get_interpreter_completions()",
                        [{"name": "sys", "value": sys}],
                    ),
                    [],
                )