

# Generated at 2022-06-24 07:51:25.623134
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = 'for a in b: \n    print(a)'
    assert parse_source(source).get_code() == source
    source = 'if True: \n    print(a)'
    assert parse_source(source).get_code() == source
    source = 'if True: \nprint(a)'
    assert parse_source(source).get_code() == source


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:51:28.915849
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    class_name = "ThonnyCompletion"
    func_name = "__getitem__"
    str_keys = ["name", "complete", "type", "description", "parent", "full_name"]
    list_keys = ["__dict__"]



# Generated at 2022-06-24 07:51:29.768797
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:51:34.818902
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("your_name.", 8, 12, "dummy.py")
    assert len(completions) == 2
    assert completions[0].name == "__add__"
    assert completions[1].name == "__contains__"



# Generated at 2022-06-24 07:51:43.823063
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import pandas as pd # This is the module to test with.
    from jedi.parser_utils import get_statement_of_position # This will fail without the other test function.
    tree = parse_source("#df.iloc[:, 0]")
    interpreter = get_interpreter_completions("#df.iloc[:, 0].", list(pd.DataFrame()), sys_path = ["C:\\Program Files\\Anaconda3\\lib\\site-packages\\pandas"]) # This will fail without the function.
    completions = interpreter[3:]
    tree = parse_source("#df.iloc[:, 0].")
    resource = get_statement_of_position(tree, (1, 20))

# Generated at 2022-06-24 07:51:48.589401
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:51:59.737852
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import sys
    import parso
    import parso.python.tree
    from parso import parse

    sys.path.insert(0, "c:/Users/rhnvrm/Documents/thonny/thonny")
    import jedi
    import jedi.parser_utils

    from thonny.jedi_utils import get_statement_of_position as thonny_get_statement_of_position

    # test_file_name = "c:/Users/rhnvrm/Documents/thonny/thonny/backend_python/operations.py"
    test_file_name = "c:/Users/rhnvrm/Documents/thonny/thonny/backend_python/console.py"
    test_file = open(test_file_name, "r")

# Generated at 2022-06-24 07:52:06.825100
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    D = Dict
    completion = ThonnyCompletion(name="__name", complete="__complete", type="type", description="description", parent="parent", full_name="full_name")
    assert completion == {
        'name': '__name',
        'complete': '__complete',
        'type': 'type',
        'description': 'description',
        'parent': 'parent',
        'full_name': 'full_name'
    }

# Generated at 2022-06-24 07:52:10.544180
# Unit test for function parse_source
def test_parse_source():
    source = """\
        # test
        def some_func():
           pass
        """
    root = parse_source(source)
    func_node = root.children[1]
    assert func_node.get_code() == "def some_func():\n   pass"



# Generated at 2022-06-24 07:52:12.717241
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        return


# Generated at 2022-06-24 07:52:19.722523
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import ExprStmt

    node = parse_source("a = 1; b = 2; c = 3")
    result = get_statement_of_position(node, 7)
    assert isinstance(result, ExprStmt)
    assert result.start_pos == 2
    assert result.end_pos == 6

    result = get_statement_of_position(node, 9)
    assert isinstance(result, ExprStmt)
    assert result.start_pos == 8
    assert result.end_pos == 12

# Generated at 2022-06-24 07:52:26.797272
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    from tokenize import tokenize
    from io import BytesIO
    source = 'import re\nre.compile("asd")'
    tokens = [tok for tok in tokenize(BytesIO(source.encode("utf-8")).readline)]
    for i in range(1, len(tokens) - 2):
        token = tokens[i]
        row = token.start[0]
        column = token.start[1]
        definitions = get_definitions(source, row, column, "/test.py")
        if len(definitions) == 0:
            continue
        definition = definitions[0]
        assert definition.start_pos[0] == token.start[0]
        assert definition.start_pos[1] == token.start[1]
        assert definition.end_pos

# Generated at 2022-06-24 07:52:37.670587
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree

    module = parse_source(b"import os\ndef func(a, b):\n    pass\nprint(a)")
    assert isinstance(module, parso.python.tree.Module)
    assert len(module.children) == 5
    imports = module.children[0]
    assert imports.type == "import_from"
    assert imports.names[0].string == "os"
    assert imports.names[1].name == "import"
    assert imports.level == 0
    func_def = module.children[1]
    assert func_def.type == "funcdef"
    assert func_def.name.string == "func"
    print(func_def.children)
    assert func_def.children[0].type == "param"
    assert func_def.children

# Generated at 2022-06-24 07:52:46.174524
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    script = jedi.Script("from tkinter import *")
    completion = script.completions()[0]
    assert completion.name == "Button"
    assert completion.complete == "Button("

    thonny_completion = ThonnyCompletion(completion.name, completion.complete, completion.type, completion.description,
                                         completion.parent, completion.full_name)
    assert thonny_completion.name == "Button"
    assert thonny_completion.complete == "Button("
    assert thonny_completion.type == str(completion.type)
    assert thonny_completion.description == completion.description
    assert thonny_completion.parent == str(completion.parent)
    assert thonny_completion.full_name == completion.full_

# Generated at 2022-06-24 07:52:51.792408
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    a = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert a["name"] == "name"
    assert a["complete"] == "complete"
    assert a["type"] == "type"
    assert a["description"] == "description"
    assert a["parent"] == "parent"
    assert a["full_name"] == "full_name"



# Generated at 2022-06-24 07:52:55.276726
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc: ThonnyCompletion = ThonnyCompletion("x", "x", "x", "x", "x", "x")
    tc.name = "y"
    assert tc.name == "y"
    assert tc["name"] == "y"



# Generated at 2022-06-24 07:53:02.685706
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree
    from parso.tree import search_ancestor

    def test_one_case(source, pos, expected_type, expected_name):
        """Test that the line identified by pos has the expected_type and expected_name."""
        tree = parso.parse(source)
        node = get_statement_of_position(tree, pos)
        assert node.type == expected_type
        if expected_name is not None:
            if expected_type == "import_from":
                assert node.get_first_leaf().value == expected_name
            else:
                assert search_ancestor(node, tree.Name).value == expected_name


# Generated at 2022-06-24 07:53:11.662444
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        completions = get_script_completions(
            "\n", 2, 0, "", sys_path=["/test/test_1", "/test/test_2"]
        )
        assert completions and len(completions) > 10
        completions = get_script_completions("import math\n", 1, 8, "", sys_path=[])
        assert completions and len(completions) > 10
    else:
        completions = get_script_completions("", 1, 0, "", sys_path=["/test/test_1"])
        assert completions and len(completions) > 10

# Generated at 2022-06-24 07:53:21.743774
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    result = get_interpreter_completions("print('Hello')", [], None)
    assert result[0].name == "print"
    assert result[0].complete == "print"
    assert isinstance(result[0].type, str)

    result = get_interpreter_completions("import sys", [], None)
    assert result[0].name == "sys"
    assert result[0].complete == "sys"
    assert isinstance(result[0].type, str)

    result = get_interpreter_completions("import sys; sys.", [], None)
    assert result[0].name == "argv"



# Generated at 2022-06-24 07:53:31.144690
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "get_usages"
    complete = "get_usages=jedi.api.Script.get_usages"
    type = "function"
    description = "Script.get_usages(self,<br>only_stubs: bool = False) -&gt; list"
    parent = "Script"
    full_name = "jedi.api.Script.get_usages"
    tc_instance = ThonnyCompletion(
        name, complete, type, description, parent, full_name
    )
    assert tc_instance["name"] == "get_usages"
    assert tc_instance["complete"] == "get_usages=jedi.api.Script.get_usages"
    assert tc_instance["type"] == "function"

# Generated at 2022-06-24 07:53:37.102570
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import os
    import sys

    class TestCase(unittest.TestCase):
        def test_get_definitions(self):
            dirpath = os.path.dirname(__file__)
            test_file = os.path.join(dirpath, "jedi_test_pos.py")

            with open(test_file, "r") as fp:
                src = fp.read()
                src = src.replace("%JEDI_TEST_FILE%", test_file)

            with open(test_file, "w") as fp:
                fp.write(src)

            module = sys.modules[__name__]

            from thonny import get_workbench
            from thonny.jedi_utils import get_definitions


# Generated at 2022-06-24 07:53:41.192003
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import os
    import parso
    from parso.python.tree import Node
    import jedi.parser_utils
    
    if hasattr(jedi.parser_utils, "get_statement_of_position"):
        getter = jedi.parser_utils.get_statement_of_position
    else:
        getter = _copy_of_get_statement_of_position
    
    dirname = os.path.dirname(__file__)
    test_file_path = os.path.join(dirname, "get_statement_of_pos.py")
    with open(test_file_path, "r", encoding="utf-8") as fp:
        source = fp.read()
    
    root = parse_source(source)
    line, col = 8, 40

# Generated at 2022-06-24 07:53:51.416617
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def _test(jedi_version, source, cursor_pos, expected_start, expected_end):
        if _using_older_jedi(jedi_version):
            node = parse_source(source)
            node = get_statement_of_position(node, cursor_pos)
            assert node is not None
            assert node.start_pos == expected_start
            assert node.end_pos == expected_end
        else:
            import jedi

            node = jedi.Script(source, 1, 1)._parser_module()
            node = get_statement_of_position(node, cursor_pos)
            assert node is not None
            assert node.start_pos == expected_start
            assert node.end_pos == expected_end


# Generated at 2022-06-24 07:53:55.748119
# Unit test for function parse_source
def test_parse_source():
    from jedi import Script
    import parso
    from thonny.jedi_utils import parse_source
    source = '''def f(a):
        a.b'''
    jedi_script = Script(source, 2, 7)
    assert isinstance(parse_source(source), parso.python.tree.Module)
    assert get_statement_of_position(parse_source(source), jedi_script.cursor.path[0].start_pos) == parse_source(source).children[1]
    assert get_statement_of_position(parse_source(source), jedi_script.cursor.path[0].end_pos) == parse_source(source).children[1]

# Generated at 2022-06-24 07:53:58.581349
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completions = get_script_completions("import datetime; datetime.", 0, 0, "test")
    assert completions[0]["name"] == "datetime.datetime("

# Generated at 2022-06-24 07:54:00.906722
# Unit test for function get_script_completions
def test_get_script_completions():
    completion_list = get_script_completions("os.", 0, 3, "")
    assert len(completion_list) > 1



# Generated at 2022-06-24 07:54:05.042414
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_ThonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    test_key = "name"
    assert test_ThonnyCompletion.__getitem__(test_key) == "name"

# Generated at 2022-06-24 07:54:09.574573
# Unit test for function parse_source
def test_parse_source():
    # parse_source should throw an exception if it can't parse the code
    try:
        parse_source('invalid code')
        assert False, "parse_source did not throw an exception"
    except BaseException as e:
        logger.info("Expected exception:" + str(e))


# Generated at 2022-06-24 07:54:17.963973
# Unit test for function get_script_completions
def test_get_script_completions():
    assert "tuple_" == get_script_completions("tuple_", 1, 7, "tmp.py")[0].name
    assert "tuple_" == get_script_completions("tupl_", 1, 6, "tmp.py")[0].name
    assert "tuple_=" == get_script_completions("tupl_", 1, 6, "tmp.py")[1].name
    assert "tuple_=" == get_script_completions("tuple_", 1, 7, "tmp.py")[1].name

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 07:54:21.550765
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"

# Generated at 2022-06-24 07:54:24.700384
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = """def foo(x, y=5, *args, **kwargs):
    pass
    """
    parsed = parse_source(source)
    assert isinstance(parsed, parso.python.tree.Module)

# Generated at 2022-06-24 07:54:34.161640
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.completion import Completion

    _ = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert _.name == "name"
    assert _.complete == "complete"
    assert _.type == "type"
    assert _.description == "description"
    assert _.parent == "parent"
    assert _.full_name == "full_name"
    # Check if ThonnyCompletion object can be used as Completion object

# Generated at 2022-06-24 07:54:41.472046
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    
    tree = parse_source("""
    a = 10
    a + = #<--- caret here
    """)
    
    last_node = tree.children[2]
    assert isinstance(last_node, parso.python.tree.ExprStmt)
    
    pos = last_node.get_end_pos_of_prefix()
    stmt = get_statement_of_position(tree, pos)
    
    assert isinstance(stmt, parso.python.tree.ExprStmt)
    assert stmt.get_code() == "a + ="

# Generated at 2022-06-24 07:54:43.149182
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert getattr(ThonnyCompletion, 'complete')


if __name__ == "__main__":
    test_ThonnyCompletion()

# Generated at 2022-06-24 07:54:46.403623
# Unit test for function parse_source
def test_parse_source():
    expr = parse_source('if a > 1: a += 1')
    assert expr.type == 'file_input'
    assert expr.children[0].type == 'if_stmt'


# Generated at 2022-06-24 07:54:53.998441
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        jedi_version = "0.16"
    else:
        jedi_version = "0.18"


# Generated at 2022-06-24 07:55:04.045494
# Unit test for function get_definitions
def test_get_definitions():
    """This should pass for all supported jedi versions."""
    import os.path

    test_dir = os.path.dirname(__file__)
    source = open(os.path.join(test_dir, "test.py")).read()
    row = 12
    column = 5
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)

    assert len(definitions) == 1
    assert definitions[0].line == 9
    assert definitions[0].column == 5
    assert definitions[0].module_path == os.path.join(test_dir, "test.py")
    assert definitions[0].in_builtin_module() == False

    # Not sure how to test against other installed libraries

# Generated at 2022-06-24 07:55:08.808274
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if _using_older_jedi(jedi):
        interpreter = jedi.Interpreter("", [{"test": sys.modules["jedi"]}])
    else:
        interpreter = jedi.Interpreter("", [{"test": sys.modules["jedi"]}], sys_path=None)

    completions = interpreter.completions()
    print(completions)

    completions = interpreter.complete()
    print(completions)

# Generated at 2022-06-24 07:55:16.260837
# Unit test for function parse_source
def test_parse_source():
    node = parse_source("x = 42")
    assert node.type == "file_input"
    assert len(node.children) == 1
    assert node.children[0].type == "simple_stmt"
    assert len(node.children[0].children) == 1
    assert node.children[0].children[0].type == "expr_stmt"
    assert len(node.children[0].children[0].children) == 1
    assert node.children[0].children[0].children[0].type == "annassign"
    assert len(node.children[0].children[0].children[0].children) == 2
    assert node.children[0].children[0].children[0].children[0].type == "name"

# Generated at 2022-06-24 07:55:18.218378
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module
    from parso.python import tree


# Generated at 2022-06-24 07:55:23.552912
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="str", complete="str", type="str", description="str", parent="str", full_name="str"
    )
    assert completion.name == "str"
    assert completion.complete == "str"
    assert completion.type == "str"
    assert completion.description == "str"
    assert completion.parent == "str"
    assert completion.full_name == "str"



# Generated at 2022-06-24 07:55:27.228891
# Unit test for function parse_source
def test_parse_source():
    import parso

    p = parse_source("import sys\nsys.stdout.write('hello')")
    assert isinstance(p, parso.python.tree.Module)
    node = p.children[1].children[1]
    assert isinstance(node, parso.python.tree.Name) and node.value == "stdout"

# Generated at 2022-06-24 07:55:35.110686
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    import parso

    code = "def f():\n    while True:\n        if cond:\n            return 3"
    module = parso.parse(code)
    funcdef = module.children[0]

    def check(node, expected_node_node_start, expected_node_node_end):
        statement = get_statement_of_position(node, 8)
        assert isinstance(statement, tree.WhileStmt), statement
        assert expected_node_node_start <= statement.start_pos <= statement.end_pos <= expected_node_node_end
        return statement

    while_node = check(funcdef, 8, 26)
    check(while_node, 8, 26)

# Generated at 2022-06-24 07:55:40.276281
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]
    source = "import math\nmath.ceil()"
    row = 2
    column = 8
    completions = get_script_completions(source, row, column, filename = None, sys_path = None)
    assert set([c.name for c in completions]) == set(["ceil"])

if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 07:55:41.277684
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:55:47.680010
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    suite = tree.Node(type="suite")
    for i in range(4):
        node = tree.Node(type="simple_stmt")
        node.start_pos = (i, 0)
        node.end_pos = (i, 1)
        suite.children.append(node)

    suite.children[1].children.append(tree.Node(type="flow_stmt"))
    suite.children[1].children[0].start_pos = (1, 0)
    suite.children[1].children[0].end_pos = (1, 1)

    assert get_statement_of_position(suite, (0, 0)) == suite.children[0]
    assert get_statement_of_position(suite, (1, 0)) == suite.children[1]


# Generated at 2022-06-24 07:55:53.063506
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:55:57.456865
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    data = {
        "name": "name",
        "complete": "complete",
        "type": "type",
        "description": "description",
        "parent": "parent",
        "full_name": "full_name",
    }
    c = ThonnyCompletion(**data)
    for k in data:
        assert c[k] == data[k]

# Generated at 2022-06-24 07:56:02.900098
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    """
    Test that get_statement_of_position works with new as well as with old jedi
    """
    from parso.python.tree import Module
    from parso.python.tree import SimpleStatement
    from parso.python.tree import PythonNode

    class DummyPythonNode(PythonNode):
        _fields = []

        def __init__(self, start_pos, end_pos):
            self.start_pos = start_pos
            self.end_pos = end_pos

    class DummySimpleStatement(SimpleStatement):
        def __init__(self, start_pos, end_pos):
            self.start_pos = start_pos
            self.end_pos = end_pos

    # Test old jedi
    # jedi 0.16.0 uses parso 0.6.x
    # jedi 0.

# Generated at 2022-06-24 07:56:13.449525
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    tree = parse_source('print("Hello World!")')
    statements = tree.children

    assert(statements[0].type == "simple_stmt")
    print(statements[0].children)
    assert(len(statements[0].children) == 1)
    assert(statements[0].children[0].type == "expr_stmt")

    assert(len(statements[0].children[0].children) == 1)
    assert(statements[0].children[0].children[0].type == "power")

    assert(len(statements[0].children[0].children[0].children) == 1)
    assert(statements[0].children[0].children[0].children[0].type == "atom_expr")


# Generated at 2022-06-24 07:56:19.520224
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "description"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-24 07:56:20.991719
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:56:29.670521
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.misc_utils import running_on_windows

    result = get_script_completions("print(\"\")", 0, 10, "", sys_path=["/a"])
    assert result == [], "Completions list is not empty"

    result = get_script_completions("pri", 0, 3, "")
    if running_on_windows():
        expected_result = [
            {"complete": "print(end='')", "name": "print(", "type": "statement"},
            {"complete": "pri", "name": "pri", "type": "name"},
        ]

# Generated at 2022-06-24 07:56:40.501280
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from unittest import TestCase
    import parso
    import parso.python.tree

    class TestCase(TestCase):
        def run_test(self, code, pos, expected_node_class):
            root_node = parso.parse(code)
            statement = get_statement_of_position(root_node, pos)
            self.assertIsInstance(statement, expected_node_class)


# Generated at 2022-06-24 07:56:49.578943
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__ as jedi_version

    completions = get_script_completions(
        "import datetime; datetime.da", 20, len("datetime.da"), "test.py"
    )
    assert [c.name for c in completions] == ["date", "datetime"]

    if jedi_version >= "0.17":
        # 'test.test' is a valid completion
        assert "test.test" in [c.complete for c in completions]
    else:
        # 'test.test' is not a valid completion
        assert "test.test" not in [c.complete for c in completions]



# Generated at 2022-06-24 07:56:58.834250
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os.path
    import unittest

    from test.test_support import run_unittest

    from thonny.jedi_utils import get_script_completions

    class JediTest(unittest.TestCase):
        def test_simple(self):
            completions = get_script_completions("d", 1, 1, "foo.py")
            self.assertEqual(completions, [])

            completions = get_script_completions("i", 1, 1, "foo.py")
            self.assertEqual(completions, [])
            # TODO: add more tests
            # TODO: add test with import

    run_unittest(JediTest)


if __name__ == "__main__":
    test_get_script_complet

# Generated at 2022-06-24 07:57:03.635494
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate import compiled
    from jedi.parser_utils import get_parent_scope

    def find_names(scope, name, definitons=[]):
        for child in scope.children:
            if child.name == name:
                definitons.append(child)
            if isinstance(child, compiled.CompiledObject):
                continue
            find_names(child, name, definitons)
        return definitons


# Generated at 2022-06-24 07:57:14.085057
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    import unittest

    class TestJediUtils(unittest.TestCase):
        def test_get_interpreter_completions(self):

            import jedi

            class DummyClass:
                def __init__(self, name: str, module: str, object: object):
                    self.name = name
                    self.module_name = module
                    self.obj = object

                def __repr__(self):
                    return self.name

            # Here, the text is like this :
            #
            # import os.path
            #
            # _ = os.pa<cursor>

# Generated at 2022-06-24 07:57:25.227204
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Test all attributes
    ref_obj = thonny.jediutils.ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert ref_obj.name == "name"
    assert ref_obj.complete == "complete"
    assert ref_obj.type == "type"
    assert ref_obj.description == "description"
    assert ref_obj.parent == "parent"
    assert ref_obj.full_name == "full_name"
    # Test attribute access
    assert ref_obj["name"] == "name"
    assert ref_obj["complete"] == "complete"
    assert ref_obj["type"] == "type"
    assert ref_obj["description"] == "description"
    assert ref_obj["parent"] == "parent"

# Generated at 2022-06-24 07:57:27.452366
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    from parso import parse


# Generated at 2022-06-24 07:57:32.821803
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    t = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert t.name == "name" and t.complete == "complete" and t.type == "type" and t.description == "description" and t.parent == "parent" and t.full_name == "full_name"

# Generated at 2022-06-24 07:57:38.704882
# Unit test for function parse_source
def test_parse_source():
    from parso import ParserSyntaxError

    root = parse_source("1 + 1")

    assert root.children[0].type == "arithmetic_expression"
    assert root.children[0].children[1].value == "+"
    assert root.children[0].children[0].value == "1"
    assert root.children[0].children[2].value == "1"

    with pytest.raises(ParserSyntaxError):
        parse_source("a + 1")

# Generated at 2022-06-24 07:57:47.044232
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Unit tests for method __init__ of class ThonnyCompletion

# Generated at 2022-06-24 07:57:50.487363
# Unit test for function get_definitions
def test_get_definitions():
    source = "from collections import defaultdict\n"
    locations=get_definitions(source, 1, 22, "test_file")
    assert [x.line for x in locations] == [41] # line 41 in collections.py

# Generated at 2022-06-24 07:57:51.486233
# Unit test for function parse_source
def test_parse_source():
    parse_source("import json")


# Generated at 2022-06-24 07:57:56.963925
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("class A:")
    assert parse_source("class A(B):")
    assert parse_source("def f(a):")
    assert parse_source("def f(a, b, c=1, d=2):")
    assert parse_source("@decorator\ndef f():")

# Generated at 2022-06-24 07:57:59.237214
# Unit test for function get_definitions
def test_get_definitions():
    get_definitions("import datetime; datetime.da", 0, 27, "my.py")

# Generated at 2022-06-24 07:58:06.425161
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script("import json")
        completion = script.completions()[0]
    else:
        script = jedi.Script(code="import json")
        completion = script.complete()[0]
    thonny_completion = ThonnyCompletion(
        completion.name, completion.complete, completion.type, completion.description, completion.parent, completion.full_name
    )

    assert thonny_completion["name"] == completion.name
    assert thonny_completion["complete"] == completion.complete
    assert thonny_completion["type"] == completion.type
    assert thonny_completion["description"] == completion.description
    assert thonny_completion["parent"] == completion.parent
   

# Generated at 2022-06-24 07:58:12.476131
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]

    completions = get_interpreter_completions("__builtins__.",[{"x": "abc"}])
    assert len(completions) > 0



# Generated at 2022-06-24 07:58:14.184008
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion
    import jedi

# Generated at 2022-06-24 07:58:19.090581
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from parso.python.tree import Leaf
    import jedi
    if not _using_older_jedi(jedi):
        test_leaf = Leaf(0, 0, "TestString")
        test_name = "test_name"
        test_completion = jedi.Completion(test_leaf, name=test_name)
        test_type = "test_type"
        test_description = "test_description"
        test_parent = None
        test_full_name = "test_full_name"
        completions = ThonnyCompletion(test_name, test_name, test_type, test_description, test_parent, test_full_name)
        assert completions.name == test_name
        assert completions.complete == test_name
        assert completions.type == test_type
        assert completions

# Generated at 2022-06-24 07:58:22.922755
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions("print(m)", [], sys_path=["."])
    assert result == [ThonnyCompletion(name='math', complete='math', type='module', description='<module>', parent=None, full_name='math')]


# Generated at 2022-06-24 07:58:33.605752
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = ThonnyCompletion(name="testname",
                                complete="testcomplete",
                                type="testtype",
                                description="testdescription",
                                parent="testparent",
                                full_name="testname")
    assert complete["name"] == "testname"
    assert complete["complete"] == "testcomplete"
    assert complete["type"] == "testtype"
    assert complete["description"] == "testdescription"
    assert complete["parent"] == "testparent"
    assert complete["full_name"] == "testname"
    assert complete.name == "testname"
    assert complete.complete == "testcomplete"
    assert complete.type == "testtype"
    assert complete.description == "testdescription"
    assert complete.parent == "testparent"
    assert complete.full_name == "testname"


# Generated at 2022-06-24 07:58:41.978368
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    import parso.python.tree

    # test a block which is not a statement
    node = parso.python.tree.ExprStmt(start_pos=(1, 1), end_pos=(1, 2))
    leaf = parso.python.tree.Leaf(1, 1, 1, 2, ")", ")", node)
    node.children.append(leaf)
    assert jedi.parser_utils.get_statement_of_position(node, (1, 2)) == node

    # test a block which is a statement
    if _using_older_jedi(jedi):
        actual = jedi.parser_utils.get_statement_of_position(node, (1, 1))

# Generated at 2022-06-24 07:58:43.697897
# Unit test for function parse_source
def test_parse_source():
    from parso.utils import split_lines

# Generated at 2022-06-24 07:58:53.108274
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    from jedi import Interpreter

    class Test(TestCase):
        def test_get_interpreter_completions(self):
            interpreter = Interpreter("3 + 4", [{}])
            result = get_interpreter_completions("3 + 4", [{}])
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].name, "7")
            self.assertEqual(result[0].complete, "7")
            self.assertEqual(result[0].type, "int")
            self.assertEqual(result[0].description, "int")
            self.assertEqual(result[0].parent, None)
            self.assertEqual(result[0].full_name, "7")

   

# Generated at 2022-06-24 07:58:58.566477
# Unit test for function get_definitions
def test_get_definitions():
    source = 'def test_get_definitions():\n    pass'
    line = 1
    column = 8
    locations = get_definitions(source, line, column, "<test>")
    assert len(locations) == 1
    assert locations[0].module_name == '<test>'
    assert locations[0].line == 1
    assert locations[0].column == 4

# Generated at 2022-06-24 07:59:01.993918
# Unit test for function parse_source
def test_parse_source():
    source = "class Foo: pass"
    root = parse_source(source)
    assert root is not None
    assert len(root.children) == 1
    assert isinstance(root.children[0], parso.python.tree.Class)

# Generated at 2022-06-24 07:59:09.216732
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys
    import jedi

    # set up interpreter
    from thonny import get_workbench

    namespace = [
        {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__loader__": None,
            "__spec__": None,
            "__annotations__": {},
        }
    ]

# Generated at 2022-06-24 07:59:13.973822
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == "name"
    assert tc["complete"] == "complete"
    assert tc["type"] == "type"
    assert tc["description"] == "description"
    assert tc["parent"] == "parent"
    assert tc["full_name"] == "full_name"



# Generated at 2022-06-24 07:59:23.160195
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import api
    import jedi

    if _using_older_jedi(jedi):
        return

    source = "import math\nmath.sqrt("
    script = jedi.Script(code=source, path="")
    completions = script.complete(line=1, column=len("import math\nmath.sqrt("))
    completion = completions[0]
    tc = ThonnyCompletion(name=completion.name, complete=completion.complete, type="", description="", parent="", full_name="")
    assert tc.name == completion.name
    assert tc.complete == completion.complete
    assert tc.type == completion.type
    assert tc.description == completion.description
    assert tc.parent == completion.parent
    assert tc.full_name == completion.full_name

# Generated at 2022-06-24 07:59:24.987520
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree


# Generated at 2022-06-24 07:59:29.499582
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    from parso import parse

    expected = parse(sample_source_1)
    actual = parse_source(sample_source_1)
    assert isinstance(actual, tree.Module)
    assert expected.children == actual.children


# Generated at 2022-06-24 07:59:37.282461
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    # The following test code is taken from jedi 0.13.3
    # (https://github.com/davidhalter/jedi/blob/9f3a2f93c48eda24e2dcc25e54eb7cc10aa73848/jedi/api/tests/test_Script.py#L40-L60)
    source = '''import json
json.l'''
    completions = get_script_completions(source, 2, 8, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "load"

# Generated at 2022-06-24 07:59:39.408255
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Function

    result = parse_source(
"""def f(x, y):
    pass"""
    )

    assert isinstance(result.children[0], Function)



# Generated at 2022-06-24 07:59:50.146834
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    from parso.python.tree import ImportName
    from parso.python.tree import ImportStatement
    from parso.python.tree import DottedName
    from parso.python.tree import Name
    from parso.python.tree import Leaf
    from parso.python.tree import OneLineSuite
    from parso.python.tree import IfStmt

    source = """
    from sys import path
    if True:
        pass
    """
    tree = parse_source(source)
    assert type(tree) is Module
    assert len(tree.children) == 3

    import_stmt_node = tree.children[0]
    assert type(import_stmt_node) is ImportStatement
    assert len(import_stmt_node.children) == 1

    import_name

# Generated at 2022-06-24 07:59:59.851524
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import parso

    assert ThonnyCompletion(
        name="ex", complete="ex", type=parso.python.tree.Name, description="ex", parent=None, full_name="ex"
    )["name"] == "ex"
    assert ThonnyCompletion(
        name="ex", complete="ex", type=parso.python.tree.Name, description="ex", parent=None, full_name="ex"
    )["complete"] == "ex"
    assert ThonnyCompletion(
        name="ex", complete="ex", type=parso.python.tree.Name, description="ex", parent=None, full_name="ex"
    )["type"] == parso.python.tree.Name

# Generated at 2022-06-24 08:00:03.681654
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    import jedi

    class TestGetICom(TestCase):
        def setUp(self):
            self.source = """
import json
json.dumps()
            """

# Generated at 2022-06-24 08:00:06.700548
# Unit test for function parse_source
def test_parse_source():
    source = "print('Hello World!'"
    node = parse_source(source)
    assert node.get_code() == source


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 08:00:14.979846
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench

    wb = get_workbench()

    wb.editor.set_text("from datetime import datetime\nprint(datetime.date.)")
    wb.editor.set_insertion_point(row=1, column=20)
    completions = get_script_completions(
        source=wb.editor.get_source_code(), row=1, column=20, filename="test1.py"
    )
    for c in completions:
        print(c.name)

    wb.editor.set_text("with open() as f:\n    print(f.read)")
    wb.editor.set_insertion_point(row=1, column=19)

# Generated at 2022-06-24 08:00:22.088559
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    result = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert result.name == "name"
    assert result.complete == "complete"
    assert result.type == "type"
    assert result.description == "description"
    assert result.parent == "parent"
    assert result.full_name == "full_name"



# Generated at 2022-06-24 08:00:25.778105
# Unit test for function parse_source
def test_parse_source():
    # parse_source should be no-op for text with no syntax error
    for text in ["def foo():\n print(3)", "3", "3 + 2", 'print("hello")']:
        assert parse_source(text).get_code() == text

    # parse_source should work with multiline comment
    assert parse_source("# hello\nprint(3)").get_code() == "print(3)"


# Unit tests for function get_completions

# Generated at 2022-06-24 08:00:35.590277
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("x", 0, 1, "test.py")) == 0
    d = get_definitions("str()", 0, 5, "test.py")
    assert len(d) == 1
    assert d[0].name == "str" and d[0].type == "class" and d[0].full_name == "str"
    
    d = get_definitions("str.number", 0, 11, "test.py")
    assert len(d) == 1
    assert d[0].name == "number" and d[0].type == "instance" and d[0].full_name == "str"
    
    d = get_definitions("number", 0, 7, "test.py")
    assert len(d) == 2

# Generated at 2022-06-24 08:00:46.181225
# Unit test for function get_definitions
def test_get_definitions():
    namespaces = [{
        "sys": {
            "path": ["/lib/moduleA.py", "/lib/moduleB.py"]
        }
    }]

    definitions = get_definitions("import sys\nsys.path", 0, len("import sys\nsys.path"), "dummy.py")
    assert len(definitions) == 1
    assert definitions[0].module_name == 'sys'
    assert definitions[0].type == 'module'

    definitions = get_definitions("import sys\nsys.", 0, len("import sys\n"), "dummy.py")
    assert len(definitions) == 1
    assert definitions[0].module_name == 'sys'
    assert definitions[0].type == 'module'


# Generated at 2022-06-24 08:00:51.392319
# Unit test for function get_script_completions
def test_get_script_completions():
    def compare_completions(c1, c2):
        k1 = c1["name"]
        k2 = c2["name"]
        return k1 < k2

    comps = get_script_completions(
        "import sys\nsys.r", 5, 10, "thonny_code.py"
    )  # 39
    comps.sort(key=comparator(compare_completions))
    assert comps[0]["name"] == "recursionlimit"
    assert comps[0]["complete"] == "recursionlimit"
    assert comps[0]["type"] == "attribute"

    assert comps[1]["name"] == "recursionlimit="
    assert comps[1]["complete"] == "recursionlimit="
    assert comps[1]["type"]

# Generated at 2022-06-24 08:01:00.317691
# Unit test for function get_script_completions
def test_get_script_completions():
    def _test(source, row, column, filename, sys_path=None):
        completions = get_script_completions(source, row, column, filename, sys_path)
        return sorted(c.name for c in completions)

    # jedi 0.17

# Generated at 2022-06-24 08:01:06.636383
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    completion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert completion[
        "name"
    ] == name, "Error in method __getitem__ of class ThonnyCompletion"
    assert completion[
        "complete"
    ] == complete, "Error in method __getitem__ of class ThonnyCompletion"
    assert completion[
        "type"
    ] == type, "Error in method __getitem__ of class ThonnyCompletion"
    assert completion[
        "description"
    ] == description, "Error in method __getitem__ of class ThonnyCompletion"
   

# Generated at 2022-06-24 08:01:16.563600
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    import parso.python.tree

    assert get_statement_of_position is not None

    node = parso.parse("a=1")
    pos = 2
    result = get_statement_of_position(node, pos)
    assert isinstance(result, parso.python.tree.ExprStmt)
    assert result.start_pos == 1
    assert result.end_pos == 4

    pos = 1
    result = get_statement_of_position(node, pos)
    assert isinstance(result, parso.python.tree.ExprStmt)
    assert result.start_pos == 1
    assert result.end_pos == 4

    pos = 0
    result = get_statement_of_position(node, pos)
    assert result is None

# Generated at 2022-06-24 08:01:23.900138
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_statement_of_position
    from jedi import refactoring
    from jedi.evaluate import compiled

    def get_definitions2(source, row, column, filename):
        module = parse_source(source)
        node = get_statement_of_position(module, (row, column))
        refactoring._replace_names(module.names, [], [])
        evaluation = compiled.create(module, None)
        return refactoring.get_goto_definitions(evaluation, node, (row, column))

    def _test(test_source, expected_result, row, column):
        source = test_source
        result = get_definitions(source, row, column, "<testIt>")