

# Generated at 2022-06-24 07:51:32.815292
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class MyTestCase(TestCase):
        def test_get_interpreter_completions(self):
            from jedi import Interpreter

            ns = [{"a": 1, "b": 2}]
            interpreter = Interpreter('a.b.', ns)
            self.assertTrue(hasattr(interpreter, "completions"))

            completion = get_interpreter_completions('a.', ns)[0]
            self.assertEqual(completion.name, "a")
            completion = get_interpreter_completions('a.b.', ns)[0]
            self.assertEqual(completion.name, "b")
            self.assertEqual(completion.description, type(2).__name__)


# Generated at 2022-06-24 07:51:38.834118
# Unit test for function get_definitions
def test_get_definitions():
    from tkinter import Tk
    from thonny import get_workbench
    from thonny.plugins.jedi_support.jedi_repl import _JediReplPane
    from thonny.config import get_config_val
    from jedi import __version__ as jedi_version

    old_val = get_config_val("jedi.use_latest_jedi")
    root = Tk()
    get_workbench().set_default_window_size(800, 800)
    get_workbench().create()
    repl = _JediReplPane(get_workbench())
    repl.show_code_viewer()
    repl.load_file(__file__)
    text = repl.get_text()
    get_config_val("jedi.use_latest_jedi", False)


# Generated at 2022-06-24 07:51:41.112129
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree as tree

    module = parse_source('print("Hello World")')
    assert isinstance(module, tree.Module)

# Generated at 2022-06-24 07:51:47.330292
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:51:52.511820
# Unit test for function parse_source
def test_parse_source():
    parse_source("")
    parse_source("a")
    parse_source("123")
    parse_source("1.23")
    parse_source("a + b")
    parse_source("a[0]")
    parse_source("def f():\n    pass")
    parse_source("def f(a, b):\n    pass")
    parse_source("class C:\n    pass")
    parse_source("def f(a = 5, b = 6):\n    pass")


if __name__ == "__main__":
    from test_util import rundocs
    import sys

    rundocs(sys.modules[__name__])

# Generated at 2022-06-24 07:51:54.138708
# Unit test for function get_definitions
def test_get_definitions():
    import inspect
    import os
    from thonny.plugins.osu.backend_jedi import get_definitions


# Generated at 2022-06-24 07:51:59.444841
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test is based on the contents of the following script
    script = '''
import logging
logger = logging.getLogger()
logger.debug("x")
'''

    completions = get_interpreter_completions(script, [{}], [])
    assert ("logger", "logger") in [(c.name, c.complete) for c in completions]
    assert ("logger.debug", "logger.debug") in [(c.name, c.complete) for c in completions]

# Generated at 2022-06-24 07:52:11.020693
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # This is not a full unit test, just simple verification of the copy
    # of the function that is guaranteed to work with older Jedi versions.
    from unittest.mock import MagicMock

    node_mock = MagicMock()
    node_mock.children = []

    assert _copy_of_get_statement_of_position(node_mock, 2) == None

    node_mock = MagicMock()
    node_mock.children = [MagicMock()]
    node_mock.children[0].start_pos = 5
    node_mock.children[0].end_pos = 8

    assert _copy_of_get_statement_of_position(node_mock, 4) == None

    node_mock = MagicMock()

# Generated at 2022-06-24 07:52:20.767837
# Unit test for function get_definitions
def test_get_definitions():
    """Unit test for function get_definitions."""
    source = """from math import *
from math import sqrt
from math import fabs
from tkinter import *
from tkinter import Canvas"""
    filename = "test_file.py"

# Generated at 2022-06-24 07:52:22.068920
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-24 07:52:31.851072
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_t_c = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert test_t_c.__getitem__('name') == 'name'
    assert test_t_c.__getitem__('complete') == 'complete'
    assert test_t_c.__getitem__('type') == 'type'
    assert test_t_c.__getitem__('description') == 'description'
    assert test_t_c.__getitem__('parent') == 'parent'
    assert test_t_c.__getitem__('full_name') == 'full_name'

    try:
        assert test_t_c.__getitem__('wrong_key') == 'name'
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 07:52:40.623730
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso
    from jedi.api.keywords import KeywordName

    name = "main"
    complete = "main"
    type = KeywordName
    description = None
    parent = parso.python.tree
    full_name = "main"
    thonnyCompletion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert thonnyCompletion.name == name
    assert thonnyCompletion.complete == complete
    assert thonnyCompletion.type == type
    assert thonnyCompletion.description == description
    assert thonnyCompletion.parent == parent
    assert thonnyCompletion.full_name == full_name

# Generated at 2022-06-24 07:52:45.840987
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    res = ThonnyCompletion(name='name',
                           complete='complete',
                           type='type',
                           description='description',
                           parent='parent',
                           full_name='full_name')

    assert res['name'] == 'name'
    assert res['complete'] == 'complete'
    assert res['type'] == 'type'
    assert res['description'] == 'description'
    assert res['parent'] == 'parent'
    assert res['full_name'] == 'full_name'

# Generated at 2022-06-24 07:52:47.565095
# Unit test for function parse_source
def test_parse_source():
    # segfault with jedi 0.13.2 and earlier
    parse_source("import math\n")



# Generated at 2022-06-24 07:52:57.222748
# Unit test for function get_script_completions
def test_get_script_completions():
    from sys import path
    from tkinter import Text, Tk
    from unittest.mock import Mock
    import tempfile
    import os
    import re

    def assert_completions_are_valid(completions):
        regex_chars_pattern = "[\^$.\[\]|()?*+\\"
        regex_digit_pattern = "\d"
        regex_letter_pattern = "\w"
        regex_underscore_pattern = "\_"
        allowed_ascii_chars_pattern = "[\n\r\t\f\a\v " + "".join([chr(x) for x in range(32, 128)]) + "]"

# Generated at 2022-06-24 07:53:02.691158
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"



# Generated at 2022-06-24 07:53:10.755987
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert not get_statement_of_position(None, None)

    from parso.python import tree

    # Simple test case
    node = tree.IfStmt(start_pos=(0, 0), end_pos=(0, 10))
    assert get_statement_of_position(node, (0, 10)) is node

    # Test is a bit more interesting
    class RecursiveNode(tree.BaseNode):
        def __init__(self):
            self.start_pos = (0, 0)
            self.end_pos = (0, 10)
            self.children = [RecursiveNode()]

    node = RecursiveNode()
    assert get_statement_of_position(node, (0, 10)) is node

# Generated at 2022-06-24 07:53:14.246321
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions(
        """class X:
            def __init__(self, name):
                self.name = name
            def get_name(self):
                return self.name
        x  = X(123)""",
        [],
    )

    assert "X(" in [x.complete for x in completions]
    assert "name" in [x.complete for x in completions]
    assert "get_name(" in [x.complete for x in completions]
    assert "x.get_name(" in [x.complete for x in completions]
    assert "x.name" in [x.complete for x in completions]

# Generated at 2022-06-24 07:53:14.960489
# Unit test for function get_definitions

# Generated at 2022-06-24 07:53:18.499530
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import ast

    code = ast.parse("a + b")
    node = get_statement_of_position(code, 5)
    assert node.col_offset == 0
    assert isinstance(node, ast.Expr)

    node = get_statement_of_position(code, 10)
    assert node is None

# Generated at 2022-06-24 07:53:28.723405
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf, Node

    leaf = Leaf(1, 2)
    leaf.start_pos = (1, 1)
    leaf.end_pos = (1, 10)
    leaf.type = "test"

    assert get_statement_of_position(leaf, (1, 1)) == leaf
    assert get_statement_of_position(leaf, (1, 3)) == leaf
    assert get_statement_of_position(leaf, (1, 10)) == leaf
    assert get_statement_of_position(leaf, (1, 20)) is None

    dummy_node = Node(1, 2)
    dummy_node.children = [leaf]
    assert get_statement_of_position(dummy_node, (1, 1)) == leaf

# Generated at 2022-06-24 07:53:30.461912
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name",complete="complete",type="type", description="description", parent="parent", full_name="full_name")
    return

# Generated at 2022-06-24 07:53:33.804213
# Unit test for function parse_source
def test_parse_source():
    import parso
    """
    this function tests if the wrapper parse_source works 
    """
    source = "def parse_source(source):\n\timport parso\n\n\treturn parso.parse(source)"
    node = parse_source(source)
    assert type(node) is parso.python.tree.Module

# Generated at 2022-06-24 07:53:43.201502
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import sys

    class TestCompletions(unittest.TestCase):
        def test_get_column(self):
            source = "x.a"
            row = 0
            column = 3
            filename = ""

            completions = get_script_completions(source, row, column, filename)
            self.assertEals(completions[0] in ["append", "capitalize", "count", "index", "splitlines", "split"], True)

        def test_get_row(self):
            source = "x\n.a"
            row = 1
            column = 1
            filename = ""

            completions = get_script_completions(source, row, column, filename)

# Generated at 2022-06-24 07:53:53.088340
# Unit test for function get_definitions
def test_get_definitions():
    # FIXME: case when module is not found
    # import sys
    # sys.path.append(os.path.join(os.path.dirname(__file__), "..", "parser"))
    from unittest.mock import Mock

    get_definitions("import math", 0, 0, "")
    assert get_definitions("import tkinter", 0, 0, "")
    assert get_definitions("import this", 0, 0, "")
    assert get_definitions("import tkinter", 0, 0, "")
    assert get_definitions("from tkinter import *", 0, 0, "")
    assert get_definitions("from tkinter.filedialog import *", 0, 0, "")

# Generated at 2022-06-24 07:54:03.067136
# Unit test for function parse_source
def test_parse_source():
    source = """def foo(x, y="default"):
    if 1 < x < 2:
        print(x)
    for i in range(10, 20):
        print(i)
        if i == 15:
            break
    else:
        print("ok")
    try:
        assert 2 + 2 == 5
    except AssertionError:
        print("ouch")
    finally:
        print("done")
"""
    if _using_older_jedi(jedi):
        from parso.python.tree import Function, IfStmt
    else:
        from parso.python import tree as pt
        Function, IfStmt = pt.Function, pt.IfStmt

    root = parse_source(source)
    assert isinstance(root, tree.Module)
    assert len(root.children) == 1


# Generated at 2022-06-24 07:54:06.793714
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import json
    import jedi

    # Jedi 18 and lower
    if _using_older_jedi(jedi):
        assert json.loads(json.dumps(get_interpreter_completions("print", [{}]))) == [
            {
                "name": "print",
                "complete": "print",
                "type": "function",
                "description": "print(value, ..., sep=' ', end='\\n', file=sys.stdout, flush=False)",
                "parent": "builtins",
                "full_name": "builtins.print",
            }
        ]

    # Jedi 19 and greater
    else:
        print(get_interpreter_completions("print", [{}]))

# Generated at 2022-06-24 07:54:15.851122
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonny_completion["name"] == thonny_completion.name
    assert thonny_completion["complete"] == thonny_completion.complete
    assert thonny_completion["type"] == thonny_completion.type
    assert thonny_completion["description"] == thonny_completion.description
    assert thonny_completion["parent"] == thonny_completion.parent
    assert thonny_completion["full_name"] == thonny_completion.full_name

# Generated at 2022-06-24 07:54:21.604685
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    class MockCompletion(Completion):
        def __init__(self, name, complete, type, description, parent, full_name):
            super().__init__(self, name, complete, type, description, parent, full_name)

    completion = MockCompletion(
        name="a", complete="a", type="t", description="d", parent="p", full_name="f"
    )
    thonny_completion = ThonnyCompletion(
        name="a", complete="a", type="t", description="d", parent="p", full_name="f"
    )
    assert thonny_completion == completion

# Generated at 2022-06-24 07:54:25.082840
# Unit test for function get_definitions
def test_get_definitions():
    try:
        import jedi
    except ImportError:
        import unittest
        raise unittest.SkipTest("Skip test: jedi not installed")

    defs = get_definitions("max", 0, 0, "")
    print(defs)

# Generated at 2022-06-24 07:54:30.816641
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:54:40.951941
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import jedi
        if jedi.__version__.startswith("0.18."):
            print("TODO: jedi.Script.complete issue with sys_paths: https://github.com/davidhalter/jedi/pull/1723")
            return 
    except ImportError:
        print("Skipping test for get_script_completions, because jedi is not installed")
        return

    script = "import bs4"
    results = get_script_completions(script, 1, 8, "script.py")
    assert len(results) == 1
    assert results[0].complete == "bs4"

    results = get_script_completions("import logging", 1, 8, "script.py")
    assert len(results) > 0
    found = False
   

# Generated at 2022-06-24 07:54:44.201449
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import matplotlib.pyplot as plt\nplt.figure(",
                                         1, 27, "test.py")
    if len(completions) < 10:
        raise Exception("Expected many completions for plt.figure, got " + str(len(completions)))



# Generated at 2022-06-24 07:54:49.962445
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    """Test for method __getitem__ of class ThonnyCompletion"""
    
    # Test the function with a parameter
    t = ThonnyCompletion(name="name", complete="complete", type="type",
        description="description", parent="parent", full_name="full_name")
    assert t.__getitem__("name") == "name"
    assert t.__getitem__("type") == "type"

# Generated at 2022-06-24 07:54:56.455221
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    try:
        from jedi.api.classes import Script
    except ImportError:
        Script = jedi.Script

    class ScriptMock(Script):
        def __init__(self, source, row, column, filename, sys_path=None):
            pass

    jedi.Script = ScriptMock
    get_script_completions("", 0, 0, "")
    jedi.Script = Script

# Generated at 2022-06-24 07:55:06.274238
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete = ThonnyCompletion("a", "a", "a", "a", "a", "a")
    # test the name attribute of class ThonnyCompletion
    assert test_complete["name"] == "a"
    # test the complete attribute of class ThonnyCompletion
    assert test_complete["complete"] == "a"
    # test the type attribute of class ThonnyCompletion
    assert test_complete["type"] == "a"
    # test the description attribute of class ThonnyCompletion
    assert test_complete["description"] == "a"
    # test the parent attribute of class ThonnyCompletion
    assert test_complete["parent"] == "a"
    # test the full_name attribute of class ThonnyCompletion
    assert test_complete["full_name"] == "a"

# Unit test

# Generated at 2022-06-24 07:55:09.176499
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(
        name="full_name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    ).__getitem__("name") == "full_name"

# Generated at 2022-06-24 07:55:16.519955
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    source = ("class A:\n"
               "    @property\n"
               "    def prop(cls):\n"
               "        return 42\n"
               "\n"
               "def func(x):\n"
               "    def inner():\n"
               "        pass\n"
               "    return x ** 2\n"
               "\n"
               "a = A()\n"
               "func(a.prop)\n")
    src_path = "test_get_definitions.py"
    # in line "func(a.prop)"
    row, col = 10, 4
    result = get_definitions(source, row, col, src_path)
    assert len(result) == 2
    assert result[0].description == "func"

# Generated at 2022-06-24 07:55:23.721048
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion.__getitem__('name') == 'name'
    assert completion.__getitem__('complete') == 'complete'
    assert completion.__getitem__('type') == 'type'
    assert completion.__getitem__('description') == 'description'
    assert completion.__getitem__('parent') == 'parent'
    assert completion.__getitem__('full_name') == 'full_name'
    assert completion.__getitem__('non_existent') is None


# Generated at 2022-06-24 07:55:31.319676
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.pgen2 import token
    
    # Type tokens (parso.python.tree.newstyle._type_tokens)
    # 'colon'
    # 'type_as_tokens', '[]', '()', '**', '...', '{}', '<>'

    # Python 3.8 keywords
    # 'asynccontextmanager', 'asyncfor', 'asyncwith'

    # Python 3.6 keywords
    # 'async', 'await', 'nonlocal'
    
    # Python 3.5 keywords
    # 'yield_from'

    # Python 3.4 keywords
    # None
    
    # Python 3.3 keywords
    # None
    
    # Python 3.2 keywords
    # None
    
    # Python 3.1 keywords

# Generated at 2022-06-24 07:55:32.550210
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils as pu
    

# Generated at 2022-06-24 07:55:39.325305
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    assert get_script_completions('print("Hello, world!")', 0, 0, 'test.py')[0].name == 'print'
    assert get_script_completions('print("Hello, world!")', 1, 0, 'test.py')[0].name == 'print'
    assert get_script_completions('print("Hello, world!")', 1, 8, 'test.py')[0].name == 'print'
    assert get_script_completions('print("Hello, world!")', 1, 9, 'test.py')[0].name == 'print'
    assert get_script_completions('print("Hello, world!")', 0, 1, 'test.py')[0].name == '__name__'
    assert '<module>' in get_script_

# Generated at 2022-06-24 07:55:41.203362
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Node

    node = parse_source("class Foo:\n    pass\n")
    assert isinstance(node, Node)

# Generated at 2022-06-24 07:55:42.810840
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    pos = (0, 0)

    # case 1:

# Generated at 2022-06-24 07:55:46.641270
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    object1 = ThonnyCompletion('foo', 'foo', 'foo', 'foo', 'foo', 'foo')
    assert object1['name'] == 'foo'



# Generated at 2022-06-24 07:55:55.584327
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from os.path import dirname
    from pathlib import Path
    import jedi
    logger.debug("jedi version {}".format(jedi.__version__))

    script_directory = dirname(__file__)
    path = Path(script_directory).parent.parent.parent
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        file_path = path / "../../../../examples/jedi_unit_tests_0.14/example2.py"
    else:
        file_path = path / "../../../../examples/jedi_unit_tests_0.18/example2.py"


# Generated at 2022-06-24 07:55:58.196107
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    # If no exception is raised, then the test is completed.

# Generated at 2022-06-24 07:56:06.182734
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    n = parso.parse("""
        def f(a, b, c):
            pass
    """)
    assert get_statement_of_position(n, 15) is None
    assert get_statement_of_position(n, 14) is None
    assert get_statement_of_position(n, 13).type == "suite"
    assert get_statement_of_position(n, 12).type == "param"
    assert get_statement_of_position(n, 11).type == "param"
    assert get_statement_of_position(n, 10).type == "param"
    assert get_statement_of_position(n, 9).type == "funcdef"

# Generated at 2022-06-24 07:56:14.874322
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == "name"
    assert tc["complete"] == "complete"
    assert tc["type"] == "type"
    assert tc["description"] == "description"
    assert tc["parent"] == "parent"
    assert tc["full_name"] == "full_name"
    try:
        tc["not_in_dict"]
    except KeyError:
        assert True
    else:
        assert False
    try:
        tc["not_in_dict"] = 1
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 07:56:24.758044
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import unittest

    class Test(unittest.TestCase):
        def test_constructor(self):
            completion = ThonnyCompletion(
                "name",
                "complete",
                "type",
                "description",
                "parent",
                "full_name"
            )
            self.assertEqual(completion.name, "name")
            self.assertEqual(completion.complete, "complete")
            self.assertEqual(completion.type, "type")
            self.assertEqual(completion.description, "description")
            self.assertEqual(completion.parent, "parent")
            self.assertEqual(completion.full_name, "full_name")

    unittest.main()

# Generated at 2022-06-24 07:56:30.326354
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi import interpreter

    jedi.settings.case_insensitive_completion = False
    source = "from math import *\n"
    source += "x = pi\n"
    source += "def fun(y):\n"
    source += "    return y + x\n"
    source += "z = fun(x)\n"
    script = interpreter.Script(source)
    print("definitions for 'fun':")
    for defn in script.get_names('fun', definitions=True):
        print("  ", defn.parent)

# Generated at 2022-06-24 07:56:35.380276
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from thonny.jedi_utils import get_statement_of_position

    def collect_statements(node):
        result = []
        if isinstance(node, parso.python.tree.Statement):
            result.append(node)
        for child in node.children:
            result.extend(collect_statements(child))
        return result

    source = """
    my_var = None
    if True:
        def func1():
            fob = 3
            fob = 4
            return
        def func2(x = 2):
            return x
    """
    ast = parso.parse(source)
    statements = collect_statements(ast)

# Generated at 2022-06-24 07:56:40.774927
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    interpreter_completions = get_interpreter_completions("import sys\nsy", [{"sys": sys}])
    assert len(interpreter_completions) > 0
    assert all(isinstance(x, ThonnyCompletion) for x in interpreter_completions)
    assert all(x.name not in ["__builtins__", "__name__", "__doc__"] for x in interpreter_completions)

    # up to jedi 0.17
    if hasattr(jedi.Interpreter(""), "completions"):
        interpreter = jedi.Interpreter("import sys\nsy", [{"sys": sys}])
        assert len(interpreter.completions()) > 0
        assert len(interpreter.completions()[0]) == 7
       

# Generated at 2022-06-24 07:56:51.116947
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    import sys
    from thonny.plugins.backend_jedi_completions import parse_source, get_definitions

    # Some code to test that when asking to infer the code,
    # we get a variable and not the code itself.
    source = """from test import Test
from test import Test2
from test import Test3
from test import Test4

import test

Test()
t = test.Test()
test.Test()
"""

    path = os.path.join(
        os.path.dirname(__file__), "test_get_definition_resources/test_get_definition.py"
    )

    imports = parse_source(source).get_imports()

    assert len(imports) == 6


# Generated at 2022-06-24 07:57:00.639232
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.globals import get_workbench
    from thonny import get_runner
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.languages import tr
    import unittest
    import sys

    from collections import namedtuple
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from thonny.plugins.micropython.micropython_stubs import MicroPythonProxyStub

    import jedi

    class TestGetScriptCompletions(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.workbench = get_workbench()
            cls.backend = get_runner().backend
            cls.connector = cls.backend.create_filesystem_commander()

# Generated at 2022-06-24 07:57:11.576265
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # The code here should be exactly the same as in 
    # https://github.com/davidhalter/jedi/blob/master/jedi/parser_utils.py
    
    from parso.python import tree
    from parso.utils import split_lines
    

# Generated at 2022-06-24 07:57:18.365769
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    from jedi import Script
    from thonny import get_workbench
    from thonny.languages import tr

    workbench = get_workbench()

    # create new file
    editor = workbench.create_editor("test_get_script_completions.py")
    editor.set_text("name = {1:2,}\nprint(na")
    # get completions
    completions = get_script_completions(editor.get_source_as_text(), 2, 14, "test")
    # JEDI returns completions, but completion.full_name is empty
    # https://github.com/davidhalter/jedi/issues/2154
    # completions = Script("print(na").completions()


# Generated at 2022-06-24 07:57:22.144398
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:23.351175
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils


# Generated at 2022-06-24 07:57:24.514368
# Unit test for function parse_source
def test_parse_source():
    source = """if True:\n  print('hi')"""
    parse_source(source)

# Generated at 2022-06-24 07:57:27.981122
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("", 0, 0, ""))


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 07:57:29.805437
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("def f(a, b):\n    pass")



# Generated at 2022-06-24 07:57:31.505159
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree


# Generated at 2022-06-24 07:57:37.997478
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_object = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

    # test
    assert test_object["name"] == "name"
    assert test_object["complete"] == "complete"
    assert test_object["type"] == "type"
    assert test_object["description"] == "description"
    assert test_object["parent"] == "parent"
    assert test_object["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:41.331925
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions

    c = get_script_completions('x = 1; x.i' , 1, 5, 'f.py')
    assert c[0].complete == 'imag'

# Generated at 2022-06-24 07:57:49.612754
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnycomp = ThonnyCompletion(name="name",
                                  complete="complete",
                                  type="type",
                                  description="description",
                                  parent="parent",
                                  full_name="full_name")
    assert thonnycomp["name"] == "name"
    assert thonnycomp["complete"] == "complete"
    assert thonnycomp["type"] == "type"
    assert thonnycomp["description"] == "description"
    assert thonnycomp["parent"] == "parent"
    assert thonnycomp["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:56.111747
# Unit test for function parse_source
def test_parse_source():
    import parso
    if jedi:
        assert parse_source("for i in range(10): print(i)") == parso.parse("for i in range(10): print(i)")
    else:
        from parso import parse
        assert parse_source("for i in range(10): print(i)") == parse("for i in range(10): print(i)")


# Generated at 2022-06-24 07:58:00.981428
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert get_statement_of_position(
        parse_source("def foo(): pass\n1\n"), (2, 0)
    ) is None
    assert get_statement_of_position(
        parse_source("def foo(): pass\n1\n"), (1, 0)
    ).get_code() == "def foo(): pass"

# Generated at 2022-06-24 07:58:02.622720
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-24 07:58:09.242802
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from textwrap import dedent

    import thonny.inputhook as ih
    from thonny.plugins.jedi_backend import get_interpreter_completions, ThonnyCompletion

    print("Checking for completions of integer division in Python 3.x/2.x")

    i = ih.get_interpreter_for_subprocess()
    completions = get_interpreter_completions("3 / 2", [{"__builtins__": i.builtin_module}])
    completions = dict((e.name, e) for e in completions)

    assert "floor_div" not in completions
    assert "div" not in completions
    assert "true_div" in completions
    assert "truediv" not in completions
    assert "floordiv" in comple

# Generated at 2022-06-24 07:58:12.024873
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    if _using_older_jedi(jedi):
        print("Unit test for function get_definitions is not supported with jedi version" +
              jedi.__version__)
    else:
        defs = get_definitions("import numpy", 0, 7, "")
        print(defs)

if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-24 07:58:19.766838
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class CompletionsTest(TestCase):
        def test_builtin_completion(self):
            completions = get_script_completions("min([], key=max)", 1, 4, "dummy.py")
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "min")
            self.assertEqual(completions[0].complete, "min([], key=max)")
            self.assertEqual(completions[0].description, "min(iterable, *[, default=obj, key=func]) -> value\nmin(a, b, c, ...[, key=func]) -> value")
            self.assertEqual(completions[0].type, "function")
            self

# Generated at 2022-06-24 07:58:23.766259
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "ThonnyCompletion"
    t_c = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert t_c['name'] == 'name'
    assert t_c.__dict__['name'] == 'name'


# Generated at 2022-06-24 07:58:30.046238
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:58:33.354527
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    completion = jedi.Script("x = 1").completions()[0]
    assert ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

# Generated at 2022-06-24 07:58:35.868994
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = 'import secrets\nsecrets.token_hex(16)'
    assert isinstance(parse_source(source), parso.python.tree.Module)

# Generated at 2022-06-24 07:58:40.865268
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name='name',
        complete='complete',
        type='type',
        description='description',
        parent='parent',
        full_name='full_name',
    )

    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'

# Generated at 2022-06-24 07:58:46.760494
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    lines = ["a = [1, 2, 3]", "x = "]
    i = 1
    pos = len(lines[i]) - 1

    t = parse_source("\n".join(lines))
    node = get_statement_of_position(t, (i, pos))

    assert isinstance(node, tree.ExprStmt)
    assert node.get_code().strip() == "x ="

# Generated at 2022-06-24 07:58:55.204750
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.classes import Completion

    completions = get_interpreter_completions("'".upper(), [{'__name__': '__main__'}])
    assert len(completions) > 10
    assert isinstance(completions[0], Completion)

    completions = get_interpreter_completions('import math; math.pi'.upper(), [{'__name__': '__main__'}])
    assert len(completions) == 1

    completions = get_interpreter_completions('import math; math.sin('.upper(), [{'__name__': '__main__'}])
    assert len(completions) >= 2


# Generated at 2022-06-24 07:59:02.297127
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    completion = jedi.Script("import threading; threading").complete()[0]
    assert completion.name == "threading"
    completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )
    assert completion["name"] == "threading"
    assert completion["complete"] == "threading"

# Generated at 2022-06-24 07:59:07.289673
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    node_1 = tree.PythonNode("for", "for")
    node_1.children = [tree.Leaf(2, "i", "i"), tree.Leaf(3, "in", "in"), tree.Leaf(2, "a", "a")]
    node_2 = tree.PythonNode("for", "for")
    node_2.children = [node_1]
    assert get_statement_of_position(node_2, 3) == node_2

# Generated at 2022-06-24 07:59:12.451548
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == tc.name
    assert tc["complete"] == tc.complete
    assert tc["type"] == tc.type
    assert tc["description"] == tc.description
    assert tc["parent"] == tc.parent
    assert tc["full_name"] == tc.full_name

# Generated at 2022-06-24 07:59:22.085420
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.evaluate.compiled import CompiledObject
    from jedi.evaluate.base_context import ContextSet

    class CompiledObjectMock(CompiledObject):
        def __init__(self, name, type):
            self.name = name
            self.type = type
            return None

        def py__call__(self, arguments):
            return None

        def get_parent_context(self, *args, **kwargs):
            return ContextSet([])

        def __repr__(self):
            return "<CompiledObject %s %s %s>" % (self.name, self.type, self.get_signatures())


# Generated at 2022-06-24 07:59:27.109739
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        print("Testing with old jedi version")
    else:
        print("Testing with new jedi version")

    source = 'import os\nos.pa'
    row = 0
    column = len(source)
    filename = "<test file.py>"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "path"
    assert completions[0].complete == "path"
    assert completions[0].description == "module os"
    assert completions[0].type == "module"
    assert completions[0].parent is None
    assert completions[0].full_name == "os.path"



# Generated at 2022-06-24 07:59:37.876436
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import os
    import jedi
    from jedi.parser_utils import get_statement_of_position

    _get_statement_of_position = (
        getattr(jedi.parser_utils, "get_statement_of_position", None)
        or get_statement_of_position
    )

    file_path = os.path.join(
        os.path.dirname(os.path.abspath(jedi.__file__)), "complete", "inheritance.py"
    )
    with open(file_path, "r", encoding="utf-8") as f:
        source = f.read()

    module = jedi.Script(source, column=1, line=1, path=file_path).module
    statement = _get_statement_of_position(module, (3, 5))
   

# Generated at 2022-06-24 07:59:48.194172
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    completion_name = completion.__getitem__("name")
    completion_complete = completion.__getitem__("complete")
    completion_type = completion.__getitem__("type")
    completion_description = completion.__getitem__("description")
    completion_parent = completion.__getitem__("parent")
    completion_full_name = completion.__getitem__("full_name")
    # If all the attributes of completion can be retrieved,
    # then the method __getitem__ is successful.
    assert completion_name == completion.name
    assert completion_complete == completion.complete
    assert completion_type == completion.type
    assert completion_description == completion.description
    assert completion_parent == completion.parent


# Generated at 2022-06-24 07:59:58.468988
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    def test(source, pos, expected_result):
        c = get_statement_of_position(parse_source(source), pos)
        assert c is not None
        assert c.start_pos == expected_result[0]
        assert c.end_pos == expected_result[1]

    test(
        """a = 2
          b = 3
          c = 5""",
        11,
        (8, 11),
    )  # with comments

    test(
        """
        a = 2
        b = 3

        def _(x):
            z = 3
            y = 4
            return x*y
        """,
        17,
        (17, 17),
    )  # in function


# Generated at 2022-06-24 08:00:03.399291
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module
    from parso import parse
    from parso.python.tree import Function
    from parso.python.tree import Class
    from parso.python.tree import If
    from parso.python.tree import For


# Generated at 2022-06-24 08:00:13.339758
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"
    assert len(completion) == 6

# Generated at 2022-06-24 08:00:19.044497
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        """
a = 1
a.
""",
        2,
        3,
        "foo.py",
    )
    assert completions[0].name == "strip"
    assert completions[1].name == "upper"
    assert completions[-1].name == "zfill"


# Generated at 2022-06-24 08:00:29.322555
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.base_context import ContextSet, Context, Evaluator, NO_CONTEXTS
    from jedi.evaluate.context import iterate_contexts
    import parso.python
    import parso
    import jedi.evaluate.filters
    import jedi.parser_utils
    import sys
    import os

    import jedi

    if _using_older_jedi(jedi):
        return

    script = parso.parse("import sys\nx = sys.path")
    
    #parent_scope = get_parent_scope
    module = script.get_root_node()
    name = script.children[1].children[0].children[0]
    pos = (2, 8)
    #definitions = jedi.evaluate.

# Generated at 2022-06-24 08:00:33.976386
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp=ThonnyCompletion("name","completion","type","description","parent","full_name")
    assert comp.name=="name"
    assert comp.complete == "completion"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"


# Generated at 2022-06-24 08:00:40.205305
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t_comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert t_comp["name"] == "name"
    assert t_comp["complete"] == "complete"
    assert t_comp["type"] == "type"
    assert t_comp["description"] == "description"
    assert t_comp["parent"] == "parent"
    assert t_comp["full_name"] == "full_name"

# Generated at 2022-06-24 08:00:49.976766
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import jedi

    class _Tests(unittest.TestCase):
        def test_some_completions(self):
            source = "class Foo:\n    def bar(self): pass\n\nFoo.bar()"
            completion_list = get_script_completions(source, 0, 0)
            self.assertIsInstance(completion_list, list)
            self.assertIsInstance(completion_list[0], ThonnyCompletion)
            self.assertEqual(completion_list[0]["name"], "Foo")
            self.assertEqual(completion_list[0]["complete"], "Foo")
            self.assertEqual(completion_list[0]["type"], "class")

# Generated at 2022-06-24 08:00:53.806659
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("__builti", 0, 1, None)
    assert len(result) > 0
    assert isinstance(result[0], ThonnyCompletion)
    assert result[0].complete.startswith("__builtin__")


# Generated at 2022-06-24 08:00:55.631912
# Unit test for function parse_source
def test_parse_source():
    src = 'import os\nx = "hello"\n'
    result = parse_source(src)
    assert len(result.children) == 2

# Generated at 2022-06-24 08:01:04.406471
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name = "completion.test.",
        complete = "name",
        type = "parso.python.tree.Name",
        description = "test(name, *, number = 0, *args, **kwargs)",
        parent = "test",
        full_name = "test_ThonnyCompletion.test",
    )
    assert completion.name == "completion.test."
    assert completion.complete == "name"
    assert completion.type == "parso.python.tree.Name"
    assert completion.description == "test(name, *, number = 0, *args, **kwargs)"
    assert completion.parent == "test"
    assert completion.full_name == "test_ThonnyCompletion.test"

    assert completion["name"] == "completion.test."

# Generated at 2022-06-24 08:01:11.216030
# Unit test for function parse_source
def test_parse_source():
    # No syntax error
    parse_source("x = 3\ny = 4")
    parse_source("def f(x):\n    return x+y")

    # Syntax errors
    try:
        parse_source("syntax error")
        assert False
    except Exception:
        pass

    try:
        parse_source("def f(x):\n    return x+y")
        assert False
    except Exception:
        pass



# Generated at 2022-06-24 08:01:17.656240
# Unit test for function get_script_completions
def test_get_script_completions():
    #    def func(a, b, c):
    #         pass
    #
    #    func(1, b=2,
    #         # <- cursor here, no completions
    #         )
    text = 'def func(a, b, c):\n    pass\n\nfunc(1, b=2,\n     # <- cursor here, no completions\n    )'
    assert not get_script_completions(text, 3, 10, "test.py", sys_path=None)



# Generated at 2022-06-24 08:01:24.406938
# Unit test for function parse_source
def test_parse_source():
    import parso, jedi
    # Testing jedi version < 0.18:
    assert parse_source == parso.parse

    # Testing jedi version >= 0.18:
    jedi.__version__ = "0.19.0"
    assert parse_source == parso.parse
    jedi.__version__ = "0.18.1"
    assert parse_source == parso.parse

    # Testing other jedi version:
    try:
        old = parso.parse
        del parso.parse
        assert parse_source != parso.parse
    except:
        pass