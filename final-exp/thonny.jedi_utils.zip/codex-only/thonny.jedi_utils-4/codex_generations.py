

# Generated at 2022-06-24 07:51:17.549233
# Unit test for function get_interpreter_completions

# Generated at 2022-06-24 07:51:18.686904
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:51:25.457767
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.parser import grammar
    from thonny import get_workbench

    get_workbench().unittest_mode_on()
    if _using_older_jedi(jedi):
        assert get_script_completions("", 1, 1, "") == []

    script = get_script_completions("import re", 1, 10, "")
    assert len(script) > 0

# Generated at 2022-06-24 07:51:35.397417
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statements

    result = get_script_completions("", 1, 1, "untitled")
    assert result == []

    source = dedent(
        """\
    import math
    math.sqrt(2)
    sq
    """
    )
    result = get_script_completions(source, 4, 3, "untitled")
    assert len(result) == 1
    assert result[0].name == "sqrt"

    result = get_script_completions(source, 4, 3, "untitled")
    assert result[0].parent == "math"
    assert result[0].full_name == "math.sqrt"

    source = dedent(
        """\
    import sys
    sys.path
    path
    """
    )
   

# Generated at 2022-06-24 07:51:39.321714
# Unit test for function get_script_completions
def test_get_script_completions():
    # kwargs not supported in 0.13 and 0.14
    assert get_script_completions("print(0)\n", 0, 6, "")


if __name__ == "__main__":
    test_get_script_completions()
    print("OK")

# Generated at 2022-06-24 07:51:49.316097
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions("", [], [])
    # noinspection PyProtectedMember
    assert len(completions) == len(jedi._jedi_framework.platform._builtin_names)
    assert isinstance(completions[0], ThonnyCompletion)

    completions = get_interpreter_completions("a=1", [], [])
    assert len(completions) == 1
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name == "a"
    assert completions[0].complete == "a="
    assert completions[0].full_name == '1'



# Generated at 2022-06-24 07:51:57.805647
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Test if returned results are in expected shape
    """
    import jedi

    if _using_older_jedi(jedi):
        source = "import json; json."
    else:
        source = "import json\njson."

    completions = get_script_completions(source, 2, len("json.") + 1, "test.py")
    assert isinstance(completions, list)
    assert len(completions) > 0
    for completion in completions:
        assert isinstance(completion, ThonnyCompletion)



# Generated at 2022-06-24 07:52:01.111742
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = 'import json\n json.l'
    namespaces = [{'json': json}]
    completions = get_interpreter_completions(source, namespaces)
    assert [c.name for c in completions] == ['loads', 'load']
    assert len(completions) == 2

# Generated at 2022-06-24 07:52:03.876428
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert "completions" in get_interpreter_completions("completions", [])

# Generated at 2022-06-24 07:52:11.553045
# Unit test for function parse_source
def test_parse_source():
    tree = parse_source("def foo():\n    pass")
    assert tree.type == 'file_input'
    assert len(tree.children) == 1
    assert tree.children[0].type == 'funcdef'
    assert tree.children[0].children[3].type == 'suite'
    assert len(tree.children[0].children[3].children) == 1
    assert tree.children[0].children[3].children[0].type == 'simple_stmt'


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:52:17.429764
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    C = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert C["name"] == "name"
    assert C["complete"] == "complete"
    assert C["type"] == "type"
    assert C["description"] == "description"
    assert C["parent"] == "parent"
    assert C["full_name"] == "full_name"



# Generated at 2022-06-24 07:52:23.309864
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.__getitem__("name") == "name"
    assert c.__getitem__("complete") == "complete"
    assert c.__getitem__("type") == "type"
    assert c.__getitem__("description") == "description"
    assert c.__getitem__("parent") == "parent"
    assert c.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:52:26.279734
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name = 1, complete = 2, type = 3, description = 4, parent = 5, full_name = 6)
    assert completion.name == 1
    assert completion.complete == 2
    assert completion.type == 3
    assert completion.description == 4
    assert completion.parent == 5
    assert completion.full_name == 6

# Generated at 2022-06-24 07:52:33.255491
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    for complete in ['foo', 'foo()', 'foo=']:
        tc = ThonnyCompletion(name='foo', complete=complete, type='type', description='desc', parent='parent', full_name='full_name')
        assert tc.name == 'foo'
        assert tc.complete == complete
        assert tc.type == 'type'
        assert tc.description == 'desc'
        assert tc.parent == 'parent'
        assert tc.full_name == 'full_name'

# Generated at 2022-06-24 07:52:42.876974
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import parso.utils
    # We don't need to cover everything, just a quick sanity check

    source = "def func():\n    print(\"abc\")"
    module = parso.parse(source)
    defs = module.children[0]
    print_node = defs.children[0].children[0]
    assert get_statement_of_position(module, 15) is print_node
    assert get_statement_of_position(module, 16) is print_node
    assert get_statement_of_position(module, 17) is print_node
    assert get_statement_of_position(module, 18) is print_node
    assert get_statement_of_position(module, 19) is print_node
    assert get_statement_of_position(module, 20) is print_node



# Generated at 2022-06-24 07:52:45.506797
# Unit test for function parse_source
def test_parse_source():
    source = "import math"
    node = parse_source(source)

    assert node.type == "file_input"
    assert node.get_code() == source


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:52:47.157516
# Unit test for function parse_source

# Generated at 2022-06-24 07:52:53.031735
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    source = """
# In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
# since 0.16 it does. Need to ensure similar result for all supported versions.
    """
    result = list(map(lambda completion: completion.__dict__, get_script_completions(source, 3, 4, "somemodule.py")))
    assert result[0]["complete"] == "map"



# Generated at 2022-06-24 07:53:00.121181
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    completions = get_interpreter_completions("import os\nos.", [], sys_path=[])
    assert len(completions) > 5
    assert isinstance(completions[0], ThonnyCompletion)

    if jedi.__version__[:4] not in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        return

    completions = get_interpreter_completions("import os\nos.sep", [], sys_path=[])
    assert len(completions) == 1
    assert isinstance(completions[0], ThonnyCompletion)



# Generated at 2022-06-24 07:53:10.003285
# Unit test for function get_script_completions
def test_get_script_completions():
    import textwrap
    import jedi

    source = textwrap.dedent(
        """
    def f(x, y):
        return
    def f2(x):
        return
    def f3(x, y, z):
        return
    def f4(x):
        return
    """
    )
    completions = get_script_completions(source=source, row=2, column=1, filename="m.py")
    assert len(completions) == 4
    names = [c.name for c in completions]
    assert "f" in names
    assert "f2" in names
    assert "f3" in names
    assert "f4" in names

    # in older Jedi versions (lower than 0.18) the completions are namedtuples

# Generated at 2022-06-24 07:53:14.095524
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def get_completions(source, row, column, filename):
        return get_script_completions(source, row, column, filename)


# Generated at 2022-06-24 07:53:15.164574
# Unit test for function get_definitions

# Generated at 2022-06-24 07:53:24.947151
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from unittest.mock import MagicMock

    has_test_dir = [{"testdir"}]
    has_test_dir2 = [{"testdir2"}]
    has_test_dir_testdir = [{"testdir"}, {"testdir", "testdir"}]

    orig_get_module_names = jedi.api.names.get_module_names
    jedi.api.names.get_module_names = MagicMock(
        side_effect=[has_test_dir, has_test_dir2, has_test_dir_testdir]
    )

    result = get_interpreter_completions("", [{}], sys_path=[])
    assert result == [{"name": "testdir", "complete": "testdir"}]

    result = get_interpreter_

# Generated at 2022-06-24 07:53:31.906941
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    for test_case in [
        ['a', 'a', '', '', '', 'a'],
        ['b=', 'b', '', '', '', 'b'],
    ]:
        completion = ThonnyCompletion(*test_case)
        assert completion['name'] == test_case[0]
        assert completion['complete'] == test_case[1]
        assert completion['type'] == test_case[2]
        assert completion['description'] == test_case[3]
        assert completion['parent'] == test_case[4]
        assert completion['full_name'] == test_case[5]

# Generated at 2022-06-24 07:53:35.580753
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        source="a = 5\n" "a.", row=2, column=3, filename="dummy.py"
    )

    assert "abs=" in [c.complete for c in completions]



# Generated at 2022-06-24 07:53:42.191845
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from random import randint\n\n" "randint\n"
    completions = get_script_completions(source, row=2, column=0, filename="")
    assert len(completions) == 1
    completion = completions[0]
    assert completion.name == "randint"
    assert completion.complete == "randint("
    assert completion.type == "statement"
    assert completion.description == "random.randint(${1:a}, ${2:b})"



# Generated at 2022-06-24 07:53:44.863423
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    obj = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert obj.name == obj["name"]

# Generated at 2022-06-24 07:53:51.458267
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.__getitem__("name") == 'name'
    assert c.__getitem__("complete") == 'complete'
    assert c.__getitem__("type") == 'type'
    assert c.__getitem__("description") == 'description'
    assert c.__getitem__("parent") == 'parent'
    assert c.__getitem__("full_name") == 'full_name'

# Generated at 2022-06-24 07:53:57.740437
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from textwrap import dedent

    # jedi < 0.17
    source = dedent(
        """\
    import sys
    import os
    
    
    # This can be used for
    print(sys.get
    """
    )

    completions = get_interpreter_completions(
        source, namespaces=[{"sys": sys}, {"os": os}]
    )
    assert len(completions) > 0
    assert completions[0].name == "getdefaultencoding"
    assert completions[0].complete == "getdefaultencoding"
    assert completions[0].parent == "sys"



# Generated at 2022-06-24 07:54:07.447969
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import PythonNode

    node1 = PythonNode(type="a", start_pos=1, end_pos=2)
    node2 = PythonNode(type="b", start_pos=3, end_pos=4)
    node3 = PythonNode(type="c", start_pos=5, end_pos=6)

    node1.children = [node2]
    node2.parent = node1
    node2.children = [node3]
    node3.parent = node2

    assert get_statement_of_position(node1, 3) is node2
    assert get_statement_of_position(node1, 5) is node3
    assert get_statement_of_position(node1, 2) is None
    assert get_statement_of_position(node1, 4) is None
   

# Generated at 2022-06-24 07:54:10.731727
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# jedi 0.15 didn't have goto_assignments() method
# in jedi 0.16 it was added to Script

# Generated at 2022-06-24 07:54:14.431727
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import Interpreter
    import jedi

    assert isinstance((_tweak_completions(Interpreter.test_completions())), list) == True


# Generated at 2022-06-24 07:54:15.685322
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('print("hello")')


# Generated at 2022-06-24 07:54:16.642046
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso


# Generated at 2022-06-24 07:54:24.006111
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree as parso_tree

    def create_statement(name, start, end):
        node = parso_tree.Leaf(name, start, end)
        node.children = []
        node._parent = None
        return node

    def create_suite(name, start, end, children):
        node = create_statement(name, start, end)
        node.children = children
        for child in children:
            child._parent = node
        return node

    a = create_statement("a", (1, 0), (1, 1))
    b = create_statement("b", (2, 0), (2, 1))
    c = create_statement("c", (3, 0), (3, 1))
    d = create_statement("d", (4, 0), (4, 1))
   

# Generated at 2022-06-24 07:54:28.971603
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    tree1 = parse_source("x = 1")
    assert isinstance(tree1, tree.Module)

    def f():
        pass

    tree2 = parse_source(f.__code__.co_code)
    assert isinstance(tree2, tree.Module)

# Generated at 2022-06-24 07:54:37.458664
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.cpython.test_run.test_run_thonny import _get_interpreter_completions

    def check(source, expected_names):
        completions = get_interpreter_completions(source, [{}])
        result = _get_interpreter_completions(completions)
        assert result == expected_names

    check("", [])

# Generated at 2022-06-24 07:54:37.995019
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:54:44.524141
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print(get_interpreter_completions("class A: pass\nA.", []))
    print(get_interpreter_completions("class A: def f(self): pass\nA(1).f.", []))
    print(get_interpreter_completions("import math\nmath.", []))
    print(get_interpreter_completions("import math\nmath.pow.", []))
    print(get_interpreter_completions("def f(x): pass\nf.", []))
    print(get_interpreter_completions("import logging\nlogging", []))

# Generated at 2022-06-24 07:54:48.222273
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )["name"] == "name"



# Generated at 2022-06-24 07:54:54.745136
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def check(expected, source, row, column, filename=None, sys_path=None):
        result = get_script_completions(source, row, column, filename, sys_path=sys_path)
        # print(result)
        assert set(c.name for c in result) == set(expected)

    check(["filename"], """
import os
os.path.basename(r"c:\\test")
""", 2, 23)

    check(["filename"], """
import os
os.path.basename(r"c:\\test")
""", 2, 23, "test.py")

    check(["filename"], """
import os
os.path.basename(r"c:\\test")
""", 2, 23, filename="test.py", sys_path=[])

    # check

# Generated at 2022-06-24 07:54:57.873850
# Unit test for method __getitem__ of class ThonnyCompletion

# Generated at 2022-06-24 07:55:07.460297
# Unit test for function get_script_completions
def test_get_script_completions():
    from parso.python.tree import ImportFrom
    from parso.utils import get_cached_code_lines

    def _assert_script_completions_equals(
        self,
        source,
        result_set,
        expected_set,
        script_path=None,
        sys_path=None,
        column_offset=0,
    ):
        if script_path is not None:
            completions = get_script_completions(
                source=source,
                row=0,
                column=0,
                filename=script_path,
                sys_path=sys_path,
            )

# Generated at 2022-06-24 07:55:15.264705
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree
    source = 'def foo():\n    print(x)\nfoo()'
    row = 1
    column = 11
    filename = '<unknown>'
    defs = get_definitions(source, row, column, filename)
    assert defs[0].as_string() == 'def foo():\n    print(x)\nfoo()\n'
    assert isinstance(defs[0].parent, tree.Module)
    assert defs[0].name == 'foo'
    assert defs[0].type == 'function'
    assert defs[0].full_name == 'foo'
    source = 'import math\nx = math.log(10)'
    row = 2
    column = 9
    filename = '<unknown>'

# Generated at 2022-06-24 07:55:16.190736
# Unit test for function parse_source

# Generated at 2022-06-24 07:55:22.315617
# Unit test for function get_definitions
def test_get_definitions():
    definitions = get_definitions(
        'import tkinter as tk\n'
        'import math\n'
        'tk.Button()\n'
        'math.log(1)\n',
        3,
        6,
        'test.py'
    )

    assert len(definitions) == 2
    assert definitions[0].full_name == "tkinter.Button"
    assert definitions[1].full_name == "math.log"

# Generated at 2022-06-24 07:55:24.904257
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    assert get_statement_of_position(object(), 0).type == tree.Statement.ILLEGAL

# Generated at 2022-06-24 07:55:29.685291
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert get_statement_of_position(
        parse_source("def foo(): pass; foo"), (0, 10)
    ) is None
    assert get_statement_of_position(
        parse_source("def foo(): pass; foo"), (0, 12)
    ) is not None
    assert get_statement_of_position(
        parse_source("def foo(): pass; foo"), (0, 11)
    ) is None

# Generated at 2022-06-24 07:55:30.763044
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

# Generated at 2022-06-24 07:55:37.125594
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # TODO: check all possible cases of * with *
    # TODO: check with decorators
    assert get_statement_of_position(
        parse_source("a=b+c\n"),
        (2, 0)
    ) is None
    assert get_statement_of_position(
        parse_source("a=b+c\n"),
        (1, 4)
    ) is None

    from parso.python import tree

    main_stmt = get_statement_of_position(parse_source("a=b+c\nd=e+f\n"), (1, 0))
    assert isinstance(main_stmt, tree.ExprStmt)
    assert isinstance(main_stmt.children[0].children[0], tree.Assignment)

    main_stmt = get_statement_of_

# Generated at 2022-06-24 07:55:40.621955
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.script import Script
    from jedi import jedi

    script = Script("import os; os.", 1, 9, "test.py")
    if _using_older_jedi(jedi):
        completions = script.completions()
    else:
        completions = script.complete()

    assert len(completions) > 0


# Generated at 2022-06-24 07:55:44.006780
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import random
    import string

    test_string = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    completion = ThonnyCompletion(test_string, test_string, test_string,
                                  test_string, test_string, test_string)

    assert completion['name'] == test_string

# Generated at 2022-06-24 07:55:48.368776
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = "def test(a, b):\n return a + b"
    tree = parse_source(source)
    assert isinstance(tree, parso.python.tree.Module)

# Generated at 2022-06-24 07:55:57.236315
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # copy of jedi.tests.test_parser_utils.test_get_statement_of_position
    def _check(source, row, column, expected_type=None, expected_value=None):
        node = parse_source(source)
        assert node
        result_node = get_statement_of_position(node, (row, column))
        result_type = result_node.type
        result_value = result_node.value
        if expected_type:
            assert result_type == expected_type, (result_type, expected_type)
            if expected_value:
                assert result_value == expected_value

    _check('if True:\n    x = 10', 2, 5, 'simple_stmt')

# Generated at 2022-06-24 07:55:59.683508
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    source = "a = 1"
    result = parse_source(source)
    assert isinstance(result,Module)

# Generated at 2022-06-24 07:56:06.681408
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from unittest.mock import Mock

    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion.__getitem__("name") == "name"

# Generated at 2022-06-24 07:56:14.285242
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class TestCase(unittest.TestCase):
        def test_from_import(self):
            source = """from datetime import datetime
dt = datetime.now()
dt.date()
"""
            symbols = get_definitions(source, 3, 9, "")
            self.assertEquals(1, len(symbols))
            self.assertEquals("from datetime import datetime", symbols[0].module_name)

    unittest.main(module="test_get_statements", exit=False, verbosity=1)



# Generated at 2022-06-24 07:56:20.370295
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'

# Generated at 2022-06-24 07:56:29.250365
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest

    # Unit test for function get_script_completions
    class TestScriptCompletions(unittest.TestCase):
        def test_script_completions_1(self):
            """Test that the list of completion contains at least the word 'str'"""
            list_dict = get_script_completions("str", 0, 0, "")
            test_passed = False
            for value in list_dict:
                if "str" in value['name']:
                    test_passed = True
            self.assertTrue(test_passed)

        def test_script_completions_2(self):
            """Test that the list of completion contains at least the word 'str'"""
            list_dict = get_script_completions("'string'", 0, 0, "")
            test

# Generated at 2022-06-24 07:56:40.038150
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import jedi.api

    if _using_older_jedi(jedi):
        script = jedi.Script("import a", 0, 9, "test.py")
        completions = script.completions()
    else:
        script = jedi.Script(code="import a", path="test.py")
        completions = script.complete(line=0, column=9)
    assert isinstance(completions, list)
    assert isinstance(completions[0], jedi.api.classes.Completion)
    assert completions[0].type == "import"
    assert completions[0].complete == "abc"
    assert completions[0].name == "abc"
    assert completions[0].parent.name == "a"



# Generated at 2022-06-24 07:56:45.305674
# Unit test for function get_script_completions
def test_get_script_completions():

    from jedi.api.interpreter import Interpreter
    from jedi.api.project import jedi_path
    from jedi import Script

    sources = [
        'from thonny import',
        'from threading import',
        'from operator import',
        'from _thread import',
        'from _operator import',
        'import thonny',
        'import threading',
        'import operator',
        'import _thread',
        'import _operator',
    ]


# Generated at 2022-06-24 07:56:54.642809
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    # test for source like
    # if 10 == 20:
    #     print(10)
    #     print(20)
    #
    # should return the whole suite if pos is in the suite
    # should return the whole first print(10) if pos is in it
    # should return the whole second print(20) if pos is in it
    # should return nothing when pos is outside the suite
    source = "if 10 == 20:\n    print(10)\n    print(20)\n"
    ast_tree = parse_source(source)
    statements = ast_tree.children
    if_suite_statement = statements[1]
    if_condition_statement = statements[1].children[0]
    first_print_statement = statements[1].children[1]
    second_print_statement

# Generated at 2022-06-24 07:56:59.046328
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    text = "import math\nmath.f"
    completions = get_interpreter_completions(text, [locals()], None)

    completions_old = Interpreter(text, locals()).completions()
    assert len(completions) == len(completions_old), "%d != %d" % (
        len(completions),
        len(completions_old),
    )
    assert all(c.name == oc.name for c, oc in zip(completions, completions_old))



# Generated at 2022-06-24 07:57:02.452948
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    compl = get_interpreter_completions(
        "le", [{"locals": {"le": Mock(spec=["__name__", "__file__"])}}]
    )
    assert len(compl) == 1 and compl[0].name == "le"

# Generated at 2022-06-24 07:57:09.769869
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'name'
    complete = 'complete'
    type = 'type'
    description = 'description'
    parent = 'parent'
    full_name = 'full_name'
    
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    
    if tc['name'] == name and tc['complete'] == complete and tc['type'] == type and tc['description'] == description and tc['parent'] == parent and tc['full_name'] == full_name:
       print('Success')
    else:
       print('Failure')

# Generated at 2022-06-24 07:57:13.657330
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    node = parse_source("a = 1")
    position = get_statement_of_position(node, (1, 0))
    assert isinstance(position, tree.ExprStmt)



# Generated at 2022-06-24 07:57:23.649803
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("a","b","c","d","e","f").name == "a"
    assert ThonnyCompletion("a","b","c","d","e","f").complete == "b"
    assert ThonnyCompletion("a","b","c","d","e","f").type == "c"
    assert ThonnyCompletion("a","b","c","d","e","f").description == "d"
    assert ThonnyCompletion("a","b","c","d","e","f").parent == "e"
    assert ThonnyCompletion("a","b","c","d","e","f").full_name == "f"

# Generated at 2022-06-24 07:57:29.327050
# Unit test for function get_definitions
def test_get_definitions():
    def f1(x, y):
        print(x, y)

    class Foo:
        pass

    assert len(get_definitions(f1.__code__.co_code, 2, 10, "test.py")) == 1
    assert len(get_definitions(Foo.__init__.__code__.co_code, 2, 10, "test.py")) == 1

# Generated at 2022-06-24 07:57:36.478821
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """jedi 0.15 and 0.16 has different behaviour for Interpreter objects"""
    logging.basicConfig(level=logging.INFO)

    import jedi

    if not _using_older_jedi(jedi):
        print("Skipping test_get_interpreter_completions")
        return

    source = "import datetime; datetime.da"
    result = get_interpreter_completions(source, [])
    assert len(result) > 1, result

# Generated at 2022-06-24 07:57:43.529206
# Unit test for function get_script_completions
def test_get_script_completions():
    import pathlib
    import parso.python.tree

    from . import jedi_utils

    filename = "/home/user/example.py"
    source = "a = 10\na."
    row = 3
    column = 3

    jedi_version = jedi.__version__
    node = parse_source(source)
    script_completions = jedi_utils.get_script_completions(source, row, column, filename)

    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, filename)
        completions = script.completions()
        completions_contain_name = []
        for completion in completions:
            completions_contain_name.append(completion.name)
        statement = jedi.parser_utils.get_

# Generated at 2022-06-24 07:57:46.175627
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp_test = ThonnyCompletion('a', 'a', 'simple_stmt', 'a', 'a', 'a')
    assert comp_test.name == 'a' and comp_test.complete == 'a' and \
        comp_test.type == 'simple_stmt' and comp_test.description == 'a' and \
        comp_test.parent == 'a' and comp_test.full_name == 'a'



# Generated at 2022-06-24 07:57:57.788931
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    def _check_result(code, row, column, filename, sys_path):
        completions = get_script_completions(code, row, column, filename, sys_path)

        found = [
            (c["name"], c["complete"]) for c in completions if c["name"] in ["print", "x"]
        ]
        if _using_older_jedi(jedi):
            assert found == [("print", "print"), ("x", "x")]
        else:
            assert found == [("print", "print"), ("x", "x=")]

    _check_result("x = 1\nprint(x)", 2, 6, "tempfile", [])
    _check_result("x = 1\nprint(x)", 2, 6, "tempfile", ["."])


# Unit

# Generated at 2022-06-24 07:58:04.752753
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    expected_attrs = ["name", "complete", "type", "description", "parent", "full_name"]
    for attr in expected_attrs:
        assert hasattr(ThonnyCompletion("name", "complete", "type", "desc", "parent", "full"), attr)
    assert not hasattr(ThonnyCompletion("name", "complete", "type", "desc", "parent", "full"), "x")
    def get_attrs(ci):
        return list(ci.__dict__.keys())
    assert get_attrs(ThonnyCompletion("name", "complete", "type", "desc", "parent", "full")) == expected_attrs

# Generated at 2022-06-24 07:58:10.282255
# Unit test for function parse_source
def test_parse_source():
    source = """\
# This is a comment
# This is another comment
x = 1
"""
    tree = parse_source(source)
    assert tree.get_code() == source
    # code block
    assert tree.type == "<module>"
    # 'x = 1'
    assert tree.children[-1].type == "simple_stmt"


# Generated at 2022-06-24 07:58:18.809117
# Unit test for function get_definitions
def test_get_definitions():
    # test dunder methods
    assert get_definitions("class A:\n    def __init__", 1, 20, "foo.py")[0].type == "function"
    assert get_definitions("class A:\n    def __init__", 1, 20, "foo.py")[0].name == "__init__"
    assert get_definitions("class A:\n    def __enter__", 1, 20, "foo.py")[0].type == "function"
    assert get_definitions("class A:\n    def __enter__", 1, 20, "foo.py")[0].name == "__enter__"
    assert get_definitions("class A:\n    def __exit__", 1, 20, "foo.py")[0].type == "function"

# Generated at 2022-06-24 07:58:26.096090
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    source = """class A:\n"""
    row = 0
    column = len(source)
    filename = "<instance>"
    script = jedi.Script(source, row, column, filename)
    completions = script.completions()
    for completion in completions:
        tc = ThonnyCompletion(
            name=completion.name,
            complete=completion.complete,
            type=completion.type,
            description=completion.description,
            parent=completion.parent,
            full_name=completion.full_name,
        )
        assert completion.name == tc.name
        assert completion.complete == tc.complete
        assert completion.type == tc.type
        assert completion.description == tc.description
        assert completion.parent == tc.parent
        assert completion.full_name

# Generated at 2022-06-24 07:58:35.553863
# Unit test for function get_definitions
def test_get_definitions():
    from asynctest import TestCase as AsyncTestCase, mock as async_mock
    from jedi import Script
    from jedi.api.classes import Name, Definition

    def mock_goto_definitions(self, *args, **kwargs):
        class MockClass:
            def __init__(self, parent):
                self.parent = parent
                self.parent_context = parent.parent_context
                self.string_name = parent.string_name

            def __getitem__(self, key):
                return self.__dict__[key]

            def __iter__(self):
                return iter(self.__dict__.values())

            def __setitem__(self, key, value):
                self.__dict__[key] = value


# Generated at 2022-06-24 07:58:39.592889
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion("__foo__", "__foo__", "__foo__", "__foo__", "__foo__", "__foo__")
    assert thonny_completion["name"] == "__foo__"
    assert thonny_completion["complete"] == "__foo__"
    assert thonny_completion["type"] == "__foo__"
    assert thonny_completion["description"] == "__foo__"
    assert thonny_completion["parent"] == "__foo__"
    assert thonny_completion["full_name"] == "__foo__"


# Generated at 2022-06-24 07:58:44.762886
# Unit test for function get_script_completions
def test_get_script_completions():
    # This is copied from jedi
    # https://github.com/davidhalter/jedi/blob/9f3a2f93c48eda24e2dcc25e54eb7cc10aa73848/test/test_completion.py#L87
    code = "import datetime\ndatetime."
    completions = get_script_completions(code, 2, 13, "example.py")
    for name in ("date", "datetime", "timedelta", "time"):
        assert name in [c.name for c in completions]


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 07:58:53.962003
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi

    def get_completions(source: str, namespace, sys_path=None):
        return get_interpreter_completions(source, namespace, sys_path)

    # jedi 0.17
    namespace = [{"str": str , "Interpreter" : Interpreter}]
    result = get_completions("str.is", namespace)
    assert(result[0].name == "isascii")
    assert(result[0].complete == "isascii")
    assert(result[0].type == "function")

    # jedi > 0.17
    result = get_completions("Interpreter.complete", namespace)
    assert(result[0].name == "complete")
    assert(result[0].complete == "complete")


# Generated at 2022-06-24 07:58:55.179487
# Unit test for function parse_source

# Generated at 2022-06-24 07:59:04.904978
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from thonny.languages import tr_code

    source = "import math\n" "print(math.pi)"
    expected = [
        Completion(name="print", complete="print(", type="function", description="print"),
        Completion(
            name="import",
            complete="import",
            type="keyword",
            description="import ... as ...",
        ),
    ]
    actual = get_script_completions(source, 2, 7, "abc.py")

    print_nicely(expected == actual, "expected == actual")
    print_nicely(expected[0].name == actual[0].name, expected[0].name + "==" + actual[0].name)

# Generated at 2022-06-24 07:59:14.304942
# Unit test for function get_script_completions
def test_get_script_completions():
    import pytest
    from jedi import api
    jedi.set_debug_function()

    assert get_script_completions("", 1, 2, "test_mod.py") == []
    assert get_script_completions("import", 1, 7, "test_mod.py") == []
    assert get_script_completions("import ", 1, 8, "test_mod.py") == []
    assert get_script_completions("import ", 1, 8, "test_mod.py") == []
    assert get_script_completions("import ma", 1, 8, "test_mod.py") == []
    assert get_script_completions("import ma", 1, 8, "test_mod.py") == []

# Generated at 2022-06-24 07:59:19.385720
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import parso
    import jedi.parser_utils

    if hasattr(jedi.parser_utils, "get_statement_of_position"):
        return

    class _JediTestCase(unittest.TestCase):
        def get_statement(self, source, pos):
            node = parso.parse(source)
            return _copy_of_get_statement_of_position(node, pos)


# Generated at 2022-06-24 07:59:23.339809
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    obj = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert obj.name == "name"
    assert obj.complete == "complete"
    assert obj.type == "type"
    assert obj.description == "description"
    assert obj.parent == "parent"
    assert obj.full_name == "full_name"

# Generated at 2022-06-24 07:59:23.712595
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:59:24.977707
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-24 07:59:35.135544
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    interpreter = jedi.Interpreter("import string; string.", [{}])

# Generated at 2022-06-24 07:59:41.767440
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import sys
    import jedi

    if sys.version_info >= (3, 7):
        completion = jedi.Script("a", 2, 3, "filename").completions()[0]
    else:
        completion = jedi.Script("a", 2, 3, "filename").completions(True)[0]

    new_completion = ThonnyCompletion(name=completion.name, complete=completion.complete, type=completion.type, description=completion.description, parent=completion.parent, full_name=completion.full_name)

    assert completion.name == new_completion.name
    assert completion.complete == new_completion.complete
    assert completion.type == new_completion.type
    assert completion.description == new_completion.description
    assert completion.parent == new_completion

# Generated at 2022-06-24 07:59:45.758782
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    result = thonnyCompletion.__getitem__("name")
    assert result == "name"


# Generated at 2022-06-24 07:59:49.666720
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    assert isinstance(get_definitions("x", 0, 0, "f.py"), list)
    assert isinstance(get_definitions("x", 0, 0, "f.py")[0], jedi.api.classes.BaseDefinition)



# Generated at 2022-06-24 07:59:56.551022
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    dict_test = {'name': 'name', 'complete': 'complete', 'type': 'type', 'description': 'description',
                 'parent': 'parent', 'full_name': 'full_name'}
    thonnycom = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    for x in dict_test.keys():
        assert dict_test[x] == thonnycom[x]



# Generated at 2022-06-24 08:00:00.626810
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    completions = get_script_completions("import", 0, 7, '')
    assert len(completions) > 0


# Generated at 2022-06-24 08:00:12.039160
# Unit test for function get_script_completions
def test_get_script_completions():
    def _test(source, row, column, expected_completions):
        result = get_script_completions(source, row, column, filename="test_file.py")
        assert len(result) == len(expected_completions), (
            "expected %d, got %d completions" % (len(expected_completions), len(result))
        )
        for i, completion in enumerate(result):
            assert completion.name == expected_completions[i]

    _test("def f():\n    pass\n\nf", 4, 0, ["f()"])
    _test("def f():\n    pass\n\nf", 4, 1, ["f()"])
    _test("def f():\n    pass\n\nf", 4, 2, [])
    _test

# Generated at 2022-06-24 08:00:20.022192
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    from parso.python import tree
    node = tree.Module('')
    node.children = [tree.ExprStmt('')]
    inner_node = node.children[0]

    t = get_statement_of_position(node, 0)
    # node.children = [tree.ExprStmt(continuation=True)]
    assert t == inner_node
    # print(node.__dict__)


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-24 08:00:23.283756
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import sys; sys.", 0, 12, 'test.py')
    # Check that completions with no prefix (which are all "imports" in this case)
    # are not included in the result
    assert len(completions) == 0

# Generated at 2022-06-24 08:00:27.410839
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
	ThonnyCompletion(name="xyz",
					complete="xyz",
					type=0,
					description="abc",
					parent=None,
					full_name="qwerty")

# Generated at 2022-06-24 08:00:35.205184
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python

    # TODO: test weird cases from
    # https://github.com/davidhalter/jedi/blob/5c6d5b6c9b6dc4e6ee4f09ffb18d54b77f6544e6/jedi/parser_utils.py#L150-L192

    def _check(source, pos, result):
        match = get_statement_of_position(parse_source(source), pos)
        assert match.start_pos <= pos <= match.end_pos
        # print(match)
        assert match.get_code() == result


# Generated at 2022-06-24 08:00:38.145235
# Unit test for function parse_source
def test_parse_source():
    # I.e. Test that it works with both Parso 0.8.1 and 0.7.1
    assert parse_source("3 + 5").startswith("Module")



# Generated at 2022-06-24 08:00:48.771376
# Unit test for function parse_source
def test_parse_source():
    import parso, sys

    def print_tree(node, indent=""):
        print(indent, node.type)
        for c in node.children:
            print_tree(c, indent + "   ")

    my_source = "def foo(x):\n    return x\n\ndef bar(a):\n    return a * 2\n"
    module = parse_source(my_source)
    print_tree(module)

    # now try with parso directly
    module = parso.parse(my_source)
    print_tree(module)

    # test that the objects are isomorphic
    def compare(n1, n2):
        for name in dir(n1):
            if not name.startswith("_"):
                val1 = getattr(n1, name)
                val2

# Generated at 2022-06-24 08:00:55.766925
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "impo"
    completions = get_script_completions(source, 0, 0, "test", [])
    assert len(completions) > 0
    assert type(completions) == list
    assert type(completions[0]) == ThonnyCompletion
    assert completions[0].name == "rt"
    assert completions[0].complete == "mport"
    assert completions[0].description == "import"
    assert completions[0].type == "keyword"
    assert completions[0].parent is None
    assert completions[0].full_name == "import"

# Generated at 2022-06-24 08:00:58.577749
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        """import os, sys
 
print(o""",
        2,
        11,
        filename="<input>",
    )
    assert len(completions) == 1
    assert completions[0].name == "os"


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 08:01:02.259862
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    root = parse_source("x = 5")
    assert isinstance(root, Module)
    assert root.children[0].start_pos == (1, 0)
    assert root.children[0].end_pos == (1, 5)

# Generated at 2022-06-24 08:01:12.795187
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from . import jediutils
    from unittest import mock

    saved_get_interpreter_completions = jediutils.get_interpreter_completions

    for version in ("0.13", "0.14", "0.15", "0.16", "0.17", "0.18", "0.19", "0.20"):
        jediutils.get_interpreter_completions = mock.Mock(return_value=(version,))

        result, = jediutils.get_interpreter_completions("", [], None)
        assert result == version

    jediutils.get_interpreter_completions = saved_get_interpreter_completions

# Generated at 2022-06-24 08:01:15.251141
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "import a.b; a.b"
    assert isinstance(parse_source(source), parso.python.tree.Module)

# Generated at 2022-06-24 08:01:23.390877
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    class ParserHelper:
        def __init__(self):
            self.module = parse_source("\n\nx = 1\ny = 2\nzzz = 3\n\n")

        def get_position_tree_node(self, row, column):
            return _copy_of_get_statement_of_position(self.module, (row, column))

    # Position is after line of code
    ph = ParserHelper()
    assert ph.get_position_tree_node(2, 5) == ph.module.children[1]
    # Position is on line of code
    ph = ParserHelper()
    assert ph.get_position_tree_node(2, 1) == ph.module.children[1]
    # Position is on line in between code
    ph = Pars