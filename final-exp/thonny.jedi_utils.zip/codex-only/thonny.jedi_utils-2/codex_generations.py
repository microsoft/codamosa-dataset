

# Generated at 2022-06-24 07:50:49.123750
# Unit test for function get_script_completions
def test_get_script_completions():
    from mypy.test.config import test_temp_dir
    from mypy.test.data import DataDrivenTestCase, DataSuite
    from mypy.test.helpers import assert_string_arrays_equal
    import os

    class JediCompletionTest(DataDrivenTestCase):
        def run_test(self) -> None:
            script = self.input
            pos = self.pos
            row = self.row
            column = self.column
            expected = self.output
            filename = "main.py"
            results = [completion.name for completion in get_script_completions(script, row, column, filename)]

# Generated at 2022-06-24 07:50:53.052254
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    a = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    if a.name != 'name' : return False
    if a.complete != 'complete' : return False
    if a.type != 'type' : return False
    if a.description != 'description' : return False
    if a.parent != 'parent' : return False
    if a.full_name != 'full_name' : return False
    return True

# Generated at 2022-06-24 07:50:59.341705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import os"
    namespaces = [{"__name__": "__main__", "os": "dummy"}]
    completions = get_interpreter_completions(source, namespaces)
    assert isinstance(completions, list)
    assert len(completions)>0
    assert isinstance(completions[0], ThonnyCompletion)
    assert completions[0].name
    assert completions[0].complete
    assert completions[0].type
    assert completions[0].description
    assert completions[0].parent

# Generated at 2022-06-24 07:51:08.842525
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import LEAF
    from parso.python.tree import Node

    def _assert_node_type(node, node_type):
        assert node == node_type, node

    # Testing syntax error
    try:
        parse_source("foo =")
        assert False, "Do not execute this line"
    except SyntaxError as e:
        assert e.text == "foo =\n"
        assert e.msg == "invalid syntax"
        assert e.lineno == 1
        assert e.offset == 4

    # Testing node types
    node = parse_source("foo = None")
    _assert_node_type(node.type, "file_input")
    _assert_node_type(node.children[0].type, "simple_stmt")

# Generated at 2022-06-24 07:51:17.465641
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    import unittest
    import unittest.mock

    test_dir = os.path.dirname(__file__)

    class TestCase(unittest.TestCase):
        @unittest.mock.patch("sys.path", [test_dir])
        def test_get_definitions(self):
            from thonny.plugins.jedi_backend.utils import get_definitions


# Generated at 2022-06-24 07:51:22.692171
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import sys
import os

print(os)

"""
    from thonny.misc_utils import running_on_mac_or_linux

    if not running_on_mac_or_linux():
        raise RuntimeError("test only works on Mac/Linux")
    completions = get_script_completions(source, 3, 6, "test.py")
    assert len(completions) == 1
    completion = completions[0]
    assert completion["name"] == "os"
    assert completion["complete"] == "os"



# Generated at 2022-06-24 07:51:28.217209
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion(name="__main__", complete="__main__", type="a", description="", parent="", full_name="")
    assert comp["name"] == "__main__"
    assert comp["complete"] == "__main__"
    assert comp["type"] == "a"
    assert comp["description"] == ""
    assert comp["parent"] == ""
    assert comp["full_name"] == ""

# Generated at 2022-06-24 07:51:38.987276
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name_ThonnyCompletion_class"
    complete = "complete_ThonnyCompletion_class"
    type = "type_ThonnyCompletion_class"
    description = "description_ThonnyCompletion_class"
    parent = "parent_ThonnyCompletion_class"
    full_name = "full_name_ThonnyCompletion_class"
    obj = ThonnyCompletion(
        name=name, complete=complete, type=type, description=description, parent=parent, full_name=full_name
    )

    assert obj["name"] == name
    assert obj["complete"] == complete
    assert obj["type"] == type
    assert obj["description"] == description
    assert obj["parent"] == parent
    assert obj["full_name"] == full_name

# Generated at 2022-06-24 07:51:49.850477
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock
    source = "def bar():\n    return 42\nbar()"
    row, column = 1, 4

    def mock_jedi_version(jedi):
        jedi.__version__ = "0.17"
        
    with unittest.mock.patch("jedi.Script", autospec=True) as jedi_script_mock:
        with unittest.mock.patch("jedi.__version__", "0.17"):
            get_definitions(source, row, column, "")
    jedi_script_mock.assert_called_once_with(source, row, column, "")
    jedi_script_mock.return_value.goto_definitions.assert_called_once_with()


# Generated at 2022-06-24 07:51:51.202390
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('print()')

# Generated at 2022-06-24 07:51:55.800198
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc1.name == "name"
    assert tc1.complete == "complete"
    assert tc1.type == "type"
    assert tc1.description == "description"
    assert tc1.parent == "parent"
    assert tc1.full_name == "full_name"

# Generated at 2022-06-24 07:52:01.340423
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "TEST_NAME"
    complete = "TEST_COMPLETE"
    type = "TEST_TYPE"
    description = "TEST_DESCRIPTION"
    parent = "TEST_PARENT"
    full_name = "TEST_FULL_NAME"

    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert tc.name == name
    assert tc.complete == complete
    assert tc.type == type
    assert tc.description == description
    assert tc.full_name == full_name

# Generated at 2022-06-24 07:52:02.692461
# Unit test for function parse_source

# Generated at 2022-06-24 07:52:12.723510
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import ast
    import parso.tree
    from jedi.evaluate.compiled.subprocess import FakeName

    source = "import time\ntime.sleep(5)"
    root_node = parso.parse(source)
    time_sleep = root_node.children[1].children[1]
    time_sleep_call = time_sleep.children[1]
    time_sleep_cal = time_sleep_call.children[1]
    time_sleep_call_arg = time_sleep_cal.children[0]
    time_sleep_arg = ast.parse("5").body[0].value

# Generated at 2022-06-24 07:52:15.046392
# Unit test for function get_definitions
def test_get_definitions():
    source = """
import threading
threading.Thread"""

    print(get_definitions(source, 2, 14, "test.py"))

# Generated at 2022-06-24 07:52:23.460457
# Unit test for function parse_source
def test_parse_source():
    import parso

    for code in (
        ("if True:\n" "    x=10\n"),
        ("if True:\n" "    pass\n"),
        ("if True:\n" "    pass\n"),
        ("try:\n" "    pass\n" "except:\n" "    pass\n"),
        ("class C1:\n" "    pass\n"),
        ("def foo():\n" "    pass\n"),
        ("for i in [1,2,3]:\n" "    print(i)\n" "\n" "for i in [1,2,3]:\n" "    print(i)\n"),
    ):
        assert isinstance(parse_source(code), parso.python.tree.Module)

# Generated at 2022-06-24 07:52:28.597697
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:52:38.975572
# Unit test for function get_definitions
def test_get_definitions():
    import parso

    source = "from tkinter import *"
    result = get_definitions(source, 0, 16, "")
    assert len(result) == 1
    assert result[0].module_path == "tkinter"
    assert result[0].description == "Tkinter"

    source = "from tkinter import *; Button()"
    result = get_definitions(source, 0, 16, "")
    assert len(result) == 1
    assert result[0].module_path == "tkinter"
    assert result[0].description == "Tkinter"
    result = get_definitions(source, 0, 28, "")
    assert len(result) == 1
    assert result[0].module_path == "tkinter"

# Generated at 2022-06-24 07:52:41.935432
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent=None,
        full_name="full_name",
    )

# Generated at 2022-06-24 07:52:42.716792
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("1")

# Generated at 2022-06-24 07:52:47.760802
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions("import json", [], None)
    assert len(result) > 0
    result = get_interpreter_completions("import json; json.dump", [], None)
    assert len(result) > 0
    result = get_interpreter_completions("import json; json.dump(o", [], None)
    assert len(result) > 0
    result = get_interpreter_completions("import json; json.dump(o,", [], None)
    assert len(result) > 0

# Generated at 2022-06-24 07:52:50.958232
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert _using_older_jedi(jedi)
    assert len(get_interpreter_completions("import numpy as np\n np.arra", ["{}"])) > 0

# Generated at 2022-06-24 07:52:58.257958
# Unit test for function get_script_completions
def test_get_script_completions():
    def run_tests(completions):
        assert len(completions) > 1
        assert any(c["name"] == "abs" for c in completions)

    run_tests(get_script_completions("abs", 0, 3, "_dummy_path_"))
    run_tests(get_script_completions("abs", 0, 1, "_dummy_path_"))
    run_tests(get_script_completions("abs", 0, 0, "_dummy_path_"))
    run_tests(get_script_completions("abs(", 0, 3, "_dummy_path_"))




# Generated at 2022-06-24 07:53:07.373281
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import os", row=0, column=7, filename="")
    assert len(completions) > 0
    completions = get_script_completions("import", row=0, column=7, filename="")
    assert len(completions) > 0
    completions = get_script_completions("", row=0, column=0, filename="")
    assert len(completions) > 0
    completions = get_script_completions("", row=0, column=0, filename="")
    assert len(completions) > 0
    completions = get_script_completions("", row=0, column=10, filename="")
    assert len(completions) > 0

# Generated at 2022-06-24 07:53:16.403425
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.ast_utils import get_source_lines

    def assert_definitions(s: str, row: int, column: int, expected_positions: List[tuple]):
        """
        Example:
        >>> assert_definitions(s, 2, 1, [])
        >>> assert_definitions(s, 2, 2, [(0, 1, 0, 6)])
        """
        definitions = get_definitions(s, row, column, filename="test.py")
        assert len(definitions) == len(expected_positions)
        for i in range(len(definitions)):
            actual_line_col = definitions[i].line, definitions[i].column
            try:
                expected_line_col = expected_positions[i][0:2]
            except IndexError:
                raise Assert

# Generated at 2022-06-24 07:53:22.173267
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    source = 'import'
    row = 1
    column = 0
    filename = 'my.py'
    line_source = source + '\n'
    script = jedi.Script(source, row, column, filename)
    completion = script.complete()[0]
    ThonnyCompletion(completion.name, completion.complete, completion.type, completion.description, completion.parent, completion.full_name)
    return

# Generated at 2022-06-24 07:53:24.319504
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name1", "complete1", "type1", "description1", "parent1", "full_name1")

# Generated at 2022-06-24 07:53:32.018867
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:33.725817
# Unit test for function get_script_completions
def test_get_script_completions():
    assert isinstance(get_script_completions("", 0, 0, ""), list)



# Generated at 2022-06-24 07:53:43.168196
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert (
        ThonnyCompletion(
            name="name",
            complete="complete",
            type="type",
            description="description",
            parent="parent",
            full_name="full_name",
        )["name"]
        == "name"
    )
    assert (
        ThonnyCompletion(
            name="name",
            complete="complete",
            type="type",
            description="description",
            parent="parent",
            full_name="full_name",
        )["complete"]
        == "complete"
    )

# Generated at 2022-06-24 07:53:50.398797
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", None, None, None, None)
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type is None
    assert completion.description is None
    assert completion.parent is None
    assert completion.full_name is None
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] is None
    assert completion["description"] is None
    assert completion["parent"] is None
    assert completion["full_name"] is None


# Generated at 2022-06-24 07:53:55.242277
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(
        "__init__", "__init__", "function", "some description", "some parent", "some full name"
    ).__dict__ == {
        "name": "__init__",
        "complete": "__init__",
        "type": "function",
        "description": "some description",
        "parent": "some parent",
        "full_name": "some full name",
    }

# Generated at 2022-06-24 07:54:05.560160
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python

    def make_class(name, start_pos, end_pos, children):
        return make_node("classdef", name, start_pos, end_pos, children)

    def make_func(name, start_pos, end_pos, children):
        return make_node("funcdef", name, start_pos, end_pos, children)

    def make_node(type, name, start_pos, end_pos, children):
        node = parso.python.tree.Node(type, parent=None)
        node.children = children
        node.start_pos = start_pos
        node.end_pos = end_pos
        node.name = name
        return node

    pos = (1, 2)


# Generated at 2022-06-24 07:54:09.835980
# Unit test for function parse_source
def test_parse_source():
    node = parse_source("import re")
    assert node.type == "file_input" and len(list(node.children)) == 1
    assert node.children[0].type == "import_from"
    assert node.children[0].module.value == "re"



# Generated at 2022-06-24 07:54:19.274526
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.tree import PythonNode

    def genTestNode(
        children: List[PythonNode],
        start_pos: (int, int),
        end_pos: (int, int),
        type: str,
        prefix: str = "",
    ) -> PythonNode:
        import parso

        class TestNode(PythonNode):
            children = children
            start_pos = start_pos
            end_pos = end_pos
            prefix = prefix

            def get_parent_until(self, *args):
                return None

            def get_definition(self):
                return None

            def get_annotations(self, **kwargs):
                return None

            def get_type_hint(self, **kwargs):
                return None


# Generated at 2022-06-24 07:54:20.300533
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("import", 0, 7, "sample.py"))

# Generated at 2022-06-24 07:54:25.979458
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    if _using_older_jedi(jedi):
        from jedi.api.classes import BaseDefinition as JediDefinition
    else:
        from jedi.api.classes import Definition as JediDefinition

    source = ("def module_level_function():\n" "    pass\n")
    completions = get_script_completions(source, 0, 0, "")
    assert len(completions) == 2
    assert completions[0].__dict__ == completions[1].__dict__
    assert isinstance(completions[1].parent, JediDefinition)
    assert completions[1].type == "statement"
    assert completions[1].full_name == "module_level_function"



# Generated at 2022-06-24 07:54:27.597909
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

# Generated at 2022-06-24 07:54:35.232215
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Test default parameter
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

    # Test name parameter
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    
    # Test complete parameter
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

    # Test type parameter
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

    # Test description parameter

# Generated at 2022-06-24 07:54:41.629852
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    source = "import sys; sys."
    script = jedi.Script(source, 1, len(source), "example.py")
    completions = script.completions()

    if _using_older_jedi(jedi):
        completion = completions[0]
        assert completion.name == "sys"
        assert completion.complete == "sys."
        assert completion.type == "module"
        assert completion.description == "Builtin modules"
        assert completion.parent is None
        assert completion.full_name == "sys"
    else:
        completion = completions[0]
        assert completion.name == "sys"
        assert completion.complete == "sys"
        assert completion.type == "module"
        assert completion.description == "module sys"
        assert completion.parent == "<built-in module>"

# Generated at 2022-06-24 07:54:42.961640
# Unit test for function parse_source
def test_parse_source():
    import parso

    assert isinstance(parse_source("x = 42"), parso.python.tree.Module)

# Generated at 2022-06-24 07:54:52.235127
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import platform

    import jedi

    # get the path of the jedi module
    if platform.system() == "Windows":
        separator = "\\"
    else:
        separator = "/"

    jedi_path = separator.join(
        jedi.__file__.split(separator)[:-1]
    )  # -1 to remove the file name
    path = os.environ.get("PATH", "")
    path = path.split(":")

    if jedi_path not in path:
        path.append(jedi_path)
    # set path to the jedi module
    os.environ["PATH"] = ":".join(path)

    # recreate jedi.Interpreter
    from jedi.api import Interpreter

    import thonny.jedi_

# Generated at 2022-06-24 07:55:03.542307
# Unit test for function get_script_completions
def test_get_script_completions():
    from importlib import reload

    import jedi

    # Verify if the function is able to handle older jedi.
    reload(jedi)

    import jedi_utils
    from thonny.languages.utils import parse_source

    with open(__file__) as fp:
        source = fp.read()

    completions = jedi_utils.get_script_completions(source, 3, 3, "xyz.py")
    assert len(completions) > 0

    assert completions[1].name == "reload"

    # Verify if the function is able to handle newer jedi.
    reload(jedi)

    completions = jedi_utils.get_script_completions(source, 3, 3, "xyz.py")
    assert len(completions) > 0

    assert comple

# Generated at 2022-06-24 07:55:05.938259
# Unit test for function parse_source
def test_parse_source():
    import parso
    from . jedi_utils import parse_source

    source = "x = 1"
    parso_tree = parse_source(source)
    assert isinstance(parso_tree, parso.python.tree.Module)

# Generated at 2022-06-24 07:55:08.400679
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import sys; sys.p", 1, 11, "")
    assert len(completions) > 0
    assert completions[0].name == "path"

# Generated at 2022-06-24 07:55:11.501784
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("a", "b", "c", "d", "e", "f") == {"name": "a", "complete": "b", "type": "c", "description": "d", "parent": "e", "full_name": "f"}

# Generated at 2022-06-24 07:55:15.487422
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "\n\nos.p"
    completions = get_script_completions(source, 2, 4, "test.py")

    assert len(completions) > 0
    assert any(c.complete == "os.path" for c in completions)



# Generated at 2022-06-24 07:55:16.080822
# Unit test for function parse_source

# Generated at 2022-06-24 07:55:17.075034
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api import classes
    from jedi.api import types


# Generated at 2022-06-24 07:55:26.014949
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench

    get_workbench().add_backend(
        "jedi",
        get_script_completions,
        get_interpreter_completions,
        get_definitions,
        parse_source,
    )
    assert get_workbench().get_editor_notebook()

    # Simple case
    assert ["abs", "all", "any"][0].name == "abs"
    assert ["abs", "all", "any"][0].complete == "abs"
    assert ["abs", "all", "any"][0].type == "<function>"
    assert ["abs", "all", "any"][0].parent == "__builtin__"
    assert ["abs", "all", "any"][0].full_name == "__builtin__.abs"

    #

# Generated at 2022-06-24 07:55:30.734511
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = 'x = "__file__"'
    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert any(completion.name == "__file__" for completion in completions)


if __name__ == "__main__":
    test_get_interpreter_completions()
    print("OK")

# Generated at 2022-06-24 07:55:38.064680
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion_obj = ThonnyCompletion(
        name="name_value",
        complete="complete_value",
        type="type_value",
        description="description_value",
        parent="parent_value",
        full_name="full_name_value",
    )
    assert thonny_completion_obj["name"] == "name_value"
    assert thonny_completion_obj["complete"] == "complete_value"
    assert thonny_completion_obj["type"] == "type_value"
    assert thonny_completion_obj["description"] == "description_value"
    assert thonny_completion_obj["parent"] == "parent_value"
    assert thonny_completion_obj["full_name"] == "full_name_value"

# Generated at 2022-06-24 07:55:41.278514
# Unit test for function get_script_completions
def test_get_script_completions():
    _source = """import jedi"""
    _row = 0
    _column = 12
    _filename = "script.py"

    script_completions = get_script_completions(_source, _row, _column, _filename)
    assert script_completions != None


# Generated at 2022-06-24 07:55:51.491322
# Unit test for function get_definitions
def test_get_definitions():
    def check(source, expected):
        logger.info(source)
        result = get_definitions(source, 1, 1, "/tmp/foo.py")
        if expected is None:
            assert len(result) == 0
            return
        assert result[0].description == expected, str(result)

    check("import sys", "import sys")
    check("import sys, os", "import sys")
    check("sys", "module sys")
    check("sys.", "module sys")
    check("sys.v", "sys.version")
    check("sys.version", "sys.version")
    check("sys.version=", "sys.version")
    check("sys.foo =", None)
    check("a.b.", "a.b")
    check("a.b=", None)

# Generated at 2022-06-24 07:55:59.401049
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys
    import parso
    from parso.python.tree import Module
    from jedi import Script
    from unittest import TestCase

    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(test_dir, "test-data"))

    def get_script(source, row, column, filename):
        try:
            return Script(source, row, column, filename)
        except parso.cache.parser_cache.ParserSyntaxError:
            return Script(source, row, column, filename, sys_path=[test_dir])


# Generated at 2022-06-24 07:56:08.274251
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys
    import jedi
    import unittest
    import pytest

    @pytest.mark.skipif(str(jedi.__version__).startswith('0.18'), reason='jedi 18')
    class TestGetInterpreterCompletions(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            # use jedi from the same Thonny installation
            my_dir = os.path.dirname(os.path.abspath(__file__))
            sys.path.insert(0, os.path.join(my_dir, "..", "..", ".."))

        def test_get_sys_path(self):
            import sys


# Generated at 2022-06-24 07:56:09.945425
# Unit test for function parse_source

# Generated at 2022-06-24 07:56:14.954527
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    not_str = 10
    not_int = "foo"
    try:
        ThonnyCompletion(
            name=not_int, 
            complete=not_str, 
            type=not_str, 
            description=not_str, 
            parent=not_str, 
            full_name=not_str
        )
    except TypeError as e:
        print("Error: Incorrect arguments passed in constructor of class ThonnyCompletion")
        print(e)

# Generated at 2022-06-24 07:56:22.877183
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"


# Generated at 2022-06-24 07:56:28.528329
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert test_complete["name"] == "name"
    assert test_complete["complete"] == "complete"
    assert test_complete["type"] == "type"
    assert test_complete["description"] == "description"
    assert test_complete["parent"] == "parent"
    assert test_complete["full_name"] == "full_name"

# Generated at 2022-06-24 07:56:34.138386
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import copy
    import builtins

    namespaces = [{"dir": builtins, "globals": {}},
        {"dir": {"modules": {"dummy": "dummy"}}, "globals": {}}]
    source = "from os import path"
    completions = get_interpreter_completions(source, copy.deepcopy(namespaces),
        ["/path/to/module"])
    assert len(completions) == 101
    assert completions[0].name == "O_RDONLY"
    assert completions[-1].name == "path"

    source = "import os"
    completions = get_interpreter_completions(source, namespaces,
    ["/path/to/module"])
    assert len(completions) == 116
    assert completions[0].name

# Generated at 2022-06-24 07:56:43.798844
# Unit test for function get_script_completions
def test_get_script_completions():
    from random import randint

    for p in range(1, 101):
        for i in range(0, 100):
            source = ""
            for j in range(0, i):
                source += "a = " + str(randint(-100, 100)) + "\n"
            source += "a = " + str(randint(-100, 100)) + "."
            row = i
            column = len(source)
            filename = "filename"
            sys_path = [p]

            result = get_script_completions(source, row, column, filename, sys_path)

            logger.info("Test " + str(p) + "." + str(i) + " end")


if __name__ == "__main__":
    logger.setLevel(logging.DEBUG)
    test_get_script_complet

# Generated at 2022-06-24 07:56:50.186914
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    if _using_older_jedi(jedi):
        source = "x=[1, 2, 3]\nx."
    else:
        source = "x=[1, 2, 3]\nx."

    completions = get_script_completions(source, 2, 3, "")
    assert len(completions) > 10
    for c in completions:
        assert c.type == "statement"



# Generated at 2022-06-24 07:56:59.655909
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = """
if cond:
    # cursor here
    something
else:
    # cursor here
    something_else
"""
    from parso.tree import Leaf, Node
    from parso.python import tree

    # https://github.com/davidhalter/jedi/blob/master/jedi/parser_utils.py#L136
    import jedi.parser_utils
    func = getattr(jedi.parser_utils, "get_statement_of_position", _copy_of_get_statement_of_position)

    root = parse_source(source)

    # get a node with no children
    node = root.children[1]
    pos = Leaf(type="comment", value="# cursor here", start_pos=(2, 4), prefix="\n    ")
    s = func(node, pos)


# Generated at 2022-06-24 07:57:01.447241
# Unit test for function parse_source
def test_parse_source():
    source = "def myfunc(r):\n    return None"
    result = parse_source(source)
    assert result is not None


# Generated at 2022-06-24 07:57:11.996103
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete_1 = ThonnyCompletion("name_1", "complete_1", "type_1", "description_1", "parent_1", "full_name_1")
    test_complete_2 = ThonnyCompletion("name_2", "complete_2", "type_2", "description_2", "parent_2", "full_name_2")
    test_complete_3 = ThonnyCompletion("name_3", "complete_3", "type_3", "description_3", "parent_3", "full_name_3")
    test_list = [test_complete_1, test_complete_2, test_complete_3]
    index = 0
    for test_complete in test_list:
        assert test_complete.name == test_list[index].__getitem__("name")
       

# Generated at 2022-06-24 07:57:18.583804
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("test_name", "test_complete", "test_type", "test_description", "test_parent", "test_full_name") 
    assert completion.name == "test_name"
    assert completion.complete == "test_complete"
    assert completion.type == "test_type"
    assert completion.description == "test_description"
    assert completion.parent == "test_parent"
    assert completion.full_name == "test_full_name"
    assert completion["name"] == "test_name"
    assert completion["complete"] == "test_complete"
    assert completion["type"] == "test_type"
    assert completion["description"] == "test_description"
    assert completion["parent"] == "test_parent"
    assert completion["full_name"] == "test_full_name"

# Generated at 2022-06-24 07:57:26.092303
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

    module = jedi.Script("print('Hello')")._module
    module.start_pos = 0
    print_call = module.children[0]
    assert get_statement_of_position(module, print_call.start_pos) == print_call
    assert get_statement_of_position(module, print_call.start_pos - 1) == module
    assert get_statement_of_position(module, print_call.start_pos + 1) == print_call
    assert get_statement_of_position(module, module.end_pos) == module


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-24 07:57:27.258926
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:57:29.110533
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase


# Generated at 2022-06-24 07:57:32.025732
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python.diff import diff
    from parso.python.parser import Parser
    import jedi
    import time


# Generated at 2022-06-24 07:57:39.320354
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions(
        'import os; from os import path; os.path.join("foo", "bar")',
        1,
        0,
        "test.py",
    )
    assert len(defs) == 1
    assert defs[0].module_path == "os"
    assert defs[0].line == 21


if __name__ == "__main__":
    import sys

    completions = get_script_completions(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]))
    print(completions)

# Generated at 2022-06-24 07:57:42.491928
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import parso
    # get_script_completions should work even with older jedi
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17", "0.18"]


# Generated at 2022-06-24 07:57:53.575899
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import PythonNode

    class Node(PythonNode):
        def __init__(self, type, start_pos, end_pos, children):
            self.type = type
            self.start_pos = start_pos
            self.end_pos = end_pos
            self.children = children

    def check(node, pos, expect_type):
        stmt = get_statement_of_position(node, pos)
        assert stmt.type == expect_type

    def node(type, start_pos, end_pos, *children):
        return Node(type, start_pos, end_pos, children)

    # if

# Generated at 2022-06-24 07:57:59.815415
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api import Script
    from jedi.api.project import JediProject
    from jedi.api.environment import get_cached_default_environment
    from jedi.api import Interpreter


# Generated at 2022-06-24 07:58:05.201360
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Arrange
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    # Act
    test = ThonnyCompletion(name, complete, type, description, parent, full_name)

    # Assert
    assert test.name == name
    assert test.complete == complete
    assert test.type == type
    assert test.description == description
    assert test.parent == parent
    assert test.full_name == full_name

# Generated at 2022-06-24 07:58:11.159637
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if jedi.__version__[:4] == "0.13":

        def test_cases():
            yield "", 1, 1, "test.py"
            yield "", 0, 0, "test.py"
            yield "a = 123", 1, 5, "test.py"
            yield "a", 1, 2, "test.py"
            yield "\n\n\n\n\n\n", 6, 0, "test.py"

        for source, row, column, filename in test_cases():
            script = jedi.Script(source, row, column, filename)
            completions = script.completions()

    elif jedi.__version__[:4] == "0.14":

        def test_cases():
            yield "", 1, 1, "test.py"

# Generated at 2022-06-24 07:58:19.309229
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    For the sake of this test, the 'project' used is just a stub in which we
    can name an arbitrary file.
    """
    # When calling get_script_completions, the function calls get_script_completions
    # internally, so we need to make sure that we disable the test in this case
    # (by removing the _test_ prefix)
    if not __name__.endswith("backend.jedi_utils") or '_test_' not in __name__:
        return
    import jedi
    from parso.python import tree
    
    def get_variable_name(line):
        """
        Returns the variable name (as a string) for the given line.
        If the line does not contain a variable name, an empty string is returned.
        """
        variable_name = ""
       

# Generated at 2022-06-24 07:58:23.066944
# Unit test for function get_definitions
def test_get_definitions():
    if get_definitions("x=", 1, 2, "test.py")[0].module_path == "test.py":
        print("get_definitions works in jedi>=0.18")
    else:
        print("get_definitions does not work in jedi<0.18")


# Generated at 2022-06-24 07:58:28.932010
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import re

    script_completions = get_script_completions

    def sort(completions):
        return sorted(completions, key=lambda x: [x.name, x.complete])

    # For completions, jedi ignores the source completely and only looks
    # for the line, column and filename.
    source = """print('This is a sample source')"""

    assert sort(script_completions(source, row=0, column=0, filename="test.py"))[0].name == "abs"
    assert (
        sort(script_completions(source, row=0, column=0, filename="test.py"))[0].complete
        == "abs("
    )


# Generated at 2022-06-24 07:58:38.007006
# Unit test for function get_definitions
def test_get_definitions():
    """Test getting a list of definitions of an object in a Python file."""
    import os.path

    get_definitions("", 0, 0, "")
    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), "test_data", "definitions.py")
    definitions = get_definitions("", 0, 0, test_file)
    assert len(definitions) == 1
    assert definitions[0] == ("definitions", 1, 0, test_file, "module")
    definitions = get_definitions("definitions", 1, 0, test_file)
    assert len(definitions) == 1
    assert definitions[0] == ("definitions", 1, 0, test_file, "module")

# Generated at 2022-06-24 07:58:42.032830
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module

    module = parse_source("")
    assert isinstance(module, Module)

    module = parse_source("a=1")
    assert module.start_pos == (1, 0) and module.end_pos == (1, 3)

# Generated at 2022-06-24 07:58:49.649543
# Unit test for function get_script_completions
def test_get_script_completions():
    # Select the right version of get_script_completions
    get_script_completions_func = get_script_completions
    script = "tuple([1, 2, 3])"
    row = 0
    column = 10
    filename = None
    sys_path = None
    completions = get_script_completions_func(script, row, column, filename, sys_path)
    assert completions is not None
    assert len(completions) > 0
    assert completions[0].complete == "tuple()"



# Generated at 2022-06-24 07:58:56.688552
# Unit test for function parse_source
def test_parse_source():
    code = "import math"
    node = parse_source(code)
    assert node.type == "file_input"
    assert len(node.children) == 1
    assert node.children[0].type == "simple_stmt"
    assert len(node.children[0].children) == 1
    assert node.children[0].children[0].type == "import_from"

# Generated at 2022-06-24 07:58:58.988611
# Unit test for function get_script_completions
def test_get_script_completions():
    if _using_older_jedi(__import__("jedi")):
        print("ignoring test")

# Generated at 2022-06-24 07:59:02.776208
# Unit test for function parse_source
def test_parse_source():
    """
        Test to parse a source string
    """
    source = """import sys"""
    result = parse_source(source)
    expected_result = 'Module(name_for_position='')'
    assert str(result) == expected_result


# Generated at 2022-06-24 07:59:12.254289
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "a = 1\na.\nb=2"
    completions = get_script_completions(source, 2, 2, "test.py")
    assert len(completions) == 1
    assert completions[0].name == "capitalize"


if __name__ == "__main__":
    print(get_script_completions(r"a = 1\na.\nb=2", 2, 2, "test.py"))
    print(get_script_completions(r"a = 1\na.\nb=2", 3, 0, "test.py"))
    print(get_script_completions(r"import sys\na = 1\na.\nb=2", 3, 0, "test.py"))

# Generated at 2022-06-24 07:59:18.917006
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name="name", complete="complete", type="type",
                                  description="description", parent="parent",
                                  full_name="full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:59:19.462970
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:59:26.575967
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.globals import get_runner
    import sys

    if sys.version_info.major == 2:
        return # No testing for python2
    

# Generated at 2022-06-24 07:59:36.075303
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    args = ("name", "complete", "type", "description", "parent", "full_name")
    test_obj = ThonnyCompletion(*args)
    assert test_obj.__getitem__('name') == 'name'
    assert test_obj.__getitem__('complete') == 'complete'
    assert test_obj.__getitem__('type') == 'type'
    assert test_obj.__getitem__('description') == 'description'
    assert test_obj.__getitem__('parent') == 'parent'
    assert test_obj.__getitem__('full_name') == 'full_name'
    

# Generated at 2022-06-24 07:59:39.685624
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion['name'] == 'name'
    assert completion['complete'] == 'complete'
    assert completion['type'] == 'type'
    assert completion['description'] == 'description'
    assert completion['parent'] == 'parent'
    assert completion['full_name'] == 'full_name'

# Generated at 2022-06-24 07:59:45.760187
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:59:53.655067
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.__getitem__("name") == "name" and \
        completion.__getitem__("complete") == "complete" and \
        completion.__getitem__("type") == "type" and \
        completion.__getitem__("description") == "description" and \
        completion.__getitem__("parent") == "parent" and \
        completion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 08:00:00.284162
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Test the presence and type of the completion object
    class Obj():
        pass

    expected = {'name': 'A', 'complete': 'A', 'type': 'class', 'description': '', 'parent': 'Obj',
                'full_name': 'Obj.A'}
    assert isinstance(get_interpreter_completions('class A: pass', [Obj], None)[0],
                      ThonnyCompletion) == True
    # Test the value of the completion object
    assert get_interpreter_completions('class A: pass', [Obj], None)[0].__dict__ == expected



# Generated at 2022-06-24 08:00:07.842909
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

    try:
        comp["not_exist"]
        assert False, "should throw exception"
    except KeyError:
        pass

# Generated at 2022-06-24 08:00:15.461127
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import jedi.api
    import jedi.parser
    import jedi.evaluate
    import jedi.api.classes
    import jedi.api.keywords
    import jedi.api.helpers
    import jedi.api.functions
    
    print("\njedi version:", jedi.__version__)
    # Testing on Python 3.7.3
    assert(jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17", "0.18", "0.19"])
    
    # Definition: built-in class
    source = '''import os
print('''
    result = get_definitions(source, 1, 4, "")
    assert len(result) == 1

# Generated at 2022-06-24 08:00:22.124346
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.__getitem__("name") == c.name
    assert c.__getitem__("complete") == c.complete
    assert c.__getitem__("type") == c.type
    assert c.__getitem__("description") == c.description
    assert c.__getitem__("parent") == c.parent
    assert c.__getitem__("full_name") == c.full_name

# Generated at 2022-06-24 08:00:25.409909
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    n = parso.parse("for a in (1,2,3)\n    pass")
    node = get_statement_of_position(n, 9)
    assert isinstance(node, parso.python.tree.ForStmt)
    node = get_statement_of_position(n, 0)
    assert isinstance(node, parso.python.tree.Flow)

# Generated at 2022-06-24 08:00:31.227726
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    result = ThonnyCompletion(
        "name", "name", "type", "description", "parent", "full_name"
    )
    assert result.name == "name"
    assert result.complete == "name"
    assert result.type == "type"
    assert result.description == "description"
    assert result.parent == "parent"
    assert result.full_name == "full_name"



# Generated at 2022-06-24 08:00:34.535360
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import patch
    from jedi import version_info

    if version_info < (0,18):
        patch("jedi.Interpreter.completions").start()
    else:
        patch("jedi.Interpreter.complete").start()

    assert get_interpreter_completions("asdf", [])



# Generated at 2022-06-24 08:00:37.475228
# Unit test for function parse_source
def test_parse_source():
    node = parse_source("for i in range(3): print(i)")
    assert node.type == "file_input"
    assert node.get_code() == "for i in range(3): print(i)"


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 08:00:44.397672
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert (
        ThonnyCompletion(
            name="name",
            complete="complete",
            type="type",
            description="description",
            parent="parent",
            full_name="full_name",
        ).__dict__
        == {
            "name": "name",
            "complete": "complete",
            "type": "type",
            "description": "description",
            "parent": "parent",
            "full_name": "full_name",
        }
    )