

# Generated at 2022-06-24 07:51:22.810230
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.parser_utils import get_statement_of_position
    source = "import string\nstring.\nstring.as"
    row = 2
    column = 7
    filename = "test.py"
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) == 10
    assert completions[0].name == "as_bytes"
    assert not completions[0].complete.endswith("=")
    assert completions[1].name == "as_bytes="
    assert completions[1].complete.endswith("=")

    # Test on newer jedi versions

# Generated at 2022-06-24 07:51:26.649851
# Unit test for function get_definitions

# Generated at 2022-06-24 07:51:30.424684
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("v", 0, 1, "")
    completions = sorted(completions, key=lambda c: c.complete)
    assert len(completions) > 1
    assert completions[0].complete == "variables"
    assert completions[1].complete == "vars"



# Generated at 2022-06-24 07:51:35.386387
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    dict = {
        "name": "taco",
        "complete": "taco",
        "type": "function_call",
        "description": "tacos for me",
        "parent": "tacomania",
        "full_name": "tacomania.taco",
    }

    assert ThonnyCompletion(**dict) == ThonnyCompletion(**dict)

# Generated at 2022-06-24 07:51:36.672327
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("Foo")


# Generated at 2022-06-24 07:51:39.442270
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from unittest import TestCase

    from parso.python import tree


# Generated at 2022-06-24 07:51:49.913908
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    
    def check(code, pos, expected_type):
        """Raise AssertionError if test fails."""
        node = parse_source(code)
        stmt = get_statement_of_position(node, pos)
        assert  isinstance(stmt, tree._BaseNode)
        assert stmt.type == expected_type
    
    
    check('x = 42', 5, "simple_stmt")
    check('x = 42', 6, "simple_stmt")
    check('def f():\n\tpass\n', 8, "simple_stmt")
    check('def f():\n\tpass\n', 9, "simple_stmt")
    check('import random', 13, "simple_stmt")

# Generated at 2022-06-24 07:51:55.970403
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [
        {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__loader__": None,
            "__spec__": None,
            "__annotations__": {},
            "__builtins__": __builtins__,
            "__file__": "<ipython-input-11-567535c3d0d3>",
            "__cached__": None,
            "turtle": __import__("turtle"),
        }
    ]

    assert "turtle." in [
        c.name for c in get_interpreter_completions("turtle.", namespaces)
    ]

# Generated at 2022-06-24 07:51:59.980588
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def get_pos(source, lineno, col):
        import jedi.parser

        parser = jedi.parser.Parser(source, None)
        try:
            node = parser.module.children[lineno - 1]
        except IndexError:
            return None
        else:
            return node.get_start_pos_of_prefix(col)


# Generated at 2022-06-24 07:52:05.273383
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class Test(unittest.TestCase):
        def test_get_interpreter_completions(self, source: str, namespaces, expected):
            actual = get_interpreter_completions(source, namespaces)
            self.assertEqual(
                [(item.name, item.type, item.complete) for item in actual], expected
            )

    import sys
    import collections

    test = Test("test_get_interpreter_completions")
    test.test_get_interpreter_completions(
        "collections.", [sys.modules], [("namedtuple", "func", "namedtuple")]
    )
    

# Generated at 2022-06-24 07:52:14.295898
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    try:
        t = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
        assert t.name == "name"
        assert t.complete == "complete"
        assert t.type == "type"
        assert t.description == "description"
        assert t.parent == "parent"
        assert t.full_name == "full_name"
        assert t["name"] == "name"
        assert t["complete"] == "complete"
        assert t["type"] == "type"
        assert t["description"] == "description"
        assert t["parent"] == "parent"
        assert t["full_name"] == "full_name"
    except AssertionError as e:
        raise AssertionError("test_ThonnyCompletion failed: " + str(e))

# Generated at 2022-06-24 07:52:14.903701
# Unit test for function parse_source

# Generated at 2022-06-24 07:52:23.896683
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from .jedi_utils import get_interpreter_completions

    completions = get_interpreter_completions(
        "import datetime",
        [{"datetime": {"datetime": "datetime.datetime"}}],
    )

    assert len(completions) > 0
    assert completions[0].complete == "datetime"
    assert completions[0].full_name == "datetime"

    completions = get_interpreter_completions(
        "import datetime\ndatetime.datetime", [{"datetime": {"datetime": "datetime"}}]
    )

    assert len(completions) > 0
    assert completions[0].complete == "datetime"
    assert completions[0].full_name == "datetime.datetime"



# Generated at 2022-06-24 07:52:35.238910
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.utils import FakeName
    from jedi.evaluate.base_context import ContextSet, NO_CONTEXTS
    from jedi.evaluate.compiled.context import CompiledContext
    import parso
    import jedi

    sys_path = ['testpath']

    source = "a"
    namespaces = [{'a': 'a'}]
    interpreter = get_interpreter_completions(
        source=source, namespaces=namespaces, sys_path=sys_path)
    assert interpreter == ['abc']

    source = "a."
    namespaces = [{'a': 'a'}]
    interpreter = get_interpreter_completions(
        source=source, namespaces=namespaces, sys_path=sys_path)

# Generated at 2022-06-24 07:52:44.224913
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("foo.bar", 0, 6, "")[0].name == "bar"
    assert get_script_completions("foo", 0, 3, "")[0].type == "module"
    assert get_script_completions("import sys", 7, 4, "")[0].name == "sys"
    assert get_script_completions("import sys", 7, 4, "")[1].name == "sysconfig"
    assert get_script_completions("foo(", 0, 4, "")[0].name == "()"
    assert get_script_completions("foo = [1, 2, 3]\nfoo[",
                                  1, 7, "")[0].name == "__getitem__"



# Generated at 2022-06-24 07:52:54.411756
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_support import utils

    def check(source, row, column, expected):
        actual = utils.get_script_completions(source, row, column, None)
        assert len(actual) == len(expected)
        for i in range(len(actual)):
            assert actual[i].complete == expected[i]

    check("froz", 0, 4, ["frozenset"])
    check("import a\na.fo", 1, 3, ["a.fool", "a.foo"])
    check("import a\na.fool.", 1, 7, ["fool.blah", "fool.blah2"])
    check("a=1\na.", 1, 2, ["a.bit_length"])

# Generated at 2022-06-24 07:53:00.305139
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    script = jedi.Script('import sys', 1, 3, None)
    completions = script.completions()
    completion = completions[0]
    assert isinstance(completion, ThonnyCompletion)
    assert completion.name == "sys"
    assert completion.complete == "sys"
    assert completion.type == "module"
    assert completion.description == "The Python Standard Library.\n\nimport itertools\nimport sys"
    assert completion.parent == "jetbrains.python.jedi.builtin.modules.sys"
    assert completion.full_name == "sys"

# Generated at 2022-06-24 07:53:01.889386
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", None, None, None, None, None)


# Generated at 2022-06-24 07:53:10.947318
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.classes import Script

    imports = get_script_completions(
        "from sys import ", 3, 13, "test_file.py"
    )
    assert len(imports) > 10

    imports = get_script_completions(
        'import sys\nprint(sys.m', 6, 12, "test_file.py"
    )
    assert len(imports) > 10

    class FakeScript:
        def __init__(self, completions):
            self.completions = lambda: completions

    fake_script = FakeScript([Completion("import sys", "sys", 0)])

    with _Monkey(jedi, "Script", lambda *args, **kw: fake_script):
        imports = get_script_complet

# Generated at 2022-06-24 07:53:13.402534
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    tests if code object contains data
    """
    code = """
    def func(parameter):
        '''
        Test function to check if code object contains data
        '''
        parameter = parameter + 1
    func(2)
    """
    completions = get_script_completions(code, 4, 10, "script.py")
    assert completions and len(completions) > 0


# Generated at 2022-06-24 07:53:23.115287
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import os\n" "os.pa" + "th"
    completions = get_script_completions(source, 0, 16, "foo.py")
    assert [c.name for c in completions] == ["path", "pathsep", "pathconf_names", "pathconf_names_unicode"]

    source = "import os\n" + "os.pa" + "th = 5"
    completions = get_script_completions(source, 0, 16, "foo.py")
    assert [c.name for c in completions] == ["path", "pathsep", "pathconf_names", "pathconf_names_unicode"]

    source = "import os\n" + "os.pa" + "th"

# Generated at 2022-06-24 07:53:32.337011
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(name="name", complete="complete", type=1, description="description", parent=None, full_name="full_name").__getitem__("name") == "name"
    assert ThonnyCompletion(name="name", complete="complete", type=1, description="description", parent=None, full_name="full_name").__getitem__("complete") == "complete"
    assert ThonnyCompletion(name="name", complete="complete", type=1, description="description", parent=None, full_name="full_name").__getitem__("type") == 1
    assert ThonnyCompletion(name="name", complete="complete", type=1, description="description", parent=None, full_name="full_name").__getitem__("description") == "description"

# Generated at 2022-06-24 07:53:34.905982
# Unit test for function parse_source
def test_parse_source():
    """
    Tests whether the parse_source method can correctly parse
    the given string.

    :return: True if the test has passed, else False.
    """

# Generated at 2022-06-24 07:53:39.708149
# Unit test for function get_definitions
def test_get_definitions():
    defn = get_definitions(
        "from math import sin, cos\nprint(sin(1))\n", row=1, column=1, filename="test.py"
    )
    assert defn[0].description == "Import from math."
    assert defn[1].description == "sin(x) method of module math"

# Generated at 2022-06-24 07:53:49.528934
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(name="test_name", complete="test_complete",
                                         type="test_type", description="test_description",
                                         parent="test_parent", full_name="test_full_name")
    assert thonny_completion["name"] == "test_name"
    assert thonny_completion["complete"] == "test_complete"
    assert thonny_completion["type"] == "test_type"
    assert thonny_completion["description"] == "test_description"
    assert thonny_completion["parent"] == "test_parent"
    assert thonny_completion["full_name"] == "test_full_name"

# Generated at 2022-06-24 07:53:54.792157
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completions = get_script_completions("print()", 0, 6, "abc.py")
    dictionary = completions[0]
    assert dictionary["name"] == "help"
    assert dictionary["complete"] == "help("
    assert dictionary["parent"] == "builtins"
    assert dictionary["type"] == "function"
    assert dictionary["description"] == "help(object) -> help information\n"
    assert dictionary["full_name"] == "builtins.help"

# Generated at 2022-06-24 07:54:01.276982
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    if not hasattr(__builtins__, "test_utils"):
        return

    test_utils.tweak_import_path_for_testing()

    import parso

    def get_tests(node):
        # isinstance() breaks with jedi 0.16
        if getattr(node, "type", None) == "suite":
            for child in node.children:
                yield from get_tests(child)

        elif getattr(node, "type", None) == "simple_stmt":
            for child in node.children:
                if getattr(child, "type", None) == "statement":
                    yield from get_tests(child)

# Generated at 2022-06-24 07:54:09.839502
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase
    from unittest.mock import Mock
    import types

    def test_case(self, source, row, column, filename, expected_module_name=None):
        import jedi

        if _using_older_jedi(jedi):
            script = jedi.Script(source, row, column, filename)
            definitions = script.goto_definitions()
        else:
            script = jedi.Script(code=source, path=filename)
            definitions = script.infer(line=row, column=column)

        self.assertEqual(
            len(definitions),
            1,
            "There is exactly one definition for '"
            + source.split("\n")[row - 1][column :].split("(")[0]
            + "'",
        )
       

# Generated at 2022-06-24 07:54:17.603735
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    source = """
if True:
    a = 2
    if True:
        b = 3
            # ^
            # (inside the comment)
"""

    node = parse_source(source)
    comment = node.get_leaf_for_position((6, 8))
    assert comment.type == "comment"

    if_node = node.get_leaf_for_position((3, 7))
    assert isinstance(if_node, tree.IfStmt)

    found = get_statement_of_position(node, (6, 8))
    assert if_node == found

# Generated at 2022-06-24 07:54:18.392890
# Unit test for function get_definitions

# Generated at 2022-06-24 07:54:24.846636
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from parso.python.tree import Name

    tree_name = Name("name", type_annotation=None, is_definition=False)
    tree_name.var_args = False
    tree_name.kwargs = False
    tree_name.star_count = 1

    comp = ThonnyCompletion(
        name="name",
        complete="name",
        type="name",
        description="description",
        parent="parent",
        full_name=tree_name,
    )

    assert comp.name == "name"
    assert comp.complete == "name"
    assert comp.type == "name"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name.star_count == 1



# Generated at 2022-06-24 07:54:34.006697
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_Comp = ThonnyCompletion("test_name", "test_complete", "test_type",
                                 "test_description", "test_parent", "test_full_name")
    assert test_Comp.__getitem__("name") == test_Comp.name
    assert test_Comp.__getitem__("complete") == test_Comp.complete
    assert test_Comp.__getitem__("type") == test_Comp.type
    assert test_Comp.__getitem__("description") == test_Comp.description
    assert test_Comp.__getitem__("parent") == test_Comp.parent
    assert test_Comp.__getitem__("full_name") == test_Comp.full_name
    assert test_Comp.__getitem__("new_var") is None

# Generated at 2022-06-24 07:54:42.532383
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    source = """class Test:
    def foo(self):
        self.x = 42
        self.y = 41
        self.z = 40
"""
    print(get_statement_of_position(parse_source(source), (3, 12)))
    assert isinstance(
        get_statement_of_position(parse_source(source), (3, 12)), tree.AssignmentStmt
    )
    assert isinstance(
        get_statement_of_position(parse_source(source), (4, 12)), tree.AssignmentStmt
    )
    assert isinstance(
        get_statement_of_position(parse_source(source), (5, 12)), tree.AssignmentStmt
    )



# Generated at 2022-06-24 07:54:47.566647
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-24 07:54:48.993888
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert len(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")) == 6


# Generated at 2022-06-24 07:54:50.744242
# Unit test for function parse_source
def test_parse_source():
    from parso import parse

# Generated at 2022-06-24 07:55:01.843312
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import unittest

    class ThonnyCompletionTests(unittest.TestCase):
        def test_ThonnyCompletion(self):
            completion = ThonnyCompletion(
                name="print",
                complete="print",
                type="statement",
                description="print(value, ..., sep=' ', end='\\n', file=sys.stdout, flush=False)",
                parent="",
                full_name="",
            )

            self.assertEqual(completion.name, "print")
            self.assertEqual(completion.complete, "print")
            self.assertEqual(completion.type, "statement")
            self.assertEqual(completion.description, "print(value, ..., sep=' ', end='\n', file=sys.stdout, flush=False)")
            self

# Generated at 2022-06-24 07:55:09.751590
# Unit test for function get_script_completions
def test_get_script_completions():
    """The function is tested with two tests:
       - The first test is to verify if the function returns all completions
         in case the code "import" is written and the second test tries to
         verify if the function returns completions when at least one letter
         is written before the "import" word.
    """
    import jedi
    from test.jedi_test import CompletionTest
    from test.test_jedi import enable_docstrings, _tmp_module

    with _tmp_module() as filename:
        enable_docstrings()

        source = "import "
        completions = get_script_completions(source=source, row=0, column=len(source), filename=filename)
        assert set(_.name for _ in completions) == set(CompletionTest.get_completions(source))

        source = "imp"

# Generated at 2022-06-24 07:55:13.886156
# Unit test for function parse_source
def test_parse_source():
    # Test for function parse_source
    source="""\
import math
a=5+5
for i in range(2):
    print(i)"""
    tree=parse_source(source)
    assert tree.children[0].type=="import_from"
    assert tree.children[1].type=="simple_stmt"
    assert tree.children[2].type=="for_stmt"

# Generated at 2022-06-24 07:55:23.599269
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi.parser_utils

    old_get_statement_of_position = getattr(
        jedi.parser_utils, "get_statement_of_position", None
    )

    if old_get_statement_of_position is None:
        jedi.parser_utils.get_statement_of_position = get_statement_of_position

    original_completions = get_script_completions(
        "import time\nprint(abs)", 3, 6, "test_get_script_completions.py"
    )

    new_completions = get_script_completions(
        "import time\nprint(abs)", 3, 6, "test_get_script_completions.py"
    )

    assert original_completions == new_completions

    jedi.parser_

# Generated at 2022-06-24 07:55:27.814450
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import collections
    import unittest

    class TestThonnyCompletion(unittest.TestCase):
        def test_1(self):
            tc = ThonnyCompletion("name", "complete", "type", "des", "parent", "full_name")
            self.assertTrue(isinstance(tc, collections.abc.Mapping))

    unittest.main(exit=False)

# Generated at 2022-06-24 07:55:29.934350
# Unit test for function parse_source
def test_parse_source():
    import jedi.parser_utils
    source = "import math"

    node = parse_source(source)
    assert node.type == "file_input"
    assert node.children[0].type == "import_name"



# Generated at 2022-06-24 07:55:36.262086
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock
    import jedi

    completions = [(x.name, x.complete, x.type, x.description, x.parent, x.full_name) for x in
    get_interpreter_completions("import math\nmath", [{"math": MagicMock()}])]

# Generated at 2022-06-24 07:55:40.236289
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="this", complete="complete", type="type", description="description", parent="parent", full_name="fullname"
    )
    assert completion.name == "this"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "fullname"
    

# Generated at 2022-06-24 07:55:41.239905
# Unit test for function parse_source
def test_parse_source():
    import jedi

# Generated at 2022-06-24 07:55:41.716992
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:55:47.411596
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("im", 0, 3, "x.py") == []
    assert get_script_completions("import math as m\nm.", 4, 2, "x.py") == ['pi', 'e']
    assert get_script_completions("import sys\nsy.", 4, 3, "x.py") == ['system', 'symlink']
    assert get_script_completions("import turtle\nturtle.", 4, 8, "x.py") == [
        'Screen', 'Turtle', 'TurtleScreen'
    ]
    assert get_script_completions("str.l", 4, 5, "x.py") == ['ljust', 'lower', 'lstrip']

# Generated at 2022-06-24 07:55:51.871891
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("test", "test", "test", "test", "test", "test")
    assert c.name == "test"
    assert c.complete == "test"
    assert c.type == "test"
    assert c.description == "test"
    assert c.parent == "test"
    assert c.full_name == "test"


# Generated at 2022-06-24 07:55:58.407427
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import unittest

    tests = [
        (" ", " ", " ", " ", " ", " "),
        ("name", "complete", "type", "description", "parent", "full_name"),
    ]

    for name, complete, type, description, parent, full_name in tests:
        completion = ThonnyCompletion(
            name, complete, type, description, parent, full_name
        )
        assert name == completion.name
        assert complete == completion.complete
        assert type == completion.type
        assert description == completion.description
        assert parent == completion.parent
        assert full_name == completion.full_name



# Generated at 2022-06-24 07:56:03.264039
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import TestCase

    class DummyClass:
        pass

    dummy_obj = DummyClass()

    tc1 = ThonnyCompletion("name", "complete", "type", "description", dummy_obj, "full_name")

    tc1.__dict__['key'] = 'value'
    assert tc1.__getitem__('key') == 'value'



# Generated at 2022-06-24 07:56:08.755785
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("param1", "param1", "type_info", "description", "parent", "full_name")
    assert completion["name"] == "param1"
    assert completion["complete"] == "param1"
    assert completion["type"] == "type_info"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:56:13.681415
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("import random", 0, 0, "<input>")) == 1
    assert len(get_definitions("import random", 0, 0, "<input>")) == 1
    assert len(get_definitions("random.sample([1,2,3], 3)", 0, 0, "<input>")) == 1

# Generated at 2022-06-24 07:56:19.879940
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name","complete","type","description","parent","full_name")
    assert(completion.name == "name")
    assert(completion.complete == "complete")
    assert(completion.type == "type")
    assert(completion.description == "description")
    assert(completion.parent == "parent")
    assert(completion.full_name == "full_name")


# Generated at 2022-06-24 07:56:28.993867
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.parser import ParserError

    assert get_statement_of_position(9, 9) == None
    assert get_statement_of_position(tree.PythonNode(0, 0), 9) == None

    node = tree.Module('abc')
    node.children = [tree.Statement('abc')]
    assert get_statement_of_position(node, 0) == None
    assert get_statement_of_position(node, 3) == None

    stmt = tree.Statement('abc')
    node.children = [stmt]
    assert get_statement_of_position(node, 0) == stmt
    assert get_statement_of_position(node, 3) == stmt

    stmt = tree.Statement('abc')

# Generated at 2022-06-24 07:56:32.612244
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(
        name = "name",
        complete = "complete",
        type = "type",
        description = "description",
        parent = "parent",
        full_name = "full_name"
    )
    assert tc.__getitem__("name") == "name"
    assert tc.__getitem__("complete") == "complete"
    assert tc.__getitem__("type") == "type"
    assert tc.__getitem__("description") == "description"
    assert tc.__getitem__("parent") == "parent"
    assert tc.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:56:37.374552
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "x =\n"
    namespaces = [{'__name__': '__main__', 'x': 5}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 0
    assert completions[0].name == 'x'



# Generated at 2022-06-24 07:56:47.661153
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"x": 1}, {"y": 2}]
    source = "x.y"
    result = get_interpreter_completions(source, namespaces)
    assert result
    assert result[0].complete == "y"

    source = "y.x"
    result = get_interpreter_completions(source, namespaces)
    assert not result

    namespaces = [{"x": 1}, {"x": 2}]
    source = "x.y"
    result = get_interpreter_completions(source, namespaces)
    assert result
    assert result[0].complete == "y"

    namespaces = [{"x": 1}]
    source = "x."
    result = get_interpreter_completions(source, namespaces)
    assert result
    #

# Generated at 2022-06-24 07:56:55.264620
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    jediCompletion = jedi.Script("x.isalpha()", 5, 5).completions()[0]
    thonnyCompletion = ThonnyCompletion("isalpha", "isalpha", "function", "str.isalpha()", "str", "str.isalpha")
    assert thonnyCompletion.name == jediCompletion.name
    assert thonnyCompletion.complete == jediCompletion.complete
    assert thonnyCompletion.type == jediCompletion.type
    assert thonnyCompletion.description == jediCompletion.description
    assert thonnyCompletion.parent == jediCompletion.parent
    assert thonnyCompletion.full_name == jediCompletion.full_name

# Generated at 2022-06-24 07:57:02.489367
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module, ClassOrFunc, Function
    from parso.cache import cache_module

    module = cache_module(parse_source("def foo():\n\tpass\nclass MyClass():\n\tdef bar():\n\t\tpass"))
    assert type(module) is Module
    assert module.children[0].name == "foo"
    assert type(module.children[0]) is Function
    assert module.children[1].name == "MyClass"
    assert type(module.children[1]) is ClassOrFunc

# Generated at 2022-06-24 07:57:03.549299
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

# Generated at 2022-06-24 07:57:09.689369
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_object = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert(test_object['name'] == 'name')
    assert(test_object['complete'] == 'complete')
    assert(test_object['type'] == 'type')
    assert(test_object['description'] == 'description')
    assert(test_object['parent'] == 'parent')
    assert(test_object['full_name'] == 'full_name')

# Generated at 2022-06-24 07:57:11.462542
# Unit test for function parse_source
def test_parse_source():
    parse_source("print(123")

# Generated at 2022-06-24 07:57:18.314648
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("3 + ", namespaces=[dict()]) == [
        ThonnyCompletion(
            name="__abs__",
            complete="__abs__",
            type="function",
            description="",
            parent="",
            full_name="__abs__",
        ),
        ThonnyCompletion(
            name="__add__",
            complete="__add__",
            type="function",
            description="",
            parent="",
            full_name="__add__",
        ),
    ]


# Generated at 2022-06-24 07:57:22.440171
# Unit test for function parse_source
def test_parse_source():
    import jedi
    main_result = jedi.utils.parse_source("a = 1\nprint(a)")
    test_result = parse_source("a = 1\nprint(a)")
    assert list(main_result.children) == list(test_result.children)

# Generated at 2022-06-24 07:57:26.306901
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    dict = {'name': "a", 'complete': "a", 'type': "a", 'description': "a", 'parent': "a", 'full_name': "a"}
    obj = ThonnyCompletion(name="a", complete="a", type="a", description="a", parent="a", full_name="a")
    result = obj['name']
    assert result == dict['name']

# Generated at 2022-06-24 07:57:37.069573
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.helpers import FakeName

    # Completions for a module should include:
    # - classes
    # - functions
    # - module level variables
    # - general variables
    # - functions that returns a class
    # - functions that returns a function
    # - functions that returns a module level variable
    # - functions that returns a general variable
    # NB!  no example for functions that returns "self"

# Generated at 2022-06-24 07:57:41.992565
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completions = []
    for i in range(10):
        completions.append(ThonnyCompletion(str(i), str(i), str(i), str(i), str(i), str(i)))
    for i in range(len(completions)):
        assert completions[i]["name"] == completions[i].name
    return "Passed"

if __name__ == "__main__":
    print('Test "ThonnyCompletion" class')
    print(test_ThonnyCompletion___getitem__())

# Generated at 2022-06-24 07:57:44.172101
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree


# Generated at 2022-06-24 07:57:48.820154
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import sys\nsys."
    namespaces = [{"__name__": "__main__", "sys": sys}]
    comps = get_interpreter_completions(source, namespaces)

    # check if the repository property is there
    assert comps
    assert hasattr(comps[0], "module_path")



# Generated at 2022-06-24 07:57:53.779926
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("a.b").children[0].children[0].value == "a"
    assert parse_source("a.b").children[0].children[1].value == "."
    assert parse_source("a.b").children[0].children[2].value == "b"


# Generated at 2022-06-24 07:58:00.851224
# Unit test for function get_definitions
def test_get_definitions():
    source = """
try:
    print("I'm inside try.")
except ValueError:
    print("I'm in except.")
"""
    row = 0
    column = 4

    definitions = get_definitions(source, row, column, "try_statement.py")
    
    assert isinstance(definitions, list)
    assert len(definitions) > 0
    assert definitions[0].name == "Try"
    assert definitions[0].description == "try"

# Generated at 2022-06-24 07:58:03.361157
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import os
print(os.path.join("", ""))
"""
    completions = get_interpreter_completions(source, [])
    assert False, completions

# Generated at 2022-06-24 07:58:10.420807
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Script
    source = """
import random
print(random.Random)
"""
    definitions = get_definitions(source, 2, 21, "/random.py")
    assert len(definitions) == 1
    assert definitions[0].module_name == "random"
    assert definitions[0].name == "Random"
    assert definitions[0].line == 22
    assert definitions[0].column == 6

    assert len(Script(source, 2, 21, "/random.py").goto_assignments()) == 0



# Generated at 2022-06-24 07:58:15.483237
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert t["name"] == "name"
    assert t["complete"] == "complete"
    assert t["type"] == "type"
    assert t["description"] == "description"
    assert t["parent"] == "parent"
    assert t["full_name"] == "full_name"

# Generated at 2022-06-24 07:58:24.378678
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso

    # test for jedi >= 0.18
    completion_dict1 = {"name": "abc", "complete": "abc", "type": "a", "description": "b", "parent": "c", "full_name": "d"}
    completion1 = parso.completion.Completion(None, completion_dict1)
    result_completion1 = ThonnyCompletion(
        name=completion1.name,
        complete=completion1.complete,
        type=completion1.type,
        description=completion1.description,
        parent=completion1.parent,
        full_name=completion1.full_name,
    )
    assert result_completion1.name == completion1.name
    assert result_completion1.complete == completion1.complete
    assert result_completion

# Generated at 2022-06-24 07:58:32.138006
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from unittest.mock import patch

    from parso import parse

    some_code = """
"""

    for i in range(len(some_code)):
        node = parse(some_code)

        statement = get_statement_of_position(node, i)
        # print(i, statement)
        # print(dir(statement))
        assert statement.type == "decorated"
        assert statement.start_pos < i < statement.end_pos


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-24 07:58:36.673562
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench
    import jedi
    workbench = get_workbench()
    workbench.set_option("editor.use_jedi", True)
    workbench.set_option("editor.jedi_sys_path", None)
    workbench.set_option("editor.jedi_auto_shorten_names", False)
    workbench.set_option("editor.jedi_naming_scheme", "long")

    # get completion with no sys_path
    filename = "my_module.py"
    source = "import math\nm = math.\n"
    completions = get_script_completions(source, 2, 8, filename)
    assert len(completions) == 14

    from thonny import get_workbench
    workbench = get_workbench()


# Generated at 2022-06-24 07:58:44.654745
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    collect = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert collect.__getitem__("name") == "name"
    assert collect.__getitem__("complete") == "complete"
    assert collect.__getitem__("type") == "type"
    assert collect.__getitem__("description") == "description"
    assert collect.__getitem__("parent") == "parent"
    assert collect.__getitem__("full_name") == "full_name"
    assert collect.__getitem__("invalid") == KeyError



# Generated at 2022-06-24 07:58:53.866510
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    completion = ThonnyCompletion(name="name",
                                  complete="complete",
                                  type=jedi.api.classes.Name("Type"),
                                  description="description",
                                  parent=jedi.api.classes.Name("Parent"),
                                  full_name="full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == jedi.api.classes.Name("Type")
    assert completion.description == "description"
    assert completion.parent == jedi.api.classes.Name("Parent")
    assert completion.full_name == "full_name"


if __name__ == "__main__":
    # Run the unit tests
    test_ThonnyCompletion()

# Generated at 2022-06-24 07:59:04.047203
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso
    from jedi.parser_utils import get_parent_scope

    source = """
    import math
    math.
    """
    root = parse_source(source)
    param_node = get_statement_of_position(root, len("import math.asd"))
    parent = get_parent_scope(param_node)

    c = ThonnyCompletion(
        name="sin",
        complete="sin",
        type=parso.tree.Name("sin", parent=parent),
        description="sin(...) method of math module",
        parent=parent,
        full_name="math.sin",
    )
    assert c.name == "sin"
    assert c.complete == "sin"
    assert c.parent == parent
    assert c.full_name == "math.sin"
    assert c

# Generated at 2022-06-24 07:59:14.041705
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from thonny import get_workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.config import get_python_path, load_configuration
    from thonny.plugins.jedi_completer import JediCompletionProvider

    # The sys_path should contain the path to the test file, so if the code
    # under test wants to import a module from the test file's folder,
    # it will be able to do it correctly.
    sys_path = [get_workbench().get_local_cwd()]
    open(get_workbench().get_local_cwd() + "/test_module.py", "w").write('print("Hello")')

    # Get the old value of the sys_path setting and remember it so we can restore it later.
    old_python_

# Generated at 2022-06-24 07:59:16.070160
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("import os\nx = 123\n")
    assert parse_source("if x: print(x)")


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:59:18.443245
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")


# Generated at 2022-06-24 07:59:23.811423
# Unit test for function parse_source
def test_parse_source():
    source = """\
x = 1
x.foo()
"""
    node = parse_source(source)
    assert node.start_pos == (1, 0)
    assert node.end_pos == (3, 7)
    assert len(node.children) == 2
    assert node.children[0].start_pos == (1, 0)
    assert node.children[0].end_pos == (1, 7)
    assert node.children[1].start_pos == (2, 0)
    assert node.children[1].end_pos == (3, 7)

# Generated at 2022-06-24 07:59:28.522143
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("a", [])
    for completion in completions:
        assert completion.name == completion.complete

    completions = get_interpreter_completions("a.b", [])
    for completion in completions:
        assert completion.name == completion.complete



# Generated at 2022-06-24 07:59:34.877338
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    jedi_completion = ThonnyCompletion("first", "second", "third", "fourth", None, None)
    assert jedi_completion.name == "first"
    assert jedi_completion.complete == "second"
    assert jedi_completion.type == "third"
    assert jedi_completion.description == "fourth"
    assert jedi_completion.parent == None
    assert jedi_completion.full_name == None

# Generated at 2022-06-24 07:59:36.096485
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    import jedi.parser_utils

# Generated at 2022-06-24 07:59:38.996151
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion[0] == "name"

# Generated at 2022-06-24 07:59:44.056930
# Unit test for function get_script_completions
def test_get_script_completions():
    from pytest import approx

    source = "import math\nmath.sq"
    completions = get_script_completions(source, row=1, column=8, filename="")
    assert len(completions) == 1
    assert completions[0]["name"] == "sqrt"
    assert completions[0]["type"] == "function"
    assert completions[0]["description"] == "sqrt(x)\n\nReturn the square root of x."

    source = "import json\njson.d"
    completions = get_script_completions(source, row=1, column=8, filename="")
    assert len(completions) == 3
    assert {c["name"] for c in completions} == {"dump", "dumps", "decoder"}

# Generated at 2022-06-24 07:59:45.667102
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )["name"] == "name"

# Generated at 2022-06-24 07:59:56.600733
# Unit test for function get_script_completions
def test_get_script_completions():
    try:
        import jedi
    except ImportError:
        print("Jedi not installed.")
        return
    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        fp = open('completions_script_test_script.py', 'r')
        source = fp.read()
        fp.close()
        completions = get_script_completions(source, 4, 5, 'completions_script_test_script.py', sys_path=[])


# Generated at 2022-06-24 08:00:08.076171
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.interpreter import Interpreter
    from jedi import Script

    script = Script(code='x_123=9;y_123=10;print(y_123);', path="test_file.py")
    completions = script.complete(line=2, column=5)

    # ThonnyCompletion(name='y_123',
    #                  complete='y_123',
    #                  type=<CompletionName.Variable: 1>,
    #                  description='int',
    #                  parent=<Module: test_file.py>,
    #                  full_name='y_123'),

    print(completions[0].complete)
    print(completions[0].name)
    print(completions[0].type)
    print(completions[0].description)
    print

# Generated at 2022-06-24 08:00:09.705196
# Unit test for function get_script_completions

# Generated at 2022-06-24 08:00:12.112835
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    
    tree = parso.parse("print(a)\nf()\n")
    node = tree.children[1].get_first_leaf()
    assert get_statement_of_position(tree, node.start_pos) == node

# Generated at 2022-06-24 08:00:22.697380
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def parse(source):
        return parse_source(source)

    def create_node(source):
        return parse(source).children[0].children[0]

    def get_pos(source, row, column):
        return parse(source).get_position_of_line_and_column(row, column)

    node = create_node("def foo():\n    x = 1\n    x + 2")
    assert get_statement_of_position(node, get_pos("def foo():\n    x = 1\n    x + 2", 2, 4))

    assert get_statement_of_position(node, get_pos("def foo():\n    x = 1\n    x + 2", 2, 5))


# Generated at 2022-06-24 08:00:26.613020
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import abc; abc.get"
    namespaces = [{"abc": "abc"}]

    completions = get_interpreter_completions(source, namespaces)

    assert completions[0].name == "getattr"



# Generated at 2022-06-24 08:00:35.527632
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    from parso.python import tree

    class TestCase(unittest.TestCase):
        def check_statements(self, source, positions):
            # type: (str, List[tuple]) -> None
            node = parse_source(source)

            for pos, expected_name in positions:
                actual = get_statement_of_position(node, pos)
                if actual is None:
                    actual_name = None
                else:
                    actual_name = actual.get_code()
                self.assertEqual(actual_name, expected_name)

    import parso

    class Mytree(tree.Whitespace, tree.Comment, tree.Leaf):
        pass

    # Create source string

# Generated at 2022-06-24 08:00:37.551678
# Unit test for function parse_source
def test_parse_source():
    assert isinstance(parse_source("import simple\n"), parso.python.tree.Module)


# Generated at 2022-06-24 08:00:47.609406
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion
    from jedi.api.helpers import get_script_completions
    from jedi.parser_utils import get_cached_code_lines

    source = get_cached_code_lines("""
import math

math.ceil
math.
""")

    completions = get_script_completions(source, row=2, column=6)
    assert set(map(lambda x: x.name, completions)) == {'ceil', 'floor', 'log'}

    completions = get_script_completions(source, row=3, column=7)
    assert set(map(lambda x: x.name, completions)) == {'ceil', 'floor', 'log'}

# Generated at 2022-06-24 08:00:56.509805
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            defs = get_definitions("def foo():\n    print(1)", 1, 9, "test.py")
            self.assertIsInstance(defs, list)
            self.assertGreaterEqual(len(defs), 1)
            self.assertEqual(defs[0].module_path, "test.py")
            self.assertEqual(defs[0].module_name, "test")
            self.assertEqual(defs[0].desc_with_module, "function foo in module test")

            defs = get_definitions("import math\nprint(math.sqrt(9))\n", 2, 16, "test.py")
            self.assertIsInstance(defs, list)

# Generated at 2022-06-24 08:01:01.386119
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi.api
    import jedi.interpreter.module

    completions = get_interpreter_completions("", [], [])
    assert jedi.api.Script("", []).complete() == completions
    assert isinstance(completions[0].parent, jedi.interpreter.module.ModuleWrapper)

# Generated at 2022-06-24 08:01:09.374903
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print("Running test")
    import os
    print("Path to this file is " + os.path.dirname(os.path.realpath(__file__)))
    print("Got \n" + str(get_interpreter_completions('import matplotlib.pyplot', [], sys_path=['/home/rickard/anaconda3/envs/myenv/lib/python3.8/site-packages'])))

if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 08:01:18.894917
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    code = 'import sys\nimport foo'
    completions = get_interpreter_completions(code, [{'a': 1, 'sys': sys}])

    assert len(completions) == 2
    assert completions[0].name == 'sys'
    assert completions[1].name == 'foo'
    assert completions[1].type == 'module'
    assert completions[1].complete == 'foo'

    code = "a = 1\n" + "a."
    completions = get_interpreter_completions(code, [{'a': 1, 'sys': sys}])
    assert len(completions) == 1
    assert completions[0].name == "numerator"
    assert completions[0].type == "method"
   