

# Generated at 2022-06-24 07:51:32.816215
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree
    from parso.python.tree import Leaf, NodeOrLeaf

    tree = parse_source("def foo()->str:\n\treturn 'bar'\nfoo()")
    for item in tree.children:
        assert(isinstance(item, NodeOrLeaf) or isinstance(item, Leaf))


# Generated at 2022-06-24 07:51:38.206541
# Unit test for function get_definitions
def test_get_definitions():
    # Create a dummy project
    import os.path

    import jedi

    test_dir = os.path.dirname(os.path.abspath(__file__))
    dummy_dir = os.path.join(test_dir, "dummy_project")
    dummy_file = os.path.join(test_dir, "dummy_project", "a.py")

    assert get_definitions("a", 1, 1, dummy_file) == []

    assert len(get_definitions("b", 1, 1, dummy_file)[0].infer()) == 4
    assert get_definitions("c", 1, 1, dummy_file)[0].name == "c"

    assert len(get_definitions("a", 1, 1, dummy_file)[0].infer()) == 1

# Generated at 2022-06-24 07:51:43.340508
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    # select this code
    # import sys
    # sys.path
    # ^
    completions = get_script_completions(
        "import sys\nsys.path", 1, 10, "dummy_file_name.py"
    )

    # old jedi (<= 0.16) does not give correct results for Interpreter
    scripts = jedi.api.Script("import sys\nsys.path", 1, 10, "dummy_file_name.py")
    if not scripts:
        scripts = jedi.api.Script("import sys\nsys.path", 1, 10, "dummy_file_name.py")
    assert len(completions) == len(scripts)
    assert completions[0].name == scripts[0].name
    assert completions[0].complete == scripts

# Generated at 2022-06-24 07:51:46.466124
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    keys = ["name", "complete", "type", "description", "parent", "full_name"]
    values = ["name", "complete", "type", "description", "parent", "full_name"]

    completion = ThonnyCompletion(*values)

    for key in keys:
        assert completion[key] == completion.__dict__[key]

# Generated at 2022-06-24 07:51:49.724918
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    root = parse_source("a = 123")
    expr = get_statement_of_position(root, 2)
    assert isinstance(expr, tree.ExprStmt)

    root = parse_source("a = 123")
    expr = get_statement_of_position(root, 2)
    assert isinstance(expr, tree.ExprStmt)


# Generated at 2022-06-24 07:51:55.978288
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple
    from jedi import Script
    from jedi import Interpreter
    import time

    declare_time = time.time()

    class FakeScript:
        def __init__(self, source, row, column, filename, sys_path=None):
            self.source = source
            self.row = row
            self.column = column
            self.filename = filename
            self.sys_path = sys_path
        def completions(self):
            call_time = time.time()
            time_diff = call_time - declare_time
            if time_diff > 0.1:
                raise AssertionError("Script is called too late")

            Completion = namedtuple("Completion", ["name", "complete", "type",
                                                   "description", "parent", "full_name"])


# Generated at 2022-06-24 07:52:02.887407
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        return

    source = 'class A: pass\nA'
    filename = 'file.py'
    row = 2
    column = 2
    defs = get_definitions(source, row, column, filename)
    assert len(defs) == 1
    the_def = defs[0]
    assert the_def.module_name == filename
    assert the_def.line == 1
    assert the_def.type == 'class'
    assert the_def.description == 'A = <class \'file.A\'>'
    assert the_def.full_name == 'file.A'

    source = 'import sys\nsys'.strip()
    row = 2
    column = 4

# Generated at 2022-06-24 07:52:08.801757
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest.mock import MagicMock
    from types import ModuleType
    parent = ModuleType("test_parent")
    ThonnyCompletion(
        name="test_name",
        complete="test_complete",
        type=MagicMock(),
        description="test_description",
        parent=parent,
        full_name="test_full_name",
    )["name"] == "test_name"

# Generated at 2022-06-24 07:52:18.672516
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree

    source = """x = 1
if x:
    y = 2
"""
    node = parso.parse(source)
    stmt = get_statement_of_position(node, 0)
    assert isinstance(stmt, tree.ExprStmt) and stmt.get_code().strip() == "x = 1"
    stmt = get_statement_of_position(node, 8)
    assert isinstance(stmt, tree.ExprStmt) and stmt.get_code().strip() == "x = 1"
    stmt = get_statement_of_position(node, 5)
    assert stmt is None
    stmt = get_statement_of_position(node, 15)
    assert isinstance(stmt, tree.IfStmt) and st

# Generated at 2022-06-24 07:52:23.968327
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonnyCompletion = ThonnyCompletion("testName","testComplete","testType","testDescription",None,"testFullName")
    assert thonnyCompletion.name == "testName"
    assert thonnyCompletion.complete == "testComplete"
    assert thonnyCompletion.type == "testType"
    assert thonnyCompletion.description == "testDescription"
    assert thonnyCompletion.parent == None
    assert thonnyCompletion.full_name == "testFullName"

# Generated at 2022-06-24 07:52:34.767352
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    arg = ("name", "complete", "type", "description", "parent", "full_name")
    test = ThonnyCompletion(*arg)
    assert test.name == "name"
    assert test.complete == "complete"
    assert test.type == "type"
    assert test.description == "description"
    assert test.parent == "parent"
    assert test.full_name == "full_name"
    try:
        test.name = "name2"
        assert False, "Cannot edit name"
    except AttributeError:
        pass
    assert test["name"] == "name"
    assert test["complete"] == "complete"
    assert test["type"] == "type"
    assert test["description"] == "description"
    assert test["parent"] == "parent"

# Generated at 2022-06-24 07:52:35.747906
# Unit test for function get_definitions

# Generated at 2022-06-24 07:52:44.905657
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """def f(a, b, c=1, d=2, e=3):
    print(a, b, c, d, e)

f("a", "b", e=3
"""
    completions = get_script_completions(source, 4, 26, "untitled")

    assert len(completions) == 4

    assert completions[0].name == "c"
    assert completions[0].complete == "c="
    assert completions[0].type == "param"
    assert completions[0].description == "param: (number) c=1"
    assert completions[0].parent == "f"
    assert completions[0].full_name == "f(a, b, c=1, d=2, e=3)"


# Generated at 2022-06-24 07:52:53.660651
# Unit test for function get_definitions
def test_get_definitions():
    def check_expected_result(source, expected_description, row, column):
        source_as_string = source.split("\n")
        definitions = get_definitions(source, row, column, "test.py")
        if len(definitions) > 0:
            definition = definitions[0]
            found_description = definition.description
            assert found_description == expected_description
        else:
            assert False, "Got no function definition"

    source = "def foo():\n" + "    print('hello world')\n"
    expected_description = "foo()"
    check_expected_result(source, expected_description, 1, 6)



# Generated at 2022-06-24 07:52:55.549025
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete = ThonnyCompletion("test", "test", "test", "test", "test", "test")
    assert test_complete.name == test_complete["name"]

# Generated at 2022-06-24 07:52:59.278576
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
    import datetime
    datetime.
    """
    result = get_script_completions(source, 2, 11, "test_get_script_completions.py")
    assert result[0].complete == "date("



# Generated at 2022-06-24 07:53:08.416675
# Unit test for function get_definitions
def test_get_definitions():
    line = 4

    def check_position(source, expected_line, expected_column=None, filename=None, sys_path=None):
        line = max(1, expected_line - 1)
        column = 0
        definitions = get_definitions(source, line, column, filename, sys_path)
        if definitions:
            if expected_column is not None:
                assert definitions[0].line == expected_line
                assert definitions[0].column == expected_column
            else:
                # can't check exact column number, because could be different even in the same version
                # with different source text
                assert definitions[0].line == expected_line

    # TODO: I should check that I get the right definition, not the first one
    # TODO: test more cases


# Generated at 2022-06-24 07:53:17.316576
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import subprocess
    from thonnycontrib.jediviewer.utils import get_definitions


# Generated at 2022-06-24 07:53:24.104461
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os, sys

    from jedi import interpreter

    class MockNameSpace:
        pass

    class MockInterpreter:
        """Mock class for jedi.Interpreter"""

        def __init__(self, source, namespaces):
            self.source = source
            self.namespaces = namespaces
            self.namespace = MockNameSpace()

            # prepare interpreter
            _interpreter_completions(self)

        def complete(self):
            """Mock function for jedi.Interpreter.complete()"""

            if self.source.endswith("()."):
                return self._completions
            else:
                return []

    # support for 0.17
    if hasattr(interpreter.Interpreter, "completions"):
        MockInterpreter.completions = MockInterpre

# Generated at 2022-06-24 07:53:32.595331
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api import classes
    from jedi.api import base

    # create fake definition object (name, description, type, parent)
    definition_obj = classes.ScopedName("a", base.Definition(None, None), base.Scope())
    definition_obj.description = "description of a"
    definition_obj.type = "type of a"
    definition_obj.parent = "parent of a"

    # create fake completion object (name, complete, type, parent)
    completion_obj = classes.Completion(definition_obj, None, None)
    completion_obj.complete = "complete of a"

    # test constructor

# Generated at 2022-06-24 07:53:37.635407
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    text = """
    import math
    math.
    """
    from parso.python.tree import PythonNode
    from parso.tree import NodeOrLeaf

    node = parse_source(text)
    assert isinstance(node, PythonNode)
    assert isinstance(get_statement_of_position(node, len(text)), NodeOrLeaf)

# Generated at 2022-06-24 07:53:43.366069
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c1 = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert c1["name"] == "name"
    assert c1["complete"] == "complete"
    assert c1["type"] == "type"
    assert c1["description"] == "description"
    assert c1["parent"] == "parent"
    assert c1["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:50.951833
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    from unittest.mock import Mock
    import jedi
    import thonny.jediutils

    # given
    source = "import sys; sys.stdout"
    row = 0
    column = len(source)
    filename = "test.py"
    goto_definitions_mock = Mock()
    jedi.Script.goto_definitions = goto_definitions_mock

    # when
    thonny.jediutils.get_definitions(source, row, column, filename)

    # then
    assert goto_definitions_mock.called

# Generated at 2022-06-24 07:53:54.217802
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("def f():\n    pri", 1, 11, "t.py")[0].name == "print"
    assert get_definitions("def f():\n    pri", 1, 11, "t.py")[0].module_name == 'builtins'

# Generated at 2022-06-24 07:54:00.871445
# Unit test for function get_definitions
def test_get_definitions():
    import inspect
    if 'Thonny.backend.jedi_backend' in inspect.getfile(test_get_definitions):
        from ..jedi_backend import get_definitions
    
    from unittest.mock import MagicMock
    def test_get_definitions_helper(code, expected):
        result = get_definitions(code, 1, 1, 'test.py')
        print(result)
        assert len(result) == len(expected), 'expected {} results got {}'.format(len(expected), len(result))
        for r, e in zip(result, expected):
            assert r.line == e.line, 'expected line {} got {}'.format(e.line, r.line)

# Generated at 2022-06-24 07:54:03.024056
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse


# Generated at 2022-06-24 07:54:06.671970
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert not ThonnyCompletion(name="name", complete="complete", type=1, description="description", parent="parent", full_name="full_name").__dict__.__eq__(dict({'name': 'name', 'complete': 'complete', 'description': 'description', 'parent': 'parent', 'full_name': 'full_name'}))

# Generated at 2022-06-24 07:54:09.403277
# Unit test for function parse_source
def test_parse_source():
    test_str = 'def foo():\n\tpass\n'
    assert parse_source(test_str).children[0].type == "def"



# Generated at 2022-06-24 07:54:18.938974
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("print(\"hello world\")", 0, -1, "") == [
        ThonnyCompletion(name="print", complete="print", type="function", description=None, parent=None, full_name="print"),
        ThonnyCompletion(name="print", complete="print", type="statement", description=None, parent=None, full_name="print"),
    ]

    assert get_definitions("from math import *", 0, -1, "") == [
        ThonnyCompletion(name="from", complete="from", type="keyword", description=None, parent=None, full_name="from")
    ]


# Generated at 2022-06-24 07:54:19.411276
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:54:21.791612
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("import sys", 0, 10, "")
    print(result)

# Generated at 2022-06-24 07:54:32.073508
# Unit test for function get_script_completions
def test_get_script_completions():

    import jedi

    if jedi.__version__[:4] in ("0.18", "0.19", "0.20"):
        COMPL_CODE = [
            "import math",
            'def f(x):\n'
            '    math',
            '    math.l',
            '    math.log',
            '    math.log(',
            '    math.log(x, ',
            '    math.log(x, 10',
            '    math.log(x, 10)',
            '    # math.log(x, 10)',
            '    # math.log(x, 10)',
            '    math',
        ]

# Generated at 2022-06-24 07:54:37.991152
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import numpy as np\nnp."
    row, column = source.count("\n") + 1, source.index('np.') + 3
    completions = get_script_completions(source, row, column, filename="module.py")
    assert completions
    assert any([c.name == "array" for c in completions])


if __name__ == "__main__":
    test_get_script_completions()
    print("OK")

# Generated at 2022-06-24 07:54:45.789569
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import api

    row = 2
    column = 1
    code = """def test_fn(a, b=2):
    x = [  
        a
    ]
    x"""
    filename = "example.py"
    completions = get_script_completions(code, row, column, filename)
    assert len(completions) == 6
    for completion in completions:
        assert completion.name in ("x", "test_fn", "a", "b", "int", "Example")
    try:
        api.Script(code, row, column, filename).completions()
        assert False, "Should raise ValueError"
    except ValueError:
        pass

    assert completions[0].name == "x"
    assert completions[0].complete == "x"

# Generated at 2022-06-24 07:54:46.431929
# Unit test for function parse_source

# Generated at 2022-06-24 07:54:46.977423
# Unit test for function get_interpreter_completions

# Generated at 2022-06-24 07:54:49.512713
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"

# Generated at 2022-06-24 07:54:53.951408
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("import sys; sys.path.", 1, 16, "dummy")
    assert len(result) == 2
    result = get_script_completions("import sys; sys.path.", 1, 16, "dummy", [])
    assert len(result) == 0

# Generated at 2022-06-24 07:55:04.760899
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree
    from parso.python import tree
    import jedi.parser_utils

    def _get_tree_elements(root):
        elements = root.get_descendants()
        elements.append(root)
        return elements

    node = parse_source("a = 0\nb = 1\n")
    statement_of_position = get_statement_of_position(
        node, parso.python.tree.Leaf(node, "=", 0, 1, 1, 2)
    )
    assert isinstance(statement_of_position, tree.AssignmentStmt)
    assert statement_of_position.get_code() == "a = 0"
    assert statement_of_position.start_pos == (1, 0)

# Generated at 2022-06-24 07:55:12.915186
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    pos = tree.Leaf(10, 2)
    pos.parent = tree.Node(4, 1)

    # first two assertions are for situation where pos is a leaf
    assert get_statement_of_position(pos.parent, pos.start_pos) == pos.parent
    assert get_statement_of_position(pos.parent, pos.end_pos) == pos.parent

    # now pos is the Node itself, and should work just like with Leaf
    assert get_statement_of_position(pos, pos.start_pos) == pos
    assert get_statement_of_position(pos, pos.end_pos) == pos

    # inside a Node, but in a child
    child = tree.Leaf(pos.start_pos, pos.end_pos)

# Generated at 2022-06-24 07:55:22.658597
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import testutils
    import traceback

    print("Testing jedi.utils.get_definitions")
    test_dir = os.path.dirname(os.path.dirname(testutils.__file__))
    test_dir = os.path.join(test_dir, "completion_test_input")
    for filename in os.listdir(test_dir):
        if not filename.endswith(".py"):
            continue
        print("Testing filename: " + filename)
        full_path = os.path.join(test_dir, filename)
        with open(full_path, "r") as f:
            text = f.read()
        lines = text.split("\n")
        for line in lines:
            if line.startswith("#"):
                continue

# Generated at 2022-06-24 07:55:27.048072
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("1+1").get_code() == "1+1"
    assert parse_source("1+1\n").get_code() == "1+1\n"
    assert parse_source("\n1+1").get_code() == "\n1+1"
    assert parse_source("\n1+1\n").get_code() == "\n1+1\n"

# Generated at 2022-06-24 07:55:31.089756
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"

# Generated at 2022-06-24 07:55:38.280822
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_ThonnyCompletion = ThonnyCompletion("TEST_NAME", "TEST_COMPLETE",
                                             "TEST_TYPE", "TEST_DESCRIPTION", "TEST_PARENT", "TEST_FULL_NAME")
    assert test_ThonnyCompletion.__getitem__("name") == "TEST_NAME"
    assert test_ThonnyCompletion.__getitem__("complete") == "TEST_COMPLETE"
    assert test_ThonnyCompletion.__getitem__("type") == "TEST_TYPE"
    assert test_ThonnyCompletion.__getitem__("description") == "TEST_DESCRIPTION"
    assert test_ThonnyCompletion.__getitem__("parent") == "TEST_PARENT"

# Generated at 2022-06-24 07:55:42.955283
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    compl = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert compl["name"] == "name"
    assert compl["complete"] == "complete"
    assert compl["type"] == "type"
    assert compl["description"] == "description"
    assert compl["parent"] == "parent"
    assert compl["full_name"] == "full_name"

# Generated at 2022-06-24 07:55:49.822792
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    # Represents: if a > 5: return True

# Generated at 2022-06-24 07:55:58.799783
# Unit test for function get_interpreter_completions

# Generated at 2022-06-24 07:56:05.130912
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    item = ThonnyCompletion(name ='name',
                            complete = 'complete',
                            type = 'type',
                            description = 'description',
                            parent = 'parent',
                            full_name = 'full_name')
    assert item['name'] == 'name'
    assert item['complete'] == 'complete'
    assert item['type'] == 'type'
    assert item['description'] == 'description'
    assert item['parent'] == 'parent'
    assert item['full_name'] == 'full_name'

# Generated at 2022-06-24 07:56:13.592821
# Unit test for function parse_source
def test_parse_source():
    import jedi
    import parso
    import ast

    # without error
    node = parse_source("def f(): pass")
    assert isinstance(node, parso.tree.Module)

    # with error
    node = parse_source("def f(): pass\n" + "fake code")
    assert isinstance(node, parso.tree.Module)

    # on python 3.8 (parso 2.3.0) Node.type is a enum
    if hasattr(parso.python.tree, "NodeType"):
        assert isinstance(node.type, parso.python.tree.NodeType)

    # https://github.com/parso-python/parso/issues/186
    # on python 3.8 (parso 2.3.0) Module.get_statement_for_position won't work

# Generated at 2022-06-24 07:56:21.130166
# Unit test for function parse_source
def test_parse_source():
    src = "def test(x):\n    pass"
    node = parse_source(src)
    assert isinstance(node, parso.tree.Module)
    assert node.type == "file_input"
    assert len(node.children) == 1

    func_node = node.children[0]
    assert func_node.type == "funcdef"
    assert func_node.children[1].type == "parameters"
    assert func_node.children[2].type == "suite"



# Generated at 2022-06-24 07:56:23.350992
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api import classes

# Generated at 2022-06-24 07:56:29.151572
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"
    assert completion["undefined_key"] == None
    assert completion.__getitem__("undefined_key") == None

# Generated at 2022-06-24 07:56:39.953475
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    assert get_statement_of_position(None, 0) is None

    from parso.python import tree
    import parso
    node = parso.parse(
        """
        if x:
            a
            b
        """
    )
    if_node = node.children[0]
    assert isinstance(get_statement_of_position(if_node, 0), tree.IfStmt)
    assert isinstance(get_statement_of_position(if_node, 1), tree.IfStmt)
    assert isinstance(get_statement_of_position(if_node, 2), tree.IfStmt)
    assert isinstance(get_statement_of_position(if_node, 3), tree.IfStmt)

# Generated at 2022-06-24 07:56:50.404681
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi
    import jedi.parser_utils
    import jedi.api.classes
    import thonny.jediutils


# Generated at 2022-06-24 07:56:51.742133
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("") is not None

# Generated at 2022-06-24 07:57:00.715667
# Unit test for function get_definitions
def test_get_definitions():
    from unittest.mock import patch, Mock

    for jedi_version in ["0.13", "0.14", "0.15", "0.16", "0.17", "0.18"]:
        with patch("thonny.jedi_utils.get_definitions") as mocked_func, patch("thonny.jedi_utils._using_older_jedi") as mocked_older_jedi:
            mocked_func.return_value = ["result 1", "result 2"]
            mocked_older_jedi.return_value = jedi_version < "0.18"
            result = get_definitions("source code", 1, 2, "test_name.py")
            assert result == ["result 1", "result 2"]
            if jedi_version < "0.18":
                mocked_func.assert_

# Generated at 2022-06-24 07:57:06.420270
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"



# Generated at 2022-06-24 07:57:15.759603
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:57:22.608974
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyComp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert "name" == ThonnyComp.name
    assert "complete" == ThonnyComp.complete
    assert "type" == ThonnyComp.type
    assert "description" == ThonnyComp.description
    assert "parent" == ThonnyComp.parent
    assert "full_name" == ThonnyComp.full_name

# Generated at 2022-06-24 07:57:25.017337
# Unit test for function get_definitions
def test_get_definitions():
    assert 3 == len(get_definitions(source='def foo(x):\n    y = x + 1 \nprint(foo(1))', row=2, column=12, filename="foo.py"))

# Generated at 2022-06-24 07:57:36.303525
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [
        {
            "builtins": {
                "open": object(),
                "print": object(),
                "save_notebook": object(),
                "test_value": object(),
            }
        }
    ]

# Generated at 2022-06-24 07:57:36.791452
# Unit test for function get_definitions

# Generated at 2022-06-24 07:57:40.973750
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("str.istr", 0, 0, "") == []
    assert get_script_completions("str.istr", 0, 4, "") == [ThonnyCompletion(
        name="istitle",
        complete="istitle",
        type="statement",
        description="istitle(${1:self, /})\n\nReturn True if the string is a title-cased string, i.e. uppercase characters may only follow uncased characters and lowercase characters only cased ones. Return False otherwise.",
        parent="str",
        full_name="str.istitle"
    )]



# Generated at 2022-06-24 07:57:45.258274
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = '''if True:\n    a = ""\n    b = ''\n    c = """\n'''
    res = parse_source(source)
    assert(isinstance(res, parso.tree.Module))

# Generated at 2022-06-24 07:57:47.003839
# Unit test for function get_script_completions
def test_get_script_completions():
    assert isinstance(get_script_completions(source="pri", row=0, column=2), list)

# Generated at 2022-06-24 07:57:58.869896
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    import parso

    def get_token(source: str, offset: int) -> tree.BaseNode:
        module = parse_source(source)
        return get_statement_of_position(module, offset)

    # 1. token, 2. expected name, 3. string

# Generated at 2022-06-24 07:58:06.622605
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    def test(key, expected):
        import jedi
        completion = jedi.Script("square(x").completions()[0]
        thonny_completion = ThonnyCompletion(
            name=completion.name,
            complete=completion.complete,
            type=completion.type,
            description=completion.description,
            parent=completion.parent,
            full_name=completion.full_name,
        )
        assert thonny_completion[key] == expected, thonny_completion[key]

    yield test, "name", "sqrt"
    yield test, "complete", "sqrt("
    yield test, "type", "statement"
    yield test, "description", "sqrt(x)\nReturn the square root of x."
    yield test, "parent", None

# Generated at 2022-06-24 07:58:09.444483
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:58:17.695722
# Unit test for function get_definitions
def test_get_definitions():
    """
    to test it, run
    python -m jedi.utils.thonnyutils
    """
    global counter
    counter = 0
    results = []
    src = """
        def fun(x):
            return x
        x = fun(y)
    """
    defs = get_definitions(src, 2, 17, "")
    for d in defs:
        print(d.name, d.full_name, d.module_path)
        results.append(d.name)
        counter += 1

    assert(counter == 2)
    assert("fun" in results)
    assert("x" in results)
    print("OK")


if __name__ == '__main__':
    test_get_definitions()

# Generated at 2022-06-24 07:58:23.513008
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from jedi.parser_utils import get_statement_of_position as func

    source = "foo\nbar\n"
    node = parso.parse(source)

    assert func(node, 0) is None
    assert func(node, 3) is node.children[0]
    assert func(node, 4) is node.children[1]
    assert func(node, 5) is node.children[2]
    assert func(node, 6) is None



# Generated at 2022-06-24 07:58:34.305665
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def assert_result(node, pos, expected_type, expected_start, expected_end):
        res = get_statement_of_position(node, pos)
        if res is not None:
            assert res.type == expected_type
            assert res.start_pos == expected_start
            assert res.end_pos == expected_end
        else:
            assert (
                expected_start is None and expected_end is None and expected_type is None
            ), "Expected node of type=%s, start=%s, end=%s, but was None" % (
                expected_type,
                expected_start,
                expected_end,
            )

    source = """
foo(a,
    b,
    c,
    d=4,
    e=5)
"""
    node = parse_source(source)

# Generated at 2022-06-24 07:58:37.683946
# Unit test for function parse_source
def test_parse_source():
    source = "import os,sys"
    tree = parse_source(source)
    assert tree.type == "file_input"
    assert len(tree.children) == 3
    for child in tree.children:
        assert child.type in ("import_name", "import_from")

# Generated at 2022-06-24 07:58:40.722457
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion["name"] == "name"

# Generated at 2022-06-24 07:58:46.671123
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """Test get_interpreter_completions."""
    import jedi

    my_namespaces = [{"test": jedi}]
    completions = get_interpreter_completions("jedi.", my_namespaces)
    assert {"jedi": "jedi", "jedi.api": "jedi.api"} == set(
        [(c.name, c.description) for c in completions]
    )

# Generated at 2022-06-24 07:58:55.205672
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'a'
    complete = 'a'
    type = 'bool'
    description = 'desc'
    parent = 'parent'
    full_name = 'full_name'
    thonny_completion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert(thonny_completion['name'] == 'a')
    assert(thonny_completion['complete'] == 'a')
    assert(thonny_completion['type'] == 'bool')
    assert(thonny_completion['description'] == 'desc')
    assert(thonny_completion['parent'] == 'parent')
    assert(thonny_completion['full_name'] == 'full_name')

test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:59:02.651639
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def check(src, pos, expected_end_pos):
        module = parse_source(src)
        stat = get_statement_of_position(module, pos)
        assert isinstance(stat, tree.Statement)
        assert stat.end_pos == expected_end_pos

    check("a, b", 3, 3)
    check("a, b", 0, 1)
    check("from os import path\na, b", 16, 16)
    check("from os import path\na, b\nprint(c, d)", 26, 26)

# Generated at 2022-06-24 07:59:06.749560
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert complete.name == "name"
    assert complete.complete == "complete"
    assert complete.type == "type"
    assert complete.description == "description"
    assert complete.parent == "parent"
    assert complete.full_name == "full_name"



# Generated at 2022-06-24 07:59:15.340008
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check(s, pos, result_s):
        scope = parse_source(s)
        pos = scope.get_position_for_offset(pos)
        node = get_statement_of_position(scope, pos)
        if node is None:
            assert result_s is None
        else:
            assert node.get_code().strip() == result_s.strip()

    check('f(g())', 0, "f(g())")
    check('f(g())', 4, "f(g())")
    check('f(g())', 5, "g()")
    check('f(g())', 6, "g()")
    check('f(g())', 7, "g()")
    check('f(g())', 8, "f(g())")

# Generated at 2022-06-24 07:59:16.225069
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-24 07:59:17.576855
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi


# Generated at 2022-06-24 07:59:25.332834
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from thonny.plugins.jedi_backend import utils

    thonny_completion = utils.ThonnyCompletion(
        name='name',
        complete='complete',
        type='type',
        description='description',
        parent='parent',
        full_name='full_name',
    )
    assert thonny_completion.__getitem__('name') == 'name'
    assert thonny_completion.__getitem__('complete') == 'complete'
    assert thonny_completion.__getitem__('type') == 'type'
    assert thonny_completion.__getitem__('description') == 'description'
    assert thonny_completion.__getitem__('parent') == 'parent'

# Generated at 2022-06-24 07:59:36.519502
# Unit test for function get_script_completions
def test_get_script_completions():
    import textwrap

    def _assert_results(source, expected):
        result = get_script_completions(source, row=1, column=1, filename="/tmp/t.py")
        assert [c["name"] for c in result] == expected

    _assert_results("x = z.", ["zfill"])
    _assert_results("x = z.zf", ["zfill"])
    _assert_results("x = z.zfill(wi", ["width"])
    _assert_results("x = z.zfill(width=", ["42"])
    _assert_results("x = z.zfill(width=42,", ["foo"])
    _assert_results("x = z.zfill(width=42, foo=", ["b"])

# Generated at 2022-06-24 07:59:42.944840
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.python_shell_code_model import check_function_name


# Generated at 2022-06-24 07:59:48.887996
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    t = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert t.name == "name"
    assert t.complete == "complete"
    assert t.type == "type"
    assert t.description == "description"
    assert t.parent == "parent"
    assert t.full_name == "full_name"

# Generated at 2022-06-24 07:59:59.042720
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    def completion(name, description):
        return {
            "name": name,
            "complete": name,
            "type": "",
            "description": description,
            "parent": "",
            "full_name": name,
        }

    completions = [
        ThonnyCompletion(**completion("a", "descr 1")),
        ThonnyCompletion(**completion("b", "descr 2")),
        ThonnyCompletion(**completion("c", "descr 3")),
    ]

    assert completions[0]["name"] == "a"
    assert (
        completions[0]["complete"]
        == "a"
    ), "parameter 'complete' should match parameter 'name'"
    assert completions[1]["name"] == "b"

# Generated at 2022-06-24 08:00:00.261261
# Unit test for function get_definitions

# Generated at 2022-06-24 08:00:11.722787
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():

    source = "import os\nos."
    completions = get_interpreter_completions(source, [])
    completions = sorted(completions, key=lambda x: x.name)
    assert completions[0].name == "access"
    assert completions[0].full_name == "os.access"
    assert completions[0].type == "function"
    assert completions[0].parent == "os"
    assert completions[0].description is not None

    assert completions[1].name == "altsep"
    assert completions[1].full_name == "os.altsep"
    assert completions[1].type == "str"
    assert completions[1].parent == "os"
    assert completions[1].description is not None


# Generated at 2022-06-24 08:00:15.530945
# Unit test for function parse_source
def test_parse_source():
    source = "def f() -> int: pass"

    node = parse_source(source)
    # the assert is empty
    assert node

# Generated at 2022-06-24 08:00:19.785162
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # Try if the function works for the same input on both jedi versions
    import jedi
    import parso
    if _using_older_jedi(jedi):
        parse_fun = jedi.parser.Parser.parse
    else:
        parse_fun = parso.parse

# Generated at 2022-06-24 08:00:26.340927
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.jedi_utils import load_jedi_script_completions
    from jedi.parser_utils import get_parent_scope
    from jedi import Script, Interpreter

    def convert_param_list_to_dict(params):
        params_dict = []
        for param in params:
            params_dict.append({"name": param.name, "type": param.type, "description": param.description})
        return params_dict

    def assert_expected_completion(completion, expected_completion):
        assert completion.name == expected_completion["name"]
        assert completion.complete == expected_completion["complete"]
        assert completion.type == expected_completion["type"]
        assert completion.description == expected_completion["description"]

# Generated at 2022-06-24 08:00:35.874915
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso import parse
    import jedi


# Generated at 2022-06-24 08:00:43.483916
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 08:00:53.139790
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    k1 = "name"
    k2 = "complete"
    k3 = "type"
    k4 = "description"
    k5 = "parent"
    k6 = "full_name"
    v1 = "testname"
    v2 = "testcomplete"
    v3 = "testtype"
    v4 = "testdescription"
    v5 = "testparent"
    v6 = "testfull_name"
    t = ThonnyCompletion(v1, v2, v3, v4, v5, v6)
    if t[k1] != v1:
        return False
    if t[k2] != v2:
        return False
    if t[k3] != v3:
        return False
    if t[k4] != v4:
        return False
   

# Generated at 2022-06-24 08:00:59.756454
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    print(get_interpreter_completions('print(', [{}]))
    print(get_interpreter_completions('print(', [{"__builtins__": {}}]))
    
    def foo():
        a = 1
        # Enter here
        # See that a is not visible
        print(get_interpreter_completions('print(', [{"__builtins__": {}, "__name__": "bla"}]))
    
    
if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 08:01:04.872385
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name= "name",
        complete= "complete",
        type= "type",
        description= "description",
        parent= "parent",
        full_name= "full_name",
    )
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 08:01:08.825487
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    version = jedi.__version__
    print('v', version)
    source = 'self.g'
    row = 0
    column = 7
    filename = 'x.py'
    completions = get_script_completions(source, row, column, filename)
    print('c', completions)

if __name__ == '__main__':
    test_get_script_completions()

# Generated at 2022-06-24 08:01:18.442987
# Unit test for function get_script_completions
def test_get_script_completions():
    # Testing with jedi <= 0.16.0
    from test.test_editor import get_test_script
    from thonny.plugins.jedi_backend.jedi_utils import get_script_completions

    # Completion for "a" in "print(a)"
    source = get_test_script("print(a)")
    completions = get_script_completions(source, 1, 6, "test.py")

    # Testing with jedi >= 0.17.0
    from test.test_editor import get_test_script
    from thonny.plugins.jedi_backend.jedi_utils import get_script_completions

    # Completion for "a" in "print(a)"
    source = get_test_script("print(a)")
    completions = get_script

# Generated at 2022-06-24 08:01:28.488506
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase

    class Test(TestCase):
        def assert_definitions_equal(self, source, row, column, expected_defs):
            actual_defs = get_definitions(source, row, column, "")
            self.assertEqual(len(actual_defs), len(expected_defs))
            for i in range(len(actual_defs)):
                self.assertEqual(actual_defs[i].name, expected_defs[i][0])
                self.assertEqual(actual_defs[i].line, expected_defs[i][1])
                self.assertEqual(actual_defs[i].column, expected_defs[i][2])