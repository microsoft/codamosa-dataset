

# Generated at 2022-06-24 07:51:12.986519
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import representation as er
    from jedi.evaluate.context import InterpreterContext
    from jedi.evaluate.context import ModuleContext
    from jedi.evaluate.context.compiled.module import CompiledObject
    from jedi.parser_utils import get_cached_code_lines
    from thonny.plugins.backend import BackendPlugin

    import parso
    import jedi
    import jedi.evaluate.representation as er
    import jedi.evaluate.context as ec

    import os
    import sys
    import pytest
    import string

    test_dir = os.path.dirname(__file__)
    source = "import string"

    script = jedi.Script(source=source)
    defs = script.infer(line=1, column=8)


# Generated at 2022-06-24 07:51:18.084508
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("a = list(map(int, ", [{"locals": {"a": "a"}}, {}, {}], [".", "..", "../../"])
    assert get_interpreter_completions("a = list(map(int, ", [{"locals": {"a": "a"}}, {}, {}])

# Generated at 2022-06-24 07:51:29.834198
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys

    if sys.version_info[0] == 2:
        # TODO: enable back after Python2 support is removed
        pass
    else:
        from unittest.mock import MagicMock, call
        from jedi.api import Interpreter, Script

        interpreter = Interpreter(
            "foo", [{"x": 1, "y": 2}, {"a": 3, "b": 4}], sys_path=["/foo", "/bar"]
        )
        interpreter.complete = MagicMock()
        interpreter.completions = MagicMock()

        result = get_interpreter_completions("foo", [{"x": 1, "y": 2}, {"a": 3, "b": 4}])
        assert interpreter.completions.call_count == 1
        assert result == interpreter.completions

# Generated at 2022-06-24 07:51:38.173154
# Unit test for function get_definitions
def test_get_definitions():
    import jedi.api
    import parso
    
    # Test two parts:
    # 1. Test correctness against jedi.api.Script.goto_definitions by creating a jedi.api.Script.
    # 2. Test that the result contains expected elements and is not empty.
    
    # Test with sys.argv
    source = "import sys\nsys.arg"
    row = 2
    column = 7
    filename = "<example.py>"
    definitions_api = jedi.api.Script(source, row, column, filename).goto_definitions()
    definitions_method = get_definitions(source, row, column, filename)
    
    # Test one of the results (there should be only one)
    assert len(definitions_method) == 1
    definition_method = definitions_method[0]
   

# Generated at 2022-06-24 07:51:42.684412
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import os\n" "os.path.", 7, 8)

# Generated at 2022-06-24 07:51:48.253180
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        "abc",
        "abc completions",
        "function",
        "description",
        "parent",
        "full name"
    )
    assert completion.name == "abc"
    assert completion.complete == "abc completions"
    assert completion.type == "function"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full name"

# Generated at 2022-06-24 07:51:58.364068
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, mock
    from queue import Queue
    from test.debugger.helpers import MockRequestHandler

    def run_test(http_method, code):
        handler = MockRequestHandler()
        with mock.patch("time.time", return_value=1.0):
            handler.log_message("Starting")
        with mock.patch("time.time", return_value=2.0):
            handler.handle()
        with mock.patch("time.time", return_value=3.0):
            handler.log_message("Finished")

        handler.method = http_method
        handler.headers = {"Content-Length": str(len(code))}
        handler.rfile = mock.MagicMock()
        handler.rfile.read = mock.MagicMock(return_value=code)
       

# Generated at 2022-06-24 07:52:06.872608
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import os
    import sys

    THONNY_USER_DIR = os.path.abspath(os.path.expanduser("~/.thonny"))
    sys.path.insert(0, os.path.join(THONNY_USER_DIR, "backend_utils"))
    import monkeypatching

    monkeypatching.try_monkeypatching_stdlib()

    import jedi
    from jedi.parser_utils import get_statements
    from jedi.api.interpreter import Interpreter
    from jedi import ParserError


# Generated at 2022-06-24 07:52:08.843222
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    result = tc.__getitem__("name")
    assert result == "name"



# Generated at 2022-06-24 07:52:11.234308
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import sys
    ThonnyCompletion(name=1,complete=2,type='module',description=sys.version,parent=sys,full_name=sys.version)

# Generated at 2022-06-24 07:52:21.011886
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.cache import parser_cache
    from thonny.jedi_utils import get_statement_of_position

    def get_node(source, pos):
        module = parser_cache.get_module(
            "", None, None, parser_version=tree.PYTHON_VERSION
        )
        module.update(parser_cache._get_parser(source, "", "").parse())
        return get_statement_of_position(module, pos)

    def check_node(source, pos, node_type, start_pos, end_pos):
        node = get_node(source, pos)
        assert node.type == node_type
        assert node.start_pos == start_pos
        assert node.end_pos == end_pos


# Generated at 2022-06-24 07:52:26.950229
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name='name',complete='complete',type='type',description='description',parent='parent',full_name='full_name')
    assert completion.__getitem__('name') == 'name'
    assert completion.__getitem__('complete') == 'complete'
    assert completion.__getitem__('type') == 'type'
    assert completion.__getitem__('description') == 'description'
    assert completion.__getitem__('parent') == 'parent'
    assert completion.__getitem__('full_name') == 'full_name'



# Generated at 2022-06-24 07:52:37.846417
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.plugins.jedi_utils import get_definitions
    from jedi.api.classes import Name
    result = get_definitions(
        "import os\nos.path.join(", row=0, column=12, filename="file.py"
    )
    assert isinstance(result, list)
    assert isinstance(result[0], Name)
    assert result[0].name == "join"
    assert result[0].parent().name == "os.path"

    # test multi-level import
    result = get_definitions(
        "import numpy.random\nnumpy.random.rand(", row=0, column=12, filename="file.py"
    )
    assert isinstance(result, list)
    assert isinstance(result[0], Name)

# Generated at 2022-06-24 07:52:46.296947
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = """def f():
    a = 1
    if a:
        x = 2
        y = 2
    b = 3
    while a:
        x = 2
        y = 2"""
    tree = parse_source(source)

    assert get_statement_of_position(tree, (3, 4)) == tree.children[1]
    assert get_statement_of_position(tree, (4, 6)) == tree.children[1]
    assert get_statement_of_position(tree, (5, 10)) == tree.children[1].children[2]
    assert get_statement_of_position(tree, (6, 10)) == tree.children[1].children[3]
    assert get_statement_of_position(tree, (7, 4)) == tree.children[1]
    assert get_statement_of

# Generated at 2022-06-24 07:52:55.946559
# Unit test for function get_definitions
def test_get_definitions():
    def get_defs(code):
        return [d.module_name for d in get_definitions(code, 0, 0, "")]

    assert get_defs('import foo') == ["foo"]
    assert get_defs('from foo import bar') == ["foo"]
    assert get_defs('from foo import bar, baz') == ["foo"]
    assert get_defs('import sphinx.util as util') == ["sphinx.util"]
    assert get_defs('import sphinx.util as util, os.path') == ["sphinx.util", "os.path"]
    assert get_defs('from sphinx.util import logging') == ["sphinx.util"]
    assert get_defs('from sphinx.util import logging as log') == ["sphinx.util"]


# Generated at 2022-06-24 07:52:58.650204
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import collections
    assert isinstance(ThonnyCompletion('str','str','str','str','str','str'), collections.abc.Sequence)

# Generated at 2022-06-24 07:53:00.905409
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    com = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert com.__getitem__('complete') == com.complete

# Generated at 2022-06-24 07:53:01.828377
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module
    

# Generated at 2022-06-24 07:53:04.532927
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:07.502758
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tw = ThonnyCompletion(name="print", complete="print ", type="function", description="print", parent=None, full_name="print")
    assert tw.name == "print"

# Generated at 2022-06-24 07:53:10.808840
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert tc["name"] == "name"
    assert tc["complete"] == "complete"
    assert tc["type"] == "type"
    assert tc["description"] == "description"
    assert tc["parent"] == "parent"
    assert tc["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:11.320059
# Unit test for function parse_source
def test_parse_source():
    parse_source("print()")


# Generated at 2022-06-24 07:53:19.963457
# Unit test for function get_definitions
def test_get_definitions():
    def test_one_file(source, row, column, expected_definitions):
        import jedi

        definitions = get_definitions(source, row, column, "/some/dummy/file.py")

        print(definitions)

        if len(definitions) != len(expected_definitions):
            raise Exception(
                "Expected exactly %d definitions, got %d"
                % (len(expected_definitions), len(definitions))
            )

        for i in range(len(definitions)):
            actual = definitions[i].line
            expected = expected_definitions[i]
            if actual != expected:
                raise Exception(
                    "Expected definition at line %d, got line %d" % (expected, actual)
                )


# Generated at 2022-06-24 07:53:29.712313
# Unit test for function get_definitions
def test_get_definitions():
    source = "import math; math.sqrt(3)"

    bufs = _get_buffer_list_contents()
    for pos, expected_file in [
        (14, "math.py"),
        (21, "__init__.py"),
        (48, "math.py"),
    ]:
        definitions = get_definitions(source, *_to_coordinate(pos), filename=__file__)
        assert len(definitions) == 1
        assert definitions[0].module_name == "math"
        assert definitions[0].line == 1
        # FIXME: don't hardcode path
        assert definitions[0]._definition.path.endswith("Lib/math.py")
        with open(definitions[0]._definition.path) as fp:
            buffer_content = fp.read()


# Generated at 2022-06-24 07:53:36.212673
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import sys
    if sys.version_info >= (3, 6):

        # Test standard "class" completion
        code = "class A: pass\nA."
        row, column = 2, 3
        completions = get_script_completions(code, row, column, "")
        assert len(completions) == 1
        assert completions[0].name == "__init__"
        assert completions[0].description == "A.__init__(${1:self}, ${2:...})\nConstructor for A.\n\nCalls constructor for the parent class ${3:object}\n${4:first}."
        assert completions[0].complete == "__init__"
        assert completions[0].type == "statement"
        assert completions[0].parent == "A"


# Generated at 2022-06-24 07:53:44.593080
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree
    
    def make_blank_line(pos):
        return tree.Leaf(u"pass", pos, pos+1)
    
    def make_node(start, end):
        return tree.Node("foo", (make_blank_line(start), make_blank_line(end)))
    
    code = "def foo():\n    pass\n    pass\npass\n" + \
           "pass\npass\n\n\npass\n"
    
    node = parso.parse(code)
    assert get_statement_of_position(node, 0) == node
    assert get_statement_of_position(node, 1) == node   # start of def block

# Generated at 2022-06-24 07:53:53.983181
# Unit test for function get_script_completions
def test_get_script_completions():
    # Using older jedi
    completions = get_script_completions(
        source="pri", row=0, column=3, filename=os.path.expanduser("~/temp.py")
    )
    assert len(completions) == 1
    assert completions[0].name == "print("

    # Using jedi 0.18
    completions = get_script_completions(
        source="pri", row=0, column=3, filename=os.path.expanduser("~/temp.py")
    )
    assert len(completions) == 1
    assert completions[0].name == "print("

    # Using older jedi

# Generated at 2022-06-24 07:54:04.031433
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi.api.classes import Definition

    assert len(get_definitions("def t", 0, 0, "")) == 1
    assert len(get_definitions("def t", 0, 4, "")) == 1
    assert "t" in str(get_definitions("def t", 0, 4, ""))
    
    if _using_older_jedi(jedi):
        assert len(get_definitions("import sys", 0, 0, "")) == 1
        assert len(get_definitions("import sys", 0, 7, "")) == 1
        assert "sys" in str(get_definitions("import sys", 0, 7, ""))
        assert len(get_definitions("import sys", 0, 7, "", sys_path = [])) == 1

# Generated at 2022-06-24 07:54:05.265339
# Unit test for function get_definitions

# Generated at 2022-06-24 07:54:16.172550
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os
    import tempfile
    import subprocess
    import tkinter as tk
    import tkinter.ttk as ttk

    # TODO: check that no jedi completions are returned
    temp_dir = tempfile.gettempdir()

    test_code = """
        import tkinter

        root = tkinter.Tk()
        root.m"""

    # Call get_script_completions
    completions = get_script_completions(test_code, 4, 14, os.path.join(temp_dir, "test.py"))

    # Check results
    assert len(completions) == 4, "Unexpected number of completions: " + repr(completions)


# Generated at 2022-06-24 07:54:19.300415
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = "def f():\n    return True\n"
    pos = len(source) - 1
    ast_tree = parse_source(source)
    statement = get_statement_of_position(ast_tree, pos)
    assert statement is not None
    assert statement.type == "return_stmt"

# Generated at 2022-06-24 07:54:23.296808
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = 'a = 1\nf = lambda: a\nf()'
    node = parse_source(source)
    assert get_statement_of_position(node, len(source) - 1) is node.children[-1]

# Generated at 2022-06-24 07:54:29.746843
# Unit test for function parse_source
def test_parse_source():
    src = 'p = 5\np' # test_sources.py
    node = parse_source(src)
    assert node.start_pos == (1, 0)
    assert node.end_pos == (2, 1)
    assert node.type == 'file_input'
    assert node.children[0].type == 'simple_stmt'
    assert node.children[0].children[0].type == 'expr_stmt'

# Generated at 2022-06-24 07:54:31.293411
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('') is not None
    assert parse_source('def foo():') is not None


# Generated at 2022-06-24 07:54:41.433504
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from types import ModuleType
    import unittest

    class DummyModule(ModuleType):
        def __init__(self, name="dummy_module"):
            ModuleType.__init__(self, name)

        def _get_completions(self):
            return [
                ThonnyCompletion(name="completion1", complete="completion2", type="sometype", description="somedesc", parent=None, full_name="completion1")
                for _ in range(5)
            ]

    dummy_module = DummyModule()
    from jedi.evaluate import Interpreter
    from jedi.evaluate.compiled import CompiledObject
    from jedi.parser_utils import get_cached_code_lines


# Generated at 2022-06-24 07:54:45.726917
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="test_name", complete="test_complete", type=1, description="test_description", parent=2, full_name=3
    )
    assert completion["name"] == completion.name
    assert completion["complete"] == completion.complete
    assert completion["type"] == completion.type
    assert completion["description"] == completion.description
    assert completion["parent"] == completion.parent
    assert completion["full_name"] == completion.full_name

# Generated at 2022-06-24 07:54:53.606996
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    def check():
        ThonnyCompletion(
            name="name1",
            complete="complete1",
            type=1,
            description="description1",
            parent=1,
            full_name="full_name1",
        )["name"] == "name1"
        ThonnyCompletion(
            name="name2",
            complete="complete2",
            type=2,
            description="description2",
            parent=2,
            full_name="full_name2",
        )["complete"] == "complete2"
        ThonnyCompletion(
            name="name3",
            complete="complete3",
            type=3,
            description="description3",
            parent=3,
            full_name="full_name3",
        )["type"] == 3

# Generated at 2022-06-24 07:54:59.316537
# Unit test for function parse_source
def test_parse_source():
    import parso
    import jedi.parser_utils

    try:
        # parso >= 0.7.0
        assert parso.parse("def foo():\n    pass") != None
    except AssertionError:
        # parso < 0.7.0
        assert jedi.parser_utils.parse("def foo():\n    pass") != None

# Generated at 2022-06-24 07:55:08.118211
# Unit test for function get_definitions
def test_get_definitions():
    from os.path import join, dirname
    from unittest.mock import MagicMock
    from unittest.mock import patch
    import tkinter.messagebox

    def mock_get_definitions(source: str, row: int, column: int, filename: str):
        if filename == 'foo.py':
            return [MagicMock(module_path=join(dirname(__file__), 'dummy.py'), line=11,
                              column=3, name='bar', full_name='bar')]
        elif filename == 'notabar.py':
            return [MagicMock(module_path=join(dirname(__file__), 'dummy.py'), line=11,
                              column=3, name='notabar', full_name='notabar')]

# Generated at 2022-06-24 07:55:09.335265
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    # sample code

# Generated at 2022-06-24 07:55:16.624280
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    script = jedi.Script(code="import sys", path="")
    completions = script.complete(line=1, column=8)
    completion = completions[0]
    name = completion.name
    complete = completion.complete
    type = completion.type
    description = completion.description
    parent = completion.parent
    full_name = completion.full_name

    completion_one_in_list = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert completion_one_in_list.complete == completion.complete
    assert completion_one_in_list.type == completion.type
    assert completion_one_in_list.description == completion.description
    assert completion_one_in_list.parent == completion.parent
    assert completion_one_in_list.full

# Generated at 2022-06-24 07:55:25.066646
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.utils import setup_readline
    setup_readline()

    # Setup.
    import jedi

    jedi.settings.case_insensitive_completion = True
    jedi.settings.add_bracket_after_function = True

    # The code you want to complete, type a dot and see the awesome autocompletion.
    source = """
from tkinter import *

root = Tk()

root.mainloop()
"""

    script = get_script_completions(source, 2, 0)
    assert len(script) > 0
    assert "from " in [x["complete"] for x in script]
    assert "tkinter" in [x["name"] for x in script]



# Generated at 2022-06-24 07:55:32.472330
# Unit test for function get_definitions
def test_get_definitions():
    # jedi 0.14 and 0.15 only
    # jedi 0.16 and 0.17
    definitions = get_definitions("class A: pass\na=A()", 2, 5, "test.py")
    assert len(definitions) == 1
    assert isinstance(definitions[0], ThonnyCompletion)
    assert definitions[0].name == "A"
    assert definitions[0].complete == "A"
    assert definitions[0].type == "class"
    assert definitions[0].description == "class A"
    assert definitions[0].parent == "test"
    assert definitions[0].full_name == "test.A"

# Generated at 2022-06-24 07:55:33.249162
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # TODO: unit test for function get_statement_of_position
    pass

# Generated at 2022-06-24 07:55:40.351520
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c1 = ThonnyCompletion(name="name", complete="complete", type="type", description="desc", parent="parent", full_name="full_name")
    assert c1.name == "name"
    assert c1.complete == "complete"
    assert c1.type == "type"
    assert c1.description == "desc"
    assert c1.parent == "parent"
    assert c1.full_name == "full_name"

    c2 = ThonnyCompletion(name="n", complete="c", type="t", description="d", parent="p", full_name="f")
    assert c2.name == "n"
    assert c2.complete == "c"
    assert c2.type == "t"
    assert c2.description == "d"

# Generated at 2022-06-24 07:55:44.077177
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    a = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert a.name == 'name'
    assert a.complete == 'complete'
    assert a.type == 'type'
    assert a.description == 'description'
    assert a.parent == 'parent'
    assert a.full_name == 'full_name'

# Generated at 2022-06-24 07:55:53.264385
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import ast
    if jedi.__version__[:4] == "0.12":
        return # skip this test on old jedi
    result = get_script_completions("os.path.exi", 0, 12, "", [])
    assert len(result) == 1
    assert result[0].name == "exists"
    assert result[0].complete == "exist"
    assert result[0].type == "statement"
    assert result[0].description == "exists(path)"
    assert result[0].parent == "os.path"
    assert result[0].full_name == "os.path.exists"

# Generated at 2022-06-24 07:56:00.655698
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os.path
    import tempfile

    test_files = [
        # test_script.py
        """import datetime

foo = datetime.date
        """,
        # test_pkg/test_module.py
        """def func():
    pass
        """,
        # test_pkg/__init__.py
        """from . import test_module
        """,
    ]

    temp_dir = tempfile.TemporaryDirectory()
    sys.path.insert(0, temp_dir.name)

# Generated at 2022-06-24 07:56:09.585626
# Unit test for function get_definitions
def test_get_definitions():
    source = "import math\n"
    source += "def func(x,y):\n"
    source += "    print(x,y)\n"
    source += "    print(math.sin(x))\n"
    source += "func(2,3)\n"
    source += "print(math.sin(math.pi))\n"

    # Test function definition
    defs = get_definitions(source, 1, 1, "main.py")
    assert len(defs) == 1
    assert defs[0].module_name == "main"
    assert defs[0].line == 1
    assert defs[0].column == 4
    assert defs[0].type == "function"

    # Test function call

# Generated at 2022-06-24 07:56:17.156324
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_name = "test"
    test_complete = "test"
    test_type = "test"
    test_description = "test"
    test_full_name = "test"
    test_parent = "test"
    test_ThonnyCompletion = ThonnyCompletion(test_name, test_complete, test_type, test_description, test_parent, test_full_name)
    if test_ThonnyCompletion.name != test_name:
        print("error in name")
    if test_ThonnyCompletion.complete != test_complete:
        print("error in complete")
    if test_ThonnyCompletion.type != test_type:
        print("error in type")
    if test_ThonnyCompletion.description != test_description:
        print("error in description")
   

# Generated at 2022-06-24 07:56:20.943858
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    s = "import test\ntest.a.b.c(   )"
    d = parse_source(s)
    assert get_statement_of_position(d, len(s) - 1) == d.children[-1].children[-1]

# Generated at 2022-06-24 07:56:29.636076
# Unit test for function get_script_completions
def test_get_script_completions():
    from collections import namedtuple
    jedi_result = namedtuple("jedi_result", ["name", "complete", "type", "description"])
    jedi_result.__getitem__ = lambda self, key: self.__dict__[key]
    result = get_script_completions("", 1, 1, "")
    assert result == []

    result = get_script_completions("a = 1\n", 2, 1, "")

    assert len(result) == 2
    assert result[0] == ThonnyCompletion(name="a", complete="a", type="name", description="int", parent=None, full_name=None)

# Generated at 2022-06-24 07:56:33.431231
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import MagicMock
    import jedi

    jedi.Interpreter = MagicMock()
    jedi.Interpreter.return_value.complete.return_value = [
        MagicMock(
            name="some_name", complete="some_complete", type="some_type", description="..."
        )
    ]
    assert ThonnyCompletion(
        name="some_name", complete="some_complete", type="some_type", description="..."
    ) in get_interpreter_completions("", [])

# Generated at 2022-06-24 07:56:35.182102
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("def foo():\n    pass").children[0].type == "funcdef"



# Generated at 2022-06-24 07:56:36.056225
# Unit test for function parse_source

# Generated at 2022-06-24 07:56:46.345831
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    filename = "test.py"
    source = "a = max(1, 2)"

    # running Jedi from code
    res1 = get_definitions(source, len(source), len(source), filename)
    if _using_older_jedi(jedi):
        compliment_msg = " JEDI version is too old.  Please update it."
    else:
        compliment_msg = ""
    assert len(res1) == 1, "Expected 1 result, but got {}".format(len(res1)) + compliment_msg

    # running Jedi from command-line (jedi.api)
    res2 = jedi.api.names(source, pos=(len(source), len(source)), path=filename)
    assert len(res2) == 1

    # These two results should be the same
    res1

# Generated at 2022-06-24 07:56:54.915632
# Unit test for function get_definitions
def test_get_definitions():
    def get_defs(code, row, col):
        return [
            (def_obj.line, def_obj.column, def_obj.module_name)
            for def_obj in get_definitions(code, row, col, "/tmp/x.py")
        ]

    assert get_defs(
        'import foo\nfoo.bar(1)', 2, 10
    ) == [(1, 7, "foo")]  # qualified name
    assert get_defs('import foo\nbar(1)', 2, 5) == [(1, 0, "?")]  # unqualified name
    assert get_defs('with open("x"):\n  pass', 2, 5) == [(1, 0, "_io.py")]  # with statement: returns IO context manager


# Generated at 2022-06-24 07:57:04.037311
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from jedi.parser_utils import get_statement_of_position
    from parso.parser import Parser

    def check_get_statement(source, pos, expected_code):
        node = Parser(source).module()
        statement = get_statement_of_position(node, pos)
        assert statement.get_code() == expected_code

    check_get_statement("a = 3", 3, "a = 3")
    check_get_statement("class A:\n    pass", 10, "pass")
    check_get_statement("while a:\n    pass\n    pass", 10, "pass")
    check_get_statement("def f():\n    pass\n    pass", 10, "pass")

# Generated at 2022-06-24 07:57:14.376280
# Unit test for function get_definitions
def test_get_definitions():
    def check(text, position, expected):
        print()
        print(text)

        # in jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
        # since 0.16 it does. Need to ensure similar result for all supported versions.

        if isinstance(expected, tuple):
            expected_name, expected_type, expected_description_start, expected_full_name = expected
        else:
            expected_name, expected_type, expected_description_start, expected_full_name = (
                expected,
                None,
                None,
                None,
            )

        # Remove '=' from the expected name.
        # To ease debugging, allow both '=' and '='
        if expected_name.endswith("="):
            expected_name = expected_name[:-1]

        source,

# Generated at 2022-06-24 07:57:25.227485
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from unittest.mock import Mock, patch
    from collections import namedtuple

    Node = namedtuple("Node", "start_pos end_pos type children")
    Node.__getitem__ = lambda self, key: self.children[key]

    Node.__len__ = lambda self: len(self.children)

    n0 = Node(start_pos=(1,1), end_pos=(1,1), type="file_input", children=[])
    n1 = Node(start_pos=(1,1), end_pos=(1,1), type="decorated", children=[None, n0])
    n2 = Node(start_pos=(1,1), end_pos=(1,1), type="funcdef", children=[None, None, None])

# Generated at 2022-06-24 07:57:35.990072
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class Test(TestCase):
        def test_basic(self):
            completions = get_interpreter_completions(
                source="{}.f".format("a"), namespaces=[{"a": {"f": {"g": 1}}}]
            )
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0].name, "g")
            self.assertEqual(completions[0].full_name, "a.f.g")

    import unittest

    unittest.TextTestRunner().run(unittest.makeSuite(Test))


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 07:57:43.138559
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import mock
    import jedi

    complet_dictionary = dict(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    with mock.patch.object(jedi.Completion, "__getitem__", return_value=complet_dictionary):
        completion = ThonnyCompletion(
            name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
        )

        assert completion["name"] == "name"
        assert completion["complete"] == "complete"
        assert completion["type"] == "type"
        assert completion["description"] == "description"
        assert completion["parent"] == "parent"

# Generated at 2022-06-24 07:57:44.994519
# Unit test for function parse_source
def test_parse_source():
    # jedi.Script("import sys", 1, 1).completions()
    assert parse_source("import sys").get_code() == 'import sys'
    assert parse_source("import sys\nimport os").get_code() == 'import sys\nimport os'



# Generated at 2022-06-24 07:57:56.061295
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python.tree import Module
    from parso.python.token import Token

    def _get_module_node():
        token = Token("def", "def", (1, 0), (1, 3), (1, 0), (1, 3))
        def_node = tree.Function(None, None, token)
        token = Token("x", "x", (1, 4), (1, 5), (1, 4), (1, 5))
        name_node = tree.Name(None, token)
        def_node.children.insert(0, name_node)
        yield from def_node.children

    class MyModule(Module):
        def __init__(self):
            super().__init__(None)
            self.children = list(_get_module_node())

    node = MyModule()

# Generated at 2022-06-24 07:57:59.943057
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from jedi.parser import tree as jedi_tree

    i = ThonnyCompletion("a", "a", "a", "b", jedi_tree.Node(), "c")
    assert i.__getitem__("name") == "a"

# Generated at 2022-06-24 07:58:04.160803
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script

    script = Script("1 +")
    completion = script.completions()[0]

    assert completion.name == "+"
    assert completion.complete == "+"
    assert completion.description == "operator.add($a, $b) -- Add arguments."
    assert completion.parent == "builtins"
    assert completion.full_name == "builtins.+"
    assert completion.type == "operator"

# Generated at 2022-06-24 07:58:08.354360
# Unit test for function parse_source
def test_parse_source():
    source = "print(1)"
    result = parse_source(source)
    assert result.type == "file_input"
    assert result.start_pos == (1, 0)
    assert result.end_pos == (2, 0)




# Generated at 2022-06-24 07:58:14.366372
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import jedi.parser_utils

    get_statement_of_position = getattr(
        jedi.parser_utils, "get_statement_of_position", _copy_of_get_statement_of_position
    )

    class TestNode(object):
        def __init__(self, start_pos, end_pos):
            self.start_pos = start_pos
            self.end_pos = end_pos


# Generated at 2022-06-24 07:58:18.257424
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'

# Generated at 2022-06-24 07:58:23.128457
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    obj = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert obj['name'] == 'name'
    assert obj['complete'] == 'complete'
    assert obj['type'] == 'type'
    assert obj['description'] == 'description'
    assert obj['parent'] == 'parent'
    assert obj['full_name'] == 'full_name'

# Generated at 2022-06-24 07:58:28.972182
# Unit test for function get_definitions
def test_get_definitions():
    definitions = get_definitions("import jedi; jedi.get_definitions()", 0, 0, "test.py")
    assert len(definitions) == 1
    assert definitions[0].module_name == "jedi"
    assert definitions[0].line == "def get_definitions(self):"



# Generated at 2022-06-24 07:58:35.210263
# Unit test for function get_definitions
def test_get_definitions():
    def check(source: str, row: int, column: int, expected_positions):
        definitions = get_definitions(source, row, column, "source.py")
        actual_positions = [(d.module_path, d.line, d.column, d.description) for d in definitions]

        if actual_positions != expected_positions:
            msg = "Expected: %s\nActual: %s" % (expected_positions, actual_positions)
            raise AssertionError(msg)

    check(
        "import os\nos.path", 2, 10, [("os.__init__", 2, 10, "module")]
    )  # module name

# Generated at 2022-06-24 07:58:39.755976
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    th = ThonnyCompletion("apple", "apple=", "type", "desc", "parent", "full_name")
    assert th["name"] == "apple"
    assert th["complete"] == "apple="
    assert th["type"] == "type"
    assert th["description"] == "desc"
    assert th["parent"] == "parent"
    assert th["full_name"] == "full_name"

# Generated at 2022-06-24 07:58:41.411611
# Unit test for function get_definitions

# Generated at 2022-06-24 07:58:51.583994
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "def greet(name):\n    print('Hello', name)\n\n"
    completions = get_script_completions(source, row=1, column=1, filename="a.py")
    assert len(completions) == 1
    assert completions[0].complete == "greet("
    assert completions[0].name == "greet("
    assert completions[0].description == "greet(name: "
    assert completions[0].parent == "None"
    assert completions[0].type == "def"
    assert completions[0].full_name == "greet"

    # Ensure that if we add '(' that we don't get full signature
    completions = get_script_completions(source, row=1, column=7, filename="a.py")
    assert len

# Generated at 2022-06-24 07:59:02.777624
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import sys
    import unittest

    class GetScriptCompletionsTests(unittest.TestCase):
        def test_completions(self):
            project_root = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), ".."
            )
            sys.path.append(project_root)
            source = "\n".join(
                [
                    "i = ''",
                    "",
                    "if i.isalpha():",
                    "    i.capitali",
                    "    ",
                    "",
                    "    i.lower",
                ]
            )
            completions = get_script_completions(source, 3, 13, "")
            completion_list = [c.complete for c in completions]
            expected_com

# Generated at 2022-06-24 07:59:09.697669
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    code = "from math import sin\nfrom cmath import log\nsin(log(log(log(log(10.0)))))"
    completions = get_interpreter_completions(code, [{}])
    assert len(completions) == 2
    assert completions[0].name == "sin"
    assert completions[1].name == "log"

    code = "from math import sqrt\nfrom cmath import log\nsin(log(log(log(log(10.0)))))"
    completions = get_interpreter_completions(code, [{}])
    assert len(completions) == 3

    code = "sin(log(log(log(log(10.0)))))"
    completions = get_interpreter_completions(code, [{}])
   

# Generated at 2022-06-24 07:59:10.991144
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("2+3") is not None

# Generated at 2022-06-24 07:59:12.527631
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    # prepare a module with a very simple tree

# Generated at 2022-06-24 07:59:22.160233
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import inspect
    import jedi
    def get_source(depth=0):
        """
        :param depth: how many frames to go back in the stack
        """
        frame = inspect.stack()[1 + depth]
        filename = frame[1]
        with open(filename) as fp:
            source = fp.read()
        return source, os.path.abspath(filename)

    # Check that we get the correct definition for this function itself
    source, path = get_source()
    def_objs = get_definitions(source, 4, 28, path)
    for def_obj in def_objs:
        if def_obj.line == 4 and def_obj.column == 13:
            # definition of function get_source()
            assert def_obj.module_path == path
           

# Generated at 2022-06-24 07:59:26.328809
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api import classes
    import jedi

    jedi_comp = classes.Completion("foo", "a=")
    compl = ThonnyCompletion(jedi_comp.name, jedi_comp.complete, jedi_comp.type,
                             jedi_comp.description, jedi_comp.parent, jedi_comp.full_name)
    assert compl.name == "foo"
    assert compl.complete == "foo="
    assert compl.type == "statement"
    assert compl.description == ""
    assert compl.parent == ""
    assert compl.full_name == "a.foo"


# Generated at 2022-06-24 07:59:35.831318
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_thonny_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_thonny_completion["name"] == "name" and \
           test_thonny_completion["complete"] == "complete" and \
           test_thonny_completion["type"] == "type" and \
           test_thonny_completion["description"] == "description" and \
           test_thonny_completion["parent"] == "parent" and \
           test_thonny_completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:59:36.622309
# Unit test for function get_definitions

# Generated at 2022-06-24 07:59:40.154143
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = """a_dict = {'a':1, 'b':2}
"""
    namespaces = [{'a_dict': jedi.Interpreter(source, [{}]).goto_definitions()[0]}]
    completions = get_interpreter_completions(source, namespaces)
    assert [c.name for c in completions] == ['b', 'a']

# Generated at 2022-06-24 07:59:49.669290
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"


# Generated at 2022-06-24 07:59:59.556318
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    import jedi

    original_using_older_jedi = _using_older_jedi
    import sys

    if sys.version_info >= (3, 7):
        # https://github.com/davidhalter/jedi/issues/1743
        _using_older_jedi = lambda x: True

    class GetInterpreterCompletionsTest(TestCase):
        def test_no_completions_for_unknown_module(self):
            self.assertEqual([], get_interpreter_completions("import blah\nblah.", []))

        def test_completions(self):
            completions = get_interpreter_completions('a = 1\na.b = "c"\na.split', [])

# Generated at 2022-06-24 08:00:11.099346
# Unit test for constructor of class ThonnyCompletion

# Generated at 2022-06-24 08:00:21.825676
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import test.jedi_mock as jedi_mock

    class GetStatementOfPositionTest(unittest.TestCase):
        def test_with_class(self):
            path = "/tmp/jedi-test-class.py"
            jedi_mock.get_module(
                """class Foo(object):
                       def __init__(self):
                           print("foo")
                """,
                path,
            )
            node = jedi_mock.get_module(
                """class Foo(object):
                       def __init__(self):
                           print("foo")
                """,
                path,
            )
            position = node.get_position_of_line_column(1, 0)
            statement = get_statement_of_position(node, position)
            self

# Generated at 2022-06-24 08:00:32.032341
# Unit test for function get_script_completions
def test_get_script_completions():
    def check_completions(source, row, column, expected):
        actual = get_script_completions(source, row, column, "<input>")
        assert [c.name for c in actual] == expected

    check_completions(
        "a = 0\n" 'def f(arg="default"):\n' "    print(arg)\n" 'f(',
        2,
        6,
        ["arg", "f"],
    )

    check_completions(
        "a = 0\n" 'def f(arg="default"):\n' "    print(arg)\n" 'f(a',
        2,
        7,
        ["arg", "a"],
    )


# Generated at 2022-06-24 08:00:39.043633
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree
    from parso import parse
    
    source = """def foo():
    pass
    a = 7
    b = 9
    if a < b:
        c = a
    else:
        c = b
    return c
"""

    source_tree = parse(source)
    child_init = source_tree.children[0].children[0]
    
    assert get_statement_of_position(child_init, 7) is None
    returned_node = get_statement_of_position(child_init, 8)
    assert isinstance(returned_node, tree.ExprStmt)
    returned_node = get_statement_of_position(child_init, 9)
    assert isinstance(returned_node, tree.ExprStmt)
    returned_

# Generated at 2022-06-24 08:00:40.499370
# Unit test for function get_script_completions
def test_get_script_completions():
    return get_script_completions("import sys", 0, 7, "")

# Generated at 2022-06-24 08:00:41.685923
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import parser_utils
    from parso.python.tree import Name
    from copy import copy
    import jedi


# Generated at 2022-06-24 08:00:43.897445
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f') == {
        'name': 'a',
        'complete': 'b',
        'type': 'c',
        'description': 'd',
        'parent': 'e',
        'full_name': 'f',
    }

# Generated at 2022-06-24 08:00:53.651069
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    from jedi import Script
    from jedi import definitions

    # Trying to test a function in a file
    source1 = "def function_test():\n\treturn 1"
    script1 = Script(source=source1, line=1, column=7, path=r'C:\Users\athiker\test.py')
    result1 = script1.goto_definitions()
    assert len(result1) == 1

    # Trying to test a class in a file
    source2 = "class class_test():\n\tdef __init__(self):\n\t\tself.var1 = 5"
    script2 = Script(source=source2, line=1, column=7, path=r'C:\Users\athiker\test.py')
    result2 = script2.goto_def

# Generated at 2022-06-24 08:01:02.860456
# Unit test for function get_definitions
def test_get_definitions():
    def check(txt, row, col, expected):
        actual = [x.name for x in get_definitions(txt, row, col, "<string>")]
        assert set(actual) == set(expected)

    check("1", 0, 1, [])
    check("abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc", 1, 11, [])
    check("def foo():\n    bar = 0\n\nbar = 1\nfoo()", 6, 0, [])
    check("def foo():\n    bar = 0\n\nbar = 1\nfoo()", 2, 5, ["bar"])
    check("def foo():\n    return 0\n\nx = foo(); print(x)", 2, 5, ["foo"])

# Generated at 2022-06-24 08:01:13.092055
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnycompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnycompletion.__getitem__("name") == "name"
    assert thonnycompletion.__getitem__("complete") == "complete"
    assert thonnycompletion.__getitem__("type") == "type"
    assert thonnycompletion.__getitem__("description") == "description"
    assert thonnycompletion.__getitem__("parent") == "parent"
    assert thonnycompletion.__getitem__("full_name") == "full_name"