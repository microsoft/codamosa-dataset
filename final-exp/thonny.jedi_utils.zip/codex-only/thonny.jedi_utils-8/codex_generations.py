

# Generated at 2022-06-24 07:51:33.818082
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test = ThonnyCompletion(
        "name",
        "complete",
        "type",
        "description",
        "parent",
        "full_name",
    )
    assert test.name == "name"
    assert test.complete == "complete"
    assert test.type == "type"
    assert test.description == "description"
    assert test.parent == "parent"
    assert test.full_name == "full_name"



# Generated at 2022-06-24 07:51:42.878318
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock
    from thonny.codeview import get_interpreter_completions, ThonnyCompletion

    expected = [
        ThonnyCompletion(
            name="cmath",
            complete="cmath",
            type="module",
            description="Built-in cosine function.",
            parent=None,
            full_name="cmath",
        ),
        ThonnyCompletion(
            name="math",
            complete="math",
            type="module",
            description="Built-in cosine function.",
            parent=None,
            full_name="math",
        ),
    ]

    with mock.patch("thonny.codeview.jedi.Interpreter") as mocked_interpreter:
        mocked_interpreter.return_value.complete.return_value = expected


# Generated at 2022-06-24 07:51:45.703737
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    completions = jedi.Script("1 + 1").completions()
    thonny_completions = _tweak_completions(completions)
    assert thonny_completions[0]["name"] == thonny_completions[0].name

# Generated at 2022-06-24 07:51:47.842138
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    source = ""
    row = 0
    column = 0
    filename = ""
    completions = get_script_completions(source, row, column, filename)
    for completion in completions:
        print(completion["name"])

# Generated at 2022-06-24 07:51:58.325028
# Unit test for function get_script_completions
def test_get_script_completions():
    def check_result(source, row, column, filename, result):
        assert [
            (c.name, c.complete) for c in get_script_completions(source, row, column, filename)
        ] == result


# Generated at 2022-06-24 07:52:00.250765
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    # verify that it works with all jedi versions
    assert get_statement_of_position(jedi.__file__, 0) is not None

# Generated at 2022-06-24 07:52:03.442204
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name='a', complete='a', type='', description='', parent='', full_name='')
    assert(completion['name'] == 'a')
    assert(completion['complete'] == 'a')
    assert(completion['type'] == '')
    assert(completion['description'] == '')
    assert(completion['parent'] == '')
    assert(completion['full_name'] == '')

# Generated at 2022-06-24 07:52:13.218403
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.parse import ParserError
    from parso.python.tree import EndMarker, PythonNode
    import jedi.parser_utils as parser_utils

    def _create_parser(syntax, version):
        from parso import parse
        from parso._compatibility import _get_grammar_version

        parse_tree = parse(
            syntax,
            version=_get_grammar_version(version),
            error_recovery=False,
            line_offset=1,
            column_offset=0,
        )
        return parse_tree

    def _get_last_line(node):
        # Find the last line node, where the statement can be found
        return node.children[-1]


# Generated at 2022-06-24 07:52:22.738545
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    find_completions = [ ThonnyCompletion(name="name1",complete="complete1",type="function",description="description1",parent="parent1",full_name="full_name1"),
                         ThonnyCompletion(name="name2",complete="complete2",type="function",description="description2",parent="parent2",full_name="full_name2"),
                         ThonnyCompletion(name="name3",complete="complete3",type="function",description="description3",parent="parent3",full_name="full_name3")]
    assert find_completions[0]['name'] == "name1"
    assert find_completions[1]['complete'] == "complete2"
    assert find_completions[2]['type'] == "function"

# Generated at 2022-06-24 07:52:33.014464
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import parse
    from parso.python.tree import Class, Function, Import, Flow, KeywordStatement
    from parso.python.tree import IfStmt, ExprStmt, AssignmentStmt

    # Simple
    source = "def f():\n    a = 42"
    pos = len(source) - 1
    root = parse(source)
    node = root.children[0]
    assert(isinstance(node, Function))
    child = node.children[0]
    assert(isinstance(child, ExprStmt))
    child = child.children[0]
    assert(isinstance(child, AssignmentStmt))

    assert(child == get_statement_of_position(node, pos))

    # If block

# Generated at 2022-06-24 07:52:39.966089
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    @ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    class Test:
        pass

    assert Test.__dict__["name"] == "name"
    assert Test.__dict__["complete"] == "complete"
    assert Test.__dict__["type"] == "type"
    assert Test.__dict__["description"] == "description"
    assert Test.__dict__["parent"] == "parent"
    assert Test.__dict__["full_name"] == "full_name"

# Generated at 2022-06-24 07:52:45.610704
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    object = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert object.__getitem__('name') == 'name'
    assert object.__getitem__('complete') == 'complete'
    assert object.__getitem__('type') == 'type'
    assert object.__getitem__('description') == 'description'
    assert object.__getitem__('parent') == 'parent'
    assert object.__getitem__('full_name') == 'full_name'

# Generated at 2022-06-24 07:52:50.718514
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(name="str", complete="str", type=object, description="str",
                            parent=object, full_name="str")["name"] == "str"
    assert ThonnyCompletion(name="str", complete="str", type=object, description="str",
                            parent=object, full_name="str")["complete"] == "str"

# Generated at 2022-06-24 07:52:56.487183
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    source = """
# comment 1
# comment 2
a = [[
a + 1

b + 2
], 5]

"""
    node = parse_source(source)
    pos = node.children[2].start_pos
    assert isinstance(get_statement_of_position(node, pos), tree.PythonNode)

    pos = node.children[6].start_pos
    assert get_statement_of_position(node, pos) is None

# Generated at 2022-06-24 07:53:04.964868
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    jedi = _dummy_jedi()
    old_style_completion = _get_old_style_completion(jedi)
    new_style_completion = _get_new_style_completion(jedi)

    assert str(ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')) == str(old_style_completion)
    assert str(ThonnyCompletion('asyncio.get_event_loop=', 'asyncio.get_event_loop=', 'function', '', '', 'asyncio.get_event_loop=')) == str(new_style_completion)



# Generated at 2022-06-24 07:53:06.297488
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree

# Generated at 2022-06-24 07:53:08.039533
# Unit test for function parse_source
def test_parse_source():
    source = "if x:\n\tx=5"
    assert isinstance(parse_source(source), object)

# Generated at 2022-06-24 07:53:11.473096
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    complete = jedi.names("np.", "import numpy as np")
    assert complete[0]['name'] == 'sort'
    return complete[0]["description"].startswith('sort(a, axis=-1, kind=None, order=None, axis=None)')

# Generated at 2022-06-24 07:53:15.503619
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = "def f():\n\treturn\n"
    node = parse_source(source)
    pos = len(source) - 1
    pos = node.get_position_index(2, source[pos])
    elem = get_statement_of_position(node, pos)
    print(elem)

# Generated at 2022-06-24 07:53:25.311910
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import mock
    the_dict = {"key1": "value1", "key2": "value2"}
    # mock the ThonnyCompletion. __getitem__ method
    with mock.patch.object(ThonnyCompletion, '__getitem__', return_value=the_dict):
        # mock the function __init__ of class ThonnyCompletion
        with mock.patch.object(ThonnyCompletion, '__init__', return_value=None):
            # initialize the ThonnyCompletion
            completion = ThonnyCompletion(None, None, None, None, None, None)
            # check the result
            assert completion["key1"] == "value1"
            assert completion["key2"] == "value2"
            assert completion["key0"] == the_dict
        # unittest completed

# Generated at 2022-06-24 07:53:33.751156
# Unit test for function parse_source
def test_parse_source():
    source = """
if True:
    a = 1
else:
    a = 2
    
logger.info("Hello world")
"""
    root_node = parse_source(source)
    logger.debug("Got source: " + source)
    logger.debug("Got root node: " + root_node.get_code())
    logger.debug("Got indent: " + str(root_node.get_indent()))
    # Test the if-else statement
    if_node = root_node.children[0]
    logger.debug("Got if node: " + if_node.get_code())
    if if_node.get_code() != "if True:\n    a = 1\nelse:\n    a = 2\n":
        raise Exception("Not expected node found in if-else test.")

    # Test the second

# Generated at 2022-06-24 07:53:39.362075
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    source = "import sys\nsys\n"
    row = 2
    column = 3
    filename = "test.py"
    defs = get_definitions(source, row, column, filename)
    assert len(defs) > 0
    assert defs[0].description.startswith("module")
    assert defs[0].description.endswith("sys")

# Generated at 2022-06-24 07:53:40.529647
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:53:47.778320
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi

    if _using_older_jedi(jedi):
        script = jedi.Script('a = [1, 2, 3]')
        completions = script.completions()
        assert completions[0].name == 'a'
    else:
        script = jedi.Script(code='a = [1, 2, 3]', path='')
        completions = script.complete(line=0, column=1)
        assert completions[0].name == 'a'

# Generated at 2022-06-24 07:53:56.415599
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    from jedi.evaluate.precedence import get_precedence

    dfn_node = tree.Parameter(name='a', start_pos=(1, 1))
    dfn_node.assignment_details = None
    dfn_node.parent = tree.Function([dfn_node])
    assert get_statement_of_position(dfn_node.parent, (1, 1)).type == 'funcdef'
    assert get_statement_of_position(dfn_node.parent, (1, 1)).children[0] == dfn_node

    precedence_tree = tree.Precedence(operator='+', start_pos=(1, 1))
    precedence_tree.assignment_details = None
    precedence_tree.precedence = get_precedence("+")
    precedence

# Generated at 2022-06-24 07:54:01.326923
# Unit test for function get_script_completions
def test_get_script_completions():
    num = 0
    source = """
"""

    completions = get_script_completions(source, 0, num, "test_file")
    assert len(completions) == 20

    completions = get_script_completions(source, 0, num, "test_file", sys_path=['/tmp/test1'])
    assert len(completions) == 20

# Generated at 2022-06-24 07:54:07.965193
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import collections
    import jedi
    from thonny import get_runner
    from thonny.codeview import CodeViewText

    def check_completions(completions, expected):
        if len(completions) != len(expected):
            raise AssertionError("Expected %d completions, but got %d" % (len(expected), len(completions)))

        for i in range(len(completions)):
            if not isinstance(expected[i], (str, collections.Hashable)):
                raise AssertionError("Complete test implementation needed")

            if not isinstance(completions[i], ThonnyCompletion):
                raise AssertionError("Complete test implementation needed")


# Generated at 2022-06-24 07:54:17.890325
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    assert ThonnyCompletion(name, complete, type, description, parent, full_name).name == name
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).complete == complete
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).type == type
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).description == description
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).parent == parent
    assert ThonnyCompletion(name, complete, type, description, parent, full_name).full

# Generated at 2022-06-24 07:54:22.836917
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion("name1", "complete1", "type1", "description1", "parent1", "full_name1")
    assert x.name == "name1"
    assert x.complete == "complete1"
    assert x.type == "type1"
    assert x.description == "description1"
    assert x.parent == "parent1"
    assert x.full_name == "full_name1"

# Unit test: different jedi versions use different naming convention
# for the keys of a completion item

# Generated at 2022-06-24 07:54:32.818684
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from tempfile import NamedTemporaryFile

    sys_path = ["/home/me", "/home/you"]

    with NamedTemporaryFile(mode="w") as f:
        f.write("from os.path import basename")
        f.flush()

        # The following test just shows that we manage to use sys_path
        completions = get_script_completions(
            "import os\nos.path.basen", 1, 14, filename=f.name, sys_path=sys_path
        )

        assert len(completions) == 1
        assert completions[0].name == "basename"

    completions = get_interpreter_completions(
        "import os\nos.path.basen", namespaces=[], sys_path=sys_path
    )

    assert len(completions)

# Generated at 2022-06-24 07:54:38.691251
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    completion = ThonnyCompletion(Completion('name', 'complete', 'type', 'description', 'parent', 'full_name'))
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'

# Generated at 2022-06-24 07:54:40.375155
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso


# Generated at 2022-06-24 07:54:43.351498
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    source = "from collections import defaultdict\nfrom typing import (List, Dict)\nfrom tkinter import Tk\nfrom tkinter import *"
    root = parse_source(source)
    assert isinstance(root, tree.Module)
    assert len(root.children) == 4

# Generated at 2022-06-24 07:54:51.326730
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    a = jedi.Script("").completions()[0]
    comp = ThonnyCompletion(
        name=a.name,
        complete=a.complete,
        type=a.type,
        description=a.description,
        parent=a.parent,
        full_name=a.full_name,
    )

    assert comp.name == a.name
    assert comp.complete == a.complete
    assert comp.type == a.type
    assert comp.description == a.description
    assert comp.parent == a.parent
    assert comp.full_name == a.full_name



# Generated at 2022-06-24 07:54:53.532709
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:55:01.151474
# Unit test for function get_definitions
def test_get_definitions():
    source = """\
import sys as y
x = y.stdout
x.write"""

    defs = get_definitions(source, 1, 5, "test_file.py")
    assert len(defs) == 1
    assert defs[0].module_path == [
        "sys"
    ]  # this means, it's the one from sys, not from typing
    assert defs[0].type == "instance"
    assert defs[0].line == 1
    assert defs[0].column == 5



# Generated at 2022-06-24 07:55:06.127353
# Unit test for function get_definitions
def test_get_definitions():
    from unittest.mock import Mock

    def mock_get_definitions(source, row, column, filename):
        return [
            Mock(filename="A"),
            Mock(filename="B"),
            Mock(filename="C"),
            Mock(filename="D"),
        ]

    get_definitions_real = get_definitions
    get_definitions = mock_get_definitions


# Generated at 2022-06-24 07:55:10.001318
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    comp = Script("def foo(a, b, c): pass\nfoo('''a''', {}, [])").completions()[1]
    assert ThonnyCompletion("a", "a", "param", "str(object='')", "foo", "foo.a") == comp



# Generated at 2022-06-24 07:55:16.606117
# Unit test for function get_definitions
def test_get_definitions():
    source = 'import os\nos.path.abspath("")\n'
    row = 3
    column = 1
    filename = "Dummy"
    defs = get_definitions(source, row, column, filename)
    assert len(defs) == 1
    assert str(defs[0].description) == "abspath(path, *, strict=True)"
    assert str(defs[0].module_name) == "posixpath"


# Generated at 2022-06-24 07:55:25.705491
# Unit test for function get_definitions
def test_get_definitions():
    import os.path

    test_scripts = [
        "import os; os.path.join",
        "def f(a): return a; f(",
        "from os.path import join; join",
        "from os import path; path.join",
        "from os import path as p; p.join",
        "def f(): pass; f(",
    ]

    success_count = 0
    for script in test_scripts:
        index = script.rfind(" ")
        source = script[:index]
        referent = script[index + 1 :]
        definitions = get_definitions(source, 0, len(source), "test.py")
        if any(referent == definition.description for definition in definitions):
            success_count += 1
    assert success_count == len(test_scripts)


#

# Generated at 2022-06-24 07:55:28.806485
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion_obj = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    result_test_ThonnyCompletion___getitem__ = completion_obj.__getitem__("name")
    assert result_test_ThonnyCompletion___getitem__ == "name"

# Generated at 2022-06-24 07:55:35.729003
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonnycompletion_completion = ThonnyCompletion("name1", "complete1", "type1", "description1", "parent1", "full_name1")
    assert thonnycompletion_completion.name == "name1"
    assert thonnycompletion_completion.complete == "complete1"
    assert thonnycompletion_completion.type == "type1"
    assert thonnycompletion_completion.description == "description1"
    assert thonnycompletion_completion.parent == "parent1"
    assert thonnycompletion_completion.full_name == "full_name1"

# Generated at 2022-06-24 07:55:42.704753
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils

    # This is a copied function from parso 0.7.0. It had a bug that was fixed in
    # https://github.com/davidhalter/parso/commit/9f3a2f93c48eda24e2dcc25e54eb7cc10aa73848
    # which is included in jedi 0.18.1
    #
    # Function get_statement_of_position from parso 0.6.0 is included in jedi 0.17.1
    # It does not have a bug
    #
    # In jedi 0.17 and 0.18, we can use jedi.parser_utils.get_statement_of_position
    # to avoid copying from parso
    #
    # In other jedi versions, we must use _copy_

# Generated at 2022-06-24 07:55:46.492351
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module

    source = '"""\nThis is a module docstring.\n"""\n\n\ndef foo():\n    pass\n'

    node = parse_source(source)
    assert isinstance(node, Module)
    assert node.start_pos == (1, 0)
    assert node.end_pos == (7, 4)
    assert node.get_code() == source



# Generated at 2022-06-24 07:55:55.430349
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Generate a fake completion with arbitrary values
    fake_completion = {'name': 'abc', 'complete': 'abc', 'type': 'int', 'description': 'abc', 'parent': 'abc', 'full_name': 'abc'}
    # Instantiate a ThonnyCompletion class with the fake completion
    tc = ThonnyCompletion(name = fake_completion['name'], complete = fake_completion['complete'], type = fake_completion['type'], description = fake_completion['description'], parent = fake_completion['parent'], full_name = fake_completion['full_name'])
    # Test if the attributes of the instantiated ThonnyCompletion class object are equal to the values of the fake completion
    assert tc.name == fake_completion['name']
    assert tc.complete == fake_completion

# Generated at 2022-06-24 07:55:56.384697
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:56:05.682147
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, main
    from parso import parse

    class MyTestCase(TestCase):
        def runTest(self):
            source = """import datetime
            a=datetime.
            """
            parsed_source = parse(source)
            row = 1
            col = 15
            completions = get_interpreter_completions(
                source,
                [{"globals": parsed_source.get_globals()}],
                sys_path=["."],
            )
            self.assertTrue(len(completions) > 0)
            self.assertTrue(any(["datetime." in c.name for c in completions]))

    myTestCase = MyTestCase()
    myTestCase.runTest()


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 07:56:15.149433
# Unit test for function get_definitions
def test_get_definitions():
    def check_definitions(source: str, row: int, column: int, expected):
        got = get_definitions(source, row, column, "test.py")
        if len(got) != len(expected):
            raise AssertionError(
                "Wrong number of definitions: expected %s, got %s" % (expected, got)
            )
        for i in range(len(got)):
            if got[i].type != expected[i]:
                raise AssertionError(
                    "Unexpected definition type for %s: expected %s, got %s"
                    % (got[i].full_name, expected[i], got[i].type)
                )

    check_definitions("a", 0, 0, [])
    check_definitions("a = 1", 0, 0, [])
    check

# Generated at 2022-06-24 07:56:22.123761
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

if __name__ == "__main__":
    test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:56:27.087482
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions(source="import xyzzy\nxyzzy.", namespaces=[], sys_path=[]) == \
        [ThonnyCompletion(name='xyzzy', complete='xyzzy', type='import',
                          description='', parent=None, full_name='xyzzy')]

assert parse_source("print(1)").get_code() == "print(1)\n"

# Generated at 2022-06-24 07:56:33.551746
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    from parso.python import tree

    def test_with_node(node, pos, expected_result):
        res = get_statement_of_position(node, pos)
        if res is None:
            assert expected_result is None
        else:
            assert isinstance(res, tree.Node)
            found_pos = res.start_pos
            if hasattr(res, "start_pos"):
                found_pos = res.start_pos
            else:
                found_pos = res.first_leaf().start_pos
            assert found_pos == expected_result

    def test_with_pos(node, pos, expected_result):
        res = get_statement_of_position(node, pos)
        if res is None:
            assert expected_result is None

# Generated at 2022-06-24 07:56:40.292645
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    node = tree.Module([tree.ExprStmt([tree.Name("a", (1, 0)), tree.Operator("+", (1, 2)), tree.Name("b", (1, 3))])])
    def testpos(pos, expected_name):
        result = get_statement_of_position(node, pos)
        assert isinstance(result, tree.Name)
        assert result.value == expected_name

    testpos(2, "a")
    testpos(3, "b")


# Generated at 2022-06-24 07:56:44.228551
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(0, 1, 2, 3, 4, 5)
    assert completion[0] == 0
    assert completion[1] == 1
    assert completion[2] == 2
    assert completion[3] == 3
    assert completion[4] == 4
    assert completion[5] == 5


# Generated at 2022-06-24 07:56:51.609299
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import sys

    completion = ThonnyCompletion(name=sys.version, complete="test_complete", type="test_type", description="test_description", parent="test_parent", full_name="test_full_name")
    assert completion["name"] == sys.version
    assert completion["complete"] == "test_complete"
    assert completion["type"] == "test_type"
    assert completion["description"] == "test_description"
    assert completion["parent"] == "test_parent"
    assert completion["full_name"] == "test_full_name"

# Generated at 2022-06-24 07:56:57.557858
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    from parso.python import tree
    from unittest.mock import patch, Mock

    def _mock_get_statement_of_position(node: tree.Node, pos):
        # Mock implementation of jedi.parser_utils.get_statement_of_position
        return node.children[0]

    with patch('jedi.parser_utils.get_statement_of_position', _mock_get_statement_of_position):
        assert get_statement_of_position(
            jedi.Script('x = ""')._parser.module, (1, 2)
        ).get_code() == 'x = ""', "Mocking of get_statement_of_position failed"

# Generated at 2022-06-24 07:57:02.950498
# Unit test for function get_definitions
def test_get_definitions():
    import os

    path = os.path.dirname(__file__)
    text = (
        "import sys\n"
        "\n"
        "def f():\n"
        '    x = sys.path\n'
        '    print(x)\n'
        '    print(sys.path)\n'
    )
    get_definitions(text, 2, 9, path + "/fake.py")
    get_definitions(text, 3, 5, path + "/fake.py")

# Generated at 2022-06-24 07:57:13.336835
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions, ThonnyCompletion
    import os

    namespace = locals().copy()
    # remove self from namespace
    namespace.pop("__name__")
    namespace.pop("__doc__")
    namespace.pop("__package__")
    namespace.pop("__loader__")
    namespace.pop("__spec__")
    namespace.pop("__file__")
    namespace.pop("__cached__")
    namespace.pop("namespace")
    namespace.pop("os")

    sys_path = os.path.dirname(__file__)
    completions = get_interpreter_completions("", [namespace], [sys_path])


# Generated at 2022-06-24 07:57:19.310232
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").name == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").complete == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").type == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").description == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").parent == "parent"

# Generated at 2022-06-24 07:57:24.237505
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"

# Generated at 2022-06-24 07:57:34.567614
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # Arrange
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    obj = ThonnyCompletion(name, complete, type, description, parent, full_name)

    # Act & Assert
    assert obj.__getitem__("name") == name
    assert obj.__getitem__("complete") == complete
    assert obj.__getitem__("type") == type
    assert obj.__getitem__("description") == description
    assert obj.__getitem__("parent") == parent
    assert obj.__getitem__("full_name") == full_name

# Generated at 2022-06-24 07:57:40.335133
# Unit test for function get_definitions
def test_get_definitions():
    from test.jedi_utils import get_definitions
    
    definitions = [
        {'complete': 'len',
         'description': 'Builtin function len().',
         'full_name': 'builtins.len',
         'name': 'len',
         'parent': 'builtins',
         'type': 'function'}
    ]
    src = 'len('
    row = 0
    column = 3
    filename = ''
    
    assert(get_definitions(src, row, column, filename) == definitions)

# Generated at 2022-06-24 07:57:44.939793
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    jedi_version = jedi.__version__
    print("jedi version " + jedi_version)


# Generated at 2022-06-24 07:57:56.008360
# Unit test for function get_script_completions
def test_get_script_completions():
    assert len(_tweak_completions([{"name":"=", "complete":"="},
        {"name":"==", "complete":"=="}, {"name":"!=", "complete":"!="},
        {"name":"<", "complete":"<"}, {"name":"<=", "complete":"<="},
        {"name":">", "complete":">"}, {"name":">=", "complete":">="}])) == 7
    assert len(_tweak_completions([{"name":"=", "completion":"="},
        {"name":"==", "complete":"=="}, {"name":"!=", "complete":"!="},
        {"name":"<", "complete":"<"}, {"name":"<=", "complete":"<="},
        {"name":">", "complete":">"}, {"name":">=", "complete":">="}])) == 7

# Generated at 2022-06-24 07:58:04.111195
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny import get_workbench
    import unittest.mock
    import unittest.mock as mock

    wb = get_workbench()
    wb.controlling_shell = mock.Mock()
    wb.controlling_shell.namespace = {"x" : 1}
    try:
        script = "x[1,2,3].i"
        code, pos = script.rsplit(".", 1)
        result = get_script_completions(code + ".", pos, len(pos), "testfile.py")
        assert result[0].name == "index"
    finally:
        wb.controlling_shell = None

# Generated at 2022-06-24 07:58:10.328114
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name="a", complete="b", type="", description="c", parent="d", full_name="e")
    assert tc["name"] == "a"
    assert tc["complete"] == "b"
    assert tc["type"] == ""
    assert tc["description"] == "c"
    assert tc["parent"] == "d"
    assert tc["full_name"] == "e"

# Generated at 2022-06-24 07:58:18.836964
# Unit test for function get_definitions
def test_get_definitions():
    def assert_definitions(source, row, column, expected_names):
        print(source, row, column)
        definitions = get_definitions(source, row, column, "test_file.py")
        assert [defn.name for defn in definitions] == expected_names
        print(definitions)
        print("-")

    assert_definitions("x = 1\nx", 1, 4, ["x"])
    assert_definitions("x = 1\nclass X:\n   pass\nx", 3, 2, ["x"])

    # class attribute
    assert_definitions("class X:\n    y = 1\n    def f(self):\n        return self.y\nx = X()\nx.y", 5, 3, ["y"])

    # method parameter

# Generated at 2022-06-24 07:58:24.379105
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion(
        "name", "complete", "type", "description", "parent", "full_name"
    )
    assert thonnyCompletion["name"] == "name"
    assert thonnyCompletion["complete"] == "complete"
    assert thonnyCompletion["type"] == "type"
    assert thonnyCompletion["description"] == "description"
    assert thonnyCompletion["parent"] == "parent"
    assert thonnyCompletion["full_name"] == "full_name"

# Generated at 2022-06-24 07:58:34.675668
# Unit test for function get_script_completions
def test_get_script_completions():
    import pip
    from subprocess import run, DEVNULL
    from thonny import get_runner

    (major, minor, micro, releaselevel, serial) = pip.__version__.split(".")

    try:
        # pip 9 or later
        run("pip", "install", "-q", "--user", "jedi>=0.16.0,<0.17", stderr=DEVNULL)
        run("pip", "install", "-q", "--user", "jedi>=0.17.0,<0.18.0", stderr=DEVNULL)
        run("pip", "install", "-q", "--user", "jedi>=0.18.0,<0.19.0", stderr=DEVNULL)
    except TypeError:
        # pip 8 or earlier
        run

# Generated at 2022-06-24 07:58:42.691733
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert _tweak_completions([{"name": "name", "complete": "name=", "type": "param"}]) == [
        ThonnyCompletion("name", "name=", "param", None, None, None)
    ]
    assert _tweak_completions([{"name": "name", "complete": "name", "type": "param"}]) == [
        ThonnyCompletion("name", "name", "param", None, None, None)
    ]


# Generated at 2022-06-24 07:58:48.658095
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_object = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert test_object.name == 'name'
    assert test_object.complete == 'complete'
    assert test_object.type == 'type'
    assert test_object.description == 'description'
    assert test_object.parent == 'parent'
    assert test_object.full_name == 'full_name'

# Generated at 2022-06-24 07:58:52.040420
# Unit test for function parse_source
def test_parse_source():
    source = "def f(x):\n\treturn x"
    module = parse_source(source)
    assert module.children[0].children[1].value == "x"
    assert module.children[0].children[3].children[0].value == "x"

# Generated at 2022-06-24 07:58:57.533030
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'a'
    complete = 'abc'
    type_ = 'abc'
    description = 'abc'
    parent = 'abc'
    full_name = 'abc'
    obj = ThonnyCompletion(name, complete, type_, description, parent, full_name)
    assert obj.__getitem__('name') == 'a'

# Generated at 2022-06-24 07:59:03.380452
# Unit test for function parse_source
def test_parse_source():
    # Test with import
    path = os.path.realpath(os.path.dirname(__file__))
    path_to_module = os.path.join(path, '../examples/example.py')
    source = open(path_to_module, encoding='utf-8').read()
    module = parse_source(source)

    if len([node for node in module if node.type == 'import_from']) == 0:
        return 1
    return 0

# Generated at 2022-06-24 07:59:07.832340
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name="test",
        complete="test",
        type="test",
        description="test",
        parent="test",
        full_name="test",
    )
    assert completion.name == "test"
    assert completion.complete == "test"
    assert completion.type == "test"
    assert completion.description == "test"
    assert completion.parent == "test"
    assert completion.full_name == "test"

# Generated at 2022-06-24 07:59:15.882848
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate import compiled
    import jedi
    import json
    import os

    testCases = os.path.join(os.path.dirname(os.path.realpath(__file__)), "testcases.json")
    with open(testCases, "r") as f:
        data = json.load(f)
    for testCase in data:
        sys_path = testCase.get("sys_path")
        completion_dict = {}
        completions = []

        source = testCase["source"]
        namespaces = [{k: compiled.CompiledObject.create(v) for k, v in d.items()} for d in testCase["namespaces"]]


# Generated at 2022-06-24 07:59:24.441681
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def get_statement_of_position_test(pos, expected_node):
        node = tree.Node(None, None, None, None, None)
        for name, child in expected_node.items():
            node.add_child(tree.Node(name, child[0], child[1], None, None))
        assert expected_node == get_statement_of_position(node, pos)

    get_statement_of_position_test(
        6, {"x": (1, 7)}
    )  # Simple test just to make sure it works.

    expected = {"for": (3, 19), "x": (3, 19), "in": (3, 19), "range": (3, 19)}


# Generated at 2022-06-24 07:59:30.280885
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import sys
sys.
"""
    completions = get_interpreter_completions(source, [{"sys": sys}])

    assert "stdin" in [completion.name for completion in completions]
    assert "stdin" in [completion.complete for completion in completions]


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 07:59:36.319127
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        "name", "complete", "type", "description", "parent", "full_name"
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:59:41.663353
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    s = Script(code='print(', path='<stdin>')
    completions = s.complete(line=1, column=7)
    completions_adapted = _tweak_completions(completions)

    for comp in completions_adapted:
        assert isinstance(comp, ThonnyCompletion)
        assert comp["name"] == comp.name
        assert comp["complete"] == comp.complete
        assert comp["type"] == comp.type
        assert comp["description"] == comp.description
        assert comp["parent"] == comp.parent
        assert comp["full_name"] == comp.full_name

# Generated at 2022-06-24 07:59:47.052710
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion(name='a', complete='b', type=1, description='c', parent='d', full_name='e')
    assert c.name == 'a'
    assert c.complete == 'b'
    assert c.type == 1
    assert c.description == 'c'
    assert c.parent == 'd'
    assert c.full_name == 'e'

# Generated at 2022-06-24 07:59:51.318493
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse
    from parso.python.tree import Import, ImportFrom
    from parso.python.tree import AsyncFunctionDef, ClassOrFunc

    # One statement in a suite
    source = "import numpy"
    stmt = get_statement_of_position(parse(source), len(source) - 1)
    assert stmt is not None
    assert isinstance(stmt, Import)

    # Two statements in a suite
    source = "import numpy\nimport scipy"
    stmt = get_statement_of_position(parse(source), len(source) - 1)
    assert stmt is not None
    assert isinstance(stmt, Import)

    # One statement in decorator
    source = "@myDecor\ndef f():"
    tree = parse(source)
    stmt

# Generated at 2022-06-24 07:59:55.725528
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import os
os.pa
"""
    completions = get_script_completions(source, 3, 15, "file.py")
    assert sorted(c.name for c in completions) == ["path", "pathconf", "pathconf_names"]


# Generated at 2022-06-24 08:00:06.846533
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import mock
    # Make sure get_interpreter_completions works with jedi older than 0.18
    with mock.patch("jedi.jedi_api.VERSION_INFO", [0, 16]):
        result = get_interpreter_completions("", [])
        assert type(result) == list
        # Make sure get_interpreter_completions works with jedi 0.18.2 or newer
        with mock.patch("jedi.jedi_api.VERSION_INFO", [0, 18, 2]):
            result = get_interpreter_completions("", [])
            assert type(result) == list
    with mock.patch("jedi.jedi_api.VERSION_INFO", [0, 19]):
        result = get_interpreter_completions("", [])
       

# Generated at 2022-06-24 08:00:15.072374
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os.path
    from jedi import __file__ as jedi_file
    from jedi.parser.python import load_grammar

    jedi_dir = os.path.dirname(jedi_file)
    grammar_file = os.path.join(jedi_dir, "parser", "grammar", "__init__.py")
    source = open(grammar_file).read()

    parser = load_grammar(source)
    for node in parser.iter_funcdefs():
        #print(node.start_pos, node.end_pos)
        node_name = node.get_name().value
        if node_name == "__init__":
            continue

        row = node.start_pos[0]
        column = node.start_pos[1] + 1


# Generated at 2022-06-24 08:00:23.965157
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree
    import parso.python.diff
    import jedi.parser
    import jedi

    def make_node(start, end, children=None):
        class Node(parso.python.tree.PythonNode):
            def __init__(self, start_pos, end_pos, children):
                super().__init__("fake", start_pos, end_pos)
                self.children = children

            @property
            def start_pos(self):
                return self._start_pos

        return Node(start, end, children=children)

    def pos(line, column):
        return parso.python.diff.Position("", line, column)


# Generated at 2022-06-24 08:00:34.217128
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["name"] == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["complete"] == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["type"] == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["description"] == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")["parent"] == "parent"

# Generated at 2022-06-24 08:00:41.422432
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf, PythonNode
    
    class Node(PythonNode):
        def __init__(self, name: str, pos: int):
            super().__init__(leaf=Leaf(pos, "%s(%d)" % (name, pos)))

    pos = 10
    start = Node("start", 0)
    mid = Node("mid", 5)
    end = Node("end", 15)
    start.children = [mid]
    mid.children = [end]
    
    assert get_statement_of_position(start, pos) == mid

# Generated at 2022-06-24 08:00:51.826658
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.plugins.jedi_utils import get_definitions, get_script_completions

    def run_test(source, row, column, filename, expected_name):
        definitions = get_definitions(source, row, column, filename)

        # if not found
        assert len(list(definitions)) > 0

        # if wrong one
        assert definitions[0].name == expected_name

    run_test(
        source="my_var = ClassWithMethod(123)\nmy_var.method()",
        row=2,
        column=8,
        filename="untitled.py",
        expected_name="method",
    )


# Generated at 2022-06-24 08:00:53.292074
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    result = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    # The test will be successful by default.
    assert result["name"] == "name"

# Generated at 2022-06-24 08:01:02.600616
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.environment import InterpreterEnvironment, InvalidPythonEnvironment
    import sys
    import builtins

    try:
        env = InterpreterEnvironment()
    except InvalidPythonEnvironment:
        env = None

    def make_module(name, val):
        module = type(builtins)(name)
        module.__dict__[name] = val
        return module

    namespaces = [{'__main__': make_module('argv', ['sys', 'argv'])}]

    def assert_completes(source, result):
        assert get_interpreter_completions(source, namespaces, sys_path=(sys.path)) == result


# Generated at 2022-06-24 08:01:07.743235
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    ast = parso.parse("a = 1\n@decorator")

    # go to the 2nd token
    pos = ast.children[1].start_pos + 1

    assert get_statement_of_position(ast, pos).type == "fill_token"

# Generated at 2022-06-24 08:01:13.140437
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree

    def assert_correct_node(node, correct_node):
        assert node.type == correct_node.type
        assert node.start_pos == correct_node.start_pos
        assert node.end_pos == correct_node.end_pos


# Generated at 2022-06-24 08:01:21.289116
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import patch
    from unittest import TestCase

    class Completion:
        """
        Fake for jedi.Script.complete().
        """
        def __init__(self, compl_str, compl_type, compl_doc):
            self.complete = compl_str
            self.name = compl_str
            self.type = compl_type
            self.description = compl_doc
            self.parent = ''
            self.full_name = compl_str

        def __repr__(self):
            return self.complete

    class GetCompletionsMock:
        """
        Mock for jedi.Script.complete() to test get_interpreter_completions(),
        where completion 'pip' is mocked to be both a module and a function.
        """

# Generated at 2022-06-24 08:01:25.866839
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"], "name"
    assert completion["complete"], "complete"
    assert completion["type"], "type"
    assert completion["description"], "description"
    assert completion["parent"], "parent"
    assert completion["full_name"], "full_name"

# Generated at 2022-06-24 08:01:31.974519
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    path = "test.py"
    text = "import sys; sys.path.appe"
    line, column = 1, len(text)
    script = jedi.Script(text, line, column, path)
    completions = script.completions()

    result = ThonnyCompletion(
        name=completions[0].name,
        complete=completions[0].complete,
        type=completions[0].type,
        description=completions[0].description,
        parent=completions[0].parent,
        full_name=completions[0].full_name,
    )

    assert result.name == "append"
    assert result.complete == "append"
    assert result.type == "statement"