

# Generated at 2022-06-24 07:51:32.816243
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position
    from parso.python import tree

    node = tree.Module(start_pos=(1,1), end_pos=(1,4))
    assignment = tree.Operator(value="=", start_pos=(1,2), end_pos=(1,3))
    atom = tree.Name(value="x", start_pos=(1,1), end_pos=(1,2))
    atom2 = tree.Name(value="x", start_pos=(1,3), end_pos=(1,4))
    node.children = [assignment, atom, atom2]

    assert node == get_statement_of_position(node, (1,3))
    assert assignment == get_statement_of_position(node, (1,2))
    assert atom == get_statement_

# Generated at 2022-06-24 07:51:35.518477
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = "class FooClass:\n    def foo(self, a, b, c):\n        a = 3\n        b = 4\n"
    pos = (3, 7)
    assert get_statement_of_position(parse_source(source), pos)
    assert not get_statement_of_position(parse_source(""), pos)
    assert not get_statement_of_position(parse_source("a = 1\nc = 2"), pos)

# Generated at 2022-06-24 07:51:43.643442
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert thonny_completion.__getitem__("name") == "name"
    assert thonny_completion.__getitem__("complete") == "complete"
    assert thonny_completion.__getitem__("type") == "type"
    assert thonny_completion.__getitem__("description") == "description"
    assert thonny_completion.__getitem__("parent") == "parent"
    assert thonny_completion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:51:51.392470
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.tree import Leaf
    from parso.tree import Node
    from parso.python import tree

    l1 = Leaf(type="NAME", value="a", start_pos=(1,), prefix="")
    l2 = Leaf(type="NAME", value="b", start_pos=(2,), prefix="")
    l3 = Leaf(type="NAME", value="c", start_pos=(3,), prefix="")
    l4 = Leaf(type="NAME", value="d", start_pos=(4,), prefix="")
    l5 = Leaf(type="NAME", value="e", start_pos=(5,), prefix="")
    l6 = Leaf(type="NAME", value="f", start_pos=(6,), prefix="")

# Generated at 2022-06-24 07:51:58.542197
# Unit test for function get_script_completions
def test_get_script_completions():
    '''
        To test this function, run "python -m thonny.jediutils test_get_script_completions()"
    '''
    from thonny import get_workbench
    from thonny.plugins.jedi import JediCompletionProvider

    wb = get_workbench()
    wb.create_editor_notebook()
    test_dir = os.path.dirname(__file__)
    path_to_file = os.path.join(test_dir, "jedi_completion_test_file.py")
    wb.load_file(path_to_file)
    wb.shell.run_current()
    _, filename = os.path.split(path_to_file)
    # Test script completions
    completions = jediutils.get_script_com

# Generated at 2022-06-24 07:52:09.834725
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("import math; x = math.sin(0)", row=1, column=22, filename="<stdin>")
    assert get_definitions("import math; x = math.sin(", row=1, column=22, filename="<stdin>")
    assert get_definitions("import math; x = math.cos(", row=1, column=22, filename="<stdin>")
    assert get_definitions("import math; x = math.cos(0)", row=1, column=22, filename="<stdin>")
    assert get_definitions("from math import sin; x = sin(0)", row=1, column=24, filename="<stdin>")

# Generated at 2022-06-24 07:52:12.306300
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf
    from parso.python import tree


# Generated at 2022-06-24 07:52:14.260180
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "desc", "parent", "full_name")

# Generated at 2022-06-24 07:52:22.196003
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    _ThonnyCompletion_dict = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert _ThonnyCompletion_dict.name == "name"
    assert _ThonnyCompletion_dict.complete == "complete"
    assert _ThonnyCompletion_dict.type == "type"
    assert _ThonnyCompletion_dict.description == "description"
    assert _ThonnyCompletion_dict.parent == "parent"
    assert _ThonnyCompletion_dict.full_name == "full_name"

# Generated at 2022-06-24 07:52:32.050267
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script("print(", 1, 6, "test.py")
        completion = script.completions()[0]
        c = ThonnyCompletion(
            name=completion.name,
            complete=completion.complete,
            type=completion.type,
            description=completion.description,
            parent=completion.parent,
            full_name=completion.full_name,
        )
        assert c['type'] == 'statement'
    else:
        script = jedi.Script(code='print(', path="test.py")
        completion = script.complete(line=1, column=6)[0]

# Generated at 2022-06-24 07:52:41.894408
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    expected_name = "name"
    expected_complete = "complete"
    expected_type = "type"
    expected_description = "description"
    expected_parent = "parent"
    expected_full_name = "full_name"
    expected_completion = ThonnyCompletion(
        name=expected_name,
        complete=expected_complete,
        type=expected_type,
        description=expected_description,
        parent=expected_parent,
        full_name=expected_full_name,
    )
    assert expected_completion["name"] == expected_name
    assert expected_completion["complete"] == expected_complete
    assert expected_completion["type"] == expected_type
    assert expected_completion["description"] == expected_description
    assert expected_completion["parent"] == expected_parent
    assert expected

# Generated at 2022-06-24 07:52:51.388597
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    jedi.Script = jedi.Interpreter

    def test_completions(expected, input):
        result = []
        if len(expected) == 0:
            result = get_interpreter_completions(input, [{}])
        else:
            result = get_interpreter_completions(input, [{'test': 'test'}])
        assert result == expected

    test_completions([{'name': 'test', 'complete': 'test', 'type': 'test', 'description': 'test', 'parent': 'test',
                      'full_name': 'test'}], 'test')

# Generated at 2022-06-24 07:52:57.384486
# Unit test for function get_definitions
def test_get_definitions():
    result = get_definitions(
        'def foo():\n    bar = 5\n    print(bar)', 2, 10, "testpath"
    )
    assert len(result) == 1
    assert result[0].name == "bar"
    assert result[0].module_name == "testpath"
    assert result[0].line == 2
    assert result[0].column == 8
    assert result[0].module_path == "testpath"
    assert result[0].type == "statement"

# Generated at 2022-06-24 07:53:05.842865
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_ThonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_ThonnyCompletion.__getitem__("name") == "name"
    assert test_ThonnyCompletion.__getitem__("complete") == "complete"
    assert test_ThonnyCompletion.__getitem__("type") == "type"
    assert test_ThonnyCompletion.__getitem__("description") == "description"
    assert test_ThonnyCompletion.__getitem__("parent") == "parent"
    assert test_ThonnyCompletion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:53:12.838374
# Unit test for function get_definitions
def test_get_definitions():
    source = "def foo(): pass\nfoo"
    new_defs = get_definitions(source, 2, len("foo"), "testing.py")
    old_defs = get_definitions(source, 2, len("foo"), "testing.py")

    assert len(new_defs) == 1
    assert len(old_defs) == 1

    # Verify name and type attributes
    assert new_defs[0].type == "function"
    assert new_defs[0].name == "foo"

    assert old_defs[0].type == "function"
    assert old_defs[0].name == "foo"

# Generated at 2022-06-24 07:53:22.867381
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Completion:
        pass

    c1 = Completion()
    c1.name = "a"
    c1.complete = "a="
    c1.description = "description"
    c1.type = "type"
    c1.parent = "parent"
    c1.full_name = "full_name"

    tc1 = ThonnyCompletion(
        name="a",
        complete="a=",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    assert tc1["name"] == c1.name
    assert tc1["complete"] == c1.complete
    assert tc1["description"] == c1.description
    assert tc1["type"] == c1.type

# Generated at 2022-06-24 07:53:32.163549
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.plugins.micropython.utils import micropython_completions
    from copy import deepcopy


# Generated at 2022-06-24 07:53:35.104830
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("import datetime; datetime.date(20", [])
    assert completions[0].name == "date(20"



# Generated at 2022-06-24 07:53:44.231892
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from thonny.plugins.jedi_autocomplete import utils_jedi
    from jedi.parser_utils import get_statement_of_position
    from parso.python.tree import Name

    # Testing for older jedi
    if utils_jedi._using_older_jedi(jedi):
        source = "a=5\na."
        row = 2
        column = 3
        filename = "test_file.py"
        sys_path = None
        script = jedi.Script(source, row, column, filename)
        assert isinstance(script, jedi.Script)
        completions = script.completions()
        completions = utils_jedi._tweak_completions(completions)
        assert isinstance(completions, list)

# Generated at 2022-06-24 07:53:47.988014
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.python import tree

    source = "a = 1\nb = 2"
    root_node = parse_source(source)
    assert isinstance(root_node, tree.Module)
    assert len(root_node.children) == 2



# Generated at 2022-06-24 07:53:51.973823
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    from parso.python.tree import (
        Leaf,
    )

    src = "x = 1 + 2\n"
    module = parse_source(src)

    assert type(module) == tree.Module
    assert module[0].type == "simple_stmt"
    assert module[0][0].type == "expr_stmt"
    assert module[0][0][0].type == "arithmetic_expr"
    assert module[0][0][0][0].type == "name"



# Generated at 2022-06-24 07:53:56.243381
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.codeview import get_code_view
    from thonny.ui_utils import select_sequence

    code = """
    import numpy
    numpy.
    """

    view = get_code_view()

    # Put the cursor on numpy
    view.text.insert("1.end", code)
    view.text.see("3.3")
    select_sequence(view.text, "3.3", "3.8")

    # Call get_definitions
    definitions = get_definitions(view.text.get("1.0", "end-1c"), 3, 3, view.text.winfo_name())

    assert len(definitions) == 1
    definition = definitions[0]

    assert isinstance(definition, jedi.api.classes.Definition)

# Generated at 2022-06-24 07:54:06.439021
# Unit test for function get_script_completions
def test_get_script_completions():

    from thonny import get_workbench

    # Create a new test file
    from thonny import get_runner
    from thonny.common import InlineCommand
    from thonny.globals import get_workbench, get_shell
    from thonny.ui_utils import select_sequence

    editor = get_workbench().get_editor("TestPythonFile.py")
    editor.set_text("x =")
    editor.text.mark_set("insert", "1.3")
    editor.text.see("insert")
    editor.update()

    select_sequence(editor.text, "insert", "end")

    # Test completions.
    completions = _get_completions(editor, row=1, column=3)
    assert completions

    # Test incomplete completions
    completions = _

# Generated at 2022-06-24 07:54:12.577080
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert c['name'] == 'name'
    assert c['complete'] == 'complete'
    assert c['type'] == 'type'
    assert c['description'] == 'description'
    assert c['parent'] == 'parent'
    assert c['full_name'] == 'full_name'

# Generated at 2022-06-24 07:54:15.186885
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    from jedi.parser.tree import Statement
    from parso.python.tree import Name
    from jedi import common


# Generated at 2022-06-24 07:54:16.065127
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:54:21.524160
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion("", "", "", "", "", "")["name"] == ""
    assert ThonnyCompletion("", "", "", "", "", "")["complete"] == ""
    assert ThonnyCompletion("", "", "", "", "", "")["type"] == ""
    assert ThonnyCompletion("", "", "", "", "", "")["description"] == ""
    assert ThonnyCompletion("", "", "", "", "", "")["parent"] == ""
    assert ThonnyCompletion("", "", "", "", "", "")["full_name"] == ""



# Generated at 2022-06-24 07:54:28.015014
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert get_interpreter_completions("import tho", [{'tho': 'thonny.plugins.micropython'}])
    assert get_interpreter_completions("import thonny; thonny.get_shell().tho", [{}])
    assert get_interpreter_completions("import thonny; thonny.get_shell().thonny.get_shell()", [{}])

# Generated at 2022-06-24 07:54:36.088696
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    import random
    import pytest
    import jedi.parser_utils

    # The general idea of this test is to generate a 'suite' with a
    # few statements. The statements should be in a nested structure.
    # For example: if, else, elif statements or if, try, except statements.
    # 
    # For each position in the suite, a jedi.parser_utils.get_statement_of_position
    # call is made. The result is checked, by calling the same method with the
    # result tree node instead of the source code. If the two calls return the same
    # node, the test succeeds.

    # This is the list of node types that are considered a statement.
    # The random test generator only uses those.

# Generated at 2022-06-24 07:54:39.023861
# Unit test for function parse_source
def test_parse_source():
    def get(python_code):
        parsed = parse_source(python_code)
        return parsed.type

    assert get("while True") == "file_input"
    assert get("while True: pass") == "file_input"
    assert get("while True: pass\n 2 + 3") == "file_input"



# Generated at 2022-06-24 07:54:42.347746
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.python_shell import get_completion_names
    completion_names = get_completion_names("import sys;sys.setde", 3, 22, "")
    assert ("sys.setdefaultencoding" in completion_names)


# Generated at 2022-06-24 07:54:50.460271
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['name'] == 1
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['complete'] == 2
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['type'] == 3
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['description'] == 4
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['parent'] == 5
    assert ThonnyCompletion(1, 2, 3, 4, 5, 6)['full_name'] == 6

# Generated at 2022-06-24 07:55:01.474194
# Unit test for function get_definitions
def test_get_definitions():
    assert eval("get_definitions('''x=5\nd''', 2, 2, '')") == []
    assert eval("get_defitions('''5+5\n''', 1, 3, '')") == []
    assert eval("get_definitions('''x=5\nd''', 1, 2, '')") == []
    assert eval("get_definitions('''def f(): pass\n''', 1, 8, '')") == []
    assert eval("get_definitions('''def f():\n    def g():\n        pass\nf''', 3, 8, '')") == []
    assert eval("get_definitions('''class A:\n    x=5\n    A''', 2, 6, '')") == []

# Generated at 2022-06-24 07:55:02.659413
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-24 07:55:08.468476
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'name'
    complete = 'complete'
    type = 'type'
    description = 'description'
    parent = 'parent'
    full_name = 'full_name'
    completion = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert completion['name'] == name
    assert completion['complete'] == complete
    assert completion['type'] == type
    assert completion['description'] == description
    assert completion['parent'] == parent
    assert completion['full_name'] == full_name

test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:55:16.031512
# Unit test for function parse_source
def test_parse_source():
    # test for source with only one statement and no error
    source = "a = 1"
    actual = parse_source(source)
    assert actual.start_pos == (1, 0)
    assert actual.end_pos == (1, 5)
    # test for source with multiple statements and no error
    source = """
a = 1
b = 2
"""
    actual = parse_source(source)
    assert actual.start_pos == (2, 0)
    assert actual.end_pos == (3, 6)
    # test for source with invalid statement
    source = """
a = 1
b = 2
c = 3
d = 4 e = 5
"""
    actual = parse_source(source)
    assert actual.type == "file_input"
    assert actual.start_pos == (1, 0)
    assert actual

# Generated at 2022-06-24 07:55:25.628244
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # case 1: std library
    interp = get_interpreter_completions(
        source="import math",
        namespaces=[{
            "__builtins__": __builtins__
        }],
    )
    assert len(interp) > 0
    found = False
    for completion in interp:
        if completion.name == "math":
            found = True
    assert found

    # case 2: project
    import os
    import _demo
    source = os.path.dirname(_demo.__file__)
    completions = get_interpreter_completions(
        source="import",
        namespaces=[{
            "__builtins__": __builtins__,
        }],
        sys_path=[
            source,
        ],
    )

# Generated at 2022-06-24 07:55:34.127689
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.config import get_python_path
    from thonny.misc import running_on_mac_os
    from thonny.globals import get_runner

    test_code = "try:\n    import turtle\n    t = turtle.Turtle()\n    t.circle(100, ext"
    test_row = 3
    test_column = 44
    test_filename = "test.py"
    expected_completions = [
        ThonnyCompletion(
            name="extent", complete="extent=360", type="keyword", description=""
        ),
        ThonnyCompletion(name="steps", complete="steps=10", type="keyword", description=""),
    ]

    # Check with empty sys_path

# Generated at 2022-06-24 07:55:36.031628
# Unit test for function get_script_completions
def test_get_script_completions():
    assert (
        get_script_completions("print('Hällo')", 0, 1, "hello.py")[0].name
        == "print()"
    )



# Generated at 2022-06-24 07:55:36.619804
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso


# Generated at 2022-06-24 07:55:42.413287
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert thonnyCompletion.__getitem__("name") == "name"
    assert thonnyCompletion.__getitem__("complete") == "complete"
    assert thonnyCompletion.__getitem__("type") == "type"
    assert thonnyCompletion.__getitem__("description") == "description"
    assert thonnyCompletion.__getitem__("parent") == "parent"
    assert thonnyCompletion.__getitem__("full_name") == "full_name"


# Generated at 2022-06-24 07:55:52.984605
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp1.__dict__ == {
        "name":"name", 
        "complete":"complete", 
        "type":"type", 
        "description":"description", 
        "parent":"parent", 
        "full_name":"full_name"
    }
    comp2 = ThonnyCompletion("n", "c", "t", "d", "p", "f")
    assert comp2.__dict__ == {
        "name":"n", 
        "complete":"c", 
        "type":"t", 
        "description":"d", 
        "parent":"p", 
        "full_name":"f"
    }


# Generated at 2022-06-24 07:55:57.699794
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completions = [
        ThonnyCompletion(name="x", complete="x", type="x", description="x", parent="x", full_name="x")
    ]
    result = [
        {"name": "x", "complete": "x", "type": "x", "description": "x", "parent": "x", "full_name": "x"}
    ]
    assert result == completions

# Generated at 2022-06-24 07:56:07.257105
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    import jedi.parser_utils

    def parse(code):
        return parso.parse(code)

    assert isinstance(get_statement_of_position(parse("a\nb"), (1, 1)), tree.ErrorLeaf)
    assert isinstance(get_statement_of_position(parse("a\nb"), (1, 2)), tree.ExprStmt)
    assert isinstance(get_statement_of_position(parse("a\n  b"), (2, 1)), tree.ErrorLeaf)
    assert isinstance(get_statement_of_position(parse("a\n  b"), (2, 2)), tree.ExprStmt)

# Generated at 2022-06-24 07:56:16.163595
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso
    import jedi
    from thonny.jedi_utils import get_script_completions
    import parso.tree

    def get_name(node):
        if isinstance(node, parso.tree.ExprStmt):
            return node.get_expressions()[-1].name
        elif isinstance(node, parso.tree.Name):
            return node
        elif isinstance(node, parso.tree.Param):
            return node.get_name()

    def get_complete(node):
        if isinstance(node, parso.tree.ExprStmt):
            return node.get_expressions()[-1].get_code()
        elif isinstance(node, parso.tree.Name):
            return node.get_code()

# Generated at 2022-06-24 07:56:23.210144
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    """
    Known to fail with jedi <= 0.16

    >>> source = 'def func():\\n    pass\\n    pass\\n    pass'
    >>> node = parse_source(source)
    >>> pos = (3, 5)
    >>> result = get_statement_of_position(node, pos)
    >>> print(result.get_code())
    pass
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 07:56:29.050164
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    complete = ThonnyCompletion(name='name', complete='complete', type='type', description='description', parent='parent', full_name='full_name')
    assert complete['name'] == 'name'
    assert complete['complete'] == 'complete'
    assert complete['type'] == 'type'
    assert complete['description'] == 'description'
    assert complete['parent'] == 'parent'
    assert complete['full_name'] == 'full_name'
    try:
        complete['something']
        assert False
    except KeyError:
        pass

# Generated at 2022-06-24 07:56:37.083408
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion1 = ThonnyCompletion(
        name="name1", complete="complete1", type="type1", description="desc1", parent="parent1", full_name="full_name1"
    )
    assert completion1.name == "name1"
    assert completion1.complete == "complete1"
    assert completion1.type == "type1"
    assert completion1.description == "desc1"
    assert completion1.parent == "parent1"
    assert completion1.full_name == "full_name1"


# Generated at 2022-06-24 07:56:47.370084
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    if _using_older_jedi(jedi):
        assert get_script_completions("class MyClass:pass", 0, 10, "demo.py")[1].complete == "s"
        assert get_script_completions("class MyClass:pass", 0, 10, "demo.py")[1].name == "s"
        assert get_script_completions("class MyClass:pass", 0, 10, "demo.py")[1].type == "class"
        assert get_script_completions("class MyClass:pass", 0, 10, "demo.py")[1].parent == "__main__"

# Generated at 2022-06-24 07:56:52.214320
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion(name="name",complete="complete",type="type",description="description",parent="parent",full_name="full_name")
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"

# Generated at 2022-06-24 07:56:54.541068
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(name="name", 
                     complete="complete", 
                     type="type", 
                     description="description", 
                     parent="parent", 
                     full_name="full_name")
#test_ThonnyCompletion()

# Generated at 2022-06-24 07:57:03.732280
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import sys

    cur_dir_path = os.path.dirname(os.path.realpath(__file__))
    parent_dir_path = os.path.abspath(os.path.join(cur_dir_path, os.pardir))
    sys.path.append(cur_dir_path)
    sys.path.append(parent_dir_path)

    import test_utils

    file_path = os.path.join(cur_dir_path, "test_get_definitions.py")
    with open(file_path, "r", encoding="utf-8") as f:
        file_content = f.read()

    lines = file_content.split("\n")

# Generated at 2022-06-24 07:57:06.557287
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(
        name="name", complete="complete",
        type="type", description="description",
        parent="parent", full_name="full_name"
    )

# Generated at 2022-06-24 07:57:15.844837
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    assert _using_older_jedi(jedi) == False
    from jedi.api.classes import Interpreter
    from jedi import Script
    import types

    def dummy_complete(self):
        return []

    def dummy_get_global_namespace(self):
        return []

    def dummy_set_context(self):
        return []

    def dummy_get_modules(self):
        return []

    Interpreter.complete = dummy_complete
    Interpreter.get_global_namespace = dummy_get_global_namespace
    Interpreter.set_context = dummy_set_context
    Interpreter.get_modules = dummy_get_modules

    # test passing parameters in jedi 0.18 method

# Generated at 2022-06-24 07:57:22.644162
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions('"a".uppe',0, 1, '/tmp/a'))
    print(get_script_completions('"a".uppe',0, 7, '/tmp/a'))
    print(get_script_completions('import datetime\ndateti',0, 1, '/tmp/a'))
    print(get_script_completions('import datetime\ndateti',1, 10, '/tmp/a'))

# Generated at 2022-06-24 07:57:26.626151
# Unit test for function get_script_completions
def test_get_script_completions():
    from .jedi_utils import get_script_completions

    source = "import cv2"
    row = 1
    column = 11
    filename = "test.py"
    print(
        get_script_completions(source, row, column, filename)
    )  # Outputs [Completion(name='cv2'....)]


if __name__ == "__main__":
    test_get_script_completions()

# Generated at 2022-06-24 07:57:27.930251
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso


# Generated at 2022-06-24 07:57:29.244033
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase


# Generated at 2022-06-24 07:57:33.013329
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("a = 16\na.real", 1, 3, "test.py")) == 1
    assert len(get_definitions("a = 16\na.rea", 1, 4, "test.py")) == 0



# Generated at 2022-06-24 07:57:41.543458
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script
    import os

    # get the path of the script
    dir = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(dir, '../../thonny/workbench.py')

    # read source as string
    with open(path) as f:
        source = f.read()

    # test for completions for the builtin function "min"
    row = 1
    column = 1
    completions = Script(source, row, column, '').completions()
    assert len(completions) > 0
    assert completions[0].name == 'min'

    # test for completions for "settings."
    row = 142
    column = 26
    completions = Script(source, row, column, '').completions()


# Generated at 2022-06-24 07:57:43.386192
# Unit test for function parse_source

# Generated at 2022-06-24 07:57:46.224284
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import sys\n sys.std", 2, 5, "dummy.py")
    assert len(completions) == 1 and completions[0].name == "stdin"

# Generated at 2022-06-24 07:57:50.001831
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        print("Run the test_get_interpreter_completions unit test in Python 3.6 or 3.7")
        return

# Generated at 2022-06-24 07:58:00.808316
# Unit test for function get_definitions
def test_get_definitions():
    import parso.python.tree as pt
    from parso.python import tree

    source = "def foo():\n    pass\n\nfoo()\n"
    definitions = get_definitions(source, 3, 3, "<string>")

    assert isinstance(definitions, list)

    assert len(definitions) == 1
    assert definitions[0].line == 1
    assert isinstance(definitions[0].start_pos, tuple)
    assert isinstance(definitions[0].parent, tree.Function)
    assert definitions[0].parent.end_pos == definitions[0].end_pos
    assert definitions[0].parent.name.value == "foo"
    assert isinstance(definitions[0].parent.parent, pt.Module)

# Generated at 2022-06-24 07:58:08.017026
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import ast
    import types

    def make_namespace(ns_name, vars):
        # vars should be a list of (name, value) pairs

        class Simple:
            pass

        namespace = Simple()
        namespace.__name__ = ns_name

        for name, value in vars:
            setattr(namespace, name, value)

        return namespace

    s = "a = [1,2, 'spam']; a.ap"
    result = get_interpreter_completions(
        s,
        [make_namespace("__main__", [("a", [1, 2, "spam"])])],
    )

# Generated at 2022-06-24 07:58:17.322301
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class TestCase(unittest.TestCase):
        def test_module(self):
            definitions = get_definitions(
                "import math\nm=math", row=2, column=2, filename="#"
            )
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].module_name, "math")

        def test_class(self):
            definitions = get_definitions(
                "class A: pass\n" "a = A()", row=2, column=4, filename="#"
            )
            self.assertEqual(len(definitions), 1)
            self.assertEqual(definitions[0].type, "class")
            self.assertEqual(definitions[0].description, "A")


# Generated at 2022-06-24 07:58:21.754732
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\n" "sys."
    completions = get_script_completions(source, 1, 5)
    names = [completion["name"] for completion in completions]

    assert "sys" in names
    assert "argv" in names
    assert "path" in names
    assert "version_info" in names



# Generated at 2022-06-24 07:58:26.941488
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp.name == "name"
    assert comp.complete == "complete"
    assert comp.type == "type"
    assert comp.description == "description"
    assert comp.parent == "parent"
    assert comp.full_name == "full_name"
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-24 07:58:36.365033
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("int", "int(", "int", "int(x) -> integer", "", "int")
    assert completion.name == "int"
    assert completion.complete == "int("
    assert completion.type == "int"
    assert completion.description == "int(x) -> integer"
    assert completion.parent == ""
    assert completion.full_name == "int"

    completion = ThonnyCompletion("int=", "int(", "int", "int(x) -> integer", "", "int")
    assert completion.name == "int="
    assert completion.complete == "int("
    assert completion.type == "int"
    assert completion.description == "int(x) -> integer"
    assert completion.parent == ""
    assert completion.full_name == "int"

# Generated at 2022-06-24 07:58:38.933657
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions("import sys", 1, 0, "test.py")

    assert len(defs) == 1
    assert defs[0]._name.get_code() == "sys"

# Generated at 2022-06-24 07:58:41.607275
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('test', 'test', 'test', 'test', 'test', 'test')
    assert completion.name == 'test'

# Generated at 2022-06-24 07:58:45.681263
# Unit test for function get_definitions
def test_get_definitions():
    source = "import random; rn = random.randint\nrn(1,3)"
    defs = get_definitions(source, 1, len(source), "dummy.py")
    assert len(defs) == 1
    d = defs[0]
    assert d.row == 1
    assert d.column == 0
    assert d.module_name == "random"
    assert d.full_name == "random.randint"
    assert d.type == "function"
    assert d.name == "randint"
    assert d.in_builtin_module() is True

# Generated at 2022-06-24 07:58:53.528451
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # jedi >= 0.18
    try:
        import jedi
        if jedi.__version__[:4] in ["0.18", "0.19", "0.20"]:
            test_get_interpreter_completions_jedi_18()
            return
    except ImportError:
        pass

    completions = get_interpreter_completions("open", [])
    assert len(completions) > 30
    assert [c.name for c in completions] == [c.complete for c in completions]
    assert [c.type for c in completions]
    assert [c.description for c in completions]



# Generated at 2022-06-24 07:59:03.761200
# Unit test for function parse_source
def test_parse_source():
    import sys
    if sys.version_info < (3, 8):
        raise Exception("test needs python 3.8 or higher")

    test_source = '''def foo(x: int,
                            y):
    return x + y
'''

    test_tree = parse_source(test_source)
    # This is a fix for Parso
    # https://github.com/davidhalter/parso/pull/213
    # https://github.com/davidhalter/parso/issues/214
    # TODO: is this still needed?
    for node in test_tree.children:
        if isinstance(node, parso.python.tree.Function):
            node.newlines = 0

    return test_tree



# Generated at 2022-06-24 07:59:13.584460
# Unit test for function parse_source
def test_parse_source():
    import parso

    sample_source = "def myfun():\n    return 5"
    parsed = parse_source(sample_source)
    assert isinstance(parsed, parso.python.tree.Module)

    sample_source = "# mycomment\n" + sample_source
    parsed = parse_source(sample_source)
    assert isinstance(parsed, parso.python.tree.Module)

    sample_source = "not_python\n" + sample_source
    try:
        parsed = parse_source(sample_source)
    except parso.python.tree.ParserSyntaxError as e:
        assert "unexpected EOF while parsing" in str(e)
    else:
        # this should trigger an error -> test fails.
        assert False

# Generated at 2022-06-24 07:59:19.669578
# Unit test for function get_definitions
def test_get_definitions():
    source = "import math\nm = math.log(10)"

    definitions = get_definitions(source, row=1, column=9, filename=__file__)
    assert len(definitions) == 1
    assert definitions[0].line == 6

    definitions = get_definitions(source, row=1, column=0, filename=__file__)
    assert len(definitions) == 1
    assert definitions[0].line == 0

# Generated at 2022-06-24 07:59:20.219968
# Unit test for function parse_source

# Generated at 2022-06-24 07:59:25.801319
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase

    class T(TestCase):
        def check(self, source):
            completions = get_interpreter_completions(source, [])
            self.assertTrue(len(completions) > 0)
            for c in completions:
                self.assertTrue(c.complete.startswith(c.name))

    import tkinter
    import tkinter as tk
    import tkinter.ttk

    T().check("tkinter.Tk().")
    T().check("tk.Tk().")
    T().check("tk.ttk.Tk().")



# Generated at 2022-06-24 07:59:37.040398
# Unit test for function get_script_completions
def test_get_script_completions():

    source = "import json; json.d"
    row = 0
    column = len(source)
    filename = "tst.py"
    actual = get_script_completions(source, row, column, filename)


# Generated at 2022-06-24 07:59:42.474963
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    # Arrange
    jedi.Interpreter = mock_jedi_interpreter
    row = 0
    column = 0
    filename = ""
    text = "a = 3"
    sys_path = None

    # Act
    result = get_interpreter_completions(text, [], sys_path)

    # Assert
    assert result is not None
    assert len(result) > 0
    assert result[0].name == "abc"
    assert result[0].complete == "abc"
    assert result[0].type == "import"
    assert result[0].description == "description"
    assert result[0].full_name == "full_name"



# Generated at 2022-06-24 07:59:49.060441
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    from unittest.mock import patch, MagicMock

    class DummyInterpreter:
        def __init__(self, source, namespaces):
            self.completions = MagicMock()

    test_source = 'some_source'
    test_namespaces = ["some_namespace"]

    completions = get_interpreter_completions(test_source, test_namespaces)

    assert completions == DummyInterpreter(test_source, test_namespaces).completions()

# Generated at 2022-06-24 07:59:53.953544
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("import datetim", 1, 15, "test.py")
    result = list(result)
    assert len(result) == 2
    assert result[0].name == "datetime"
    assert result[1].name == "dateutil"
    

# Generated at 2022-06-24 08:00:00.695983
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    execution = ThonnyCompletion(name="add_to_db", complete="add_to_db(", type="function", description="add_to_db(param_1, param_2)", parent="Connection", full_name="Connection.add_to_db")

    assert execution.name == "add_to_db"
    assert execution.complete == "add_to_db("
    assert execution.type == "function"
    assert execution.description == "add_to_db(param_1, param_2)"
    assert execution.parent == "Connection"
    assert execution.full_name == "Connection.add_to_db"



# Generated at 2022-06-24 08:00:12.110512
# Unit test for function get_definitions
def test_get_definitions():
    import imp
    import sys

    sys.path.insert(0, "C:/Users/eneri/Documents/GitHub/thonny/tests")
    sys.modules["thonny.globals_"] = imp.load_source(
        "thonny.globals_", "C:/Users/eneri/Documents/GitHub/thonny/tests/thonny/globals_.py"
    )
    input = "from thonny import globals_\nglobals_."
    definitions = get_definitions(input, 2, 17, "C:/Users/eneri/Documents/GitHub/thonny/tests")
    assert len(definitions) == 3

# Generated at 2022-06-24 08:00:22.698462
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    def find_statement_in_python3(source, pos):
        tree = parso.parse(source)
        try:
            return get_statement_of_position(tree, pos)
        except AttributeError:
            return None

    def find_statement_in_python2(source, pos):
        try:
            tree = parso.parse(source)
            return _copy_of_get_statement_of_position(tree, pos)
        except AttributeError:
            return None

    def assertSameStatement(source, pos):
        expected = find_statement_in_python3(source, pos)
        found = find_statement_in_python2(source, pos)
        assert (expected.get_code() == found.get_code())


# Generated at 2022-06-24 08:00:26.081439
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    try:
        c.__getitem__("name")
    except AttributeError:
        return False
    return True

# Generated at 2022-06-24 08:00:28.714489
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("os.path.", [{"os": {}}])) > 0



# Generated at 2022-06-24 08:00:38.094071
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    def test_one(input, position, expected):
        node = parse_source(input)
        result = get_statement_of_position(node, position)
        assert result.get_code() == expected

    test_one("x=5", (0, 1), "x")
    test_one("x=5", (0, 2), "x=5")
    test_one("x=5", (1, 0), "")

    test_one("x=5\nif x:\n    print(1)", (1, 1), "if x:")
    test_one("x=5\nif x:\n    print(1)", (2, 3), "print(1)")

    test_one("x=5\nif x:", (1, 1), "if x:")

# Generated at 2022-06-24 08:00:48.735144
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Script, Interpreter

    # Generate completions for a string in an interpreter
    # Taken from https://jedi.readthedocs.io/en/latest/docs/api.html#jedi.Script
    # but adapted for new jedi
    code = "import datetime, sys"
    line = 2
    column = 7
    namespace = [{"name": "datetime", "path": "datetime"}, {"name": "sys", "path": "sys"}]
    completions = get_interpreter_completions(code, namespace)

    # We need to assert that completions are empty to ensure the completion is correct.
    # If we don't assert that completions are empty, and completions contain an invalid
    # result, no exception will be raised.
    assert completions == []

    # Ass

# Generated at 2022-06-24 08:00:56.065627
# Unit test for function get_script_completions
def test_get_script_completions():
    if _using_older_jedi(__import__("jedi")):
        import jedi

        script = jedi.Script("""
import sys
sys.pa
""", 1, 10, "test.py")
        completions = script.completions()
        assert len(completions) >= 1
        assert completions[0].name == "path"
    else:
        import jedi

        script = jedi.Script("""
import sys
sys.pa
""", "test.py")
        completions = script.complete(1, 10)
        assert len(completions) >= 1
        assert completions[0].complete == "path"

# Generated at 2022-06-24 08:01:04.680358
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    import jedi.parser

    # Test case 1: from sys import
    source = "import sys"
    namespaces = [{'sys': sys}]
    _test_completions(
        sorted(Interpreter(source, namespaces).completions()),
        sorted(get_interpreter_completions(source, namespaces)),
    )

    # Test case 2: from jedi import
    source = "import jedi"
    from jedi.parser_utils import get_statement_of_position

    namespaces = [{'jedi': jedi}]
    _test_completions(
        sorted(Interpreter(source, namespaces).completions()),
        sorted(get_interpreter_completions(source, namespaces)),
    )

    #

# Generated at 2022-06-24 08:01:09.761846
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    variables, _ = Interpreter(code="print()", namespaces=[]).gather_names()
    assert len(variables) == 1
    print(variables[0].type)
    assert variables[0].name == "print"
    assert variables[0].type == "function"



# Generated at 2022-06-24 08:01:19.186512
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"
    # KeyError
    try:
        completion["wrong_key"]
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-24 08:01:19.888598
# Unit test for function get_definitions

# Generated at 2022-06-24 08:01:26.272939
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    script = Script("import sys; sys.p")
    completion = script.complete()[0]
    thonny_completion = ThonnyCompletion(completion.name, completion.complete,
                                         completion.type, completion.description,
                                         completion.parent, completion.full_name)
    assert completion.name == thonny_completion.name
    assert completion.complete == thonny_completion.complete
    assert completion.type == thonny_completion.type
    assert completion.description == thonny_completion.description
    assert completion.parent == thonny_completion.parent
    assert completion.full_name == thonny_completion.full_name
