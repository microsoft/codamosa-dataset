

# Generated at 2022-06-24 07:51:05.635188
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys

    sys.path.append(os.path.abspath("test/testdata/jedi"))
    s = "'".join(get_interpreter_completions("import test_2\ntest_2.", [], ["test"]))
    assert "test_child_a" in s
    assert "test_child_a()" in s
    assert "test_child_b" in s
    assert "test_child_b()" in s
    assert "test_child_3" not in s
    assert "test_child_3()" not in s

# Generated at 2022-06-24 07:51:12.839375
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.classes import Definition
    from thonny.plugins.jedi_utils import get_definitions
    source = ("class Foo:\n"
              "    def __init__(self, name):\n"
              "        self.name = name\n"
              "\n"
              "    def greet(self):\n"
              "        print('Hello')\n"
              "\n"
              "    def say_name(self):\n"
              "        print(self.name)\n"
              "\n"
              "foo = Foo('Guy')\n"
              "foo.say_name()\n")
    filename = 'mymodule.py'
    ds = get_definitions(source, 20, 4, filename)
    print(ds)
    assert len(ds) == 1
   

# Generated at 2022-06-24 07:51:20.002036
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # Setup
    name = "test_name"
    complete = "test_complete"
    type = "test_type"
    description = "test_description"
    parent = "test_parent"
    full_name = "test_full_name"
    keys = {name, complete, type, description, parent, full_name}
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)

    # Assert
    for key in keys:
        assert(tc.__getitem__(key) == key)

# Generated at 2022-06-24 07:51:29.601427
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    # name, complete, type, description, parent, full_name
    parent = jedi.api.classes.Class()
    test_completion = ThonnyCompletion("name", "complete", "type", "description", parent, "full_name")
    assert test_completion[
        "name"
    ] == "name", "Test constructor of class ThonnyCompletion failed"
    assert (
        test_completion["complete"] == "complete"
    ), "Test constructor of class ThonnyCompletion failed"
    assert test_completion["type"] == "type", "Test constructor of class ThonnyCompletion failed"
    assert (
        test_completion["description"] == "description"
    ), "Test constructor of class ThonnyCompletion failed"

# Generated at 2022-06-24 07:51:40.441589
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__getitem__("name") == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__getitem__("complete") == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__getitem__("type") == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__getitem__("description") == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").__getitem__("full_name") == "full_name"


# Generated at 2022-06-24 07:51:48.513763
# Unit test for function parse_source
def test_parse_source():
    import parso
    src = 'print("Hello" + " world!")'
    result = parse_source(src)
    assert isinstance(result, parso.python.tree.Module)
    assert result.children[0].children[0].type == 'print_stmt'
    assert result.children[0].children[0].children[0].type == 'atom'
    assert result.children[0].children[0].children[0].end_pos == (0, 6)
    assert result.children[0].children[0].children[0].end_pos == (0, 6)

# Generated at 2022-06-24 07:51:54.622634
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:52:00.149133
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys

    # case 1
    assert len(get_interpreter_completions("sys.", sys.modules)) > 0
    # case 2
    assert (
        len(
            get_interpreter_completions(
                "sys.path", sys.modules, sys_path=["/home/thonnydev/thonny/thonny/backend"]
            )
        )
        > 0
    )
    # case 3
    assert len(get_interpreter_completions("a", [])) == 0

# Generated at 2022-06-24 07:52:07.634712
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    from parso.python.tokenize import Token

    source = "with open('asd'):\n    print('asd')"
    node = parse_source(source)
    assert isinstance(node, Module)
    assert len(node.children) == 1
    assert isinstance(node.children[0], Token)
    assert node.children[0].string == 'with'



# Generated at 2022-06-24 07:52:15.379687
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import os
    import sys

    if sys.platform == "win32":
        return

# Generated at 2022-06-24 07:52:24.145868
# Unit test for function get_definitions
def test_get_definitions():
    assert len(get_definitions("import sys\nprint(sys)", 1, 8, "test.py")) == 1
    assert len(get_definitions("import sys\nprint(sys)", 1, 17, "test.py")) == 1
    assert len(get_definitions("import sys\nprint(sys", 1, 16, "test.py")) == 1
    assert len(get_definitions("import sys\nprint(sys.argv", 1, 20, "test.py")) == 1
    assert len(get_definitions("import sys\nprint(sys.argv.remove", 1, 29, "test.py")) == 1
    assert len(get_definitions("import sys\nprint(sys.argv.remove.", 1, 33, "test.py")) == 1

# Generated at 2022-06-24 07:52:31.395637
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="name",
                                  complete="complete",
                                  type="type",
                                  description="description",
                                  parent="parent",
                                  full_name="full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"


# Generated at 2022-06-24 07:52:32.967752
# Unit test for function get_definitions

# Generated at 2022-06-24 07:52:40.624098
# Unit test for function get_script_completions
def test_get_script_completions():
    # jedi has changed default input for completions
    # verify our workaround works
    import jedi
    if jedi.__version__[:4] < "0.17":
        expected_name = "self"
        expected_complete = "self"
    else:
        expected_name = "self="
        expected_complete = "self"

    result = get_script_completions(source="", row=1, column=1, filename="")
    
    assert [x.name for x in result] == [expected_name]
    assert [x.complete for x in result] == [expected_complete]

# Generated at 2022-06-24 07:52:47.920010
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree as tree
    # see https://github.com/davidhalter/parso/issues/28

# Generated at 2022-06-24 07:52:56.284334
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import itertools\nitertools."
    completions = get_script_completions(source, 2, 11, "dummy")
    assert sorted([c.name for c in completions]) == [
        "chain",
        "combinations",
        "combinations_with_replacement",
        "compress",
        "count",
        "cycle",
        "dropwhile",
        "filterfalse",
        "groupby",
        "islice",
        "permutations",
        "product",
        "repeat",
        "starmap",
        "takewhile",
        "tee",
        "zip_longest",
    ]



# Generated at 2022-06-24 07:52:56.702051
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:53:07.013809
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    class FakeNode:
        def __init__(self, start_pos, end_pos, children):
            self.start_pos = start_pos
            self.end_pos = end_pos
            self.children = children

    fake_parser = FakeNode(
        (1, 1),
        (12, 12),
        [
            FakeNode((1, 1), (2, 2), []),
            FakeNode(
                (2, 2), (5, 9), [FakeNode((3, 4), (5, 5), [])]
            ),  # should return this
            FakeNode((5, 9), (12, 12), []),
        ],
    )
    result = get_statement_of_position(fake_parser, (4, 4))
    assert result.start_pos == (3, 4)
    assert result.end

# Generated at 2022-06-24 07:53:11.807132
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t1 = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    if t1["name"] != "name":
        print("ERROR! Test t1[name]")
    if t1["complete"] != "complete":
        print("ERROR! Test t1[complete]")
    if t1["type"] != "type":
        print("ERROR! Test t1[type]")
    if t1["description"] != "description":
        print("ERROR! Test t1[description]")
    if t1["parent"] != "parent":
        print("ERROR! Test t1[parent]")
    if t1["full_name"] != "full_name":
        print("ERROR! Test t1[full_name]")



# Generated at 2022-06-24 07:53:13.892388
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api import Script
    script = Script("import abc", 1, 1)
    definitions = script.goto_definitions()
    assert len(definitions) == 1

# Generated at 2022-06-24 07:53:20.696317
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_support.jedi_utils import get_script_completions

    source = 'import sys\n'
    row = 2
    column = 0
    filename = '/path/to/file'
    completions = get_script_completions(source, row, column, filename)
    assert completions[0].name == 'print'
    assert completions[0].complete == 'print'
    assert completions[0].description.startswith('print(')
    assert completions[0].type == 'function'

# Generated at 2022-06-24 07:53:22.707153
# Unit test for function parse_source
def test_parse_source():
    source = "print(1 + 2)"
    node = parse_source(source)
    assert node.type == "file_input"

# Generated at 2022-06-24 07:53:26.128517
# Unit test for function parse_source
def test_parse_source():
    result = parse_source("from math import *\nx = ")
    assert result.children[1].type == "simple_stmt"
    assert result.children[1].children[0].children[0].type == "power"

# Generated at 2022-06-24 07:53:27.724670
# Unit test for function get_script_completions
def test_get_script_completions():
    print(get_script_completions("print(shap", 1, 8, "<stdin>"))

# Generated at 2022-06-24 07:53:32.535758
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    prio_node=tree.Node('print', 'print', [1,1])
    name_node=tree.Node('name', 'name', [1,2])
    prio_node.add_child(name_node)
    assert get_statement_of_position(prio_node, 1)==prio_node
    assert get_statement_of_position(prio_node, 2)==name_node

# Generated at 2022-06-24 07:53:42.266303
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").name == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").complete == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").type == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").description == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").parent == "parent"

# Generated at 2022-06-24 07:53:47.634650
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from test.jedi_utils import parse_source
    import jedi.parser_utils
    node = parse_source("if a:\n    pass\nelse:\n    pass")
    assert jedi.parser_utils.get_statement_of_position(node, (0, 0)) == node
    assert jedi.parser_utils.get_statement_of_position(node, (0, 4)) == node[1]

# Generated at 2022-06-24 07:53:53.941942
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc.__getitem__("name") == "name"
    assert tc.__getitem__("complete") == "complete"
    assert tc.__getitem__("type") == "type"
    assert tc.__getitem__("description") == "description"
    assert tc.__getitem__("parent") == "parent"
    assert tc.__getitem__("full_name") == "full_name"


# Generated at 2022-06-24 07:53:54.553879
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:53:57.849606
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # ThonnyCompletion(name=name, complete=complete, type=type, description=description, parent=parent, full_name=full_name)
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

# Generated at 2022-06-24 07:53:59.496042
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    ThonnyCompletion('', '', '', '', '', '')


# Generated at 2022-06-24 07:54:05.928186
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="test", complete="test", type="test", description="test", parent="test", full_name="test")
    completion_dict = completion.__dict__
    assert completion_dict["name"] == "test"
    assert completion_dict["complete"] == "test"
    assert completion_dict["type"] == "test"
    assert completion_dict["description"] == "test"
    assert completion_dict["parent"] == "test"
    assert completion_dict["full_name"] == "test"

# Generated at 2022-06-24 07:54:10.584888
# Unit test for function parse_source
def test_parse_source():
    source = '''\
    def function(x):
        pass
    '''

    root_node = parse_source(source)
    func_node = root_node.children[0]
    if func_node.type != "funcdef":
        raise AssertionError("jedi.Script did not return a function node")

# Generated at 2022-06-24 07:54:19.035777
# Unit test for function get_script_completions
def test_get_script_completions():
    _test_completions(get_script_completions, "x = sqrt(5)", 4, 7, "")
    _test_completions(get_script_completions, "import math; x = math.sqrt(5)", 4, 15, "")
    _test_completions(get_script_completions, "from math import sqrt", 4, 7, "")
    _test_completions(get_script_completions, "from math import sqrt as m", 4, 11, "")
    _test_completions(get_script_completions, "from math import sqrt as m; x = m(5)", 4, 13, "")


# Generated at 2022-06-24 07:54:30.317689
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import collections
    import textwrap

    if "jedi" not in globals():
        import jedi
    
    class TestGetDefinitions(unittest.TestCase):
        def setUp(self):

            # NB! Because of argparse module, on some systems (notably Windows) the first use
            # of jedi.Script with Jedi's default sys.path may fail 
            # (see https://github.com/davidhalter/jedi/issues/1540)
            # As a workaround we make sure that the first attempt does not fail
            jedi.Script("import argparse")

        # The following two function are copied from 
        # https://github.com/davidhalter/jedi/blob/master/test/test_goto_definitions.py

# Generated at 2022-06-24 07:54:40.335380
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree
    root = parse_source("print(hello)")
    assert root.start_pos == (1, 0)
    assert root.end_pos == (2, 8)
    assert isinstance(root, tree.Module)
    assert root.children == [
        tree.ExprStmt(
            children=[
                tree.Call(
                    children=[
                        tree.Name(children=[tree.NamePart(children=[tree.String("print")])]),
                        tree.Arguments(
                            children=[
                                tree.Argument(
                                    children=[
                                        tree.Name(children=[tree.NamePart(children=[tree.String("hello")])])
                                    ]
                                )
                            ]
                        ),
                    ]
                )
            ]
        )
    ]

# Generated at 2022-06-24 07:54:47.644105
# Unit test for function get_script_completions
def test_get_script_completions():
    """Test function get_script_completions from jedithon.py"""
    from jedithon import get_script_completions
    from unittest import TestCase

    source = 'print("Hello world")'
    row = 0
    column = 0
    filename = "test.py"
    sys_path = ["/home/thonny"]
    completions = get_script_completions(source, row, column, filename, sys_path)
    TestCase.assertEqual(type(completions), list)
    TestCase.assertNotEqual(len(completions), 0)
    TestCase.assertEqual(completions[0].name, "print()")



# Generated at 2022-06-24 07:54:55.371638
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    jedi = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    text1 = jedi["name"]
    text2 = jedi["complete"]
    text3 = jedi["type"]
    text4 = jedi["description"]
    text5 = jedi["parent"]
    text6 = jedi["full_name"]
    assert (text1 == "name") and (text2 == "complete") and (text3 == "type") and (text4 == "description") and (text5 == "parent") and (text6 == "full_name")

# Generated at 2022-06-24 07:54:57.635416
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("1 + 1", [{}], [])) == 1



# Generated at 2022-06-24 07:55:02.949879
# Unit test for function parse_source
def test_parse_source():
    source = """
if __name__ == '__main__':
    print('hello')
"""
    from parso.python.tree import Module
    from parso.python.tree import IfStmt

    module = parse_source(source)
    assert(isinstance(module, Module))
    assert(module.children[0] == IfStmt)


# Generated at 2022-06-24 07:55:11.003443
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Module, Function, ExprStmt, Name

    # use jedi.parser_utils to generate test data
    from jedi import parser_utils
    import parso

    for name in dir(parser_utils):
        if not name.startswith("test_"):
            continue

        method = getattr(parser_utils, name)
        source = "#".join(method.__doc__.split("#")[1:]).strip()

        tree = parso.parse(source)
        get_comments = False
        lines = source.splitlines()

        for el in tree.iter_all():
            if get_comments and not isinstance(el, Name):
                continue

# Generated at 2022-06-24 07:55:16.674596
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    try:
        import jedi.parser_utils
        get_statement_of_position = jedi.parser_utils.get_statement_of_position
    except ImportError:
        get_statement_of_position = _copy_of_get_statement_of_position

    def _test_result(source, pos, expected_type = None):
        module = parse_source(source)
        stmt = get_statement_of_position(module, pos)
        assert stmt
        if expected_type is not None:
            assert stmt.type == expected_type

    # position at the beginning

# Generated at 2022-06-24 07:55:19.189824
# Unit test for function parse_source
def test_parse_source():
    from unittest import TestCase
    from parso.utils import parse_version
    from parso import __version__

    if parse_version(__version__) < parse_version("2.2.0"):
        return

    try:
        parse_source("#!\n")
    except SyntaxError as e:
        TestCase().assertEqual(e.msg, "unexpected character after line continuation character")



# Generated at 2022-06-24 07:55:27.884139
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import ParserSyntaxError

    from thonny.pythonview import _parser

    # test with empty input
    source = ""
    node = _parser.parse(source)
    assert get_statement_of_position(node, (1, 0)) is None

    # test with input without new line
    source = "a = 1"
    node = _parser.parse(source)
    assert get_statement_of_position(node, (1, 0)) is None

    # test with a statement
    source = "a = 1\n"
    node = _parser.parse(source)
    assert get_statement_of_position(node, (1, 0)) is not None

    # test with a statement and a decorator
    source = "@dec\n" + source

# Generated at 2022-06-24 07:55:36.320515
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:55:40.067345
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    jedi.settings.additional_dynamic_modules = ["six"]

    completions = get_interpreter_completions(
        source="import six\nsix.", namespaces=[{}], sys_path=["."]
    )

    assert len(completions) > 0
    assert set([c.name for c in completions]) == set(["six"])

# Generated at 2022-06-24 07:55:50.496133
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    node = tree.Module("dummy")

    comments = [tree.Comment("# nothing")]

    statements = [
        tree.ExprStmt(
            tree.Name("a", prefix=None, suffix=None, context=None, is_definition=None)
        ),
        tree.ExprStmt(
            tree.Name(
                "b", prefix=None, suffix=None, context=tree.Load(), is_definition=None
            )
        ),
        tree.ExprStmt(
            tree.Name(
                "c",
                prefix=None,
                suffix=None,
                context=tree.Load(),
                is_definition=None,
            )
        ),
    ]

    node.children = comments + statements


# Generated at 2022-06-24 07:55:58.879809
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from jedi.api import classes

    # Test for type string
    completion_name = "thonny_completion_test_name"
    completion_complete = "thonny_completion_test_complete"
    completion_type = "thonny_completion_test_type"
    completion_description = "thonny_completion_test_description"
    completion_parent = classes.CallSignature()
    completion_full_name = "thonny_completion_test_full_name"
    thonny_completion = ThonnyCompletion(
        name = completion_name,
        complete = completion_complete,
        type = completion_type,
        description = completion_description,
        parent = completion_parent,
        full_name = completion_full_name,
    )
    assert completion_name == th

# Generated at 2022-06-24 07:56:07.827860
# Unit test for function get_definitions
def test_get_definitions():
    stdlib_path = r'C:\Python34\lib'
    filename = r'test.py'
    source = r'import os\ndef test(): pass\nclass Test: pass'
    row = 1

    def check(column, expected_name):
        definitions = get_definitions(source, row, column, filename)
        if len(definitions) == 0:
            print('No definitions found')
            return False
        elif len(definitions) > 1:
            print(len(definitions), 'definitions found')
            return False
        else:
            if definitions[0].name == expected_name:
                return True
            else:
                print(definitions[0].name, 'instead of', expected_name)
                return False

    def check_module(column, expected_description):
        definitions = get_

# Generated at 2022-06-24 07:56:14.847942
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"



# Generated at 2022-06-24 07:56:25.490416
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock as mock
    import pytest
    import sys
    import re

    @mock.patch("jedi.Script")
    def test(fake_script):
        get_definitions("", 0, 0, "")
        assert fake_script.call_count == 1
        for call_args in fake_script.call_args_list:
            # jedi.Script("", 0, 0, "")
            assert len(call_args) == 1
            assert len(call_args[0]) == 4
            assert fake_script.call_args[0][0] == ""
            assert fake_script.call_args[0][1] == 0
            assert fake_script.call_args[0][2] == 0
            assert fake_script.call_args[0][3] == ""
            # j

# Generated at 2022-06-24 07:56:27.944728
# Unit test for function parse_source
def test_parse_source():
    import parso.python as python

    code = """str = 'Test'\nstr.r"""
    tree = parse_source(code)
    assert(isinstance(tree, python.Module))

# Generated at 2022-06-24 07:56:33.757086
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # test jedi older than 0.18
    if _using_older_jedi(__import__("jedi")):
        completions = get_interpreter_completions(
            "import sys\nsys", [{"__name__": "__main__", "__builtins__": __builtins__}]
        )
        assert completions
    # test jedi 0.18
    else:
        completions = get_interpreter_completions(
            "from math import sqrt\nsqrt",
            [{"__name__": "__main__", "__builtins__": __builtins__}],
        )
        assert completions

# Generated at 2022-06-24 07:56:37.373827
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    namespace = [{'a': Mock(spec=['b', 'c', 'd'])}]
    print(get_interpreter_completions('a.b.', namespace))

# Generated at 2022-06-24 07:56:43.411560
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "import math\nt = lambda: 1"
    parsed = parse_source(source)

    assert isinstance(parsed, parso.python.tree.Module)
    assert parsed.type == "module"

    lines = parsed.get_code().split("\n")
    assert lines[0] == "import math"
    assert lines[1] == "t = lambda: 1"


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:56:53.354076
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from os.path import join

    from parso.python import tree

    from thonny import get_workbench

    get_workbench().set_option("run.hide_internal_frames", False)
    get_workbench().set_option("run.show_cell_source_code", True)

    filename = join(get_workbench().get_package_dir("thonny"), "thonny", "backend.py")
    parser = parse_source(open(filename).read())
    node = get_statement_of_position(parser, (19, 6))
    assert isinstance(node, tree.Flow)
    node = get_statement_of_position(parser, (18, 17))
    assert isinstance(node, tree.ExprStmt)

# Generated at 2022-06-24 07:57:00.114221
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:11.206661
# Unit test for function get_interpreter_completions

# Generated at 2022-06-24 07:57:18.158471
# Unit test for function get_script_completions
def test_get_script_completions():
    """test for line 11"""

# Generated at 2022-06-24 07:57:21.359416
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name = "sys.exit", complete = "sys.exit", type = "module", description = "sys module", parent = "sys", full_name = "sys.exit")
    assert completion["name"] == "sys.exit"
    assert completion["complete"] == "sys.exit"
    assert completion["type"] == "module"
    assert completion["description"] == "sys module"
    assert completion["parent"] == "sys"
    assert completion["full_name"] == "sys.exit"


# Generated at 2022-06-24 07:57:23.230488
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("import os", 0, 8, "")
    assert len(completions) > 0



# Generated at 2022-06-24 07:57:25.501492
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('x = 1\na = x + 1').children[0].children[1].value == '= 1'


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:57:29.110540
# Unit test for function get_script_completions
def test_get_script_completions():
    s = "from math import "
    completions = get_script_completions(s, 1, 17, "foo.py")
    assert len(completions) > 0
    assert "sqrt" in [c["complete"] for c in completions]

# Generated at 2022-06-24 07:57:36.604745
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    
    node = tree.Module()
    line = tree.PythonNode(type="line")
    node.children.append(line)
    line.start_pos = (1, 0)
    line.end_pos = (1, 4)
    
    assert get_statement_of_position(node, (1, 2)) == line
    assert get_statement_of_position(node, (1, 100)) == line
    assert get_statement_of_position(node, (2, 2)) is None

# Generated at 2022-06-24 07:57:40.695380
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    def f():
        pass

    completion = ThonnyCompletion(
        name="func-name", complete="func", type="function", description=f, parent=None, full_name="func-name"
    )
    if jedi.__version__ < "0.17.0":
        assert "func" == completion["complete"]
    else:
        assert "func()" == completion["complete"]

# Generated at 2022-06-24 07:57:46.857489
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    source = """def f(x, y):
    return x + y
"""
    parsed = parse_source(source)
    def_node = parsed.children[0]

    assert isinstance(get_statement_of_position(def_node, (len(source) + 10)*(10**4)), tree.ExprStmt)


# Generated at 2022-06-24 07:57:58.723889
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    import os

    jedi_path = jedi.__file__
    if jedi_path.endswith("pyc"):
        jedi_path = jedi_path[:-1]
    jedi_path = os.path.dirname(jedi_path)
    source = "def f(x):\n    return x\n" + \
             "return f()\n"
    my_dir = os.path.dirname(__file__)
    with open(os.path.join(my_dir, "data", "sample.py")) as fp:
        source = fp.read()
    tree = jedi.Script(source, 1, 0, "sample.py")._module

    # Test parent-child relationships (together with parse_source)
    last_pos = 0
   

# Generated at 2022-06-24 07:58:02.099022
# Unit test for function get_definitions
def test_get_definitions():
    source = """
import sys
sys.getdefaultencoding()
    """
    row = 4
    column = 6
    filename = "test.py"
    definitions = get_definitions(source, row, column, filename)
    assert len(definitions) == 1

# Generated at 2022-06-24 07:58:03.794758
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = '''import sys'''
    assert isinstance(parse_source(source), parso.python.tree.Module)

# Generated at 2022-06-24 07:58:12.934166
# Unit test for function get_definitions
def test_get_definitions():
    from test.jedi_utils_test import check_results_as_expected

    def test_get_definitions(input_str, expected):
        actual = get_definitions(input_str, 1, 1, "t.py")
        check_results_as_expected(actual, expected)

    test_get_definitions(
        """class Foo:
                def __init__(self):
                    self.x = 1""",
        [("1", "x<1>", "int", ".x")],
    )

    test_get_definitions("""PYTHON_VERSION = sys.version_info[0]""", [("0", "version_info", "()", "")])



# Generated at 2022-06-24 07:58:16.914756
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils

    get_statement_of_position_alt = get_statement_of_position
    get_statement_of_position = getattr(
        jedi.parser_utils, "get_statement_of_position", get_statement_of_position_alt
    )


# Generated at 2022-06-24 07:58:25.313003
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import __main__

    import jedi

    if _using_older_jedi(jedi):
        completion = jedi.Script(source="import", line=1, column=7).completions()[0]
    else:
        completion = jedi.Script(code="import", path="").complete(line=1, column=7)[0]
    thonny_completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

    assert thonny_completion.name == "import"
    assert thonny_completion.complete == "import"
    assert thonny

# Generated at 2022-06-24 07:58:35.274296
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi

    source = """
        x = 5

        def f():
            a = 1
            b = 2
            c = 3

            if True:
                print(x)
        """

    completions = get_script_completions(source, 1, 1, "test.py")

    def_node = completions[0].parent.parent
    dummy_node = completions[0].parent

    pos_range = (def_node.start_pos[1] - 1, dummy_node.end_pos[1])

    node = get_statement_of_position(source, pos_range)

    assert isinstance(node, jedi.api_classes.Statement)
    assert node.start_pos[1] == def_node.start_pos[1]
    assert node.end_pos[1] == dummy_

# Generated at 2022-06-24 07:58:40.120534
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_object = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_object.name == "name"
    assert test_object.complete == "complete"
    assert test_object.type == "type"
    assert test_object.description == "description"
    assert test_object.parent == "parent"
    assert test_object.full_name == "full_name"

# Generated at 2022-06-24 07:58:45.837295
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi import Script

    script = Script("")
    source = """
a = 1
a = 'two'
a = """
    three

    four
    """
    a = [1, 2, 3]
    a = [
        1,
        2,
        3,
    ]
    print(a)
    """

    def get_node(node_type, line, name=None):
        nodes = [node for node in script._parse_module().iter_subchildren() if node.type == node_type]
        assert len(nodes) == 1
        node = nodes[0]
        assert node.start_pos[0] == line
        if name is not None:
            assert node.name == name
        return node


# Generated at 2022-06-24 07:58:49.066876
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    x = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert x.__getitem__('name') == 'name'


# Generated at 2022-06-24 07:58:56.253637
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    jedi.settings.case_insensitive_completion = True

    def assert_completions(source, expected_completions, row=None, column=None):
        completions = get_script_completions(
            source, row or len(source.splitlines()), column or len(source.splitlines()[-1]), "hello.py"
        )
        # print(completions)
        for completion in completions:
            print(completion.complete)
        assert [completion.complete for completion in completions] == expected_completions

    assert_completions("", [], 0, 0)
    assert_completions("", [], 0, 1)
    assert_completions("", [], 1, 0)
    assert_completions("", [], 1, 1)

# Generated at 2022-06-24 07:59:02.692959
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from thonny.plugins.completion.fake_jedi import ThonnyCompletion

    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"



# Generated at 2022-06-24 07:59:09.652107
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import unittest
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == tc.__dict__["name"]
    assert tc["complete"] == tc.__dict__["complete"]
    assert tc["type"] == tc.__dict__["type"]
    assert tc["description"] == tc.__dict__["description"]
    assert tc["parent"] == tc.__dict__["parent"]
    assert tc["full_name"] == tc.__dict__["full_name"]
    tc = ThonnyCompletion(1, 2, 3, 4, 5, 6)
    assert tc["name"] == tc.__dict__["name"]
    assert tc["complete"] == tc.__dict__["complete"]
    assert tc["type"] == tc.__

# Generated at 2022-06-24 07:59:11.408430
# Unit test for function get_definitions
def test_get_definitions():
    import jedi.api
    import jedi.parser_utils
    import parso.python
    import jedi.parser


# Generated at 2022-06-24 07:59:18.271264
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    values = ["name", "complete", "type", "description", "parent", "full_name"]
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    for i in range(len(values)):
        assert completion[values[i]] == values[i]

# equivalent of jedi.parser_utils.get_parent_scope in <2018.2.1

# Generated at 2022-06-24 07:59:21.138412
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion('a','b','c','d','e','f')
    a = tc.name
    b = tc['name']
    if a == b:
        print('ok')
    else:
        print('nok')

# Generated at 2022-06-24 07:59:27.806602
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from jedi.api.refactoring import inline
    from jedi.api.project import Project
    from jedi.api.interpreter import Interpreter
    from jedi.api.environment import get_system_environment

    env = get_system_environment()
    interp = Interpreter(env, [])
    script = jedi.Script("import os",1,1, "test.py", project=Project(env.path[0], [env.path[0]]))
    # o=os.listdir()
    script.complete()
    inline(script,(2,9), "os", [])
    script.names()
    # script.get_refactoring_script().get_in_function_call().get_param_index(1,1)

    # script.completions()


# Generated at 2022-06-24 07:59:37.912701
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import Interpreter

    sources = [
        "import re",
        "re.compile",
        "str.format",
        "int.bit_length",
        "str.format(3, 4, 5)",
        "str.format(",
        "int.bit_length(3)",
        "int.bit_length(3, 4)",
        "int.bit_length(",
        "int.bit_length(3, 4, 5)",
        "import re.compile",
    ]

# Generated at 2022-06-24 07:59:48.195382
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    if _using_older_jedi(jedi):
        script = jedi.Script('str.low', 0, 6, '')
    else:
        script = jedi.Script('str.low', path='')
    completions = script.completions()
    jedi_completion = completions[0]
    complete_name = jedi_completion.complete
    complete = ThonnyCompletion(jedi_completion.name, complete_name, jedi_completion.type,
                                jedi_completion.description, jedi_completion.parent,
                                jedi_completion.full_name)
    assert complete.name == complete_name
    assert complete.complete == complete_name
    assert complete.type == jedi_completion.type
    assert complete.description == j

# Generated at 2022-06-24 07:59:52.901584
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(
        "test", "test", "test", "test", "test", "test"
    ).__dict__ == {"name": "test", "complete": "test",
                   "type": "test", "description": "test",
                   "parent": "test", "full_name": "test"}

# Generated at 2022-06-24 08:00:01.255353
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import Script
    from parso.python.tree import Name
    source = "int(x, b=0)"
    row = 1
    column = 6
    script = Script(source, row, column)
    complet = script.complete()
    comp = complet[0]
    name = Name(comp.full_name, comp.start_pos)
    desc = "int(x, base=10) -- convert a number in a string to an integer, if possible"
    thonnycomp = ThonnyCompletion(name.value, comp.complete, comp.type, desc, name.parent, comp.full_name)
    assert thonnycomp.name == name.value
    assert thonnycomp.complete == comp.complete
    assert thonnycomp.type == comp.type

# Generated at 2022-06-24 08:00:11.053564
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    source = """
import os
os.chdir()
"""

    defs = get_definitions(source, 3, 5, None)
    assert len(defs) == 1
    assert defs[0].type == "function"
    assert defs[0].description == "os.chdir(path)"
    assert defs[0].parent.name == "os"
    assert defs[0].parent.type == "module"
    assert defs[0].parent.full_name == "os"
    assert defs[0].full_name == "os.chdir"

    # test for class

# Generated at 2022-06-24 08:00:17.989507
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "str."
    namespaces = [{}]
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) > 10
    assert completions[0]["type"] == "instance"
    assert "lower" in [c["name"] for c in completions]


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 08:00:25.538064
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse

    def get_positions(code):
        node = parse(code)
        return [
            get_statement_of_position(node, pos)
            for pos in (len(line) + 1 for line in code.strip().split("\n"))
        ]

    assert get_positions("a = 1\n") == [parse("a = 1").children[0]]
    assert get_positions("a = 1\na = 2\n") == [
        parse("a = 1").children[0],
        parse("a = 2").children[0],
    ]
    assert get_positions("a = 1\nb = 2\n") == [
        parse("a = 1").children[0],
        parse("b = 2").children[0],
    ]

# Generated at 2022-06-24 08:00:35.443260
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    script = Script('import sys\nsys.vers', 2, len('sys.vers'))
    # script = Script('')
    # completions = script.get_completions()
    completions = get_script_completions('import sys\nsys.vers', 2, len('sys.vers'), "")
    print(completions)

    script = Script('import sys\nsys.v', 2, len('sys.v'))
    # script = Script('')
    # completions = script.get_completions()
    completions = get_script_completions('import sys\nsys.v', 2, len('sys.v'), "")
    print(completions)


# Generated at 2022-06-24 08:00:39.329868
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # This function is a copy-paste of jedi's function with the same name,
    # so unit tests are also copy-pasted
    from parso import parse
    from parso.python.tree import Leaf, Node


# Generated at 2022-06-24 08:00:49.314117
# Unit test for function get_definitions
def test_get_definitions():

    def _test(source, row, column, expected_type, expected_complete, expected_name):
        result = get_definitions(source, row, column, "")
        if not result:
            raise AssertionError("Expecting result for " + source)
        if len(result) > 1:
            raise AssertionError("Expecting only one result for " + source)

        result = result[0]

        assert result.type == expected_type, source
        assert result.complete == expected_complete, source
        assert result.name == expected_name, source

    _test("spam(", 5, 0, "function", "spam", "spam")
    _test("foo.bar(", 8, 0, "function", "foo.bar", "bar")

# Generated at 2022-06-24 08:00:58.772211
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    completions = get_interpreter_completions("'he'", [], sys_path=[])
    assert len(completions) > 10
    assert any(c.name == "upper" for c in completions)

    completions = get_interpreter_completions("'he'.up", [], sys_path=[])
    assert len(completions) > 10
    assert any(c.name == "upper" for c in completions)

    completions = get_interpreter_completions("'he'.upper", [], sys_path=[])
    assert len(completions) > 10
    assert any(c.name == "upper" for c in completions)

    completions = get_interpreter_completions("'he'.upper().", [], sys_path=[])