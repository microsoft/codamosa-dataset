

# Generated at 2022-06-24 07:51:26.777103
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    t=ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert t['name'] == 'name'
    assert t['complete'] == 'complete'
    assert t['type'] == 'type'
    assert t['description'] == 'description'
    assert t['parent'] == 'parent'
    assert t['full_name'] == 'full_name'

# Generated at 2022-06-24 07:51:27.339508
# Unit test for function get_definitions

# Generated at 2022-06-24 07:51:29.201261
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if hasattr(jedi.Script, "completions"):
        return True
    else:
        return False



# Generated at 2022-06-24 07:51:34.261025
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
    def test_func(arg1, arg2):
        '''extended documentation'''
        return arg1 + arg2

    test_fu"""
    completions = get_interpreter_completions(source, [{}])
    assert completions[0].name == "test_func"
    assert completions[0].complete == "test_func("
    assert completions[0].description == "extended documentation"
    assert completions[0].parent == "def"
    assert completions[0].full_name == "test_func"

# Generated at 2022-06-24 07:51:37.774683
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase
    from test.cpython_test.test_jedi import check_get_definitions

    check_get_definitions(self=TestCase(), func=get_definitions)

# Generated at 2022-06-24 07:51:44.672474
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    tc = ThonnyCompletion(
        name="if", complete="if", type="keyword", description="", parent=[], full_name=""
    )
    return jedi.Script("if", 1, 1).completions()[0] == tc

# Generated at 2022-06-24 07:51:51.879008
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    complete = "testcomplete"
    type = "testtype"
    description = "testdescription"
    parent = "testparent"
    full_name = "testname"
    assert "testcomplete" == ThonnyCompletion(complete, complete, type, description, parent, full_name).complete
    assert "testname" == ThonnyCompletion(complete, complete, type, description, parent, full_name).name
    assert "testtype" == ThonnyCompletion(complete, complete, type, description, parent, full_name).type
    assert "testdescription" == ThonnyCompletion(complete, complete, type, description, parent, full_name).description
    assert "testparent" == ThonnyCompletion(complete, complete, type, description, parent, full_name).parent
    assert "testname" == ThonnyCompletion

# Generated at 2022-06-24 07:51:55.524453
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    a = ThonnyCompletion('name', 'complete', 'type', 'desc', 'parent', 'full_name')

    assert a.name == 'name'
    assert a.complete == 'complete'
    assert a.type == 'type'
    assert a.description == 'desc'
    assert a.parent == 'parent'
    assert a.full_name == 'full_name'

# Generated at 2022-06-24 07:52:02.613563
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        src_0 = [{"a": 1}]
        src = """def g():
    pass

a.b"""
        completions = get_interpreter_completions(src, src_0)
        assert len(completions) > 0
        assert completions[0].name == "b"
        assert completions[0].complete == "b"

        src_1 = [{"a": 1, "b": 2}]
        src = """def g():
    pass

a.b.c"""
        completions = get_interpreter_completions(src, src_1)
        assert len(completions) == 0
    else:
        src_0 = [{"a": 1}]

# Generated at 2022-06-24 07:52:12.691133
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonny_completion.__getitem__("name") == "name", "Unexpected result for key 'name'"
    assert thonny_completion.__getitem__("complete") == "complete", "Unexpected result for key 'complete'"
    assert thonny_completion.__getitem__("type") == "type", "Unexpected result for key 'type'"
    assert thonny_completion.__getitem__("description") == "description", "Unexpected result for key 'description'"
    assert thonny_completion.__getitem__("parent") == "parent", "Unexpected result for key 'parent'"

# Generated at 2022-06-24 07:52:18.339145
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _jedi_utils import get_interpreter_completions
    source = "f"

# Generated at 2022-06-24 07:52:24.245054
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils
    import textwrap

    source = textwrap.dedent(
"""\
    def f():
        pass
    class C:
        pass
    from math import *
    """
)

    node = parso.parse(source)
    for i in range(len(source)):
        statement = get_statement_of_position(node, i)
        assert statement.get_code() + "\n" == jedi.parser_utils.get_statement_of_position(
            node, i
        ).get_code() + "\n"

# Generated at 2022-06-24 07:52:29.185141
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    sys.path.append(".")

    complete = get_interpreter_completions("import sys,os;sys.p", [], sys.path)
    assert len(complete) >= 1


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 07:52:38.502233
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    t1 = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    if not isinstance(t1, jedi.api.classes.Completion):
        raise AssertionError("ThonnyCompletion is not an instance of Completion")
    a = t1.name
    b = t1.complete
    c = t1.type
    d = t1.description
    e = t1.parent
    f = t1.full_name
    assert a == "a"
    assert b == "b"
    assert c == "c"
    assert d == "d"
    assert e == "e"
    assert f == "f"

# Generated at 2022-06-24 07:52:46.731343
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_complete = "str"
    test_name = "str"
    test_type = "type"
    test_description = "str"
    test_parent = ""
    test_full_name = "str"

    completion = ThonnyCompletion(
        name=test_name,
        complete=test_complete,
        type=test_type,
        description=test_description,
        parent=test_parent,
        full_name=test_full_name,
    )

    assert completion.__getitem__("name") == test_name
    assert completion.__getitem__("complete") == test_complete
    assert completion.__getitem__("type") == test_type
    assert completion.__getitem__("description") == test_description
    assert completion.__getitem__("parent") == test_parent


# Generated at 2022-06-24 07:52:51.698121
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.jedi_utils import get_definitions
    from parso.python.tree import Operator

    source = 'x = 0\nx + 1\n'
    locations = [get_definitions(source, 1, 1, '')[0].line, get_definitions(source, 2, 5, '')[0].line]

    assert locations == [1, 2]

# Generated at 2022-06-24 07:52:56.568268
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    keys = ["name", "complete", "type", "description", "parent", "full_name"]
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )

    for key in keys:
        assert completion[key] == getattr(completion, key)

# Generated at 2022-06-24 07:53:03.347218
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    try:
        # Python 3
        import builtins
    except ImportError:
        # Python 2
        import __builtin__ as builtins

    namespaces = [{"builtins": vars(builtins)}, {"thonny": vars(builtins)}]
    completions = get_interpreter_completions("abs(", namespaces=namespaces)
    assert "abs(" in [c.name for c in completions]
    assert "abs(" in [c.complete for c in completions]

# Generated at 2022-06-24 07:53:08.760446
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="name", complete="complete",
                                  type="type", description="description",
                                  parent="parent", full_name="full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:53:16.076095
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        sys_path = []
        completions = get_interpreter_completions("import datetime", [], sys_path)
        assert len(completions) == 1
        completion = completions[0]
        assert completion.complete == "datetime"
    else:
        sys_path = []
        completions = get_interpreter_completions("import datetime", [], sys_path)
        assert len(completions) == 1
        completion = completions[0]
        assert completion.complete == "datetime"



# Generated at 2022-06-24 07:53:17.282280
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("1 + 2")



# Generated at 2022-06-24 07:53:18.171123
# Unit test for function get_definitions
def test_get_definitions():
    import jedi


# Generated at 2022-06-24 07:53:24.585956
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    # TODO: create and use test_utils
    def create_node(type, children, start_pos=(1, 1), end_pos=None):
        node = tree.Node(type, [], start_pos)
        node.children = children
        if end_pos:
            node.end_pos = end_pos
        else:
            node.end_pos = (max(c.end_pos[0] for c in children), max(c.end_pos[1] for c in children))
        return node

    source = """def foo():
    pass"""
    node = parse_source(source)
    assert get_statement_of_position(node, (2, 1)) is None
    assert get_statement_of_position(node, (2, 3)) is None
    assert get

# Generated at 2022-06-24 07:53:29.368772
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion('b', 'a', 'c', 'd', 'e', 'f')
    # Test if method __getitem__ is implemented
    try:
        result = thonny_completion['name']
        assert result == 'b'
    except:
        raise AssertionError("Class ThonnyCompletion doesn't implement method __getitem__")

# Generated at 2022-06-24 07:53:32.086538
# Unit test for function get_script_completions
def test_get_script_completions():
    result = get_script_completions("impor", 0, 5, "sample_filename.py")
    assert len(result) == 2
    assert result[0].name == "import"
    assert result[1].name == "__import__"
    # TODO: add more?

# Generated at 2022-06-24 07:53:34.104953
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import math; math.pi", 1, 9, "", [])

# Generated at 2022-06-24 07:53:43.430987
# Unit test for function get_definitions
def test_get_definitions():
    """
    Tests the function get_definitions for a very simple case.
    """
    import jedi

    source = "class MyClass:\n" "    def __init__(self):"
    definitions = get_definitions(source, 1, 16, "")
    assert len(definitions) == 1
    assert definitions[0].description == "class MyClass"
    assert definitions[0].module_path == "builtins"
    assert definitions[0].line == 0
    assert definitions[0].column == 0
    definitions = get_definitions(source, 1, 21, "")
    assert len(definitions) == 1
    assert definitions[0].description == "def __init__(self)"
    assert definitions[0].module_path == "builtins"
    assert definitions[0].line == 0
    assert definitions[0].column

# Generated at 2022-06-24 07:53:49.615560
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    someString = "the name"
    someString += "="
    someOtherString = "the name="

    completion = Completion(
        name=someString, complete=someOtherString, type=None, description=None, parent=None, full_name=None
    )

    assert completion.name == someString, f"Name should be {someString}"
    assert completion.complete == someOtherString, f"Complete should be {someOtherString}"

# Generated at 2022-06-24 07:53:51.913644
# Unit test for function get_script_completions
def test_get_script_completions():
    assert (
        get_script_completions(source="", row=0, column=0, filename="") is not None
    ), "Script should get completions for empty line"

# Generated at 2022-06-24 07:53:57.054331
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    jedi.settings.additional_dynamic_modules = ["numpy"]
    jedi.settings.case_insensitive_completion = True
    jedi.settings.no_completion_duplicates = True
    jedi.settings.use_deprecated_function_signatures = False
    #jedi.settings.fast_completion = False


# Generated at 2022-06-24 07:54:06.076909
# Unit test for function parse_source
def test_parse_source():
    from jedi.parser_utils import parse_source
    from parso import parse
    import parso

    module_node = parse("""import sys as sys1;
sys1.stdin.encoding
sys1.stdin.read()
"""
    )
    line = 3
    column = 5

    # line 3
    assert parse_source(module_node, line, column).get_code() == "read()"

    # line 1
    assert parse_source(module_node, 1, 5) is module_node

    # wrong line
    line = 4
    assert parse_source(module_node, line, column) is None

if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:54:16.642863
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    source = 'import sys\nsys.'
    namespaces = [{'sys': sys}]

    load_completions = get_interpreter_completions(source, namespaces)
    assert len(load_completions) > 0

    if _using_older_jedi(jedi):
        # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
        # since 0.16 it does. Check that our _tweak_completions function works as intended
        no_assignment_sign_present = True
        for completion in load_completions:
            if completion['name'] == 'argv=':
                no_assignment_sign_present = False

        assert no_assignment_sign_present

# Generated at 2022-06-24 07:54:22.810547
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase, mock

    def fake_script(source, row, column, filename, sys_path=None):
        if source != "abc":
            raise Exception("Incorrect source")
        if row != 1:
            raise Exception("Incorrect row")
        if column != 2:
            raise Exception("Incorrect column")
        if filename != "test.py":
            raise Exception("Incorrect filename")
        return mock.MagicMock()

    def fake_new_script(source, path):
        if source != "abc":
            raise Exception("Incorrect source")
        if path != "test.py":
            raise Exception("Incorrect path")
        return mock.MagicMock()


# Generated at 2022-06-24 07:54:23.752180
# Unit test for function parse_source
def test_parse_source():
    assert (parse_source("print()"))

# Generated at 2022-06-24 07:54:33.425865
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(name="name",complete="complete",type="type", description="description", parent="parent", full_name="full_name")["name"] == "name"
    assert ThonnyCompletion(name="name",complete="complete",type="type", description="description", parent="parent", full_name="full_name")["complete"] == "complete"
    assert ThonnyCompletion(name="name",complete="complete",type="type", description="description", parent="parent", full_name="full_name")["type"] == "type"
    assert ThonnyCompletion(name="name",complete="complete",type="type", description="description", parent="parent", full_name="full_name")["description"] == "description"

# Generated at 2022-06-24 07:54:38.481252
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert t['name'] == "name"
    assert t['complete'] == "complete"
    assert t['type'] == "type"
    assert t['description'] == "description"
    assert t['parent'] == "parent"
    assert t['full_name'] == "full_name"

# Generated at 2022-06-24 07:54:39.035384
# Unit test for function parse_source

# Generated at 2022-06-24 07:54:46.497849
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock

    # Simulate old jedi (up to 0.17) which delivers completions with name like
    # "func_name=" and not "func_name"
    old_completion = MagicMock()
    old_completion.name = "func_name="
    old_completion.complete = "func_name"
    old_completion.type = "function"
    old_completion.description = "func_desc"
    old_completion.parent = "module_name"
    old_completion.full_name = "module_name.func_name"

    # Simulate new jedi (0.18+) which delivers completions with name like
    # "func_name" and not "func_name="
    new_completion = MagicMock()
    new_com

# Generated at 2022-06-24 07:54:48.944790
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    result = parse_source("print('Hello')")
    assert isinstance(result, tree.Module)
    assert len(result.children) == 1
    assert isinstance(result.children[0], tree.ExprStmt)
    assert isinstance(result.children[0].children[0], tree.Call)



# Generated at 2022-06-24 07:55:00.055437
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    jediCompletion = jedi.api.classes.Completion("name", "complete", "type", "description", "parent", "full_name")
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert(jediCompletion.name == thonnyCompletion.name)
    assert(jediCompletion.complete == thonnyCompletion.complete)
    assert(jediCompletion.type == thonnyCompletion.type)
    assert(jediCompletion.description == thonnyCompletion.description)
    assert(jediCompletion.parent == thonnyCompletion.parent)
    assert(jediCompletion.full_name == thonnyCompletion.full_name)

# Generated at 2022-06-24 07:55:06.952644
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(name="name", complete="complete", type="type",
                                         description="description", parent="parent",
                                         full_name="full_name")
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"
    try:
        assert thonny_completion["wrong_keyword"]
        raise ValueError("KeyError expected but not thrown")
    except KeyError:
        pass


# Generated at 2022-06-24 07:55:14.908896
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from test.test_jedi import fix_for_differences_in_jedi

    source = "import sys\n" "sys."
    row = 2
    column = 5
    filename = "test"
    completions = get_script_completions(source, row, column, filename)
    jedi_completions = jedi.Script(source, row, column, filename).completions()
    assert completions == fix_for_differences_in_jedi(jedi_completions)

    source = "import sys\ndef f():\n   sys."
    row = 3
    column = 8
    filename = "test"
    completions = get_script_completions(source, row, column, filename)

# Generated at 2022-06-24 07:55:17.154357
# Unit test for function parse_source
def test_parse_source():
    try:
        from parso.python import tree
    except:
        return

# Generated at 2022-06-24 07:55:19.322503
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc["name"] == "name"



# Generated at 2022-06-24 07:55:21.956949
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert isinstance(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name"), ThonnyCompletion)
    return True


# Generated at 2022-06-24 07:55:27.883962
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert test_complete.__getitem__("name") == "name"
    assert test_complete.__getitem__("complete") == "complete"
    assert test_complete.__getitem__("type") == "type"
    assert test_complete.__getitem__("description") == "description"
    assert test_complete.__getitem__("parent") == "parent"
    assert test_complete.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:55:31.517483
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import sys\n" "sys.std"
    s = get_script_completions(source, 2, 7, "testfile.py")
    assert len(s) > 0
    assert s[0].name == "stdin"



# Generated at 2022-06-24 07:55:36.256136
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    list_of_keys = ['name', 'complete', 'type', 'description', 'parent', 'full_name']
    thonny_compl = ThonnyCompletion('name_test', 'complete_test',
            'type_test', 'description_test', 'parent_test', 'full_name_test')
    for keys in list_of_keys:
        assert thonny_compl.__getitem__(keys) == getattr(thonny_compl, keys)


# Generated at 2022-06-24 07:55:42.835979
# Unit test for function get_definitions
def test_get_definitions():
    from test.test_util import load_test_script
    from jedi import __version__

    logger.info("test_get_definitions for Jedi " + __version__)

    for test_script in load_test_script():
        logger.info("About to test " + test_script)
        test_tuple = test_script.split("|")
        source = test_tuple[0].strip()
        row = int(test_tuple[1].strip())
        column = int(test_tuple[2].strip())
        definition_names = test_tuple[3].strip().replace(" ", "").split(",")

        definitions = get_definitions(source, row, column, "dummy.py")
        definitions = [d.full_name for d in definitions]

# Generated at 2022-06-24 07:55:44.504197
# Unit test for function get_script_completions
def test_get_script_completions():
    for x in range(5):
        print(x)

# Generated at 2022-06-24 07:55:55.002334
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    source = """#hello
    a = 1 + """
    source2 = """
    something longer that should not be touched """
    source3 = """x = 10"""
    source4 = """
    if 12 > 10:
        pass
    """

    node = parse_source(source + source2 + source3 + source4)
    node.start_pos = 0

    def check(node, children):
        for child in children:
            assert child in node.children

    check(node, [node.children[0], node.children[1], node.children[2]])

    stmt = get_statement_of_position(node, len(source) + 1)
    check(stmt, [stmt.children[0], stmt.children[1], stmt.children[2]])

   

# Generated at 2022-06-24 07:56:04.300677
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree
    from thonny.jedi_utils import get_interpreter_completions
    import parso

    source = "import pathlib\n"
    node = parso.parse(source)
    module = node.get_root_node()

# Generated at 2022-06-24 07:56:12.773238
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions(
        "import urllib.request\nurllib.request.",
        [],
        sys_path=["/Library/Frameworks/Python.framework/Versions/3.6/lib/"],
    )

    assert len(result) >= 11
    assert any(
        [
            completion.complete == "urllib.request.urlopen"
            for completion in result
            if completion.type == "function"
        ]
    )
    assert any(
        [
            completion.complete == "urllib.request.Request"
            for completion in result
            if completion.type == "class"
        ]
    )

# Generated at 2022-06-24 07:56:21.510238
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import json\njson."
    namespaces = [{"json": {"k1": "v1", "k2": "v2"}}]

    completions = get_interpreter_completions(source, namespaces)

    assert len(completions) == 2
    assert completions[0].name == "k1"
    assert completions[0].type == "str"
    assert completions[1].name == "k2"
    assert completions[1].type == "str"


# Generated at 2022-06-24 07:56:30.041294
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """Ensure output of the function is consistent with other completions."""
    from jedi.parser.python import tree
    from jedi import Interpreter
    from collections import namedtuple
    from thonny.ast_utils import get_namespace_dict, get_position_tuple
    from thonny.jedi_utils import get_interpreter_completions
    def local_evaluation(source, line, column, namespaces):
        interpreter = Interpreter(source, namespaces)
        return interpreter.complete(line, column)

    completions = namedtuple('complete', 'name type description parent')
    # [0]name = name
    # [1]complete = complete
    # [2]type = type
    # [3]description = description
    # [4]parent = parent
    Namespace = namedt

# Generated at 2022-06-24 07:56:32.520332
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:56:40.908518
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(
        name = "a",
        complete = "a",
        type = "a",
        description = "a",
        parent = "a",
        full_name = "a",
    )
    assert thonny_completion["name"] == "a"
    assert thonny_completion["complete"] == "a"
    assert thonny_completion["type"] == "a"
    assert thonny_completion["description"] == "a"
    assert thonny_completion["parent"] == "a"
    assert thonny_completion["full_name"] == "a"

# Generated at 2022-06-24 07:56:42.996160
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module

    ast = parse_source("a = 2\nb = 2")
    assert isinstance(ast, Module)

# Generated at 2022-06-24 07:56:53.022905
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    _get_new_jedi_project = mock.MagicMock()
    from jedi.api.interpreter import Interpreter

    Interpreter.complete = mock.MagicMock(return_value=["a", "b"])

    result = get_interpreter_completions("import math", [], [])
    assert result == ["a", "b"]
    Interpreter.assert_called_with("import math", [])

    result = get_interpreter_completions("import math", [], ["syspath_1", "syspath_2"])
    assert result == ["a", "b"]
    Interpreter.assert_called_with("import math", [], sys_path=["syspath_1", "syspath_2"])

    _get_new_j

# Generated at 2022-06-24 07:56:59.319898
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
a=3
print(a.bit_le,a.denominator)
"""
    completions = get_interpreter_completions(source, [{}, {"a": 3}])
    assert len(completions) == 2
    assert completions[0].name == "bit_length"
    assert completions[0].complete == "bit_length("
    assert completions[1].name == "denominator"
    assert completions[1].complete == "denominator"

# Generated at 2022-06-24 07:57:06.096715
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    try:
        import parso
    except ImportError:
        pass
    import tempfile
    import os
    import sys

    # create a temporary file
    test_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", dir=None, delete=False
    )
    # fill it with Python code
    test_file.write("""
    def func():
        a = 1
        b = 2
        c = 3
    """)
    test_file.close()

    # compute error position
    parser = parso.parse(open(test_file.name).read())

    line = 1
    column = 12

    if sys.version_info[0] >= 3:
        node = get_statement_of_position(parser, (line, column))

# Generated at 2022-06-24 07:57:09.345364
# Unit test for function parse_source
def test_parse_source():
    import parso.python

    source = """import sys"""
    node = parse_source(source)
    assert isinstance(node, parso.python.tree.Module)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:57:14.193564
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions(
        """x = "hello"
y = x.upper()
""",
        0,
        0,
        "test.py",
    ) == get_definitions(
        """x = "hello"
y = x.upper()
""",
        2,
        6,
        "test.py",
    )

# Generated at 2022-06-24 07:57:25.226927
# Unit test for function get_script_completions
def test_get_script_completions():

    def run_completion_test(text, expected_completions):
        completions = get_script_completions(
            text, text.index("|") + 1, 0, filename="test.py"
        )
        assert [c.complete for c in completions] == expected_completions

    run_completion_test("[1,2,3].ind|", ['index(', 'index'])
    run_completion_test("[1,2,3].ind|x", ['index(', 'index'])
    run_completion_test("l = [1,2,3]; l.ind|x", ['index(', 'index'])
    run_completion_test("l = [1,2,3]; l.ind|x", ['index(', 'index'])
    run_completion_

# Generated at 2022-06-24 07:57:26.155749
# Unit test for function get_definitions

# Generated at 2022-06-24 07:57:36.902151
# Unit test for function get_script_completions
def test_get_script_completions():
    # Note:
    # expect_completions(source, line, column, filename, sys_path, expected)
    # source, line and column are in Python code
    # filename is in filesystem
    expect_completions(
        source=r"""
import sys
sys.getd""",
        line=2,
        column=13,
        filename="test.py",
        expected=[
            "sys.getdefaultencoding",
            "sys.getdefaulttimeout",
            "sys.getdlopenflags",
            "sys.getfilesystemencoding",
        ],
    )

    # At this moment this test checks that in Python 3.5, rlcompleter will finish attributes
    # like 'sys.getd' to 'sys.getdefaul' but Jedi will not.
    #
    # This way I can decide whether

# Generated at 2022-06-24 07:57:41.849397
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    new_ThonnyCompletion = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert new_ThonnyCompletion["name"] == "name"
    assert new_ThonnyCompletion["complete"] == "complete"
    assert new_ThonnyCompletion["type"] == "type"
    assert new_ThonnyCompletion["description"] == "description"
    assert new_ThonnyCompletion["parent"] == "parent"
    assert new_ThonnyCompletion["full_name"] == "full_name"


# Generated at 2022-06-24 07:57:48.129056
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion

    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    completion = Completion(name, complete, type, description, parent, full_name)
    ThonnyCompletion(name, complete, type, description, parent, full_name)



# Generated at 2022-06-24 07:57:50.866101
# Unit test for function get_definitions
def test_get_definitions():
    import _ast
    from jedi.evaluate import compiled
    from jedi import parser


# Generated at 2022-06-24 07:58:01.574331
# Unit test for function get_definitions
def test_get_definitions():
    # skip on Jython
    import sys

    if sys.platform.startswith("java"):
        return

    from os.path import join, dirname, abspath

    source = """
import tkinter

root = tkinter.Tk()
button = tkinter.Button(root, text="Hello")
button.pack()
"""
    # row = 6
    # column = 8
    row = 4
    column = 17

    filename = join(dirname(abspath(__file__)), "test_get_definitions.py")
    definitions = get_definitions(source, row, column, filename=filename)
    assert len(definitions) > 0, definitions
    assert definitions[0].module_name == "tkinter"

# Generated at 2022-06-24 07:58:09.732579
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    comp = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert comp.__getitem__("name") == name
    assert comp.__getitem__("complete") == complete
    assert comp.__getitem__("type") == type
    assert comp.__getitem__("description") == description
    assert comp.__getitem__("parent") == parent
    assert comp.__getitem__("full_name") == full_name

# Generated at 2022-06-24 07:58:18.450206
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest.mock as mock

    source = """if True:
    pri"""

    sys_path = ["/home/me/.local/lib/python3.7/site-packages"]
    with mock.patch("jedi.Script.completions") as mock_completions:
        with mock.patch("jedi.Script.__init__") as mock_init:
            get_script_completions(source, 2, 6, "script.py", sys_path)

# Generated at 2022-06-24 07:58:24.457598
# Unit test for function get_definitions
def test_get_definitions():
    defname = get_definitions("""
    class X:
        def __init__(self):
            self.x = 2
    y = X()
    """, 4, 4, "<str>")[0]
    assert defname.line == 2
    assert defname.column == 4
    assert str(defname.module_path) == "<str>"
    assert defname.name == "X"
    assert str(defname.full_name) == "X"
    assert defname.description == "class X"
    assert defname.type == "class"



# Generated at 2022-06-24 07:58:27.855760
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert c['name'] == 'name'

# Generated at 2022-06-24 07:58:37.067756
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    # In 0.17 there is completion for builtin function "exec", in 0.18+. it is gone
    test_cases = [
        (
            'exec',
            [
                {
                    "name": "exec",
                    "complete": "exec(object, globals=None, locals=None)",
                    "type": "exec",
                    "description": "",
                    "parent": "",
                    "full_name": "exec",
                }
            ],
        ),
    ]

    for name, expected_result in test_cases:
        namespaces = [{"__builtins__": Mock(Exec=Mock())}]
        completions = get_interpreter_completions(name, namespaces)

# Generated at 2022-06-24 07:58:39.132291
# Unit test for function parse_source
def test_parse_source():
    import parso
    from parso.utils import parse_version

# Generated at 2022-06-24 07:58:44.730448
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    source = "class A:\n    def f()"
    node = parse_source(source)
    pos = (1, 8)

    def_node = get_statement_of_position(node, pos)
    assert def_node.type == "funcdef"

    pos = (1, 16)
    assert get_statement_of_position(node, pos) is None

# Generated at 2022-06-24 07:58:53.930974
# Unit test for function parse_source
def test_parse_source():
    source = "import os; print(os.path)"
    node = parse_source(source)
    assert node.get_code() == source


# from jedi.evaluate import base
# from jedi.evaluate.representation import Instance

# def get_param_names_from_value(value: Instance):
# }
#     if hasattr(value, "get_signature"):
#         for param in getattr(value, "get_signature")():
#             yield param.name
#     else:
#         for param in getattr(value, "_param_names"):
#             yield param
#
#
# def get_star_arg_names_from_value(value: Instance):
#     if hasattr(value, "get_signature"):
#         return value.get_signature().get

# Generated at 2022-06-24 07:59:04.127348
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi import __version__ as jedi_version
    name = "test_name"
    complete = "test_complete"
    type = "test_type"
    description = "test_description"
    parent = "test_parent"
    full_name = "test_full_name"
    test_object = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert(test_object.name == name)
    assert(test_object.complete == complete)
    assert(test_object.type == type)
    assert(test_object.description == description)
    assert(test_object.parent == parent)
    assert(test_object.full_name == full_name)
    assert(__name__ == "thonnycontrib.jedi_utils")

# Generated at 2022-06-24 07:59:10.767460
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    sample = "def f(x): \n return x+1"
    node = parso.parse(sample)

    for pos in range(0, len(sample) + 1):
        stmt = get_statement_of_position(node, pos)
        # print(stmt, stmt.get_code())
        assert stmt.get_code() in ["def f(x):" , "return x+1"]



# Generated at 2022-06-24 07:59:16.338849
# Unit test for function get_definitions
def test_get_definitions():
    import sys

    # This is the code which is going to have the definitions
    code = "import re\nre.findall"
    definitions = get_definitions(code, 0, 0, sys.executable)

    # There should be a definition of type import_name (re)
    assert any(
        definition.type == "import_name" and definition.name == "re" for definition in definitions
    )
    # There should be a definition of type function (findall)
    assert any(
        definition.type == "function" and definition.name == "findall" for definition in definitions
    )

# Generated at 2022-06-24 07:59:23.482349
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    comp = tree.Operator("=", (1, 1))

    expr = tree.ExprStmt(comp, (1, 1))

    expr.children = [expr]

    assert expr.children[0] == expr

    node = tree.Node("test", (1, 1))
    node.children = [expr]

    assert node.children[0] == expr

    assert get_statement_of_position(node, (0, 0)) is None
    assert get_statement_of_position(expr, (0, 0)) is None

    assert get_statement_of_position(node, (1, 1)) == expr

# Generated at 2022-06-24 07:59:34.226950
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Script, Interpreter

    # Test with path
    jedi.Script = Script
    path = 'c:/users/kaspar/myfile.py'
    expected = [ThonnyCompletion(name='str', complete='str', type='type',
                                 description='str(object=\'\') -> str\nstr(bytes_or_buffer[, encoding[, errors]]) -> str',
                                 parent=None, full_name='str')]

    result = get_script_completions('import datetime\ndate', 2, 5, path)
    assert result == expected

    # Test without path
    path = ''
    result = get_script_completions('import datetime\ndate', 2, 5, path)
    assert result == expected

    # Test with sys_path
   

# Generated at 2022-06-24 07:59:41.417233
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class MyTest(TestCase):
        def test_get_script_completions(self):
            source = "a"
            filename = "jedi_helper_test.py"
            row = 1
            column = 1
            completions = get_script_completions(source, row, column, filename)
            self.assertEqual(len(completions), 1)
            self.assertEqual(completions[0]["name"], "abs")
            self.assertEqual(completions[0]["complete"], "abs(")

            source = "abs("
            filename = "jedi_helper_test.py"
            row = 1
            column = 4
            completions = get_script_completions(source, row, column, filename)
            # There

# Generated at 2022-06-24 07:59:47.549057
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from _jedi_imports import jedi

    namespaces = [
        {"os": jedi.Interpreter("import os; ", [])},
        {"sys": jedi.Interpreter("import sys; ", [])},
    ]
    completions = get_interpreter_completions("sys.std", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "stdout"

# Generated at 2022-06-24 07:59:57.959019
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_object = ThonnyCompletion(
        name="abc", complete="abc", type=1, description="abc", parent="abc", full_name="abc"
    )
    try:
        assert test_object["name"] == "abc"
    except AssertionError:
        raise AssertionError("AssertionError")
    try:
        assert test_object["complete"] == "abc"
    except AssertionError:
        raise AssertionError("AssertionError")
    try:
        assert test_object["type"] == 1
    except AssertionError:
        raise AssertionError("AssertionError")
    try:
        assert test_object["description"] == "abc"
    except AssertionError:
        raise AssertionError("AssertionError")

# Generated at 2022-06-24 08:00:02.769829
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.helpers import get_definitions

    defs = get_definitions('import tkinter', 0, 3, __file__)
    for defi in defs:
        print(defi)


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-24 08:00:12.988320
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion_name = "blub"
    completion_complete= "blub"
    completion_type= "blub"
    completion_description= "blub"
    completion_parent= "blub"
    completion_full_name= "blub"
    completion = ThonnyCompletion(
        name=completion_name,
        complete=completion_complete,
        type=completion_type,
        description=completion_description,
        parent=completion_parent,
        full_name=completion_full_name
    )
    assert completion.name == "blub"
    assert completion.complete == "blub"
    assert completion.type == "blub"
    assert completion.description == "blub"
    assert completion.parent == "blub"
    assert completion.full_name == "blub"

# Generated at 2022-06-24 08:00:23.219828
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    if get_statement_of_position is _copy_of_get_statement_of_position:
        return

    from parso.utils import convert_offset_to_line_column
    import unittest

    class TestParseError(Exception):
        pass

    class TestCase(unittest.TestCase):
        def assertResult(self, root, pos, node_cls):
            result = get_statement_of_position(root, pos)
            if not isinstance(result, node_cls):
                raise TestParseError(
                    "Expected get_statement_of_position(root, %s) to return %s, but got %s."
                    % (pos, node_cls, type(result))
                )

        def test_assignments(self):
            root = parse_source("var = 5")

# Generated at 2022-06-24 08:00:33.782351
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils
    from parso.python.tree import Leaf

    def _test_get_statement_of_position(node, pos):
        return jedi.parser_utils.get_statement_of_position(node, pos)

    ast = parse_source("print(test)")
    name = ast.children[0]
    funcargs = name.children[0]
    if _using_older_jedi(ast):
        assert _test_get_statement_of_position(funcargs, name.start_pos + 1) == funcargs
    else:
        assert _copy_of_get_statement_of_position(funcargs, name.start_pos + 1) == funcargs



if __name__ == "__main__":
    test_get_statement_of_position()
    print("OK")

# Generated at 2022-06-24 08:00:39.183382
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert (
        ThonnyCompletion(
            name="a",
            complete="a=",
            type="int",
            description="The highest prime number",
            parent="int",
            full_name="a",
        ).__dict__
        == {
            "name": "a",
            "complete": "a=",
            "type": "int",
            "description": "The highest prime number",
            "parent": "int",
            "full_name": "a",
        }
    )


if __name__ == "__main__":
    test_ThonnyCompletion()

# Generated at 2022-06-24 08:00:44.629878
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("completion", "completion", "type", "description", "parent", "full_name")
    assert completion["name"] == "completion"
    assert completion["complete"] == "completion"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 08:00:53.972229
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    try:
        # For older jedi where system path is not supported inside Interpreter
        assert len(
            get_interpreter_completions(
                "import sys\nsys.path.append('/path/to/something')\nimport ",
                namespaces=[{"__name__": "__main__"}],
            )
        ) > 0
    except Exception:
        # For new jedi where system path is supported inside Interpreter
        assert len(
            get_interpreter_completions(
                "import sys\nsys.path.append('/path/to/something')\nimport ",
                namespaces=[{"__name__": "__main__"}],
                sys_path=["/path/to/something"],
            )
        ) > 0

# Generated at 2022-06-24 08:00:56.145436
# Unit test for function parse_source
def test_parse_source():
    source = "def f(x):\n    return x"
    assert parse_source(source).get_code().strip().startswith(source.splitlines()[0])

# Generated at 2022-06-24 08:00:59.141814
# Unit test for function parse_source
def test_parse_source():
    with open("./test.py", "r") as f:
        source = f.read()
    parse_source(source)
    # Just check if not throw exception
    assert True


# Generated at 2022-06-24 08:01:06.191415
# Unit test for function get_script_completions
def test_get_script_completions():
    def run_test(expected_completions, filename, source=None, row=None, column=None):
        if isinstance(source, tuple):
            source, row, column = source

        import jedi

        if row is None:
            return jedi.Script(source, 0, 0, filename).completions()
        else:
            return jedi.Script(source, row, column, filename).completions()

    run_test(["os"], "test_script.py", "import os; os.")
    run_test(["os"], "test_script.py", "import os as x; x.", row=2)
    run_test(["sys"], "test_script.py", "import sys; import os;", row=2, column=10)

# Generated at 2022-06-24 08:01:12.990356
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    dummy_completion = ThonnyCompletion(name=None, complete=None, type=None, description=None, parent=None, full_name=None)
    assert dummy_completion["name"] is None
    assert dummy_completion["complete"] is None
    assert dummy_completion["type"] is None
    assert dummy_completion["description"] is None
    assert dummy_completion["parent"] is None
    assert dummy_completion["full_name"] is None

# Generated at 2022-06-24 08:01:18.590561
# Unit test for function get_definitions
def test_get_definitions():
    from thonny import ui_utils
    from thonny.globals import get_workbench
    from thonny.shell import Shell
    from thonny.plugins.jedi_support import handlers
    from jedi import Interpreter
    import sys
    import jedi
    import os
    import json

    def _assemble_test_env(filename):
        source = open(filename).read()
        row = 1
        column = 1
        file = os.path.abspath(filename)
        print("f: ", file)
        return source,row,column,os.path.abspath(filename)

    def _start_thonny():
        root = get_workbench().get_option("shell.pythonpath")
        if root is False:
            root = ""

        interpreter = ui_utils

# Generated at 2022-06-24 08:01:21.322064
# Unit test for function get_definitions
def test_get_definitions():
    source = ("from thing import Universe\n" "Universe().")
    get_definitions(source, 1, 16, '<input>')



# Generated at 2022-06-24 08:01:29.817835
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    import parso
    import textwrap
    class TestCase(unittest.TestCase):
        def assertDefinitionsEqual(self, expected, observed):
            self.assertEqual(len(expected), len(observed))
            for i in range(len(expected)):
                self.assertEqual(expected[i].module_path, observed[i].module_path)
                self.assertEqual(expected[i].type, observed[i].type)
                self.assertEqual(expected[i].line, observed[i].line)
                self.assertEqual(expected[i].column, observed[i].column)
                self.assertEqual(expected[i]._module_node, observed[i]._module_node)