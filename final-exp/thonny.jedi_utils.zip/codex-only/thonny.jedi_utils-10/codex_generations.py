

# Generated at 2022-06-24 07:51:10.488465
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
    """

    completions = get_script_completions(source, 0, 0, "test.py")

    assert len(completions) > 0



# Generated at 2022-06-24 07:51:20.319174
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    assert _using_older_jedi(jedi) == False
    test_script = """
    def test_function():
        return 10
    test_function()"""
    completions = get_script_completions(test_script, 2, 17, filename='/test_file') # 2 - line index, 17 - char index
    assert len(completions) == 1
    assert completions[0].name == 'test_function'
    assert completions[0].complete == 'test_function'
    assert completions[0].type == 'function'
    assert completions[0].description == 'function'
    assert completions[0].parent == 'module'
    assert completions[0].full_name == 'test_function'

# Generated at 2022-06-24 07:51:25.110723
# Unit test for function parse_source
def test_parse_source():
    if _using_older_jedi(jedi):
        from parso import parse
    else:
        from parso.python import parse

    doc = parse_source(
        "def foo()\n    print('bar')\n"
    )  # type: parso.python.tree.Module

    assert isinstance(doc, parse)

# Generated at 2022-06-24 07:51:29.981789
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name="a", complete="a", type="string", description="b", parent="c", full_name="d")
    assert tc["name"] == "a"
    assert tc["complete"] == "a"
    assert tc["type"] == "string"
    assert tc["description"] == "b"
    assert tc["parent"] == "c"
    assert tc["full_name"] == "d"

# Generated at 2022-06-24 07:51:41.984830
# Unit test for function get_definitions

# Generated at 2022-06-24 07:51:50.246731
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"
    assert completion.__dict__ == {'name': 'name', 'complete': 'complete', 'type': 'type',
                                   'description': 'description', 'parent': 'parent', 'full_name': 'full_name'}

# Generated at 2022-06-24 07:51:58.324214
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(name="int", complete="int", type="int", description="int",
                                  parent="int", full_name="int")
    assert(completion.__getitem__("name") == "int")
    assert(completion.__getitem__("complete") == "int")
    assert(completion.__getitem__("type") == "int")
    assert(completion.__getitem__("description") == "int")
    assert(completion.__getitem__("parent") == "int")
    assert(completion.__getitem__("full_name") == "int")


# Generated at 2022-06-24 07:52:00.310738
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name').__getitem__('name') == 'name'

# Generated at 2022-06-24 07:52:08.347678
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"



# Generated at 2022-06-24 07:52:13.473708
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    >>> above = '''
    ... import abc
    ... import os
    ... class Foo:
    ...     def b'''
    >>> script_completion_suggestions = get_script_completions(above, 3, 35, 'test.py')
    >>> [suggestion.complete for suggestion in script_completion_suggestions]
    ['basename', 'buffer', 'bar', 'baz', 'bam', 'abc', 'open']
    """


# Generated at 2022-06-24 07:52:15.046267
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import parso.python.tree


# Generated at 2022-06-24 07:52:17.055842
# Unit test for function parse_source
def test_parse_source():
    assert get_statement_of_position(parse_source("foo=bar"), pos=2) is None

# Generated at 2022-06-24 07:52:21.762013
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion.name == 'name'
    assert completion.complete == 'complete'
    assert completion.type == 'type'
    assert completion.description == 'description'
    assert completion.parent == 'parent'
    assert completion.full_name == 'full_name'



# Generated at 2022-06-24 07:52:27.747509
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def parse(s):
        import parso
        return parso.parse(s)
        
    node = parse("def f(x):\n    return x + 1\n")
    positions = [
        (parse("def f(x):\n"), 1),  # function
        (parse("def f(x):\n    return x + 1\n"), 4),  # return
        (parse("def f(x):\n    return x + 1\n"), 2),  # r
        (parse("def f(x):\n    return x + 1\n"), -10),  # nothing
        (parse("def f(x):\n    return x + 1\n"), 10),  # nothing in the end
    ]

# Generated at 2022-06-24 07:52:38.502467
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from test.tp_utils import run_isolated

    def worker():
        import unittest
        from unittest import mock
        from thonny.plugins.jedi_utils import ThonnyCompletion

        class ThonnyCompletionTesting(unittest.TestCase):
            def test_getitem_thonnycompletion(self):
                thonnycompletion = ThonnyCompletion(
                    "javascript",
                    "javascript",
                    "language",
                    "Javascript is the most popular language in the world",
                    "language",
                    "language.javascript",
                )
                self.assertEqual(thonnycompletion["name"], "javascript")
                self.assertEqual(thonnycompletion["complete"], "javascript")
                self.assertEqual(thonnycompletion["type"], "language")


# Generated at 2022-06-24 07:52:41.769582
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import mock
    from types import SimpleNamespace

    completion = ThonnyCompletion(1,2,3,4,5,6)

    assert completion.name == completion.__dict__['name'] == completion[0]

# Generated at 2022-06-24 07:52:46.618742
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():

    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")

    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"


# Generated at 2022-06-24 07:52:49.953963
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("import sys\nsys.", 0, 0, "temp") == []
    assert get_script_completions("import sys\nsys.", 1, 4, "temp")[0].complete == "sys."

# Generated at 2022-06-24 07:52:58.890245
# Unit test for function get_script_completions
def test_get_script_completions():
    # this test can be run using internal function run_tests in thonny/__init__.py
    import sys
    import os
    import jedi
    del sys.path[:]
    sys.path.append(os.path.dirname(os.__file__))

    root = os.path.dirname(os.path.abspath(__file__))
    # all the test files are in this directory
    test_files_dir = os.path.join(root, "jedi_test_files")
    all_files = [f for f in os.listdir(test_files_dir) if f.endswith(".py")]

# Generated at 2022-06-24 07:53:00.117080
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso import parse


# Generated at 2022-06-24 07:53:09.257924
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    from unittest.mock import patch

    class TestJedi(unittest.TestCase):
        def setUp(self):
            sys_path = ["path"]
            source = "x"
            namespaces = [{"x": 1}, {"y": 2}]
            self.get_interpreter_completions = patch(
                "jedihttp.utils.jedi.get_interpreter_completions"
            )
            self.get_interpreter_completions.start()
            self.get_interpreter_completions.return_value = [{"name": "x"}, {"name": "y"}]

        def tearDown(self):
            self.get_interpreter_completions.stop()


# Generated at 2022-06-24 07:53:15.907429
# Unit test for function parse_source
def test_parse_source():
    import inspect
    import sys
    example_dir = inspect.getfile(test_parse_source)
    example_dir = example_dir.replace("test_jedi_utils.py", "") + "example"
    if example_dir not in sys.path:
        sys.path.insert(0, example_dir)
    from example.filename import parse_source
    from example.filename import parse_source as parse_source2
    example: str = parse_source.__doc__
    example2: str = parse_source2.__doc__
    assert example == example2


# Generated at 2022-06-24 07:53:25.398663
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    dict1 = {}
    dict1.update({"name":"name"})
    dict1.update({"complete":"complete"})
    dict1.update({"type":"type"})
    dict1.update({"description":"description"})
    dict1.update({"parent":"parent"})
    dict1.update({"full_name":"full_name"})
    dict2 = {}
    dict2.update({"name":"name"})
    dict2.update({"complete":"complete"})
    dict2.update({"type":"type"})
    dict2.update({"description":"description"})
    dict2.update({"parent":"parent"})
    dict2.update({"full_name":"full_name"})
    assert dict1 == dict2

# Generated at 2022-06-24 07:53:33.808034
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def test_tree(node, pos, result, index=0):
        if len(result) == index:
            return (True, True)
        if (
            result[index].type == node.type
            and result[index].start_pos == node.start_pos
            and result[index].end_pos == node.end_pos
        ):
            return (True, True)
        else:
            return (False, False)

    import parso
    from parso.python.tree import Leaf
    from parso.python.tree import Node

    source = """def f(x):
    def g(y):
        return x+y
    return g
"""
    tree = parse_source(source)
    node = tree.children[0].children[4].children[0]
    pos = 0
    assert test_tree

# Generated at 2022-06-24 07:53:34.855207
# Unit test for function get_definitions

# Generated at 2022-06-24 07:53:40.633809
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    source = 'class Foo:\n    def foo(self):\n        pass\n'
    module = parse_source(source)
    assert isinstance(module, Module)
    assert len(module.children) == 2
    assert module.children[0].type == 'class'
    assert module.children[1] == EOL()

if __name__ == '__main__':
    test_parse_source()

# Generated at 2022-06-24 07:53:48.663102
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "test_name"
    complete = "test_complete"
    type_ = "test_type"
    description = "test_description"
    parent = "test_parent"
    full_name = "test_full_name"

    obj = ThonnyCompletion(name, complete, type_, description, parent, full_name)
    assert obj["name"] == name
    assert obj["complete"] == complete
    assert obj["type"] == type_
    assert obj["description"] == description
    assert obj["parent"] == parent
    assert obj["full_name"] == full_name

# Generated at 2022-06-24 07:53:54.448819
# Unit test for function get_script_completions
def test_get_script_completions():

    import jedi

    if _using_older_jedi(jedi):
        assert isinstance(
            get_script_completions("turtle.Turtle", 1, 1, "foo.py")[0], jedi.api_classes.Completion
        )
    else:
        assert isinstance(
            get_script_completions("turtle.Turtle", 1, 1, "foo.py")[0], jedi.api.classes.Completion
        )



# Generated at 2022-06-24 07:53:58.543636
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    source = """
    x = 1
    y = 2
    z = 3
    def f(a):
        def g(b):
            c = 1
    """

    module = parse_source(source)
    node = module
    assert get_statement_of_position(node, (1, 5)) == module.children[-1]
    assert get_statement_of_position(node, (2, 5)) == module.children[-1]
    assert get_statement_of_position(node, (3, 5)) == module.children[-1]

    assert get_statement_of_position(node, (4, 12)) == node.children[-1]

# Generated at 2022-06-24 07:54:04.559062
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    from parso.python.tree import ImportFrom
    from parso.python.tree import Name
    from parso.python.tree import Function, Class

    filename = "./test.py"

# Generated at 2022-06-24 07:54:15.563733
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    def should_contain_completion(completions, name, type, description):
        matching_completions = [c for c in completions if c.name == name]
        assert len(matching_completions) > 0, name
        assert matching_completions[0].type == type, name + " type mismatch"
        assert matching_completions[0].description == description, name + " description mismatch"

    completions = get_interpreter_completions("", [], ["."])
    should_contain_completion(completions, "abs", "function", "abs() -> integer")
    should_contain_completion(completions, "open", "function", "open(name, mode='r', buffering=-1)")


# Generated at 2022-06-24 07:54:23.513416
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.project import InternalDependency

    d = get_script_completions(
        "import sys\nimport smtplib\nsmtplib.\n", 2, 10, "test.py", sys_path=[__file__]
    )

    assert isinstance(d, list)
    assert len(d) > 3

    d = get_script_completions("import sys\nimport smtplib\nsmtplib.\n", 2, 10, "test.py")

    assert isinstance(d, list)
    assert len(d) > 3

    assert isinstance(d[0], ThonnyCompletion)
    assert d[0]["name"] == "SMTP_SSL"
    assert d[0]["type"] == "class"

# Generated at 2022-06-24 07:54:32.246803
# Unit test for function get_definitions
def test_get_definitions():
    """
    This function is not used in production code but can be used
    to test the current jedi version when it is imported (jedi.get_definitions).
    """
    import sys
    import inspect

    filename,_ = inspect.getframeinfo(inspect.currentframe())[:2]
    defs = get_definitions("""import sys
sys.getdefaultencoding()""", 2, 5, filename)
    if len(defs) == 1 and defs[0].module_name =='sys':
        print("jedi.get_definitions() is functional")


if __name__=="__main__":
    test_get_definitions()

# Generated at 2022-06-24 07:54:41.600061
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from parso.python import tree

    source = ""

    def make_thonny_completion(name: str, complete: str, type, description, parent, full_name):
        completion = ThonnyCompletion(
            name=name,
            complete=complete,
            type=type,
            description=description,
            parent=parent,
            full_name=full_name,
        )
        return completion

    # Test when no name provided
    tc = make_thonny_completion(
        name="",
        complete="",
        type="",
        description="",
        parent=tree.Node(type="node", start_pos=0, end_pos=0),
        full_name="",
    )

    assert tc.name == ""
    assert tc.complete == ""
    assert tc.type == ""

# Generated at 2022-06-24 07:54:49.601107
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "from math import *\na = sin(0.2*pi) + acos(1)"
    completions = get_script_completions(source, 2, 5, "test.py")
    assert len(completions) > 15
    assert "sin" in [c["name"] for c in completions]
    assert "acos" in [c["name"] for c in completions]

    # The order of completions is quite trivial, check at least something
    assert (
        completions[0]["name"]
        == "sin"
        and completions[1]["name"] == "sinh"  # my jedi 0.17 has "sinh" first
    )

# Generated at 2022-06-24 07:55:00.734086
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.evaluate.compiled.context import LazyTreeContext
    from jedi import Script, Interpreter

    code = "class A: pass"
    script = Script(code)
    completions = get_interpreter_completions(code, [])
    completions[0].complete = completions[0].complete.strip()
    assert completions == [
        {
            "name": "A",
            "complete": "class A(object):\n    pass",
            "type": "class",
            "description": "",
            "parent": "",
            "full_name": "A",
        }
    ]

    # Test that get_interpreter_completions works with jedi versions before 0.18

# Generated at 2022-06-24 07:55:09.077718
# Unit test for function get_definitions
def test_get_definitions():
    """ get_definitions in jedi <0.18 (0.17.2) did not work if module was
        imported by package or alias """
    import jedi
    
    if jedi.__version__[:3] >= "0.18":
        return
    
    jedi_path = jedi.__path__[0]
    import sys

    sys.path.append(jedi_path)  # add jedi to sys.path in order to import test data
    source = """from parso.python.diff import diff
diff

from parso.python.diff import parso_helper_diff
parso_helper_diff"""

# Generated at 2022-06-24 07:55:16.464476
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """with open("test") as f:
    f.read
    """
    completions = get_script_completions(source, row=2, column=8, filename="test.py")
    #    print(completions)
    assert completions == [
        ThonnyCompletion(name="read", complete="read", type="function", description="read() -> read at 0x7efd3ac39bf8>", parent={"type": "Instance", "name": "file"}, full_name="file.read")
    ]

    source = """with open("test") as f:
    f.readli
    """
    completions = get_script_completions(source, row=2, column=9, filename="test.py")
    #    print(completions)

# Generated at 2022-06-24 07:55:20.102453
# Unit test for function parse_source
def test_parse_source():
    import parso

    test_source = "print(1)"
    result_source = parse_source(test_source)

    assert isinstance(result_source, parso.python.tree.Module)

# Generated at 2022-06-24 07:55:28.504722
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from thonny.misc_utils import running_on_ci

    # with tokenize.open(__file__) as f:
    #     source = f.read()
    import parso
    # ast_ = parso.parse(source)
    # def_ = list(ast_.iter_classdefs())
    # name = def_[0].name.value
    # name = def_[0].name.value
    # type_ = "function"
    # pos = parso.python.tree.Leaf(type=parso.python.tree.Name, value=name, start_pos=(1, 5))
    # docstring = parso.python.tree.Leaf(type=parso.python.tree.Name, value="docstring", start_pos=(1, 5))
    # line = parso.python.tree

# Generated at 2022-06-24 07:55:31.158101
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")[
        "name"
    ] == "name"

# Generated at 2022-06-24 07:55:38.331065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    s = "import argparse\nargparse.\n"
    completions = get_interpreter_completions(s, [])
    assert len(completions) == 3
    assert completions[0].name == "ArgumentParser"
    assert completions[1].name == "FileType"
    assert completions[2].name == "Namespace"
    assert completions[0].full_name == "argparse.ArgumentParser"

    s = "import inspect\ninspect.\n"
    completions = get_interpreter_completions(s, [])
    assert len(completions) == 5
    assert completions[0].name == "ArgInfo"
    assert completions[0].full_name == "inspect.ArgInfo"

# Generated at 2022-06-24 07:55:43.572983
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    test = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert test["name"] == name
    assert test["complete"] == complete
    assert test["type"] == type
    assert test["description"] == description
    assert test["parent"] == parent
    assert test["full_name"] == full_name

# Generated at 2022-06-24 07:55:51.746225
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    thonny_completion = ThonnyCompletion(name=name, complete=complete, type=type, description=description, parent=parent, full_name=full_name)
    print("thonny_completion.name =", thonny_completion.name)
    print("thonny_completion['name'] =", thonny_completion["name"])

# Generated at 2022-06-24 07:55:59.568278
# Unit test for function get_definitions
def test_get_definitions():
    # up to version 0.16, the return type of get_definitions was list of StringLike objects
    # since version 0.17, it is a list of Definition objects
    from unittest import mock

    jedi_mock = mock.MagicMock()
    jedi_mock.__version__ = "0.16.1"
    defs = get_definitions(jedi_mock, "", 0, 0, "")
    assert isinstance(defs, list)
    assert not hasattr(defs[0], "type")

    jedi_mock = mock.MagicMock()
    jedi_mock.__version__ = "0.17.2"
    defs = get_definitions(jedi_mock, "", 0, 0, "")
    assert isinstance(defs, list)


# Generated at 2022-06-24 07:56:05.216784
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert tc['name'] == "name"
    assert tc['complete'] == "complete"
    assert tc['type'] == "type"
    assert tc['description'] == "description"
    assert tc['parent'] == "parent"
    assert tc['full_name'] == "full_name"


# Generated at 2022-06-24 07:56:13.679618
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import ExprStmt, Name
    from parso.python import tree

    def get_statement(offset):
        return get_statement_of_position(node, offset)

    # statement - 0, comment - 1, statement - 2
    node = parse_source("x = 42 \n #comment \n y = 17 \n")
    assert get_statement(0) == node.children[0]
    assert get_statement(1) == node.children[0]
    assert get_statement(2) == node.children[0]
    assert get_statement(3) is None
    assert get_statement(4) is None
    assert get_statement(5) is None
    assert get_statement(6) is None
    assert get_statement(7) is None
    assert get_statement(8) == node

# Generated at 2022-06-24 07:56:18.732264
# Unit test for function get_definitions
def test_get_definitions():
    if get_definitions("def foo():\n    pass", 2, 7, "")[0].module_path != __file__:
        print("Failed")
    else:
        print("Passed")

if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-24 07:56:26.222062
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion_object = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonny_completion_object["name"] == "name"
    assert thonny_completion_object["complete"] == "complete"
    assert thonny_completion_object["type"] == "type"
    assert thonny_completion_object["description"] == "description"
    assert thonny_completion_object["parent"] == "parent"
    assert thonny_completion_object["full_name"] == "full_name"

# Generated at 2022-06-24 07:56:31.909425
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    instance = ThonnyCompletion(name="name",
                                complete="complete",
                                type="type",
                                description="description",
                                parent="parent",
                                full_name="full_name")
    assert instance["name"] == "name"
    assert instance["complete"] == "complete"
    assert instance["type"] == "type"
    assert instance["description"] == "description"
    assert instance["parent"] == "parent"
    assert instance["full_name"] == "full_name"

# Generated at 2022-06-24 07:56:41.836714
# Unit test for function get_script_completions
def test_get_script_completions():
    source = """
import os
"""
    completions = get_script_completions(source, 0, 1, "test.py")
    assert completions[0].name == "os"
    assert completions[0].complete == "os"
    assert completions[1].name == "open"

    completions = get_script_completions(source, 1, 5, "test.py")
    assert completions[0].name == "open"
    assert completions[0].type == "function"
    assert completions[0].complete == "open("
    assert completions[1].name == "os"
    assert completions[1].type == "module"
    assert completions[1].complete == "os"

    source = """
from os import path,
"""
    completions = get_script_completions

# Generated at 2022-06-24 07:56:52.055309
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    old_result = get_interpreter_completions('import threading\nthreading', [])
    old_result.sort(key=lambda x: x.name)
    assert old_result[-1].name == 'threading.Thread' # should be the last one
    assert old_result[-1].complete == 'threading.Thread'
    assert old_result[-1].type == 'class'

    new_result = get_interpreter_completions('import threading\nthreading', [])
    new_result.sort(key=lambda x: x.name)
    assert new_result[-1].name == 'threading.Thread' # should be the last one
    assert new_result[-1].complete == 'threading.Thread'
    assert new_result[-1].type == 'class'

# Generated at 2022-06-24 07:57:01.106447
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():

    import jedi

    completion = jedi.api.classes.Completion()

    completion.name = "name"
    completion.complete = "complete"
    completion.type = "type"
    completion.description = "description"
    completion.parent = "parent"
    completion.full_name = "full name"

    thonny_completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

    assert completion.name == thonny_completion["name"]
    assert completion.complete == thonny_completion["complete"]
    assert completion.type == thonny_completion["type"]

# Generated at 2022-06-24 07:57:09.474924
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:11.604630
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:57:18.390296
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import namedtuple
    from unittest.mock import MagicMock
    import jedi
    from jedi.api.classes import Namespace

    MockCompletion = namedtuple(
        "MockCompletion", ["name", "complete", "type", "description", "parent", "full_name"]
    )

    mock_completion = MockCompletion(
        name="some_name",
        complete="some_complete",
        type="some_type",
        description="some_description",
        parent=Namespace(MagicMock()),
        full_name="some_full_name",
    )
    completions = [mock_completion]
    result = get_interpreter_completions("", [], sys_path=[])

    assert result[0].name == completions[0].name
   

# Generated at 2022-06-24 07:57:23.482739
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("a = 'abc'", 1, 5, __file__)
    names = [comp.complete for comp in completions]
    assert "capitalize" in names
    assert "center" in names

if __name__ == "__main__":
    test_get_script_completions()
    print("OK")

# Generated at 2022-06-24 07:57:24.314884
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:57:35.838381
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    # Test empty source
    completions = get_interpreter_completions("", [], None)
    assert len(completions) == 0

    # Test with imports
    completions = get_interpreter_completions("from math import *", [], None)
    assert len(completions) == 0

    # Test with imports
    import math
    namespaces = [{"math": math}]
    completions = get_interpreter_completions("math.", namespaces, None)
    assert completions[0].name in ['pi', 'remainder']

    # Check with separate namespaces
    import random
    namespaces = [{"random": random}, {"math": math}]
    completions = get_interpreter_completions("random.", namespaces, None)
    assert comple

# Generated at 2022-06-24 07:57:43.035133
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.case

    case = unittest.case.TestCase()
    source = """
    a = 1
    a = 2
    "abc"
    """

    defns = get_definitions(source, 1, 3, "test.py")
    case.assertEqual(len(defns), 1)
    case.assertEqual(defns[0].line, 2)
    case.assertEqual(defns[0].in_builtin_module(), False)
    case.assertIsNotNone(defns[0].module_path)

    defns = get_definitions(source, 3, 1, "test.py")
    case.assertEqual(len(defns), 1)
    case.assertEqual(defns[0].line, 0)

# Generated at 2022-06-24 07:57:53.625585
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import OrderedDict

    def split(string):
        return [x for x in string.split("\n") if x]

    if _using_older_jedi(jedi):
        # up to jedi 0.17
        expected = split(
            """
            woof
            woofy
            wow
            x
            y
            z
            """
        )
    else:
        # 0.18 and later
        expected = split(
            """
            woof
            woofy
            wow
            x()
            x = None
            y()
            y = None
            z()
            z = None
            """
        )

    code = "class A:\n    pass"

# Generated at 2022-06-24 07:57:56.202754
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    completions1 = get_script_completions("somestring", 0, 0, "")
    completions2 = Script("somestring", 0, 0, "").completions()
    assert len(completions1) > len(completions2)

# Generated at 2022-06-24 07:58:05.198632
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check(source, pos, expected_code):
        node = parse_source(source)
        found = get_statement_of_position(node, pos)
        found_code = found.get_code()
        if found_code != expected_code:
            raise AssertionError(
                "Found %s, but expected %s for %s at %s" % (found_code, expected_code, source, pos)
            )

    check("""x = 1\n""", (1, 1), "x = 1")
    check("""x = 1\n""", (1, 8), "x = 1")
    check("""x = 1\n""", (2, 1), "")
    check("""x = 1\n""", (0, 0), "")

# Generated at 2022-06-24 07:58:11.658030
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"  # Should be true
    assert completion["type"] == "type"  # Should be true
    assert completion["parent"] == "parent"  # Should be true
    assert completion["full_name"] == "full_name"  # Should be true
test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:58:18.657342
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import os
    import jedi

    if _using_older_jedi(jedi):
        print("For running this test case thonny must use a >= 0.18 jedi")
        return

    sys_path = [os.path.dirname(__file__)]
    completions = get_script_completions("from o", 0, 7, "test.py", sys_path)

    for c in completions:
        print(f"{c.name}, {c.complete}, {c.description}, {c.parent}, {c.full_name}")


if __name__ == '__main__':
    test_get_script_completions()

# Generated at 2022-06-24 07:58:26.020296
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.tree import NodeOrLeaf

    def _find_by_position(node_or_leaf):
        if isinstance(node_or_leaf, NodeOrLeaf):
            start_pos = node_or_leaf.start_pos

            def _comp(other):
                if isinstance(other, NodeOrLeaf):
                    return other.start_pos == start_pos

                return False

            return _comp
        else:
            return lambda x: False

    def get_statement_of_pos(position: tuple, nodes: List[NodeOrLeaf]):
        node = nodes[0]
        found_node_or_leaf = next(filter(_find_by_position(node), nodes), None)
        assert found_node_or_leaf is not None
        return get_statement

# Generated at 2022-06-24 07:58:35.506803
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    namespaces = [{'i': 1}]
    source = "i"

    # Using older jedi < 0.18
    if not hasattr(jedi, "Interpreter"):
        return  # No function in older jedi

    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 2
    assert [completion.name for completion in completions] == ["i", "id"]

    completions = get_interpreter_completions(source, namespaces, sys_path=["/tmp"])
    assert len(completions) == 2
    assert [completion.name for completion in completions] == ["i", "id"]

    namespaces = [{'hasattr': hasattr}]

# Generated at 2022-06-24 07:58:36.924214
# Unit test for function get_definitions
def test_get_definitions():
    source = """
x = 42
"""
    row, col = 1, 4
    assert get_definitions(source, row, col, '')[0].module_path == 'builtins'

# Generated at 2022-06-24 07:58:46.576932
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions(
        "import os.path.\n"
        "os.path.exists('')",
        filename="",
        row=2,
        column=12,
    )
    assert completions[0].name == "exists", completions[0]
    assert len(completions) == 19, completions
    completions = get_script_completions(
        "import os.path.\n"
        "os.path.exis",
        filename="",
        row=2,
        column=12,
    )
    assert completions[0].name == "exists", completions[0]
    assert len(completions) == 19, completions



# Generated at 2022-06-24 07:58:55.147630
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.codeview import _pick_definition
    from thonny.codeview import get_definitions
    
    def test(source, row, column, expected_module, expected_name, expected_type):
        defs = get_definitions(source, row, column, filename="test.py")
        
        actual_module, actual_name, actual_type = _pick_definition(defs)
        
        assert actual_module == expected_module
        assert actual_name == expected_name
        assert actual_type == expected_type
    
    # build-in function
    test("zo\n", 1, 2, "builtins", "zord", "function")
    
    # declaration

# Generated at 2022-06-24 07:59:04.904441
# Unit test for function get_script_completions
def test_get_script_completions():
    def assert_comp_len(code, pos, expected=None):
        completions = get_script_completions(code, *pos)
        assert len(completions) == expected

    assert_comp_len("", (0, 0), 0)
    assert_comp_len("    ", (0, 4), 0)
    assert_comp_len("name", (0, 4), 0)
    assert_comp_len("name=", (0, 5), 0)

    assert_comp_len("my_var =", (0, 1), 1)
    assert_comp_len("my_var =", (0, 9), 0)

    assert_comp_len("import sys", (0, 1), 5)
    assert_comp_len("import sys", (0, 8), 0)


# Generated at 2022-06-24 07:59:14.301928
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import parso

    # Test for jedi.Script.goto_definitions() in jedi < 0.18
    source_script = '''def some_function():
    def nested_function():
        a = 1
        return a
    '''
    col = 19
    row = 2
    filename = '/home/user/hello.py'
    definitions = get_definitions(source_script, row, col, filename)
    assert type(definitions) == list
    for item in definitions:
        assert isinstance(item, jedi.api_classes.Definition)
    # TODO: check Definition attributes
    assert definitions[0].in_builtin_module()
    assert definitions[0].module_path == '/home/user/hello.py'
    assert definitions[0].line == 3

# Generated at 2022-06-24 07:59:21.812623
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_ThonnyCompletion = ThonnyCompletion(
        name="pip", complete="pip", type="import", description="", parent="", full_name=""
    )
    assert test_ThonnyCompletion.name == "pip"
    assert test_ThonnyCompletion.complete == "pip"
    assert test_ThonnyCompletion.type == "import"
    assert test_ThonnyCompletion.description == ""
    assert test_ThonnyCompletion.parent == ""
    assert test_ThonnyCompletion.full_name == ""
    assert test_ThonnyCompletion["name"] == "pip"
    assert test_ThonnyCompletion["complete"] == "pip"
    assert test_ThonnyCompletion["type"] == "import"
    assert test_Thonny

# Generated at 2022-06-24 07:59:31.033257
# Unit test for function get_definitions
def test_get_definitions():
    from parso import parse
    from parso.python.tree import PythonNode, IfStmt
    from thonny.jedi_utils import get_definitions
    from thonny.jedi_utils import _tweak_completions

    source1 = "a = 1\na"
    source2 = "a = 1\na\nif True: b=1\nb"
    source3 = "a = 1\na\nif True:    \n    b=1\nb"

    tree1 = parse(source1)
    tree2 = parse(source2)
    tree3 = parse(source3)

    completions = get_definitions(source1, 1, 2, "test")

    if False:
        print (completions)
        print ([c.name for c in completions])

# Generated at 2022-06-24 07:59:36.319035
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(name="x", complete="x", type=None, description="", parent=None,full_name=None)
    assert completion.name == "x"
    assert completion.complete == "x"
    assert completion.type == None
    assert completion.description == ""
    assert completion.parent == None
    assert completion.full_name == None

# Generated at 2022-06-24 07:59:39.100764
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
import math
a = math.f"""
    completions = get_interpreter_completions(source, [globals()])
    assert len(list(completions)) == 1
    assert completions[0]["name"] == "math.factorial"



# Generated at 2022-06-24 07:59:44.931933
# Unit test for function get_script_completions
def test_get_script_completions():
    from test.jedi_example_code import complete_def_assign_example
    from thonny.jediutils import get_script_completions
    from thonny.jediutils import ThonnyCompletion

    script_completions = get_script_completions(complete_def_assign_example, 8, 9,
                                                filename = "complete_def_assign_example.py")

    assert len(script_completions) == 3
    assert isinstance(script_completions[0], ThonnyCompletion)

    assert script_completions[0].name == "sqr"
    assert script_completions[0].type == "function"

    assert script_completions[1].name == "sorted"

# Generated at 2022-06-24 07:59:45.845769
# Unit test for function get_definitions

# Generated at 2022-06-24 07:59:56.782628
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import patch
    from jedi import Script, Interpreter

    def side_effect_completions(line, column):
        return ["side_effect_completions"]

    def side_effect_completions_old(self):
        return ["side_effect_completions_old"]

    with patch.object(Script, "completions", side_effect=side_effect_completions):
        script = Script("from tkinter import *\n")
        assert get_script_completions("from tkinter import *\n", 1, 0, "") == [
            "Canvas"
        ]

    with patch.object(Script, "completions", side_effect=side_effect_completions):
        script = Script("from tkinter import *\n")

# Generated at 2022-06-24 08:00:05.933506
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    temp = ThonnyCompletion('str', 'str', "types", "description", "parent", "full_name")
    temp.__getitem__.function_name = '__getitem__'
    if temp['name'] != 'str':
        return False
    if temp['complete'] != 'str':
        return False
    if temp['type'] != "types":
        return False
    if temp['description'] != "description":
        return False
    if temp['parent'] != "parent":
        return False
    if temp['full_name'] != "full_name":
        return False

    return True


# Generated at 2022-06-24 08:00:11.796675
# Unit test for function get_definitions
def test_get_definitions():
    from jedi import get_definitions
    # in jedi 0.13.2 get_definitions does not work with column < 0
    # so we need a dummy file and specify ('filename', row, column)
    assert len(get_definitions('dir"', 1, 1, 'test')) > 1


if __name__ == "__main__":
    test_get_definitions()

# Generated at 2022-06-24 08:00:22.441727
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import PythonNode

    def get_child_with_range(parent, start, end):
        return next(c for c in parent.children if c.start_pos == start and c.end_pos == end)
    
    # Node at position p
    #  0  1  2  3  
    #  f(a)
    #    |
    #    p
    node = tree_builder("f(a)")
    p = 2
    assert get_statement_of_position(node, p) == get_child_with_range(node, 1, 4)
    
    # p at the end of node
    #  0  1  2  3  
    #  f(a)
    #       |
    #       p
    p = 3
    assert get_statement_of_

# Generated at 2022-06-24 08:00:27.869391
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from jedi.parser_utils import get_statement_of_position
    assert get_statement_of_position(None, None) == None
    source = 'def foo():\n    "foo"\n    pass'
    node = parso.parse(source)
    assert get_statement_of_position(node, 0) == None
    assert get_statement_of_position(node, 1) == None
    assert get_statement_of_position(node, 2) == None
    assert get_statement_of_position(node, 3).type == "funcdef"
    assert get_statement_of_position(node, 3).value == "foo"
    assert get_statement_of_position(node, 4) == None
    assert get_statement_of_position(node, 5) == None
    assert get_

# Generated at 2022-06-24 08:00:37.588894
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("def foo():\n   ", 1, 4, "test.py")[0]["name"] == "foo"
    assert get_script_completions("def foo():\n   ", 1, 4, "test.py")[0]["complete"] == "def "
    assert get_script_completions("def foo():\n   ", 1, 4, "test.py")[0]["type"] == "function"
    assert get_script_completions("def foo():\n   ", 1, 4, "test.py")[0]["description"] == "foo"
    assert get_script_completions("def foo():\n   ", 1, 4, "test.py")[0]["parent"] == "def"

# Generated at 2022-06-24 08:00:43.286431
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    try:
        test["name"]
        test["complete"]
        test["type"]
        test["description"]
        test["parent"]
        test["full_name"]
        assert True
    except Exception:
        assert False
    else:
        assert False

# Generated at 2022-06-24 08:00:50.016971
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_compl = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert test_compl.__getitem__('name') == 'name'
    assert test_compl.__getitem__('complete') == 'complete'
    assert test_compl.__getitem__('type') == 'type'
    assert test_compl.__getitem__('description') == 'description'
    assert test_compl.__getitem__('parent') == 'parent'
    assert test_compl.__getitem__('full_name') == 'full_name'

# Generated at 2022-06-24 08:00:55.441703
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock

    with mock.patch("jedi.Interpreter.__init__") as mock_constructor:
        mock_constructor.return_value = None
        get_interpreter_completions("", [], [])
        mock_constructor.assert_called_once_with(
            "", [], None  # TODO: maybe change to sys_path=[],  but can't verify then
        )

# Generated at 2022-06-24 08:01:04.291694
# Unit test for method __getitem__ of class ThonnyCompletion

# Generated at 2022-06-24 08:01:11.559240
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"