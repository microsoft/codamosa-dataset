

# Generated at 2022-06-24 07:50:35.802945
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import pprint

    # Code copied from https://github.com/thonny/thonny/issues/715#issuecomment-586507881

# Generated at 2022-06-24 07:50:42.027174
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso
    completion = ThonnyCompletion("name", "complete", "type", "description", parso.parse("def abc()"), "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent.children[0].type == "funcdef"
    assert completion.parent.children[0].children[1].value == "abc"
    assert completion.full_name == "full_name"
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"].children[0].type == "funcdef"

# Generated at 2022-06-24 07:50:47.395678
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import PythonNode

    source = """
for i in range(10):
    if i == 5:
        print("Hello world")
    else:
        print("Goodbye")
"""

    module = parse_source(source)
    assert isinstance(module, PythonNode)
    assert module.type == "file_input"



# Generated at 2022-06-24 07:50:53.928735
# Unit test for function get_definitions
def test_get_definitions():
    import os.path

    import jedi.evaluate.representation
    from jedi import __file__ as jedi_file

    jedi_path = os.path.join(os.path.dirname(jedi_file), "evaluate")
    jedi_path = os.path.abspath(jedi_path)

    from thonny.jedi_utils import get_definitions
    from parso.python import tree

    source = "foo=123\n(foo.upper()) ."
    row = 2
    column = 10
    filename = "__dummy__"

    defs = get_definitions(source, row, column, filename)
    assert len(defs) == 1
    definition = defs[0]
    assert definition.description == jedi.evaluate.representation.str_repr
    assert isinstance

# Generated at 2022-06-24 07:51:03.743272
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # Works with older parso
    text = """\
if True:
    something()
"""
    pos = len(text)
    source = parse_source(text)
    node = source.children[0]
    node = get_statement_of_position(node, pos)
    assert node.type == "simple_stmt"

    # Works with newer parso
    text = """\
if True:
    something()
"""
    pos = len(text)
    source = parse_source(text)
    node = source.children[0]
    node = get_statement_of_position(node, pos)
    assert node.type == "simple_stmt"

# Generated at 2022-06-24 07:51:11.434410
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import unittest.mock
    import jedi

    class Jedi:
        @staticmethod
        def __empty__():
            pass

        DEFINITION = "DEFINITION"

    mock = unittest.mock.Mock()
    mock.goto_definitions.return_value = [Jedi]
    script_attr = Jedi.__empty__
    script_attr.goto_definitions = mock.goto_definitions

    jedi.Script = unittest.mock.Mock()
    jedi.Script.return_value = script_attr

    defs = get_definitions("source", 1, 2, "filename")
    assert defs == [{"type": Jedi.DEFINITION}]


# Generated at 2022-06-24 07:51:19.609663
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_interpreter_completions(self):
            result = get_interpreter_completions('a="spam"', [{'a':'spam'}])
            self.assertEqual(result[0].name, 'count')
            self.assertEqual(result[1].name, 'capitalize')

    unittest.main(
        module=__name__, failfast=True, exit=False, verbosity=2, buffer=True
    )


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 07:51:24.048542
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("a", "a", "class", "", "", "")
    assert completion["name"] == "a"
    assert completion["complete"] == "a"
    assert completion["type"] == "class"
    assert completion["description"] == ""

# Generated at 2022-06-24 07:51:33.899801
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    assert _using_older_jedi(jedi)
    
    def test(source: str, row: int, column: int, filename: str, sys_path=None):
        try:
            script = jedi.Script(source, row, column, filename, sys_path=sys_path)
        except Exception as e:
            logger.info("Could not get completions with given sys_path", exc_info=e)
            script = jedi.Script(source, row, column, filename)

        completions = script.completions()
        
        for completion in _tweak_completions(completions):
            assert isinstance(completion, ThonnyCompletion)
    
    test("a = 1\na.s(", 4, 4, "")

# Generated at 2022-06-24 07:51:42.953935
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    completion = jedi.Script("def foo(x: int) -> int: ...").completions()[0]
    thonny_completion = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )

    assert type(thonny_completion) == ThonnyCompletion
    assert thonny_completion.name == "foo"
    assert thonny_completion.complete == "foo"
    assert thonny_completion.type == "function"
    assert thonny_completion.description == "foo(x: int) -> int"
    assert thonny

# Generated at 2022-06-24 07:51:48.702030
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os

    test_folder = os.path.dirname(__file__)
    sys_path = [os.path.join(test_folder, "utils")]

    script = jedi.Script("", 1, 3, "", sys_path=sys_path)
    completions = script.completions()
    assert any(map(lambda c: c.name == "stuff", completions)), "incompletions"

    completions = script.completions(line=2, column=0)
    assert len(completions) == 0


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        source = open(sys.argv[1]).read()

# Generated at 2022-06-24 07:51:59.737491
# Unit test for function get_definitions
def test_get_definitions():
    from parso.python import tree
    from jedi.evaluate import analysis
    from jedi.evaluate import compiled

# Generated at 2022-06-24 07:52:00.276708
# Unit test for function get_definitions
def test_get_definitions():
    pass

# Generated at 2022-06-24 07:52:07.100543
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    temp_completion = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    assert temp_completion["name"] == "a"
    assert temp_completion["complete"] == "b"

if __name__ == "__main__":
    test_ThonnyCompletion___getitem__()
    # print(help(ThonnyCompletion))

# Generated at 2022-06-24 07:52:15.108962
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import Interpreter
    from jedi.api import classes
    from jedi.api.script import Script
    import parso.python.tree

    def prepare_assertion(obj):
        if isinstance(obj, list):
            return [prepare_assertion(x) for x in obj]
        if isinstance(obj, parso.python.tree.Module):
            return "Module"
        if isinstance(obj, Script):
            return "Script"
        if isinstance(obj, Interpreter):
            return "Interpreter"
        elif isinstance(obj, classes.Name):
            return "Name"
        elif isinstance(obj, classes.Statement):
            return "Statement"
        elif isinstance(obj, classes.Function):
            return "Function"

# Generated at 2022-06-24 07:52:24.041163
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion
    from jedi.api.keywords import Keyword
    from jedi.api.helpers import FakeName
    from jedi.parser.tree import BaseNode
    from jedi import __version__
    import jedi
    keyword = Keyword("for")
    completion = Completion(keyword, keyword.name)
    completion.full_name = keyword.name
    completion.parent = FakeName("parent", BaseNode, completion.name)
    if __version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert (
            completion.type == "keyword"
        ), "For jedi version {} and a keyword completion the type should be 'keyword'".format(
            __version__
        )


# Generated at 2022-06-24 07:52:34.802780
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import math
    from unittest.mock import Mock

    from thonny.plugins.backend import BackendPlugin
    from thonny.plugins.jedi_utils import get_interpreter_completions

    # create a mock backend plugin
    plugin = BackendPlugin(None)
    # make the directory of jedi_utils the path from which the user code would be executed
    plugin.get_runner().get_sys_path = Mock(return_value=[os.path.abspath(os.path.dirname(__file__))])
    completions = get_interpreter_completions("math.", [{"name": "sys", "object": sys}, {"name": "math", "object": math}])

# Generated at 2022-06-24 07:52:37.152282
# Unit test for function get_definitions
def test_get_definitions():
    from thonny import get_workbench
    from thonny.jedi_utils import get_definitions


# Generated at 2022-06-24 07:52:44.681169
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # Input data
    input_data = {
        "name": "",
        "complete": "",
        "type": "",
        "description": "",
        "parent": "",
        "full_name": "",
    }

    # Expected output
    expected_output = {
        "name": "",
        "complete": "",
        "type": "",
        "description": "",
        "parent": "",
        "full_name": "",
    }

    # Start of unit test
    method_output = ThonnyCompletion(**input_data)

    # Assertion
    assert method_output.__dict__ == expected_output

# Generated at 2022-06-24 07:52:54.976937
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from thonny.misc_utils import running_on_linux

    if _using_older_jedi(jedi):
        print("Skipping test for jedi version < 0.18")
        return

    completions = get_interpreter_completions("x = 1; x.", [{}])
    assert len(completions) > 3

    completions = get_interpreter_completions("x.", [{}])
    assert len(completions) == 1
    assert completions[0].name == "xrange"

    completions = get_interpreter_completions('from datetime import date; date()', [{}])
    assert len(completions) > 1

    completions = get_interpreter_completions('date()', [{}])
   

# Generated at 2022-06-24 07:53:01.379602
# Unit test for function get_definitions
def test_get_definitions():
    from thonny.globals import get_workbench

    get_workbench().set_python_version(3, 7, 32)
    source = """
import sys
sys.maxint
"""
    lines = source.splitlines(keepends=True)
    row, column = 2, 16
    filename = "<stdin>"
    results = get_definitions(source, row, column, filename)
    if not results:
        raise Exception("Could not get completion")
    assert results[0].module_name == "sys"
    assert results[0].line == 1
    assert results[0].column == 1



# Generated at 2022-06-24 07:53:04.709358
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("in", [{"spam": "eggs"}])) == 1
    assert get_interpreter_completions("spam", [{"spam": "eggs"}])[0].name == "spam"

# Generated at 2022-06-24 07:53:13.261395
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import os

    here = os.path.abspath(__file__)
    dir_path = os.path.dirname(here)
    jedi_file = os.path.join(dir_path, "jedi_source.py")
    with open(jedi_file, "r") as f:
        code = f.read()

    possible_completions = get_script_completions(code, 4, 10, jedi_file)
    assert len(possible_completions) > 0

    if _using_older_jedi(jedi):
        assert possible_completions[0].name == "SimpleClass"
        assert possible_completions[0].complete == "meth1"

# Generated at 2022-06-24 07:53:17.503814
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    from parso.parser import ParserError
    src = "import sys"
    node = parse_source(src)
    assert isinstance(node, Module)
    try:
        parse_source("def a:")
        assert False
    except ParserError:
        pass



# Generated at 2022-06-24 07:53:27.612365
# Unit test for function get_script_completions
def test_get_script_completions():
    from jaraco.test.support import ImportGuard

    with ImportGuard(
        "jedi.api.Script", "jedi.api.classes.Interpreter", "jedi.evaluate.representation", "jedi.evaluate.compiled.access"
    ) as modules:
        import jedi.api
        import jedi.api.classes
        import jedi.evaluate.representation
        import jedi.evaluate.compiled.access

        modules.jedi.api.classes.Completion = ThonnyCompletion
        modules.jedi.evaluate.representation.Function = (
            lambda name, parent: ThonnyCompletion(name=name, parent=parent, description="")
        )

# Generated at 2022-06-24 07:53:29.310889
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion(None, None, None, None, None, None)
    assert c['name'] == None

# Generated at 2022-06-24 07:53:36.024608
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import numpy\n numpy.array([]).tr{}".format('a'*10)

# Generated at 2022-06-24 07:53:41.614222
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    testCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert testCompletion["name"] == "name"
    assert testCompletion["complete"] == "complete"
    assert testCompletion["type"] == "type"
    assert testCompletion["description"] == "description"
    assert testCompletion["parent"] == "parent"
    assert testCompletion["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:43.413588
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.common import jedi_utils as jediutils


# Generated at 2022-06-24 07:53:45.721042
# Unit test for function parse_source
def test_parse_source():
    assert "class" in parse_source("class C: pass").children[0].type


# TODO: coverage for the below


# Generated at 2022-06-24 07:53:46.287835
# Unit test for function parse_source

# Generated at 2022-06-24 07:53:52.051093
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        # TODO: complete unit test for older jedi
        pass
    else:
        # It's slightly different for newer jedi
        interpreter = jedi.Interpreter("print('hello')", [])
        completions = interpreter.complete(column=0)
        assert len(completions) > 100
        completions = interpreter.complete(column=1)
        assert len(completions) > 100
        completions = interpreter.complete(column=2)
        assert len(completions) > 100
        completions = interpreter.complete(column=3)
        assert len(completions) > 100
        completions = interpreter.complete(column=4)
        assert len(completions) > 100

# Generated at 2022-06-24 07:53:56.341764
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.test_utils import assertEqual
    from thonny import get_workbench
    import sys

    completions = get_interpreter_completions(
        "import sys",
        [
            {
                "namespaces": [{"name": "locals", "type": "dict", "items": []}],
                "path": sys.executable,
            }
        ],
    )


# Generated at 2022-06-24 07:54:06.433135
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_basic(self):
            source = "import os"
            namespaces = []

# Generated at 2022-06-24 07:54:16.996712
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import mock
    from parso.python.tree import ImportFrom

    import jedi

    # Create a mock object for jedi.Interpreter
    script = mock.MagicMock()
    script.complete = mock.MagicMock(return_value=[])
    interpreter = jedi.Interpreter = mock.MagicMock(return_value=script)

    source = "import os; os."

# Generated at 2022-06-24 07:54:20.975549
# Unit test for function get_script_completions
def test_get_script_completions():
    import os, sys, unittest

    # Test Case - 1
    source = "import SimpleHTTPServer\nimport http.server\nimport socketserver\nimport SocketServer"
    row = get_script_completions(source, 0, 0, "test_file")
    for a in row:
        print(a)

    # Test Case - 2
    source = "import os\nos.p"
    row = get_script_completions(source, 0, 0, "test_file")
    for a in row:
        print(a)

    # Test Case - 3
    source = "from tkinter import *\nfrom tkinter.ttk import *\nfrom tkinter.tix import *\nlb=Listbox()\nlb."

# Generated at 2022-06-24 07:54:29.110755
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert tc["name"] == name
    assert tc["complete"] == complete
    assert tc["type"] == type
    assert tc["description"] == description
    assert tc["parent"] == parent
    assert tc["full_name"] == full_name

# Generated at 2022-06-24 07:54:36.064365
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(
        name="abc",
        complete="abc",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    ).name == "abc"
    assert ThonnyCompletion(
        name="abc",
        complete="abc",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    ).complete == "abc"
    assert ThonnyCompletion(
        name="abc",
        complete="abc",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    ).type == "type"

# Generated at 2022-06-24 07:54:40.315176
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    foo_completion = ThonnyCompletion("foo", "foo", "type", "description", "parent", "full_name")
    assert foo_completion.name == "foo"
    assert foo_completion.complete == "foo"
    assert foo_completion.type == "type"
    assert foo_completion.description == "description"
    assert foo_completion.parent == "parent"
    assert foo_completion.full_name == "full_name"

# Generated at 2022-06-24 07:54:40.721089
# Unit test for function get_definitions

# Generated at 2022-06-24 07:54:49.692835
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        @unittest.skipIf(sys.version_info.minor < 8, "This works only with python 3.8")
        def test_get_definitions_signature(self):
            from jedi import __version__
            from jedi.inference.value import ModuleValue
            from jedi.api.project import Project

            if __version__[0:4] == "0.17":
                self.skipTest("jedi version 0.17 does not support completion for signature")

            script = jedi.Script("from test import a; a")
            definitions = script.infer(0, len("a"))

            self.assertIsInstance(definitions, list)
            self.assertEqual(len(definitions), 1)
           

# Generated at 2022-06-24 07:55:00.456627
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.python.tree import NodeOrLeaf
    from parso.utils import split_lines

    def create_node(start_line, start_column, end_line, end_column, type=None):
        start_pos = (start_line, start_column)
        end_pos = (end_line, end_column)

        class Source:
            def __init__(self, code):
                self.code = code

        if type is None:
            type = tree.Expr

        node = NodeOrLeaf(type, start_pos, end_pos, '')
        node.source = Source('\n'.join(split_lines(code, keepends=True)))
        return node


# Generated at 2022-06-24 07:55:05.272142
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = """
    class Klass():

        def method(self):
            pass
        """
    namespaces = [{"Klass": Klass}]
    completions = get_interpreter_completions(source, namespaces)
    assert any(item.name == "Klass" for item in completions)
    assert any(item.name == "method" for item in completions)

# Generated at 2022-06-24 07:55:06.096880
# Unit test for function parse_source
def test_parse_source():
    import parso

# Generated at 2022-06-24 07:55:14.165548
# Unit test for function get_definitions
def test_get_definitions():
    import networkx as nx
    import matplotlib
    import matplotlib.pyplot as plt
   
    if True:
        source = 'import networkx as nx\nimport matplotlib\nimport matplotlib.pyplot as plt\na=[1,2,3]\nb=a\nplt.plot(a)\n\n'
        row = 10
        column = 4
        filename = 'test.py'
        print(get_script_completions(source, row, column, filename))
        #print(get_definitions(source, row, column, filename))

# Generated at 2022-06-24 07:55:20.061377
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion(
        name='name', complete='complete', type='type',
        description='description', parent='parent', full_name='full_name'
    )

    assert completion['name'] == 'name'
    assert completion['complete'] == 'complete'
    assert completion['type'] == 'type'
    assert completion['description'] == 'description'
    assert completion['parent'] == 'parent'
    assert completion['full_name'] == 'full_name'

# Generated at 2022-06-24 07:55:27.159461
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:55:29.870718
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import jedi
    

# Generated at 2022-06-24 07:55:34.052536
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    # Test the branch with multiple functions; test the branch with the flow

    source = "def foo():\n    if True:\n        pass\ndef bar():\n    pass\n"
    result = jedi.Script(source, 5, 0, "").call_signatures()
    result = [sig.index for sig in result]
    assert result == [2], result

# Generated at 2022-06-24 07:55:35.928875
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("", 0, 0, "foo.py")
    assert completions



# Generated at 2022-06-24 07:55:39.402136
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import tempfile
    import jedi
    import parso

    version = jedi.__version__
    if version[:3] == "0.16":
        from jedi import api_classes

    def create_file(code):
        fd, fn = tempfile.mkstemp(".py")
        os.write(fd, code.encode())
        os.close(fd)
        return fn


# Generated at 2022-06-24 07:55:45.364170
# Unit test for function get_script_completions
def test_get_script_completions():
    def check(source, row, column, expected_completions, sys_path=None):
        completions = get_script_completions(source, row, column, "test.py", sys_path=sys_path)
        completions = [c.name for c in completions]
        assert sorted(completions) == sorted(expected_completions)

    check(
        "import p; p.s",
        0,
        13,
        ["split", "splitlines", "splitlines", "splitlines", "splitlines"],
        sys_path=["python3.7/site-packages"],
    )



# Generated at 2022-06-24 07:55:55.353860
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Completion:
        def __init__(self, name: str, complete: str, type, description, parent, full_name):
            self.name = name
            self.complete = complete
            self.type = type
            self.description = description
            self.parent = parent
            self.full_name = full_name

        def __getitem__(self, key):
            return self.__dict__[key]

    test_object = Completion("name", "complete", "type", "description", "parent", "full_name")

    assert test_object["name"] == "name"
    assert test_object["complete"] == "complete"
    assert test_object["type"] == "type"
    assert test_object["description"] == "description"
    assert test_object["parent"] == "parent"
    assert test_

# Generated at 2022-06-24 07:56:03.988163
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Completion

    source = """
import os
os."""

    completions = get_script_completions(source, 2, 6, "test.py")

    assert all([isinstance(c, ThonnyCompletion) for c in completions])
    assert len(completions) > 10
    assert any([c.name == "sep" for c in completions])
    assert any([c.name == "stat" for c in completions])
    assert any([c.name == "mkdir" for c in completions])
    assert not any([c.name == "stat=" for c in completions])
    assert any([c.name == "mkdir=" for c in completions])



# Generated at 2022-06-24 07:56:05.599029
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi


# Generated at 2022-06-24 07:56:13.715851
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from unittest.mock import Mock

    node = Mock()
    node.children = []
    pos = Mock()
    pos.start_pos = (1, 2)
    pos.end_pos = (3, 4)
    pos.type = 'classdef'
    node.children.append(pos)

    pos2 = Mock()
    pos2.start_pos = (1, 3)
    node.children.append(pos2)

    pos3 = Mock()
    pos3.start_pos = (1, 1)
    node.children.append(pos3)

    assert get_statement_of_position(node, (1, 2)) == pos2
    assert get_statement_of_position(node, (1, 3)) == pos

# Generated at 2022-06-24 07:56:16.758728
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree


# Generated at 2022-06-24 07:56:26.222079
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import sys
    import re
    import jedi

    # example of CPython sys.path
    sys_path = ['/Users/Kali/Library/Python/3.6/lib/python/site-packages']
    source = 'import re\n' + 're.'

    if jedi.__version__[:4] not in ['0.13', '0.14', '0.15', '0.16', '0.17']:
        completions = get_interpreter_completions(source, [{}], sys_path)
        assert completions
        assert any('IGNORECASE' in c.name for c in completions)
        assert any('compile' in c.name for c in completions)


# Generated at 2022-06-24 07:56:27.086603
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso


# Generated at 2022-06-24 07:56:28.206053
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

# Generated at 2022-06-24 07:56:35.096220
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    utils = __import__("thonny.jedibackend").jedibackend.utils
    assert len(utils.get_interpreter_completions("import unittest", [])) > 0
    assert len(utils.get_interpreter_completions("import unittest", [])) == len(utils.get_interpreter_completions("import unittest", [], sys_path=[""]))



# Generated at 2022-06-24 07:56:44.751340
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    class Completion:
        name = "name"
        complete = "complete"
        type = "type"
        description = "description"
        parent = "parent"
        full_name = "full_name"

    c = Completion()
    assert c.name == "name"
    assert c.complete == "complete"
    assert c.type == "type"
    assert c.description == "description"
    assert c.parent == "parent"
    assert c.full_name == "full_name"
    tc = ThonnyCompletion(c.name, c.complete, c.type, c.description, c.parent, c.full_name)
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "description"


# Generated at 2022-06-24 07:56:48.126680
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree as tree
    from parso.utils import search_ancestor

    filename = "dummy_filename.py"

# Generated at 2022-06-24 07:56:56.049163
# Unit test for function get_script_completions
def test_get_script_completions():
    # Test for current and older jedi
    import jedi

    if _using_older_jedi(jedi):
        from jedi.parser.python import tree
    else:
        from parso.python import tree

    example_lines = [
        "# This is a test file",
        "a_variable = 10",
        "a_variable.real",
    ]
    source = "\n".join(example_lines)

    script = jedi.Script(source, 1, 14, "test.py")

    defs = script.goto_definitions()
    assert len(defs) == 1

    completion = get_script_completions(source, 1, 14, "test.py")[0]
    assert completion.name == "real"
    assert completion.complete == "real"

    completion = get_script_

# Generated at 2022-06-24 07:57:04.428367
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = []
    assert get_interpreter_completions("dict(key1=") == [ThonnyCompletion(name='key1', complete='key1', type='param', description='str', parent='dict')]
    assert get_interpreter_completions("dict(key1=1, key2=") == [ThonnyCompletion(name='key2', complete='key2', type='param', description='str', parent='dict')]
    assert get_interpreter_completions("dict(key1=1, key2='2', key3=") == [ThonnyCompletion(name='key3', complete='key3', type='param', description='str', parent='dict')]

# Generated at 2022-06-24 07:57:14.717394
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc1 = ThonnyCompletion(
        name="name1",
        complete="complete1",
        type="type1",
        description="description1",
        parent="parent1",
        full_name="full_name1",
    )
    tc2 = ThonnyCompletion(
        name="name2",
        complete="complete2",
        type="type2",
        description="description2",
        parent="parent2",
        full_name="full_name2",
    )
    assert tc1.name == "name1"
    assert tc2.name == "name2"
    assert tc1.complete == "complete1"
    assert tc2.complete == "complete2"
    assert tc1.type == "type1"
    assert tc2.type == "type2"

# Generated at 2022-06-24 07:57:25.289324
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    
    jedi.settings.additional_dynamic_modules =[]
    assert jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]
    
    source = "import datetime"
    namespaces = [{}]
    result = get_interpreter_completions(source, namespaces, [])
    assert result[0].name == "datetime"
    
    source = "import sys, datetime"
    result = get_interpreter_completions(source, namespaces, [])
    assert result[0].name == "datetime"
    
    source = "datetime."
    result = get_interpreter_completions(source, namespaces, [])

# Generated at 2022-06-24 07:57:31.370180
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    t = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert t.name == 'name'
    assert t.complete == 'complete'
    assert t.type == 'type'
    assert t.description == 'description'
    assert t.parent == 'parent'
    assert t.full_name == 'full_name'

# Generated at 2022-06-24 07:57:39.102651
# Unit test for function parse_source
def test_parse_source():
    source = 'print("hello")'
    script = parse_source(source)

    assert script is not None
    assert script.type == "file_input"
    assert isinstance(script.children[0], tree.SimpleStatement)
    assert isinstance(script.children[0].children[0], tree.ExprStmt)
    assert isinstance(script.children[0].children[0].children[0], tree.Call)
    assert isinstance(script.children[0].children[0].children[0].children[0], tree.Name)
    assert script.children[0].children[0].children[0].children[0].value == "print"

# Generated at 2022-06-24 07:57:41.938122
# Unit test for function parse_source
def test_parse_source():
    source = 'import sys; sys.path'
    ast = parse_source(source)
    assert isinstance(ast, str)



# Generated at 2022-06-24 07:57:53.140669
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter

    # test for jedi version >=0.17
    # for older jedi versions, this test is skipped
    if hasattr(Interpreter, "completions"):
        source = "import datetime"
        namespaces = [{"datetime": datetime}]
        completions = get_interpreter_completions(source, namespaces)
        assert len(completions) == 1
        assert completions[0].name == "datetime"
        assert completions[0].complete == "import datetime"
        assert completions[0].full_name == "datetime"
        assert completions[0].type == "module"
        assert completions[0].description == "datetime"
        assert completions[0].parent is None

        source = "datetime.timed"
       

# Generated at 2022-06-24 07:57:58.957178
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "def foo(a,c=1,d=2):pass;foo(42)"
    completions = get_script_completions(source, 1, 15, "test.py", ['/'])
    assert set([c.complete for c in completions]) == set(["a", "c=", "d="])

# Generated at 2022-06-24 07:58:02.448045
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    x = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert x.name == "name"
    assert x.complete == "complete"
    assert x.type == "type"
    assert x.description == "description"
    assert x.parent == "parent"
    assert x.full_name == "full_name"



# Generated at 2022-06-24 07:58:05.617517
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python.tree import Module

    def _is_valid(node, start, end):
        return node.type in ("simple_stmt", "expr_stmt") \
            and node.start_pos <= start and node.end_pos >= end


# Generated at 2022-06-24 07:58:10.592935
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "import"
    row, column = 1, len(source)
    filename = 'nofile'
    completions = get_script_completions(source, row, column, filename)
    assert len(completions) > 0
    assert completions[0].name == "sys"


# Generated at 2022-06-24 07:58:11.621620
# Unit test for function parse_source

# Generated at 2022-06-24 07:58:16.131045
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase
    import jedi

    class TestCompletion(TestCase):
        def test_get_script_completions_method(self):
            completions = get_script_completions("def foo():\n    p", 1, 6, "example.py")
            self.assertEqual(completions[0].complete, "pass")


# Generated at 2022-06-24 07:58:19.457590
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion("a", "b", "c", "d", "e", "f")
    result = thonnyCompletion.__getitem__("name")
    assert result == "a"

# Generated at 2022-06-24 07:58:26.297356
# Unit test for function get_definitions
def test_get_definitions():
    global get_definitions

    from unittest import TestCase

    class GetDefinitionsTest(TestCase):
        def test_builtin(self):
            definitions = get_definitions("abs(", 1, 4, "<string>")
            self.assertEqual(1, len(definitions))
            self.assertEqual("__builtin__.builtins.abs", definitions[0].full_name)
            self.assertEqual("builtins.abs", definitions[0].type)

        def test_local(self):
            definitions = get_definitions("def f():\n    x = 1", 2, 10, "<string>")
            self.assertEqual(1, len(definitions))
            self.assertEqual("f.<locals>.x", definitions[0].full_name)

# Generated at 2022-06-24 07:58:35.775335
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny.jedi_utils import get_interpreter_completions

    namespaces = [{"a": 123, "b": {"c": "abc", "d": [1, 2, 3]}}]
    completions = get_interpreter_completions("b.c.islower()", namespaces)
    assert len(completions) >= 1
    assert completions[0].complete == "islower()"

    completions = get_interpreter_completions("b.d.sort()", namespaces)
    assert len(completions) >= 1
    assert completions[0].complete == "sort()"

    # None of these calls should ever raise Exception (even when sys_path is None)

# Generated at 2022-06-24 07:58:43.139617
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock
    source = "import sys\nprint(sys.path)"
    path = "some-path"
    row = 1
    column = 8
    filename = "python.py"
    sys_path = [path]
    script = Mock()
    script.complete = Mock(return_value=[])
    script.get_script_path.return_value = path
    script.completions.return_value = [{"name": "path", "complete": "path"}]

    completions = get_script_completions(source, row, column, filename, sys_path)

    assert len(completions) == 1
    assert completions[0].name == "path"
    assert completions[0].complete == "path"



# Generated at 2022-06-24 07:58:52.671831
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['name'] == 'a'
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['complete'] == 'b'
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['type'] == 'c'
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['description'] == 'd'
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['parent'] == 'e'
    assert ThonnyCompletion('a', 'b', 'c', 'd', 'e', 'f')['full_name'] == 'f'

# Generated at 2022-06-24 07:59:02.919011
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import get_sys_path
    from os.path import join
    from sys import executable
    from thonny import get_runner
    from thonny.plugins.micropython import MicroPythonProxy

    runner = get_runner()
    if runner:
        micro_python_proxy = MicroPythonProxy(runner)
        micro_python_sys_path = micro_python_proxy.get_sys_path()
    else:
        micro_python_sys_path = get_sys_path(python_path=executable)

    print(
        get_definitions(
            "import os.path",
            1,
            0,
            join(micro_python_sys_path[0], 'os', 'path', '__init__.py')
        )
    )

# Generated at 2022-06-24 07:59:03.803092
# Unit test for function parse_source

# Generated at 2022-06-24 07:59:11.850910
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'name'
    complete = 'complete'
    _type = 'type'
    description = 'description'
    parent = 'parent'
    full_name = 'full_name'

    t = ThonnyCompletion(name, complete, _type, description, parent, full_name)

    assert t[0] == t.name
    assert t[1] == t.complete
    assert t[2] == t.type
    assert t[3] == t.description
    assert t[4] == t.parent
    assert t[5] == t.full_name

# Generated at 2022-06-24 07:59:15.476685
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("import os", [{"os": os}], sys_path=None)

    assert "os." in [c.complete for c in completions]

# Generated at 2022-06-24 07:59:21.424723
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_complete_1 = "test_complete_1"
    test_complete_2 = "test_complete_2"
    test_complete_3 = "test_complete_3"
    test_complete_4 = "test_complete_4"

    test_completion = ThonnyCompletion(
        name=test_complete_1,
        complete=test_complete_2,
        type=test_complete_3,
        description=test_complete_4,
        parent=None,
        full_name=None,
    )
    assert test_completion[test_complete_1] == test_complete_1

# Generated at 2022-06-24 07:59:26.674496
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name123",
        complete="complete456",
        type="type789",
        description="description101112",
        parent="parent131415",
        full_name="full_name161718",
    )

    assert completion["name"] == "name123"
    assert completion["complete"] == "complete456"
    assert completion["type"] == "type789"
    assert completion["description"] == "description101112"
    assert completion["parent"] == "parent131415"
    assert completion["full_name"] == "full_name161718"

# Generated at 2022-06-24 07:59:33.798115
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    complete = jedi.Script("im").completions()[0]
    completion = ThonnyCompletion(
        name=complete.name,
        complete=complete.complete,
        type=complete.type,
        description=complete.description,
        parent=complete.parent,
        full_name=complete.full_name,
    )
    assert completion.name == "import"



# Generated at 2022-06-24 07:59:41.144390
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__ as jedi_version
    if jedi_version[:3] == "0.1":
        assert get_script_completions("1 + 2 * 3", 2, 1, "<string>")[0].name == "1"
        assert get_script_completions("[1, 2, 3]", 2, 5, "<string>")[0].complete == "2"
        assert get_script_completions("[1, 2, 3]", 2, 5, "<string>")[0].parent == "list"
        assert get_script_completions("[1, 2, 3]", 2, 5, "<string>")[0].type == "int"

# Generated at 2022-06-24 07:59:52.005598
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree
    import parso.tree
    from jedi.parser_utils import get_statement_of_position

    class Pos(parso.python.tree.PythonNode):
        def __init__(self, pos, parent):
            self.parent = parent
            self.start_pos = pos

    class Dummy(parso.tree.BaseNode):
        def __init__(self, _type, children=None, parent=None, prefix="", start_pos=None):
            # type: (str, List[BaseNode], Optional[BaseNode]) -> None
            self.type = _type
            self.parent = parent
            self._children = children or []
            self.start_pos = start_pos

    def pos(p):
        return Pos(p, None)


# Generated at 2022-06-24 08:00:00.937927
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi, sys
    if sys.version_info[0] == 3 and sys.version_info[1] >= 8:
        t = ThonnyCompletion("a", "a=", "NAME", "", "", "")
        assert t.name == "a"
        assert t.complete == "a="
        assert t.type == "NAME"
        assert t.description == ""
        assert t.parent == ""
        assert t.full_name == ""

        # t = jedi.api.Script("a=1", 1, 1, "").completions()[0]
        t = get_script_completions("a=1", 1, 1, "")[0]
        assert t.name == "a"
        assert t.complete == "a="
        assert t.type == "NAME"

# Generated at 2022-06-24 08:00:12.271125
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def assert_equal(start_pos, end_pos, expected_start, expected_end):
        s = "x = 123"
        node = parse_source(s)
        subnode = node.get_subnode_at_position((start_pos, end_pos))
        actual = _copy_of_get_statement_of_position(node, (start_pos, end_pos))
        expected = node.get_subnode_at_position((expected_start, expected_end))
        assert subnode == actual
        assert expected == actual

    assert_equal(0, 1, 1, 2)
    assert_equal(0, 2, 1, 2)
    assert_equal(1, 2, 1, 2)
    assert_equal(1, 3, 1, 2)



# Generated at 2022-06-24 08:00:22.800748
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    from parso.python import tree

    class TestCase(unittest.TestCase):
        def run_test(self, source, scope):
            root = parse_source(source)
            result = get_statement_of_position(root, scope.end_pos)
            self.assertIs(result, scope)

        def test_name(self):
            source = "b = 1"
            self.run_test(source, parse_source(source).children[0].children[1])

        def test_function(self):
            source = "def f(): pass"
            self.run_test(source, parse_source(source).children[0])

        def test_class(self):
            source = "class C: pass"

# Generated at 2022-06-24 08:00:24.037979
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    # TODO: implement this
    pass

# Generated at 2022-06-24 08:00:34.217589
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    if _using_older_jedi(jedi):
        completions = get_script_completions("import numpy as np; x = np.arange(1,10); x.", row=2, column=14,
                                             filename="test.py")