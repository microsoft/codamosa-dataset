

# Generated at 2022-06-24 07:50:49.123451
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter, names
    from jedi.parser_utils import get_parent_scope, load_grammar
    from jedi.cache import load_module_attribute_following_imports
    from jedi._compatibility import unicode


# Generated at 2022-06-24 07:50:55.213691
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    env = {"xx": "abc"}
    completions = get_interpreter_completions("xx", [env])
    assert len(completions) > 0
    assert completions[0].parent == env

    if _using_older_jedi(jedi):
        completions = get_interpreter_completions("xx.", [env])
        assert len(completions) > 0
        assert completions[0].parent == "abc"
    else:
        completions = get_interpreter_completions("xx.", [env])
        assert len(completions) > 0
        assert completions[0].parent.py__name__() == "str"

    completions = get_interpreter_completions("xx.islower", [env])

# Generated at 2022-06-24 07:51:02.214287
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonnyCompletion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert thonnyCompletion['name'] == 'name'
    assert thonnyCompletion['complete'] == 'complete'
    assert thonnyCompletion['type'] == 'type'
    assert thonnyCompletion['description'] == 'description'
    assert thonnyCompletion['parent'] == 'parent'
    assert thonnyCompletion['full_name'] == 'full_name'

# Generated at 2022-06-24 07:51:08.272432
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert t["name"] == "name"
    assert t["complete"] == "complete"
    assert t["type"] == "type"
    assert t["description"] == "description"
    assert t["parent"] == "parent"
    assert t["full_name"] == "full_name"

# Generated at 2022-06-24 07:51:14.233215
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    jedi.settings.case_insensitive_completion = False

    # Control the case sensitivity of completions
    completions = get_script_completions(
        source="print('Hello, world')\n", row=0, column=6, filename="untitled"
    )
    assert completions[0].name == "print"
    jedi.settings.case_insensitive_completion = True
    completions = get_script_completions(
        source="print('Hello, world')\n", row=0, column=6, filename="untitled"
    )
    assert completions[0].name == "Print"

    # Test command-line completion

# Generated at 2022-06-24 07:51:23.181520
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser.python


# Generated at 2022-06-24 07:51:24.308627
# Unit test for function parse_source

# Generated at 2022-06-24 07:51:28.996817
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # jedi 0.13: ['test_completion', 'test_completion_alt1', 'test_completion_alt2']
    # jedi 18: ['test_completion', 'test_completion_alt1', 'test_completion_alt1_alt1']
    assert get_interpreter_completions("test_completion", [])[0].name == "test_completion"

# Generated at 2022-06-24 07:51:39.191534
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    class Child(tree.BaseNode):
        def __init__(self, children, pos):
            self.children: List[Child] = children
            self.pos = pos

    def f(pos):
        return get_statement_of_position(Child([], 0), pos)

    assert f(0) == None
    assert f(1) == None

    children = [Child([], 0), Child([], 10), Child([], 100)]

    assert f(1) == None
    assert f(9) == None
    assert f(10) == children[1]
    assert f(99) == children[1]
    assert f(100) == children[2]
    assert f(1000) == children[2]

# Generated at 2022-06-24 07:51:49.850836
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import TestCase
    import jedi

    def test_tuple_style(tc):
        tc.assertEqual(comp[0], 'name')
        tc.assertEqual(comp[1], 'complete')
        tc.assertEqual(comp[2], 'type')
        tc.assertEqual(comp[3], 'description')
        tc.assertEqual(comp[4], 'parent')
        tc.assertEqual(comp[5], 'full_name')
        tc.assertRaises(KeyError, comp.__getitem__, 6)
        tc.assertRaises(IndexError, comp.__getitem__, 6)

    def test_key_style(tc):
        tc.assertEqual(comp['name'], 'name')

# Generated at 2022-06-24 07:51:51.514164
# Unit test for function parse_source
def test_parse_source():
    # pylint: disable=line-too-long
    import parso


# Generated at 2022-06-24 07:51:58.048422
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("hash()", 1, 5, "")
    assert len(completions) > 0
    assert any(c.name == "hash" for c in completions)

    completions = get_script_completions("hash(", 1, 5, "")
    assert len(completions) > 0
    assert any(c.name == "hash" for c in completions)

    completions = get_script_completions("{1, 2, 3}[0]", 1, 8, "")
    assert len(completions) > 0
    assert any(c.name == "0" for c in completions)

    completions = get_script_completions("print(\"hello\".startswith(", 1, 32, "")
    assert len(completions)

# Generated at 2022-06-24 07:52:09.608384
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    from unittest.mock import MagicMock

    class Completion(object):
        def __init__(self, complete, name):
            self.complete = complete
            self.name = name
            self.description = ""
            self.description_with_module = ""
            self.module_name = ""
            self.type = ""
            self.parent = ""
            self.full_name = name

    # jedi 0.15

# Generated at 2022-06-24 07:52:18.339686
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi
    source_code = """
x = "hello"

if True:
    def f():
        x = 1
        if 1:
            print(x)

"""
    module = jedi.Script(source_code).goto_assignments()[0].get_definition()
    assert get_statement_of_position(module, position=8) is None
    assert get_statement_of_position(module, position=12).value == "True"
    assert get_statement_of_position(module, position=34).value == "x = 1"
    assert get_statement_of_position(module, position=55).value == "print(x)"

# Generated at 2022-06-24 07:52:22.155605
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import re

    source = "import math"
    row = 0
    column = len("import ma")
    script = jedi.Script(source, row, column, "test.py")

    defs = script.goto_definitions()
    assert len(defs) == 1
    assert defs[0].full_name == "math"

    source = "from math import sqrt"
    row = 0
    column = len("from math")
    script = jedi.Script(source, row, column, "test.py")

    defs = script.goto_definitions()
    assert len(defs) == 1
    assert defs[0].full_name == "math"

    source = "from math import sqrt\nsqrt"
    row = 1

# Generated at 2022-06-24 07:52:32.001126
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import Script

    # The reason of this test is to ensure function get_script_completions works as expected.
    # jedi currently only supports Python 3.5 or later and the
    # get_script_completions is only used in autocompletion, so testing the autocompletion
    # in Python 2 is enough.


# Generated at 2022-06-24 07:52:39.729690
# Unit test for function get_definitions
def test_get_definitions():
    """
    >>> len(get_definitions('a=1; a', 1, 3, "test.py"))
    1
    >>> get_definitions('a=1; a', 1, 3, "test.py")[0].desc_with_module
    'int'
    >>> len(get_definitions('a=1; a\\nimport datetime', 2, 3, "test.py"))
    1
    >>> get_definitions('a=1; a\\nimport datetime', 2, 3, "test.py")[0].desc_with_module
    'module'
    """
    pass

# Generated at 2022-06-24 07:52:40.404639
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("import re").get_code() == "import re\n"

# Generated at 2022-06-24 07:52:47.788089
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnyCompletion.name == "name"
    assert thonnyCompletion.complete == "complete"
    assert thonnyCompletion.type == "type"
    assert thonnyCompletion.description == "description"
    assert thonnyCompletion.parent == "parent"
    assert thonnyCompletion.full_name == "full_name"
    assert thonnyCompletion["name"] == "name"
    assert thonnyCompletion["complete"] == "complete"
    assert thonnyCompletion["type"] == "type"
    assert thonnyCompletion["description"] == "description"
    assert thonnyCompletion["parent"] == "parent"
    assert th

# Generated at 2022-06-24 07:52:57.463839
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.languages import tr_lang

    # Test different versions of jedi
    from importlib import import_module

    old_jedi = import_module("jedi")

    # Test with old version of Jedi
    from thonny.jedi_utils import get_script_completions

    s = "import os\nos.listdir('')"
    completions = get_script_completions(s, 2, 14, "test.py")
    assert len(completions) > 2
    assert completions[0].name == "os.listdir"
    assert completions[0].complete == "os.listdir('')"
    assert completions[1].name == "os.listdir"
    assert completions[1].complete == "os.listdir('')"

    # Test with new version of Jedi

# Generated at 2022-06-24 07:53:07.282348
# Unit test for function parse_source
def test_parse_source():
    import parso
    sample = "from x import y\nimport numpy as np\nfrom matplotlib import pyplot as plt"
    with open("test.py", "w") as file:
        file.write(sample)
    root_node = parse_source(sample)
    assert (
        isinstance(root_node, parso.python.tree.Module)
    ), "Root node of the AST tree is not of type Module."
    with open("test.py", "r") as file:
        sample = file.read()
    os.remove("test.py")
    line_offset = sample.index("import")
    assert line_offset == root_node[0].start_pos[0] - 1, "First import start position is incorrect."
    line_offset = sample.index("as np")

# Generated at 2022-06-24 07:53:14.967007
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:53:22.424980
# Unit test for function get_definitions
def test_get_definitions():
    print("Unit test for function get_definitions")
    print("Skipping unit tests for function get_definitions - for more details see #738")
    # import sys
    # sys.path.append("/Users/nestor/git/thonny-jedi-remoteprocess/python")
    # from remote_jedi_client import jedi_utils
    # ls = jedi_utils.get_definitions("foo = 1\nprint(foo)\n", 2, 8, "foo.py")
    # print("Definitions for print(foo):")
    # for x in ls:
    #     print("\t" + x.description)
    #
    # ls = jedi_utils.get_definitions("foo = 1\nprint(foo)\n", 1, 5, "foo.py")
   

# Generated at 2022-06-24 07:53:23.779632
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert isinstance(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name"), object)

# Generated at 2022-06-24 07:53:29.630265
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"



# Generated at 2022-06-24 07:53:36.154262
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import Project

    filename = "test.py"
    row = 8
    column = 13
    def_location = row, column
    source = """
    import sys, os
    import json


    class A(object):
        def __init__(self, first_name, last_name):
            self.first_name = first_name
            self.last_name = last_name

        def __str__(self):
            return "{self.first_name} {self.last_name}".format(self=self)


    a = A('John', 'Doe')
    print(a)


    def test_func(first_name, last_name):
        return '{} {}'.format(first_name, last_name)
    """


# Generated at 2022-06-24 07:53:39.762689
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from tkinter import Tk
    import time

    source = "import math\nmath.sin"
    root = Tk()
    root.withdraw()
    time.sleep(0.1)
    completions = get_interpreter_completions(source, [], sys_path=[])
    assert len(completions) == 1
    assert completions[0].type == "function"
    assert completions[0].name == "sin(x, /)"


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 07:53:50.651496
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    try:
        get_statement_of_position
    except NameError:
        # should not get here because get_statement_of_position
        # should be available in this module
        raise RuntimeError("get_statement_of_position not available")

    source = "for x in range(10):\n    x*2\n"
    # point after "2"
    point = len(source) - 2
    node = parso.parse(source)

    res = get_statement_of_position(node, point)
    if not res:
        raise AssertionError("get_statement_of_position returned None")

    res_text = source[res.start_pos:res.end_pos].strip()

# Generated at 2022-06-24 07:53:58.432343
# Unit test for function get_definitions
def test_get_definitions():
    # jedi 18.11.0 and earlier
    assert get_definitions("x", 0, 1, "test") == []
    assert get_definitions("def f():\n    x = 1\nx", 2, 1, "test")[0].line == 1
    assert get_definitions("def f():\n    x = 1\nx", 2, 1, "test")[0].column == 4
    assert get_definitions("def f():\n    x = 1\nx", 2, 1, "test")[0].description == "int"
    assert get_definitions("def f():\n    x = 1\nx", 2, 1, "test")[0].type == "statement"

# Generated at 2022-06-24 07:54:08.350346
# Unit test for function get_definitions
def test_get_definitions():
    print("Testing function get_definitions")
    import jedi

    if _using_older_jedi(jedi):
        print('Using older jedi')
    else:
        print('Using new jedi')

    from os.path import abspath, basename, dirname
    from sys import version
    from time import time

    start_time = time()
    file_name = "/usr/local/bin/python"
    source = open(file_name).read()

    stdout = ''
    for i in range(100):
        definitions = get_definitions(source, 1, 1, file_name)
        stdout += "\n".join(["{0}.{1}".format(i, x) for i, x in enumerate(definitions)])
        i += 1
    end_time = time()


# Generated at 2022-06-24 07:54:14.341109
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "import datetime\ndatetime.timedelta(1) + datetime.d"
    completions = get_interpreter_completions(source, [])
    assert len(completions) >= 1
    assert "date" == completions[0].complete
    assert "date" in completions[0].name
    assert "datetime.date" == completions[0].full_name

# Generated at 2022-06-24 07:54:20.801198
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    if _using_older_jedi(jedi):
        import jedi.api.classes
        if isinstance(get_script_completions("s", 1, 2, "d")[0], jedi.api.classes.Completion):
            assert True
        else:
            assert False
    else:
        import jedi.api.classes
        if isinstance(get_script_completions("s", 1, 2, "d")[0], jedi.api.classes.Completion):
            assert True
        else:
            assert False

if __name__ == '__main__':
    test_get_script_completions()

# Generated at 2022-06-24 07:54:31.808620
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    def check(source, pos, expected_result):
        """
        Tests that get_statement_of_position returns expected_result
        for given source and pos

        source -- either python source or parso.tree.Node
        pos -- position in source
        expected_result -- either parso.tree.Node or None
        """
        if isinstance(source, str):
            import parso

            source = parso.parse(source)

        assert isinstance(source, tree.Node)

        result = get_statement_of_position(source, pos)

        if expected_result is None:
            assert result is None
        else:
            assert result.type == expected_result

    check("def a():\n  pass\n  pass", 6, None)

# Generated at 2022-06-24 07:54:33.160130
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi


# Generated at 2022-06-24 07:54:42.310826
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if _using_older_jedi(jedi):
        answer = [
            ThonnyCompletion(
                name="a", complete="a ", type="module", parent=None, full_name="a"
            ),
            ThonnyCompletion(
                name="b", complete="b ", type="module", parent=None, full_name="b"
            ),
            ThonnyCompletion(
                name="c", complete="c ", type="module", parent=None, full_name="c"
            ),
        ]
        assert get_interpreter_completions(
            "import a, b, c",
            [{"a": 3, "b": [4, 5], "c": {"d": 6, "e": "text"}}],
        ) == answer


# Generated at 2022-06-24 07:54:51.601990
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.helpers import is_keyword

    completions = get_script_completions("import os; os.", 0, 0, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    for e in completions:
        assert isinstance(e, ThonnyCompletion)

    completions = get_script_completions("import os; os.", 1, 6, "")
    assert isinstance(completions, list)
    assert len(completions) > 0
    for e in completions:
        assert isinstance(e, ThonnyCompletion)

    completions = get_script_completions("import os; os.", 1, 5, "")
    assert isinstance(completions, list)
    assert len(completions) == 0

# Generated at 2022-06-24 07:55:02.947942
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import tests.test_utils as test_utils
    import parso.python
    import jedi.parser_utils
    import jedi

    class TestStatementOfPosition(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            # Must be a class var and not in setUp() to
            # avoid different results on different jedi versions
            if hasattr(jedi.parser_utils, "get_statement_of_position"):
                self.initial_function = jedi.parser_utils.get_statement_of_position
            else:
                self.initial_function = None

        def setUp(self):
            jedi.parser_utils.get_statement_of_position = _copy_of_get_

# Generated at 2022-06-24 07:55:04.176278
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    assert len(get_interpreter_completions("1+", [])) >= 10

# Generated at 2022-06-24 07:55:07.071664
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi

    if not _using_older_jedi(jedi):
        script = jedi.Script(code="import thonny; thonny.")
        completions = script.complete(line=1, column=13)
        assert completions[0].name == "RELEASE"

# Generated at 2022-06-24 07:55:14.965567
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    result = get_interpreter_completions(source='print(", ".join(["a", "b"]))', namespaces=[{'print': print}])
    assert "join" in [c.complete for c in result]
    result = get_interpreter_completions('import os', namespaces=[{'print': print}])
    assert "os." in [c.complete for c in result]
    result = get_interpreter_completions('import os.path', namespaces=[{'print': print}])
    assert "os.path." in [c.complete for c in result]
    result = get_interpreter_completions('import os.path', namespaces=[{'os': os}])

# Generated at 2022-06-24 07:55:24.654597
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    if jedi.__version__ >= "0.18":
        from parso import parse # from parso import parse as parso_parse
        from jedi import Project
        from jedi.api import Script
        #from importlib.resources import read_text
        #from . import resources
        
        #from . import helloworld
        #from . import helloworld # - hello.py:4: warning: module 'helloworld' has no attribute 'helloworld'
        #from helloworld import helloworld
        
        #from helloworld import helloworld
        #from helloworld.helloworld import helloworld
        
        #from helloworld import helloworld as HelloWorld
        #from helloworld.helloworld import helloworld as HelloWorld
        #from helloworld.hellow

# Generated at 2022-06-24 07:55:29.566747
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completions = get_script_completions("from math import *;a=cos(2)", 3, 5, "")
    for completion in completions:
        try:
            completion["haha"]
        except KeyError:
            continue
        else:
            assert False
    completions = get_script_completions("from math import *;a=cos(2)", 3, 5, "")
    for completion in completions:
        completion["haha"] = 'hahaha'
        assert completion["haha"] == 'hahaha'

# Generated at 2022-06-24 07:55:34.619743
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """jedi version 0.17 and 0.18 have a different return type for this function,
    and the name attribute of completion may have different value (for completions
    concerning default parameters). So let's test that the returned results are
    similar."""

    import jedi

    source = "range(1, 10, step=3)"
    namespaces = [{"locals": jedi.Interpreter("", []).get_namespace_variables()}]

    # get completions from different versions of jedi
    older_completions = get_interpreter_completions(source, namespaces)
    newer_completions = get_interpreter_completions(source, namespaces)

    # check name attributes, they may have different value, but in any case,
    # the 'name' attribute should have the same value in both versions

# Generated at 2022-06-24 07:55:37.037980
# Unit test for function get_script_completions
def test_get_script_completions():
    completions = get_script_completions("pass", row=1, column=5, filename="<string>")
    assert completions
    completion = completions[0]
    assert completion.name == "pass"
    assert completion.complete == "pass"



# Generated at 2022-06-24 07:55:40.297536
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"

    a = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert a.name == name
    assert a.complete == complete
    assert a.type == type
    assert a.description == description
    assert a.parent == parent
    assert a.full_name == full_name

# Generated at 2022-06-24 07:55:44.890840
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Token
    from thonny import get_workbench


# Generated at 2022-06-24 07:55:50.273497
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys

    completions = get_script_completions(
        "from math import *\npi", 1, 14, "<test_file>", sys_path=[""]
    )
    assert len(completions) > 0, completions
    assert completions[0].name == "pi", completions

# Generated at 2022-06-24 07:55:58.845065
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.parser_utils import get_parent_scope

    source = "import datetime\ndatetime.dateti"
    namespaces = [{"foo": 1234}]

    completions = get_interpreter_completions(source, namespaces)

# Generated at 2022-06-24 07:56:07.790179
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os

    # Get the path of the file in the test/ folder
    path_cwd = os.path.abspath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    file_path = path_cwd + "/get_def.py"

    # Indicate the line of code you want to know the definition of
    row = 6
    column = 5
    # Open the file and read it
    with open(file_path, "r") as file:
        source = file.read()
    # Test the function
    if _using_older_jedi(jedi):
        script = jedi.Script(source, row, column, file_path)
        print(script.goto_definitions())
    else:
        script = jedi.Script

# Generated at 2022-06-24 07:56:14.593265
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import jedi
    tc = _tweak_completions(jedi.Script("a = 3+2").completions())[0]
    assert tc.name == "int"
    assert tc.complete == "int"
    assert tc.type == "<class 'int'>"
    assert tc.description == "int(x=0) -> integer\nint(x, base=10) -> integer"
    assert tc.parent == "builtins"
    assert tc.full_name == "builtins.int"

# Generated at 2022-06-24 07:56:15.617237
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:56:26.014218
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils

    # For jedi 0.18 it's defined directly in jedi
    if not hasattr(jedi.parser_utils, "get_statement_of_position"):

        def _check(code, pos, expected):
            node = parse_source(code)
            got = get_statement_of_position(node, pos)
            assert got.start_pos == expected

        _check("foo(", 2, 0)
        _check("foo(1,2)", 4, 0)
        _check("foo(a=1,2)", 4, 0)
        _check("foo(a=1,2)", 7, 6)
        _check("foo(a=foo(1,2))", 4, 0)
        _check("foo(a=foo(1,2))", 8, 0)
       

# Generated at 2022-06-24 07:56:28.122319
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    node = parse_source('def f():\n    pass\n')
    assert get_statement_of_position(node, (2, 4)) is node.children[1].children[0].children[0]

# Generated at 2022-06-24 07:56:30.651979
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    py_node = _copy_of_get_statement_of_position(
        tree.Module("").children[0], (1, 10)
    )
    assert isinstance(py_node, tree.ExprStmt)

# Generated at 2022-06-24 07:56:41.505963
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    This function should work regardless of the installed version of jedi.
    """
    from unittest import TestCase

    # NB! this test might fail if you ran something with tests on the same folder and jedi doesn't implement reload
    class Test(TestCase):
        """
        The names below should be the same as in thonny_test.py
        """


# Generated at 2022-06-24 07:56:51.771899
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree
    from parso import parse

    script = """
    class C:
        """

    node = parse(script, version="3.9")
    assert isinstance(get_statement_of_position(node.children[0], 4), tree.Flow)

    script = """
    if cond:
        pass
    else:
        pass

    tmp = 1
    """

    node = parse(script, version="3.9")
    assert isinstance(get_statement_of_position(node, len("\n\n")), tree.ExprStmt)

    script = """
    while cond:
        pass
    else:
        pass

    tmp = 1
    """

    node = parse(script, version="3.9")

# Generated at 2022-06-24 07:56:52.518960
# Unit test for function get_script_completions

# Generated at 2022-06-24 07:56:57.948316
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.jedi_utils import get_script_completions
    source = "from turtle import "
    completions = get_script_completions(source, 0, 18, "")
    assert isinstance(completions, list)
    # Should contain at least "Turtle()"
    for item in completions:
        if item['complete'] == "Turtle()":
            break
    else:
        assert False

# Generated at 2022-06-24 07:57:05.308008
# Unit test for function get_definitions
def test_get_definitions():
    import sys
    import os
    import json

    here = os.path.dirname(__file__)
    test_folder = os.path.join(here, "jedi_test_files")

    success_count = 0
    fail_count = 0

    for (dirpath, dirnames, filenames) in os.walk(test_folder):
        for filename in filenames:
            if filename.startswith("definitions"):
                print("Testing file: %s" % filename)

                with open(os.path.join(dirpath, filename)) as f:
                    code = f.read()

                with open(os.path.join(dirpath, filename.replace("definitions", "results"))) as f:
                    expected = json.load(f)


# Generated at 2022-06-24 07:57:13.463782
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    node = parse_source("abc")
    assert isinstance(node, tree.Module)
    assert node.children[0].type == "simple_stmt"
    assert node.children[0].children[0].type == "expr_stmt"
    assert node.children[0].children[0].children[0].type == "atom"
    assert node.children[0].children[0].children[0].children[0].type == "name"
    assert node.children[0].children[0].children[0].children[0].value == "abc"

# Generated at 2022-06-24 07:57:18.770122
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "a = 0\na.repl"
    completions = get_script_completions(source, 1, 5, "")
    assert len(completions) > 0
    assert completions[0].name == "replace("


# Generated at 2022-06-24 07:57:26.946996
# Unit test for function get_definitions
def test_get_definitions():
    from unittest import TestCase
    from unittest.mock import MagicMock

    def make_comp_with_name(name: str):
        comp = MagicMock()
        comp.name = name
        comp.type = "function"
        return comp

    def make_def_with_module(name: str, module: str):
        defn = MagicMock()
        defn.module_name = module
        defn.description = "description"
        defn.line = 10
        defn.module_path = "module_path"
        defn.name = name
        defn.type = "function"
        defn.full_name = name
        defn.docstring = ""
        defn.in_builtin_module = False

# Generated at 2022-06-24 07:57:37.425375
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("a = 10\n\na.", 0, 0, "") == []
    assert get_script_completions("a = 10\n\na.", 1, 2, "") == []

    assert get_script_completions("a = 10\ny = 20\nz = a", 0, 1, "") == []
    assert get_script_completions("a = 10\ny = 20\nz = a", 2, 5, "") == [
        ThonnyCompletion(
            name="a",
            complete="a",
            type="instance",
            description="int",
            parent="int",
            full_name="int",
        )
    ]

    # In jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
    # since 0.16

# Generated at 2022-06-24 07:57:43.932848
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi
    completion = jedi.Script("print()").completions()[0]
    def_obj = ThonnyCompletion(
        name=completion.name,
        complete=completion.complete,
        type=completion.type,
        description=completion.description,
        parent=completion.parent,
        full_name=completion.full_name,
    )
    def_obj.name == def_obj["name"]

# Generated at 2022-06-24 07:57:47.951362
# Unit test for function get_script_completions
def test_get_script_completions():
    assert (
        get_script_completions("x = int()", 0, 6, "/tmp/x.py")[0].complete
        == "x = int()\n"
    )
    assert get_script_completions("x = int()", 0, 6, "/tmp/x.py")[0].type == "keyword"
    assert (
        get_script_completions("x = int()", 0, 6, "/tmp/x.py")[0].description
        == "int(x[, base]) -> integer\n"
    )

# Generated at 2022-06-24 07:57:50.679581
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert(ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name") \
            .__getitem__("name") == "name")

# Generated at 2022-06-24 07:58:02.097567
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse
    from parso.tree import Leaf
    from parso.utils import split_lines
    from parso.python import tree
    import unittest

    def get_statement_for_leaf(leaf):
        return get_statement_of_position(leaf.get_root_node(), leaf.start_pos[1])

    class TestGetStatementOfPosition(unittest.TestCase):
        def test_get_statement_of_position(self):
            node = parse("a = 1")
            self.assertIs(get_statement_for_leaf(node.children[0]), node.children[0])
            self.assertIs(get_statement_for_leaf(node.children[1]), node.children[1])

# Generated at 2022-06-24 07:58:05.841506
# Unit test for function parse_source
def test_parse_source():
    import parso

    source = "11\n"
    module = parse_source(source)
    assert isinstance(module, parso.python.tree.Module)
    assert module.start_pos == (1, 0)
    assert module.end_pos == (1, 0)


if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:58:16.363738
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    get_definitions('abc',1,1,'abc.py')
    test1 = ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")
    assert test1.name == "name"
    assert test1.complete == "complete"
    assert test1.type == "type"
    assert test1.description == "description"
    assert test1.parent == "parent"
    assert test1.full_name == "full_name"
    assert test1['name'] == "name"
    assert test1['complete'] == "complete"
    assert test1['type'] == "type"
    assert test1['description'] == "description"
    assert test1['parent'] == "parent"

# Generated at 2022-06-24 07:58:18.212343
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")



# Generated at 2022-06-24 07:58:22.816697
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = """
        import os
        os.li
    """
    namespaces = [{'os': jedi.Interpreter('os', []).namespace()}]
    
    completions = get_interpreter_completions(source, namespaces)
    assert [c.name for c in completions] == ['listdir']

# Generated at 2022-06-24 07:58:29.353926
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso import parse

    source = "some_text\n" + "some_more_text\n"
    pos = len(source) - 5
    module = parse(source)
    node = get_statement_of_position(module, pos)
    assert node.type == "suite", "Wrong node type"
    assert node.start_pos <= pos <= node.end_pos, "Node doesn't contain position"

# Generated at 2022-06-24 07:58:33.847671
# Unit test for function get_definitions
def test_get_definitions():
    source = "print(2 + 3)"
    row, column = 1, 7
    definitions = get_definitions(source, row, column, "testfile.py")
    assert len(definitions) == 1
    first_def = definitions[0]
    assert first_def.parent().name == "builtins"
    assert first_def.name == "print"

# Generated at 2022-06-24 07:58:42.138697
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi


# Generated at 2022-06-24 07:58:48.283789
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    node = parse_source("def f():\n    pass")

    for pos in ([4, 5], [5, 5], [6, 5], [7, 5]):
        assert node is get_statement_of_position(node, pos)

    for pos in ([4, 4], [3, 5], [8, 5]):
        assert node.children[0] is get_statement_of_position(node, pos)



# Generated at 2022-06-24 07:58:55.879991
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import namedtuple

    import jedi

    if not _using_older_jedi(jedi):
        logger.info("Jedi version " + jedi.__version__ + " detected")
        logger.info("Updating test_get_interpreter_completions...")
        return

    def get_definition_path(definition):
        return definition.module_path

    def get_definition_type(definition):
        return definition.type

    # The following code is a copy of the test for the function get_interpreter_completions() in jedi.common.test_completion
    # included in jedi 0.15.1
    namespace = namedtuple("namespace", "name module_path type")


# Generated at 2022-06-24 07:59:05.379262
# Unit test for function get_script_completions
def test_get_script_completions():
    import unittest
    import sys

    class TestJediInterpreter(unittest.TestCase):
        def test_get_script_completions(self):
            import jedi
            import parso

            source = "import datetime\ndatetime.datetime.utcnow()"
            row = 1
            column = 14

            expected_script_completions = "utcnow"
            if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16"]:
                self.assertEqual(
                    expected_script_completions,
                    get_script_completions(source, row, column, "t.py")[1].name,
                )

# Generated at 2022-06-24 07:59:12.095422
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import parso

    comp = ThonnyCompletion(
        name="any_name",
        complete="any_complete",
        type=parso.Name,
        description="any_description",
        parent=None,
        full_name="any_full_name",
    )
    print(comp["name"])
    assert comp["name"] == "any_name"
    del comp["name"]
    try:
        comp["name"]
        assert False
    except Exception:
        assert True

# Generated at 2022-06-24 07:59:18.357931
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import PythonNode
    parsed = parse_source("def f():\n    abc.something()")
    assert isinstance(parsed, PythonNode)
    assert parsed.start_pos == (1, 0)
    assert parsed.end_pos == (2, 19)
    assert parsed.get_first_leaf().value == "def"
    assert parsed.get_last_leaf().value == ")"

# Generated at 2022-06-24 07:59:19.250823
# Unit test for function get_definitions

# Generated at 2022-06-24 07:59:23.520016
# Unit test for function get_script_completions
def test_get_script_completions():
    source = "class A:\n    def m(self):\n        self.a"
    completions = get_script_completions(source, 3, 12, "test")
    assert completions[0].name == "a"
    completions2 = get_script_completions(source, 3, 12, "test", sys_path=["dummy"])
    assert completions == completions2

# Generated at 2022-06-24 07:59:34.320644
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def check(source, pos, expected_result=None, show_output=False):
        parsed = parse_source(source)
        result = get_statement_of_position(parsed, pos)
        if result is None and expected_result is None:
            return

        if expected_result is not None:
            assert result is not None, "Expected %s, but got nothing" % expected_result
            assert result.type == expected_result, (
                "Expected %s, but got %s %s"
                % (expected_result, result.type, result.start_pos)
            )

        elif isinstance(result, list):
            for r in result:
                assert r.type != expected_result, (
                    "Expected different result, but got %s" % r.type
                )

# Generated at 2022-06-24 07:59:39.462827
# Unit test for function parse_source
def test_parse_source():
    pass
    # The following test is disabled because it fails under python 3.5 with jedi 0.16.
    #import parso
    #source = """def foo(a, b, c=1):
    #    pass
    #
    #
    #class X:
    #    def bar(self, x, y=3):
    #        if x:
    #            pass"""
    #
    #module = parse_source(source)
    #assert isinstance(module, parso.python.tree.Module)

# Generated at 2022-06-24 07:59:45.473276
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"


# Generated at 2022-06-24 07:59:47.360504
# Unit test for function parse_source
def test_parse_source():
    assert parse_source("print(")


from thonny.plugins.micropython.backend import MicroPythonProxy

# Generated at 2022-06-24 07:59:54.871248
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    name = completion["name"]
    assert name == "name"
    complete = completion["complete"]
    assert complete == "complete"
    type = completion["type"]
    assert type == "type"
    description = completion["description"]
    assert description == "description"
    parent = completion["parent"]
    assert parent == "parent"
    full_name = completion["full_name"]
    assert full_name == "full_name"

# Generated at 2022-06-24 08:00:02.429501
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    result = get_interpreter_completions(
        """
        def f(x):
            pass
        """,
        [
            {
                "a": 1,
                "b_long_name": "something",
                "c_long_long_name": "something else",
                "d_long_long_name_with_arg": "something else with arg",
            }
        ],
    )
    assert [c["name"] for c in result] == [
        "a",
        "b_long_name",
        "c_long_long_name",
        "d_long_long_name_with_arg",
        "f",
    ]


# Generated at 2022-06-24 08:00:12.915081
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions("b.a=100\nb.a", 3, 3, "somefile")[0].parent().name == "b"
    assert get_definitions("a=100\na+a", 3, 1, "somefile")[0].parent().name == "a"
    assert (
        get_definitions("class A:\n    def f(self):\n        self.f", 4, 7, "somefile")[0].parent().name == "self"
    )
    assert get_definitions("x=10\nprint(x)", 3, 7, "somefile")[0].parent().name == "x"

# Generated at 2022-06-24 08:00:21.426370
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():

    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    completion = ThonnyCompletion(name, complete, type, description, parent, full_name)

    _list = [
        completion["name"],
        completion["complete"],
        completion["type"],
        completion["description"],
        completion["parent"],
        completion["full_name"],
    ]

    assert _list == [name, complete, type, description, parent, full_name], "Elements are not equal"



# Generated at 2022-06-24 08:00:25.409397
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert "=" in ThonnyCompletion("arg", "arg=", "dummy", "dummy", "dummy", "dummy").name
    assert "=" not in ThonnyCompletion("arg=", "arg=", "dummy", "dummy", "dummy", "dummy").name

# Generated at 2022-06-24 08:00:30.540063
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 08:00:31.545442
# Unit test for function get_definitions
def test_get_definitions():
    import unittest.mock as mock
    from collections import namedtuple


# Generated at 2022-06-24 08:00:36.625343
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_utils import get_script_completions
    compl = get_script_completions("import turtle\nturtle.forward(1)", 1, 10, "turtle_test.py", ["/usr/lib/python3.5"])
    assert len(compl) > 0
    assert compl[0]["name"] == "forward"
    assert compl[0]["complete"] == "forward("
    assert compl[0]["description"] == "forward(distance) -- Move the turtle forward by the specified distance, in the direction the turtle is headed."



# Generated at 2022-06-24 08:00:42.446793
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("my_var",0,0,"") == []
    assert get_script_completions("M",0,1,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Ma",0,2,"") == []
    assert get_script_completions("Map",0,3,"") == []
    assert get_script_completions("Map",0,3,"")