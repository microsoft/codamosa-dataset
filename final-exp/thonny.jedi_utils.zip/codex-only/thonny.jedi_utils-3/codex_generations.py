

# Generated at 2022-06-24 07:50:45.782807
# Unit test for function get_definitions

# Generated at 2022-06-24 07:50:52.830644
# Unit test for function parse_source
def test_parse_source():
    import os
    path = os.path.dirname(__file__)
    with open(os.path.join(path, "test.py"), "r") as f:
        source = parse_source(f.read())

    assert source is not None
    assert source.number_of_lines() == 2

    # Check parse tree
    assert len(source.children) == 1
    assert source.children[0].type == "file_input"
    file_input = source.children[0]

    assert len(file_input.children) == 1
    assert file_input.children[0].type == "simple_stmt"
    simple_stmt = file_input.children[0]

    assert len(simple_stmt.children) == 1

# Generated at 2022-06-24 07:50:53.710307
# Unit test for function get_script_completions
def test_get_script_completions():
    assert get_script_completions("", 1, 1, "") == []

# Generated at 2022-06-24 07:50:56.547525
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    completions = get_interpreter_completions('"".', [], sys_path=[""])
    assert len(completions) > 0
    completions = get_interpreter_completions('"".join(', [], sys_path=[""])
    assert len(completions) > 0
    for c in completions:
        if c.name == "split":
            assert c.complete == "split("

# Generated at 2022-06-24 07:51:08.018104
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from jedi.evaluate.compiled.dot_lookup import FakeName

    import builtins
    from test.cpython_sample_namespace import namespace

    for key in namespace:
        if key not in dir(builtins):
            namespace[key] = FakeName(namespace[key], key)

    source = "import sys; print(sys.path[0])"
    completions = get_interpreter_completions(source, [namespace])

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert completions[0].name == "sys"
    else:
        assert completions[0].name == "sys."



# Generated at 2022-06-24 07:51:13.453184
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    """Unit test for function get_interpreter_completions"""
    from jedi.api.keywords import Keyword

    completions = get_interpreter_completions(
        "print(m)",
        [{"name": "__builtins__", "description": "builtins", "value": __builtins__}],
    )
    expected = [
        ThonnyCompletion(
            name="min",
            complete="min",
            type=Keyword,
            description="min = 0",
            parent=__builtins__,
            full_name="min",
        )
    ]
    # print(completions)
    # print(expected)
    assert expected == completions



# Generated at 2022-06-24 07:51:15.550130
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api import Interpreter
    import jedi


# Generated at 2022-06-24 07:51:23.294358
# Unit test for function get_script_completions
def test_get_script_completions():
    import os
    import sys
    import jedi
    currentDir = os.path.dirname(__file__)
    #Need to add the folder of jedi to sys.path
    sys.path.append(os.path.dirname(jedi.__path__[0]))
    from jedi.api import scripts
    import jedi
    from jedi.utils import sys_path
    from parso.python import tree
    import itertools

    def get_completion_type(completion):
        try:
            return completion.type
        except AttributeError:
            pass

        complete = completion.complete
        if complete.endswith("="):
            if "_" in complete:
                if complete.endswith("__="):
                    return "private"
                else:
                    return "var"

# Generated at 2022-06-24 07:51:25.750703
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    src = "if 4 == 2:"
    t = parse_source(src)
    assert isinstance(t, tree.Module)

# Generated at 2022-06-24 07:51:33.481017
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python.tree import Class, AssignmentStmt, Function
    from parso.python import tree

    node = parso.parse("""
        class Person:
            def __init__(self):
                self.name = "Alice"
        """)
    assert isinstance(get_statement_of_position(node, 9), Class)
    assert isinstance(get_statement_of_position(node, 25), Function)
    assert isinstance(get_statement_of_position(node, 40), AssignmentStmt)
    assert isinstance(get_statement_of_position(node, 42), tree.ExprStmt)

# Generated at 2022-06-24 07:51:38.246288
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import PythonNode
    from parso.tree import Leaf

    node = PythonNode("", [Leaf(1, ":")])
    node.start_pos = (0, 1)
    node.end_pos = (0, 1)
    assert get_statement_of_position(node, (0, 0)) == node

# Generated at 2022-06-24 07:51:49.851799
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Node, ErrorNode

    class stub_node(Node):
        def __init__(self, start_pos, end_pos, children=None):
            self.start_pos = start_pos
            self.end_pos = end_pos
            self.children = children


# Generated at 2022-06-24 07:51:52.599823
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import jedi.parser_utils

    def _get_class(source: str):
        parse_tree = parso.parse(source)
        cls = parse_tree.children[0]
        assert isinstance(cls, parso.python.tree.Class)
        return cls


# Generated at 2022-06-24 07:51:56.491937
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest.mock
    import jedi

    def call_with(namespaces, sys_path=None):
        return jedi.get_interpreter_completions("", namespaces, sys_path)

    class Namespace:
        def __init__(self):
            self.values = {
                "__name__": "__main__",
                "__builtins__": __builtins__,
                "__doc__": None,
                "__package__": None,
            }

        def __setitem__(self, k, v):
            self.values[k] = v

        def __getitem__(self, k):
            return self.values[k]

        def items(self):
            return self.values.items()

    namespace = Namespace()

    # A simple case

# Generated at 2022-06-24 07:51:58.925472
# Unit test for function parse_source
def test_parse_source():
    from parso.python import tree

    parse = parse_source("print('hello')")

    assert parse is not None
    assert isinstance(parse, tree.Module)
    assert isinstance(parse.children[0], tree.ExprStmt)
    assert isinstance(parse.children[0].children[0], tree.SimpleExpr)

# Generated at 2022-06-24 07:52:10.280678
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").name == "name"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").complete == "complete"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").type == "type"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").description == "description"
    assert ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name").parent == "parent"

# Generated at 2022-06-24 07:52:16.961697
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    instance = ThonnyCompletion(name="name", complete="complete", 
                                type="type", description="description", 
                                parent="parent", full_name="full_name")
    assert instance.name == instance["name"]
    assert instance.complete == instance["complete"]
    assert instance.type == instance["type"]
    assert instance.description == instance["description"]
    assert instance.parent == instance["parent"]
    assert instance.full_name == instance["full_name"]



# Generated at 2022-06-24 07:52:25.168694
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    import parso

    test_name = "test_name"
    test_complete = "test_complete"
    test_type = "test_type"
    test_description = "test_description"
    test_parent = parso.python.tree.PythonNode()
    test_full_name = "test_full_name"
    thonny_completion = ThonnyCompletion(
        test_name, test_complete, test_type, test_description, test_parent, test_full_name
    )
    assert (thonny_completion["name"] == test_name)
    assert (thonny_completion["complete"] == test_complete)
    assert (thonny_completion["type"] == test_type)
    assert (thonny_completion["description"] == test_description)

# Generated at 2022-06-24 07:52:29.185001
# Unit test for function get_script_completions
def test_get_script_completions():
    # Tests for function get_script_completions
    import jedi
    from Thonny.jedi_utils import get_script_completions
    from parso.python import tree
    import parso
    from jedi.evaluate import compiled
    

# Generated at 2022-06-24 07:52:39.786863
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree

    import testutils
    from testutils import TestCase

    class InterpreterCompletionsTest(TestCase):
        def setUp(self):
            self.jedi_module = testutils._import_module("jedi")

        def _fake_node(self, completions):
            return self.jedi_module.Interpreter(code="", line=1, column=1, namespaces=[])._module

        def test_infer_statement(self):
            completions = [
                self.jedi_module.InterpreterCompletion(
                    name="completion", complete="completion", type="module", description=""
                )
            ]
            node = self._fake_node(completions)

# Generated at 2022-06-24 07:52:44.906761
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    # pylint: disable=unsubscriptable-object
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:52:55.063180
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.api.helpers import Interpreter
    from jedi import __version__
    from jedi.parser_utils import get_statement_of_position

    sys_path = ["/usr/local"]
    source = """import sys
print(sys.path)
"""
    namespaces = [
        {
            "type": "module",
            "module_path": "builtins",
            "namespace": "builtins",
            "all_namespace_names": ["builtins"],
            "namespace_names": ["builtins"],
        }
    ]
    if __version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        # Older jedi versions
        interpreter = Interpreter(source, namespaces)
        # Get the

# Generated at 2022-06-24 07:52:55.946624
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:53:02.257866
# Unit test for function get_definitions
def test_get_definitions():
    assert get_definitions(source='aaa', row=1, column=0, filename='test.py') == []
    assert get_definitions(source='def aaa(): pass', row=0, column=0, filename='test.py') == []
    assert get_definitions(source='def aaa(): pass', row=1, column=0, filename='test.py') == []
    assert len(get_definitions(source='def aaa(): pass', row=1, column=4, filename='test.py')) == 1
    assert len(get_definitions(source='def aaa():\n    aaa', row=2, column=4, filename='test.py')) == 1

# Generated at 2022-06-24 07:53:07.014264
# Unit test for function parse_source
def test_parse_source():
    source = '''def a():
    def b():
        return 1
    '''
    tree = parse_source(source)
    lines = str(tree).splitlines()
    assert lines[1].strip() == 'def a():'
    assert lines[2].strip() == 'def b():'
    assert lines[3].strip() == 'return 1'



# Generated at 2022-06-24 07:53:12.665893
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase, main

    import jedi

    sys_path = ["/a/b/c"]

    class Test(TestCase):
        def test_completions(self):
            if _using_older_jedi(jedi):
                self.assertEqual(len(get_interpreter_completions("", [], sys_path)), 7)
            else:
                self.assertEqual(len(get_interpreter_completions("", [], sys_path)), 2)

    main()

# Generated at 2022-06-24 07:53:14.138972
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser

# Generated at 2022-06-24 07:53:20.083626
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    c = ThonnyCompletion('a_name', 'a_complete', 'a_type', 'a_description', 'a_parent', 'a_full_name')
    assert c.name == 'a_name'
    assert c.complete == 'a_complete'
    assert c.type == 'a_type'
    assert c.description == 'a_description'
    assert c.parent == 'a_parent'
    assert c.full_name == 'a_full_name'

# Generated at 2022-06-24 07:53:29.457045
# Unit test for function parse_source
def test_parse_source():
    code1 = '''def foo(x,y): pass'''
    code2 = '''def foo(x,y): pass "what"'''
    code3 = '''def foo(x,y): pass 42'''
    code4 = '''def foo(x,y): 42'''
    code5 = '''def foo(x,y): 42; 43'''
    code6 = '''def foo(x,y): 42; 43; pass'''
    parse_source(code1)
    parse_source(code2)
    parse_source(code3)
    parse_source(code4)
    parse_source(code5)
    parse_source(code6)

if __name__ == "__main__":
    test_parse_source()

# Generated at 2022-06-24 07:53:30.185661
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi


# Generated at 2022-06-24 07:53:36.531421
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import patch

    with patch("thonny.jediutils.jedi.Interpreter.complete") as mocked:
        mocked.return_value = [
            ThonnyCompletion(
                name="name1",
                complete="complete1",
                type="type1",
                description="description1",
                parent="parent1",
                full_name="full_name1",
            ),
            ThonnyCompletion(
                name="name2",
                complete="complete2",
                type="type2",
                description="description2",
                parent="parent2",
                full_name="full_name2",
            ),
        ]
        result = get_interpreter_completions("source", "namespaces")
        assert 2 == len(result)

# Generated at 2022-06-24 07:53:44.816279
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # Arrange
    import jedi
    import sys
    import types

    class Foo(object):
        pass

    foo = Foo()
    foo.a = 4
    foo.b = 5
    foo.c = 6
    globals = {'foo' : foo}

    # Act
    completions = get_interpreter_completions("foo.", globals)

    # Assert
    assert len(completions) == 3
    assert "a" in [c.name for c in completions]
    assert "b" in [c.name for c in completions]
    assert "c" in [c.name for c in completions]
    assert "foo" not in [c.name for c in completions]
    assert "Foo" not in [c.name for c in completions]



# Generated at 2022-06-24 07:53:46.237572
# Unit test for function parse_source
def test_parse_source():
    import sys
    import jedi


# Generated at 2022-06-24 07:53:53.402363
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    
    dir_path = os.path.dirname(os.path.realpath(__file__))
    with open(dir_path + "/get_definitions.py", "r") as f:
        source = f.read()
        
    definitions = get_definitions(source, 2, 4, "<test>")
    assert len(definitions) == 1
    print(definitions[0])
    assert definitions[0].module_path == dir_path + "/get_definitions.py"
    assert definitions[0].line == 0
    assert definitions[0].column == 0

# Generated at 2022-06-24 07:54:00.745408
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonny_completion = ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent="parent",
        full_name="full_name",
    )
    assert thonny_completion.name == "name"
    assert thonny_completion.complete == "complete"
    assert thonny_completion.type == "type"
    assert thonny_completion.description == "description"
    assert thonny_completion.parent == "parent"
    assert thonny_completion.full_name == "full_name"

# Generated at 2022-06-24 07:54:06.147948
# Unit test for function get_definitions
def test_get_definitions():
    src = """
a = 5
a # <---
""".strip()

    row = 2
    column = 3
    filename = "t.py"
    defs = get_definitions(src, row, column, filename)
    assert len(defs) == 1
    assert defs[0]["name"] == "a"
    assert defs[0]["type"] == "statement"



# Generated at 2022-06-24 07:54:16.957217
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class TestGetDefinitions(unittest.TestCase):
        def test_get_definition_for_builtin(self):
            import jedi

            source = 'import math; math.log'
            row, column = source.index("log"), 1
            definitions = get_definitions(source, row, column, "test.py")

            if _using_older_jedi(jedi):
                self.assertEqual(len(definitions), 3)
                self.assertIn("log", [d.full_name for d in definitions])
                self.assertIn("log10", [d.full_name for d in definitions])
                self.assertIn("log1p", [d.full_name for d in definitions])
            else:
                self.assertEqual(len(definitions), 1)
               

# Generated at 2022-06-24 07:54:22.307173
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python import tree

    root = parso.parse("a.b=3")
    node_a_dot_b_eq = root.children[0].children[0]
    assert isinstance(node_a_dot_b_eq, tree.ExprStmt)
    assert get_statement_of_position(root, node_a_dot_b_eq.end_pos + 1) == node_a_dot_b_eq


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-24 07:54:28.736068
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = 'name'
    complete = 'complete'
    type = 'type'
    description = 'description'
    parent = 'parent'
    full_name = 'full_name'
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    if tc['name'] == name and tc['complete'] == complete:
        print('Pass!')
    else:
        print('Fail')



# Generated at 2022-06-24 07:54:35.862502
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from jedi.api.classes import Completion
    from jedi.parser.tree import Class
    from jedi import __version__

    ThonnyCompletion(
        name="name",
        complete="complete",
        type="type",
        description="description",
        parent=Class("", ""),
        full_name="full_name",
    )

    if __version__[0:3] >= "0.16" and __version__[0:3] < "0.18":
        c = Completion(name="name", complete="complete", type="type", description="description",
                       parent=Class("", "", None, None, None), full_name="full_name")

# Generated at 2022-06-24 07:54:42.514561
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import parso.python.tree

    source = "def foo(a):\n    print(a)\n    a = 1\n    if a:\n        b = 2\n        \n    "
    output1 = get_statement_of_position(
        parse_source(source), parso.parse("print(a)").children[0].start_pos
    )
    assert isinstance(output1, parso.python.tree.ExprStmt)
    output2 = get_statement_of_position(
        parse_source(source), parso.parse("b = 2").children[0].start_pos
    )
    assert isinstance(output2, parso.python.tree.ExprStmt)

# Generated at 2022-06-24 07:54:51.801031
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys

    # test for module
    source = "import sys"
    completions = get_script_completions(source, 0, 7, "")
    assert len(completions) > 0
    assert sys in [completion.parent for completion in completions]

    # test for class
    source = "import sys\nprint(sys.getwindowsversion().platform)"
    completions = get_script_completions(source, 1, 21, "")
    assert len(completions) > 0
    assert sys in [completion.parent for completion in completions]

    # test for function
    source = "import sys\nprint(sys.getwindowsversion().platform)"
    completions = get_script_completions(source, 1, 27, "")
    assert len(completions) > 0
    assert sys

# Generated at 2022-06-24 07:55:01.751355
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    assert jedi.__version__ >= "0.12"

    case = get_interpreter_completions("str().")
    assert case[0].name == "capitalize"
    if jedi.__version__ > "0.14":
        assert case[0].type == "method"

    assert get_interpreter_completions("import datetime; datetime.")[0].name == "date"

    case = get_interpreter_completions("tuple(); tuple().")
    assert case[0].name == "count"

    case = get_interpreter_completions("len(); len().")
    assert case[0].name == "bit_length"



# Generated at 2022-06-24 07:55:07.730671
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    Completion = ThonnyCompletion("x", "x", "int", "int(x=0)", "int", "int")
    Completion.__getitem__("name") == "x"
    Completion.__getitem__("complete") == "x"
    Completion.__getitem__("type") == "int"
    Completion.__getitem__("description") == "int(x=0)"
    Completion.__getitem__("parent") == "int"
    Completion.__getitem__("full_name") == "int"

# Generated at 2022-06-24 07:55:10.245273
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(None, None, None, None, None, None)[
        "name"
    ] == None, "__getitem__ method of class ThonnyCompletion does not work as expected"

# Generated at 2022-06-24 07:55:15.388374
# Unit test for function get_definitions
def test_get_definitions():
    import jedi

    script = jedi.Script("import os")
    assert len(script.goto_definitions()) == 1
    assert script.goto_assignments()[0].desc_with_module == 'os: module'
    
    script = jedi.Script("os.path.exists")
    assert len(script.goto_definitions()) == 1
    assert script.goto_definitions()[0].desc_with_module == 'posixpath: os.path.exists(...)'


# Generated at 2022-06-24 07:55:16.939124
# Unit test for function get_definitions

# Generated at 2022-06-24 07:55:24.276740
# Unit test for function get_script_completions
def test_get_script_completions():
    from thonny.plugins.jedi_completer import utils

    source = "import numpy\n numpy.f"
    completions = utils.get_script_completions(source, 2, 14, "")
    for completion in completions:
        if completion.name == "foo":
            assert completion.type == "function"
            assert completion.parent == "numpy"
            assert completion.full_name == "numpy.foo"
            assert completion.description.startswith("foo(a, b, c=None)")
            break
    else:
        assert False, "Completion missing"


# Generated at 2022-06-24 07:55:26.608935
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    thonnyCompletion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert thonnyCompletion is not None


# Generated at 2022-06-24 07:55:34.968201
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.parser_utils import get_statement_of_position
    from parso.python.tree import ClassOrFunc

    completions = get_script_completions("", 1, 1, "test")
    assert len(completions) > 0
    for completion in completions:
        assert completion.name != "get_script_completions"
        assert completion.complete != "get_script_completions"
        assert completion.type != "function"
        assert completion.type != "statement"
        assert completion.type != "import"

    completions = get_script_completions("", 1, 1, "gis.py")

    assert len(completions) > 0
    for completion in completions:
        assert completion.name != get_script_completions.__name__
        assert completion.complete

# Generated at 2022-06-24 07:55:37.012289
# Unit test for function parse_source
def test_parse_source():
    # check that this function is working
    node = parse_source("import os")
    assert node.children[0].type == "import_from"
    assert node.children[1].type == "error_leaf"



# Generated at 2022-06-24 07:55:43.944096
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion("abc", "def", "ghi", "jkl", "mno", "pqr")
    assert tc.__getitem__("name") == "abc", "name did not return correct string"
    assert tc.__getitem__("complete") == "def", "complete did not return correct string"
    assert tc.__getitem__("type") == "ghi", "type did not return correct string"
    assert tc.__getitem__("description") == "jkl", "description did not return correct string"
    assert tc.__getitem__("parent") == "mno", "parent did not return correct string"
    assert tc.__getitem__("full_name") == "pqr", "full_name did not return correct string"

# Generated at 2022-06-24 07:55:48.280624
# Unit test for function parse_source
def test_parse_source():
    import parso

    assert (
        parse_source("x = 1 # comment")
        == parso.parse('x = 1 # comment"')  # endquote is required to make parso happy
    )



# Generated at 2022-06-24 07:55:51.018841
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.parser_utils


# Generated at 2022-06-24 07:55:59.071294
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi.parser_utils import get_root_scope
    from jedi.evaluate.context import ContextSet, array_type

    source = "import numpy as n; n.abs"
    completions = get_interpreter_completions(source, [])

    assert len(completions) > 0
    first_completion = completions[0]
    assert "abs" in first_completion.name
    assert first_completion.type == "function"

    # This part of the code requires jedi 0.17+

# Generated at 2022-06-24 07:56:08.425305
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    """
    Test getitem method of class ThonnyCompletion
    """
    complete1 = ThonnyCompletion(
        "name1", "complete1", "type", "description", "parent", "full_name"
    )
    complete2 = ThonnyCompletion(
        "name2", "complete2", "type", "description", "parent", "full_name"
    )
    complete3 = ThonnyCompletion(
        "name3", "complete3", "type", "description", "parent", "full_name"
    )
    print(complete1["name"])
    print(complete2["complete"])
    print(complete3["type"])
    print(complete1["description"])
    print(complete2["parent"])
    print(complete3["full_name"])



# Generated at 2022-06-24 07:56:15.405523
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    """
    This test checks if the constructor of class ThonnyCompletion is working.
    """
    thonnyCompletion_1 = ThonnyCompletion(name="a", complete="b", type=None, description="c",
        parent=None, full_name=None)
    assert thonnyCompletion_1.name == "a"
    assert thonnyCompletion_1.complete == "b"
    assert thonnyCompletion_1.type == None
    assert thonnyCompletion_1.description == "c"
    assert thonnyCompletion_1.parent == None
    assert thonnyCompletion_1.full_name == None


# Generated at 2022-06-24 07:56:25.805130
# Unit test for function get_definitions
def test_get_definitions():
    import unittest

    class Test(unittest.TestCase):
        def test_1(self):
            from unittest import mock
            import jedi
            jedi.Script = mock.Mock()
            jedi.Script.goto_definitions = mock.Mock()

            defs = get_definitions("some source", 3, 5, "some file.py")

            self.assertTrue(jedi.Script.called)
            self.assertTrue(jedi.Script.goto_definitions.called)
            self.assertEqual(
                jedi.Script.call_args[0],
                ("some source", 3, 5, "some file.py"),
                "Expected to be called with source row col filename",
            )

# Generated at 2022-06-24 07:56:26.348277
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:56:36.008341
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi

    if not _using_older_jedi(jedi):
        sys_path = ["/usr"]
    else:
        sys_path = "/usr"
    completions = get_interpreter_completions("import os\nos.", [], sys_path)
    completions = get_interpreter_completions("import os\nos.path.", [], sys_path)
    completions = get_interpreter_completions(
        "from datetime import date\n"
        "d = date(1, 2, 3)\n"
        "d.",
        [],
        sys_path,
    )

# Generated at 2022-06-24 07:56:42.485926
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    tests = [
        ("", ["_", "__", "__all__", "__builtins__", "__doc__", "__file__", "__loader__", "__name__", "__package__", "__spec__"]),
    ]
    for test in tests:
        completion_strs = [comp.name for comp in get_interpreter_completions(test[0], [])]
        assert completion_strs == test[1]


# Generated at 2022-06-24 07:56:52.603304
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest import TestCase

    class Test_get_script_completions(TestCase):
        def test1(self):
            # Zero completions
            result = get_script_completions(
                source="",
                row=1,
                column=1,
                filename="",
            )
            self.assertEqual(len(result), 0)

        def test2(self):
            # One completion
            result = get_script_completions(
                source="import os\n\nos.",
                row=3,
                column=3,
                filename="",
            )
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].name, "path")

        def test3(self):
            # Multiple completions
            result = get_script_com

# Generated at 2022-06-24 07:56:58.095170
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    source = "import sys\nsys.p"
    namespaces = [{"sys": jedi.Interpreter(source).builtins}]
    completions = get_interpreter_completions(source, namespaces)
    assert len([x for x in completions if x.name == "path"]) > 0


if __name__ == "__main__":
    test_get_interpreter_completions()

# Generated at 2022-06-24 07:57:05.387382
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.interpreter import Script
    from jedi.api.helpers import completions_to_json

    completion = Script('s = "string"; s.repl', 1, 13, 'test.py').complete()[0]

# Generated at 2022-06-24 07:57:15.495796
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion('name_test', 'complete_test', 'type_test', 'description_test', 'parent_test', 'full_name_test')['type'] == 'type_test'
    assert ThonnyCompletion('name_test', 'complete_test', 'type_test', 'description_test', 'parent_test', 'full_name_test')['complete'] == 'complete_test'
    assert ThonnyCompletion('name_test', 'complete_test', 'type_test', 'description_test', 'parent_test', 'full_name_test')['name'] == 'name_test'
    assert ThonnyCompletion('name_test', 'complete_test', 'type_test', 'description_test', 'parent_test', 'full_name_test')['description'] == 'description_test'
    assert Th

# Generated at 2022-06-24 07:57:20.701921
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny import get_thonny_python_exe
    from thonny.python_shell import PythonShell
    from thonny.plugins.backend import BackendPlugin
    
    if _using_older_jedi(jedi):
        logger.warning("Tests require jedi >= 0.18")
        return
    
    shell = PythonShell(BackendPlugin.get_workbench())
    interpreter = shell.interp
    completions = get_interpreter_completions(source="import os.pat", namespaces=[], sys_path=get_thonny_python_exe())
    assert len(completions) > 0
    assert any([(c.name == "path") and (c.description == "Module") for c in completions])

# Generated at 2022-06-24 07:57:26.554008
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from thonny import get_workbench

    assert isinstance(get_interpreter_completions("test_word.", [{"test_word": 1}]), list)
    assert isinstance(get_interpreter_completions("test_word.", [{"test_word": 1}], get_workbench().get_option("run.sys_path")), list)
    assert isinstance(get_interpreter_completions("test_word.", [{"test_word": 1}], [get_workbench().get_option("run.sys_path")]), list)


# Generated at 2022-06-24 07:57:30.905545
# Unit test for function parse_source
def test_parse_source():
    import jedi

    src = "def foo(p1, p2):\n    return p1 + p2"
    node = parse_source(src)
    assert isinstance(node, jedi.parser_utils.get_base_node_class())



# Generated at 2022-06-24 07:57:37.800740
# Unit test for function parse_source
def test_parse_source():
    import parso
    import jedi.api

    source = "x = 'hello'\ndef f(x): return x**2"
    new = parse_source(source)

    old = parso.parse(source)

    def get_tree(obj):
        if isinstance(obj, jedi.api.classes.Script):
            return obj._get_module().tree
        elif isinstance(obj, parso.python.tree.Module):
            return obj

    assert get_tree(new) == get_tree(old)

# Generated at 2022-06-24 07:57:48.084500
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from jedi.parser_utils import get_statement_of_position

    def f():
        if cond:
            a = 1
        else:
            b = 2
        pass #breakpoint

    assert f.__code__.co_name == "f"

    source = inspect.getsource(f)
    module = ast.parse(source)
    func_node = module.body[0]

    for node in func_node.body:
        if node.lineno <= 6:
            assert get_statement_of_position(func_node, node.lineno, 1) == node

    assert get_statement_of_position(func_node, 5, 0) == func_node.body[0]
    assert get_statement_of_position(func_node, 2, 0) is None

# Generated at 2022-06-24 07:57:51.195505
# Unit test for function parse_source
def test_parse_source():
    import parso

    code = "a=5\nb='a'"
    expected_result = parso.parse(code)
    result = parse_source(code)
    assert result == expected_result

# Generated at 2022-06-24 07:58:02.503939
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    from parso.python.tree import Leaf
    from parso.python.tree import NodeOrLeaf

    def find_leaf_by_pos(node_or_leaf: NodeOrLeaf, pos: int) -> Leaf:
        """
        Traverse the given tree and find the leaf with the given position attribute (column_offset)
        """
        if isinstance(node_or_leaf, Leaf):
            if node_or_leaf.start_pos == pos:
                return node_or_leaf
            else:
                return None
        else:
            for child in node_or_leaf.children:
                result = find_leaf_by_pos(child, pos)
                if result is not None:
                    return result
            else:
                return None


# Generated at 2022-06-24 07:58:12.384510
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Script
    from jedi.api.classes import Interpreter


# Generated at 2022-06-24 07:58:17.065998
# Unit test for function get_script_completions
def test_get_script_completions():
    if not _using_older_jedi(__import__("jedi")):
        import jedi
        try:
            project = jedi.Project()
            out = get_script_completions("\n", 1, 0, "<string>", [])
            assert len(out) > 0
            assert isinstance(out[0], ThonnyCompletion)
        finally:
            project.die()

# Generated at 2022-06-24 07:58:18.806430
# Unit test for function parse_source
def test_parse_source():
    import parso

# Generated at 2022-06-24 07:58:22.707455
# Unit test for function get_definitions
def test_get_definitions():
    import jedi
    import os
    from thonny.globals import get_workbench
    workbench = get_workbench()


# Generated at 2022-06-24 07:58:28.586026
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_list =[1,2,3]
    assert ThonnyCompletion(name=test_list[0], complete=test_list[1], type=test_list[2], description=test_list[0], parent=test_list[1], full_name=test_list[2]).name == test_list[0]
    assert ThonnyCompletion(name=test_list[0], complete=test_list[1], type=test_list[2], description=test_list[0], parent=test_list[1], full_name=test_list[2]).complete == test_list[1]

# Generated at 2022-06-24 07:58:35.638504
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi import __version__ as jedi_version

    source = "import sys\n"
    row, column = 1, 0

    if jedi_version < "0.13":
        completion = get_script_completions(source, row, column)[0]
    elif jedi_version < "0.16":
        completion = get_script_completions(source, row, column)
    else:
        completion = get_script_completions(source, row, column)[0]

    assert completion.type == "statement"
    assert completion.description == "this is sys\n"


# Generated at 2022-06-24 07:58:40.009763
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import jedi.api
    definitions = list(jedi.api.names(
"""def f(n):
    if n > 10:
        print("n > 10")
    elif n > 5:
        print("n > 5")
    return n
f(5)
f(11)
""",
    column=6, line=2))
    if_node = definitions[0].module.subscopes[0]
    print(get_statement_of_position(if_node, 8).children[1].type)
    print(get_statement_of_position(if_node, 9).children[0].type)
    print(get_statement_of_position(if_node, 19).children[0].type)

# Generated at 2022-06-24 07:58:45.827401
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion["name"] == "name"
    assert completion["complete"] == "complete"
    assert completion["type"] == "type"
    assert completion["description"] == "description"
    assert completion["parent"] == "parent"
    assert completion["full_name"] == "full_name"



# Generated at 2022-06-24 07:58:50.963120
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    assert jedi.__version__[0:3] == "0.1"
    assert len(get_script_completions("", 0, 0, "")) > 0
    assert len(get_script_completions("import sys", 0, 0, "")) > 0

    assert len(get_interpreter_completions("import sys", [])) > 0

# Generated at 2022-06-24 07:59:02.606593
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.evaluate.compiled import CompiledObject
    from jedi import ParserSyntaxError

    source = "raise StopIteration"
    for row, column in [(1, 5), (1, 11)]:
        definitions = get_definitions(source, row, column, "<test>")
        assert len(definitions) == 1
        assert isinstance(definitions[0], CompiledObject)
        assert definitions[0].name == "StopIteration"
        assert definitions[0].description == "Exception"
        assert definitions[0].full_name == "builtins.StopIteration"

    definitions = get_definitions(source, 1, 0, "<test>")
    assert len(definitions) == 0

    definitions = get_definitions("import os", 1, 10, "<test>")

# Generated at 2022-06-24 07:59:07.517445
# Unit test for function parse_source
def test_parse_source():
    path = "tests/test_files/jedi_test_script.py"
    with open(path) as f:
        source = f.read()
    tree = parse_source(source)
    assert isinstance(tree, parso.python.tree.Module)
    assert len(tree.children) == 3
    assert tree.children[0].type == "decorated"
    assert tree.children[1].type == "simple_stmt"
    assert tree.children[2].type == "funcdef"

# Generated at 2022-06-24 07:59:12.333821
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    test_content = """
i = 2
i.
"""
    completions = get_interpreter_completions(test_content, [{}])
    assert any(
        c["name"] == "__rmul__" for c in completions
    ), "get_interpreter_completions does not work with older jedi"



# Generated at 2022-06-24 07:59:14.486826
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    assert isinstance(parse_source("foo"), Module)

# Generated at 2022-06-24 07:59:23.339384
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso

    # 1. Test for older version of jedi (before 0.18).
    version = "0.13"
    ast = _get_ast(version)
    completions = get_script_completions(
        _get_source(version), _get_row(version), _get_column(version), ast
    )
    is_correct = True
    for i in range(len(completions)):
        i_correct = is_correct_completion(completions[i], i)
        is_correct = is_correct and i_correct
    assert is_correct

    # 2. Test for new version of jedi (after 0.18).
    version = "0.18"
    ast = _get_ast(version)

# Generated at 2022-06-24 07:59:27.239783
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from test.unittest_tools import unittest_run_with_captured_output
    from test.test_runner import redirect_io_functions

    with redirect_io_functions():
        out, err = unittest_run_with_captured_output("tests/jedi_test_files/interpreter_completions.py")


# Generated at 2022-06-24 07:59:37.877560
# Unit test for function get_definitions
def test_get_definitions():
    from toga.interface import Button as TogaButton

    def on_press(widget):
        pass

    button = TogaButton(label='OK')

    button.on_press.connect(on_press)

    test_code = """
    from toga.interface import Button as TogaButton
    button = TogaButton(label='OK')
    button.on_press.connect(on_press)
    """

    line = 4
    column = 26
    filename = "tst.py"

    definitions = get_definitions(test_code, line, column, filename)

    assert definitions
    definition = definitions[0]
    assert definition.full_name == "toga.interface.widgets.button.Button.on_press"
    assert definition.type == "event"
    assert definition.line == 2

# Generated at 2022-06-24 07:59:48.194881
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from jedi import Interpreter
    from copy import copy
    from test.test_jedi import run_test
    from jedi._compatibility import u
    from parso.python import tree
    from jedi.parser_utils import get_parent_scope
    from jedi.evaluate.context import ContextSet, ContextualizedName, ModuleContext
    from jedi.evaluate.compiled.access import BoundMethod, BoundMethodClass
    import ast
    import random

    # get random number of modules
    nr_modules = random.randint(1, 4)
    # create a list of unique module names so they don't interfere with each other
    module_names = [set() for _ in range(nr_modules)]
    modules = {}
    # create random number of variables

# Generated at 2022-06-24 07:59:53.021113
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import MagicMock
    
    def mock_tweak_completions(completions):
        return [
            ThonnyCompletion(
                name="123",
            ),
            ThonnyCompletion(
                name="456",
            ),
        ]
    global _tweak_completions
    old_tweak_completions = _tweak_completions
    _tweak_completions = mock_tweak_completions

    def mock_get_script_completions_older_jedi(source, row, column, filename):
        completions = [
            MagicMock(name="abc"),
            MagicMock(name="abc"),
        ]
        return completions


# Generated at 2022-06-24 07:59:54.092826
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import os
    import sys


# Generated at 2022-06-24 08:00:00.758419
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    def test_get_item(key, expected):
        val = completion.__getitem__(key)
        assert val == expected

    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    test_get_item("name", "name")
    test_get_item("complete", "complete")
    test_get_item("type", "type")
    test_get_item("description", "description")
    test_get_item("parent", "parent")
    test_get_item("full_name", "full_name")

# Generated at 2022-06-24 08:00:09.799237
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test = ThonnyCompletion("name", "completion", "type", "description", "parent", "full_name")
    assert test.__getitem__("complete") == "completion"
    assert test.__getitem__("parent") == "parent"
    assert test.__getitem__("full_name") == "full_name"
    assert test.__getitem__("") == None
    assert test.__getitem__(23) == None
    assert test.__getitem__(None) == None
    assert test.__getitem__(True) == None

# Generated at 2022-06-24 08:00:11.472039
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    assert ThonnyCompletion(name="a", complete="a=", type="a", description="a", parent="a", full_name="a")["name"] == "a"

# Generated at 2022-06-24 08:00:16.098166
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module, Number

    assert isinstance(parse_source(""), Module)  # from parso
    assert isinstance(parse_source("1"), Module)
    assert isinstance(parse_source("1").children[0], Number)  # from parso

# Generated at 2022-06-24 08:00:22.974251
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso
    import inspect
    
    
    def test_position(code, pos, result_name, passed):
        parser = parso.parse(code)
        test_result = get_statement_of_position(parser, pos)
        if inspect.ismethod(test_result):
            test_result = test_result.name.value
        else:
            test_result = test_result.get_code()
        if passed:
            assert test_result == result_name
        else:
            assert test_result != result_name
        


# Generated at 2022-06-24 08:00:33.537157
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python.tree import Leaf
    from parso.python.tree import NodeOrLeaf

    body = NodeOrLeaf()
    a = Leaf(1, "a")
    b = Leaf(1, "b")
    c = Leaf(1, "c")

    body.add_child(a, "a")
    body.add_child(b, "b")
    body.add_child(c, "c")

    assert getattr(b, "start_pos") == 1 and getattr(b, "end_pos") == 1
    assert get_statement_of_position(body, 0) == a
    assert get_statement_of_position(body, 1) == b
    assert get_statement_of_position(body, 2) == c
    assert get_statement_of_position(body, 3)

# Generated at 2022-06-24 08:00:40.288742
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    import parso

    source = "class Foo:\n    def bar(self):\n        pass\n"

    node = parse_source(source)
    node = node.children[0]  # class_stmt

    # class body
    node = node.children[-1]  # suite
    node = node.children[0]  # simple_stmt
    node = node.children[0]  # function_def
    node = node.children[-1]  # suite
    node = node.children[0]  # simple_stmt
    node = node.children[0]  # pass_stmt

    result = get_statement_of_position(node, parso.python.util.StringLikeFile(source).tell())