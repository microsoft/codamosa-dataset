

# Generated at 2022-06-24 07:51:15.162409
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:51:16.751463
# Unit test for function get_definitions

# Generated at 2022-06-24 07:51:18.501047
# Unit test for function parse_source
def test_parse_source():
    import parso.python.tree
    tree = parse_source("x = 2")
    assert isinstance(tree, parso.python.tree.Module)

# Generated at 2022-06-24 07:51:22.091511
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from parso.python import tree
    import jedi
    parser = jedi.parser

# Generated at 2022-06-24 07:51:25.666286
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    from parso.python.tree import Module


# Generated at 2022-06-24 07:51:26.548943
# Unit test for function parse_source
def test_parse_source():
    assert "Module" in str(parse_source("a=2"))

# Generated at 2022-06-24 07:51:36.978499
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.tree import Module, Node

    def recurse_get_statement_of_position(source, pos_list):
        assert isinstance(source, Module)
        statements = [
            recurse_get_statement_of_position(node, pos_list)
            for node in source.iter_imports()
        ]
        statements += [
            recurse_get_statement_of_position(node, pos_list)
            for node in source.iter_funcdefs()
        ]
        statements += [
            recurse_get_statement_of_position(node, pos_list)
            for node in source.iter_classdefs()
        ]
        statements += [
            recurse_get_statement_of_position(node, pos_list)
            for node in source.iter_stmts()
        ]

# Generated at 2022-06-24 07:51:47.563960
# Unit test for function get_definitions
def test_get_definitions():
    from jedi.api.project import get_sys_path

    for jedi_version in [[0,16,0], [0,18,0]]:
        definitions = get_definitions(
            "import os; os.chdir('.')",
            1,
            11,
            "python"
        )
        assert len(definitions) > 0
        assert defitions[0].file_path.endswith("os.py")
        assert defitions[0].line == 85
        assert defitions[0].column == 8

# Generated at 2022-06-24 07:51:54.297253
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert c["name"] == "name"
    assert c["complete"] == "complete"
    assert c["type"] == "type"
    assert c["description"] == "description"
    assert c["parent"] == "parent"
    assert c["full_name"] == "full_name"

# Generated at 2022-06-24 07:51:56.100420
# Unit test for function get_script_completions
def test_get_script_completions():
    assert hasattr(get_script_completions, "__code__")
    assert hasattr(get_script_completions, "__annotations__")

# Generated at 2022-06-24 07:52:00.834960
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    expected_keys = ["name", "complete", "type", "description", "parent", "full_name"]
    thonny_completion = ThonnyCompletion("name", "complete", "type", "description", None, "full_name")

    actual_keys = []
    for expected_key in expected_keys:
        actual_keys.append(thonny_completion.__getitem__(expected_key))

    assert actual_keys == expected_keys



# Generated at 2022-06-24 07:52:12.021561
# Unit test for function get_definitions
def test_get_definitions():
    import os
    import os.path
    import sys
    import platform
    from thonny.config import get_config_dir

    # Establish the configuration and runtime environment
    home_dir = get_config_dir()
    os.environ["USERPROFILE"] = home_dir
    os.environ["HOME"] = home_dir
    os.environ["PYTHONPATH"] = os.pathsep.join(sys.path)
    interpreter_path = os.path.join(sys.prefix, 'python.exe')
    sys.path.insert(0, home_dir)
    # Add the directory where the Python interpreter is located
    # to the PATH environment variable.
    # This ensures "python" is found by Jedi
    os.environ["PATH"] = os.path.dirname(interpreter_path)


# Generated at 2022-06-24 07:52:14.307455
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    ThonnyCompletion(name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name")

# Generated at 2022-06-24 07:52:23.423425
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi

    print("Current jedi version is: " + jedi.__version__)
    print("get_script_completions is " + str(get_script_completions))

    completions = get_script_completions("import sys", 0, 0, "")
    assert ("sys" in [c.name for c in completions])

    completions = get_script_completions("import sys\nimport zlib", 1, 0, "")
    assert ("zlib" in [c.name for c in completions])

    completions = get_script_completions("import sys\nimport z", 1, 0, "")
    assert ("zmq" in [c.name for c in completions])


# Generated at 2022-06-24 07:52:34.089174
# Unit test for function get_script_completions
def test_get_script_completions():
    import jedi
    import jedi.parser_utils

    source = "def f():\n    res = max("

    completions = get_script_completions(source, row=1, column=15, filename="test.py")
    assert len(completions) > 0
    assert any(c.name == "0" for c in completions)

    completions = get_script_completions(source, row=1, column=15, filename="test.py", sys_path=[""])
    assert len(completions) > 0
    assert any(c.name == "0" for c in completions)

    # test compatibility with old jedi versions

# Generated at 2022-06-24 07:52:43.606119
# Unit test for function parse_source
def test_parse_source():
    from thonny.misc_utils import running_on_windows
    import parso
    from parso.python import tree
    import jedi
    # broken in jedi 2018.7 and 2019.3
    if jedi.__version__[:5] in ["2018.7", "2019.3"]:
        return

    # on Windows, parso (or jedi?) have a bug:
    # https://github.com/davidhalter/parso/issues/36
    if running_on_windows():
        return
    
    # Without this test, the function won't be called while debugging
    # because parse_source is used before jedi has been imported
    func = parse_source("def prithee(arg1, arg2):\n  print(arg1)\n")
    assert isinstance(func, tree.Function)


# Generated at 2022-06-24 07:52:53.661257
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    source = "print('a')\n"

# Generated at 2022-06-24 07:53:00.276877
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    from parso.python import tree
    import parso 

    src="import sys"
    module = parso.parse(src)
    completion = ThonnyCompletion(
        name="sys",
        complete="sys",
        type=module.get_first_leaf(),
        description="import sys",
        parent=None,
        full_name="sys",
    )
    print(completion.name)
    assert completion.name == "sys"
    assert completion.complete == "sys"
    assert completion.type is module.get_first_leaf()
    assert completion.description == "import sys"
    assert completion.parent is None
    assert completion.full_name == "sys"

# Generated at 2022-06-24 07:53:05.971550
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    c = ThonnyCompletion(name, complete, type, description, parent, full_name)
    assert c.name == name
    assert c.complete == complete
    assert c.type == type
    assert c.description == description
    assert c.parent == parent
    assert c.full_name == full_name

# Generated at 2022-06-24 07:53:08.287920
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion(name = "test", complete = "test", description = "test", parent = "test", full_name = "test") is not None

# Generated at 2022-06-24 07:53:17.214446
# Unit test for function get_definitions
def test_get_definitions():
    var1_definition = get_definitions("x=10; x", 1, 1, "")[0]
    assert var1_definition.module_name == ""
    assert var1_definition.line == 1

    var2_definition = get_definitions("x=10; x", 2, 1, "")[0]
    assert var2_definition.module_name == ""
    assert var2_definition.line == 1

    func1_definition = get_definitions("def foo(): pass; foo", 1, 1, "")[0]
    assert func1_definition.module_name == ""
    assert func1_definition.line == 1

    func2_definition = get_definitions("def foo(): pass; foo", 2, 1, "")[0]
    assert func2_definition.module_name == ""
    assert func2

# Generated at 2022-06-24 07:53:18.740352
# Unit test for function get_script_completions
def test_get_script_completions():
    import sys
    import jedi
    import parso.python.tree


# Generated at 2022-06-24 07:53:24.462440
# Unit test for function get_script_completions
def test_get_script_completions():
    code = """
import math
math.
"""
    completions = get_script_completions(code, 3, 7, "test.py")

    assert len(completions) > 20
    assert set(c.name for c in completions) == set(("acos", "acosh", "asin", "asinh", "atan", "atan2", "atanh", "ceil", "comb"))



# Generated at 2022-06-24 07:53:33.196145
# Unit test for function get_definitions
def test_get_definitions():
    source = "import os; print(os.path.join('a', 'b'))"
    row = 2
    column = 16
    filename = "some_file.py"
    def test_get_definitions():
        source = "import os; print(os.path.join('a', 'b'))"
        row = 2
        column = 16
        filename = "some_file.py"
        definitions = get_definitions(source, row, column, filename)
        assert len(definitions) == 1
        definition = definitions[0]
        assert hasattr(definition, "in_builtin_module")
        assert hasattr(definition, "description")
        assert hasattr(definition, "is_keyword")
        assert hasattr(definition, "desc_with_module")
        assert hasattr(definition, "line")

# Generated at 2022-06-24 07:53:38.971296
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    a = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert a['name'] == 'name'
    assert a['complete'] == 'complete'
    assert a['type'] == 'type'
    assert a['description'] == 'description'
    assert a['parent'] == 'parent'
    assert a['full_name'] == 'full_name'

# Generated at 2022-06-24 07:53:50.092125
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("sumName", "sumComplete", 1, "sumDescription", "sumParent", "sumFullName")
    assert completion["name"] == "sumName"
    assert completion["complete"] == "sumComplete"
    assert completion["type"] == 1
    assert completion["description"] == "sumDescription"
    assert completion["parent"] == "sumParent"
    assert completion["full_name"] == "sumFullName"
    # Test that we can change a value
    completion["name"] = "newName"
    assert completion["name"] == "newName"
    assert completion["complete"] == "sumComplete"
    assert completion["type"] == 1
    assert completion["description"] == "sumDescription"
    assert completion["parent"] == "sumParent"
    assert completion["full_name"] == "sumFullName"
    #

# Generated at 2022-06-24 07:53:55.872841
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"a": 1, "b": 2}]
    completions = get_interpreter_completions("a", namespaces)
    assert len(completions) == 1
    assert completions[0].name == "a"
    assert completions[0].complete == "a"
    assert completions[0].type == "statement"
    assert completions[0].description == "int"
    assert completions[0].parent == "builtins"
    assert completions[0].full_name == "int"



# Generated at 2022-06-24 07:53:59.599684
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    comp = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert comp["name"] == "name"
    assert comp["complete"] == "complete"
    assert comp["type"] == "type"
    assert comp["description"] == "description"
    assert comp["parent"] == "parent"
    assert comp["full_name"] == "full_name"

# Generated at 2022-06-24 07:54:08.835151
# Unit test for function get_statement_of_position

# Generated at 2022-06-24 07:54:15.102578
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    t = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert t.name == "name"
    assert t.complete == "complete"
    assert t.type == "type"
    assert t.description == "description"
    assert t.parent == "parent"
    assert t.full_name == "full_name"


# For backwards compatibility with old jedi versions

# Generated at 2022-06-24 07:54:21.955663
# Unit test for function get_script_completions
def test_get_script_completions():
    """
    Tests that the signature for get_script_completions is correct for a given
    Jedi version, and that the function throws no exceptions.
    """
    import inspect
    from types import FunctionType

    from thonny.jedi_utils import get_script_completions
    from thonny.jedi_utils import jedi

    if jedi.__version__[:4] in ["0.13", "0.14", "0.15", "0.16", "0.17"]:
        assert len(inspect.signature(get_script_completions).parameters) == 4, (
            "get_script_completions has a wrong number of parameters"
        )
        assert not isinstance(get_script_completions, FunctionType)


# Generated at 2022-06-24 07:54:29.523859
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso.python.tree

    source = "1+2\nx=3"
    pos = len(source) - 1
    module = parse_source(source)
    assert isinstance(get_statement_of_position(module, pos), parso.python.tree.ExprStmt)

    source = "def f(): pass"
    pos = len(source) - 1
    module = parse_source(source)
    assert isinstance(get_statement_of_position(module, pos), parso.python.tree.FuncDef)

# Generated at 2022-06-24 07:54:36.557310
# Unit test for function get_definitions
def test_get_definitions():
    def test(source: str, row: int, column: int, filename: str, expected_defs: List[str]):
        import jedi
        import inspect
        import sys
        import os

        dirname = os.path.dirname(inspect.getfile(jedi))
        expected_defs = [os.path.join(dirname, f) for f in expected_defs]
        defs = get_definitions(source, row, column, filename)
        defs = set([d.module_path for d in defs])
        assert defs == set(expected_defs)

    test('import jedi', 0, 8, "", ["api.py", "jedi.py"])
    test('import jedi as j', 0, 8, "", ["api.py", "jedi.py"])


# Generated at 2022-06-24 07:54:38.212589
# Unit test for function parse_source
def test_parse_source():
    text = "print('test')"
    source = parse_source(text)

    assert source.get_code() == "print('test')"



# Generated at 2022-06-24 07:54:45.961451
# Unit test for function get_definitions
def test_get_definitions():
    import parso
    import jedi
    import re

    # this test only works with Jedi >= 0.17
    if _using_older_jedi(jedi):
        return

    # get_definitions is not a function, but a class instance method (mock)
    get_definitions_mock = get_definitions

    def assert_definitions(expected: str, script: str):
        node = parso.parse(script)
        for result in get_definitions_mock(script, node.start_pos[0], node.start_pos[1] + 1, "foo.py"):
            if result.type == "imported_module":
                # can not predict the file name for the library
                match = re.match(r"<module .* of '(.*)'>", str(result))
                assert match


# Generated at 2022-06-24 07:54:50.676705
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest.mock import Mock

    from jedi.api.classes import Interpreter
    from jedi import Script
    import jedi

    # Test for older jedi versions
    if _using_older_jedi(jedi):
        interpreter = Interpreter("import json", [{"json": Mock(name="json")}])
        completions = interpreter.completions()
        assert completions[0].name == "json"
        # Newer jedi versions have name="import " (note empty string after import)
        # However, in jedi before 0.16, the name attribute did not contain trailing '=' for argument completions,
        # since 0.16 it does.

    # Test for newer jedi versions

# Generated at 2022-06-24 07:55:01.751964
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import jedi
    import sys

    if "jedi" in sys.modules and sys.modules["jedi"].__version__ >= "0.17.0":
        return
    source = "import numpy as np"
    namespaces = [{"np": np}]
    completions = get_interpreter_completions(source, namespaces)
    assert completions[0].name == "nan"

# Generated at 2022-06-24 07:55:09.700926
# Unit test for function get_definitions
def test_get_definitions():
    # Check version of jedi
    import jedi
    jedi_version = jedi.__version__

    # Test input:
    # 1) Line number
    # 2) Column (starting with 0)
    # 3) Code
    tests = [
        (1, 4, "from tkinter import *", "Tk"),
        (1, 4, "from tkinter import *\nroot = Tk()", "Tk"),
        (2, 9, "from tkinter import *\nroot.title(\"Hello\")", "Misc"),
        (3, 0, "from tkinter import *\nroot.title(\"Hello\")\nroot.mainloop()", "None"),
    ]


# Generated at 2022-06-24 07:55:13.382413
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    c = ThonnyCompletion(name="name",
                         complete="complete",
                         type="type",
                         description="description",
                         parent="parent",
                         full_name="full_name")
    assert c["name"] == "name"

# Generated at 2022-06-24 07:55:23.124573
# Unit test for function get_script_completions
def test_get_script_completions():
    from unittest.mock import Mock

    completions = get_script_completions("sys.co", 0, 7, "f.py")
    assert len(completions) == 1
    assert completions[0].name == "compile"
    assert completions[0].complete == "compile"
    assert completions[0].type == "function"
    assert completions[0].description == "compile(source, filename, mode[, flags[, dont_inherit]])"
    assert completions[0].parent == "sys"
    assert completions[0].full_name == "sys.compile"

    completions = get_script_completions("sys.com", 0, 7, "f.py")
    assert len(completions) == 1

# Generated at 2022-06-24 07:55:25.027958
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Module
    result = parse_source("print('Hello World!')")
    assert isinstance(result, Module)

# Generated at 2022-06-24 07:55:31.563964
# Unit test for function get_definitions
def test_get_definitions():
    source = """\
    class SomeClass:
        def __init__(self):
            self.attr = "an attribute"
            self.other_attr = "another attribute"
    instance = SomeClass()
    """
    assert len(get_definitions(source, 3, 10, "")) == 1
    
    assert len(get_definitions(source, 7, 18, "")) == 2
    assert get_definitions(source, 7, 18, "")[0].line == 3
    assert get_definitions(source, 7, 18, "")[0].column == 9
    assert get_definitions(source, 7, 18, "")[1].line == 5
    assert get_definitions(source, 7, 18, "")[1].column == 9
    

# Generated at 2022-06-24 07:55:33.415623
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    completion = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert completion.name == "name"
    assert completion.complete == "complete"
    assert completion.type == "type"
    assert completion.description == "description"
    assert completion.parent == "parent"
    assert completion.full_name == "full_name"

# Generated at 2022-06-24 07:55:40.800626
# Unit test for function get_definitions
def test_get_definitions():
    def get_defs(source, row, col):
        from jedi.evaluate.utils import _copy_of_get_statement_of_position
        tree = parse_source(source)
        return [(d.description, d.line) for d in get_definitions(
            source, row, col, "")]

    assert get_defs("def foo(n): return 1\nfoo(n)", 2, 6) == [("function foo", 1)]
    assert get_defs("def foo(n): return 1\nfoo(n)", 2, 7) == [("function foo", 1)]
    assert get_defs("def foo(n): return 1\nfoo(n)", 2, 8) == [("function foo", 1)]

# Generated at 2022-06-24 07:55:44.826109
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion['name'] == 'name'
    assert completion['complete'] == 'complete'
    assert completion['type'] == 'type'
    assert completion['description'] == 'description'
    assert completion['parent'] == 'parent'
    assert completion['full_name'] == 'full_name'



# Generated at 2022-06-24 07:55:55.315047
# Unit test for function get_script_completions
def test_get_script_completions():
    def assert_completions(expected, source, row, column, filename="test.py", sys_path=None):
        actual = get_script_completions(source, row, column, filename, sys_path)
        try:
            assert sorted(expected) == sorted(actual)
        except AssertionError:
            for name in sorted(expected):
                if name not in actual:
                    print("Missing " + name)
            for name in sorted(actual):
                if name not in expected:
                    print("Unexpected " + name)

            raise

    assert_completions(["a"], "a", 0, 1)
    assert_completions(["ab"], "a.b", 0, 1)
    assert_completions(["abs", "ab"], "a.b", 0, 2)
    assert_complet

# Generated at 2022-06-24 07:56:04.651424
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # This replicates the function call from bg_scope_inspect.py
    from textwrap import dedent

    import jedi

    if _using_older_jedi(jedi):
        source = dedent(
            """\
    import tkinter
    tkinter.Tk()
    tkinter.Button
    """
        )
        namespaces = [
            {"type": "exec", "source": "", "globals": {}, "locals": {}},
            # The line after the above is needed to match the values sent by background_execution.py
            {"type": "exec", "source": "", "globals": {}, "locals": {}}
        ]

# Generated at 2022-06-24 07:56:05.601319
# Unit test for function parse_source
def test_parse_source():
    assert parse_source('x = "hello"').start_pos == (1,0)


# Generated at 2022-06-24 07:56:10.099896
# Unit test for function parse_source
def test_parse_source():
    ret = parse_source("x = 'a'")
    assert ret.type == "file_input"
    assert len(ret.children) == 1

    stmt = ret.children[0]
    assert stmt.type == "simple_stmt"
    assert len(stmt.children) == 3
    assert stmt.children[2].value == "'a'"

    ret = parse_source("x = 'a' + 'b'")
    assert ret.type == "file_input"
    assert len(ret.children) == 1

    stmt = ret.children[0]
    assert stmt.type == "simple_stmt"
    assert len(stmt.children) == 3

    expr = stmt.children[2]
    assert expr.type == "expr"
    plus = expr.children[1]
   

# Generated at 2022-06-24 07:56:17.585523
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    # This is for testing only

    # This should work with both older and newer jedi.
    assert isinstance(get_interpreter_completions("", [], []), list)

    # This should work with older jedi and raise exception with newer jedi
    try:
        get_interpreter_completions("", [], [])
    except Exception as e:
        assert "namespaces" in str(e)

    # This should work with both older and newer jedi.
    ns = {"a": 1}
    assert get_interpreter_completions("a.", [ns], [])[0]["name"] == "a"

    # This should work with older jedi and raise exception with newer jedi

# Generated at 2022-06-24 07:56:27.480865
# Unit test for function get_definitions
def test_get_definitions():
    from thonny import ast_utils
    from parso.python import tree

    source = "x = 5\nx**2"
    definitions = get_definitions(source, 1, 2, "test.py")
    assert len(definitions) == 1
    # must be a module
    assert isinstance(definitions[0].tree_node, tree.Module)

    source = "x = 5\ny = x + 1"
    definitions = get_definitions(source, 1, 7, "test.py")
    assert definitions[0].description == "int (5)"
    assert definitions[0].parent() == ast_utils.get_parent_module(source)

    definitions = get_definitions(source, 2, 7, "test.py")
    assert definitions[0].description == "int (5)"

# Generated at 2022-06-24 07:56:33.917104
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree

    node = tree.Node(type="root", children=[
        tree.Node(type="foo", start_pos=(1,1), end_pos=(1,4)),
        tree.Node(type="bar", start_pos=(1,5), end_pos=(1,7)),
        tree.Node(type="baz", start_pos=(1,8), end_pos=(1,10))
    ])
    
    # Each of the integers below should correspond to the second character of a child node
    positions = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    for pos in positions:
        found_node = get_statement_of_position(node, (1,pos))

# Generated at 2022-06-24 07:56:38.080435
# Unit test for function parse_source

# Generated at 2022-06-24 07:56:47.322935
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    from unittest import TestCase

    ThonnyTestCase = TestCase("__init__")
    tc = ThonnyCompletion("name","complete","type","description","parent","full_name")
    ThonnyTestCase.assertEqual(tc["name"], "name")
    ThonnyTestCase.assertEqual(tc["complete"], "complete")
    ThonnyTestCase.assertEqual(tc["type"], "type")
    ThonnyTestCase.assertEqual(tc["description"], "description")
    ThonnyTestCase.assertEqual(tc["parent"], "parent")
    ThonnyTestCase.assertEqual(tc["full_name"], "full_name")



# Generated at 2022-06-24 07:56:53.955919
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )

    assert thonny_completion["name"] == "name"
    assert thonny_completion["complete"] == "complete"
    assert thonny_completion["type"] == "type"
    assert thonny_completion["description"] == "description"
    assert thonny_completion["parent"] == "parent"
    assert thonny_completion["full_name"] == "full_name"

# Generated at 2022-06-24 07:57:03.187464
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    """Unit test for method __getitem__ of class ThonnyCompletion"""
    import random, string, sys
    random.seed()

    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(stringLength))

    methods = [
        "__getitem__",
        "__init__",
        "__dict__",
    ]

    @add_test_calls
    def _test__getitem__():
        """Test method __getitem__ of class ThonnyCompletion"""
        from thonny.globals import get_workbench

# Generated at 2022-06-24 07:57:12.276393
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    def do_test(source, expected_result):
        import jedi
        script = jedi.Script(source, 1, 1, "dummy")
        assert expected_result == get_statement_of_position(script._module, len(source))

    do_test("x = 1\n", "x = 1")
    do_test("x = 1\n\n", "x = 1")
    do_test("a = 1\nx = 1\n", "x = 1")
    do_test("x = 1\nif x:\n    a", "if x:")


if __name__ == "__main__":
    test_get_statement_of_position()

# Generated at 2022-06-24 07:57:13.816498
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    assert ThonnyCompletion("name","complete","type","description", "parent", "full_name")

# Generated at 2022-06-24 07:57:17.579857
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    tc['complete']


# Generated at 2022-06-24 07:57:23.482874
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "print"
    complete = "print"
    type = "statement"
    description = "def print(value, ...)"
    parent = []
    full_name = "print"
    tc = ThonnyCompletion(name, complete, type, description, parent, full_name)
    if tc['name'] == "print":
        pass
    else:
        raise Exception("test_ThonnyCompletion___getitem__ failed")

# Generated at 2022-06-24 07:57:24.908015
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    get_statement_of_position(parse_source("def f():\n  pass\n"), (1, 4))

# Generated at 2022-06-24 07:57:30.766785
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    assert tc.name == "name"
    assert tc.complete == "complete"
    assert tc.type == "type"
    assert tc.description == "description"
    assert tc.parent == "parent"
    assert tc.full_name == "full_name"

# Generated at 2022-06-24 07:57:31.788456
# Unit test for function get_definitions

# Generated at 2022-06-24 07:57:33.262134
# Unit test for function get_definitions

# Generated at 2022-06-24 07:57:41.655037
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    # input arguments
    name = "name"
    complete = "complete"
    type = 0
    description = "description"
    parent = "parent"
    full_name = "full_name"

    obj = ThonnyCompletion(name, complete, type, description, parent, full_name)

    assert obj.__getitem__('name') == name
    assert obj.__getitem__('complete') == complete
    assert obj.__getitem__('type') == type
    assert obj.__getitem__('description') == description
    assert obj.__getitem__('parent') == parent
    assert obj.__getitem__('full_name') == full_name

    try:
        obj.__getitem__('other')
    except:
        assert True
    else:
        assert False
test_ThonnyCompletion

# Generated at 2022-06-24 07:57:50.820998
# Unit test for function parse_source
def test_parse_source():
    source = "x = 1\n"
    node = parse_source(source)
    assert isinstance(node, parso.python.tree.Module)
    assert len(node.children) == 1
    assert node.children[0].type == "simple_stmt"
    assert node.children[0].children[0].type == "expr_stmt"
    assert node.children[0].children[0].children[0].type == "atom"
    assert node.children[0].children[0].children[0].children[0].type == "name"
    assert node.children[0].children[0].children[0].children[0].value == "x"



# Generated at 2022-06-24 07:57:58.724149
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    thonny_completion_object = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    if thonny_completion_object["name"] == "name":
        print("Test__ThonnyCompletion__getitem__ is successful!")
    else:
        print("Test__ThonnyCompletion__getitem__ is not successful!")

# test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:58:05.617545
# Unit test for function get_definitions
def test_get_definitions():
    import os.path
    
    source = r"""
from tkinter import *

root = Tk()

var = StringVar()
label = Label( root, textvariable=var )

var.set("Hello world!")
label.pack()

root.mainloop()
"""
    
    if os.path.isfile('tkinter.py'):
        filename = 'tkinter.py'
    else:
        filename = 'tkinter/__init__.py'

    definitions = get_definitions(source, 12, 7, filename)

    assert len(definitions) == 1
    assert definitions[0].name == 'StringVar'
    assert definitions[0].full_name == 'tkinter.StringVar'
    assert definitions[0].description.startswith('class StringVar(VfsContainer, Variable)')


# Generated at 2022-06-24 07:58:14.366200
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    def test():
        tc = ThonnyCompletion(
            name="name",
            complete="complete",
            type="type",
            description="description",
            parent="parent",
            full_name="full_name",
        )
        assert tc["name"] == "name"
        assert tc["complete"] == "complete"
        assert tc["type"] == "type"
        assert tc["description"] == "description"
        assert tc["parent"] == "parent"
        assert tc["full_name"] == "full_name"

    test()

# Generated at 2022-06-24 07:58:19.277020
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    namespaces = [{"b": 1, "a": [1, 2]}]
    comps = get_interpreter_completions(source="a", namespaces=namespaces)
    assert len(comps) == 1, comps
    assert comps[0].name == "a"
    assert comps[0].type == "list"



# Generated at 2022-06-24 07:58:25.124857
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_obj = ThonnyCompletion('name','complete','type','description','parent','full_name')
    assert test_obj.__getitem__('name') == 'name'
    assert test_obj.__getitem__('complete') == 'complete'
    assert test_obj.__getitem__('type') == 'type'
    assert test_obj.__getitem__('description') == 'description'
    assert test_obj.__getitem__('parent') == 'parent'
    assert test_obj.__getitem__('full_name') == 'full_name'



# Generated at 2022-06-24 07:58:35.230829
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    import unittest
    import jedi
    import parso

    if _using_older_jedi(jedi):
        raise unittest.SkipTest("skip this test when usin jedi>0.18")
    """Test function get_interpreter_completions with Interpreter in jedi>0.18."""
    source = "import noexistmodule\n"
    source += "noexistmodule"
    namespaces = []
    completions = get_interpreter_completions(source, namespaces)
    assert len(completions) == 0

    test_code = "a = [1, 2, 3]\n"
    test_code += "a."
    # test on member completion
    completions = get_interpreter_completions(test_code, namespaces)

# Generated at 2022-06-24 07:58:40.156171
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    tc = ThonnyCompletion(name="a", complete="b", type="c", description="d", parent="e", full_name="f")
    assert tc["name"] == tc.name
    assert tc["complete"] == tc.complete
    assert tc["type"] == tc.type
    assert tc["description"] == tc.description
    assert tc["parent"] == tc.parent
    assert tc["full_name"] == tc.full_name

# Generated at 2022-06-24 07:58:50.805452
# Unit test for constructor of class ThonnyCompletion
def test_ThonnyCompletion():
    test_name = "test_name"
    test_complete = "test_complete"
    test_type = "test_type"
    test_description = "test_description"
    test_parent = "test_parent"
    test_full_name = "test_full_name"
    test_thonny_completion = ThonnyCompletion(test_name, test_complete, test_type, test_description, test_parent, test_full_name)

    assert test_thonny_completion.name == test_name
    assert test_thonny_completion.complete == test_complete
    assert test_thonny_completion.type == test_type
    assert test_thonny_completion.description == test_description
    assert test_thonny_completion.parent == test_parent
   

# Generated at 2022-06-24 07:59:02.606492
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from collections import namedtuple

    def check(source, namespace_values, expected, sys_path=[]):
        # print("----" + source)
        namespaces = []
        for ns_k, ns_v in namespace_values.items():
            if ns_k == "__builtins__":
                ns_v = __builtins__
            namespaces.append(namedtuple("Namespace", [ns_k])(ns_v))
        result = get_interpreter_completions(source, namespaces, sys_path)
        result = [x.name for x in result]
        assert sorted(result) == sorted(expected)

    check("print", {}, ["print", "print(", "print "])
    check("print", {"foo": "bar"}, ["print", "print(", "print "])
    check

# Generated at 2022-06-24 07:59:09.599763
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import parso

    p = """def foo(arg1, arg2=[]):
    return arg1

foo(1, arg2=2)"""

    node = parso.parse(p)

    assert get_statement_of_position(node, 0) == node
    assert get_statement_of_position(node, 4) == node.children[0]
    assert get_statement_of_position(node.children[0], 4) == node.children[0]
    assert get_statement_of_position(node.children[0], 5) == node.children[0]
    assert get_statement_of_position(node.children[0].children[3], 0) == node.children[0]
    assert get_statement_of_position(node.children[0].children[3], 4) == node.children[0]

# Generated at 2022-06-24 07:59:11.972239
# Unit test for function parse_source
def test_parse_source():
    # Parso >= 0.4.0 returns an array with the root
    from parso.python.tree import Module

    assert isinstance(parse_source("import sys"), Module)

# Generated at 2022-06-24 07:59:18.315180
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    test_dict = {"name": "name", "complete": "complete", "type": "type", "description": "description", "parent": "parent", "full_name": "full_name"}
    tc = ThonnyCompletion("name", "complete", "type", "description", "parent", "full_name")
    for key in test_dict:
        assert test_dict[key] == tc.__getitem__(key)


# Generated at 2022-06-24 07:59:23.813481
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion = ThonnyCompletion(
        name="name", complete="complete", type="type", description="description", parent="parent", full_name="full_name"
    )
    assert completion.__getitem__("name") == "name"
    assert completion.__getitem__("complete") == "complete"
    assert completion.__getitem__("type") == "type"
    assert completion.__getitem__("description") == "description"
    assert completion.__getitem__("parent") == "parent"
    assert completion.__getitem__("full_name") == "full_name"

# Generated at 2022-06-24 07:59:28.522397
# Unit test for function get_definitions
def test_get_definitions():
    """
    Tests get_definitions functions.
    """
    get_definitions_text = "def f(x):\n\treturn x"
    get_definitions_script = get_definitions(get_definitions_text, 1, 5, None)
    for node in get_definitions_script:
        assert node.description == 'x'

# Generated at 2022-06-24 07:59:30.758445
# Unit test for function get_definitions
def test_get_definitions():
    defs = get_definitions("import math; math.sin", 1, 12, "")
    assert len(defs) > 0



# Generated at 2022-06-24 07:59:39.800985
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    from unittest import TestCase
    from jedi.api.classes import Completion

    class Test(TestCase):
        def assert_completions_match(self, expected, completions):
            names = [c.name for c in completions]
            # print(names)
            self.assertEqual(len(expected), len(completions), msg=names)
            for name in expected:
                self.assertIn(name, names)
            
            completions = sorted(completions, key=lambda c: c.name)
            expected = sorted(expected, key=lambda c: c.name)
            for i in range(len(expected)):
                self.assertEqual(expected[i].name, completions[i].name)

# Generated at 2022-06-24 07:59:48.412482
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    src = """
        class A():
            pass
    """    
    completions = get_script_completions(src, 2, 3, filename="")
    completion = completions[0]
    assert completion["name"] == "A"
    assert completion["complete"] == "A"
    assert completion["type"] == "class"
    assert completion["description"] == "class A"
    assert completion["parent"] == "<module>"
    assert completion["full_name"] == "module.A"

# Check if the above test completes without throwing an exption
test_ThonnyCompletion___getitem__()

# Generated at 2022-06-24 07:59:52.811307
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completions = get_interpreter_completions("", [], [])
    completions = [c.name for c in completions]
    assert "int" in completions
    assert "locals" not in completions
    assert "__class__" not in completions

# Generated at 2022-06-24 07:59:57.069142
# Unit test for function get_interpreter_completions
def test_get_interpreter_completions():
    completion = get_interpreter_completions("import math\nmath.", [{"math": math}])[0]
    assert completion.complete == "exp"
    assert completion.full_name == "math.exp"
    assert completion.description == "exp(x)\n\nReturn e raised to the power of x."

# Generated at 2022-06-24 07:59:58.312664
# Unit test for function parse_source
def test_parse_source():
    import parso


# Generated at 2022-06-24 08:00:05.892008
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    completion  = ThonnyCompletion('name', 'complete', 'type', 'description', 'parent', 'full_name')
    assert completion.__getitem__('name') == completion.name
    assert completion.__getitem__('complete') == completion.complete
    assert completion.__getitem__('type') == completion.type
    assert completion.__getitem__('description') == completion.description
    assert completion.__getitem__('parent') == completion.parent
    assert completion.__getitem__('full_name') == completion.full_name

# Generated at 2022-06-24 08:00:07.041652
# Unit test for function get_interpreter_completions

# Generated at 2022-06-24 08:00:10.962078
# Unit test for function parse_source
def test_parse_source():
    import parso
    source = 'def f():\n    pass\n'
    module = parse_source(source)
    assert isinstance(module, parso.python.tree.Module)


# Generated at 2022-06-24 08:00:21.670661
# Unit test for function get_script_completions
def test_get_script_completions():
    import parso
    import random
    import string

    def get_random_name(length):
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(length))

    def get_random_namespace(number_of_members):
        module = parso.create_module("module")
        for i in range(number_of_members):
            i = get_random_name(20)
            module.children.append(parso.python.tree.Name(module, i, i))
        return module

    def add_dummy_parameter(completion):
        completion.complete = completion.complete + "(" + get_random_name(20) + ")"

    for i in range(100):
        source = get_random_name(100)
        number_

# Generated at 2022-06-24 08:00:31.228453
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    name = "name"
    complete = "complete"
    type = "type"
    description = "description"
    parent = "parent"
    full_name = "full_name"
    completion = ThonnyCompletion(
        name=name, 
        complete=complete, 
        type=type, 
        description=description,
        parent=parent,
        full_name=full_name)
    assert(completion["name"] == name)
    assert(completion["complete"] == complete)
    assert(completion["type"] == type)
    assert(completion["description"] == description)
    assert(completion["parent"] == parent)
    assert(completion["full_name"] == full_name)
    
    

# Generated at 2022-06-24 08:00:38.065542
# Unit test for function get_definitions
def test_get_definitions():
    import unittest
    import random

    class MockDefinition:
        def __init__(self, line, column):
            self.line = line
            self.column = column

    def mock_get_definitions(source, line, column, path):
        result = []
        for column in range(1, source.count("a") + 1):
            result.append(MockDefinition(line, column))
        return result

    def mock_get_definitions_error(source, line, column, path):
        raise ValueError
    
    
    class TestGetDefinitions(unittest.TestCase):
        def test_no_definitions(self):
            self.assertEqual(get_definitions("def f(): pass", 1, 1, "dummy.py"), [])
        

# Generated at 2022-06-24 08:00:48.077875
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    import unittest
    import parso

    class Test(unittest.TestCase):
        def test(self):
            code = "import math\n" "math.sin(5)\n" "math.abs(5)"
            module = parso.parse(code)
            row, col = (1, 3)
            for_test = get_statement_of_position(module, row, col)
            self.assertEqual(for_test.type, "import_from")
            row, col = (2, 3)
            for_test = get_statement_of_position(module, row, col)
            self.assertEqual(for_test.type, "power")

    unittest.main(verbosity=2, exit=False)

# Generated at 2022-06-24 08:00:49.819253
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    t = ThonnyCompletion("name", "name", "", "", None, None)
    assert t["name"] == "name"

# Generated at 2022-06-24 08:00:54.302192
# Unit test for function get_script_completions
def test_get_script_completions():
    from jedi.api.classes import Script
    from jedi.parser.python import parse

    tree = parse("import sys")
    completions = get_script_completions("import sys", 0, 7, "")
    for c in completions:
        assert isinstance(c, ThonnyCompletion)



# Generated at 2022-06-24 08:01:03.375283
# Unit test for method __getitem__ of class ThonnyCompletion
def test_ThonnyCompletion___getitem__():
    import jedi

    # Create a jedi completion
    source = "import sys\nprint(sys.arg"
    script = jedi.Script(source, 3, 8, "<stdin>")
    completions = script.completions()
    completion = completions[0]

    assert completion.full_name == "sys.argv"
    assert completion.description == "A list of command line arguments passed to a Python script."
    assert completion.type == "list"
    assert completion.complete == "sys.argv"

    # Mini test 2
    source = "import sys\nprint(sys.arg"
    script = jedi.Script(source, 3, 8, "<stdin>")
    completions = script.completions()
    completion = completions[0]

    # Create a ThonnyCompletion
    new

# Generated at 2022-06-24 08:01:09.034224
# Unit test for function parse_source
def test_parse_source():
    from parso.python.tree import Leaf

    source = "print(1 + 2)"
    root = parse_source(source)
    assert root.type == "file_input"

    leafs = list(root.iter_leaves())
    assert len(leafs) == 6
    assert isinstance(leafs[0], Leaf)

# Generated at 2022-06-24 08:01:18.632837
# Unit test for function get_statement_of_position
def test_get_statement_of_position():
    from parso.python import tree
    from parso.parser import ParserSyntaxError
    from parso.utils import split_lines
    from test.utils import parse_to_list

    assert get_statement_of_position(None, (0, 0)) is None

    node = parse_source("print()")
    assert get_statement_of_position(node, (1, 0)) is None

    assert (
        get_statement_of_position(node, (1, 1))
        == parse_source("print()").children[0].children[1]
    )

    node = parse_source("a = print(1)")
    assert (
        get_statement_of_position(node, (1, 1))
        == parse_source("a = print(1)").children[0].children[1]
    )

