

# Generated at 2022-06-24 23:31:57.896876
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create a new instance of class ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()

    # Setup the mock parameters
    args = ['None', {'apparmor': {'status': 'enabled'}}]
    module = args.pop(0)
    collected_facts = args.pop(0)

    # Run the collect() method of class ApparmorFactCollector to obtain result
    result = apparmor_fact_collector.collect(module, collected_facts)

    # Verify the result
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:00.172922
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert 'apparmor' in result



# Generated at 2022-06-24 23:32:07.858493
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_generator = [
        {
            'description': 'Apparmor is disabled',
            'os.path.exists.return_value': False,
            'expected': {'apparmor': {'status': 'disabled'}}
        },
        {
            'description': 'Apparmor is enabled',
            'os.path.exists.return_value': True,
            'expected': {'apparmor': {'status': 'enabled'}}
        }
    ]

    for test_case in test_case_generator:
        apparmor_fact_collector = ApparmorFactCollector()
        apparmor_fact_collector.collector.module_commands = {
            'which': {
                'path': '/bin/which'
            }
        }
        apparmor_fact_collector.collector.module

# Generated at 2022-06-24 23:32:10.494621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:14.751172
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_dict = apparmor_fact_collector_0.collect()
    assert isinstance(apparmor_fact_dict, dict)
    assert apparmor_fact_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:32:17.065549
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:19.758927
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == { 'apparmor': { 'status': 'disabled' } }

# Generated at 2022-06-24 23:32:22.137019
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert 'apparmor' in facts.keys()


# Generated at 2022-06-24 23:32:27.973348
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    module_0 = None
    collected_facts_0 = None
    returned_value_0 = apparmor_fact_collector_0.collect(module_0, collected_facts_0)
    assert returned_value_0 == {'apparmor': {'status': 'disabled'}}

    # apparmor = None
    apparmor_fact_collector_1 = ApparmorFactCollector()
    module_0 = None
    collected_facts_0 = None
    returned_value_1 = apparmor_fact_collector_1.collect(module_0, collected_facts_0)
    assert returned_value_1 == {'apparmor': {'status': 'disabled'}}



# Generated at 2022-06-24 23:32:29.880259
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:35.224404
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_collect = apparmor_fact_collector.collect()
    assert isinstance(apparmor_collect, dict)

# Generated at 2022-06-24 23:32:36.337031
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert apparmor_fact_collector_0.collect() is not None

# Generated at 2022-06-24 23:32:38.025719
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    r_0 = ApparmorFactCollector().collect()
    r_1 = ApparmorFactCollector().collect()
    assert r_0 == r_1


# Generated at 2022-06-24 23:32:42.843193
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:44.052284
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:45.544012
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_collect = apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:46.915304
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:32:48.530184
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:32:52.128914
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict == {'apparmor': {}}

# Generated at 2022-06-24 23:32:53.174988
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert os.path.exists('/sys/kernel/security/apparmor') == True

# Generated at 2022-06-24 23:33:02.176807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res=apparmor_fact_collector_0.collect()
    assert 'status' in res['apparmor']



# Generated at 2022-06-24 23:33:07.013787
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # Try to collect facts by calling collect method of ApparmorFactCollector
    # class
    collected_facts = apparmor_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert collected_facts['apparmor'] == {'status': 'enabled'}


# Generated at 2022-06-24 23:33:10.317146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert(apparmor_fact_collector_1.collect() is not None)
    assert(type(apparmor_fact_collector_1.collect()) is dict)


# Generated at 2022-06-24 23:33:14.937927
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of ApparmorFactCollector
    test_instance_0 = ApparmorFactCollector()

    # Test the collect method
    test_instance_0.collect()

# Generated at 2022-06-24 23:33:19.018858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {
        'apparmor': {'status': 'disabled'}
    }


# Generated at 2022-06-24 23:33:23.646303
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:29.420418
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  apparmor_fact_collector_0 = ApparmorFactCollector()
  ansible_facts = {}
  apparmor_fact_collector_0.collect(ansible_facts)
  assert type(ansible_facts['apparmor']['status']) is str


# Generated at 2022-06-24 23:33:34.264859
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:43.308347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # This is the expected result of the collect method
    expected_apparmor_facts = {"apparmor": {"status": "enabled"}}
    apparmor_fact_collector = ApparmorFactCollector()
    # If apparmor is not enabled this should return an empty dictionary
    if not os.path.exists('/sys/kernel/security/apparmor'):
        expected_apparmor_facts = {"apparmor": {"status": "disabled"}}

    assert apparmor_fact_collector.collect() == expected_apparmor_facts

# Generated at 2022-06-24 23:33:45.993924
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert apparmor_fact_collector_0.collect() == {
        'apparmor': {
            'status': 'enabled',
        },
    }

# Generated at 2022-06-24 23:33:59.142785
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector_1.collect()
    assert collected_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:34:01.980859
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:04.369485
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:09.591971
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
#
# Init ApparmorFactCollector object
#
    apparmor_fact_collector_0 = ApparmorFactCollector()
#
# Run method collect with parameters
#
    apparmor_fact_collector_0.collect()
#
# Clean up
#
    apparmor_fact_collector_0 = None

# Generated at 2022-06-24 23:34:10.895386
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:34:15.031272
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    x = apparmor_fact_collector_1.collect()
    assert x['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:34:17.378781
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {
        'status': 'enabled',
    }
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result["apparmor"] == apparmor_facts

# Generated at 2022-06-24 23:34:21.016741
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_co

# Generated at 2022-06-24 23:34:23.246260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:27.831532
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector_1.collect(module=None, collected_facts=None)['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_fact_collector_1.collect(module=None, collected_facts=None)['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:34:45.204385
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {
        'status': 'disabled',
    }}

    apparmor_fact_collector_1 = ApparmorFactCollector()
    os.environ['TEST_APPARMOR'] = '1'
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {
        'status': 'enabled',
    }}

# Generated at 2022-06-24 23:34:49.572667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:34:52.424187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    vars_0 = apparmor_fact_collector_0.collect()
    assert vars_0['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:34:56.964259
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:34:59.741072
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # for any exception raise in the collect method of class ApparmorFactCollector
    # the exception should be "collect"
    apparmor_fact_collector_0 = ApparmorFactCollector()
    with pytest.raises(Exception) as exception_info:
        apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:04.533013
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor'] is not None
    var_2 = apparmor_fact_collector_1.collect()
    assert var_2['apparmor'] is not None
    var_3 = apparmor_fact_collector_1.collect()
    assert var_3['apparmor'] is not None
    var_4 = apparmor_fact_collector_1.collect()
    assert var_4['apparmor'] is not None
    var_5 = apparmor_fact_collector_1.collect()
    assert var_5['apparmor'] is not None


# Generated at 2022-06-24 23:35:05.879596
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {"apparmor": {"status": "enabled"}}

# Generated at 2022-06-24 23:35:06.835839
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:07.795288
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:09.103542
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True == true, "Unit test for method collect of class ApparmorFactCollector was not able to be run. Please check the test and report."


# Generated at 2022-06-24 23:35:35.636339
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert('apparmor' in var_0)
    assert(var_0['apparmor']['status'] == 'disabled')

# Generated at 2022-06-24 23:35:39.736052
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:42.375705
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:35:43.932903
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:44.645393
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:35:48.883746
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:52.785663
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect(collected_facts = None)
    assert isinstance(var_0, dict)
    assert var_0 == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:35:55.840377
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1 == {}, "apparmor_fact_collector_0.collect returned unexpected value"


# Generated at 2022-06-24 23:35:58.141335
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:00.546883
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:59.055885
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert type(var_1) == dict
    assert set(var_1.keys()) == set(['apparmor'])
    apparmor_facts_0 = var_1['apparmor']
    assert type(apparmor_facts_0) == dict
    assert set(apparmor_facts_0.keys()) == set(['status'])
    assert apparmor_facts_0['status'] == 'disabled'

# Generated at 2022-06-24 23:37:01.740689
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect(None, None) == {'apparmor': {'status': 'disabled'}}

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:37:06.382022
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:07.534930
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_0 = ApparmorFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-24 23:37:16.222067
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = MagicMock()
    mock_collected_facts = MagicMock()
    mock_System = MagicMock()
    mock_Path = MagicMock()

    # Construct the call sequence
    apparmor_fact_collector_0 = ApparmorFactCollector()
    mock_Path.exists.return_value = True
    apparmor_fact_collector_0.collect(mock_module, mock_collected_facts)
    mock_Path.exists.assert_called_once_with('/sys/kernel/security/apparmor')



# Generated at 2022-06-24 23:37:17.870939
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:23.265858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:37:26.365787
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    var_1 = apparmor_fact_collector_0.collect(collected_facts_0)


# Generated at 2022-06-24 23:37:27.456442
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:37:30.562521
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-24 23:39:37.714882
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # test with a simple directory.
    apparmor_fact_collector.collect()

    # test with a simple directory.
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:39:39.772301
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var == {'apparmor': {'status': 'disabled'}}, var


# Generated at 2022-06-24 23:39:42.528680
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'enabled'}} or var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:39:44.500010
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(test_case_0)

# Generated at 2022-06-24 23:39:46.953962
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {}}



# Generated at 2022-06-24 23:39:51.378975
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:39:57.915419
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_1 = ApparmorFactCollector()
    try:
        var_1.collect()
    except Exception:
        import traceback
        exception = traceback.format_exc()
        var_1.logger.warn('Exception: ' + str(exception))
        assert False


# Generated at 2022-06-24 23:40:03.839995
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0 is not None
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:40:05.048551
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:40:10.887095
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print("test_ApparmorFactCollector_collect")
    ap = ApparmorFactCollector()

    # For coverage
    ap._get_file_content("/sys/kernel/security/apparmor/profiles")

    ret = ap.collect()
    assert ret['apparmor']['status'] == 'disabled'
