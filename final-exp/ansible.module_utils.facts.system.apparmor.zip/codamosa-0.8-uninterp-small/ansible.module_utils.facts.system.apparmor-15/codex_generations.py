

# Generated at 2022-06-24 23:31:50.687918
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()

    assert facts_dict_0['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:31:55.248933
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in collected_facts
    assert collected_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:31:56.290549
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()


# Generated at 2022-06-24 23:31:59.326497
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:01.774865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    f = apparmor_fact_collector_1.collect()
    assert 'apparmor' in f

# Generated at 2022-06-24 23:32:04.109678
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    expected = {'apparmor': {'status': 'disabled'}}
    assert result == expected


# Generated at 2022-06-24 23:32:05.298782
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    pass

# Generated at 2022-06-24 23:32:07.942244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:11.997416
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    # Test with not implemented method 'dump'
    apparmor_fact_collector_1.dump()

# Generated at 2022-06-24 23:32:18.488460
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()

    assert isinstance(result, dict) is True
    assert result.get('apparmor', None) is not None
    assert isinstance(result.get('apparmor', None), dict) is True
    assert result.get('apparmor').get('status', None) is not None
    assert isinstance(result.get('apparmor').get('status', None), str) is True or isinstance(result.get('apparmor').get('status', None), unicode) is True


# Generated at 2022-06-24 23:32:23.015968
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:26.207814
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:29.564494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test: method collect of class ApparmorFactCollector"""
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert not apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:32:34.289865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor'] == {'status': 'disabled'}
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-24 23:32:35.377118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()

# Generated at 2022-06-24 23:32:37.380941
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res = apparmor_fact_collector_0.collect()
    assert res is not None



# Generated at 2022-06-24 23:32:38.982620
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:42.256844
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {}}, 'Unexpected value from ApparmorFactCollector.collect()'

# Generated at 2022-06-24 23:32:51.645918
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts_1 = {}
    apparmor_facts_1 = {}
    list_of_facts_1 = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
       apparmor_facts_1['status'] = 'enabled'
    else:
       apparmor_facts_1['status'] = 'disabled'
    list_of_facts_1['apparmor'] = apparmor_facts_1
    collected_facts_1['ansible_local'] = list_of_facts_1
    assert apparmor_fact_collector_1.collect(collected_facts=collected_facts_1) == collected_facts_1

# Generated at 2022-06-24 23:32:55.511429
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:04.218510
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    results = apparmor_fact_collector_0.collect()
    assert 'apparmor' in results
    assert 'status' in results['apparmor']


# Generated at 2022-06-24 23:33:07.927656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    apparmor_fact_dict = apparmor_fact_collector_obj.collect()
    expected_dict = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_dict == expected_dict

# Generated at 2022-06-24 23:33:09.512164
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector_0 = ApparmorFactCollector()
    apparmor_collector_0.collect()

# Generated at 2022-06-24 23:33:14.515518
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0 != None

# Generated at 2022-06-24 23:33:18.881930
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Test with the first available test case
    apparmor_fact_collector_1.collect()
    # Test with the second available test case
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:20.784543
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:23.904034
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    ret_val_0 = apparmor_fact_collector_0.collect()
    assert ret_val_0['apparmor'] == {
        'status': 'disabled'
    }


# Generated at 2022-06-24 23:33:27.371520
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    test_facts = dict()
    apparmor_fact_collector_1.collect(collected_facts=test_facts)
    assert test_facts


# Generated at 2022-06-24 23:33:31.360018
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:33.085751
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:47.274792
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = ''
    apparmor_fact_collector._client = ''
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:49.973270
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:55.184209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    test_dict_1 = {'apparmor': {'status': 'enabled'}}
    test_dict_1 = apparmor_fact_collector_1.collect()
    assert test_dict_1['apparmor']['status'] == 'enabled'
    #assert test_dict_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:00.212331
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:06.054648
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector_collect_0 = ApparmorFactCollector().collect()
        assert apparmor_fact_collector_collect_0['apparmor']['status'] == 'enabled'
    else:
        apparmor_fact_collector_collect_0 = ApparmorFactCollector().collect()
        assert apparmor_fact_collector_collect_0['apparmor']['status'] == 'disabled'




# Generated at 2022-06-24 23:34:08.876731
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    result = apparmor_fact_collector_1.collect()
    assert result['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:34:12.101923
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # No exception should be raised
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:17.057482
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:34:18.514021
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:34:24.419257
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # In the case of apparmor_facts['status'] == 'disabled':
    apparmor_fact_collector_0.collect(module=None, collected_facts=None)
    # In the case of apparmor_facts['status'] == 'enabled':
    apparmor_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-24 23:34:50.239363
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {
        'apparmor': {'status': 'disabled'}
    }

# Generated at 2022-06-24 23:34:51.994289
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:34:54.237708
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.name == 'apparmor'
    assert apparmor_fact_collector_1.collect() == {}

# Generated at 2022-06-24 23:34:58.355300
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:00.545200
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert 'apparmor' in apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:01.500597
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    #Test collect method of ApparmorFactCollector
    assert True

# Generated at 2022-06-24 23:35:08.453493
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.name == 'apparmor'
    assert apparmor_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 23:35:08.939505
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:35:13.195912
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._load_platform_subclass = lambda x, y: False
    apparmor_fact_collector.get_file_content = lambda x: 'AppArmor: enabled\n'
    apparmor_fact_collector._get_os_version = lambda: {'distribution': 'ubuntu', 'distribution_version': '16.04'}
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}



# Generated at 2022-06-24 23:35:13.708380
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:35:40.767798
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print("<-----test_ApparmorFactCollector_collect------->")
    test_case_0()
    print("<-----end test_ApparmorFactCollector_collect------->")


# Generated at 2022-06-24 23:35:42.429769
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_0 = ApparmorFactCollector()
    var_1 = {}
    var_2 = {'apparmor': {'status': 'enabled'}}
    assert var_0.collect(var_1) == var_2

# Generated at 2022-06-24 23:35:47.208391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = isinstance(apparmor_fact_collector_0.collect(), dict)
    assert var_0

# Generated at 2022-06-24 23:35:48.654801
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None

# Generated at 2022-06-24 23:35:50.375364
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:52.754333
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:56.821182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_0.method_called('collect') == False
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_0.method_called('collect') == False
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_0.method_called('collect') == False
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_0.method_called('collect') == False
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_0.method_called('collect') == False
    # Test if the method collect has been invoked
    assert apparmor_fact_collector_

# Generated at 2022-06-24 23:35:58.856111
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:36:01.913878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert type(var_0) is dict

# Generated at 2022-06-24 23:36:03.102845
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_0 = ApparmorFactCollector()
    var_0.collect()

# Generated at 2022-06-24 23:37:00.976263
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    # Test for the absence of exception thrown by the method
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:37:09.581604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

# Generated at 2022-06-24 23:37:13.257492
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:37:16.583130
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:37:19.415334
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:23.193976
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:37:26.174427
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:37:28.122267
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:37:30.806894
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert len(var_0) == 1

# Generated at 2022-06-24 23:37:33.687679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] in ['enabled', 'disabled']
    assert var_0['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:39:41.790238
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:39:43.976485
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert callable(ApparmorFactCollector.collect)
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

test_case_0()

# Generated at 2022-06-24 23:39:45.801024
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: %s' % (e))
        print('Could not test method collect of class ApparmorFactCollector')

# Generated at 2022-06-24 23:39:51.378874
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if apparmor_fact_collector.collect() != {'apparmor': {'status': 'enabled'}}:
        raise Exception('Test case 0 failed')
    else:
        pass


# Generated at 2022-06-24 23:39:53.080771
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-24 23:39:57.588245
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:02.917936
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:05.574751
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:40:10.302619
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
#     assert var_1['apparmor']['status'] == 'enabled', 'Failed - variable did not match'

# Generated at 2022-06-24 23:40:13.381148
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()