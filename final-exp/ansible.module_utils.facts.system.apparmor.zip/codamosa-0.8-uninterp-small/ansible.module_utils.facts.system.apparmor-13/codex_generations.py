

# Generated at 2022-06-24 23:31:54.521141
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:31:55.856421
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:31:58.670483
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:00.535825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
        apparmor_fact_collector = ApparmorFactCollector()
        apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:04.209234
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert isinstance(apparmor_facts, dict)

# Generated at 2022-06-24 23:32:09.261763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    ansible_collected_facts_0 = {}
    ansible_collected_facts_0['ansible_python_version'] = '2.7.5'
    ansible_collected_facts_0['ansible_distribution'] = 'Fedora'
    ansible_collected_facts_0['ansible_distribution_major_version'] = '26'
    ansible_collected_facts_0['ansible_distribution_version'] = '26'
    ansible_collected_facts_0['ansible_distribution_release'] = '1.6'
    ansible_collected_facts_0['ansible_os_family'] = 'RedHat'
    ansible_collected_facts_0['ansible_selinux']

# Generated at 2022-06-24 23:32:12.257735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert type(apparmor_fact_collector_0.collect()) is dict

# Generated at 2022-06-24 23:32:19.805265
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # Test apparmor is enabled
    apparmor_fact_collector._run_command = lambda x: (0, 'test', '')
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    # Test apparmor is disabled
    apparmor_fact_collector._run_command = lambda x: (1, 'test', '')
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:32:23.965335
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # apparmor_fact_collector_0.collect
    # Return value of this method is not tested because the side effects
    # of the method cannot be tested in a unit test


if __name__ == '__main__':
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:28.120604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    value1 = apparmor_fact_collector_1.collect()
    assert value1['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:32:35.071480
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_facts = apparmor_fact_collector_0.collect()

    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:32:41.000022
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    module_0 = {}
    facts_dict = {}
    collected_facts_0 = {'apparmor': {}}
    if os.path.exists('/sys/kernel/security/apparmor'):
        collected_facts_0['apparmor']['status'] = 'enabled'
    else:
        collected_facts_0['apparmor']['status'] = 'disabled'
    assert apparmor_fact_collector_0.collect(module_0, facts_dict) == collected_facts_0


# Generated at 2022-06-24 23:32:45.730020
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:32:53.030515
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert type(apparmor_facts) == dict
    assert apparmor_facts.get('apparmor') is not None
    assert type(apparmor_facts['apparmor']) == dict
    assert apparmor_facts['apparmor'].get('status') is not None
    assert type(apparmor_facts['apparmor']['status']) == str

# Generated at 2022-06-24 23:32:57.304874
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_dict = apparmor_fact_collector.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_dict['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_dict['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:33:02.177079
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case = ApparmorFactCollector()
    apparmor_path = os.path.exists('/sys/kernel/security/apparmor')
    assert test_case.collect() == {'apparmor': {'status': 'enabled'}} if apparmor_path else {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:05.158502
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 23:33:10.669456
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    try:
        assert(isinstance(apparmor_fact_collector_1.collect(), dict))
    except AssertionError:
        print("AssertionError raised in test_ApparmorFactCollector_collect")
        raise
    else:
        print("No exception raised in test_ApparmorFactCollector_collect")
        return
# Test Cases for ApparmorFactCollector


# Generated at 2022-06-24 23:33:14.591073
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert type(apparmor_fact_collector_0.collect()) == dict

# Generated at 2022-06-24 23:33:17.645117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result_1 = apparmor_fact_collector_1.collect()
    assert result_1['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:33:26.362627
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test setup
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Test execution
    result = apparmor_fact_collector_0.collect()

    # Test assertion
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:33:30.758773
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:33:34.715407
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    try:
        assert ((result['apparmor'] == {'status': 'enabled'}) or
                (result['apparmor'] == {'status': 'disabled'}))
    except AssertionError as exc:
        print(exc)


# Generated at 2022-06-24 23:33:39.254529
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert result == {
        'apparmor': {
            'status': 'disabled'
        },
}

# Generated at 2022-06-24 23:33:42.868490
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:33:50.909829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = {}
    # Call method collect of ApparmorFactCollector with arguments apparmor_fact_collector_0=apparmor_fact_collector_0, facts_dict_0=facts_dict_0, module=None
    try:
        ret = apparmor_fact_collector_0.collect(apparmor_fact_collector_0, facts_dict_0, None)
        # if type(ret) is dict:
        #     print("\n\nPASSED\n\n")
        # else:
        #     print("\n\nFAILED\n\n")
        assert type(ret) is dict
    except AssertionError:
        print("\n\nFAILED\n\n")
   

# Generated at 2022-06-24 23:33:57.871130
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1._get_file_content = lambda path: ''
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}
    assert apparmor_fact_collector_1.collect()['apparmor']['status'] == 'disabled'
    apparmor_fact_collector_1._get_file_content = lambda path: 'Y = 1'
    assert apparmor_fact_collector_1.collect()['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:34:01.900075
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    test_collect = apparmor_fact_collector_collect.collect()
    assert test_collect == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:05.699269
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.collect() == apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:08.003920
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = {}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:15.321441
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:23.086302
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # When apparmor is enabled
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._read_file(filename='/sys/kernel/security/apparmor')
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    # When apparmor is disabled
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:25.647176
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    expected = {'apparmor': {'status': 'enabled'}}
    actual = apparmor_fact_collector_0.collect()
    assert actual == expected

# Generated at 2022-06-24 23:34:31.939108
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    collected_facts_0 = dict()
    apparmor_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert collected_facts_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:33.898058
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:38.890930
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Test with apparmor enabled
    os.environ['ANSIBLE_APPARMOR_STATUS'] = 'enabled'
    apparmor_facts = apparmor_fact_collector_0.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    # Test with apparmor disabled
    os.environ['ANSIBLE_APPARMOR_STATUS'] = 'disabled'
    apparmor_facts = apparmor_fact_collector_0.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'



# Generated at 2022-06-24 23:34:41.784214
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    ans_dict = apparmor_fact_collector_1.collect()
    print(ans_dict)


test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:34:45.344431
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ApparmorFactCollector_collect_collected_facts = {}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect('A', test_ApparmorFactCollector_collect_collected_facts)
    # Verify
    assert len(test_ApparmorFactCollector_collect_collected_facts) == 1
    assert 'apparmor' in test_ApparmorFactCollector_collect_collected_facts
    assert test_ApparmorFactCollector_collect_collected_facts['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:34:55.078792
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:34:56.646499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert type(apparmor_fact_collector_0.collect()) is dict


# Generated at 2022-06-24 23:35:08.972659
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    apparmor_fact_collector_collect.collect()


# Generated at 2022-06-24 23:35:10.690642
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:13.744157
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() is not None

# Generated at 2022-06-24 23:35:19.548262
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:26.156677
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert not apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.name = False
    assert not apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.name = 'x'
    assert not apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:27.137063
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert test_case_0() == {}

# Generated at 2022-06-24 23:35:33.830698
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = apparmor_fact_collector_0.collect(collected_facts)

    assert len(apparmor_fact_collector_0._fact_ids) == 1
    assert apparmor_fact_collector_0._fact_ids == set(['apparmor'])
    assert "apparmor" in apparmor_facts
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts["apparmor"]["status"] == "enabled"
    else:
        assert apparmor_facts["apparmor"]["status"] == "disabled"

# Generated at 2022-06-24 23:35:34.954900
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {}

# Generated at 2022-06-24 23:35:39.424277
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    status = apparmor_fact_collector.collect()
    assert isinstance(status, dict)


# Generated at 2022-06-24 23:35:45.985778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}
    # if you need to check that the result is of the right type, use assertIsInstance:
    assert isinstance(apparmor_fact_collector_1.collect(), dict)
    # if you need to check that the result has the right content, use assertEqual:
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}
    # if you need to check that the result does not have some content, use assertNotIn:
    assert 'apparmor' not in apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:09.863412
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:36:15.002536
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:36:16.874042
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:36:18.028004
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()




# Generated at 2022-06-24 23:36:20.710387
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    res = apparmor_fact_collector.collect()
    assert 'apparmor' in res

# Generated at 2022-06-24 23:36:22.888590
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert(apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-24 23:36:28.262996
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    os.path.exists = lambda path: True
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}, "apparmor_fact_collector.collect() != {'apparmor': {'status': 'enabled'}}"

    os.path.exists = lambda path: False
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}, "apparmor_fact_collector.collect() != {'apparmor': {'status': 'disabled'}}"

# Generated at 2022-06-24 23:36:31.106686
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()



# Generated at 2022-06-24 23:36:32.809174
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:36:34.743749
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:37:35.662766
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}
    apparmor_fact_collector_1.name = 'apparmor'

# Generated at 2022-06-24 23:37:36.979666
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:43.108829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {'apparmor': {'status': 'disabled'}}
    collected_facts_1 = {}
    collect_result_1 = apparmor_fact_collector_0.collect(collected_facts=collected_facts_1)
    assert collected_facts_0 == collect_result_1

# Generated at 2022-06-24 23:37:46.977588
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.name = "apparmor_fact_collector_name"
    apparmor_fact_collector._fact_ids = "apparmor_fact_collector_fact_ids"

    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:37:47.686396
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert True

# Generated at 2022-06-24 23:37:50.078480
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_1.collect(collected_facts=collected_facts)
    assert collected_facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:37:53.190479
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    print(apparmor_fact_collector_1.collect())

# Generated at 2022-06-24 23:37:56.666536
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:38:01.240329
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.__class__.__dict__['_fact_ids'] = {}
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor']['status'] != ''

# Generated at 2022-06-24 23:38:05.528336
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.name = "test_name_0"
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:14.799192
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:40:18.763798
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_facts'] = {}
    collected_facts_0['ansible_facts']['apparmor'] = {}
    collected_facts_0['ansible_facts']['apparmor']['status'] = 'enabled'
    assert apparmor_fact_collector_0.collect(collected_facts_0) == collected_facts_0

# Generated at 2022-06-24 23:40:20.909285
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Act
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Assert
    assert apparmor_fact_collector_0 is not None

# Unit tes for field _fact_ids of class ApparmorFactCollector

# Generated at 2022-06-24 23:40:23.174800
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert type(apparmor_facts) == dict
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-24 23:40:30.021836
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:40:32.314477
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = {
        "apparmor": {
            "status": "enabled"
        }
    }
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_collect = apparmor_fact_collector.collect(None, None)
    assert apparmor_fact_collector_collect == facts_dict

# Generated at 2022-06-24 23:40:36.765604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_collect = ApparmorFactCollector()
    assert ApparmorFactCollector_collect.collect() != {}

# Generated at 2022-06-24 23:40:41.625147
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    result = apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'apparmor' in result['ansible_facts']


# Generated at 2022-06-24 23:40:46.393257
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # mock up a module to be passed to the collect method of ApparmorFactCollector
    class MockModule:
        pass
    mock_module_0 = MockModule()

    # mock a collected facts dict

# Generated at 2022-06-24 23:40:51.734586
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()

    # Unit test for collect with None
    apparmor_fact_collector_0.collect() == apparmor_fact_collector_1.collect()
