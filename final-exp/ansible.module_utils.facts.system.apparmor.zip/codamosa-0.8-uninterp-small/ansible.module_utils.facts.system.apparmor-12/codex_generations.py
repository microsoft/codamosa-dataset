

# Generated at 2022-06-24 23:31:54.419919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:31:56.327277
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(None, None)


# Generated at 2022-06-24 23:32:05.359331
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts_dict_0 = apparmor_fact_collector_0.collect()
        apparmor_fact_status_0 = apparmor_facts_dict_0['apparmor']['status']
    else:
        apparmor_facts_dict_0 = apparmor_fact_collector_0.collect()
        apparmor_fact_status_0 = apparmor_facts_dict_0['apparmor']['status']


# Generated at 2022-06-24 23:32:15.719276
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # This module has a test case for each method of the ApparmorFactCollector
    # class. The section for a specific method has to be updated for any
    # update in that method.  The test cases share the global variable
    # ApparmorFactCollector for the main code and for each method a different
    # test case is created.
    # Since this module does not have any function or method, no need to include

    # global test case for class ApparmorFactCollector
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # test case for method get_fact_collection_filter of class ApparmorFactCollector
    test_get_fact_collection_filter_0 = apparmor_fact_collector_0.get_fact_collection_filter()
    # test case for method get_fact_ids of class ApparmorFactCollector


# Generated at 2022-06-24 23:32:17.647085
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:18.583267
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:19.660352
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:32:22.371267
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:32:26.978468
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Check if status is enabled
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

    # Check if status is disabled
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._exists = lambda x: False
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:32:29.441495
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    test_case_0()
    test_case_3()


# Generated at 2022-06-24 23:32:34.343594
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for the ApparmorFactCollector.collect() method"""
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert type(var_0) is dict


# Generated at 2022-06-24 23:32:36.598234
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

    return var_1


# Generated at 2022-06-24 23:32:38.490724
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:42.563695
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Assigning test values to variables
t_0 = os.path.exists('/sys/kernel/security/apparmor')


# Generated at 2022-06-24 23:32:44.147632
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:47.749464
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print('Testing method test_unit.ApparmorFactCollector.collect')
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    print('unit test done for method test_unit.ApparmorFactCollector.collect')


if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:51.768023
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res = apparmor_fact_collector_0.collect()
    assert res is not None

# Generated at 2022-06-24 23:32:57.277216
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Logic for when the status for kernel is not enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector_1 = ApparmorFactCollector()
        var_0 = apparmor_fact_collector_1.collect()
        assert isinstance(var_0, dict)
    else:
        apparmor_fact_collector_1 = ApparmorFactCollector()
        var_0 = apparmor_fact_collector_1.collect()
        assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:33:01.795463
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    result = apparmor_fact_collector.collect(collected_facts=collected_facts)
    assert result == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:33:05.895087
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print('\n**********************\nStarting test of ApparmorFactCollector.\
         collect().\n**********************\n')
    test_cases = [test_case_0, ]
    for test_case in test_cases:
        test_case()

test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:09.426856
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:33:15.133160
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:33:16.809374
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:20.972290
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert (ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}})


# Test if module is being run directly
if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:23.343197
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_1 = set()
    apparmor_fact_collector_1 = ApparmorFactCollector(var_1)
    var_2 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:25.761212
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:32.341883
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    if var_0 != dict():
        print('Failed: ApparmorFactCollector.collect did not return dict()')
        return False
    return True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:33:33.122721
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Run test case 0
    test_case_0()

# Generated at 2022-06-24 23:33:33.859107
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True


# Generated at 2022-06-24 23:33:35.645208
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:44.833554
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Method execution with valid argument
    assert apparmor_fact_collector_0.collect()
    # Method execution with invalid argument
    # TypeError exception expected
    with pytest.raises(TypeError) as exp:
        apparmor_fact_collector_0.collect(1)

# Generated at 2022-06-24 23:33:47.367856
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:56.924615
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    args = []
    is_exc, exc_info, trace_back_info, result = ApparmorFactCollector()._run_module(function_name='collect',function_args=args)
    assert is_exc == False
    assert exc_info == None
    assert trace_back_info == None
    assert isinstance(result,dict)
    assert result['ansible_facts']['apparmor']['status'] == 'disabled'

testcases = [test_case_0]

subdirs = set()
subdirs.add(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
for subdir in subdirs:
    print('subdir {0}'.format(subdir))
    for case in testcases:
        case_path = os.path.join

# Generated at 2022-06-24 23:33:59.998888
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert callable(ApparmorFactCollector.collect)


# Generated at 2022-06-24 23:34:03.350305
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.name
    var_1 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:13.367259
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mocking the '__init__' method of the class
    ApparmorFactCollector_obj = ApparmorFactCollector()
    ApparmorFactCollector_obj.__init__ = MagicMock()
    # Calling the method
    return_value = ApparmorFactCollector_obj.collect()
    # Asserting the return value
    assert return_value
    # Calling the method with required arguments
    return_value = ApparmorFactCollector_obj.collect(module=None, collected_facts=None)
    # Asserting the return value
    assert return_value


# Generated at 2022-06-24 23:34:16.593547
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    expected_0 = {'apparmor': {'status': 'enabled'}}
    assert var_0 == expected_0

# Generated at 2022-06-24 23:34:18.167296
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert not apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:21.097195
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor':{'status':'disabled'}}

# Generated at 2022-06-24 23:34:23.364211
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    expected_result_1 = {'apparmor': {'status': 'enabled'}}
    assert (expected_result_1 == apparmor_fact_collector_1.collect())



# Generated at 2022-06-24 23:34:35.756916
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:40.094900
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with a module object
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:44.407812
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    assert os.path.exists('/sys/kernel/security/apparmor') == False
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:49.228834
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:52.110331
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is not None
    assert 'apparmor' in var_0

# Generated at 2022-06-24 23:34:53.787078
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:58.321673
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    if not var_0:
        raise Exception("Failed")

# Generated at 2022-06-24 23:35:01.278332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:35:08.016332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert isinstance(var_1,dict)
    assert var_1 == {'apparmor': {'status': 'disabled'}}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 23:35:12.446395
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'apparmor' in var_0
    assert isinstance(var_0['apparmor'], dict)
    assert 'status' in var_0['apparmor']
    assert isinstance(var_0['apparmor']['status'], str)
    assert var_0['apparmor']['status'] in ('enabled', 'disabled')


# Generated at 2022-06-24 23:35:40.944710
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert {'apparmor': {'status': 'disabled'}} == var_1

# Generated at 2022-06-24 23:35:44.997688
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}, "apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}, ({} != {})".format(var_0, {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-24 23:35:48.908002
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:51.824629
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in var_1
    var_2 = var_1['apparmor']
    assert 'status' in var_2

# Generated at 2022-06-24 23:35:58.721142
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._fact_ids = set()
    apparmor_fact_collector_0._fact_ids.add('apparmor')
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:36:02.508397
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with default arguments
    var_1 = ApparmorFactCollector()
    var_2 = var_1.collect()
    assert var_2 == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-24 23:36:04.700132
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:36:08.141259
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert (not result is None)


# Generated at 2022-06-24 23:36:09.863993
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:15.002150
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:11.084922
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  apparmor_fact_collector_0 = ApparmorFactCollector()
  assert apparmor_fact_collector_0.collect() == {'apparmor' : {'status' : 'enabled'}}

# Generated at 2022-06-24 23:37:17.134802
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:37:19.932753
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:26.174341
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == dict(apparmor={'status': 'disabled'})


# Generated at 2022-06-24 23:37:29.567750
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:37:32.040273
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector_0 = ApparmorFactCollector()
    var_1 = fact_collector_0.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:37:33.981611
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in var_1

# Generated at 2022-06-24 23:37:35.489820
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:38.598919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}, "var_0 (got) == {'apparmor': {'status': 'disabled'}} (expected)"

# Generated at 2022-06-24 23:37:43.479245
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # apparmor_fact_collector = ApparmorFactCollector()
    # var = apparmor_fact_collector.collect()
    # assert var == 'foo'
    assert True



# Generated at 2022-06-24 23:39:52.136399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {
        'apparmor': {
            'status': 'disabled'
        }
    }


# Generated at 2022-06-24 23:39:57.536313
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:02.827794
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_instance = ApparmorFactCollector()
    assert isinstance(isinstance(ApparmorFactCollector()
    .collect(), dict), True)


# Generated at 2022-06-24 23:40:06.382621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1.keys() == {'apparmor'}
    assert var_1['apparmor'].keys() == {'status'}
    assert var_1['apparmor']['status'] in {'disabled', 'enabled'}


# Generated at 2022-06-24 23:40:13.988627
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.name = 'apparmor'
    apparmor_fact_collector_0.collect()
    #Unit test for method name var = self.name of class ApparmorFactCollector
    assert apparmor_fact_collector_0.name == 'apparmor'
    assert apparmor_fact_collector_0.name != 'apparmor'


# Generated at 2022-06-24 23:40:15.938226
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:40:25.642539
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_0 == apparmor_fact_collector_1, 'Instance not equivalent'
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_2._fact_ids.add('a')
    apparmor_fact_collector_3 = ApparmorFactCollector()
    apparmor_fact_collector_3._fact_ids.add('a')
    apparmor_fact_collector_3._fact_ids.add('a')
    assert apparmor_fact_collector_1 != apparmor_fact_collector_2, 'Instance not equivalent'
    assert apparmor_fact_collector_2

# Generated at 2022-06-24 23:40:30.421619
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

    var_1['apparmor']['status'] = 'enabled'


# Generated at 2022-06-24 23:40:31.526446
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:37.991981
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert(var_1['apparmor']['status'] == 'disabled')