

# Generated at 2022-06-24 23:31:49.392069
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    print(result)

# Generated at 2022-06-24 23:31:54.772092
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    fact_dict = apparmor_fact_collector_0.collect()
    assert fact_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:31:56.557656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    rc = apparmor_fact_collector_1.collect()
    assert rc != None


# Generated at 2022-06-24 23:32:02.639150
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    facts_dict_0 = apparmor_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert facts_dict_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:32:08.549024
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor'] == {'status': 'disabled'}


# Generated at 2022-06-24 23:32:15.160455
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    os.path.exists = MagicMock(name='exists', return_value=True)
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    os.path.exists = MagicMock(name='exists', return_value=False)
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:18.811523
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts_1 = apparmor_fact_collector_1.collect()
    assert collected_facts_1 is not None
    collected_facts_keys_1 = collected_facts_1.keys()
    assert 'apparmor' in collected_facts_keys_1
    apparmor_keys_1 = collected_facts_1['apparmor'].keys()
    assert 'status' in apparmor_keys_1
# Unit test end
test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:22.525984
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_dict = apparmor_fact_collector_0.collect()
    assert apparmor_fact_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:32:23.018490
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:32:25.517667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:29.399695
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:34.210302
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()

    assert var == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:32:37.345914
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector_0.collect()
    else:
        apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:39.450586
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:32:41.649653
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:43.316117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert 1 == 1

# Generated at 2022-06-24 23:32:44.578247
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:46.067902
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:48.252543
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:52.424705
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

    assert var_1 != None and isinstance(var_1, dict)

# Generated at 2022-06-24 23:33:00.802770
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:04.762363
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0, ApparmorFactCollector)
    apparmor_fact_collector_0._fact_ids.add('apparmor')
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:06.481019
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # TODO: Unit test using a mock object

# Generated at 2022-06-24 23:33:14.422274
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # Check if the collect method is callable.
    assert callable(apparmor_fact_collector.collect)

    # Check the 'apparmor' dictionary from the collect method.
    assert isinstance(apparmor_fact_collector.collect()['apparmor'], dict)

    # Check that the 'apparmor' dictionary has a non-empty 'status' key.
    assert bool(apparmor_fact_collector.collect()['apparmor']['status'])

    # Check that the 'apparmor' dictionary only contains the 'status' key.
    assert len(apparmor_fact_collector.collect()['apparmor'].keys()) == 1
    assert 'status' in apparmor_fact_collector.collect()['apparmor'].keys()

    # Check that the

# Generated at 2022-06-24 23:33:16.447291
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:20.426279
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:26.413407
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert type(var_1) == dict
    module_0 = var_1['apparmor']
    assert type(module_0) == dict
    assert module_0['status'] == 'enabled'
    apparmor_fact_collector_0._fact_ids = set()
    apparmor_fact_collector_0._fact_ids.add('apparmor')

# Generated at 2022-06-24 23:33:31.108362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:33:33.196685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:33:35.320719
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:33:42.828615
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:46.419345
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    if var_1:
        assert var_1
        assert isinstance(var_1, dict)
        assert len(var_1) > 0
    else:
        assert not var_1

# Generated at 2022-06-24 23:33:50.718349
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    temp_ApparmorFactCollector = ApparmorFactCollector()

    temp_ApparmorFactCollector.collect()


# Generated at 2022-06-24 23:33:53.598341
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    label = 'test_0'
    var_0 = ApparmorFactCollector()
    var_1 = var_0.collect()

test_case_0()

# Generated at 2022-06-24 23:33:55.853707
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:58.607621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

test_case_0()

# Generated at 2022-06-24 23:33:59.745651
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:34:01.817364
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:04.207831
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:10.615633
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._fact_ids = {'apparmor', }    
    var_0 = apparmor_fact_collector_0.collect()
    expected_0 = {'apparmor': {'status': 'disabled', }, }
    if True:
        assert expected_0 == var_0


# Generated at 2022-06-24 23:34:26.212698
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_1.collect(module=None, collected_facts=None)
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:34:32.744217
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    # AssertionError: {'apparmor': {'status': 'disabled'}} != {'apparmor': {'status': 'enabled'}}
    # at 0x7F3F9C2A3C10>



# Generated at 2022-06-24 23:34:34.484598
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:39.439630
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:41.784511
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:44.802460
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # testing if the method returns a dictionary
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:34:50.316722
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.fact_id == 'apparmor'
    assert apparmor_fact_collector.collect()
    assert apparmor_fact_collector.fact_id == 'apparmor'

# Generated at 2022-06-24 23:34:52.971000
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] in ('disabled', 'enabled')



# Generated at 2022-06-24 23:34:57.999568
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert 'apparmor' in var_1

# Generated at 2022-06-24 23:35:03.351486
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    # Test 1
    var_1 = apparmor_fact_collector_0.name
    assert var_1 == 'apparmor'
    # Test 2
    var_2 = apparmor_fact_collector_0._fact_ids
    assert var_2 == set()
    # Test 3
    var_3 = apparmor_fact_collector_0.collect()
    assert var_3 == {}


# Generated at 2022-06-24 23:35:32.755778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:35:33.946687
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:36.542556
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print('Testing method: collect of class: ApparmorFactCollector')
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:40.719837
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-24 23:35:43.508524
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == dict(apparmor=dict(status='disabled')), "Method collect of class ApparmorFactCollector failed."

# Generated at 2022-06-24 23:35:48.863460
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:51.464566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:35:53.235970
# Unit test for method collect of class ApparmorFactCollector

# Generated at 2022-06-24 23:35:55.442248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:58.856501
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initialize test values

    # Call method
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:57.404780
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:02.772687
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor'] == {'status': 'disabled'}
    os.mkdir('/sys/kernel/security/apparmor')
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-24 23:37:07.626253
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    # Verify whether the result equals expected
    assert var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:37:11.903201
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_ = ApparmorFactCollector()
    var = apparmor_fact_collector_.collect()
    assert var == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:37:16.841582
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:22.466558
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Testing if the type of collect method's returned value is dict
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:37:25.701544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is not None
    assert var_0.keys() == ['apparmor']
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:37:27.532969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:37:30.378455
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:31.786268
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:39:42.228151
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:43.296722
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:45.170153
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:47.988101
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Define the arguments to be passed to the test method
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Get the method under test
    method = getattr(apparmor_fact_collector_1, 'collect')
    # Invoke the method under test
    assert 'apparmor' in method()
    assert 'status' in method()['apparmor']

# Generated at 2022-06-24 23:39:50.753702
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    x = apparmor_fact_collector_1.collect()
    assert len(x) > 0


# Generated at 2022-06-24 23:39:53.080556
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == dict(apparmor=dict(status='enabled'))

# Generated at 2022-06-24 23:39:57.780954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    assert len(apparmor_fact_collector._fact_ids) == 0


# Generated at 2022-06-24 23:40:03.184672
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:40:08.044269
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:12.525957
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
