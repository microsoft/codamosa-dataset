

# Generated at 2022-06-24 23:32:00.146200
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_2 = ApparmorFactCollector()

    # Test with Apparmor disabled
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0._fact_ids == set(['apparmor'])

    # Test with Apparmor enabled
    apparmor_fact_collector_1.collect()
    assert apparmor_fact_collector_1._fact_ids == set(['apparmor'])

    # Test without any arguments
    apparmor_fact_collector_2.collect()
    assert apparmor_fact_collector_2._fact_ids == set(['apparmor'])



# Generated at 2022-06-24 23:32:06.104947
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dic = apparmor_fact_collector.collect()
    assert isinstance(apparmor_facts_dic, dict)
    assert 'apparmor' in apparmor_facts_dic
    apparmor_fact_status = apparmor_facts_dic['apparmor']['status']
    assert apparmor_fact_status == 'disabled' or apparmor_fact_status == 'enabled'

# Generated at 2022-06-24 23:32:08.147511
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector.collect()
    assert apparmor_facts_dict['apparmor']
    assert isinstance(apparmor_facts_dict['apparmor'], dict)

# Generated at 2022-06-24 23:32:11.879059
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    dict_1 = apparmor_fact_collector_1.collect()
    print(dict_1)


# Generated at 2022-06-24 23:32:14.712878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Logic to test collect method of ApparmorFactCollector
    # Test case 0
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Test case 1
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:32:17.060823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:32:20.139176
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    output = apparmor_fact_collector_collect.collect()
    assert output


# Generated at 2022-06-24 23:32:23.673670
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:25.229025
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:28.663197
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:34.687570
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert isinstance( apparmor_fact_collector_1.collect() , dict)

# Generated at 2022-06-24 23:32:38.147510
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    setattr(apparmor_fact_collector_0, '_module', None)
    setattr(apparmor_fact_collector_0, '_collected_facts', None)
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:42.420848
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ansible_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(module=test_ansible_module)


# Generated at 2022-06-24 23:32:44.117264
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:32:45.857092
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:32:55.804590
# Unit test for method collect of class ApparmorFactCollector

# Generated at 2022-06-24 23:33:01.877739
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect_0 = ApparmorFactCollector()
    collected_facts_0 = []
    apparmor_fact_collector_collect_results = apparmor_fact_collector_collect_0.collect(module=None, collected_facts=collected_facts_0)
    assert apparmor_fact_collector_collect_results == {}



# Generated at 2022-06-24 23:33:06.389225
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # FIXME (whitelister): Due to ansible/ansible#52551, this test doesn't
    # actually test anything.
    apparmor_fact_collector.collect()



# Generated at 2022-06-24 23:33:08.459617
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:33:10.307187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect(collected_facts = None)


# Generated at 2022-06-24 23:33:13.697047
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:33:19.545905
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_path = (os.path.dirname(os.path.realpath(__file__)) +
                 "/test_data/apparmor_file")
    if os.path.exists(file_path):
        os.remove(file_path)

    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {'apparmor': {}}
    apparmor_fact_collector_0.collect(collected_facts)
    expected_facts = {'apparmor': {'status': 'disabled'}}
    assert collected_facts == expected_facts

    # Create a file to fake that apparmor is present
    os.mknod(file_path)
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {'apparmor': {}}
    app

# Generated at 2022-06-24 23:33:22.197466
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_1, ApparmorFactCollector)
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:24.785315
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:33:30.878048
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    apparmor_fact_collector_collect.add_sections_if_needed(apparmor_fact_collector_collect)
    assert apparmor_fact_collector_collect.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:33:33.096615
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()

    assert result is not None

# Generated at 2022-06-24 23:33:34.712546
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:41.716604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result is not None
    expected_fields = ['apparmor']
    result_fields = result.keys()
    for field in expected_fields:
        assert field in result_fields


# Generated at 2022-06-24 23:33:44.212114
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts_1 = apparmor_fact_collector_1.collect(None, None)
    assert 'apparmor' in collected_facts_1

# Generated at 2022-06-24 23:33:50.497768
# Unit test for method collect of class ApparmorFactCollector

# Generated at 2022-06-24 23:33:55.210344
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert type(var_1) is dict


# Generated at 2022-06-24 23:33:56.334566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {"apparmor": {"status": "enabled"}}

# Generated at 2022-06-24 23:33:59.016462
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    var_1 = apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert var_1 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:34:02.181733
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:05.928253
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0_collect_res = apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0_collect_res == { 'apparmor' : { 'status' : 'enabled' } }

# Generated at 2022-06-24 23:34:16.138852
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Assert sys.path[0] is not empty
    assert sys.path[0]
    # Assert os.path.join(sys.path[0], 'ansible_collections/ansible/community/plugins/facts/apparmor') is not empty
    assert os.path.join(sys.path[0], 'ansible_collections/ansible/community/plugins/facts/apparmor')
    # Assert os.path.join(sys.path[0], 'ansible_collections/ansible/community/plugins/facts/apparmor') exists
    assert os.path.exists(os.path.join(sys.path[0], 'ansible_collections/ansible/community/plugins/facts/apparmor'))
    # Assert os.path.join(sys.path[0], 'ansible_collections/ans

# Generated at 2022-06-24 23:34:17.970844
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()



# Generated at 2022-06-24 23:34:24.348389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.name
    apparmor_fact_collector_0.name = 'ApparmorFactCollector'
    var_2 = apparmor_fact_collector_0.name
    apparmor_fact_collector_0.name = var_1
    var_3 = apparmor_fact_collector_0.name
    var_4 = apparmor_fact_collector_0.collect()

    assert var_0 == var_4
    assert var_1 == 'apparmor'
    assert var_2 == 'ApparmorFactCollector'
    assert var_3 == 'apparmor'
    assert var_4 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:29.595602
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    func_1 = fc.collect()
# patch for test method collect of class ApparmorFactCollector

# Generated at 2022-06-24 23:34:34.188270
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Test with
    # apparmor_fact_collector_1.collect(module=None, collected_facts=None)
    pass

# Generated at 2022-06-24 23:34:42.704957
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:45.272532
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in var_0


# Generated at 2022-06-24 23:34:51.313548
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if not os.path.exists('/sys/kernel/security/apparmor'):
        # Skip if apparmor is not enabled
        return
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:34:53.006849
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Case 0
    try:
        test_case_0()
    except Exception as exc:
        assert False, str(exc)

# Generated at 2022-06-24 23:34:58.503825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:00.069066
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:03.000885
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    if var_0['apparmor']['status'] == 'enabled':
        var_1 = True
        assert var_1 == True
    else:
        var_1 = True
        assert var_1 == True

# Generated at 2022-06-24 23:35:08.010409
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == dict(apparmor=dict(status='enabled')), 'Unexpected value'

# Generated at 2022-06-24 23:35:10.116785
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:17.382904
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    # Test for condition 'not os.path.exists('/sys/kernel/security/apparmor')'
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:32.210990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()


# Generated at 2022-06-24 23:35:33.830944
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:37.344372
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert isinstance(var_1, dict) == True
    assert 'apparmor' in var_1
    assert isinstance(var_1['apparmor'], dict) == True
    assert 'status' in var_1['apparmor']
    assert isinstance(var_1['apparmor']['status'], str) == True


# Generated at 2022-06-24 23:35:39.894621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:42.512318
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:47.207186
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var is None


# Generated at 2022-06-24 23:35:48.932972
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:50.125112
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:53.103608
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:35:55.602853
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status']

# Generated at 2022-06-24 23:36:26.806008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    if ApparmorFactCollector is None:
        pass

    if __name__ == '__main__':
        import __main__
        print("__main__.__file__: " + __main__.__file__)
        print("__main__.__package__: " + str(__main__.__package__))
        print("os.path.basename(__main__.__file__): " + os.path.basename(__main__.__file__))

        print("os.path.realpath(__main__.__file__): " + os.path.realpath(__main__.__file__))

# Generated at 2022-06-24 23:36:31.504876
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    var_1 = {'apparmor': {'status': 'enabled'}}
    assert var_0 == var_1

# Generated at 2022-06-24 23:36:33.278446
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:35.156536
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var == {}

# Generated at 2022-06-24 23:36:38.424779
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

if __name__ == '__main__':
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:36:40.398149
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    apparmor_fact_collector_0.collect(collected_facts=collected_facts_0)

# Generated at 2022-06-24 23:36:41.890559
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:44.194756
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-24 23:36:48.863839
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None

# Generated at 2022-06-24 23:36:54.356172
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var = ApparmorFactCollector()
    var_id = 1
    var_value = 2
    if '_fact_ids' in dir(var):
        var._fact_ids = set()

    var.collect()

    ApparmorFactCollector_instances = {}
    ApparmorFactCollector_instances[1] = {}
    if '_fact_ids' in dir(ApparmorFactCollector_instances[1]):
        ApparmorFactCollector_instances[1]._fact_ids = set()

    ApparmorFactCollector_instances[1].collect()
    assert var_id == 1, 'Failed assertion: ' + str(var_id)+' == 1'
    assert var_value == 2, 'Failed assertion: ' + str(var_value)+' == 2'


# Generated at 2022-06-24 23:37:47.937747
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    obj = ApparmorFactCollector()
    assert(obj.collect())


# Generated at 2022-06-24 23:37:52.573465
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Arrange
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Act
    var_0 = apparmor_fact_collector_0.collect()

    # Assert
    assert isinstance(var_0, dict)
    assert 'apparmor' in var_0.keys()
    assert isinstance(var_0['apparmor'], dict)
    assert 'status' in var_0['apparmor'].keys()



# Generated at 2022-06-24 23:37:53.610106
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:37:57.520799
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    keys_0 = var_0.keys()
    assert {'apparmor'} == keys_0

# Generated at 2022-06-24 23:37:59.790494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:02.044644
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:38:05.781780
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:38:07.532430
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:38:10.910298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts
    assert facts['apparmor'] is not None
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] != ''



# Generated at 2022-06-24 23:38:16.251620
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect(module=None, collected_facts=None)
    assert var_0 == {u'apparmor': {u'status': u'enabled'}}

# Generated at 2022-06-24 23:40:27.457128
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass
# << VARIANT


# Generated at 2022-06-24 23:40:29.441698
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:40:30.250922
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:40:31.863308
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {"apparmor": {"status": "enabled" }}

# Generated at 2022-06-24 23:40:37.412258
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:42.223423
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert('apparmor' in var_1)
    assert('status' in var_1['apparmor'])
    assert(var_1['apparmor']['status'] in ['disabled', 'enabled'])


# Generated at 2022-06-24 23:40:43.355503
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:44.848138
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    testing_collect = ApparmorFactCollector()

    assert testing_collect.collect is not None

# Generated at 2022-06-24 23:40:47.804192
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    try:
        apparmor_fact_collector_1.collect()
    except Exception:
        pass

# Generated at 2022-06-24 23:40:48.739100
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_0 = ApparmorFactCollector()
    var_1 = var_0.collect()