

# Generated at 2022-06-24 23:31:54.130797
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:31:56.802902
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_0.collect()
    if 'apparmor' in apparmor_facts.keys():
        assert 'status' in apparmor_facts['apparmor'].keys()

# Generated at 2022-06-24 23:31:59.061043
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:32:01.552865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:32:04.705648
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Input parameters:
    module = None
    collected_facts = None
    # Output: facts_dict
    facts_dict = apparmor_fact_collector_1.collect(module, collected_facts)
    assert facts_dict == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:32:06.667410
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:11.032060
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_0 = ApparmorFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec = dict())

    apparmor_fact_collector_0.collect(ansible_module_0)


# Generated at 2022-06-24 23:32:17.929585
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    module_1 = None
    collected_facts_1 = None
    apparmor_fact_collector_1.collect(module=module_1, collected_facts=collected_facts_1)

if __name__ == '__main__':
    test_case_0()
    # test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:24.459800
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_path = '/sys/kernel/security/apparmor'
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    expected_apparmor_dict = {}
    if os.path.exists(apparmor_path):
        expected_apparmor_dict['status'] = 'enabled'
    else:
        expected_apparmor_dict['status'] = 'disabled'
    assert apparmor_fact_collector_0.collect()['apparmor'] == expected_apparmor_dict

# Generated at 2022-06-24 23:32:26.628703
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = dict()


# Generated at 2022-06-24 23:32:34.528295
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_result_0 = apparmor_fact_collector_0.collect()
    # assert that the result does not contain any value for key "apparmor"
    assert 'apparmor' not in apparmor_fact_collector_result_0

# Generated at 2022-06-24 23:32:38.558897
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = "ansible_module_mock"
    apparmor_fact_collector._module.exit_json = "exit_json_mock"
    apparmor_fact_collector._module.fail_json = "fail_json_mock"
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:42.143250
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:43.653741
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert(apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}})

# Generated at 2022-06-24 23:32:44.948894
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result == {}

# Generated at 2022-06-24 23:32:46.846332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:47.589272
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()


# Generated at 2022-06-24 23:32:49.722469
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:32:55.584028
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:32:59.665968
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Testing the value of facts['apparmor']['status'].
    # assert apparmor_fact_collector_1.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:33:09.007723
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Apparmor fact collection test cases"""

    apparmor_fact_collector = ApparmorFactCollector()

    apparmor_facts_test_1 = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector.collect() == apparmor_facts_test_1

# Generated at 2022-06-24 23:33:11.655348
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # Testing apparmor facts
    responses = apparmor_fact_collector_1.collect()
    assert isinstance(responses, dict)



# Generated at 2022-06-24 23:33:13.772759
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts_1 = {"apparmor": {"status": "enabled"}}
    assert(apparmor_fact_collector_1.collect() == collected_facts_1)

# Generated at 2022-06-24 23:33:18.735543
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fixture = {
        'apparmor': {
            'status': 'enabled'
        }
    }

    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in collected_facts
    assert collected_facts['apparmor'] == fixture['apparmor']

# Generated at 2022-06-24 23:33:23.625509
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-24 23:33:30.371062
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    ansible_facts_0 = apparmor_fact_collector.collect()
    keys_0 = ansible_facts_0.keys()
    keys_set_0 = set(keys_0)
    assert keys_set_0 == set(['apparmor'])


# Generated at 2022-06-24 23:33:33.160489
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_0 = {}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': apparmor_facts_0}


# Generated at 2022-06-24 23:33:35.977442
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_facts_dict_0 = { '/sys/kernel/security/apparmor': 'enabled'}
    apparmor_fact_collector_0.collect(collected_facts=apparmor_facts_dict_0)


# Generated at 2022-06-24 23:33:41.400111
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}, \
        'Test for method collect of class ApparmorFactCollector failed'


# Generated at 2022-06-24 23:33:43.226821
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:56.667015
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    assert apparmor_fact_collector_1.name == 'apparmor'

# Generated at 2022-06-24 23:33:59.222948
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    apparmor_fact_collector.collect(collected_facts)
    if not (collected_facts['ansible_facts']['apparmor']):
        raise AssertionError("ansible_facts['apparmor'] does not exist")

# Generated at 2022-06-24 23:33:59.799247
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-24 23:34:01.858359
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None

# Generated at 2022-06-24 23:34:07.066737
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert isinstance(result, dict) is True
    assert len(result) == 1
    assert 'apparmor' in result
    assert isinstance(result['apparmor'], dict) is True
    assert len(result['apparmor']) == 1
    assert 'status' in result['apparmor']
    assert isinstance(result['apparmor']['status'], str) is True

# Generated at 2022-06-24 23:34:08.003311
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:34:10.024153
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:34:13.264343
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    command = 'uname -s'
    status = True
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:15.548174
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:19.006449
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_1.collect()
    assert type(apparmor_facts) == dict
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:34:33.960370
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:36.322954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Input parameters to the method
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Invoke the method
    method_response = apparmor_fact_collector_0.collect()
    print(method_response)

# Generated at 2022-06-24 23:34:40.414221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector_0 = ApparmorFactCollector()
        apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:43.825112
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:50.224036
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect(collected_facts=test_case_0())
    assert var_0 == {'apparmor': {'status': 'disabled'}} or var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:34:51.994260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:56.928979
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector_0 = ApparmorFactCollector()
    result_0 = fact_collector_0.collect()
    #assert result_0 == {}

# Generated at 2022-06-24 23:34:58.539531
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:00.733430
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:02.629687
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:35:28.702084
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:33.495461
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

if __name__ == '__main__':
    import os
    import sys
    sys.path.append(os.getcwd())
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:35:41.151542
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    var_0 = apparmor_fact_collector_0.collect()
    var_1 = apparmor_fact_collector_0.collect({'path': 'test/ansible', 'foo': 'bar'})
    var_1 = apparmor_fact_collector_0.collect(collected_facts={'path': 'test/ansible', 'foo': 'bar'})


# Generated at 2022-06-24 23:35:42.402237
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:50.273772
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        var_1 = 'enabled'
    else:
        var_1 = 'disabled'
    var_2 = apparmor_fact_collector_1.collect()
    assert var_2['apparmor']['status'] == var_1
    apparmor_fact_collector_3 = ApparmorFactCollector()
    var_3 = apparmor_fact_collector_3.collect()
    assert not var_3['apparmor'].get('status')

# Generated at 2022-06-24 23:35:53.724728
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    _ansible_module_0 = _FakeAnsibleModuleForApparmorFactCollectorCollect()
    _ansible_module_0.apparmor_fact_collector = ApparmorFactCollector()
    var_0 = _ansible_module_0.apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:35:56.032142
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 23:35:58.990986
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = test_case_0()
    assert var_0['apparmor']['status'] in [u'enabled', u'disabled']

# Generated at 2022-06-24 23:36:02.050670
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:11.203941
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create a test ApparmorFactCollector
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Invoke method collect
    var_0 = apparmor_fact_collector_0.collect()
    
    # Assert the return value of method collect is None

    # Invoke method collect
    var_1 = apparmor_fact_collector_0.collect()
    
    # Assert the return value of method collect is None

    # Invoke method collect
    var_2 = apparmor_fact_collector_0.collect()
    
    # Assert the return value of method collect is None

    # Invoke method collect
    var_3 = apparmor_fact_collector_0.collect()
    
    # Assert the return value of method collect is None

    # Invoke method collect
    var_

# Generated at 2022-06-24 23:37:12.632296
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup
    apparmor_fact_collector = ApparmorFactCollector()
    # Assertion
    apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:37:15.515059
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:17.230919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:37:24.108423
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # "/home/server2/devel/ansible-workspace/ansible/playbooks/tests/integration/targets/module_utils/facts/collectors/apparmor.py"
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:25.755731
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:27.144524
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:29.766995
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # apparmor_fact_collector_0 = ApparmorFactCollector()
    test_case_0()


# Generated at 2022-06-24 23:37:33.541635
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert 1 == 1


# Generated at 2022-06-24 23:37:35.936904
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {u'apparmor': {u'status': u'disabled'}}



# Generated at 2022-06-24 23:37:36.570437
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:39:47.143021
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:39:49.460866
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup test environment
    apparmor_fact_collector_obj = ApparmorFactCollector()

    # Execute method collect
    collect_obj = apparmor_fact_collector_obj.collect()

    # Check test results
    assert isinstance(collect_obj, dict)


# Generated at 2022-06-24 23:39:51.830164
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Unit test for method collect of class ApparmorFactCollector
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:39:53.689911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:39:58.571254
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_1.collect()
    apparmor_fact_collector_2 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_2.collect()
    assert var_0 == var_1


# Generated at 2022-06-24 23:40:03.394969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:09.145814
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert len(var_0) == 1
    assert var_0['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:40:14.128130
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:40:17.321121
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    var_1 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:20.966547
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()