

# Generated at 2022-06-24 23:31:57.737356
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {}, "apparmor collect failure"



# Generated at 2022-06-24 23:31:59.734447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert result is not None


# Generated at 2022-06-24 23:32:04.713748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert 'apparmor' in facts_dict
    assert 'status' in facts_dict['apparmor']
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:32:06.978313
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    assert apparmor_fact_collector_1.collect() is not None


# Generated at 2022-06-24 23:32:16.564610
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.find_file = lambda path: '/sys/kernel/security/apparmor'
    apparmor_fact_collector.file_exists = lambda path: True
    data = apparmor_fact_collector.collect()
    assert data['apparmor']['status'] == 'enabled'

apparmor_fact_collector = ApparmorFactCollector()
apparmor_fact_collector.find_file = lambda path: '/sys/kernel/security/apparmor'
apparmor_fact_collector.file_exists = lambda path: False
data = apparmor_fact_collector.collect()
assert data['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:32:20.318024
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    mock_collected_facts_1 = []
    apparmor_fact_collector_1.collect(collected_facts=mock_collected_facts_1)

# Generated at 2022-06-24 23:32:23.374467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_collect = apparmor_fact_collector.collect()
    assert type(apparmor_fact_collector_collect) is dict
    assert 'apparmor' in apparmor_fact_collector_collect

# Generated at 2022-06-24 23:32:24.698293
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:28.288640
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:32:32.055112
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # default param test
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()
    assert facts_dict_0['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:32:42.321595
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect(collected_facts="test_string_1")

    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_2.collect(module="test_string_2")

    apparmor_fact_collector_3 = ApparmorFactCollector()
    apparmor_fact_collector_3.collect(collected_facts="test_string_3", module="test_string_3")

# Generated at 2022-06-24 23:32:44.557391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    ret = apparmor_fact_collector_0.collect()
    assert ret['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:32:50.543583
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_cases = [
        {
            'test_case_0': {
                'test_file': 'test_file_0',
                'test_dir': 'test_dir_0',
                'test_path': 'test_path_0',
                'facts_dict': 'facts_dict_0',
                'apparmor_facts': 'apparmor_facts_0',
                'apparmor_fact_collector_0': {
                    'name': 'name_0',
                    '_fact_ids': '_fact_ids_0'
                },
                '_fact_ids': '_fact_ids_1'
            }
        }
    ]
    for test_case in test_cases:
        apparmor_fact_collector_0 = ApparmorFactCollector()

# Generated at 2022-06-24 23:32:56.531287
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    module = [os.path.abspath(os.path.join(os.getcwd(), './test/unit/library/apparmor_facts/apparmor_fact_collector.py'))]
    apparmor_fact_collector.collect(module=module)


# Generated at 2022-06-24 23:32:58.865866
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:02.047868
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:33:06.396655
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    # Assert that result did not return an empty value
    assert result


test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:08.498760
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:09.842018
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:16.337218
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_dict = {
        'apparmor': {'status': 'enabled'}
    }
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    assert apparmor_facts_dict == apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:20.507187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:21.871076
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:24.767452
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert result['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:33:30.153683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:33:34.368216
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect(module=None, collected_facts=None)

    assert facts is not None

# Generated at 2022-06-24 23:33:38.064954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:43.222744
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result_0 = apparmor_fact_collector_1.collect()
    assert 'apparmor' in result_0
    assert 'status' in result_0['apparmor']

# Generated at 2022-06-24 23:33:46.475730
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    my_test_dict = apparmor_fact_collector_0.collect()
    assert my_test_dict['apparmor']['status'] == 'enabled' or my_test_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:33:53.516031
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    ansible_module_1 = AnsibleModule(
        argument_spec = dict()
    )

    collected_facts_1 = dict()

    apparmor_fact_collector_1.collect(
        module=ansible_module_1,
        collected_facts=collected_facts_1
    )

    assert collected_facts_1['apparmor'] == dict(
        status = "enabled"
    )

# Generated at 2022-06-24 23:33:56.567411
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Verify all the return values
    assert apparmor_fact_collector_0.name == 'apparmor'
    assert apparmor_fact_collector_0._fact_ids == set()

# Generated at 2022-06-24 23:34:04.847832
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:34:07.531763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:09.775720
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initialize the test case
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Call the method
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:13.770544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_fact_collector_0.collect(collected_facts = collected_facts)

# Generated at 2022-06-24 23:34:15.424703
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:17.980660
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    facts_dict = (apparmor_fact_collector_0.collect(collected_facts))
#   assert fact_dict == {}

# Generated at 2022-06-24 23:34:21.941823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = MockModule()
    expected_apparmor_fact = {'apparmor': {'status': 'enabled'}}
    actual_apparmor_fact = apparmor_fact_collector.collect()
    assert actual_apparmor_fact == expected_apparmor_fact



# Generated at 2022-06-24 23:34:23.783880
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:25.602758
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:29.985135
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:46.832601
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    print("Unit test for method collect of class ApparmorFactCollector")
    if os.path.exists('/sys/kernel/security/apparmor'):
        facts_dict = {'apparmor': {'status': 'enabled'}}
    else:
        facts_dict = {'apparmor': {'status': 'disabled'}}
    assert apparmor_fact_collector.collect() == facts_dict, "The unit test for method collect of class ApparmorFactCollector is failed"
    print('The unit test for method collect of class ApparmorFactCollector is passed')
    print('========================================================================================')

# Generated at 2022-06-24 23:34:49.088239
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:51.381583
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result_0 = apparmor_fact_collector_0.collect()
    assert result_0 is not None

# Generated at 2022-06-24 23:34:52.494238
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()



# Generated at 2022-06-24 23:34:57.692494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:59.962270
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:35:01.653435
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_colector_0_obj = ApparmorFactCollector()
    assert apparmor_fact_colector_0_obj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:35:06.969601
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    facts_dict = c.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:35:08.939561
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:11.003422
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:35:39.696880
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:43.168165
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    dict_0 = apparmor_fact_collector_1.collect()
    # print("apparmor_fact_collector_1: {}".format(apparmor_fact_collector_1))
    # print("dict_0: {}".format(dict_0))


# Generated at 2022-06-24 23:35:48.813808
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Pre-processing
    apparmor_fact_collector_0.collect()

    # Verification

# Generated at 2022-06-24 23:35:54.569747
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert set(apparmor_fact_collector_1.collect().keys()) == set(['apparmor'])
    assert not apparmor_fact_collector_1.collect()['apparmor'].keys() == set([])
    assert 'apparmor' in apparmor_fact_collector_1.collect().keys()
    assert apparmor_fact_collector_1.collect()['apparmor']['status'] in  set(['disabled', 'enabled'])


# Generated at 2022-06-24 23:35:58.601834
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    facts_dict['apparmor'] = apparmor_facts
    assert apparmor_fact_collector_0.collect() == facts_dict

# Generated at 2022-06-24 23:36:06.142956
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a mock instance
    apparmor_fact_collector = ApparmorFactCollector()

    # Test with two different values
    apparmor_fact_collector.os_path_exists = lambda x: True
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'enabled'

    apparmor_fact_collector.os_path_exists = lambda x: False
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:36:08.557707
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert (result == {}) or (result == {'apparmor': {'status': 'enabled'}}) or (result == {'apparmor': {'status': 'disabled'}})


# Generated at 2022-06-24 23:36:12.336634
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    mock_module_1 = None
    mock_collected_facts_1 = None
    expected_result = {
        'apparmor': {
            'status': 'disabled'
        }
    }

    actual_result = apparmor_fact_collector_1.collect(mock_module_1, mock_collected_facts_1)

    assert actual_result == expected_result

# Generated at 2022-06-24 23:36:16.239761
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect(module='VAR1',
                                               collected_facts=None)
    assert result == {}

# Generated at 2022-06-24 23:36:17.746218
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:15.549553
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {
        'apparmor': {'status': 'enabled'}
    }

# Generated at 2022-06-24 23:37:17.850604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor']['status'] == 'disabled' or result['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:37:22.682754
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict is not None

# Generated at 2022-06-24 23:37:26.838169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_ansible_1 = apparmor_fact_collector_1.collect()
    apparmor_fact_collector_1.collect(collected_facts=apparmor_fact_collector_ansible_1)


# Generated at 2022-06-24 23:37:29.517984
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if apparmor_fact_collector.collect():
        assert True


# Generated at 2022-06-24 23:37:37.889154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    apparmor_fact_collector_collect_expected_result = {'apparmor': {'status': 'enabled'}}

    apparmor_fact_collector_collect._module = None
    apparmor_fact_collector_collect_actual_result = apparmor_fact_collector_collect.collect()
    assert apparmor_fact_collector_collect_actual_result == apparmor_fact_collector_collect_expected_result

# Generated at 2022-06-24 23:37:42.145727
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:37:43.633201
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:37:46.009164
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:51.838478
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    test_module = None
    expected_result = dict(apparmor={'status': 'enabled'})
    apparmor_fact_collector_0.collect(test_module, collected_facts) == expected_result


# Generated at 2022-06-24 23:40:05.087182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.name == 'apparmor'
    assert apparmor_fact_collector_0._fact_ids == set()
    assert apparmor_fact_collector_0.collect()[0]['apparmor'][0]['status'] == ['enabled']

# Generated at 2022-06-24 23:40:08.120700
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if not apparmor_fact_collector_0.collect():
        fail()



# Generated at 2022-06-24 23:40:12.276057
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:40:19.318305
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case = 'test_ApparmorFactCollector_collect'

    # create an instance of the ApparmorFactCollector class
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # call method collect of the ApparmorFactCollector instance
    apparmor_fact_collector_0.collect()

    # check if the facts_dict of ApparmorFactCollector instance contains
    # the apparmor dictionary with correct values
    apparmor_fact = apparmor_fact_collector_0.get_facts()['apparmor']
    assert set(apparmor_fact.keys()) == {'status'}, \
           'apparmor facts %s is not %s' % (apparmor_fact, {'status': 'enabled|disabled'})
    value = apparmor_fact['status']

# Generated at 2022-06-24 23:40:21.576727
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    for k, v in result.items():
        print(k, ":", v)

# Generated at 2022-06-24 23:40:27.327977
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    ApparmorFactCollector class collect() method unit test stub
    """

    # Constructing mock objects
    collected_facts_mock_0 = {}
    module_mock_0 = {}

    # Invoking object
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Testing if os.path.exists('/sys/kernel/security/apparmor') evaluates to True
    collected_facts_mock_0 = {}
    module_mock_0 = {}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(module_mock_0, collected_facts_mock_0)

    # Testing if os.path.exists('/sys/kernel/security/apparmor') evaluates to False
    collected_facts_m

# Generated at 2022-06-24 23:40:30.453959
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test the empty dict is returned
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {}

    # Test the dict with facts is returned
    apparmor_fact_collector_2 = ApparmorFactCollector()
    os.path.exists = lambda value: True
    assert apparmor_fact_collector_2.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:40:36.953462
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    ansible_facts = {}
    ansible_facts_1 = apparmor_fact_collector_1.collect(collected_facts=ansible_facts)
    apparmor_dict_0 = ansible_facts_1['apparmor']
    key_0 = 'status'
    value_0 = apparmor_dict_0[key_0]
    assert value_0 is not None


# Generated at 2022-06-24 23:40:37.485735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:40:40.610038
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
