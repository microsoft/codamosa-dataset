

# Generated at 2022-06-24 23:31:55.824615
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        apparmor_fact_collector_0 = ApparmorFactCollector()
        apparmor_facts_dict_0 = apparmor_fact_collector_0.collect()
        assert apparmor_facts_dict_0 is None
    except Exception as e:
        pass

if __name__ == "__main__":
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:31:58.670532
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:07.290467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_3 = ApparmorFactCollector()
    apparmor_fact_collector_4 = ApparmorFactCollector()
    apparmor_fact_collector_5 = ApparmorFactCollector()
    apparmor_fact_collector_6 = ApparmorFactCollector()
    apparmor_fact_collector_7 = ApparmorFactCollector()
    apparmor_fact_collector_8 = ApparmorFactCollector()
#
#     assert apparmor_fact_collector_1.collect() == apparmor_fact_collector_2.collect(), "collect() failed for case_1"
#
#     assert apparmor_fact_collector_3.

# Generated at 2022-06-24 23:32:12.405429
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert facts_dict['apparmor']['status'] is not None

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:21.781557
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fp_0 = '/sys/kernel/security/apparmor'
    fp_1 = '/sys/kernel/security/apparmor'
    fp_2 = '/sys/kernel/security/apparmor'
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if os.path.exists(fp_0):
        apparmor_fact_collector_1.collect()
    else:
        apparmor_fact_collector_1.collect()
    if os.path.exists(fp_1):
        apparmor_fact_collector_1.collect()
    else:
        apparmor_fact_collector_1.collect()
    if os.path.exists(fp_2):
        apparmor_fact_collector_1.collect()
    else:
        apparmor_fact_

# Generated at 2022-06-24 23:32:25.018054
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    fact_dict = apparmor_fact_collector_0.collect(collected_facts=None)
    assert {'apparmor': {'status': 'disabled'}} == fact_dict

# Generated at 2022-06-24 23:32:28.333104
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:35.214537
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Run method collect of class ApparmorFactCollector
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    collected_facts['apparmor'] = {}
    facts_dict = apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert facts_dict["apparmor"]["status"] == "enabled"

if __name__ == '__main__':
    print(test_case_0())
    print(test_ApparmorFactCollector_collect())

# Generated at 2022-06-24 23:32:37.518373
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()

    assert not apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:39.784392
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:32:45.929471
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:32:48.801192
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:51.810604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:52.886656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:32:54.468230
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  apparmor_fact_collector = ApparmorFactCollector()
  apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:32:59.525921
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    expected = {'apparmor': {'status': 'enabled'}}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    actual = apparmor_fact_collector_0.collect()
    assert expected == actual


# Generated at 2022-06-24 23:33:02.309302
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:04.512259
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:06.613819
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:08.715420
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:33:13.978908
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {}

if __name__ == '__main__':
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:19.785976
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    def my_code_path_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False
    apparmor_fact_collector.code_path_exists = my_code_path_exists
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'enabled'

    def my_code_path_exists_false(path):
        return False
    apparmor_fact_collector.code_path_exists = my_code_path_exists_false
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:33:20.887608
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:23.520762
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    ap_facts = apparmor_fact_collector_0.collect()
    assert 'apparmor' in ap_facts
    assert 'status' in ap_facts['apparmor']

# Generated at 2022-06-24 23:33:29.017187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect({'apparmor': {'apparmor_status': 'enabled'}}, {'apparmor': {'apparmor_status': 'enabled'}})

# Generated at 2022-06-24 23:33:34.784169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_collect_0.collect() == {u'apparmor': {u'status': u'disabled'}}


# Generated at 2022-06-24 23:33:43.666981
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # Unit test with no file
    collected_facts = {}
    assert(apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}})

    # Unit test with file
    os.makedirs('/sys/kernel/security/apparmor')
    assert(apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}})
    os.rmdir('/sys/kernel/security/apparmor')

# Generated at 2022-06-24 23:33:45.046828
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:47.952884
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:51.398127
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    test_case_0()
    result_0 = apparmor_fact_collector_0.collect()
    assert result_0 is None


# Generated at 2022-06-24 23:34:00.800496
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:03.390118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None
    assert apparmor_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:34:11.315490
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_2.collect()
    apparmor_fact_collector_3 = ApparmorFactCollector()
    apparmor_fact_collector_3.collect()

# Generated at 2022-06-24 23:34:15.211807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    a = c.collect()
    assert a.has_key('apparmor')
    assert a['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-24 23:34:18.045653
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()


test_class_1 = ApparmorFactCollector
test_method_1 = 'collect'
test_params_1 = None
test_expected_1 = {
    'apparmor': {
        'status': 'enabled'
    }
}

# Generated at 2022-06-24 23:34:21.224672
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:25.555498
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:29.545046
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:33.927679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print('Testing ApparmorFactCollector.collect')
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:34.899552
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert {} == apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:49.746168
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_0_obj.collect() is not None


# Generated at 2022-06-24 23:34:51.572845
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:55.165298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_results_0 = apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_results_0['apparmor']['status'] == 'enabled' or apparmor_fact_collector_results_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:56.505015
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_1.collect(), dict)

# Generated at 2022-06-24 23:34:58.067699
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()

    assert 'apparmor' not in facts

# Generated at 2022-06-24 23:35:02.380661
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    apparmor_fact_collector_2.collect()


test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:35:03.528476
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:35:05.977902
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Return an empty dict()
    assert apparmor_fact_collector_0.collect() == dict(), \
     'If /sys/kernel/security/apparmor does not exist, then return an empty dict'


if __name__ == "__main__":
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:35:08.761413
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:10.971399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_collection = apparmor_fact_collector.collect()
    assert type(apparmor_fact_collector_collection) is dict

# Generated at 2022-06-24 23:35:41.452954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_0.collect()
    assert('apparmor' in apparmor_facts)


# Generated at 2022-06-24 23:35:46.526036
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:52.526277
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector_0.collect()
    assert type(apparmor_facts_dict) == dict
    assert 'apparmor' in apparmor_facts_dict
    assert 'status' in apparmor_facts_dict['apparmor']
    assert type(apparmor_facts_dict['apparmor']['status']) == str

# Generated at 2022-06-24 23:35:57.811477
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(),dict)


# Generated at 2022-06-24 23:36:00.499151
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # AnsibleModule object provided by AnsibleModuleTest
    apparmor_fact_collector_1 = ApparmorFactCollector()

    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:06.574823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert isinstance(facts_dict, dict)
    assert 'apparmor' in facts_dict.keys()
    assert isinstance(facts_dict['apparmor'], dict)
    assert 'status' in facts_dict['apparmor'].keys()

# Generated at 2022-06-24 23:36:07.071146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:36:09.973609
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res_0 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in res_0.keys()
    assert 'status' in res_0['apparmor'].keys()

# Generated at 2022-06-24 23:36:16.792959
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert 'apparmor' in result.keys()
    assert 'disabled' == result['apparmor']['status']

# Generated at 2022-06-24 23:36:19.975396
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:36:57.957715
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {
        "apparmor": {
            "status": "disabled"
        }
    }

# Generated at 2022-06-24 23:36:58.995276
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:01.116516
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert (var_1['apparmor']['status'] == 'enabled' or var_1['apparmor']['status'] == 'disabled') is True

# Generated at 2022-06-24 23:37:06.844845
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    result_0 = { 'apparmor': { 'status': 'disabled' } }

    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == result_0

# Generated at 2022-06-24 23:37:11.101112
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    var_1 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:16.617450
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:37:17.256757
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # not implemented
    pass

# Generated at 2022-06-24 23:37:22.370681
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:25.914510
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:30.377476
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {
        'apparmor': {
            'status': 'enabled',
        },
    }


# Generated at 2022-06-24 23:38:36.340576
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    try:
        var_1 = apparmor_fact_collector_1.collect()
    except:
        var_1 = None
    assert var_1 == {}

# Generated at 2022-06-24 23:38:39.382427
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    var_2 = apparmor_fact_collector_0.collect()
    var_3 = apparmor_fact_collector_0.collect()
    print(var_3)
    print(var_2)

# Generated at 2022-06-24 23:38:41.632251
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:38:47.348958
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 23:38:48.691627
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:54.145894
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:38:56.982179
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    # Test for equality
    assert var_0 == {u'apparmor': {u'status': u'disabled'}}

# Generated at 2022-06-24 23:38:57.605499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:38:59.380691
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}, 'Failed to run test_ApparmorFactCollector_collect'

# Generated at 2022-06-24 23:39:00.341714
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:41:12.973843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:41:14.278911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:41:16.543176
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Case 0
    test_case_0()


if __name__ == '__main__':
    # Case 0
    test_case_0()

# Generated at 2022-06-24 23:41:19.067761
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:41:23.065548
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:41:25.180807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create object of class ApparmorFactCollector
    apparmor_fact_collector_1 = ApparmorFactCollector()

    # Call method collect of class ApparmorFactCollector
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:41:30.158173
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Test case 0. """
    test_case_0()

# Generated at 2022-06-24 23:41:32.148875
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:41:35.836648
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:41:40.607362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    if apparmor_fact_collector_1._module.params['gather_subset'] is None:
        assert var_1.get('apparmor') is not None
    else:
        assert var_1.get('apparmor') is None
    return