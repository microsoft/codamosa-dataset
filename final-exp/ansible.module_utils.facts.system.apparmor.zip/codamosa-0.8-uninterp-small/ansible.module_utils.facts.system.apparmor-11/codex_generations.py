

# Generated at 2022-06-24 23:31:54.860040
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:31:55.888344
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = ApparmorFactCollector().collect()
    assert 'apparmor' in facts

# Generated at 2022-06-24 23:31:58.737068
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-24 23:31:59.469220
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:32:01.598448
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_2.collect()

# Generated at 2022-06-24 23:32:02.579261
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_collect("apparmor", {})

# Generated at 2022-06-24 23:32:12.229997
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import imp
    import sys
    import os
    # Create instance for test case class
    apparmor_fact_collector = ApparmorFactCollector()
    # Get the test class
    test_class = getattr(sys.modules[__name__], 'ApparmorFactCollector')
    # Create an instance of the test class
    if not hasattr(test_class, '_test_class_instance'):
        test_class._test_class_instance = test_class()
    # Get the path of the data directory
    test_datadir = imp.find_module('unit_tests.collector')[1]
    test_datadir = os.path.join(test_datadir, 'data')
    # Create an instance of mock class to mock methods of the class
    # ApparmorFactCollector to be tested
    app

# Generated at 2022-06-24 23:32:17.076298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected = {'apparmor': {'status': 'enabled'}}
    else:
        expected = {'apparmor': {'status': 'disabled'}}
    actual = apparmor_fact_collector_0.collect()
    assert expected == actual

# Generated at 2022-06-24 23:32:21.281363
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmorFacts = apparmor_fact_collector_0.collect()
    apparmor_status = apparmorFacts['apparmor'].get('status')
    assert apparmor_status in ('enabled', 'disabled')

# Generated at 2022-06-24 23:32:24.209871
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    chdir = apparmor_fact_collector.setUp()
    try:
        apparmor_fact_collector.collect()
    finally:
        apparmor_fact_collector.tearDown(chdir)

# Generated at 2022-06-24 23:32:30.660516
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    try:
        assert isinstance(var_0.get('apparmor'), dict)
    except AssertionError:
        raise AssertionError(var_0.get('apparmor').__class__.__name__)

# Generated at 2022-06-24 23:32:33.705110
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:35.610679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:37.311226
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:39.785462
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:43.944824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {u'apparmor': {u'status': u'disabled'}}, var_0

if __name__ == '__main__':
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:45.187843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-24 23:32:50.171023
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:55.410067
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:32:58.396475
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:05.900592
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # unit test for ApparmorFactCollector.collect
    assert 'status' in apparmor_fact_collector_0.collect()['apparmor']
    assert 'ansible_collected' not in apparmor_fact_collector_0.collect()
# unit test for ApparmorFactCollector.__init__

# Generated at 2022-06-24 23:33:08.325744
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:33:10.821455
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts = {}
    var_1 = apparmor_fact_collector_1.collect(collected_facts=collected_facts)

# Generated at 2022-06-24 23:33:16.447060
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    dict_1 = {}
    dict_1['status'] = 'disabled'
    dict_0 = {}
    dict_0['apparmor'] = dict_1
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == dict_0

# Generated at 2022-06-24 23:33:18.188503
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# This is a dummy template

# Generated at 2022-06-24 23:33:20.116412
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:33:24.056293
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] in [
            'enabled', 'disabled']


test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:29.966822
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert var_1 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:34.852821
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:33:39.255901
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1 == {}
    assert isinstance(var_1, dict)



# Generated at 2022-06-24 23:33:49.510541
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:52.111731
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    var_0 = apparmor_fact_collector_0.collect(collected_facts=collected_facts_0)


# Generated at 2022-06-24 23:33:55.488537
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:34:00.690708
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    value_of_var_0 = apparmor_fact_collector_0.collect()
    print(value_of_var_0)


# Generated at 2022-06-24 23:34:02.985028
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:06.023770
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:34:09.174949
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_1 = ApparmorFactCollector()
    var_2 = False
    try:
        var_1.collect()
    except Exception as e:
        var_2 = True
    assert var_2 is False, "var_2 is not False"

# Generated at 2022-06-24 23:34:12.625963
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()




# Generated at 2022-06-24 23:34:14.957037
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var_0 = ApparmorFactCollector()
    var_1 = var_0.collect()

# Generated at 2022-06-24 23:34:23.647795
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    # apparmor_fact_collector_0.collect() returns a dict
    if not isinstance(var_0, dict):
        raise AssertionError()
    # apparmor_fact_collector_0.collect() returns a dict with one key(apparmor)
    if sorted(list(var_0.keys())) != [u'apparmor']:
        raise AssertionError()
    # apparmor_fact_collector_0.collect() returns a dict with one key(apparmor) and dict as value
    if not isinstance(var_0['apparmor'], dict):
        raise AssertionError()
    # apparmor_fact_collector_0.collect() returns

# Generated at 2022-06-24 23:34:39.564414
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:42.253824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:44.621625
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:49.365850
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:34:52.228127
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector._collect_facts()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-24 23:34:53.893362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:59.980383
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Collect facts from apparmor:
    var_0 = apparmor_fact_collector_0.collect()
    assert (var_0['apparmor']['status'] == 'enabled' or var_0['apparmor']['status'] == 'disabled')

# Generated at 2022-06-24 23:35:02.202752
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:06.994538
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:09.739003
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:35:35.369464
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 23:35:41.421161
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var is not None
    assert 'apparmor' in var.keys()
    assert isinstance(var['apparmor'], dict)
    assert 'status' in var['apparmor'].keys()

# Generated at 2022-06-24 23:35:44.093734
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        os.path.exists('/sys/kernel/security/apparmor')
        apparmor_fact_collector_0 = ApparmorFactCollector()
        var_0 = apparmor_fact_collector_0.collect()
    except:
        pass

# Generated at 2022-06-24 23:35:46.016289
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_list = [apparmor_fact_collector_0]
    for var_0 in var_list:
        var_0.collect()

# Generated at 2022-06-24 23:35:47.468620
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:49.903697
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:35:52.816339
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:54.611356
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:57.802202
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

if __name__ == "__main__":
    print('-- Testing ApparmorFactCollector')
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:36:01.595088
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'



# Generated at 2022-06-24 23:36:56.189990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:36:57.322798
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:58.996181
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:37:01.007129
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert 'apparmor' in var_1

# Generated at 2022-06-24 23:37:05.337565
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:37:06.904826
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:07.910782
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:37:13.125917
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    var_0 = {u'apparmor': {u'status': u'disabled'}}


# Generated at 2022-06-24 23:37:15.661367
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:17.370107
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var is not None



# Generated at 2022-06-24 23:39:19.685982
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert type(ApparmorFactCollector().collect()) is dict

# Generated at 2022-06-24 23:39:20.415100
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert callable(ApparmorFactCollector.collect)



# Generated at 2022-06-24 23:39:21.750736
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:39:29.569481
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {'apparmor': {'status': 'disabled'}}
    collected_facts_1 = apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts_1 == collected_facts

    collected_facts_2 = {'apparmor': {'status': 'enabled'}}
    collected_facts_3 = apparmor_fact_collector_0.collect(collected_facts=collected_facts_2)
    assert collected_facts_3 == collected_facts_2

# Generated at 2022-06-24 23:39:32.192807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:39:38.207890
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts_1 = {u'status': 'enabled'}
    else:
        apparmor_facts_1 = {u'status': 'disabled'}
    facts_dict_1 = apparmor_fact_collector_1.collect()
    var_1 = apparmor_facts_1['status']
    assert var_1 == u'enabled' or var_1 == u'disabled'

# Generated at 2022-06-24 23:39:39.988146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:41.473153
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:43.648953
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    var_1 = {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:39:46.340944
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print("Unit test for method collect of class ApparmorFactCollector")
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {'apparmor': {'status': 'enabled'}}
    var_0 = apparmor_fact_collector_0.collect(collected_facts_0)
