

# Generated at 2022-06-24 23:31:53.265040
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
# print(apparmor_fact_collector_0.collect())


# Generated at 2022-06-24 23:31:55.603057
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:31:58.688482
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Return facts related to apparmor
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-24 23:32:03.700721
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 23:32:08.260334
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict == { 'apparmor': {'status': 'enabled'} }

# Generated at 2022-06-24 23:32:11.676447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:32:13.545742
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:15.308914
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:20.004685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    fact_list = ['ansible_apparmor']
    facts_dict = apparmor_fact_collector_0.collect(None, fact_list)
    assert facts_dict == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:32:22.056824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:32:24.458457
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:32:25.878362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:36.111422
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test case 1 with path /sys/kernel/security/apparmor
    with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'test_data', 'apparmor', 'apparmor_status_enabled.txt'), 'r') as test_file:
        apparmor_status_enabled = test_file.read()

    with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'test_data', 'apparmor', 'apparmor_status_enabled_empty.txt'), 'r') as test_file:
        apparmor_status_enabled_empty = test_file.read()

    mock_module = type('module', (), {})

# Generated at 2022-06-24 23:32:37.486533
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:39.582172
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-24 23:32:41.725673
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:43.187809
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:45.028146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    return_value = apparmor_fact_collector_0.collect()
    assert type(return_value) is dict
    pass


# Generated at 2022-06-24 23:32:46.658311
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:50.600386
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:55.554443
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result_0 = apparmor_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:32:59.274676
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert (apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}})



# Generated at 2022-06-24 23:33:05.161078
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts = {}
    expected_facts = {
        'apparmor': {
            'status': 'disabled'
        }
    }
    collected_facts = apparmor_fact_collector_1.collect(collected_facts=collected_facts)
    assert collected_facts == expected_facts


# Generated at 2022-06-24 23:33:07.279986
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() is not None

# Generated at 2022-06-24 23:33:12.283784
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Test case #0
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_dict = {}
    ansible_facts_dict = apparmor_fact_collector_0.collect(collected_facts_dict)
    assert 'apparmor' in ansible_facts_dict
    assert 'status' in ansible_facts_dict['apparmor']
    assert ansible_facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:33:13.440387
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # a = ApparmorFactCollector()
    # b = a.collect()
    # assert b == 2
    pass

# Generated at 2022-06-24 23:33:15.265406
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    dict_0 = {}
    apparmor_fact_collector_1.collect(dict_0)


# Generated at 2022-06-24 23:33:17.803061
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # test with no exceptions
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:23.607561
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:29.419791
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}, facts_dict


# Generated at 2022-06-24 23:33:34.207501
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:39.955286
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import pytest
    # var_0 = { "changed": False, "ansible_facts": { "apparmor": {} }, "ansible_facts_d": { "apparmor": {} } }

    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.load_from_file('/home/bilal/ansible/ansible/lib/ansible/modules/system/setup/facts/collector/apparmor.py')
    var_0 = apparmor_fact_collector_0.collect()

    if "changed" in var_0:
        assert var_0["changed"] == False
    if "ansible_facts" in var_0:
        var_1 = var_0["ansible_facts"]
        assert var_1 == { "apparmor": {} }


# Generated at 2022-06-24 23:33:42.136621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}
    assert apparmor_fact_collector_0.collect({}, {}) == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:33:44.290449
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    print(var_1)

# Generated at 2022-06-24 23:33:46.098300
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-24 23:33:50.724197
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:53.221065
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:57.598009
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts_0 = {'status': 'enabled'}
    else:
        apparmor_facts_0 = {'status': 'disabled'}
    facts_dict_0 = {'apparmor': apparmor_facts_0}
    assert(apparmor_fact_collector_0.collect() == facts_dict_0)

# Generated at 2022-06-24 23:34:01.901631
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:08.839781
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect({'ansible_fact_file_valid': True})
    var_1 = apparmor_fact_collector_0.collect({'ansible_fact_file_valid': 'ansible_fact_file_valid'})
    var_2 = apparmor_fact_collector_0.collect({'ansible_fact_file_valid': 'ansible_fact_file_valid'})
    var_3 = apparmor_fact_collector_0.collect({'ansible_fact_file_valid': 0})
    var_4 = apparmor_fact_collector_0.collect({'ansible_fact_file_valid': 'ansible_fact_file_valid'})
    var_5

# Generated at 2022-06-24 23:34:16.191986
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.name == 'apparmor'

# Generated at 2022-06-24 23:34:18.967055
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:34:23.044988
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:34:24.774640
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:26.991108
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    case_0 = {'apparmor': {'status': 'disabled'}}
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == case_0


# Generated at 2022-06-24 23:34:32.470470
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == (
        {'apparmor': {'status': 'disabled'}},
        {'apparmor': {'status': 'enabled'}}
    )



# Generated at 2022-06-24 23:34:35.069666
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    # Verify variable var_0.
    assert 'apparmor' in var_0

# Generated at 2022-06-24 23:34:40.027608
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:34:43.363138
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:34:49.373679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:01.459547
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._collect()

# Generated at 2022-06-24 23:35:08.175600
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if apparmor_fact_collector_1.collect():
        print('Method "collect" returns valid value')
    else:
        print('Method "collect" returns incorrect value')


# Generated at 2022-06-24 23:35:10.749686
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_2 = apparmor_fact_collector_0.collect()
    assert var_2 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:15.045665
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert ('apparmor' in var_0)

# Generated at 2022-06-24 23:35:16.713430
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    BLUF = 'ApparmorFactCollector.collect()'
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:18.203615
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:35:21.259965
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var_0 = apparmor_fact_collector.collect()


# vim: set et ts=4 sw=4

# Generated at 2022-06-24 23:35:25.494334
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:27.737896
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 is None

# Generated at 2022-06-24 23:35:32.349455
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()



# Generated at 2022-06-24 23:35:58.817209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()
    command = fact_collector.collect()
    assert 'apparmor' in command
    assert isinstance(command['apparmor'], dict)
    assert isinstance(command['apparmor']['status'], str)

# Generated at 2022-06-24 23:36:01.497717
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  # No input verification so no test case
  pass

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-24 23:36:06.646166
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var

# Generated at 2022-06-24 23:36:09.531043
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    expected_0 = {'apparmor': {'status': 'enabled'}}
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == expected_0


# Generated at 2022-06-24 23:36:14.970207
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_m = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_m.collect()

# Generated at 2022-06-24 23:36:19.682775
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert isinstance(var_1, dict) == True
    assert var_1.get('apparmor') == {'enabled': True} or var_1.get('apparmor') == {'enabled': False}



# Generated at 2022-06-24 23:36:21.122694
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()


# Generated at 2022-06-24 23:36:22.456649
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # TODO implement your test

# Generated at 2022-06-24 23:36:24.315261
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:36:26.747660
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    if var_0 == {'apparmor': {'status': 'disabled'}}:
        assert True
    else:
        assert False

# Generated at 2022-06-24 23:37:27.217511
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Test the return value of method collect when it is called with arguments: (1, 2)
    # The expected result is: {'apparmor': {'status': 'disabled'}}
    var_1 = apparmor_fact_collector_0.collect(1, 2)
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:37:29.849958
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:32.041430
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:37:32.536063
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:37:34.701028
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        test_case_0()
    except:
        raise RuntimeError("Failed to collect apparmor facts.")

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:37:35.369120
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(True)


# Generated at 2022-06-24 23:37:37.110435
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:37:42.997134
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # no return value expected
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:37:45.350567
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var != {}

# Generated at 2022-06-24 23:37:51.973749
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initialize host variable
    host_0 = ApparmorFactCollector()
    # Execute function collect of class ApparmorFactCollector
    var_0 = host_0.collect(module='str_0', collected_facts=None)
    # Assert the value of variable var_0
    assert var_0 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:40:03.698665
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:08.826115
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:13.179198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:15.402136
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {}


# Generated at 2022-06-24 23:40:21.363558
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1["apparmor"]["status"] != None

# Generated at 2022-06-24 23:40:23.568673
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert len(var_0) == 1
    assert 'apparmor' in var_0

# Generated at 2022-06-24 23:40:29.746589
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:34.000714
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:38.553971
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    stdout = [b'enabled']
    stderr = None
    rc = 0
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:40:41.266904
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()