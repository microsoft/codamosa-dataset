

# Generated at 2022-06-24 23:31:50.317298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector_1.collect()['apparmor'].keys()[0]

# Generated at 2022-06-24 23:31:54.132130
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:31:55.714162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:31:59.326405
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None


# Note: This function name is required for Ansible to find it and call it.

# Generated at 2022-06-24 23:32:00.726621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    assert aafc.collect()

# Generated at 2022-06-24 23:32:04.846953
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-24 23:32:06.746203
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:10.797128
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:32:14.403331
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1_result = apparmor_fact_collector_1.collect()
    print(apparmor_fact_collector_1_result)


# Generated at 2022-06-24 23:32:19.951180
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Set up test environment
    apparmor_fact_collector_0._get_files_from_path = fake_path

    try:
        apparmor_fact_collector_0.collect()
    except Exception:
        raise AssertionError('Unexpected exception raised')
    else:
        assert False # test didn't throw an exception as expected


# Generated at 2022-06-24 23:32:25.481694
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        facts_dict = apparmor_fact_collector.collect()
        assert facts_dict['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:32:31.595027
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Use the module to test
    from ansible.module_utils.facts.collectors.apparmor.apparmor import ApparmorFactCollector
    # Create a fact collector object
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Run the collect method
    apparmor_fact_collector_0.collect()


# Run the tests
test_ApparmorFactCollector_collect()
test_case_0()

# Generated at 2022-06-24 23:32:35.765606
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert(result == {'apparmor': {'status': 'disabled'}})


# Generated at 2022-06-24 23:32:38.844772
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()
    # Compare results with reference
    assert facts_dict_0['apparmor'] == {
        'status': 'enabled',
    }


# Generated at 2022-06-24 23:32:41.905924
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {'apparmor': {}}
    assert 'apparmor' in apparmor_fact_collector.collect(collected_facts)

# Generated at 2022-06-24 23:32:44.998118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_dict_0 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in apparmor_dict_0
    assert 'status' in apparmor_dict_0['apparmor']

# Generated at 2022-06-24 23:32:49.519815
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    return_value_0 = apparmor_fact_collector_0.collect()
    assert 'apparmor' in return_value_0
    assert 'status' in return_value_0['apparmor']

# Generated at 2022-06-24 23:32:52.090347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:53.424875
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect()
    assert result is not None
    assert isinstance(result, dict) is True

# Generated at 2022-06-24 23:32:55.588535
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector.collect()
    assert type(apparmor_facts_dict) == dict

# Generated at 2022-06-24 23:33:09.554021
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # test status = enabled
    apparmor_fact_collector._fs.exists = lambda x: True
    results = apparmor_fact_collector.collect()
    assert 'apparmor' in results
    assert 'status' in results['apparmor']
    assert results['apparmor']['status'] == 'enabled'
    # test status = disabled
    apparmor_fact_collector._fs.exists = lambda x: False
    results = apparmor_fact_collector.collect()
    assert 'apparmor' in results
    assert 'status' in results['apparmor']
    assert results['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:33:16.047990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    # Unit test for method collect of class ApparmorFactCollector with arg 'module'
    apparmor_fact_collector_0.collect(module=None, collected_facts=collected_facts)


# Generated at 2022-06-24 23:33:20.587772
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert isinstance(result, dict)
    assert result['apparmor']['status'] in ['enabled', 'disabled']


# Generated at 2022-06-24 23:33:23.231804
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts = apparmor_fact_collector_0.collect()
    if facts['apparmor']['status'] == 'enabled':
        assert True
    else:
        assert False

# Generated at 2022-06-24 23:33:31.787184
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()

    if os.path.exists('/sys/kernel/security/apparmor'):
        facts_dict_0 = apparmor_fact_collector_0.collect()
        print(facts_dict_0)
    else:
        facts_dict_0 = apparmor_fact_collector_0.collect()
        print(facts_dict_0)

# Generated at 2022-06-24 23:33:38.349684
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    ansible_facts = {}
    ansible_facts['system'] = {}
    ansible_facts['ansible_system_capabilities'] = []
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'
    ansible_facts['apparmor'] = apparmor_facts
    ansible_facts_1 = apparmor_fact_collector_1.collect(collected_facts=ansible_facts)
    assert ansible_facts_1['apparmor'] == ansible_facts['apparmor']
    del ansible_facts['apparmor']
    ansible_facts_2

# Generated at 2022-06-24 23:33:39.353656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:33:40.692688
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}



# Generated at 2022-06-24 23:33:45.921010
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    # Example of the input that needs to be passed to the collect method of ApparmorFactCollector class
    # collected_facts = {
    #     'distribution': 'Ubuntu',
    #     'distribution_major_version': '14'
    # }

    # result = apparmor_fact_collector_1.collect(collected_facts)
    # assert result is not None
    assert 0

# Generated at 2022-06-24 23:33:50.202692
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:03.066391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:05.315538
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:07.627792
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if __name__ == '__main__':
        test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:34:08.186463
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(1)

# Generated at 2022-06-24 23:34:10.737303
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-24 23:34:13.976337
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if False:
        print('1')

# Generated at 2022-06-24 23:34:17.766307
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:20.717613
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_fact = ApparmorFactCollector()
    test_fact_collect = test_fact.collect()
    assert test_fact_collect == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-24 23:34:22.177144
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:24.846405
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    data_returned = apparmor_fact_collector_1.collect()
    print(data_returned)

test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:34:39.579132
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:41.612765
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:45.204583
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_mock_0 = MagicMock()
    apparmor_fact_collector_mock_0.collect().AndReturn({'apparmor': None, })
    var_0 = apparmor_fact_collector_mock_0.collect()
    var_0


# Generated at 2022-06-24 23:34:49.824914
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:51.916571
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:53.893823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:58.355218
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-24 23:35:01.812831
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Invoke method
    var_0 = apparmor_fact_collector_0.collect()


if __name__ == '__main__':
    print('Running test cases')
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:35:07.619906
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:35:09.553149
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:40.727094
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}, "Value should be {'apparmor': {'status': 'disabled'}}, value is %s" % var_1

# Generated at 2022-06-24 23:35:42.380011
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:35:47.786281
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}, var_1

# Generated at 2022-06-24 23:35:49.720012
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:53.232437
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    if var_1 is None:
        var_1 = {}
    if isinstance(var_1, dict):
        assert True
    else:
        assert False



# Generated at 2022-06-24 23:35:55.442539
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # test case
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:58.105573
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:36:01.253007
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:36:07.044522
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:36:10.728212
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Expected values
    expected_0 = {
        'apparmor': {
            'status': 'enabled',
        },
    }

    # Invoke method
    apparmor_fact_collector_0 = ApparmorFactCollector()
    actual_0 = apparmor_fact_collector_0.collect()

    # Assertions
    assert actual_0 == expected_0

# Generated at 2022-06-24 23:37:11.603851
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:37:19.260041
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup mock module
    module = {
                'name': 'test',
                '_load_name': 'test',
                'args': {},
                '__file__': '/path/to/test',
                'run_command': lambda x, check_rc=None: ('', None),
                'get_bin_path': lambda x, opt_dirs=None: '/bin/foo',
                'params': {}
            }
    module_class = type(module)
    mock_module = module_class(module['name'], module['args'], module['_load_name'], module['__file__'], module['_init_done'], module['_ansible_version'])
    mock_module.run_command = module['run_command']

# Generated at 2022-06-24 23:37:24.207755
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:37:25.977398
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-24 23:37:27.740423
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Call method collect of class ApparmorFactCollector
    return test_case_0()

# Generated at 2022-06-24 23:37:35.491097
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    #
    # Test case with valid inputs args.
    #
    var_0 = apparmor_fact_collector_0.collect(
        module='module',
        collected_facts='collected_facts'
    )

    #
    # Test case with invalid inputs args.
    #
    apparmor_fact_collector_1 = ApparmorFactCollector()
    with pytest.raises(TypeError):
        apparmor_fact_collector_1.collect(
            module=4,
            collected_facts='collected_facts'
        )
    with pytest.raises(TypeError):
        apparmor_fact_collector_1.collect(
            module='module',
            collected_facts=9
        )

# Generated at 2022-06-24 23:37:39.205165
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = []
    with pytest.raises(NotImplementedError):
        apparmor_fact_collector_0.collect(module=None, collected_facts=collected_facts_0)

# Generated at 2022-06-24 23:37:40.646401
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:37:42.144435
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:37:43.912113
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:56.530586
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:39:58.842728
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_dict = {
        'status': 'enabled'
    }
    apparmor_fact_collector = ApparmorFactCollector()
    try:
        apparmor_fact_collector.collect()
        assert apparmor_fact_collector.collect() == apparmor_dict
    except Exception:
        assert False

# Generated at 2022-06-24 23:40:07.126614
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    result_0 = apparmor_fact_collector_obj.collect()
    assert result_0 == {'apparmor': {'status': 'enabled'}}
    result_1 = apparmor_fact_collector_obj.collect()
    assert result_1 == {'apparmor': {'status': 'enabled'}}
    result_2 = apparmor_fact_collector_obj.collect()
    assert result_2 == {'apparmor': {'status': 'enabled'}}
    result_3 = apparmor_fact_collector_obj.collect()
    assert result_3 == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-24 23:40:09.194653
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:40:13.280521
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:40:16.358646
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert 'status' in var_0['apparmor']
    assert var_0['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:40:21.672756
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:40:23.389094
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  apparmor_fact_collector_0=ApparmorFactCollector()
  var_0=apparmor_fact_collector_0.collect()
  assert var_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:40:30.505533
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_initializer = ApparmorFactCollector()
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_initializer.collect() == apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:37.761515
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Read Mock Data
    path = os.path.join(os.path.dirname(__file__), 'mock_data')
    with open(path + '/apparmor_fact_collector_expected_result.json', 'r') as f:
        apparmor_fact_collector_expected_result = json.load(f)

    # Call method
    var_0 = apparmor_fact_collector_0.collect()

    # Check result
    assert var_0 == apparmor_fact_collector_expected_result