

# Generated at 2022-06-24 23:31:57.843664
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:31:59.868567
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:32:05.784414
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert type(result) is type({}), "apparmor_fact_collector_0.collect() did not return a dictionary."
    assert 'apparmor' in result, "apparmor_fact_collector_0.collect() did not return a dictionary with a 'apparmor' key.  It was: %s" % result

# Generated at 2022-06-24 23:32:08.572415
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # This is a dummy test case to ensure that the test case is run
    assert apparmor_fact_collector_0.collect() is None

# Generated at 2022-06-24 23:32:12.611829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    res1 = apparmor_fact_collector_1.collect()
    res2 = apparmor_fact_collector_1.collect()
    assert res1 == res2

# Generated at 2022-06-24 23:32:14.443315
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:32:16.129788
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:21.001676
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    argnames, argvalues, _2, _3 = inspect.getargvalues(inspect.currentframe())
    args = dict(list(zip(argnames, argvalues)))
    apparmor_fact_collector_0.collect(**args)


# Generated at 2022-06-24 23:32:24.596808
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # This is a test case to test the method collect from class ApparmorFactCollector
    apparmor_fact_collector_0 = ApparmorFactCollector()
    dict_of_facts_0 = apparmor_fact_collector_0.collect()
    assert dict_of_facts_0 == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:28.829317
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    results_dict_0 = apparmor_fact_collector_0.collect()
    assert results_dict_0 == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:32:36.081117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.name = 'foo'
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:42.441970
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    # This test assumes that /sys/kernel/security/apparmor exists.
    # If it does not, the collect method will fail.
    # We will assume that the test machine is correctly setup,
    # and that /sys/kernel/security/apparmor exists.
    # This is reasonable because a test machine is by definition under
    # control of the developer, who is responsible for its maintenance.
    res = apparmor_fact_collector_1.collect()
    assert res['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:32:44.148086
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:45.888106
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert 'status' in apparmor_fact_collector_0.collect()['apparmor']

# Generated at 2022-06-24 23:32:51.152858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert "apparmor" in result
    assert "status" in result["apparmor"]
    assert result["apparmor"]["status"] == "disabled"

# Generated at 2022-06-24 23:32:53.102379
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:55.668836
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1._populate()

    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_2.collect()

# Generated at 2022-06-24 23:32:58.866576
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is not None


# Generated at 2022-06-24 23:33:01.708332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:03.821555
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:16.048181
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    ret = {}
    apparmor_fact_collector_1.collect(collected_facts=ret)
    print(ret)

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:33:19.935106
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:22.517391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:33:33.801732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    with open('/sys/kernel/security/apparmor/profiles') as f:
        assert f.readline() == "abrt-helper\n"
        assert f.readline() == "alsa\n"
        assert f.readline() == "auditd\n"
        assert f.readline() == "avahi-daemon\n"
        assert f.readline() == "bluetooth-rfkill-event\n"
        assert f.readline() == "cpuspeed\n"
        assert f.readline() == "crond\n"
        assert f.readline() == "dnsmasq\n"
        assert f.readline() == "evince\n"
        assert f.readline() == "firewalld\n"

# Generated at 2022-06-24 23:33:36.061508
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_2 = ApparmorFactCollector()


# Generated at 2022-06-24 23:33:39.007251
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None


# Generated at 2022-06-24 23:33:42.351468
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    ret = apparmor_fact_collector.collect()
    assert type(ret) == dict

# Generated at 2022-06-24 23:33:43.508553
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()

# Generated at 2022-06-24 23:33:45.291263
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() is None

# Generated at 2022-06-24 23:33:48.149974
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:02.023304
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:05.796746
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector_obj = ApparmorFactCollector()
    os.environ['ANSIBLE_LOCAL'] = '1'
    expected_output = {'apparmor': {'status': 'disabled'}}
    output = collector_obj.collect(collected_facts=None)
    assert output == expected_output


# Generated at 2022-06-24 23:34:10.008894
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    expected_result = {
        "apparmor": {"status": "disabled"}
    }
    #assert result == expected_result

# Generated at 2022-06-24 23:34:14.342574
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    collected_facts['ansible_distribution_version'] = '7'
    apparmor_fact_collector_0.collect(collected_facts=collected_facts)



# Generated at 2022-06-24 23:34:18.638969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()

    # Assert.
    assert len(facts_dict_0) == 1


# Generated at 2022-06-24 23:34:21.304317
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ApparmorFactCollector = ApparmorFactCollector()
    test_ApparmorFactCollector.collect()


# Generated at 2022-06-24 23:34:23.648641
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_mock = ApparmorFactCollector()
    apparmor_fact_collector_mock.collect()

# Generated at 2022-06-24 23:34:25.872246
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector(module=None, collected_facts=None)
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:34:33.905162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {
        'dev': {
            'devices': {
                'block': [
                    'dm-0',
                    'dm-1',
                ],
            },
        },
    }
    collected_facts_1 = apparmor_fact_collector_0.collect(None, collected_facts_0)
    assert 'apparmor' in collected_facts_1
    assert 'status' in collected_facts_1['apparmor']

# Generated at 2022-06-24 23:34:35.623678
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() in ({'apparmor': {'status': 'enabled'}}, {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-24 23:35:01.263244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:07.698476
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    param_0 = None
    param_1 = None
    assert 'apparmor' in apparmor_fact_collector_0.collect(param_0, param_1)


# Generated at 2022-06-24 23:35:08.643502
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:10.431954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert type(apparmor_fact_collector_0.collect()) == dict

# Generated at 2022-06-24 23:35:13.744642
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:15.470915
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:35:16.958585
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:35:19.740529
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:35:25.287922
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    res = apparmor_fact_collector_obj.collect()
    assert res['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:35:26.861898
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector_apparmor = ApparmorFactCollector()
    fact_collector_apparmor.collect()

# Generated at 2022-06-24 23:36:17.293024
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    output = apparmor_fact_collector_1.collect()
    assert type(output) == dict

# Generated at 2022-06-24 23:36:24.733806
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    facts_dict = {}
    facts_dict['apparmor'] = apparmor_facts
    return facts_dict
    apparmor_facts = apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert apparmor_facts == facts_dict



# Generated at 2022-06-24 23:36:27.564628
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert isinstance(facts_dict, dict)


# Generated at 2022-06-24 23:36:30.601762
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    apparmor_fact_collector_collect.collect()


# Generated at 2022-06-24 23:36:34.967275
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    collected_facts = dict()
    os.path.exists = MagicMock(return_value=True)
    apparmor_facts_dict = apparmor_fact_collector_obj.collect(collected_facts=collected_facts)
    assert sorted(apparmor_facts_dict.keys()) == ['apparmor']


# Generated at 2022-06-24 23:36:36.534764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

test_case_0()

# Generated at 2022-06-24 23:36:37.490019
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert isinstance(ApparmorFactCollector().collect(), dict)


# Generated at 2022-06-24 23:36:39.362919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Execute method collect of class ApparmorFactCollector
    result = ApparmorFactCollector().collect()

    # Test that we get a dict as a result
    assert isinstance(result, dict)


# Generated at 2022-06-24 23:36:41.163467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect()['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:36:44.806198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj_0 = ApparmorFactCollector()
    if apparmor_fact_collector_obj_0.collect(module=None, collected_facts=None) is None:
        print('This is non-expected behavior of method collect')

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:38:54.643728
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._collect_apparmor_fact = lambda : {'1': '2'}
    apparmor_fact_collector.collect() == {'1': '2'}

# Generated at 2022-06-24 23:38:56.417698
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:39:00.824592
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:39:02.145438
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:39:04.456543
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}



# Generated at 2022-06-24 23:39:09.036596
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts_dict_1 = apparmor_fact_collector_1.collect()
    assert apparmor_facts_dict_1['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:39:13.990313
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:39:18.250606
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    status = apparmor_fact_collector_0.collect()
    if status:
        print("APPARMOR ENABLED")
    else:
        print("APPARMOR DISABLED")

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:39:21.054234
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:39:26.260570
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_obj.collect(collected_facts=collected_facts)
    assert collected_facts == {'apparmor': {'status': 'disabled'}}
