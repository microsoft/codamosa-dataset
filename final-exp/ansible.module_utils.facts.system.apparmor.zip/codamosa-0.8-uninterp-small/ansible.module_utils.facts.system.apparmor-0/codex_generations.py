

# Generated at 2022-06-24 23:31:49.164401
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:31:54.381402
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    os.path.exists = lambda x: True
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:31:57.285356
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    results = apparmor_fact_collector.collect()
    if results is None:
        print("Results returned from method 'collect' of class 'ApparmorFactCollector' is  None")
        assert False
    else:
        assert True


# Generated at 2022-06-24 23:32:03.419248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = apparmor_fact_collector_0.collect()
    expected_collected_facts_0 = {
        'apparmor': {
            'status': 'enabled'
        }
    }
    assert collected_facts_0 == expected_collected_facts_0
    apparmor_fact_collector_1 = ApparmorFactCollector()
    collected_facts_1 = apparmor_fact_collector_1.collect()
    expected_collected_facts_1 = {
        'apparmor': {
            'status': 'disabled'
        }
    }
    assert collected_facts_1 == expected_collected_facts_1

# Generated at 2022-06-24 23:32:08.779022
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_0.collect(collected_facts=collected_facts)
    assert(collected_facts['apparmor'] == {'status': 'disabled'})

# Generated at 2022-06-24 23:32:11.511807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:32:14.039624
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert(apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-24 23:32:16.356385
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert ('apparmor' in result)


# Generated at 2022-06-24 23:32:19.758510
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:22.753763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_1.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:32:28.372263
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:30.552867
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector(None).collect()
    assert ApparmorFactCollector(None).collect(None)
    assert ApparmorFactCollector(None).collect(None, None)

# Generated at 2022-06-24 23:32:34.241588
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector

# Generated at 2022-06-24 23:32:35.882280
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:38.111221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = dict()
    apparmor_fact_collector_0.collect(collected_facts=facts_dict)


# Generated at 2022-06-24 23:32:43.979370
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        os.mkdir('/sys/kernel/security/apparmor')
        apparmor_fact_collector_1 = ApparmorFactCollector()
        assert apparmor_fact_collector_1.collect()['apparmor']['status'] == 'enabled'
        os.rmdir('/sys/kernel/security/apparmor')
        apparmor_fact_collector_2 = ApparmorFactCollector()
        assert apparmor_fact_collector_2.collect()['apparmor']['status'] == 'disabled'
    except:
        pass

# Generated at 2022-06-24 23:32:45.446049
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:48.160323
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:32:54.053078
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:32:55.523865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:05.946713
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initializing an empty dict for collected_facts
    collected_facts = {
    }
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Calling the method to collect the facts for class ApparmorFactCollector of the collector apparmor_fact_collector_0
    apparmor_fact_collector_0.collect(collected_facts = collected_facts)

# Generated at 2022-06-24 23:33:08.717368
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    results = apparmor_fact_collector_0.collect()
    assert type(results['apparmor']['status']) is str

# Generated at 2022-06-24 23:33:10.552721
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() != {}

# Generated at 2022-06-24 23:33:14.285963
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:33:16.010709
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:18.838118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(ApparmorFactCollector.collect() == {'apparmor': [{'status': 'disabled'}]})

# Generated at 2022-06-24 23:33:20.055159
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:33:23.698848
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_path = os.path.dirname(__file__)
    with open(file_path + '/test_modules/apparmor_output.txt') as apparmor_output:
        return_value = apparmor_output.read()
        apparmor_fact_collector_0 = ApparmorFactCollector()
        apparmor_fact_collector_0.file_content = return_value
        apparmor_fact_collector_1 = apparmor_fact_collector_0.collect()
        assert apparmor_fact_collector_1 == {}

# Generated at 2022-06-24 23:33:26.006115
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:30.198594
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:42.356873
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:43.674682
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:33:46.118997
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    status = apparmor_fact_collector.collect()
    if not os.path.exists('/sys/kernel/security/apparmor'):
        assert status['apparmor']['status'] == 'disabled'
    else:
        assert status['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:33:50.742502
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert isinstance(facts_dict, dict)



# Generated at 2022-06-24 23:33:54.858711
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts_dict
    assert 'status' in apparmor_facts_dict['apparmor']

# Generated at 2022-06-24 23:34:02.768590
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # if os.path.exists('/sys/kernel/security/apparmor'):
    #     return 'enabled'
    # else:
    #     return 'disabled'

    # is_running = os.path.exists('/sys/kernel/security/apparmor')
    # if is_running:
    #     return 'enabled'
    # else:
    #     return 'disabled'
    # os.path.exists('/sys/kernel/security/apparmor')
    # if os.path.exists('/sys/kernel/security/apparmor'):
    #     return 'enabled'
    # else:
    #     return 'disabled'
    # os.path.exists('/sys/kernel/security/apparmor')
    # ret =

# Generated at 2022-06-24 23:34:05.062550
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() is not None

# Generated at 2022-06-24 23:34:08.684182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() ==  {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:15.690652
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_2 = ApparmorFactCollector()
    with os.environ.get("PATH") as path:
        path = path.split(":")
        path.append("/usr/sbin/aa-status")
        os.environ["PATH"] = ":".join(path)
        apparmor_fact_collector_2.collect()
    with open("/usr/sbin/aa-status") as fd:
        assert "enabled" in fd.read()

# Generated at 2022-06-24 23:34:18.201492
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:34:43.938228
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_0.collect()
    assert apparmor_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:34:50.078805
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_collect = ApparmorFactCollector()
    collected_facts_dict = apparmor_fact_collector_collect.collect()
    apparmor_facts_dict = collected_facts_dict['apparmor']
    assert apparmor_facts_dict['status'] == 'disabled'

# Generated at 2022-06-24 23:34:52.456453
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert (apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}})


# Generated at 2022-06-24 23:34:57.965753
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res = apparmor_fact_collector_0.collect()
    # Check exception thrown
    assert True

# Generated at 2022-06-24 23:35:00.232075
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = None
    module = None
    expected = {'apparmor': {'status': 'disabled'}}
    actual = apparmor_fact_collector.collect(module, collected_facts)
    assert actual == expected

# Generated at 2022-06-24 23:35:01.289985
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:35:02.443282
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:03.794505
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == \
           {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:35:10.016095
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Test method collect when apparmor is enabled
    '''
    fake_module_0 = "fake_module_0"
    fake_collected_facts_0 = "fake_collected_facts_0"
    apparmor_fact_collector_0 = ApparmorFactCollector()

    apparmor_fact_collector_0.collect(fake_module_0, fake_collected_facts_0)

# Generated at 2022-06-24 23:35:16.223874
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:04.458409
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:10.015298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_test_collect_0 = ApparmorFactCollector()
    apparmor_fact_collector_test_collect_0.name = 'apparmor'
    apparmor_fact_collector_test_collect_0._fact_ids = set()
    assert apparmor_fact_collector_test_collect_0.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:36:15.700701
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect(module=None, collected_facts=None)
    assert type(result) is dict

# Generated at 2022-06-24 23:36:16.840349
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:18.210375
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-24 23:36:20.386299
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fixture_0 = {'apparmor': {'status': 'disabled'}}
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == fixture_0


# Generated at 2022-06-24 23:36:22.699028
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:36:26.310387
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts = {'apparmor': {'status': 'enabled'}}
    else:
        apparmor_facts = {'apparmor': {'status': 'disabled'}}

    assert apparmor_fact_collector.collect() == apparmor_facts

# Generated at 2022-06-24 23:36:30.992429
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_1.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:36:34.023825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect(module=None, collected_facts=None)
    assert(facts_dict.get("apparmor")['status'] == 'disabled')

# Generated at 2022-06-24 23:38:36.734355
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._module = None
    apparmor_fact_collector_0._collected_facts = None
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}, 'Apparmor Fact Collector function collect() for enabled case failed!'
    apparmor_fact_collector_0._module = None
    apparmor_fact_collector_0._collected_facts = None
    apparmor_fact_collector_0._module = None
    apparmor_fact_collector_0._collected_facts = None

# Generated at 2022-06-24 23:38:41.674324
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print('Testing collect of ApparmorFactCollector')
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:38:47.809226
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    abt_apparmor_fact_collector_1 = ApparmorFactCollector()
    result_1_dict = abt_apparmor_fact_collector_1.collect()

    assert result_1_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:38:48.325974
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:38:49.688517
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_1.collect(), dict)

# Generated at 2022-06-24 23:38:53.458189
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    print(apparmor_fact_collector_0.collect())

# Generated at 2022-06-24 23:38:55.026757
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect({}, {})

# Generated at 2022-06-24 23:38:57.011580
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collect_0 = ApparmorFactCollector()
    assert test_collect_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:38:58.506871
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    if apparmor_fact_collector_1.collect():
        assert False
    else:
        assert True

# Generated at 2022-06-24 23:39:00.038555
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_0.collect(None, collected_facts)
    assert collected_facts

# Generated at 2022-06-24 23:41:05.917846
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aa_fc = ApparmorFactCollector()
    aa_fc.collect()

# Generated at 2022-06-24 23:41:07.240420
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Test of return type
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:41:13.585498
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
#     print(var_0)
    print(var_0.get('_fact_ids'))
    print(var_0['apparmor'])
    for each in var_0:
        print(each, var_0.get(each))


# Generated at 2022-06-24 23:41:15.907052
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)
    return

# Generated at 2022-06-24 23:41:19.520122
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print("\n<td>Test method ApparmorFactCollector.collect()</td>")
    test_case_0()

# Generated at 2022-06-24 23:41:20.141038
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:41:23.787780
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_ = ApparmorFactCollector()
    var = apparmor_fact_collector_.collect(apparmor_fact_collector_)
    assert isinstance(var, dict)



# Generated at 2022-06-24 23:41:24.486090
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:41:25.985843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect(apparmor_fact_collector_0)

# Generated at 2022-06-24 23:41:29.897969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass
