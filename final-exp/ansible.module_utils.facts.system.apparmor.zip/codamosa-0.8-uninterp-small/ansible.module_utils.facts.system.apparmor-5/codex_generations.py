

# Generated at 2022-06-24 23:31:49.755438
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts = {}
    apparmor_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 23:31:54.085797
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()



# Generated at 2022-06-24 23:31:56.327977
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert 'apparmor' in facts_dict.keys()

# Generated at 2022-06-24 23:32:04.852389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    status = os.path.exists('/sys/kernel/security/apparmor')
    if status:
        assert apparmor_fact_collector.collect()['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'


if __name__ == "__main__":
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:32:11.050742
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # This call to collect has the side effect of inserting the apparmor
    # fact into the module's internal facts cache
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_0 = apparmor_fact_collector_0.collect()
    apparmor_fact_1 = apparmor_fact_collector_0.collect()
    assert apparmor_fact_0 == apparmor_fact_1

# Generated at 2022-06-24 23:32:13.302499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:14.178083
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:15.869561
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:32:25.019084
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # When apparmor is disabled in the system
    if os.path.exists('/sys/kernel/security/apparmor'):
        os.system('mv /sys/kernel/security/apparmor /sys/kernel/security/apparmor.bak')
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_1.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'
    if not os.path.exists('/sys/kernel/security/apparmor'):
        os.system('mv /sys/kernel/security/apparmor.bak /sys/kernel/security/apparmor')
    # When apparmor is enabled in the system

# Generated at 2022-06-24 23:32:29.399282
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    # Testing when '/sys/kernel/security/apparmor' is absent.
    os.path.exists = lambda path: False
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:34.203562
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:32:37.906224
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        status = 'enabled'
    else:
        status = 'disabled'

    apparmor_fact_collector_1 = ApparmorFactCollector().collect()
    assert(apparmor_fact_collector_1 == {'apparmor': {'status': status}})

# Generated at 2022-06-24 23:32:41.649236
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    result = apparmor_fact_collector_0.collect()
    assert result == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-24 23:32:44.052420
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    module = object()
    collected_facts = {}
    apparmor.collect(module, collected_facts)

# Generated at 2022-06-24 23:32:50.104209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_os_family'] = 'Debian'
    collected_facts_0['ansible_distribution_major_version'] = '8'
    collected_facts_0['ansible_facts'] = {'ansible_facts': {'ansible_os_family': 'Debian', 'ansible_distribution_major_version': '8'}}
    facts_dict_0 = {}
    apparmor_facts_0 = {}
    apparmor_facts_0['status'] = 'disabled'
    facts_dict_0['apparmor'] = apparmor_facts_0
    collected_facts_1 = {}
    collected_facts_1['ansible_os_family'] = 'RedHat'


# Generated at 2022-06-24 23:32:57.657280
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Call method collect of class ApparmorFactCollector with
    # arguments: module: None, collected_facts: None
    res_0 = ApparmorFactCollector.collect(None, None)

    # Test if result is a dict
    assert(type(res_0) == dict)

    # Test if dict has key apparmor
    assert('apparmor' in res_0)
    # Test if dict apparmor has key status
    assert('status' in res_0['apparmor'])
    # Test if dict apparmor has a value for key status
    assert(res_0['apparmor']['status'])

# Generated at 2022-06-24 23:32:59.519531
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = ApparmorFactCollector().collect()
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-24 23:33:02.600349
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-24 23:33:06.402177
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {
        'apparmor': {'status': 'disabled'},
    }


# Generated at 2022-06-24 23:33:07.414146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() is not None

# Generated at 2022-06-24 23:33:15.465620
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }


# Generated at 2022-06-24 23:33:18.492890
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:21.908878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict
    assert 'status' in facts_dict['apparmor']
    assert facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-24 23:33:24.812889
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_status = apparmor_fact_collector.collect()
    assert apparmor_status['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:33:30.882374
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collector_result = apparmor_fact_collector.collect()
    assert isinstance(collector_result, dict)
    assert len(collector_result) == 1
    assert apparmor_fact_collector.name in collector_result

# Generated at 2022-06-24 23:33:33.048570
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-24 23:33:35.412252
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    res_0 = apparmor_fact_collector_1.collect()
    assert type(res_0) == dict
    assert 'apparmor' in res_0

# Generated at 2022-06-24 23:33:38.911447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result = apparmor_fact_collector_1.collect()
    assert result['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:33:43.867879
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1_collect = {'apparmor': {'status': 'disabled'}}
    assert apparmor_fact_collector_1.collect() == apparmor_fact_collector_1_collect

# Generated at 2022-06-24 23:33:45.833567
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(module=None, collected_facts=None), dict)


# Generated at 2022-06-24 23:33:55.721529
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts_dict
    assert 'status' in apparmor_facts_dict['apparmor']
    assert apparmor_facts_dict['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-24 23:33:57.772008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    result = apparmor_fact_collector_collect.collect()
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:34:07.176056
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

# Generated at 2022-06-24 23:34:13.601873
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    os.path.exists = Mock(return_value=True)
    apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.collect()

    os.path.exists = Mock(return_value=False)
    apparmor_fact_collector_0.collect()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:16.466721
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result = apparmor_fact_collector_0.collect()
    assert type(result).__name__ == 'dict'
    assert result['apparmor']['status'] == 'disabled'



# Generated at 2022-06-24 23:34:18.336970
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    print("Test method collect of class ApparmorFactCollector:")
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:23.136154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    facts_dict = {}
    apparmor_facts_dict = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts_dict['status'] = 'enabled'
    else:
        apparmor_facts_dict['status'] = 'disabled'
    facts_dict['apparmor'] = apparmor_facts_dict
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:24.846676
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:27.699527
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}
# test_ApparmorFactCollector_collect ends here


# Generated at 2022-06-24 23:34:35.461347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mock data
    mock_collected_facts = 'mock_collected_facts'
    mock_collected_facts_value = {'apparmor': {'var_1': 'value_1', 'var_2': 'value_2'}}

    # Mock
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._collect = lambda x: mock_collected_facts_value
    mock_data = apparmor_fact_collector.collect(collected_facts=mock_collected_facts)

    # Assertions
    assert mock_data == mock_collected_facts_value

# Generated at 2022-06-24 23:34:48.849927
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:34:51.170054
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case = 0
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()



# Generated at 2022-06-24 23:34:54.339314
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create the class under test
    apparmor_fact_collector_0 = ApparmorFactCollector()

    # Invoke the collect method
    result = apparmor_fact_collector_0.collect()

    # Assert
    assert result['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:35:01.460239
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0._parse_conf_file = lambda _: {}
    apparmor_fact_collector_0._get_pkg_facts = lambda _: {}
    apparmor_fact_collector_0._get_apparmor_status = lambda _: {}
    apparmor_fact_collector_0._get_profiles = lambda _: {}
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:07.907333
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test case 0
    apparmor_fact_collector_0 = ApparmorFactCollector()
    result_0 = apparmor_fact_collector_0.collect()
    assert result_0['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-24 23:35:10.016416
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert 'apparmor' in apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:35:15.708876
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  test_case_0()

# Generated at 2022-06-24 23:35:16.663522
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:35:20.846242
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_collector_0 = ApparmorFactCollector()
    apparmor_facts_0 = apparmor_facts_collector_0.collect()
    assert apparmor_facts_0['apparmor']['status'] == 'enabled'



# Generated at 2022-06-24 23:35:23.345200
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:35:41.824497
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    try:
        var_1 = [None, None]
        var_2 = apparmor_fact_collector_0.collect(var_1[0], var_1[1])
    except Exception:
        var_3 = None
    else:
        var_3 = 'success'
    assert var_3 == 'success'


# Generated at 2022-06-24 23:35:43.441653
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:46.562231
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print("[+] Testing code in method 'collect' of class 'ApparmorFactCollector'")

    apparmor_fact_collector_var_0 = ApparmorFactCollector()
    apparmor_fact_collector_var_1 = apparmor_fact_collector_var_0.collect()
    apparmor_fact_collector_var_0.collect()


# Generated at 2022-06-24 23:35:48.813027
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:35:51.720469
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {
        'apparmor': {
            'status': 'enabled',
        },
    }


# Generated at 2022-06-24 23:35:54.804400
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1['apparmor']['status'] == 'disabled'


# Generated at 2022-06-24 23:35:59.645060
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    return_value_1 = apparmor_fact_collector_0.collect(collected_facts_0)

    assert {} == return_value_1

# Generated at 2022-06-24 23:36:06.965002
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    try:
        var_1 = apparmor_fact_collector_1.collect()
    except IOError as e:
        if e.errno == 13:
            print("Permission denied.")
        elif e.errno == 2:
            print("File not found.")
        elif e.errno == 21:
            print("Is a directory.")
        else:
            print(e)
            raise e

# Generated at 2022-06-24 23:36:09.866005
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'apparmor' in var_0


# Generated at 2022-06-24 23:36:15.690296
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()
    assert var_1 == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:36:44.272353
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:49.293952
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:36:54.543974
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module_path = os.path.dirname(__file__)
    mock_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    module = AnsibleModule(
        argument_spec=mock_module.argument_spec,
        supports_check_mode=False,
    )

    apparmor_fact_collector_obj = ApparmorFactCollector()

    # Unit tests for 'collect' method
    collected_facts = dict()
    result = apparmor_fact_collector_obj.collect(module, collected_facts)

    assert result is not None, "The collect method returned None"
    assert result == {'apparmor': {'status': 'enabled'}}, "The collect method returned an incorrect result"

# Generated at 2022-06-24 23:36:57.284948
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()



# Generated at 2022-06-24 23:36:59.685196
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    res = apparmor_fact_collector.collect()


# Generated at 2022-06-24 23:37:05.799422
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert os.path.exists('/sys/kernel/security/apparmor')
    fact_0 = apparmor_fact_collector_1.collect()
    assert 'apparmor' in fact_0
    assert fact_0['apparmor']['status'] == 'enabled'


# Generated at 2022-06-24 23:37:07.278986
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:37:11.251934
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()
    assert var['apparmor']['status'] not in ('disabled', 'enabled')

# Generated at 2022-06-24 23:37:15.727990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0 == {'ansible_facts': {'apparmor': {'status': 'disabled'}}, 'warnings': []}

# Generated at 2022-06-24 23:37:17.421753
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:38:09.385184
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {}

# Generated at 2022-06-24 23:38:10.330824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var = ApparmorFactCollector().collect()
    print(var)

# Generated at 2022-06-24 23:38:15.202656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:38:16.591144
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:38:26.387148
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    config_path = (os.path.join(os.path.expanduser('~'), '.ansible', 'facts.d'))

    os.makedirs(config_path)

    file_object = open(os.path.join(config_path, 'test_ansible_fact.fact'), 'w')
    file_object.write("""
    [test_ansible_fact]
    test_fact=enabled
    """)
    file_object.close()

    os.environ['ANSIBLE_LOCAL_TEMP'] = '/tmp/ansible_test'
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/tmp/ansible_test/ansible/collections'
    apparmor_fact_collector_collect = ApparmorFactCollector()

    assert apparmor_fact_collector

# Generated at 2022-06-24 23:38:27.985197
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:38:30.080706
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] == 'disabled'

# Generated at 2022-06-24 23:38:31.685278
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:38:32.926000
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    var = apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:38:33.900311
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var = ApparmorFactCollector()
    var.collect()


# Generated at 2022-06-24 23:40:30.537032
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    var = ApparmorFactCollector()
    var.collect()
    return True

# Generated at 2022-06-24 23:40:34.659826
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:40:37.120822
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import builtins
    builtins.t = True
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res_0 = apparmor_fact_collector_0.collect()
    assert not res_0

# vim: set expandtab shiftwidth=8 softtabstop=8:

# Generated at 2022-06-24 23:40:41.652980
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    var_1 = apparmor_fact_collector_0.name

    assert isinstance(var_0, dict)
    assert isinstance(var_1, str)

# Generated at 2022-06-24 23:40:42.034260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-24 23:40:44.094630
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_1 = apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:40:45.223119
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:40:48.439114
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert var_0['apparmor']['status'] in ('enabled', 'disabled')


# Generated at 2022-06-24 23:40:51.084261
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    var_0 = apparmor_fact_collector_0.collect()
    assert type(var_0) is dict

# Generated at 2022-06-24 23:40:51.630643
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test 0
    test_case_0()