

# Generated at 2022-06-24 23:31:56.057290
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    expected_apparmor_facts = {'apparmor': {'status': 'enabled'}}

    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_0.collect()
    assert apparmor_facts == expected_apparmor_facts


# Generated at 2022-06-24 23:31:58.916150
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:01.773999
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:03.675104
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() != [], 'ApparmorFactCollector collect() failed!'

# Generated at 2022-06-24 23:32:08.038739
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_collect = ApparmorFactCollector()
    assert 'apparmor' in apparmor_fact_collector_collect.collect()

# Generated at 2022-06-24 23:32:13.139836
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_2 = ApparmorFactCollector()
    result = apparmor_fact_collector_2.collect()
    assert type(result) == dict
    assert 'apparmor' in result.keys()
    assert 'status' in result['apparmor'].keys()
    assert type(result['apparmor']['status']) == str

# Generated at 2022-06-24 23:32:15.533047
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:32:16.971583
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:32:24.353551
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initializing classes and objects
    apparmor_fact_collector_0 = ApparmorFactCollector()
    module_0 = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(type='list'),
            gather_timeout = dict(type='int')
        )
    )
    collected_facts_0 = dict()
    # Set up mock

    # Testing
    test_return_0 = apparmor_fact_collector_0.collect(module_0, collected_facts_0)

    # Unit test for method get_fact_names of class ApparmorFactCollector

# Generated at 2022-06-24 23:32:26.984817
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    print(apparmor_fact_collector_0.collect())


# Generated at 2022-06-24 23:32:34.444890
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:36.281391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def test_case_0():
        apparmor_fact_collector_0 = ApparmorFactCollector()


# Generated at 2022-06-24 23:32:37.768392
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:41.727748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict_0 = {'apparmor': {'status': 'enabled'}}
    assert facts_dict_0 == apparmor_fact_collector_0.collect(collected_facts=None)

# Generated at 2022-06-24 23:32:43.350871
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect()

# Generated at 2022-06-24 23:32:44.844475
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert "apparmor" in apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:32:46.378402
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:32:51.382005
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    collected_facts_0 = {}
    apparmor_fact_collector_0.collect(collected_facts=collected_facts_0)


# Generated at 2022-06-24 23:32:56.417268
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    os.path.exists = lambda path: True
    ansible_facts_vars_0 = apparmor_fact_collector_0.collect()
    assert ansible_facts_vars_0['apparmor']['status'] == 'enabled'

# Generated at 2022-06-24 23:32:57.955193
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:10.707961
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {'status': 'disabled'}}

    apparmor_fact_collector_2 = ApparmorFactCollector()
    path_orig_0 = '/sys/kernel/security/apparmor'
    try:
        os.mkdir(path_orig_0)
        assert apparmor_fact_collector_2.collect() == {'apparmor': {'status': 'enabled'}}
    finally:
        os.rmdir(path_orig_0)

# Generated at 2022-06-24 23:33:15.208601
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0, ApparmorFactCollector)
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:33:16.585825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:21.149582
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a ApparmorFactCollector object
    apparmor_fact_collector_1 = ApparmorFactCollector()

    # Check if the collect method returns a dict
    assert isinstance(apparmor_fact_collector_1.collect(), dict)


# Generated at 2022-06-24 23:33:24.953544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()

    apparmor_fact_collector_1.collect()

    assert isinstance(apparmor_fact_collector_1.collect(), dict) is True



# Generated at 2022-06-24 23:33:30.288101
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_return = apparmor_fact_collector.collect()
    assert apparmor_fact_collector_return is not None



# Generated at 2022-06-24 23:33:33.365743
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.facts = {}
    apparmor_fact_collector_0.collect()
    assert ('apparmor' in apparmor_fact_collector_0.facts)

# Generated at 2022-06-24 23:33:34.987872
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector_0 = ApparmorFactCollector()

    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:33:38.867981
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:33:42.591541
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    result_1 = apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:33:57.870790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector_1 = apparmor_fact_collector.collect()
    expected_apparmor_fact_collector_1 = {'apparmor': {'status': None}}
    assert (apparmor_fact_collector_1 == expected_apparmor_fact_collector_1)

# Generated at 2022-06-24 23:34:00.800324
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:03.065903
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts is not None

# Generated at 2022-06-24 23:34:08.204241
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    sys_kernel_security_apparmor_file_path = "/sys/kernel/security/apparmor"
    sys_kernel_security_apparmor_file_descriptor = open(sys_kernel_security_apparmor_file_path)
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()
    sys_kernel_security_apparmor_file = sys_kernel_security_apparmor_file_descriptor.readlines()
    sys_kernel_security_apparmor_file_descriptor.close()

# Generated at 2022-06-24 23:34:13.264459
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Based on https://github.com/ansible/ansible/blob/stable-2.9/lib/ansible/module_utils/facts/system/apparmor.py


# Generated at 2022-06-24 23:34:15.824835
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res = apparmor_fact_collector_0.collect()
    assert res is not None

# Generated at 2022-06-24 23:34:17.141048
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-24 23:34:19.408389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    ret = apparmor_fact_collector.collect()
    expected = {'apparmor': {'status': 'disabled'}}
    assert(ret == expected)



# Generated at 2022-06-24 23:34:24.509431
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}, \
        'apparmor_fact_collector_0.collect() == {\'apparmor\': {\'status\': \'disabled\'}}'


# Generated at 2022-06-24 23:34:26.058154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()


# Generated at 2022-06-24 23:34:50.662200
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:34:56.817267
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initialization
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_2 = ApparmorFactCollector()
    apparmor_fact_collector_1.name = 'apparmor_0'
    apparmor_fact_collector_2.name = 'apparmor_0'

    # Test case true
    assert apparmor_fact_collector_0.collect() == apparmor_fact_collector_1.collect()
    assert not apparmor_fact_collector_0.collect() == apparmor_fact_collector_2.collect()
    return 0


# Generated at 2022-06-24 23:34:58.191495
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None


# Generated at 2022-06-24 23:35:02.379513
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    ansible_module = AnsibleModule({})
    ansible_module.exit_json = lambda x: print(x)
    apparmor_fact_collector_0.collect(ansible_module)

if __name__ == '__main__':
    test_case_0()
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:35:07.545513
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect()
    assert facts_dict == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-24 23:35:08.800994
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:35:11.236532
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector_0.collect({})
    assert facts_dict == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-24 23:35:16.958723
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if not os.path.exists('/sys/kernel/security/apparmor'):
        os.makedirs('/sys/kernel/security/apparmor')
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector_1.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-24 23:35:20.112790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {}


# Generated at 2022-06-24 23:35:24.641452
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    apparmor_fact_collector_1.collect()

# Generated at 2022-06-24 23:36:13.942033
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:36:15.644030
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

test_case_0()
test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:36:17.432385
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()

    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:36:21.195313
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:36:24.805985
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = dict()
    result = apparmor_fact_collector.collect(collected_facts)
    assert 'apparmor' in result

# Generated at 2022-06-24 23:36:28.101187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    x = apparmor_fact_collector_0.collect()
    assert x == {
        'apparmor': {
            'status': 'enabled',
        }
    }

# Generated at 2022-06-24 23:36:30.991753
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:36:33.633522
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector() 
    test_class = apparmor_fact_collector_0.collect()

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-24 23:36:34.855512
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    ApparmorFactCollector.collect(module='raw_input')

# Generated at 2022-06-24 23:36:36.695898
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_1 = ApparmorFactCollector()
    assert apparmor_fact_collector_1.collect() == {'apparmor': {}}

# Generated at 2022-06-24 23:38:33.995868
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    res = apparmor_fact_collector_0.collect()
    assert res.get('apparmor') == {'status': 'disabled'}

# Generated at 2022-06-24 23:38:35.535956
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:38:37.281588
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    results = apparmor_fact_collector.collect()
    assert 'apparmor' in results.keys()

# Generated at 2022-06-24 23:38:38.667953
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()


# Generated at 2022-06-24 23:38:40.181106
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:38:43.853450
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_1 = ApparmorFactCollector()

    result = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        result['status'] = 'enabled'
    else:
        result['status'] = 'disabled'

    assert apparmor_fact_collector_0.collect() == { 'apparmor': result }
    assert apparmor_fact_collector_1.collect() == { 'apparmor': result }

# Generated at 2022-06-24 23:38:47.349835
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collect = ApparmorFactCollector().collect()
    assert test_collect == dict(apparmor=dict(status='enabled')
)

# Generated at 2022-06-24 23:38:52.113741
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    assert apparmor_fact_collector_0.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-24 23:38:53.237667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_0 = ApparmorFactCollector()
    apparmor_fact_collector_0.collect()

# Generated at 2022-06-24 23:38:59.581713
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts = os.listdir('/sys/kernel/security/apparmor')
        apparmor_fact_collector = ApparmorFactCollector()
        apparmor_fact_collector_output = apparmor_fact_collector.collect()
        assert 'apparmor' not in apparmor_fact_collector_output
        apparmor_fact_collector_output = apparmor_fact_collector.collect()
        for i in apparmor_facts:
            assert i in apparmor_fact_collector_output['apparmor']
        assert 'status' not in apparmor_fact_collector_output['apparmor']
    else:
        apparmor_fact_collector = ApparmorFactCollector()
        apparmor_fact_collector_