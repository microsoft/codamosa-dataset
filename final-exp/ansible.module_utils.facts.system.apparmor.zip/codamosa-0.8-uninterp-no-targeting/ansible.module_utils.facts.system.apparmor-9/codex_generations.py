

# Generated at 2022-06-20 18:51:04.368419
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:07.364782
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:51:13.354086
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector(None)

    def test_collect():
        a_facts = apparmor.collect()
        a_status = a_facts['apparmor']['status']
        assert type(a_status) is str, 'Returned apparmor status is not a string'

    test_collect()

# Generated at 2022-06-20 18:51:20.433047
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert(apparmor_facts['apparmor']['status'] == 'disabled')
    # create the /sys/kernel/security/apparmor and assert it is enabled
    os.makedirs('/sys/kernel/security/apparmor')
    apparmor_facts = apparmor_collector.collect()
    assert(apparmor_facts['apparmor']['status'] == 'enabled')

# Generated at 2022-06-20 18:51:23.003937
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:51:27.748244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create an instance of the ApparmorFactCollector class
    apparmor_collector_obj = ApparmorFactCollector()
    # call the method collect of the ApparmorFactCollector class with a valid path
    status = apparmor_collector_obj.collect(module=None, collected_facts=None)
    assert status['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:51:28.848872
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:51:29.782473
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:51:31.635766
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert len(ApparmorFactCollector._fact_ids) == 0


# Generated at 2022-06-20 18:51:33.673440
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfactcollector = ApparmorFactCollector()
    assert apparmorfactcollector.name == 'apparmor'
    assert apparmorfactcollector._fact_ids == set()


# Generated at 2022-06-20 18:51:38.553974
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()


# Generated at 2022-06-20 18:51:44.259726
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.facts.collector import Collector
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, Collector)
    assert apparmor_fact_collector.name == 'apparmor'
    return


# Generated at 2022-06-20 18:51:53.159115
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()

    # bad apparmor status
    os.environ['ANSIBLE_APPARMOR_STATUS'] = 'foo'
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert len(afc._fact_ids) == 2
    assert afc._fact_ids == set(['apparmor', 'apparmor_status'])
    os.environ['ANSIBLE_APPARMOR_STATUS'] = None

# Generated at 2022-06-20 18:52:00.744994
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector

    # Create the collector instance
    collector = ApparmorFactCollector()
    # Check the facts dictionary
    facts = Facts()
    collector.collect(module=None, collected_facts=facts)
    assert facts is not None
    apparmor_facts = facts.get('apparmor')
    assert apparmor_facts is not None
    assert apparmor_facts['status'] == 'disabled'

# Generated at 2022-06-20 18:52:01.902381
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'

# Generated at 2022-06-20 18:52:03.642005
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-20 18:52:07.709178
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    A = ApparmorFactCollector()
    assert A.name == 'apparmor'
    assert A._fact_ids == set()


# Generated at 2022-06-20 18:52:10.325523
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['apparmor']

# Generated at 2022-06-20 18:52:11.256265
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-20 18:52:13.983571
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:23.394642
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == "apparmor"
    assert set(apparmor_facts._fact_ids) == set()

# Generated at 2022-06-20 18:52:24.836512
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactColl = ApparmorFactCollector()
    apparmorFactColl.collect()

# Generated at 2022-06-20 18:52:27.225976
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c.collect()['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-20 18:52:29.846920
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:52:31.873177
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector._fact_ids == set()
    assert fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:52:35.890193
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_module = ApparmorFactCollector()
    result = fact_module.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:37.984501
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect()
    assert result.get('apparmor') is not None

# Generated at 2022-06-20 18:52:40.485298
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = {}
    assert apparmor_fact_collector.collect(collected_facts=facts) == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:41.974025
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {u'status': u'disabled'}}

# Generated at 2022-06-20 18:52:44.010460
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = type('module', (), {})
    apparmor = ApparmorFactCollector(module)
    assert apparmor.name == 'apparmor'

# Generated at 2022-06-20 18:53:03.149528
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert type(facts) is dict
    assert 'apparmor' in facts
    assert type(facts['apparmor']) is dict
    assert 'status' in facts['apparmor']
    assert os.path.exists('/sys/kernel/security/apparmor') and facts['apparmor']['status'] == 'enabled' or not os.path.exists('/sys/kernel/security/apparmor') and facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:06.303501
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorCollector = ApparmorFactCollector()
    assert apparmorCollector.name == 'apparmor'
    assert isinstance(apparmorCollector._fact_ids, set)


# Generated at 2022-06-20 18:53:10.908746
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    # apparmor path exists
    apparmor_collector.file_exists = lambda path: True
    assert apparmor_collector.collect() == {'apparmor': {'status': 'enabled'}}
    # apparmor path does not exist
    apparmor_collector.file_exists = lambda path: False
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:15.910146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        status = 'enabled'
    else:
        status = 'disabled'

    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status'] == status

# Generated at 2022-06-20 18:53:17.670504
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFact = ApparmorFactCollector()
    assert apparmorFact.name == 'apparmor'

# Generated at 2022-06-20 18:53:21.000220
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert type(a._fact_ids) == set


# Generated at 2022-06-20 18:53:30.818832
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test if method collect of ApparmorFactCollector
    gets the content of the file correctly
    """
    success_text = 'success'

    class MockFile():
        def __init__(self, content):
            self.content = content

        def readline(self):
            return self.content

        def seek(self, position):
            pass

    # File does not exists
    file_handle = '/sys/kernel/security/apparmor'
    if os.path.isfile(file_handle):
        os.remove(file_handle)
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}
    # File exists

# Generated at 2022-06-20 18:53:33.422744
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'

# Generated at 2022-06-20 18:53:35.509941
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:53:39.013857
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    mock_module = MockModule()
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect(module=mock_module, collected_facts=None)


# Generated at 2022-06-20 18:54:05.086962
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:54:08.931565
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    expected_output = {'apparmor': {
        'status': 'enabled'
    }}
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()
    assert aafc.collect() == expected_output

# Generated at 2022-06-20 18:54:09.997611
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Implement test constructor
    ApparmorFactCollector()

# Generated at 2022-06-20 18:54:11.338044
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert type(ApparmorFactCollector()) == ApparmorFactCollector

# Generated at 2022-06-20 18:54:14.076843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_collect = ApparmorFactCollector()
    ApparmorFactCollector_collect.collect()
    assert ApparmorFactCollector_collect.collect() == None

# Generated at 2022-06-20 18:54:16.638474
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert len(apparmor_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 18:54:23.274383
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_factcollector = ApparmorFactCollector()
    
    # Assert the class type
    assert(isinstance(apparmor_factcollector, ApparmorFactCollector))
    assert(isinstance(apparmor_factcollector, BaseFactCollector))

    # Check the collected facts from __init__ method
    assert(apparmor_factcollector._fact_ids == set())
    
    # Check the collected facts from collect method
    assert(isinstance(apparmor_factcollector.collect(), dict))
    
    # Check the apparmor status key
    assert('apparmor' in apparmor_factcollector.collect())
    assert('status' in apparmor_factcollector.collect()['apparmor'])
    
    # Check the apparmor status value

# Generated at 2022-06-20 18:54:24.347693
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector._fact_ids == set([])

# Generated at 2022-06-20 18:54:26.143784
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == "apparmor"

# Generated at 2022-06-20 18:54:29.090460
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = ApparmorFactCollector().collect()

    assert 'apparmor' in facts
    apparmor = facts['apparmor']
    assert 'status' in apparmor

# Generated at 2022-06-20 18:55:18.911500
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().collect()['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:55:19.900990
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
   x = ApparmorFactCollector()


# Generated at 2022-06-20 18:55:23.202248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:55:23.832183
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector

# Generated at 2022-06-20 18:55:27.569882
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector('/tmp')
    apparmor_facts = apparmor_fact_collector.collect()

    assert isinstance(apparmor_facts, dict)
    assert isinstance(apparmor_facts['apparmor'], dict)

# Generated at 2022-06-20 18:55:38.088889
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of ApparmorFactCollector
    apparmor_fc = ApparmorFactCollector()

    # Create a mock "module" and "collected_facts" objects
    collected_facts = {}

    # Call method collect of class ApparmorFactCollector with the mock objects
    apparmor_fc.collect(collected_facts = collected_facts)

    # Check that method collect of class ApparmorFactCollector returns "enabled" when the apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert collected_facts['apparmor']['status'] == 'enabled'

    # Check that method collect of class ApparmorFactCollector returns "disabled" when the apparmor is disabled

# Generated at 2022-06-20 18:55:39.791901
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert len(obj.collect()) == 1

# Generated at 2022-06-20 18:55:44.551678
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # Execute
    apparmor_facts = apparmor_fact_collector.collect()

    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:55:45.761439
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorCollector = ApparmorFactCollector()
    apparmorCollector.collect()

# Generated at 2022-06-20 18:55:47.538181
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert (ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-20 18:56:43.629716
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aa_fc = ApparmorFactCollector()
    aa_fc._module = ''
    aa_fc._collect()


# Generated at 2022-06-20 18:56:44.138008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:56:48.251998
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    try:
        f = ApparmorFactCollector()
    except RuntimeError as e:
        print(e)
    assert f.name == "apparmor"
    assert f._fact_ids == set()

# Generated at 2022-06-20 18:56:49.564667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:56:58.048968
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert isinstance(apparmor_collector, BaseFactCollector)

    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts = apparmor_collector.collect(None, None)
        assert apparmor_facts['apparmor']['status'] == 'enabled'
    else:
        apparmor_facts = apparmor_collector.collect(None, None)
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:57:02.492619
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmorFactCollector.collect()['apparmor']['status'] == 'enabled'
    else:
        assert apparmorFactCollector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:57:05.448295
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:57:08.959907
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


#test_collect and test_collect_empty are called by unit test

# Generated at 2022-06-20 18:57:12.037719
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_status = {
        'status': 'enabled' if os.path.exists('/sys/kernel/security/apparmor') else 'disabled'
    }
    aafc = ApparmorFactCollector()
    assert aafc.collect()['apparmor'] == apparmor_status

# Generated at 2022-06-20 18:57:13.388715
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_collector = ApparmorFactCollector()
    assert test_collector.name == 'apparmor'

# Generated at 2022-06-20 18:59:20.025329
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_obj = ApparmorFactCollector()
    facts_dict = test_obj.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-20 18:59:22.575215
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:59:24.765610
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-20 18:59:26.545218
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector, object)

# Generated at 2022-06-20 18:59:30.846937
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:59:32.327804
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector(module=None)
    assert apparmor.collect()['apparmor'].get('status') in ('enabled', 'disabled')

# Generated at 2022-06-20 18:59:35.439538
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:59:39.544891
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:59:41.449369
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:59:45.269041
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}
