

# Generated at 2022-06-20 18:51:04.538493
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-20 18:51:05.090866
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert True

# Generated at 2022-06-20 18:51:06.571766
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    d = ApparmorFactCollector()
    assert d.name == 'apparmor'

# Generated at 2022-06-20 18:51:09.383558
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:51:11.070555
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    obj = ApparmorFactCollector()
    obj.collect()

# Generated at 2022-06-20 18:51:18.200415
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import tempfile

    tdir = tempfile.mkdtemp()

    fd = os.open('/sys/kernel/security/apparmor', os.O_RDONLY)
    assert fd
    os.close(fd)

    assert 'apparmor' not in ApparmorFactCollector().collect()
    assert 'apparmor' in ApparmorFactCollector().collect({'kernel_name': 'Linux', 'kernel_release': '4.1.0-14-generic', 'system': 'Linux'})

# Generated at 2022-06-20 18:51:19.866318
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:51:24.507340
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class Collector(object):
        def __init__(self, module=None, collected_facts=None):
            pass

    module = Collector()
    collected_facts = Collector()

    collector = ApparmorFactCollector()

    assert isinstance(collector.collect(module, collected_facts), dict)

# Generated at 2022-06-20 18:51:27.319558
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert type(a) == ApparmorFactCollector
    assert a.name == 'apparmor'
    assert len(a._fact_ids) == 0


# Generated at 2022-06-20 18:51:28.227371
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()

# Generated at 2022-06-20 18:51:30.383839
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:51:31.872230
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test constructor
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:51:33.985181
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector=ApparmorFactCollector()
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:40.154132
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector._module = {}
    apparmorFactCollector._module["params"] = {}
    apparmorFactCollector._module["params"]["gather_subset"] = ["network"]

    ansibleExecResult = {}
    ansibleExecResult["stdout"] = ""
    ansibleExecResult["stderr"] = ""
    apparmorFactCollector._module["run_command"] = MagicMock(return_value=ansibleExecResult)

    result = apparmorFactCollector.collect()

    expected = {"apparmor": {"status": "disabled"}}
    assertEqual(result, expected)

# Generated at 2022-06-20 18:51:43.633468
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Unit tests for collect method of class ApparmorFactCollector

# Generated at 2022-06-20 18:51:46.964679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aa = ApparmorFactCollector()
    result = aa.collect()
    assert type(result) is dict
    assert 'apparmor' in result
    assert type(result['apparmor']) is dict

# Generated at 2022-06-20 18:51:48.300321
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact = ApparmorFactCollector()
    assert fact.name == 'apparmor'

# Generated at 2022-06-20 18:51:54.588467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    collected_facts = {}
    collected_facts = fact_collector.collect(collected_facts=collected_facts)
    # Test for apparmor facts
    assert 'apparmor' in collected_facts
    assert 'status' in collected_facts['apparmor']
    assert (collected_facts['apparmor']['status'] == 
            'enabled' or collected_facts['apparmor']['status'] == 'disabled')

# Generated at 2022-06-20 18:51:57.481400
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect({}, {})
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:00.243509
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:52:07.298820
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert isinstance(apparmor_facts, dict)
    assert apparmor_facts['apparmor']

# Generated at 2022-06-20 18:52:09.344534
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert type(c) == ApparmorFactCollector

# Generated at 2022-06-20 18:52:11.501740
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']

# Generated at 2022-06-20 18:52:14.505346
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' in apparmor_fact_collector._fact_ids
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:52:17.694936
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert not apparmor_collector._fact_ids


# Generated at 2022-06-20 18:52:19.877517
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collect = ApparmorFactCollector()
    assert apparmor_fact_collect.name == 'apparmor'


# Generated at 2022-06-20 18:52:23.530781
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:52:24.748783
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert not ApparmorFactCollector().collect()


# Generated at 2022-06-20 18:52:27.142478
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    import json
    print(json.dumps(c.collect()))

test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:52:30.408274
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFC = ApparmorFactCollector()
    apparmor_facts = apparmorFC.collect()
    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:38.898882
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    facts_dict = Collector().collect(module=None, collected_facts=None)
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:45.990916
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fixture_data = {
        'collector': {
            'name': 'apparmor',
            '_fact_ids': set(),
        },
        'facts_dict': {
            'apparmor': {
            }
        }
    }

    apparmor_collector = ApparmorFactCollector()

    apparmor_only_disabled = apparmor_collector.collect(collected_facts=None)

    assert fixture_data['collector']['name'] == apparmor_only_disabled['collector']['name']
    assert fixture_data['collector']['_fact_ids'] == apparmor_only_disabled['collector']['_fact_ids']

# Generated at 2022-06-20 18:52:48.326743
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    assert a.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:50.289950
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfact_collector = ApparmorFactCollector

    assert apparmorfact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:52:52.372447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    assert isinstance(apparmorFactCollector.collect(), dict)


# Generated at 2022-06-20 18:52:54.868408
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:52:57.027887
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:53:02.070513
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def module_mock(value):
        if value == "/sys/kernel/security/apparmor":
            return True
        else:
            return False

    test_class = ApparmorFactCollector()
    res = test_class._collect(module_mock)
    assert res['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:53:03.197709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-20 18:53:11.450173
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import json

    file_path = os.path.dirname(os.path.abspath(__file__))
    apparmor_already_enabled_output = json.loads(open(file_path + '/test_data/apparmor_already_enabled_output.json', 'r').read())
    apparmor_already_disabled_output = json.loads(open(file_path + '/test_data/apparmor_already_disabled_output.json', 'r').read())
    apparmor_already_otherapparmor_output = json.loads(open(file_path + '/test_data/apparmor_already_otherapparmor_output.json', 'r').read())

# Generated at 2022-06-20 18:53:23.831355
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:26.917195
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-20 18:53:29.179216
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Tests the constructor and verify if the values are being set correctly
    """
    apparmorfact = ApparmorFactCollector()
    assert apparmorfact.name == 'apparmor'
    assert isinstance(apparmorfact._fact_ids, set)

# Generated at 2022-06-20 18:53:32.147849
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    results = apparmor_collector.collect()
    assert results != None
    assert results['apparmor'] != None

# Generated at 2022-06-20 18:53:38.852327
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    apparmor_path = '/sys/kernel/security/apparmor'
    apparmor_facts = {'status': 'enabled'}

    if os.path.exists(apparmor_path):
        assert apparmor_fact_collector.collect()['apparmor'] == apparmor_facts
    else:
        assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:42.287562
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_fact._module = 'ansible.module_utils.facts.collectors.apparmor'
    assert apparmor_fact.collect() != {}

# Generated at 2022-06-20 18:53:44.652948
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids is not None


# Generated at 2022-06-20 18:53:46.361615
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-20 18:53:53.115402
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collector = ApparmorFactCollector() 
    test_mock_facts = {}
    test_mock_module = {}
    test_result = test_collector.collect(module=test_mock_module, collected_facts=test_mock_facts) 
    assert test_result is None or isinstance(test_result, dict)

# Generated at 2022-06-20 18:53:54.649496
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    aafc.collect()

# Generated at 2022-06-20 18:54:29.960647
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # mocking class
    class MockModule(object):
        def __init__(self):
            self.params = {}

    # mocking os.path.exists
    import __builtin__ as builtins
    original_exists = builtins.__dict__['exists']
    builtins.__dict__['exists'] = lambda path: path.startswith('/sys/kernel/security/apparmor')

    # gets an instance of ApparmorFactCollector
    apparmor_collector = ApparmorFactCollector()

    # gets facts
    facts = apparmor_collector.collect(MockModule())

    # restores os.path.exists
    builtins.__dict__['exists'] = original_exists

    # tests facts
    assert 'apparmor' in facts
    assert type(facts['apparmor']) == dict


# Generated at 2022-06-20 18:54:32.126878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfactcollector_obj = ApparmorFactCollector()
    assert apparmorfactcollector_obj.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:34.782158
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect() == {'apparmor': {'status': 'enabled'}}

# Test if default method of class BaseFactCollector returns the expected result

# Generated at 2022-06-20 18:54:43.259718
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Unit test for when apparmor is disabled
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.path = os.path
            self.fail_json = lambda self, msg: self

    class DummyFacts(dict):
        def __init__(self):
            pass

        def __setitem__(self, key, value):
            pass

    facts = DummyFacts()
    module = DummyModule()
    apparmor_path = '/'

# Generated at 2022-06-20 18:54:45.941463
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj_apparmor = ApparmorFactCollector()
    assert obj_apparmor != None
    assert obj_apparmor.name == 'apparmor'
    assert obj_apparmor._fact_ids == set()


# Generated at 2022-06-20 18:54:49.076723
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    if afc is not None:
        assert afc.name == ApparmorFactCollector.name

# Generated at 2022-06-20 18:54:57.735205
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a class instance
    apparmor_class_instance = ApparmorFactCollector()

    # Run method with filesystem containing /sys/kernel/security/apparmor
    apparmor_class_instance.collect()

    # Verify result
    assert apparmor_class_instance.collect() == {'apparmor': {'status': 'enabled'}}

    # Run method with filesystem not containing /sys/kernel/security/apparmor
    apparmor_class_instance.collect(collected_facts=None)

    # Verify result
    assert apparmor_class_instance.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:59.291353
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert ('apparmor' in facts)

# Generated at 2022-06-20 18:55:02.464609
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'
    assert isinstance(ApparmorFactCollector()._fact_ids, set) and len(ApparmorFactCollector()._fact_ids) == 0


# Generated at 2022-06-20 18:55:06.353297
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    f = ApparmorFactCollector()
    c = Collector(f)
    c.collect()
    assert c.collected_facts

# Generated at 2022-06-20 18:56:07.323351
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-20 18:56:10.277538
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"
    assert obj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:56:12.327797
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect(None, None) == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-20 18:56:15.101051
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:56:18.334964
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector._fact_ids.add('apparmor')
    afc = ApparmorFactCollector()
    result = afc.collect()
    assert 'apparmor' in result.keys()
    assert len(result['apparmor']) > 0

# Generated at 2022-06-20 18:56:19.976178
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x=ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert type(x._fact_ids) == set


# Generated at 2022-06-20 18:56:24.818957
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # create instance of ApparmorFactCollector
    apparmor_fc = ApparmorFactCollector()

    # test collect method
    fact_data = apparmor_fc.collect()

    # assert data returned by collect method
    assert fact_data['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:56:28.382958
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_instance = ApparmorFactCollector()
    apparmor_facts = class_instance.collect()
    assert 'apparmor' in apparmor_facts
    assert isinstance(apparmor_facts['apparmor'], dict)

# Generated at 2022-06-20 18:56:30.204280
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'


# Generated at 2022-06-20 18:56:33.003154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()
    assert ac.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:58:50.003489
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()

    # Test for return value when apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert fact_collector.collect()['apparmor']['status'] == 'enabled'

    # Test for return value when apparmor is disabled
    if not os.path.exists('/sys/kernel/security/apparmor'):
        assert fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:51.004105
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:58:53.123323
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(ApparmorFactCollector().collect() == {'apparmor' : {'status': 'disabled'}})

# Generated at 2022-06-20 18:58:57.092341
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    if os.path.exists('/sys/kernel/security/apparmor'):
        expected = {'apparmor': {'status': 'enabled'}}
    else:
        expected = {'apparmor': {'status': 'disabled'}}

    assert apparmor_fact_collector.collect() == expected

# Generated at 2022-06-20 18:58:58.937909
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_instance = ApparmorFactCollector()
    assert test_instance.name == 'apparmor'
    assert test_instance._fact_ids == set()


# Generated at 2022-06-20 18:59:02.009314
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    results = collector.collect()
    assert('apparmor' in results)
    assert('status' in results['apparmor'])

# Generated at 2022-06-20 18:59:05.263976
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    # we can't test this until we mock out /sys
    #assert 'apparmor' in c.collect().keys()

# Generated at 2022-06-20 18:59:09.810429
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:59:14.223716
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()
    assert apparmor_fact_collector.collect() == {}

# Generated at 2022-06-20 18:59:19.183605
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector('/sys/kernel/security/apparmor', {})
    assert instance.module is None
    assert instance.name == 'apparmor'
    assert instance.collected_facts == {}
