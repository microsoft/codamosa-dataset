

# Generated at 2022-06-20 18:51:09.962985
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Test collect method of class ApparmorFactCollector
    '''
    from ansible.module_utils.facts.collectors.system import ApparmorFactCollector

    apparmor_fact_collector = ApparmorFactCollector()
    assert True == apparmor_fact_collector.collect()['apparmor']['status']

# Generated at 2022-06-20 18:51:13.225325
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ap = ApparmorFactCollector()
    assert ap
    assert ap.name == 'apparmor'
    assert ap._fact_ids == set()


# Generated at 2022-06-20 18:51:16.121265
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    apparmor_facts = aafc.collect()
    assert 'apparmor' in apparmor_facts.keys()
    assert 'status' in apparmor_facts['apparmor'].keys()

# Generated at 2022-06-20 18:51:27.498656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts import ansible_collector
    import os

    ansible_collector._COLLECTOR = Collector()
    # Test a path that exists
    ansible_collector.add_collector(ApparmorFactCollector())
    assert {'apparmor': {'status': 'enabled'}} == ansible_collector.collect()

    # Test a path that does not exist
    old_path = ansible_collector._COLLECTOR.collectors[0].get_file_path
    ansible_collector._COLLECTOR.collectors[0].get_file_path = lambda: "/invalid/path"
    assert {'apparmor': {'status': 'disabled'}} == ansible_collector.collect()
    ansible_collector._

# Generated at 2022-06-20 18:51:29.614952
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert len(obj._fact_ids) == 0


# Generated at 2022-06-20 18:51:32.731250
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    collected_facts = {}
    collected_facts['cmdline'] = {'APPARMOR': 'enabled'}
    expected_facts = {'apparmor': {'status': 'enabled'}}
    assert fact_collector.collect(collected_facts=collected_facts) == expected_facts


# Generated at 2022-06-20 18:51:34.219142
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"
    assert obj.collect() == {}

# Generated at 2022-06-20 18:51:36.164504
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:51:46.685118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    posix.ApparmorFactCollector.collect -- return kernel apparmor status
    """
    # Create an instance of the TestableApparmorFactCollector
    Apparmor = TestableApparmorFactCollector()

    # Test the return value of method collect of class ApparmorFactCollector with
    # apparmor enabled.
    # Tested function is:
    #    ansible.module_utils.facts.collector.BaseFactCollector.collect
    #
    # The test expects method collect to return a valid apparmor
    # dictionary, if the kernel is apparmor enabled.
    # An apparmor dictionary is expected to have a key 'apparmor'.
    #
    # The value of key 'apparmor' of the dictionary is expected to be a
    # dictionary that contains a key 'status'.
    # The value of key 'status' is expected to

# Generated at 2022-06-20 18:51:50.431308
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:57.092561
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = __import__('ansible.module_utils.facts.collector', fromlist=('ApparmorFactCollector',))
    obj_class = getattr(module, 'ApparmorFactCollector')
    instance = obj_class()
    assert instance

# Generated at 2022-06-20 18:51:59.264040
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-20 18:52:00.438394
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name is not None
    assert apparmor._fact_ids is not None

# Generated at 2022-06-20 18:52:01.941617
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    assert c.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:52:02.662430
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:52:03.797683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
	apparmor_collector = ApparmorFactCollector()
	apparmor_collector.collect()

# Generated at 2022-06-20 18:52:10.369837
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Test collect method of class ApparmorFactCollector """
    from ansible.module_utils.facts import collector

    # Instantiating class ApparmorFactCollector
    aafc = ApparmorFactCollector()

    # Collecting facts
    collected_facts = aafc.collect(module=None, collected_facts=None)
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:11.740105
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()


# Generated at 2022-06-20 18:52:13.898245
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:52:16.355627
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:52:24.836358
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector is not None

# Generated at 2022-06-20 18:52:28.631831
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    ansible_facts = collector.collect()
    assert 'apparmor' in ansible_facts
    assert 'status' in ansible_facts['apparmor']

# Generated at 2022-06-20 18:52:32.474319
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert os.path.exists('/sys/kernel/security/apparmor') is True
    result = apparmor_fact_collector.collect(collected_facts={})
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:52:33.434651
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:52:40.167680
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test that the collect method of ApparmorFactCollector returns an
    expected dictionary when called without arguments.
    """
    collector = ApparmorFactCollector()
    expected_dict = {
        'apparmor': {
            'status': 'disabled',
        }
    }
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_dict['apparmor']['status'] = 'enabled'
    assert collector.collect() == expected_dict

# Generated at 2022-06-20 18:52:41.364398
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()

    # check instance variable assigned values to apparmor
    assert (collector.name == 'apparmor')

# Generated at 2022-06-20 18:52:42.597908
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:52:43.157777
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:46.783069
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_apparmor_facts = ApparmorFactCollector()
    assert test_apparmor_facts.name == 'apparmor'
    assert test_apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:47.426942
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  assert True

# Generated at 2022-06-20 18:53:04.357790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import shutil
    import tempfile
    import pytest

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a dummy file in the temporary directory
    os.mknod(os.path.join(temp_dir, "apparmor"))

    try:
        # Create an instance of the ApparmorFactCollector class
        apparmor_fact_collector = ApparmorFactCollector()
        # Call method collect of the ApparmorFactCollector class
        ansible_facts = apparmor_fact_collector.collect()

        assert ansible_facts['apparmor']['status'] == 'enabled'
    finally:
        # Remove the temporary directory and everything contained
        # in it
        shutil.rmtree(temp_dir)

# Generated at 2022-06-20 18:53:06.092942
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector =  ApparmorFactCollector()
    assert apparmor_fact_collector is not None

# Generated at 2022-06-20 18:53:07.368433
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  apparmorFactCollector = ApparmorFactCollector()
  assert apparmorFactCollector._fact_ids == set()
  assert apparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-20 18:53:10.976906
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfactCollector = ApparmorFactCollector()
    assert apparmorfactCollector.name == 'apparmor'
    assert apparmorfactCollector._fact_ids == set()

# Unit test collect function

# Generated at 2022-06-20 18:53:13.150008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert os.path.exists('/sys/kernel/security/apparmor') == True

# Generated at 2022-06-20 18:53:17.333870
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert isinstance(apparmor_collector, ApparmorFactCollector)
    assert not apparmor_collector._fact_ids


# Generated at 2022-06-20 18:53:23.174337
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with apparmor disabled
    del os.environ['__ansible_test_apparmor_status']
    apparmor_facts = ApparmorFactCollector.collect()

    assert apparmor_facts == {'apparmor': {'status': 'disabled'}}

    # Test with apparmor enabled
    os.environ['__ansible_test_apparmor_status'] = 'enabled'
    apparmor_facts = ApparmorFactCollector.collect()

    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:53:25.133911
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:53:30.345670
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Init
    apparmor_fact_collector = ApparmorFactCollector()
    # Call method collect
    # assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}
    apparmor_fact_collector.collect()
    # assert apparmor_fact_collector.collect() == facts_dict
    # OK
    print('ApparmorFactCollector collect method OK')

# Generated at 2022-06-20 18:53:40.234209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_col = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_col.collect()
    assert apparmor_facts_dict == {'apparmor': {'status': 'disabled'}}

    apparmor_col._file_exists = lambda x: True
    apparmor_facts_dict = apparmor_col.collect()
    assert apparmor_facts_dict == {'apparmor': {'status': 'enabled'}}

    apparmor_col._file_exists = lambda x: False
    apparmor_facts_dict = apparmor_col.collect()
    assert apparmor_facts_dict == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:53.859403
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:53:57.232655
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    print("apparmor block of facts")
    fpc = ApparmorFactCollector()
    print(fpc.collect(module, collected_facts))

# Generated at 2022-06-20 18:53:59.534886
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_obj = ApparmorFactCollector()
    collected_facts = ApparmorFactCollector_obj.collect()


# Generated at 2022-06-20 18:54:09.076766
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test ApparmorFactCollector.collect by mocking os.path.exists
    """
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import Module

    class TestModule(Module):
        def __init__(self, *args, **kwargs):
            pass

    apparmor_fact_collector = get_collector_instance(ApparmorFactCollector)

    test_module = TestModule()

    # Test apparmor enabled
    def mock_exists(path):
        return path == '/sys/kernel/security/apparmor'

    collected_facts = {'apparmor': {}}

# Generated at 2022-06-20 18:54:15.280494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module_mock = None
    collected_facts_mock = None
    ApparmorFactCollector._fact_ids.clear()
    ApparmorFactCollector._fact_ids.add('apparmor')
    apparmor_facts_collector = ApparmorFactCollector()
    facts_dict = apparmor_facts_collector.collect(module_mock, collected_facts_mock)
    assert facts_dict == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:54:22.481960
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    tmp_apparmor = '''
# AppArmor parser cache
enable flag                                                             	1
profiles are                                                           	complaining
hat                                                                    	complaining
audit                                                                  	1
profiles                                                               	2
cache hits                                                             	55
cache misses                                                           	0
audit data available                                                   	1

# AppArmor module statistics
0 profiles are in complain mode.
2 profiles are in enforce mode.
1 processes have profiles defined.
1 processes are in enforce mode.
0 processes are in complain mode.
0 processes are unconfined but have a profile defined.
'''
    ApparmorFactCollector = ApparmorFactCollector()
    result = ApparmorFactCollector.collect('')
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:54:26.143848
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collect_method = ApparmorFactCollector()
    facts_dict = collect_method.collect()
    for fact in facts_dict:
        assert fact in ['apparmor']
    assert facts_dict['apparmor']['status'] == 'disabled'


# Generated at 2022-06-20 18:54:30.944321
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  with open('/tmp/test_apparmor_fact_collector') as f:
    lines = f.readlines()

  f.close()
  lines.sort()

  assert lines == [
    '---\n',
    'apparmor:\n',
    '    status: disabled\n',
    '\n'
  ]

# Generated at 2022-06-20 18:54:32.834519
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector(0).name == 'apparmor'
    assert ApparmorFactCollector(0)._fact_ids == set()

# Generated at 2022-06-20 18:54:35.980188
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Unit test for constructor of class ApparmorFactCollector
    """
    assert(ApparmorFactCollector.name == 'apparmor')
    apparmor_obj = ApparmorFactCollector()
    # No exception thrown when executed
    apparmor_obj.collect()

# Generated at 2022-06-20 18:55:00.492365
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(),ApparmorFactCollector)


# Generated at 2022-06-20 18:55:07.072836
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class Module:
        pass
    module = Module()
    module.params = {}

    # Test with apparmor enabled
    apparmor_facts = ApparmorFactCollector(module=module, collected_facts={})

    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts.collect() == {'apparmor': {'status': 'enabled'}}

    # Test with apparmor disabled
    del module.params['apparmor']
    apparmor_facts = ApparmorFactCollector(module=module, collected_facts={})

    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:55:10.749831
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status'] == 'disabled'
    assert not facts['apparmor']['debug']


# Generated at 2022-06-20 18:55:11.955542
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:55:14.019962
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:55:15.157751
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-20 18:55:18.093121
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    assert ApparmorFactCollector(module, collected_facts)._fact_ids == set()


# Generated at 2022-06-20 18:55:20.771269
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor.collector == 'ApparmorFactCollector'

# Generated at 2022-06-20 18:55:22.855156
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    result = ApparmorFactCollector()
    assert result is not None
    assert result.name == 'apparmor'
    assert result._fact_ids == set()

# Generated at 2022-06-20 18:55:23.688934
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:56:19.241405
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_dict = apparmor_fact.collect()
    assert apparmor_dict
    assert 'apparmor' in apparmor_dict

# Generated at 2022-06-20 18:56:21.934999
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    expected = ApparmorFactCollector()
    assert expected.name == 'apparmor'
    assert expected._fact_ids == set()


# Generated at 2022-06-20 18:56:24.828990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-20 18:56:25.882824
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    expected_name = 'apparmor'
    apparmor_fact = ApparmorFactCollector()

    assert apparmor_fact.name == expected_name

# Generated at 2022-06-20 18:56:27.494723
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj.collect() == {}

# Generated at 2022-06-20 18:56:29.941033
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-20 18:56:33.952766
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    test_facts_dict = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector.collect() == test_facts_dict

# Generated at 2022-06-20 18:56:35.284985
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None


# Generated at 2022-06-20 18:56:38.474306
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] in ['enabled', 'disabled']



# Generated at 2022-06-20 18:56:41.426256
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    results = apparmor.collect()
    assert isinstance(results, dict)
    assert 'apparmor' in results
    assert isinstance(results['apparmor'], dict)
    assert results['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:58:46.357662
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:58:49.455260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ApparmorFactCollector = ApparmorFactCollector()
    test_ApparmorFactCollector.collect()

# Generated at 2022-06-20 18:58:52.460710
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_status = ApparmorFactCollector()
    fact = apparmor_status.collect()
    assert fact['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:55.111887
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert set(result.keys()) == set(['apparmor'])
    assert result['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:58:56.235861
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:58:58.448453
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test ApparmorFactCollector - collect()"""
    object_ = ApparmorFactCollector()
    result = object_.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:59:00.077533
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    assert 'apparmor' in aafc.collect()
    assert 'status' in aafc.collect()['apparmor']

# Generated at 2022-06-20 18:59:05.863778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_facts_dict = {'apparmor': {'status': 'disabled'}}
    test_apparmor_facts = ApparmorFactCollector()
    ansible_facts_dict = test_apparmor_facts.collect()
    assert ansible_facts_dict == test_facts_dict


# Generated at 2022-06-20 18:59:12.230117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Unit test for method collect of class ApparmorFactCollector
    '''
    apparmor_fact_collector = ApparmorFactCollector()

    facts_dict = apparmor_fact_collector.collect()

    assert isinstance(facts_dict, dict)
    assert 'apparmor' in facts_dict
    assert isinstance(facts_dict['apparmor'], dict)
    assert facts_dict['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:59:16.636021
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, ApparmorFactCollector)
    assert obj.name == 'apparmor'
    assert obj.collect()['apparmor']['status'] in ['enabled', 'disabled']