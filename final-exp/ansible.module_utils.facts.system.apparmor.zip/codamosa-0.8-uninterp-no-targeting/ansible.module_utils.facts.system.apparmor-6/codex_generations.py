

# Generated at 2022-06-20 18:51:10.290781
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # When apparmor is not installed in the system, it's disabled in the facts
    os.path.exists = lambda path: False
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-20 18:51:11.278066
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert 'apparmor' == aafc.name


# Generated at 2022-06-20 18:51:16.040794
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    apparmor_fact_collector = Collector()
    assert isinstance(apparmor_fact_collector, Collector)
    assert isinstance(apparmor_fact_collector, BaseFactCollector)
    assert apparmor_fact_collector.__class__.__name__ == 'ApparmorFactCollector'


# Generated at 2022-06-20 18:51:19.042802
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:51:29.530974
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test when apparmor is enabled
    collector = ApparmorFactCollector()
    output = collector.collect(None, None)
    assert 'apparmor' in output, "The output contains no field 'apparmor'"
    assert 'status' in output['apparmor'], "There is no 'status' field in the apparmor field !"
    assert 'enabled' == output['apparmor']['status'], "apparmor status is not 'enabled'"

    # Test when apparmor is disabled
    os.system('rm -rf /sys/kernel/security/apparmor')
    collector = ApparmorFactCollector()
    output = collector.collect(None, None)
    assert 'apparmor' in output, "The output contains no field 'apparmor'"

# Generated at 2022-06-20 18:51:31.213013
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }



# Generated at 2022-06-20 18:51:34.968175
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = AnsibleModuleMock()
    aa = ApparmorFactCollector(module)
    collected_facts = {}
    apparmor_facts = aa.collect(module, collected_facts)
    assert 'apparmor' in apparmor_facts
    try:
        assert apparmor_facts['apparmor']['status'] == 'disabled'
    except:
        assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:51:37.212548
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-20 18:51:40.213825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert(facts['apparmor']['status'] in ['enabled', 'disabled'])

# Generated at 2022-06-20 18:51:42.879369
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()

    assert apparmorFactCollector is not None

    apparmorFactCollector.collect()

# Generated at 2022-06-20 18:51:50.342146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.name = 'apparmor'
    apparmor_fact_collector.collect()
    expected_result = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector.collect() == expected_result

# Generated at 2022-06-20 18:51:54.767315
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    Apparmor_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        print ("apparmor exists")
        assert Apparmor_collector.collect() == {'apparmor': {'status': 'enabled'},}
    else:
        print ("apparmor does not exist")
        assert Apparmor_collector.collect() == {'apparmor': {'status': 'disabled'},}

# Generated at 2022-06-20 18:51:57.182683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    c.collect()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-20 18:51:58.604097
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'

# Generated at 2022-06-20 18:52:00.529735
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    try:
        ApparmorFactCollector()
    except:
        assert False, "Loading of ApparmorFactCollector failed"


# Generated at 2022-06-20 18:52:01.707739
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = ApparmorFactCollector()
    assert facts.name == 'apparmor'

# Generated at 2022-06-20 18:52:04.230125
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_collector_instance = ApparmorFactCollector()
    assert apparmor_facts_collector_instance.name == "apparmor"
    assert apparmor_facts_collector_instance.priority == 3
    assert not apparmor_facts_collector_instance._fact_ids

# Generated at 2022-06-20 18:52:12.605786
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test method collect of class ApparmorFactCollector"""
    apparmor_fact_collector = ApparmorFactCollector()
    # Test if apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        facts_dict = apparmor_fact_collector.collect()
        assert facts_dict['apparmor']['status'] == 'enabled'
    # Test if apparmor is disabled
    else:
        facts_dict = apparmor_fact_collector.collect()
        assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:19.435982
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # mock file path for the available and not
    module_path = 'ansible.module_utils.facts.collector.apparmor'
    mock_paths = [(module_path + '.os.path', 'isfile', True), (module_path + '.os.path', 'isfile', False)]
    with mock.patch.multiple(module_path + '.ApparmorFactCollector', autospec=True, **mock_paths) as mock_apparmor_facts:
        # check no path apparmor disable
        apparmor_facts = ApparmorFactCollector()
        assert apparmor_facts.collect() == { 'apparmor': { 'status': 'disabled'} }
        # check enable apparmor
        apparmor_facts = ApparmorFactCollector()

# Generated at 2022-06-20 18:52:24.749118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    collected_facts = {}
    facts_dict = {}
    apparmor_facts = {}
    facts_dict['apparmor'] = apparmor_facts
    assert facts_dict == apparmorFactCollector.collect(collected_facts)


# Generated at 2022-06-20 18:52:32.430637
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector = ApparmorFactCollector()
    ApparmorFactCollector._collect()
    assert (ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}})

# Generated at 2022-06-20 18:52:33.988797
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    # Test apparmor instance creation
    assert isinstance(apparmor, ApparmorFactCollector)


# Generated at 2022-06-20 18:52:38.023410
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = { 'apparmor': { 'status': 'enabled' } }
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:39.183726
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:40.366285
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert "collect" in dir(aafc)

# Generated at 2022-06-20 18:52:43.494734
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-20 18:52:44.425246
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:52:55.160917
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test when apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_fact_collector = ApparmorFactCollector()
        assert apparmor_fact_collector.name == 'apparmor'
        apparmor_facts = apparmor_fact_collector.collect()
        assert apparmor_facts['apparmor']['status'] == 'enabled'

    # Test when apparmor is disabled
    else:
        apparmor_fact_collector = ApparmorFactCollector()
        assert apparmor_fact_collector.name == 'apparmor'
        apparmor_facts = apparmor_fact_collector.collect()
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:58.532945
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector.priority == 25
    assert 'apparmor' not in apparmorFactCollector._fact_ids

# Generated at 2022-06-20 18:53:00.872503
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert isinstance(ApparmorFactCollector._fact_ids, set)

# Generated at 2022-06-20 18:53:20.285545
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **msg):
            pass

    class MockCollector(object):
        def __init__(self):
            self.facts_dict = {
                'apparmor': {
                    'status': 'enabled'
                }
            }

    mock_module = MockModule()
    mock_collector = MockCollector()
    apparmor_fact_collector = ApparmorFactCollector(mock_module)
    assert apparmor_fact_collector.collect(mock_module, mock_collector) == \
        mock_collector.facts_dict

# Generated at 2022-06-20 18:53:21.721326
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:53:24.757785
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()
    assert apparmor_facts.collect() != {}

# Generated at 2022-06-20 18:53:27.130233
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert facts['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-20 18:53:30.181746
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  fixture = ApparmorFactCollector()
  assert fixture
  assert repr(fixture) == "<ApparmorFactCollector('apparmor')>"
  assert fixture.name == 'apparmor'
  assert fixture._fact_ids == set()

# Generated at 2022-06-20 18:53:30.771435
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()

# Generated at 2022-06-20 18:53:37.515833
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Unit test to check fact dict of class ApparmorFactCollector """

    # Create an instance of ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()

    # Call method collect of class ApparmorFactCollector
    apparmor_facts = apparmor_fact_collector.collect()

    # Assert if method collect returns any facts
    assert apparmor_facts['apparmor'] is not None

# Generated at 2022-06-20 18:53:39.340268
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-20 18:53:40.049537
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:42.366422
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:53:56.285470
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector(None)
    assert isinstance(apparmor_fact_collector.collect(), dict)


# Generated at 2022-06-20 18:54:00.146833
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'enabled' or 'disabled'

# Generated at 2022-06-20 18:54:00.740497
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:54:03.187383
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    conf = {}
    fc = ApparmorFactCollector(conf)
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 18:54:09.284544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Tests if the ApparmorFactCollector collects the correct facts"""
    import os
    import os.path
    import sys

    # The AppArmor status is provided by an existing file in /sys
    from ansible.module_utils.facts import collector

    # AppArmor is disabled
    if not os.path.exists('/sys/kernel/security/apparmor'):
        assert collector.collect_apparmor_facts() == {'apparmor': {'status': 'disabled'}}
    # AppArmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert collector.collect_apparmor_facts() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:54:11.204632
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    assert fc.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:54:13.265693
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector

# Generated at 2022-06-20 18:54:14.546793
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_result = ApparmorFactCollector()
    assert test_result


# Generated at 2022-06-20 18:54:19.359795
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    afc._module = {}
    afc._module.get_bin_path = lambda x: '/bin/' + x
    facts = afc.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts['apparmor']['status'] == 'enabled'
    else:
        assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:23.452952
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    apparmor_facts = aafc.collect()['apparmor']
    assert 'status' in apparmor_facts
    assert apparmor_facts['status'] == 'enabled' or apparmor_facts['status'] == 'disabled'

# Generated at 2022-06-20 18:54:50.842426
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.name == 'apparmor'
    assert apparmor_fact_collector_obj._fact_ids == set()


# Generated at 2022-06-20 18:54:54.280195
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert "_fact_ids" not in dir(apparmor_fact_collector)


# Generated at 2022-06-20 18:55:01.259892
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''Unit test for ApparmorFactCollector.collect'''
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_dict = apparmor_fact_collector.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_dict['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:55:02.543090
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    afc.collect()

# Generated at 2022-06-20 18:55:07.222875
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Assert object is created properly
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)
    assert ApparmorFactCollector().name == "apparmor"
    assert isinstance(ApparmorFactCollector()._fact_ids, set)



# Generated at 2022-06-20 18:55:08.515732
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    target = ApparmorFactCollector()
    assert target.name == 'apparmor'

# Generated at 2022-06-20 18:55:11.746206
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'
    assert len(ApparmorFactCollector()._fact_ids) == 0

# Generated at 2022-06-20 18:55:13.358479
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()

    apparmor_status = apparmor_collector.collect()
    assert 'status' in apparmor_status['apparmor']

# Generated at 2022-06-20 18:55:15.139636
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:55:17.682281
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert len(collector._fact_ids) == 0
    facts = collector.collect()
    assert 'apparmor' in facts
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-20 18:56:15.143425
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # As ApparmorFactCollector._fact_ids is a set and we're not sure about the
    # insertion order, we need to verify the exact content of the list.
    assert set(ApparmorFactCollector().collect().keys()) == {'apparmor'}

# Generated at 2022-06-20 18:56:17.205904
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:56:27.552246
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit tests for method collect of class ApparmorFactCollector
      The value of apparmor['status'] should vary by the presence/absence of /sys/kernel/security/apparmor.
    """
    import sys
    import __builtin__
    import os
    import tempfile
    import shutil
    original_sys_modules = sys.modules.copy()
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:56:29.352556
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-20 18:56:30.509130
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-20 18:56:33.952719
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    facts = apparmor_facts.collect()
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:56:35.287282
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:56:37.416281
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    c.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:56:39.274218
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:56:41.602980
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    facts_dict = apparmor_collector.collect()
    apparmor_facts = facts_dict['apparmor']
    assert apparmor_facts['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:58:45.832494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    result = apparmor.collect()
    assert len(result) == 1
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:47.818163
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:58:51.246508
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None

    apparmor_facts = ApparmorFactCollector(module).collect(module, collected_facts)
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:58:56.844355
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    def check_apparmor_status(file_path):
        if os.path.exists(file_path):
            return 'enabled'
        else:
            return 'disabled'

    if check_apparmor_status('/sys/kernel/security/apparmor') == 'enabled':
        status = 'enabled'
    else:
        status = 'disabled'

    apparmor = {'status': status}
    assert ApparmorFactCollector().collect()['apparmor'] == apparmor

# Generated at 2022-06-20 18:58:59.698327
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collect_method = ApparmorFactCollector().collect
    test_arg = { 'module': None, 'collected_facts': {}}
    result = collect_method(module=test_arg['module'], collected_facts=test_arg['collected_facts'])
    assert 'apparmor' in result

# Generated at 2022-06-20 18:59:02.602397
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert hasattr(obj, '_fact_ids')

# Generated at 2022-06-20 18:59:09.208745
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_collect_obj = ApparmorFactCollector()
    apparmor_facts = {}
    apparmor_facts['status'] = 'enabled'
    facts_dict = {}
    facts_dict['apparmor'] = apparmor_facts
    assert ApparmorFactCollector_collect_obj.collect() == facts_dict


# Generated at 2022-06-20 18:59:16.354462
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    with open('_tmp_apparmor') as f:
        _tmp_apparmor = f.read()
    with open('_tmp_apparmor_disabled') as f:
        _tmp_apparmor_disabled = f.read()

    _apparmor_collector = ApparmorFactCollector()
    _apparmor_collector.collect_cache = {}
    _apparmor_collector.collect_cache['/sys/kernel/security/apparmor'] = _tmp_apparmor
    assert _apparmor_collector.collect()['apparmor']['status'] == 'enabled'
    _apparmor_collector.collect_cache['/sys/kernel/security/apparmor'] = _tmp_apparmor_disabled
    assert _apparmor_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:59:20.680676
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollectorObj = ApparmorFactCollector()
    assert apparmorFactCollectorObj.name == 'apparmor'
    assert apparmorFactCollectorObj._fact_ids == set()


# Generated at 2022-06-20 18:59:26.670162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Init ApparmorFactCollector
    fact_collector = ApparmorFactCollector(
        module=None, collected_facts=None)
    # Run collect() method
    fact_collector.collect()

    assert fact_collector.name == 'apparmor'