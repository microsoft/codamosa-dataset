

# Generated at 2022-06-20 18:51:04.238485
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == "apparmor"


# Generated at 2022-06-20 18:51:06.938198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()


# Collect method

# Generated at 2022-06-20 18:51:11.497822
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = None
    apparmor_fact_collector._collect_platform_subset_facts = None
    apparmor_fact_collector.collect()

# Generated at 2022-06-20 18:51:17.070720
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    dirs = os.listdir('/sys/kernel/security')
    if 'apparmor' in dirs:
        os.unlink('/sys/kernel/security/apparmor')
    apparmor_facts = ApparmorFactCollector().collect()
    if 'apparmor' in dirs:
        os.mkdir('/sys/kernel/security/apparmor')
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:22.164748
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    assert issubclass(ApparmorFactCollector, BaseFactCollector)
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:51:24.964737
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:51:26.978705
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    result = ApparmorFactCollector()
    assert result.name == 'apparmor'
    assert result._fact_ids == set()

# Generated at 2022-06-20 18:51:28.629082
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    assert test_obj.name == 'apparmor'

# Generated at 2022-06-20 18:51:30.899293
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_fact

# Generated at 2022-06-20 18:51:34.580145
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == 'apparmor'
    assert apparmor_fact._fact_ids == set()
    apparmor_fact.collect(module, collected_facts)
    assert apparmor_fact._fact_ids == set()

# Generated at 2022-06-20 18:51:38.785244
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:51:41.739770
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert isinstance(apparmor_fact, ApparmorFactCollector)


# Generated at 2022-06-20 18:51:44.310235
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector(None)
    assert obj.name == 'apparmor'
    assert obj.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:46.264170
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:51:51.173790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector_obj = ApparmorFactCollector()
    res = apparmor_collector_obj.collect()
    assert type(res) == dict
    assert 'apparmor' in res
    assert type(res['apparmor']) == dict
    assert 'status' in res['apparmor']
    assert type(res['apparmor']['status']) == str

# Generated at 2022-06-20 18:51:54.128446
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
   apparmor_facts = {}
   apparmor_facts['status'] = 'disabled'
   fact_dict = {'apparmor': apparmor_facts}
   assert ApparmorFactCollector().collect() == fact_dict

# Generated at 2022-06-20 18:51:57.586688
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """ Test the constructor of class ApparmorFactCollector to init the base class """
    apparmor_factcollector = ApparmorFactCollector()
    assert type(apparmor_factcollector) is ApparmorFactCollector


# Generated at 2022-06-20 18:52:00.656960
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    a = ApparmorFactCollector()
    a.collect(module, collected_facts)
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:52:01.191392
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:02.818283
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Instantiate the class
    aafc = ApparmorFactCollector()
    # Invoke the method collect
    aafc.collect()

# Generated at 2022-06-20 18:52:08.650827
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:52:17.260362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test ApparmorFactCollector.collect using fake
    os.path.exists.
    """
    # global os.path.exists
    # save_path_exists = os.path.exists

    # mock os.path.exists
    def mock_os_path_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False

    os.path.exists = mock_os_path_exists
    apparmor_facts_collector = ApparmorFactCollector()
    expected_apparmor_facts = {
        'apparmor': {
            'status': 'enabled'
        }
    }
    assert apparmor_facts_collector.collect() == expected_apparmor_facts

    # restore os.path.exists
   

# Generated at 2022-06-20 18:52:24.202419
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    ApparmorFactCollector.collect() Test
    """
    root_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.join(root_dir, '..', '..', '..')
    root_dir = os.path.normpath(root_dir)
    collector = ApparmorFactCollector(root_dir, {}, {}, [root_dir])
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert collector.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:26.098395
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:30.357575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create the class instance for test
    Apparmor_collector = ApparmorFactCollector()

    # Call the collect method of class ApparmorFactCollector
    actual = Apparmor_collector.collect()

    # Assert if actual is not equal to expected
    assert actual != 'disabled'

# Generated at 2022-06-20 18:52:32.095614
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector.name

# Generated at 2022-06-20 18:52:36.431034
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts == {
            'apparmor': {
                'status': 'disabled'
            }
        }

# Generated at 2022-06-20 18:52:37.756381
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector(None)
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:52:43.949843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test when apparmor is active
    fact_collector = ApparmorFactCollector({'path': '/sys/kernel/security/apparmor'})
    result = fact_collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}, "ApparmorFactCollector collect method failed when apparmor is active."

    # Test when apparmor is inactive
    fact_collector = ApparmorFactCollector({'path': '/nonexistent/dir'})
    result = fact_collector.collect()
    assert result == {'apparmor': {'status': 'disabled'}}, "ApparmorFactCollector collect method failed when apparmor is inactive."

# Generated at 2022-06-20 18:52:46.783795
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-20 18:52:56.190128
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert facts['apparmor']['status'] == 'enabled' or facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:59.410007
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {}
    apparmor_facts['status'] = 'enabled'
    fa = ApparmorFactCollector()
    res = fa.collect()
    assert res == { 'apparmor': apparmor_facts }

# Generated at 2022-06-20 18:53:00.689754
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    r = ApparmorFactCollector()
    assert r.name == 'apparmor'

# Generated at 2022-06-20 18:53:10.277495
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = MagicMock()
    mock_module.params = {}

    mock_BaseFactCollector = MagicMock()
    mock_BaseFactCollector_instance = mock_BaseFactCollector.return_value
    mock_collect = mock_BaseFactCollector_instance.collect
    mock_collect.return_value = {'apparmor': {}}

    with patch.multiple(
        'ansible.module_utils.facts.collector.base',
        BaseFactCollector=mock_BaseFactCollector
    ):
        from ansible.module_utils.facts import collector

        assert collector.collect_apparmor_facts(mock_module) == {'apparmor': {}}
        mock_collect.assert_called_once_with(mock_module, {'apparmor': {}})

# Generated at 2022-06-20 18:53:12.054563
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert dict == type(apparmor.collect())


# Generated at 2022-06-20 18:53:15.540689
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert isinstance(a.collect(), dict)



# Generated at 2022-06-20 18:53:17.670770
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:53:21.064636
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    instance = ApparmorFactCollector()
    assert instance.name == 'apparmor'
    assert instance._fact_ids == set()


# Generated at 2022-06-20 18:53:24.166588
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Test if apparmor facts are generated
    '''
    test_fact = ApparmorFactCollector()
    assert test_fact.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:27.602137
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Test that __init__() creates the correct attributes.
    """
    collector = ApparmorFactCollector()
    assert collector.name == "apparmor"
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:53:40.583808
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(),ApparmorFactCollector)



# Generated at 2022-06-20 18:53:42.845698
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"

# Generated at 2022-06-20 18:53:45.206915
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:53:49.137168
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_fact_collect = apparmor_fact.collect()
    assert apparmor_fact_collect.get('apparmor') != None

# Generated at 2022-06-20 18:54:00.738415
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    sys_path = '/tmp/apparmorLockerDir'
    sys_path_exists = True
    path_stat_exists = True
    if not os.path.exists(sys_path):
        sys_path_exists = False
        os.makedirs(sys_path)

    def mock_path_stat_os(path):
        return path_stat_exists

    def mock_os_path_exists(path):
        return sys_path_exists

    apparmor_facts = ApparmorFactCollector()

    # If /sys/kernel/security/apparmor path exists and accessible it should return 'enabled'
    path_stat_exists = True
    sys_path_exists = True
    apparmor_facts.collect()
    result = apparmor_facts.collect()

# Generated at 2022-06-20 18:54:02.426354
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    result = fact.collect()
    print(result)

# Generated at 2022-06-20 18:54:05.492686
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts_dict = {'name': 'ApparmorFactCollector'}
    assert apparmor.collect(None, facts_dict) == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:12.765536
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # Check that facts are collected only if /sys/kernel/security/apparmor exists
    with open('/sys/kernel/security/apparmor', mode='w') as f:
        collected_facts = apparmor_fact_collector.collect()
        assert collected_facts['apparmor']['status'] == 'enabled'
    os.remove('/sys/kernel/security/apparmor')
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:16.786434
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    r = ApparmorFactCollector()
    assert r.name == 'apparmor'
    assert not r._fact_ids
    assert not hasattr(r, '_cache')
    assert hasattr(r, 'collect')
    assert hasattr(r, 'collect_from_external_module')
    assert hasattr(r, 'get_fact_names')

# Generated at 2022-06-20 18:54:18.307327
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector().name == 'apparmor'

# Generated at 2022-06-20 18:54:47.057547
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class FakeModule(object):
        pass

    module = FakeModule()
    aafc = ApparmorFactCollector(module)
    aafc._module = module
    aafc._module.exit_json = lambda **kwargs: kwargs

    assert aafc._module.exit_json(ansible_facts={'apparmor': {'status': 'disabled'}}) == {'ansible_facts': {'apparmor': {'status': 'disabled'}}}

# Generated at 2022-06-20 18:54:53.431010
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test ApparmorFactCollector constructor"""
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert hasattr(apparmor_fact_collector, 'name')
    assert hasattr(apparmor_fact_collector, 'collect')
    assert hasattr(apparmor_fact_collector, '_fact_ids')
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:54:55.505095
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:54:58.036424
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    myapparmor = ApparmorFactCollector()
    assert myapparmor.name == 'apparmor'

# Generated at 2022-06-20 18:55:00.279126
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()


# Generated at 2022-06-20 18:55:02.100387
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'

# Generated at 2022-06-20 18:55:03.503940
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ansible_module = MagicMock()
    apparmor_collector = ApparmorFactCollector()


# Generated at 2022-06-20 18:55:07.222393
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
        apparmor_collector = ApparmorFactCollector()
        assert apparmor_collector.name == 'apparmor'
        assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-20 18:55:09.044892
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj
    assert obj.name == 'apparmor'


# Generated at 2022-06-20 18:55:11.610160
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-20 18:56:06.529998
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'

# Generated at 2022-06-20 18:56:12.180108
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    collectedFacts = apparmorFactCollector.collect()

    # check if the apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert collectedFacts['apparmor']['status'] == 'enabled'
    else:
        assert collectedFacts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:13.074615
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:56:15.903363
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'



# Generated at 2022-06-20 18:56:18.334935
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:56:20.188932
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:56:22.076316
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector.name == 'apparmor')

# Generated at 2022-06-20 18:56:25.367897
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_info = ApparmorFactCollector()
    apparmor_info_facts = apparmor_info.collect()
    assert 'apparmor' in apparmor_info_facts

# Generated at 2022-06-20 18:56:26.040387
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-20 18:56:27.983699
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-20 18:58:33.855948
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector.collect()
    assert isinstance(apparmor_facts, dict)
    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:58:37.761196
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    os_path_exists = os.path.exists
    try:
        os.path.exists = lambda _: True
        assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}
    finally:
        os.path.exists = os_path_exists


# Generated at 2022-06-20 18:58:38.219998
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:58:41.680636
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:58:49.318858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import ansible.utils.unsafe_proxy

    G = ansible.utils.unsafe_proxy.AnsibleUnsafeText
    apparmor_facts = {
        'status': 'enabled'
    }
    g_apparmor_facts = ansible.utils.unsafe_proxy.AnsibleUnsafeBytes.from_list([G('status'), G('enabled')])
    expected_facts = {
        'apparmor': g_apparmor_facts
    }
    ApparmorFactCollector_obj = ApparmorFactCollector()
    facts_dict = ApparmorFactCollector_obj.collect()

    assert facts_dict == expected_facts

# Generated at 2022-06-20 18:58:53.041758
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method collect of class ApparmorFactCollector
    """
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()



# Generated at 2022-06-20 18:58:54.860623
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()



# Generated at 2022-06-20 18:58:56.611137
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:58:59.708438
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorCollector = ApparmorFactCollector()
    facts = apparmorCollector.collect(collected_facts=None)
    assert facts is not None
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:59:01.061504
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    source_obj = ApparmorFactCollector()
    source_obj.collect()