

# Generated at 2022-06-20 18:51:06.959121
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    if os.path.exists('/sys/kernel/security/apparmor'):
        module = ApparmorFactCollector()
        result = module.collect(None, None)
        assert result
        assert result['apparmor']['status'] == 'enabled'
    else:
        module = ApparmorFactCollector()
        result = module.collect(None, None)
        assert result
        assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:12.724930
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test ApparmorFactCollector.collect()"""

    os.path.exists =lambda path : True

    apparmor_fact_collector = ApparmorFactCollector()
    expected = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector.collect() == expected

# Generated at 2022-06-20 18:51:13.185451
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:51:16.079090
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # create instance of ApparmorFactCollector
    apparmorCollector = ApparmorFactCollector()
    assert isinstance(apparmorCollector, ApparmorFactCollector)

# Collect facts
# Collects the facts related to apparmor.

# Generated at 2022-06-20 18:51:21.518142
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None

    apparmor_fc = ApparmorFactCollector()
    apparmor_facts = apparmor_fc.collect(module, collected_facts)

    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:25.092610
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector_obj = ApparmorFactCollector()
    facts_dict = fact_collector_obj.collect()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['apparmor'], dict)

# Generated at 2022-06-20 18:51:27.833431
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    os.path.exists = lambda x: True
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:29.953115
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_obj = ApparmorFactCollector()
    assert '/sys/kernel/security/apparmor' in test_obj.collect().values()

# Generated at 2022-06-20 18:51:31.242243
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'


# Generated at 2022-06-20 18:51:32.599159
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    assert f.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:36.769222
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = Mock()
    mock_collected_facts = Mock()
    aafc = ApparmorFactCollector()
    aafc.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert True

# Generated at 2022-06-20 18:51:38.155958
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, ApparmorFactCollector)

# Generated at 2022-06-20 18:51:40.855712
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:51:44.310552
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    my_apparmor_fact_collector = ApparmorFactCollector()
    assert my_apparmor_fact_collector.name == 'apparmor'
    assert my_apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:51:45.863683
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'


# Generated at 2022-06-20 18:51:50.609286
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    fake_file = {'exists.return_value': False}
    m = mock.MagicMock(name="apparmor")
    with mock.patch('os.path.exists', fake_file["exists.return_value"]):
        family_facts = ApparmorFactCollector().collect()
        assert 'apparmor' in family_facts

# Generated at 2022-06-20 18:51:51.833778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    assert c.collect()

# Generated at 2022-06-20 18:51:54.128010
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class_obj = ApparmorFactCollector()
    assert class_obj.name == 'apparmor'
    assert class_obj._fact_ids == set()

# Generated at 2022-06-20 18:51:56.117358
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:58.555474
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:52:03.199817
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:52:06.916905
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert len(aafc.collection_calls) == 1

# Generated at 2022-06-20 18:52:15.616198
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    collected_facts = {}
    expected_result = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'
    expected_result['apparmor'] = apparmor_facts
    if 'apparmor' in expected_result:
        aafc._fact_ids.add('apparmor')
    collected_facts = aafc.collect(collected_facts=collected_facts)
    assert collected_facts == expected_result


# Generated at 2022-06-20 18:52:16.512267
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:52:23.530566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create instance of class ApparmorFactCollector
    apparmor_fact_collector_obj = ApparmorFactCollector()

    # Call method collect of class ApparmorFactCollector
    actual_apparmor_facts = apparmor_fact_collector_obj.collect()

    # Create dictionary of expected facts
    expected_apparmor_facts = {
        "apparmor": {
            "status": "enabled"
        }
    }

    # Check if the returned apparmor facts are equal to the expected
    # apparmor facts
    assert actual_apparmor_facts == expected_apparmor_facts

# Generated at 2022-06-20 18:52:30.330468
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_facts = {}

    apparmor_facts['status'] = 'enabled'

    test_obj = ApparmorFactCollector()

    # Test with /sys/kernel/security/apparmor
    os.path.exists = lambda x: True
    assert test_obj.collect()['apparmor'] == apparmor_facts

    # Test without /sys/kernel/security/apparmor
    os.path.exists = lambda x: False
    apparmor_facts['status'] = 'disabled'
    assert test_obj.collect()['apparmor'] == apparmor_facts

# Generated at 2022-06-20 18:52:34.705888
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    This is a unit test for the collect method of class
    ApparmorFactCollector. It verifies that the class raises an
    exception if it is called without having been initialized first.

    This test is performed by calling the collect method without having
    called the init method first.
    """

    apparmor_collector = ApparmorFactCollector()

    try:
        apparmor_collector.collect()
    except NameError:
        assert True
    else:
        assert False

# Generated at 2022-06-20 18:52:37.263380
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    facts = fact.collect()
    assert type(facts) is dict
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:52:39.449882
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class_variable = ApparmorFactCollector()
    assert class_variable.name == 'apparmor'
    assert class_variable._fact_ids == set()

# Generated at 2022-06-20 18:52:43.350362
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_module = None
    fake_collected_facts = None
    fake_sys_kernel_security_apparmor = { 'status': 'disabled' }
    test_obj = ApparmorFactCollector()
    real_result = test_obj.collect(fake_module, fake_collected_facts)
    assert real_result == fake_sys_kernel_security_apparmor

# Generated at 2022-06-20 18:52:58.010198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an empty apparmor collector object
    apparmor_collector = ApparmorFactCollector()

    # Create a fake for module that always returns a True for os.path.exists('/sys/kernel/security/apparmor')
    fake_module = type('module', (object,), {'_module': 'module', 'params':{}, '_debug': False, '_verbosity': 0})
    def path_exists(path):
        return True
    fake_module.os.path.exists = path_exists

    # Test the collection function of apparmor collector when apparmor is enabled
    apparmor_collector.collect(module=fake_module)


# Generated at 2022-06-20 18:52:59.267949
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:53:00.560527
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector(None, None)
    assert apparmor.collect()

# Generated at 2022-06-20 18:53:10.215853
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector
    collector_registry.collectors['apparmor'] = ApparmorFactCollector(set(), {})
    collected_facts = {}
    def fake_init(self, fact_ids, collected_facts):
        return
    ApparmorFactCollector.__init__ = fake_init
    if not os.path.exists('/sys/kernel/security/apparmor'):
        os.makedirs('/sys/kernel/security/apparmor')
    apparmor_facts = ApparmorFactCollector(set(), {}).collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    # Cleanup
    del apparmor_facts
   

# Generated at 2022-06-20 18:53:10.883807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:11.445806
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:20.679121
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector

    # Create a collector and make sure it's a BaseFactCollector and ApparmorFactCollector
    apparmor_collector = collector.get_collector('apparmor')
    assert isinstance(apparmor_collector, BaseFactCollector)
    assert isinstance(apparmor_collector, ApparmorFactCollector)

    # Create a fake module and make sure collect returns a dictionary
    module = object()
    collected_facts = object()
    assert isinstance(apparmor_collector.collect(module, collected_facts), dict)

# Generated at 2022-06-20 18:53:23.143496
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:26.141624
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:53:28.819686
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:53:40.093423
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:53:42.404382
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-20 18:53:48.855810
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    fact_list = collector._fact_ids

    assert type(facts) is dict
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert type(facts['apparmor']['status']) is str
    assert 'apparmor' in fact_list
    assert 'apparmor_status' in fact_list

# Generated at 2022-06-20 18:53:51.651541
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect()
    assert result['apparmor']['status']

# Generated at 2022-06-20 18:53:54.349281
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    UnitTest test_ApparmorFactCollector_collect
    """
    collect = ApparmorFactCollector()
    assert(collect.name == "apparmor")

# Generated at 2022-06-20 18:53:57.375294
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_collector = ApparmorFactCollector()
    assert apparmor_facts_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:54:00.190701
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_apparmor = ApparmorFactCollector()
    ret = fact_apparmor.collect(collected_facts={})

    assert ret['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:54:04.259938
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class MockModule:
        def __init__(self):
            pass
    apparmor_fact_collector = ApparmorFactCollector(MockModule())
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-20 18:54:09.283136
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}
    try:
        assert ApparmorFactCollector.collect().keys()[0] == 'apparmor'
    except AssertionError:
        assert ApparmorFactCollector.collect().keys()[0] == 'apparmor'

# Generated at 2022-06-20 18:54:12.629403
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:54:36.842825
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor.collect() == \
        {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:45.410244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.parsers.apparmor import Apparmor
    from ansible.module_utils._text import to_text
    apparmor_data = '''
    securityfs on /sys/kernel/security type securityfs (rw,nosuid,nodev,noexec,relatime)
    pstore on /sys/fs/pstore type pstore (rw,nosuid,nodev,noexec,relatime)
    '''
    test_obj = Apparmor(content=to_text(apparmor_data))
    assert test_obj.data == {'status': 'enabled'}
    apparmor_data = '''
    pstore on /sys/fs/pstore type pstore (rw,nosuid,nodev,noexec,relatime)
    '''

# Generated at 2022-06-20 18:54:47.832658
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:54:50.798617
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()

# Generated at 2022-06-20 18:54:53.198736
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfactcollector = ApparmorFactCollector()
    assert apparmorfactcollector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:55.302146
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a=ApparmorFactCollector()
    assert a.name == 'apparmor'

# Unit test to check collect method of class ApparmorFactCollector

# Generated at 2022-06-20 18:54:58.580100
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfc = ApparmorFactCollector()
    assert apparmorfc.name == 'apparmor'
    assert apparmorfc._fact_ids == set()


# Generated at 2022-06-20 18:54:59.013096
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:55:00.237206
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector.name == 'apparmor')

# Generated at 2022-06-20 18:55:00.891735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-20 18:55:55.307735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_facts = apparmor_fact.collect()
    status = apparmor_facts.get('apparmor', {}).get('status')
    assert status == 'enabled' or status == 'disabled'

# Generated at 2022-06-20 18:55:56.467772
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # assert(False) # todo: implement or remove
    pass

# Generated at 2022-06-20 18:55:57.527724
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'

# Generated at 2022-06-20 18:55:59.843709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.collect() == dict()

# Generated at 2022-06-20 18:56:00.961072
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x is not None


# Generated at 2022-06-20 18:56:02.861664
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert isinstance(x, ApparmorFactCollector)

# Test collect method of class ApparmorFactCollector

# Generated at 2022-06-20 18:56:05.877947
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    result = fact.collect()
    assert 'apparmor' in result
    assert 'status' in result['apparmor']

# Generated at 2022-06-20 18:56:08.031886
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector.priority == 50

# Generated at 2022-06-20 18:56:11.430447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_collect = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_collect
    assert 'status' in apparmor_collect['apparmor']

# Generated at 2022-06-20 18:56:15.698970
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_test_data = {
        "apparmor": {
            "status": "enabled"
        }
    }

    collector_test = ApparmorFactCollector()
    result_test = collector_test.collect()
    assert result_test == fact_test_data

# Generated at 2022-06-20 18:58:08.679731
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:58:17.174746
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    HOSTVARS = dict()
    MOCK_MODULE = MagicMock()
    MOCK_COLLECTED_FACTS = dict()
    MOCK_COLLECTED_FACTS['ansible_distribution'] = 'Ubuntu'
    MOCK_COLLECTED_FACTS['ansible_distribution_major_version'] = '16'
    MOCK_COLLECTED_FACTS['ansible_distribution_version'] = '16.04'
    MOCK_COLLECTED_FACTS['ansible_kernel'] = '4.13.0-36-generic'
    MOCK_COLLECTED_FACTS['ansible_system'] = 'Linux'
    MOCK_COLLECTED_FACTS['ansible_processor_vcpus'] = 1
    MOCK_COLLECTED_F

# Generated at 2022-06-20 18:58:18.594148
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    obj = ApparmorFactCollector()
    facts = obj.collect()
    assert 'apparmor' in facts

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:58:19.949277
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'

# Generated at 2022-06-20 18:58:24.345431
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    assert test_obj.name == 'apparmor'
    assert test_obj._fact_ids == set()

# Unit test to ensure 'collect' method of ApparmorFactCollector
# returns correct dict with 'apparmor' as key

# Generated at 2022-06-20 18:58:27.922393
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    app_fact_cl = ApparmorFactCollector()
    app_fact_cl.collect()
    assert app_fact_cl.get_facts()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:58:31.900400
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit tests for collect method of class ApparmorFactCollector.
    """
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-20 18:58:35.619163
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    mock_module = {
        'NAME': 'apparmor'
    }
    mock_collected_facts = {}

    assert a.collect(module=mock_module, collected_facts=mock_collected_facts) == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:58:39.303434
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # collect facts.
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result.get('apparmor') is not None
    assert result['apparmor']['status'] == 'enabled'
    assert type(result['apparmor']['status']) is str

# Generated at 2022-06-20 18:58:43.505730
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert len(collector._fact_ids) == 0
    assert type(collector.collect()) == dict
