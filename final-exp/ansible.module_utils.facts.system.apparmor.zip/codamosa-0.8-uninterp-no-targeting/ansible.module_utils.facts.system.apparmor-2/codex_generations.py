

# Generated at 2022-06-20 18:51:02.324484
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_finder = ApparmorFactCollector()
    result = fact_finder.collect(module=None, collected_facts=None)
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:04.025034
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:51:06.108478
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-20 18:51:09.456837
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-20 18:51:15.475046
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    # Fake file exists
    collector._exists = lambda x: True
    assert collector.collect()['apparmor']['status'] == 'enabled'

    # Fake file not exists
    collector._exists = lambda x: False
    assert collector.collect()['apparmor']['status'] == 'disabled'


if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:51:20.144765
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()
    assert 'apparmor' in facts_dict
    assert 'status' in facts_dict['apparmor']
    assert facts_dict['apparmor']['status'] in ['disabled', 'enabled']

# Generated at 2022-06-20 18:51:21.795088
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    a.collect()

# Generated at 2022-06-20 18:51:24.252219
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-20 18:51:25.253004
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:51:27.450681
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    lf = ApparmorFactCollector()
    assert lf.name == 'apparmor'
    assert lf._fact_ids == set()

# Generated at 2022-06-20 18:51:33.297091
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:34.772742
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'


# Generated at 2022-06-20 18:51:37.726395
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'
    assert f._fact_ids == set()


# Generated at 2022-06-20 18:51:40.313568
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()


# Generated at 2022-06-20 18:51:41.751489
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name

# Generated at 2022-06-20 18:51:43.919182
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:51:45.483093
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'

# Generated at 2022-06-20 18:51:47.779166
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    s = ApparmorFactCollector()
    expected = {'apparmor': {'status': 'disabled'}}
    assert s.collect() == expected

# Generated at 2022-06-20 18:51:55.741260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import sys
    sys.modules['ansible'] = type('mock_ansible', (), {'__file__': os.devnull})
    sys.modules['ansible.module_utils'] = type('mock_ansible_module_utils', (), {'__file__': os.devnull})
    sys.modules['ansible.module_utils.facts'] = type('mock_ansible_module_utils_facts', (), {'__file__': os.devnull})
    sys.modules['ansible.module_utils.facts.collector'] = type('mock_ansible_module_utils_facts_collector', (), {'__file__': os.devnull})
    from ansible.module_utils.facts import collector

# Generated at 2022-06-20 18:52:03.942034
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # mock module
    class MockModule(object):
        pass
    mock_module = MockModule()
    mock_module.params = {}

    # mock os.path.exists
    def mock_path_exists(*args, **kwargs):
        return True

    # mock open
    def mock_open(*args, **kwargs):
        return [open(__file__).read()]

    # mock ansible.module_utils.facts.collector.BaseFactCollector
    class MockBaseFactCollector(object):
        _fact_ids = {'fact id'}
    mock_base_fact_collector = MockBaseFactCollector()

    # create an instance of ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.name = 'apparmor'

# Generated at 2022-06-20 18:52:16.285468
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for ApparmorFactCollector.collect()"""

    # If file /sys/kernel/security/apparmor exists,
    # Apparmor is enabled
    def os_path_exists_mock(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False
    ApparmorFactCollector._module.os_path.exists = os_path_exists_mock
    expected = dict(apparmor=dict(status='enabled'))
    result = ApparmorFactCollector.collect()
    assert expected == result

    # If file /sys/kernel/security/apparmor does not exist,
    # Apparmor is disabled
    def os_path_exists_mock(path):
        if path == '/sys/kernel/security/apparmor':
            return False


# Generated at 2022-06-20 18:52:18.275677
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    main_obj = ApparmorFactCollector()
    assert main_obj.name == 'apparmor'

# Generated at 2022-06-20 18:52:20.310684
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    afc.collect()
    assert afc.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:52:30.448221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector

    expected_output = {'apparmor': {'status': 'enabled'}}

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)

    # use that temporary file as /sys/kernel/security/apparmor
    base_collector = BaseFactCollector()

    # create temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    base_collector.get_file_content = lambda x: to

# Generated at 2022-06-20 18:52:32.614050
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collector = ApparmorFactCollector()
    test_collector.collect()
    assert test_collector.name == 'apparmor'

# Generated at 2022-06-20 18:52:34.770764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:38.027418
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    test_facts_dict = {'apparmor': {'status': 'disabled'}}
    test_actual = apparmor_fact_collector.collect()
    if test_actual != test_facts_dict:
        raise AssertionError('Test failed')

# Generated at 2022-06-20 18:52:39.154195
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector.collected_facts == {}


# Generated at 2022-06-20 18:52:40.342953
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:52:42.974554
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {
        "apparmor": {
            "status": "disabled"
        }
    }

    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == apparmor_facts

# Generated at 2022-06-20 18:52:48.730575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:52:55.600249
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Verify that Apparmor fact are gathered correctly """
    fake_module = type('', (), {})()
    fake_module.get_bin_path = lambda _: None
    fake_module.ansible_facts = {}

    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect(fake_module)

    assert 'apparmor' in fake_module.ansible_facts
    assert fake_module.ansible_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:58.149589
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()



# Generated at 2022-06-20 18:53:00.917459
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.name = 'apparmor'
    ac = ApparmorFactCollector()
    assert ac.collect()['apparmor']['status'] != ''

# Generated at 2022-06-20 18:53:02.262258
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:53:04.832603
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    assert test_obj.name == 'apparmor'
    assert test_obj._fact_ids == set()

# Generated at 2022-06-20 18:53:06.915124
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-20 18:53:11.501836
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()
    assert isinstance(aafc.collect()['apparmor'], dict)

# Generated at 2022-06-20 18:53:14.956996
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()

    assert apparmorFactCollector.name == 'apparmor'
    assert not apparmorFactCollector._fact_ids

# Generated at 2022-06-20 18:53:16.016608
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'


# Generated at 2022-06-20 18:53:32.324995
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfactcollector = ApparmorFactCollector()

    # Case when Apparmor is enabled
    os.path.exists = lambda path: True
    assert apparmorfactcollector.collect() == {'apparmor': {'status': 'enabled'}}

    # Case when Apparmor is disabled
    apparmorfactcollector = ApparmorFactCollector()
    os.path.exists = lambda path: False
    assert apparmorfactcollector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:34.879414
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collector = ApparmorFactCollector()
    result = test_collector.collect()
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:37.423760
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:53:41.549907
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Unit test for constructor of class ApparmorFactCollector
    """
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:53:44.075128
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collected_facts = ApparmorFactCollector().collect(None, {})
    assert collected_facts['apparmor']['status'] == 'disabled' or collected_facts['apparmor']['status'] == 'enabled'



# Generated at 2022-06-20 18:53:49.949731
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_data = {'apparmor': {'status': 'enabled'}}
    else:
        expected_data = {'apparmor': {'status': 'disabled'}}
    fact_collector = ApparmorFactCollector()
    data = fact_collector.collect()
    assert data == expected_data

# Generated at 2022-06-20 18:53:52.818346
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert not fact_collector._fact_ids

# Generated at 2022-06-20 18:53:55.825292
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facter = ApparmorFactCollector()
    facts = facter.collect(collected_facts={})

    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-20 18:53:59.103204
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    result = apparmor_fact.collect()
    assert result['apparmor']['status'] in ['enabled','disabled'], 'expected enabled or disabled'

# Generated at 2022-06-20 18:54:02.611244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect()
    print(result)

if __name__ == '__main__':
    # test the above function
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:54:28.752930
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactsCollector = ApparmorFactCollector()
    apparmorFacts = apparmorFactsCollector.collect()
    if apparmorFacts['apparmor']['status'] == 'enabled':
        assert os.path.exists('/sys/kernel/security/apparmor') is True
    elif apparmorFacts['apparmor']['status'] == 'disabled':
        assert os.path.exists('/sys/kernel/security/apparmor') is False

# Generated at 2022-06-20 18:54:30.867928
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert (apparmor_facts.name == "apparmor")


# Generated at 2022-06-20 18:54:34.181681
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-20 18:54:36.680586
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:54:38.600096
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:39.974360
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:54:41.042364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x



# Generated at 2022-06-20 18:54:41.830141
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-20 18:54:44.685671
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()


# Generated at 2022-06-20 18:54:46.469685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect().get('apparmor') == {'status': 'disabled'}

# Generated at 2022-06-20 18:55:29.881185
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:55:31.202056
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:55:35.471821
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fixture = {'somearray': [],
               'somestring': 'str',
               'somebool': True}
    obj = ApparmorFactCollector()
    result = obj.collect()
    assert result['apparmor']['status'] == fixture['somebool']

# Generated at 2022-06-20 18:55:37.253782
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name is not None

# Generated at 2022-06-20 18:55:42.223793
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mm = mock.mock_open()
    with mock.patch('ansible.module_utils.facts.collector.open', mm, create=True):
        mm.side_effect = [IOError]
        appa = ApparmorFactCollector()
        assert dict() == appa._collect()


# Generated at 2022-06-20 18:55:50.239795
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        import sys
        import os
        sys.path.search(os.path.dirname(__file__))
    except Exception:
        sys.path.append(os.path.dirname(__file__))
    import pytest

    # testing load the module Apparmor
    apparmor = pytest.importorskip('ansible.modules.system.apparmor')
    # instantiate class Apparmor
    obj = apparmor.Apparmor()
    obj.load_facts = True
    # testing method fact_collector
    obj.collect()
    # testing the method collect of class ApparmorFactCollector
    assert ApparmorFactCollector().collect() is not None

# Generated at 2022-06-20 18:55:55.347582
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector._module = object()
    apparmor_collector._module.params = dict()
    apparmor_collector._module.params["gather_subset"] = ["apparmor"]

    ans = apparmor_collector.collect()
    assert ans['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:55:58.600389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:08.526221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import uuid
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    # Test for absence of /sys/kernel/security/apparmor
    mkdtmp = os.mkdtemp()
    orig = os.environ.get('ANSIBLE_COLLECTORS_PATH')
    os.environ['ANSIBLE_COLLECTORS_PATH'] = mkdtmp

# Generated at 2022-06-20 18:56:10.542132
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'


# Generated at 2022-06-20 18:57:52.386852
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    ret = collector.collect()
    assert isinstance(ret, dict) == True
    assert isinstance(ret['apparmor'], dict) == True
    assert ret['apparmor'].get('status') in ['enabled','disabled']
    # Do we also need to test a scenario when apparmor is not available?
    return True

# Generated at 2022-06-20 18:57:58.919472
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = AnsibleModuleMock()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    del apparmor_fact_collector._module
    apparmor_fact_collector._module = AnsibleModuleMock(apparmor_exists=False)
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Unit tests for class ApparmorFactCollector

# Generated at 2022-06-20 18:58:03.372970
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # if os.path.exists('/sys/kernel/security/apparmor') doesn't exist
    #   return facts_dict["apparmor"]["status"] = "disabled"
    fact_collector = ApparmorFactCollector()
    fact_collector.collect()
    assert fact_collector.collect() == {'apparmor':{'status':'disabled'}}

# Generated at 2022-06-20 18:58:06.768240
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import mock_module
    from ansible.module_utils.facts import FactCollector

    fc = FactCollector()
    module = mock_module()

    results = fc.collect(module)
    assert results['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:58:09.105138
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-20 18:58:10.995284
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    result = fc.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:12.874339
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:58:17.570557
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = lambda: None
    mock_module.get_bin_path = lambda x: x
    mock_module.run_command_environ_update = lambda x, y, z: (0, '', '')
    collector = ApparmorFactCollector
    # No status until apparmor is enabled or disabled
    assert collector.collect(mock_module, {})['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:19.841219
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector.collect_fn == apparmor_collector.collect

# Generated at 2022-06-20 18:58:23.515025
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'