

# Generated at 2022-06-20 18:51:03.355638
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:51:05.050413
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'

# Generated at 2022-06-20 18:51:07.717927
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = ApparmorFactCollector()
    assert facts.name == 'apparmor'
    assert 'apparmor' in facts._fact_ids

# Generated at 2022-06-20 18:51:14.873624
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    modules = {'sys': '', 'os': ''}
    module_ins = type('module', tuple(), {})()
    module_ins.get_bin_path = lambda x: x
    module_ins.run_command = lambda x: (0, "", "")
    module_ins.fail_json = lambda **kwargs: {}
    module_ins.params = {}
    _collector = ApparmorFactCollector(module_ins, '', '')
    _collector.collect()

# Generated at 2022-06-20 18:51:25.006619
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with a real path for the apparmor file system
    apparmor_collector = ApparmorFactCollector()
    os.path.exists = lambda path: path == '/sys/kernel/security/apparmor'
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

    # Test with a fake path for the apparmor file system
    apparmor_collector = ApparmorFactCollector()
    os.path.exists = lambda path: path != '/sys/kernel/security/apparmor'
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:27.409515
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    module = None
    facts = apparmor_facts.collect(module)
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:51:28.848364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_FactCollector = ApparmorFactCollector()


# Generated at 2022-06-20 18:51:29.740916
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-20 18:51:32.527334
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = mock.MagicMock()
    collected_facts = mock.MagicMock()

    result = ApparmorFactCollector.collect(module, collected_facts)
    assert result == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:34.264709
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-20 18:51:39.076318
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    assert a.collect() is None

# Generated at 2022-06-20 18:51:40.404931
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-20 18:51:44.114465
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-20 18:51:50.201710
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()

    assert isinstance(facts_dict, dict) is True
    assert isinstance(facts_dict['apparmor'], dict) is True
    assert isinstance(facts_dict['apparmor']['status'], str) is True
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:55.108563
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector_facts = ApparmorFactCollector()
    ansible_module = get_module()
    ansible_facts = {}
    collection = apparmor_collector_facts.collect(module=ansible_module, collected_facts=ansible_facts)
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert collection['apparmor']['status'] == 'enabled'
    else:
        assert collection['apparmor']['status'] == 'disabled'


# Generated at 2022-06-20 18:51:56.795512
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-20 18:51:58.913768
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:52:00.293950
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_collector = ApparmorFactCollector()
    facts = facts_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:52:01.641302
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    app_obj = ApparmorFactCollector()
    app_obj.collect()

# Generated at 2022-06-20 18:52:02.655464
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    result = apparmor.collect()

# Generated at 2022-06-20 18:52:11.646834
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:52:14.307627
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()


# Generated at 2022-06-20 18:52:23.458834
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import mock
    module = mock.Mock()
    module.params = {}
    module.params['collect_subset'] = []
    module.params['gather_subset'] = []
    module.params['filter'] = ['*.ignore']
    module.params['ansible_facts'] = {}

    fact_collector = ApparmorFactCollector()


# Generated at 2022-06-20 18:52:28.673635
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.fact_class == 'hardware'
    assert apparmor_facts.fact_subclass == 'Apparmor'
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()
    assert type(apparmor_facts.collect()) == dict
    assert 'apparmor' in apparmor_facts.collect()

# Generated at 2022-06-20 18:52:30.487012
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:52:33.173722
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    # test that instance did not change dict of classes
    assert len(ApparmorFactCollector._fact_ids) == 0

# Generated at 2022-06-20 18:52:36.376118
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_instance = ApparmorFactCollector()
    assert apparmor_fact_instance


# Generated at 2022-06-20 18:52:38.654968
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert len(apparmor_facts._fact_ids) == 0

# Generated at 2022-06-20 18:52:41.189860
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_result = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_fact_result

# Generated at 2022-06-20 18:52:42.942586
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:52:56.478843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:59.366924
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()


# Generated at 2022-06-20 18:53:01.018020
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFacts = ApparmorFactCollector()
    assert apparmorFacts.collect() == {}


# Generated at 2022-06-20 18:53:02.415020
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:53:06.091339
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:09.272282
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create the collector
    collector = ApparmorFactCollector()
    # collect with empty facts dict
    collected_facts = collector.collect({}, {})
    # check values in the collected facts
    assert collected_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:53:11.134431
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collect = ApparmorFactCollector()
    assert collect.name == 'apparmor'

# Generated at 2022-06-20 18:53:13.310650
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:53:15.911701
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:53:19.516276
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    apparmor_fc = ApparmorFactCollector()
    assert issubclass(ApparmorFactCollector, BaseFactCollector)
    apparmor_fc.collect()

# Generated at 2022-06-20 18:53:31.378314
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # Testing with path that doesn't exist
    apparmor_fact = ApparmorFactCollector()
    apparmor_fact.collect()

# Generated at 2022-06-20 18:53:33.514559
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    return

# Generated at 2022-06-20 18:53:36.985511
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    '''Check for constructor of ApparmorFactCollector'''
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:53:41.609671
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = ApparmorFactCollector(module, collected_facts)
    facts_dict = fact_collector.collect(module, collected_facts)

    apparmor_facts = facts_dict['apparmor']

    assert apparmor_facts['status'] == 'disabled'

# Generated at 2022-06-20 18:53:42.517802
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:53:45.209931
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert 'apparmor' in x._fact_ids

# Generated at 2022-06-20 18:53:49.185088
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_apparmorFactCollector = ApparmorFactCollector()
    test_facts_dict = test_apparmorFactCollector.collect()
    assert test_facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:52.817768
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:53:56.570862
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''Test method ansible.utils.apparmor_facts.ApparmorFactCollector.collect()'''
    afc = ApparmorFactCollector(None)

    assert afc.collect(None, None)



# Generated at 2022-06-20 18:53:57.329690
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-20 18:54:22.317275
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector.collect() == dict(apparmor=dict(status='disabled'))

# Generated at 2022-06-20 18:54:26.650014
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Tests if the method collect of class ApparmorFactCollector
    works properly
    """
    apparmor_facts_collector = ApparmorFactCollector()
    facts_dict = dict()
    return_value = apparmor_facts_collector.collect(collected_facts=facts_dict)
    assert return_value.get('apparmor')

# Generated at 2022-06-20 18:54:30.868225
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    print(apparmor_fact_collector.name)
    print(apparmor_fact_collector._fact_ids)
    print(apparmor_fact_collector.collect())


# Generated at 2022-06-20 18:54:32.750554
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()


# Generated at 2022-06-20 18:54:37.101124
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_fact_collected = apparmor_fact.collect()
    print(apparmor_fact_collected)
    #assert(apparmor_fact_collected == [{u'apparmor': {u'status': u'disabled'}}])
    # we should probably test for the 'enabled' result too

test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:54:41.597013
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ifh = open('/sys/kernel/security/apparmor', 'r')
    output = ifh.read()
    ifh.close()

    # Create mock module and facts
    mock_module = type('module', (object,), {})()
    mock_module.params = {}
    mock_facts = {}
    aafc = ApparmorFactCollector()

    # Create mock type for class BaseFactCollector
    mock_BaseFacts = type('BaseFactCollector', (object,),
                          {'collect.return_value': mock_facts})

    # When mock_BaseFacts exists in a module, the it will be used by the
    #   ApparmorFactCollector
    setattr(mock_module, 'BaseFactCollector', mock_BaseFacts)

    # Because the actual method will not be used, only

# Generated at 2022-06-20 18:54:44.130140
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector.name == 'apparmor')
    assert(ApparmorFactCollector._fact_ids == set())
    assert(ApparmorFactCollector.__doc__)


# Generated at 2022-06-20 18:54:44.870162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:54:55.217849
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hypervisors.apparmor import ApparmorFactCollector
    from collections import namedtuple

    # Mock os.path.exists() to return True
    def mock_path_exists(value):
        return True
    monkeypatch.setattr(os.path, 'exists', mock_path_exists)

    # Instantiate ApparmorFactCollector
    apparmorfacts_collector = ApparmorFactCollector()

    # Retrieve facts
    facts = apparmorfacts_collector.collect()

    # Test facts
    assert facts['apparmor']['status'] == 'enabled'



# Generated at 2022-06-20 18:54:58.496716
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor':
        {'status': 'disabled'}}

# Generated at 2022-06-20 18:55:54.467525
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {}
    # Apparmor is enabled
    apparmor_facts['status'] = 'enabled'

    facts_dict = {}
    facts_dict['apparmor'] = apparmor_facts
    # To check return value of of collect() method
    # of class ApparmorFactCollector
    assert ApparmorFactCollector().collect() == facts_dict

# Generated at 2022-06-20 18:55:55.687919
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:55:57.385439
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'
    assert x._fact_ids == set()

# Generated at 2022-06-20 18:55:57.900783
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:56:00.376552
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    if 'apparmor' not in apparmor_obj.name:
        assert 'apparmor' in apparmor_obj.name
    assert apparmor_obj._fact_ids == set()
    apparmor_obj.collect()

# Generated at 2022-06-20 18:56:02.296207
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts, ApparmorFactCollector)

# Generated at 2022-06-20 18:56:05.836272
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorCollect = ApparmorFactCollector()
    Apparmorstatus = {'apparmor': {'status': 'enabled'}}
    assert Apparmorstatus == apparmorCollect.collect()

# Generated at 2022-06-20 18:56:09.096448
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_test = {}
    collector = ApparmorFactCollector()
    result = collector.collect(None, facts_test)
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:56:11.836553
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-20 18:56:15.269780
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()
    assert 'apparmor' in fc.collect()

# Generated at 2022-06-20 18:58:23.514852
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()

    #ApparmorFactCollector is subclass of BaseFactCollector
    assert isinstance(apparmorFactCollector, BaseFactCollector)

    #ApparmorFactCollector class has variable name
    assert apparmorFactCollector.name == 'apparmor'

    #ApparmorFactCollector class has variable _fact_ids
    assert hasattr(apparmorFactCollector, '_fact_ids')
    assert isinstance(apparmorFactCollector._fact_ids, set)

    #ApparmorFactCollector class has method collect()
    assert hasattr(apparmorFactCollector, 'collect')
    assert callable(apparmorFactCollector.collect)


# Generated at 2022-06-20 18:58:28.147141
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # name: initialize ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()

# Unit test to test collect function of class ApparmorFactCollector

# Generated at 2022-06-20 18:58:34.739896
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Set collect method return value
    ApparmorFactCollector.collect = lambda self: {
        "component1": {"status": "enabled"},
        "component2": {"status": "disabled"}
    }

    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert "apparmor" in facts_dict
    assert "components" in facts_dict["apparmor"]
    assert facts_dict["apparmor"]["status"] == "enabled"

# Generated at 2022-06-20 18:58:36.977486
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:58:41.096853
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_Apparmorfact_collector = ApparmorFactCollector()
    assert isinstance(test_Apparmorfact_collector, ApparmorFactCollector)
    assert test_Apparmorfact_collector.name == 'apparmor'
    assert test_Apparmorfact_collector._fact_ids == set()


# Generated at 2022-06-20 18:58:45.167613
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    collected_facts = {}
    test_facts = collector.collect(collected_facts)
    assert test_facts == {}

# Generated at 2022-06-20 18:58:48.123399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict
    assert facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:58:51.396387
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create object for class ApparmorFactCollector
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-20 18:58:54.539206
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert type(apparmor_fact._fact_ids) is set
    assert apparmor_fact.name == 'apparmor'


# Generated at 2022-06-20 18:58:56.275927
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    assert afc.collect() == {'apparmor': {'status': 'disabled'}}