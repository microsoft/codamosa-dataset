

# Generated at 2022-06-20 18:51:04.070103
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfc = ApparmorFactCollector()
    assert apparmorfc.name == 'apparmor'
    assert apparmorfc._fact_ids == set()


# Generated at 2022-06-20 18:51:05.284303
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector()._fact_ids == set()

# Generated at 2022-06-20 18:51:09.286273
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:51:13.312251
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    apparmorFactCollector = ApparmorFactCollector()
    assert isinstance(apparmorFactCollector, ApparmorFactCollector)
    assert apparmorFactCollector._fact_ids == set()
    assert apparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:51:16.604143
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test that 'name' and '_fact_ids' are properly set in the constructor for ApparmorFactCollector"""
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()
    assert a.collect() == dict()

# Generated at 2022-06-20 18:51:18.856280
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert type(obj) == ApparmorFactCollector

# Generated at 2022-06-20 18:51:23.106260
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    fact_ids = set()
    fact_ids.add("apparmor")
    assert ApparmorFactCollector._fact_ids == fact_ids

# Generated at 2022-06-20 18:51:25.296911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fa = ApparmorFactCollector()
    module = None
    assert fa.collect(module) == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:27.709543
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:51:29.479627
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector


# Generated at 2022-06-20 18:51:34.132284
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert isinstance(apparmor_fact_collector._fact_ids, set)

# Generated at 2022-06-20 18:51:37.730094
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:51:44.310363
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test ApparmorFactCollector.collect
    """
    # Test with Apparmor enabled
    os.path.exists = lambda path: True
    a = ApparmorFactCollector()
    assert a.collect() == {'apparmor': {'status': 'enabled'}}
    # Test with Apparmor disabled
    os.path.exists = lambda path: False
    a = ApparmorFactCollector()
    assert a.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:46.824608
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 18:51:49.819838
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create a object of ApparmorFactCollector
    a = ApparmorFactCollector()
    assert isinstance(a, ApparmorFactCollector)
    assert isinstance(a.collect(), dict)

# Generated at 2022-06-20 18:51:53.526492
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    base_collector = BaseFactCollector(module)
    apparmor_fact_collector = ApparmorFactCollector(base_collector)

    assert(apparmor_fact_collector.name == 'apparmor')

# Generated at 2022-06-20 18:51:56.403301
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert len(afc._fact_ids) == 0

# Generated at 2022-06-20 18:52:01.903065
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    # check if apparmor is enabled
    apparmor_is_enabled = os.path.exists('/sys/kernel/security/apparmor')

    # collect facts
    facts_dict = FactsCollector().get_facts(None)

    # check if facts are collected properly
    assert facts_dict['apparmor']['status'] == 'enabled' if apparmor_is_enabled else 'disabled'

# Generated at 2022-06-20 18:52:05.554099
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Build test data structures
    base_collector = BaseFactCollector()
    apparmor_collector = ApparmorFactCollector()

    # Collect facts
    collected_facts = base_collector.collect(module=None,
                                             collected_facts=None)
    apparmor_facts = apparmor_collector.collect(module=None,
                                                collected_facts=collected_facts)

    # Assert the fact collection
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:52:08.999353
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert type(apparmor._fact_ids) is set
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:52:21.598261
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def fact_collect(self, module=None, collected_facts=None):
        facts_dict = {}
        apparmor_facts = {}
        if os.path.exists('/sys/kernel/security/apparmor'):
            apparmor_facts['status'] = 'enabled'
        else:
            apparmor_facts['status'] = 'disabled'

        facts_dict['apparmor'] = apparmor_facts
        return facts_dict

    ApparmorFactCollector_instance = ApparmorFactCollector()
    assert 'apparmor' in ApparmorFactCollector.collect(ApparmorFactCollector_instance)

# Generated at 2022-06-20 18:52:23.474467
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:52:26.898650
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    '''
    Unit test for constructor of class ApparmorFactCollector
    '''
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert 'apparmor' in apparmor_facts._fact_ids


# Generated at 2022-06-20 18:52:30.792623
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Tests that the correct apparmor facts are returned
    """
    afc = ApparmorFactCollector()
    output = afc.collect(None, None)
    assert 'apparmor' in output
    assert 'status' in output['apparmor']
    assert output['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:52:33.054327
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    This method tests the collect method of the ApparmorFactCollector
    """
    fact = ApparmorFactCollector()
    result = fact.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:39.120244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        # If true, apparmor is enabled
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}
    else:
        # If false, apparmor is disabled
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:41.026427
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorClass = ApparmorFactCollector()
    assert apparmorClass is not None
    assert apparmorClass._fact_ids is not None

# Generated at 2022-06-20 18:52:42.744757
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:52:45.241374
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    data = apparmor_fact_collector.collect()
    assert data['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:48.487328
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # TODO: this unit test is not yet complete. Need to mock the file reading to return different values
    af = ApparmorFactCollector()
    assert af.collect() == {}

# Generated at 2022-06-20 18:53:02.167832
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, ApparmorFactCollector)
    assert obj.name == "apparmor"
    assert 'apparmor' in obj._fact_ids


# Generated at 2022-06-20 18:53:05.482926
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert isinstance(apparmor, ApparmorFactCollector)
    assert isinstance(apparmor.name, str)
    assert isinstance(apparmor._fact_ids, set)

# Generated at 2022-06-20 18:53:08.160290
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result is not None
    assert result == {'apparmor': {'status': 'enabled'}}



# Generated at 2022-06-20 18:53:10.336956
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-20 18:53:16.674814
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import mock

    apparmor_facts = {'apparmor': {'status': 'disabled'}}

    with mock.patch('os.path.exists') as os_path_exists:
        os_path_exists.return_value = False
        apparmor_fact_col = ApparmorFactCollector()
        assert apparmor_fact_col.collect() == apparmor_facts

# Generated at 2022-06-20 18:53:18.546939
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    assert fc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:21.998700
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test AnsibleModule constructor"""
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'
    assert x._fact_ids == set()

# Generated at 2022-06-20 18:53:26.373154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_object = ApparmorFactCollector()
    collected_facts = {}
    expected = {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector_object.collect(collected_facts=collected_facts) == expected

# Generated at 2022-06-20 18:53:27.994415
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    assert test_obj
    assert test_obj.name == 'apparmor'

# Generated at 2022-06-20 18:53:38.194190
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Acquire a reference to the ApparmorFactCollector class
    apparmor_fact_collector = getattr(sys.modules[__name__], 'ApparmorFactCollector')
    # Create an instance
    apparmor_fact_collector_instance = apparmor_fact_collector()
    # Call method collect
    print(apparmor_fact_collector.collect())

# Collect and print facts
if __name__ == '__main__':
    # Acquire a reference to the ApparmorFactCollector class
    apparmor_fact_collector = getattr(sys.modules[__name__], 'ApparmorFactCollector')
    # Create an instance
    apparmor_fact_collector_instance = apparmor_fact_collector()

# Generated at 2022-06-20 18:54:01.212786
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:54:05.382974
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_facts = apparmor_fact.collect()
    assert isinstance(apparmor_facts, dict)
    assert 'apparmor' in apparmor_facts
    assert isinstance(apparmor_facts['apparmor'], dict)
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-20 18:54:10.844413
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_obj = ApparmorFactCollector()
    assert test_obj.name == "apparmor"
    assert test_obj._fact_ids == set()
    mock_module = "mock_module"
    mock_collected_facts = "mock_collected_facts"
    x = test_obj.collect(mock_module, mock_collected_facts)
    assert x == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:13.265701
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    ApparmorFactCollector(module=module, collected_facts=collected_facts)


# Generated at 2022-06-20 18:54:15.949031
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    facts = fc.collect()

    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] != ''

# Generated at 2022-06-20 18:54:17.208843
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    my_test = ApparmorFactCollector()
    assert my_test


# Generated at 2022-06-20 18:54:17.923688
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert(c.name == 'apparmor')

# Generated at 2022-06-20 18:54:20.957860
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = ApparmorFactCollector().collect()
    assert facts['apparmor']['status'] == 'disabled' or facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:54:23.752739
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert set(['apparmor']) == fc._fact_ids
    assert 'apparmor' in fc.collect().keys()

# Generated at 2022-06-20 18:54:27.983561
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    assert type(a.collect()) is dict
    assert len(a.collect()) == 1
    assert 'apparmor' in a.collect()
    assert type(a.collect()['apparmor']) is dict
    assert 'status' in a.collect()['apparmor']

# Generated at 2022-06-20 18:55:13.351790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansibleFacts = {}
    result = ApparmorFactCollector().collect(collected_facts=ansibleFacts) 
    assert isinstance(result, dict)

# Generated at 2022-06-20 18:55:15.717019
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fake_module = None
    c = ApparmorFactCollector(fake_module)
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-20 18:55:16.989769
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = ApparmorFactCollector()
    assert 'apparmor' in facts.collect()


# Generated at 2022-06-20 18:55:19.528015
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact = ApparmorFactCollector()
    assert fact.name == 'apparmor'
    assert fact._fact_ids == set()



# Generated at 2022-06-20 18:55:23.190676
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class_obj = ApparmorFactCollector()
    output = {'apparmor': {'status': 'enabled'}}
    assert class_obj is not None
    assert class_obj.collect() == output
    assert class_obj.name == 'apparmor'

# Generated at 2022-06-20 18:55:24.061567
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa = ApparmorFactCollector()
    aa.collect()


# Generated at 2022-06-20 18:55:25.481078
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:55:31.749489
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor', "__init__() should set name to 'apparmor'"
    assert (
        a.collect()['apparmor']['status'] == 'enabled' or
        a.collect()['apparmor']['status'] == 'disabled'), \
        'collect() should return the status of apparmor'

# Generated at 2022-06-20 18:55:34.199873
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_object = ApparmorFactCollector()
    assert apparmor_object.name == 'apparmor'


# Generated at 2022-06-20 18:55:36.476633
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'
    assert ApparmorFactCollector()._fact_ids == set()


# Generated at 2022-06-20 18:57:24.008761
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts_dict = {}
    apparmor_facts = {}

    # Test _get_apparmor_status - /sys/kernel/security/apparmor doesn't exist
    apparmor_facts['status'] = 'disabled'
    facts_dict['apparmor'] = apparmor_facts
    assert(ApparmorFactCollector.collect() == facts_dict)

# Generated at 2022-06-20 18:57:26.629772
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    collected_facts = {}
    facts_dict = collector.collect(collected_facts=collected_facts)
    assert collected_facts == facts_dict

# Generated at 2022-06-20 18:57:31.160910
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert issubclass(ApparmorFactCollector, BaseFactCollector)
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.collect() == {
        'apparmor': {
            'status': 'enabled'
         }
    }

# Generated at 2022-06-20 18:57:35.573763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect(module=None, collected_facts=None)
    print(apparmor_facts['apparmor'])
    assert apparmor_facts['apparmor'] is not None

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:57:37.766797
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()
    assert ac.name == 'apparmor'
    assert len(ac._fact_ids) == 0

# Generated at 2022-06-20 18:57:45.542580
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Populate a class instance for testing
    apparmor_fact_collector = ApparmorFactCollector()
    # Recall that the first 2 arguments are module, collected_facts
    # We will be passing in 2 mock objects, so we need to create a tuple
    # of 3 elements, with the first two being None, and the third being
    # an empty dictionary.
    args = (None, None, {})
    # Finally, invoke the collect method with the tuple of arguments `args`
    return_value = apparmor_fact_collector.collect(*args)
    # Assert that the dictionary returned has a key called `apparmor`
    assert('apparmor' in return_value)

# Generated at 2022-06-20 18:57:47.499937
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-20 18:57:50.179731
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-20 18:57:51.590974
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector

# Generated at 2022-06-20 18:57:52.373865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()