

# Generated at 2022-06-20 18:51:01.032202
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-20 18:51:03.724218
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc is not None
    assert aafc._fact_ids == set()

# Generated at 2022-06-20 18:51:04.357447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:51:11.546740
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_list = []
    for filename in os.listdir('/sys/kernel/security/'):
        file_list.append(filename)
    if 'apparmor' in file_list:
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:14.046183
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:51:16.247198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    facts_dict = aafc.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:20.706809
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfact = ApparmorFactCollector()
    apparmor_facts = apparmorfact.collect()
    assert type(apparmor_facts) is dict
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:51:23.259442
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:51:25.740962
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()


# Generated at 2022-06-20 18:51:27.793114
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:34.024759
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    if apparmor_fc.collect()['apparmor']['status'] == 'disabled':
        assert os.path.exists('/sys/kernel/security/apparmor') is False
    elif apparmor_fc.collect()['apparmor']['status'] == 'enabled':
        assert os.path.exists('/sys/kernel/security/apparmor') is True
    else:
        assert False

# Generated at 2022-06-20 18:51:40.908431
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import os

    class FakeModule(object):
        def fail_json(self, **kwargs):
            pass

    class FakeCollector(BaseFactCollector):
        def __init__(self):
            pass

        def set_module(self, module):
            pass

        def collect(self, module=None, collected_facts=None):
            pass

    fake_module = FakeModule()
    
    fake_collector = FakeCollector()
    fake_collector.set_module(module=fake_module)

    aafc = ApparmorFactCollector()
    aafc.set_module(module=fake_module)
    _result = aafc.collect()

    assert(isinstance(_result['apparmor'], dict))
   

# Generated at 2022-06-20 18:51:43.170278
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_apparmor_fact_collector = ApparmorFactCollector()
    assert test_apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-20 18:51:50.056770
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import collector

    collector.collectors['apparmor'] = ApparmorFactCollector()
    assert 'apparmor' in collector.collectors, "ApparmorFactCollector not registered"

    facts = collector.collectors['apparmor'].collect()
    assert 'apparmor' in facts, "Methods 'collect' does not fetch apparmor fact"
    assert facts['apparmor']['status'] in ['enabled','disabled'], "Methods 'collect' does not fetch apparmor fact"

# Generated at 2022-06-20 18:51:51.834499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor.collect()

# Generated at 2022-06-20 18:52:00.615582
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def get_file_content(self, path):
        return True

    ApparmorFactCollector.get_file_content = get_file_content
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()
    assert("enabled" == apparmorFactCollector.collect()['apparmor']['status'])

    def get_file_content(self, path):
        return False

    ApparmorFactCollector.get_file_content = get_file_content
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()
    assert("disabled" == apparmorFactCollector.collect()['apparmor']['status'])

# Generated at 2022-06-20 18:52:05.626965
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_mock = Mock()
    file_mock.exists.return_value = False
    file_mock.name = 'os'
    apparmor_module = imp.load_source('module', 'ansible.module_utils.facts.cloud.apparmor.apparmor')
    apparmor_module.os = file_mock

    x = ApparmorFactCollector()
    assert x.collect() == {'apparmor': {'status': 'disabled'}}

    file_mock.exists.return_value = True
    apparmor_module.os = file_mock
    assert x.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:52:08.700482
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFC = ApparmorFactCollector()
    assert 'apparmor' == apparmorFC.name
    assert 'apparmor' in apparmorFC._fact_ids


# Generated at 2022-06-20 18:52:11.456913
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector.priority == 6

# Generated at 2022-06-20 18:52:14.465575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test = ApparmorFactCollector()
    fact_list = test.collect()
    # Test for existence and type
    assert 'apparmor' in fact_list
    assert isinstance(fact_list['apparmor'], dict)

# Generated at 2022-06-20 18:52:24.836735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector
    """
    collect_method = ApparmorFactCollector().collect
    os_path_exists_method = os.path.exists
    os.path.exists = lambda path: True
    expected_return_value = {'apparmor': {'status': 'enabled'}}
    return_value = collect_method()
    assert return_value == expected_return_value
    os.path.exists = lambda path: False
    expected_return_value = {'apparmor': {'status': 'disabled'}}
    return_value = collect_method()
    os.path.exists = os_path_exists_method
    assert return_value == expected_return_value

# Generated at 2022-06-20 18:52:26.099033
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:52:30.635445
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        os.path.exists('')
        A = ApparmorFactCollector.collect()
        assert(A['apparmor']['status'] == 'enabled')
        assert(A['apparmor']['status'] != 'disabled')
    except:
        assert(False)



# Generated at 2022-06-20 18:52:32.318971
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:52:34.138160
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()
    assert 'apparmor' in facts_dict
    assert type(facts_dict['apparmor']) is dict

# Generated at 2022-06-20 18:52:36.632075
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None

# Generated at 2022-06-20 18:52:38.540649
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:52:39.708234
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect(module, collected_facts)

# Generated at 2022-06-20 18:52:43.040691
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']
    assert isinstance(apparmor_facts['apparmor']['status'], str)

# Generated at 2022-06-20 18:52:50.333605
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect(): # pylint: disable=invalid-name
    '''
    Test method collect of class ApparmorFactCollector
    '''
    fake_module = type('module', (object,), dict(params={}))
    fake_module.exit_json = lambda x: None
    # Run and get facts
    apparmor_facts = ApparmorFactCollector(fake_module).collect()
    # Check results
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-20 18:52:57.650920
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert (apparmor.name == 'apparmor')

# Generated at 2022-06-20 18:52:59.316010
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:53:09.307117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.collectors.apparmor import ApparmorFactCollector
    from ansible.module_utils._text import to_bytes
    
    # Create a object of CollectedFacts class
    # It will create a empty dictionary called ansible_facts in it
    collected_facts = CollectedFacts()

    # Create a object of ApparmorFactCollector class
    apparmor_collector = ApparmorFactCollector()

    # Call the collect method of class ApparmorFactCollector
    apparmor_collector.collect(collected_facts=collected_facts)

    # The ansible_facts dictionary after calling the collect method of ApparmorFactCollector method
    ansible_facts_dict = collected_facts.ansible_facts

    #

# Generated at 2022-06-20 18:53:11.917190
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'


# Generated at 2022-06-20 18:53:13.922664
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'


# Generated at 2022-06-20 18:53:17.460238
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()

    assert apparmor_fc.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-20 18:53:19.727198
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-20 18:53:25.134364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()

    # Assert that instance is created
    assert apparmorFactCollector is not None

    # Assert that the class attributes are initialized properly
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:53:28.573746
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:53:31.965410
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-20 18:53:45.110863
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector()
    assert isinstance(instance, ApparmorFactCollector)


# Generated at 2022-06-20 18:53:57.335344
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Unit test for method collect of class ApparmorFactCollector """

    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    # Initializing mock objects
    module = MagicMock()
    collected_facts = MagicMock()

    # Declaring variables
    test_apparmor_facts = {}

    if os.path.exists('/sys/kernel/security/apparmor'):
        test_apparmor_facts['status'] = 'enabled'
    else:
        test_apparmor_facts['status'] = 'disabled'

    # Creating a new instance of ApparmorFactCollector class
    apparmor_fact_collector = ApparmorFactCollector(module, collected_facts)



# Generated at 2022-06-20 18:54:00.592279
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect(module=None, collected_facts={})
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:02.666537
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    apparmor_facts = fact.collect()
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-20 18:54:04.739326
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:06.576823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:54:09.086619
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:54:10.183993
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:54:13.731839
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_obj = ApparmorFactCollector()
    result = ApparmorFactCollector_obj.collect()
    assert result['ansible_local']['apparmor']['status'] == 'disabled'



# Generated at 2022-06-20 18:54:15.322569
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 18:54:41.042662
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    print(apparmor_fact_collector.collect())

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:54:45.497427
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
if os.path.exists('/sys/kernel/security/apparmor'):
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}
else:
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:54:47.481155
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
   apparmor = ApparmorFactCollector()
   assert apparmor

# Generated at 2022-06-20 18:54:48.355781
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:54:49.925915
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:54:52.790705
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa = ApparmorFactCollector()
    assert aa.name == 'apparmor'
    assert aa._fact_ids == set()


# Generated at 2022-06-20 18:54:57.282972
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfac = ApparmorFactCollector()
    allfacts = apparmorfac.collect()
    assert 'apparmor' in allfacts
    assert 'status' in allfacts['apparmor']
    assert allfacts['apparmor']['status'] in ("enabled", "disabled")

# Generated at 2022-06-20 18:55:03.398442
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Creating instance of class ApparmorFactCollector
    apparmor_fact_collector_instance = ApparmorFactCollector()
    # Collecting facts from ApparmorFactCollector
    apparmor_facts = apparmor_fact_collector_instance.collect()
    # Assert that key 'apparmor' exists in apparmor_facts
    assert 'apparmor' in apparmor_facts
    # Assert that key 'status' exists in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-20 18:55:06.353212
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None


# Generated at 2022-06-20 18:55:07.675368
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-20 18:56:08.961071
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test function for method collect of class ApparmorFactCollector
    """
    aafc = ApparmorFactCollector()
    # test with enabled Apparmor
    aafc.collect()
    assert 'apparmor' in aafc.collect()

    # test with disabled Apparmor
    aafc.file_exists = False
    aafc.collect()
    assert not 'apparmor' in aafc.collect()

# Generated at 2022-06-20 18:56:11.180278
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()

# Generated at 2022-06-20 18:56:13.843021
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    acs = ApparmorFactCollector()
    acs.collect()
    afs = acs.collect()
    assert afs['apparmor']['status']

# Generated at 2022-06-20 18:56:18.908861
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfac = ApparmorFactCollector()
    testDict = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        testDict['status'] = 'enabled'
    else:
        testDict['status'] = 'disabled'
    if apparmorfac.collect() != {'apparmor': testDict}:
        raise


# Generated at 2022-06-20 18:56:21.264964
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_factcollector = ApparmorFactCollector()
    assert isinstance(apparmor_factcollector, ApparmorFactCollector)

# Generated at 2022-06-20 18:56:24.374930
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-20 18:56:27.623274
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    cls = ApparmorFactCollector()
    # Check if the instance has a name
    assert cls.name == 'apparmor'
    # Check if the instance has facts
    assert cls._fact_ids

# Generated at 2022-06-20 18:56:28.462218
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:56:29.626332
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == "apparmor"

# Generated at 2022-06-20 18:56:32.650235
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:58:38.654177
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'


# Generated at 2022-06-20 18:58:39.742942
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert type(ApparmorFactCollector().collect()) == dict

# Generated at 2022-06-20 18:58:40.582847
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  pass

# Generated at 2022-06-20 18:58:42.432375
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x


# Generated at 2022-06-20 18:58:48.191343
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}
    assert apparmor_fact_collector.get_fact_names() == {'apparmor'}
    assert apparmor_fact_collector.get_fact_ids() == set()

# Generated at 2022-06-20 18:58:53.760690
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ansible_collected_facts = {}
    apparmorfact_collector = ApparmorFactCollector()
    apparmorfact_collector.collect(None, ansible_collected_facts)
    apparmorfact_collector.__class__.__dict__
    assert hasattr(apparmorfact_collector, 'name')


# Generated at 2022-06-20 18:59:00.674558
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts import get_collection_name

    test_collection = get_collection_name('test_collection')

    TestCollection = ansible_collections.get_collection(test_collection)
    TestApparmorFactCollector = TestCollection.get_resource_class(
        'ansible.module_utils.facts',
        'ApparmorFactCollector')

    mock_module = {'_ansible_module_name': 'mock_module'}

    test_apparmor_fact_collector = TestApparmorFactCollector()
    test_apparmor_fact_collector.collect(module=mock_module)

    assert test_apparmor_fact_

# Generated at 2022-06-20 18:59:09.753683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    collected_facts = dict()
    module_mock = basic.AnsibleModule(argument_spec=dict())
    FactsCollector = collector.get_collector("apparmor")
    fact_collector = FactsCollector(module_mock, collected_facts)
    facts = fact_collector.collect()
    assert type(facts) == dict
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:59:14.222564
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    apparmor_facts = afc.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:59:15.493406
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector()