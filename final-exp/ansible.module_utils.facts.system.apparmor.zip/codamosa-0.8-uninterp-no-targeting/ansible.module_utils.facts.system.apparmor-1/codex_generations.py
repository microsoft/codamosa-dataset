

# Generated at 2022-06-20 18:51:02.240169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect()['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:51:05.551904
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result['apparmor']['status'] in ['enabled','disabled']

# Generated at 2022-06-20 18:51:07.604084
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    tester = ApparmorFactCollector()
    assert tester.name == 'apparmor'


# Generated at 2022-06-20 18:51:19.300961
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    test_class = type("TestClass", (BaseFactCollector, object), {})
    test_class.name = "test_collector"

    test_inst = ApparmorFactCollector()
    res = test_inst.collect()
    print("%s" % res)
    assert "apparmor" in res
    assert "status" in res["apparmor"]

    assert "test_collector" in FactCollector._COLLECTORS

# Generated at 2022-06-20 18:51:22.256516
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert not aafc._fact_ids

# Generated at 2022-06-20 18:51:31.755568
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    
    # Create instance of class ApparmorFactCollector
    apparmor_facts = ApparmorFactCollector()
    
    # Declare expected test output
    # On systems that do not have apparmor enabled, apparmor facts are absent
    expected_apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_apparmor_facts = dict(apparmor={'status': 'enabled'})
    else:
        expected_apparmor_facts = dict(apparmor={'status': 'disabled'})

    # Execute method collect of class ApparmorFactCollector
    actual_apparmor_facts = apparmor_facts.collect()
    
    # Check whether the expected output and actual output match
    assert actual_apparmor_facts == expected_apparmor_facts

# Generated at 2022-06-20 18:51:33.371773
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ("name", "apparmor", ApparmorFactCollector.name)
    assert ("fact_ids", set(), ApparmorFactCollector._fact_ids)

# Generated at 2022-06-20 18:51:35.253320
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:51:39.466657
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    #for testing we set the module name to dummy
    ApparmorFactCollector.name = "apparmor"

    # we create a test object of class ApparmorFactCollector and access the collect method
    test_obj = ApparmorFactCollector()
    # We have created a dummy file /sys/kernel/security/apparmor
    test_dict=test_obj.collect()
    assert test_dict['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:51:42.257161
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:51:48.069812
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert len(apparmor_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 18:51:50.652837
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect(collected_facts={}) == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-20 18:51:52.179698
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:51:54.169569
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:55.462363
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:51:57.886326
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector({})
    apparmor_facts = apparmor_fc.collect()
    assert apparmor_facts['apparmor']['status'] is not None

# Generated at 2022-06-20 18:52:00.243596
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  apparmor_fact_collector = ApparmorFactCollector()

  assert apparmor_fact_collector.name == 'apparmor'

# Test for method collect

# Generated at 2022-06-20 18:52:02.847185
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    res = fact_collector.collect()
    assert type(res) == dict
    assert 'apparmor' in res
    assert res['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:07.788075
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, ApparmorFactCollector)
    assert obj.name == "apparmor"
    assert obj._fact_ids == set()

# unit test for function collect of class ApparmorFactCollector

# Generated at 2022-06-20 18:52:11.550234
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initiate the object
    apparmor_obj = ApparmorFactCollector()
    # Check if the method collect returns correct value
    assert apparmor_obj.collect()['apparmor']['status'] == 'disabled'


# Generated at 2022-06-20 18:52:18.521817
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    instance = ApparmorFactCollector()
    output = instance.collect()
    assert output['apparmor']['status'] == 'enabled'


# Generated at 2022-06-20 18:52:19.878722
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect() != {}


# Generated at 2022-06-20 18:52:23.530714
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFC = ApparmorFactCollector
    assert apparmorFC.name == 'apparmor'
    assert apparmorFC._fact_ids == set()

# Generated at 2022-06-20 18:52:25.522687
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert (apparmor.name == 'apparmor')
    assert (apparmor._fact_ids == set())

# Generated at 2022-06-20 18:52:26.817244
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:52:30.407929
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfc = ApparmorFactCollector()
    apparmorfc._facts = {}
    apparmorfc._module = MockModule()
    apparmorfc._collect()
    assert apparmorfc._facts['apparmor']['status'] is not None

# Mock module class

# Generated at 2022-06-20 18:52:32.579584
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-20 18:52:38.023487
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert len(apparmor_collector._fact_ids) == 0

# Generated at 2022-06-20 18:52:39.167094
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"
    assert 'apparmor' in ApparmorFactCollector._fact_ids

# Generated at 2022-06-20 18:52:43.142266
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        result = fact_collector.collect()
        assert result['apparmor']['status'] == 'enabled'
    else:
        result = fact_collector.collect()
        assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:52:53.659555
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    # Assert that the facts_dict returned by collect has the key 'apparmor'
    assert apparmor_facts.get('apparmor')
    assert apparmor_facts['apparmor'].get('status')

# Generated at 2022-06-20 18:53:05.065760
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    with open('test_apparmor_collector.txt') as f:
        test_data = [x.strip() for x in f.readlines()]

    with open('test_apparmor_collector_out.txt') as f:
        test_data_out = [x.strip() for x in f.readlines()]

    test_data_bool = None
    if test_data[0] == '0':
        test_data_bool = False
    elif test_data[0] == '1':
        test_data_bool = True

    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect(collected_facts=None)
    result_dict = result.get('apparmor')

    test_result_dict = {}

# Generated at 2022-06-20 18:53:07.825428
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = AnsibleModuleMock('sys')
    apparmor = ApparmorFactCollector(module)
    result = apparmor.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:53:11.444251
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()


# Generated at 2022-06-20 18:53:12.889139
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert len(ApparmorFactCollector()._fact_ids) == 0


# Generated at 2022-06-20 18:53:18.428855
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Instantiate an instance of ApparmorFactCollector
    test_apparmor_factcollector = ApparmorFactCollector()
    # Call the method collect of class ApparmorFactCollector
    test_collect = test_apparmor_factcollector.collect()
    # Check whether the method collect returns a dictionary
    assert isinstance(test_collect, dict)

# Generated at 2022-06-20 18:53:23.960385
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_class_test = ApparmorFactCollector(None)
    assert apparmor_facts_class_test.name == 'apparmor'
    assert isinstance(apparmor_facts_class_test._fact_ids, set)
    assert 'apparmor' in apparmor_facts_class_test._fact_ids


# Generated at 2022-06-20 18:53:26.281291
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector_instance = ApparmorFactCollector()
    assert apparmor_collector_instance.name == 'apparmor'


# Generated at 2022-06-20 18:53:29.756113
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']
    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-20 18:53:33.326499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_collector = ApparmorFactCollector()
    assert apparmor_facts_collector.collect() == { 'apparmor' : {'status':'disabled'} }


# Generated at 2022-06-20 18:53:48.756011
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:51.284370
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-20 18:53:54.215066
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert getattr(ApparmorFactCollector, 'name') == 'apparmor'
    assert getattr(ApparmorFactCollector, '_fact_ids') == set()

# Generated at 2022-06-20 18:53:56.666085
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert len(ApparmorFactCollector._fact_ids) == 0

# Generated at 2022-06-20 18:54:01.730979
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = {}
    fc = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        result['apparmor'] = {'status': 'enabled'}
    else:
        result['apparmor'] = {'status': 'disabled'}
    assert fc.collect() == result

# Generated at 2022-06-20 18:54:04.632935
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:54:06.730390
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # execute the code to test
    apparmor_facts = ApparmorFactCollector().collect()
    # assert that the result from collect method is not empty
    assert apparmor_facts

# Generated at 2022-06-20 18:54:09.562173
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aaf = ApparmorFactCollector()
    apparmor_facts = aaf.collect()
    assert isinstance(apparmor_facts, dict)
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:18.107791
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import tempfile

    if not os.path.exists("/sys/kernel/security/apparmor"):
        # Create a temp directory.
        tmpdir = tempfile.mkdtemp()
        # Create a temp file.
        tmpfile = os.path.join(tmpdir, "apparmor")
        f = open(tmpfile, "w")
        f.close()
        # Expected value.
        result = { "apparmor": { "status": 'enabled' } }
        # Test
        apparmor = ApparmorFactCollector()
        assert result == apparmor.collect()
        # Remove the temp 
        os.remove(tmpfile)
        os.removedirs(tmpdir)

# Generated at 2022-06-20 18:54:19.933140
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()

    assert apparmor.name == 'apparmor'

# Generated at 2022-06-20 18:54:46.469990
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    name = apparmor_collector.name
    assert name == 'apparmor'


# Generated at 2022-06-20 18:54:49.474319
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-20 18:54:52.443432
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:54:58.288990
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    dirs = os.listdir('/sys/kernel')
    if 'security' in dirs:
        assert(ApparmorFactCollector().collect()['apparmor']['status'] == 'enabled')
    else:
        apparmor_facts = ApparmorFactCollector().collect()
        assert(apparmor_facts['apparmor']['status'] == 'disabled')

# Generated at 2022-06-20 18:55:05.370627
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_not_exists = {'path.exists':lambda path:path != '/sys/kernel/security/apparmor'}
    file_exists = {'path.exists':lambda path:path == '/sys/kernel/security/apparmor'}
    module = {}
    collected_facts = {}
    c = ApparmorFactCollector(module, collected_facts)
    c.collect(module, collected_facts)
    assert collected_facts['apparmor'] == {'status': 'disabled'}
    c.collect_mock = file_exists
    c.collect(module, collected_facts)
    assert collected_facts['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-20 18:55:13.980808
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_apparmor_module = ApparmorFactCollector()

    # Success case
    test_apparmor_module.collect_apparmor_facts = lambda : {'apparmor': {'status': 'enabled'}}
    result = test_apparmor_module.collect()
    assert result == {'apparmor': {'status': 'enabled'}}

    # Failure case
    test_apparmor_module.collect_apparmor_facts = lambda : {'status': 'disabled'}
    result = test_apparmor_module.collect()
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:55:16.798649
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Unit test for method collect of class ApparmorFactCollector
    '''
    apparmorFactCollectorObj = ApparmorFactCollector()
    collected_facts = {}
    assert apparmorFactCollectorObj.collect(collected_facts=collected_facts) == {}

# Generated at 2022-06-20 18:55:19.330888
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts._fact_ids, set)


# Generated at 2022-06-20 18:55:22.104643
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-20 18:55:24.194284
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_handler = ApparmorFactCollector()
    assert apparmor_handler.name == 'apparmor'
    assert apparmor_handler._fact_ids == set()

# Generated at 2022-06-20 18:56:21.736112
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"

# Generated at 2022-06-20 18:56:24.818868
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()



# Generated at 2022-06-20 18:56:28.064515
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_factCollector = ApparmorFactCollector()
    assert isinstance(apparmor_factCollector, ApparmorFactCollector)

#Unit test for method collect of class ApparmorFactCollector

# Generated at 2022-06-20 18:56:28.925567
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:56:38.039765
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()

    # Unit test 1
    # When /sys/kernel/security/apparmor exists
    # Result: apparmor_facts = { status: enabled }
    open('/sys/kernel/security/apparmor', 'a').close()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    os.remove('/sys/kernel/security/apparmor')

    # Unit test 2
    # When /sys/kernel/security/apparmor doesn't exist
    # Result: apparmor_facts = { status: disabled }
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:41.426917
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
        apparmor_status = ApparmorFactCollector.collect()
        if os.path.exists('/sys/kernel/security/apparmor'):
            assert apparmor_status['apparmor'] == {'status': 'enabled'}
        else:
            assert apparmor_status['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-20 18:56:48.774683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_fact_collector.collect()
    # status is enabled when /sys/kernel/security/apparmor exists
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts_dict['apparmor']['status'] == 'enabled'

    # status is disabled when /sys/kernel/security/apparmor does not exist
    else:
        assert apparmor_facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:50.871130
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    app_fact_collector_obj = ApparmorFactCollector()
    assert app_fact_collector_obj.name == 'apparmor'
    assert app_fact_collector_obj._fact_ids == set()



# Generated at 2022-06-20 18:56:55.228220
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    collected_facts = {}

    facts = afc.collect(collected_facts={})
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:56:58.115567
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor=ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert isinstance(apparmor._fact_ids, set)
    apparmor.collect()

# Generated at 2022-06-20 18:59:09.667255
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert ApparmorFactCollector().collect()['apparmor']['status'] == 'enabled'
    else:
        assert ApparmorFactCollector().collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:59:11.004869
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    result = ApparmorFactCollector()
    assert isinstance(result, ApparmorFactCollector)

# Generated at 2022-06-20 18:59:18.219609
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    output = apparmor_facts.collect()
    assert isinstance(output, dict)
    assert len(output) == 1
    assert 'apparmor' in output
    assert isinstance(output['apparmor'], dict)
    assert len(output['apparmor']) == 1
    assert 'status' in output['apparmor']

# Generated at 2022-06-20 18:59:21.144379
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:59:22.645127
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:59:26.858538
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 18:59:30.675430
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'


# Generated at 2022-06-20 18:59:32.451150
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    apparmor_facts = apparmor_fact.collect()

    assert apparmor_facts is not None, 'Failed to collect apparmor facts.'

# Generated at 2022-06-20 18:59:36.107961
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    arg = '/sys/kernel/security/apparmor'
    Collector = ApparmorFactCollector()

    assert Collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:59:43.304183
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create mock for module
    module = MagicMock()
    # Create instance of ApparmorFactCollector
    apparmor_collector = ApparmorFactCollector(module, 'ApparmorFactCollector')
    # mock open
    mock_open = mock_open(read_data='0')
    with patch('__builtin__.open', mock_open, create=True):
        # Execute collect method of ApparmorFactCollector
        apparmor_collector.collect()
        # Assert that python file was opened
        mock_open.assert_called_once_with('/sys/kernel/security/apparmor')