

# Generated at 2022-06-20 18:51:02.037507
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:51:05.051270
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:51:08.729841
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # Test collector is not none
    assert ApparmorFactCollector is not None

    # Test collector name
    assert ApparmorFactCollector.name == "apparmor"


# Generated at 2022-06-20 18:51:11.249594
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector_class = ApparmorFactCollector()
    assert collector_class.name == 'apparmor'
    assert collector_class._fact_ids == set()

# Generated at 2022-06-20 18:51:12.952983
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert type(facts['apparmor']) is dict

# Generated at 2022-06-20 18:51:14.548340
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    facts_dict = c.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-20 18:51:16.416926
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    print(apparmor_fact_collector.collect())


# Generated at 2022-06-20 18:51:20.037111
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

test_ApparmorFactCollector()

# Generated at 2022-06-20 18:51:22.027151
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert not a._fact_ids

# Generated at 2022-06-20 18:51:25.202564
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_instance = ApparmorFactCollector()
    apparmor_facts = ApparmorFactCollector_instance.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:29.528448
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:51:37.250023
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    aafc = ApparmorFactCollector()

    class MockModule(object):
        pass

    test_module = MockModule()
    if os.path.exists('/sys/kernel/security/apparmor'):
        result = {
            'ansible_facts': {
                'apparmor': {
                    'status': 'enabled'
                }
            }
        }
    else:
        result = {
            'ansible_facts': {
                'apparmor': {
                    'status': 'disabled'
                }
            }
        }
    assert result == aafc.collect(test_module)

# Generated at 2022-06-20 18:51:39.197075
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect()
    assert result == {'apparmor':{'status':'disabled'}}

# Generated at 2022-06-20 18:51:40.856796
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-20 18:51:43.534021
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparm = ApparmorFactCollector()
    assert apparm.name == "apparmor"
    assert apparm._fact_ids == set()


# Generated at 2022-06-20 18:51:50.740617
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    import json
    import os

    # Test default constructor
    apparmor_fact_collector = ApparmorFactCollector()

    assert isinstance(apparmor_fact_collector.name, str)

    assert isinstance(apparmor_fact_collector._fact_ids, set)

    assert os.path.exists('/sys/kernel/security/apparmor')

    apparmor_facts = apparmor_fact_collector.collect()

    assert isinstance(apparmor_facts, dict)

    assert json.dumps(apparmor_facts)

# Generated at 2022-06-20 18:51:53.465575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    result = apparmor_facts.collect()
    assert result['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-20 18:52:01.312697
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    file_mock = ApparmorFactCollector._module.File
    module_mock = ApparmorFactCollector._module
    file_mock.hash_sums = {
        '/sys/kernel/security/apparmor': ('0', '0')
    }
    module_mock.exists.return_value = True
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}

    # test when apparmor is disabled
    module_mock.exists.return_value = False
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:02.655045
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector.priority == 8

# Generated at 2022-06-20 18:52:05.134352
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts_result = apparmor_facts.collect()
    # Check if facts is dict
    assert isinstance(apparmor_facts_result, dict)

    # Check if apparmor facts is present
    assert 'apparmor' in apparmor_facts_result

# Generated at 2022-06-20 18:52:14.750546
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }
    collector._module = {
        'get_bin_path': lambda x, required=False: '/bin/ls',
        'run_command': lambda x, check_rc=True: (
            0, '/path/to/binary', '')
    }
    assert collector.collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }

# Generated at 2022-06-20 18:52:18.026782
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)


# Generated at 2022-06-20 18:52:19.033534
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None

# Generated at 2022-06-20 18:52:24.467789
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    os.environ['ANSIBLE_FACTS_CACHE_PLUGIN'] = __name__ + '.' + ApparmorFactCollector.collect.__name__
    os.environ['ANSIBLE_FACTS_CACHE_PLUGIN_CONNECTION'] = ''
    os.environ['ANSIBLE_FACTS_CACHE_PLUGIN_PERSISTENT'] = 'False'
    facts_dict = ApparmorFactCollector().collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:27.185087
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:52:29.485895
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:52:33.590392
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result_dict = apparmor_fact_collector.collect()
    assert isinstance(result_dict, dict)
    assert list(result_dict.keys()) == ['apparmor']
    assert isinstance(result_dict['apparmor'], dict)
    assert sorted(list(result_dict['apparmor'].keys())) == ['status']

# Generated at 2022-06-20 18:52:37.262156
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
   collector =  ApparmorFactCollector()
   facts = collector.collect()
   assert 'apparmor' in facts
   assert 'status' in facts['apparmor']

# Generated at 2022-06-20 18:52:38.523544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ApparmorFactCollector = ApparmorFactCollector()
    test_dict = test_ApparmorFactCollector.collect()
    assert ('apparmor' in test_dict)

# Generated at 2022-06-20 18:52:41.086257
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  ap = ApparmorFactCollector()
  assert ap.name == 'apparmor'
  assert isinstance(ap._fact_ids, set)
  assert not ap._fact_ids


# Generated at 2022-06-20 18:52:50.684431
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_collector_instance = ApparmorFactCollector()
    apparmor_facts_collector_instance.collect()
    collected_facts = apparmor_facts_collector_instance.collect()
    assert collected_facts

# Generated at 2022-06-20 18:52:53.862305
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # empty set for fact_ids
    assert ApparmorFactCollector._fact_ids == set()

    # name of class is apparmor
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:52:56.432723
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:58.195107
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor.collect()
    assert apparmor.name == 'apparmor'

# Generated at 2022-06-20 18:53:01.352683
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:53:06.091218
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts['apparmor']['status'] == 'enabled'
    else:
        assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:53:06.871349
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector([], None)

    assert fc.name == 'apparmor'

# Generated at 2022-06-20 18:53:09.144908
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector



# Generated at 2022-06-20 18:53:12.093557
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert type(apparmor_fact_collector).__name__ == 'ApparmorFactCollector'


# Generated at 2022-06-20 18:53:17.544750
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Test the collect() function of class ApparmorFactCollector

# Generated at 2022-06-20 18:53:30.817093
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == 'apparmor'


# Generated at 2022-06-20 18:53:42.202578
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # GIVEN a collector object and a path to the apparmor kernel module
    # when os.path.exists returns False
    module = MockAnsibleModule()
    path_exists_mock = MockReturnFalse()
    collector = ApparmorFactCollector(module)

    # WHEN the collect method is executed
    facts_obtained = collector.collect()

    # THEN the following should be returned
    facts_expected = {'apparmor': {'status': 'disabled'}}
    path_exists_mock.assert_called_once_with('/sys/kernel/security/apparmor')
    module.exit_json.assert_called_once_with(ansible_facts=facts_expected)
    # and the facts are returned
    assert facts_obtained == facts_expected



# Generated at 2022-06-20 18:53:44.514979
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:53:47.949300
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collectors.system.apparmor import ApparmorFactCollector
    obj = ApparmorFactCollector()
    obj.collect()

# Generated at 2022-06-20 18:53:48.610269
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-20 18:53:53.950500
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {'status': 'disabled'}
    module = True
    collected_facts = True
    a = ApparmorFactCollector
    a._fact_ids = set()
    aa = a.collect(module=module, collected_facts=collected_facts)
    assert aa == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:57.884793
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    os.path.exists = Mock(return_value=True)
    facts = collector.collect()
    assert facts.get('apparmor').get('status') == 'enabled'


# Generated at 2022-06-20 18:54:01.026946
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert facts['apparmor']
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-20 18:54:01.586643
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:54:03.276177
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == "apparmor"


# Generated at 2022-06-20 18:54:27.651735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    source = ApparmorFactCollector()
    source.collect()
    return

# Generated at 2022-06-20 18:54:30.320267
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    result = apparmor.collect()

    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:32.201538
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == "apparmor"
    assert c._fact_ids == set()


# Generated at 2022-06-20 18:54:33.472173
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    obj.collect()

# Generated at 2022-06-20 18:54:36.212604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect(None, None)
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:54:39.597741
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = {'apparmor': {'status': 'enabled'}}
    assert apparmor_facts == apparmor_fact_collector.collect(module=None, collected_facts=collected_facts)

# Generated at 2022-06-20 18:54:41.652872
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:54:43.474967
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:54:45.906168
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()

    # Check status
    assert result['apparmor']
    assert result['apparmor']['status']

# Generated at 2022-06-20 18:54:51.078376
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_collector = ApparmorFactCollector()
    assert apparmor_facts_collector
    assert apparmor_facts_collector.name == 'apparmor'
    assert apparmor_facts_collector._fact_ids == set()
    assert apparmor_facts_collector._collected_facts == {}

# Generated at 2022-06-20 18:55:46.388383
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    host_vars_file = 'host_vars/' + 'localhost.yaml'
    aafc = ApparmorFactCollector()
    aafc.collect(module=None, collected_facts=None)
    assert aafc.name == 'apparmor'

# Generated at 2022-06-20 18:55:51.176183
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fac = ApparmorFactCollector()
    assert fac.name == 'apparmor'
    assert not fac.fact_names
    fac.name = 'foo'
    fac.fact_names = 'a,b,c'
    fact_dict = fac.collect()
    assert fact_dict == {'foo': {'fact_names': 'a,b,c'}}


if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-20 18:55:54.900038
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == "apparmor"
    assert ApparmorFactCollector()._fact_ids == set()


# Generated at 2022-06-20 18:56:01.034854
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create ApparmorFactCollector instance
    collected_facts = FactCollector()
    apparmor_fact_collector = get_collector_instance(ApparmorFactCollector, collected_facts)

    # test collect method
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:05.187096
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    apparmor_facts = fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    apparmor_facts = apparmor_facts['apparmor']
    assert 'status' in apparmor_facts

# Generated at 2022-06-20 18:56:09.941042
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:56:10.497190
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:56:11.904713
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()


# Generated at 2022-06-20 18:56:15.018666
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    _collector = ApparmorFactCollector()
    apparmor_facts = _collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:56:17.516729
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()


# Generated at 2022-06-20 18:58:21.272867
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()

    attrs = dir(apparmor_obj)

    assert 'name' in attrs
    assert 'collect' in attrs
    assert '_fact_ids' in attrs
    assert '_platform' in attrs
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()
    assert isinstance(apparmor_obj._fact_ids, set)

# Generated at 2022-06-20 18:58:23.577828
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids is not None


# Generated at 2022-06-20 18:58:26.604403
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()

    assert x._fact_ids is not None
    assert x.name == 'apparmor'


# Generated at 2022-06-20 18:58:27.670843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    print(collector.collect())

# Generated at 2022-06-20 18:58:29.911624
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-20 18:58:33.621823
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_module = object()
    fake_collected_facts = object()
    fake_facts_dict = {'apparmor': {'status': 'enabled'}}
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect(fake_module, fake_collected_facts) == fake_facts_dict

# Generated at 2022-06-20 18:58:37.761605
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    os.path.exists = lambda x: True
    assert collector.collect() == {
        'apparmor': {'status': 'enabled'}
    }
    os.path.exists = lambda x: False
    assert collector.collect() == {
        'apparmor': {'status': 'disabled'}
    }

# Generated at 2022-06-20 18:58:40.328659
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result['apparmor']['status'] == 'enabled', result

# Generated at 2022-06-20 18:58:43.206538
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  apparmor = ApparmorFactCollector()
  assert apparmor.name == 'apparmor'
  assert apparmor._fact_ids == {'apparmor'}

# Generated at 2022-06-20 18:58:48.554509
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    '''
    Unit test for constructor of class ApparmorFactCollector
    :return:
    '''
    from ansible.module_utils.facts.collector import BaseFactCollector
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts, BaseFactCollector)
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()
