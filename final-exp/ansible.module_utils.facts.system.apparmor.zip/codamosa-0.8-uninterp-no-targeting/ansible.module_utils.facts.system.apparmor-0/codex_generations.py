

# Generated at 2022-06-20 18:51:01.651443
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'



# Generated at 2022-06-20 18:51:06.685789
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_collected_facts = {}
    apparmor_fact_collector = ApparmorFactCollector()
    result_dict = apparmor_fact_collector.collect(collected_facts=fake_collected_facts)
    assert isinstance(result_dict, dict)
    assert isinstance(result_dict['apparmor'], dict)
    assert isinstance(result_dict['apparmor']['status'], str)

# Generated at 2022-06-20 18:51:14.629627
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._cache = {}
    apparmor_facts = apparmor_fact_collector.collect()
    assert type(apparmor_facts) is dict
    assert 'apparmor' in apparmor_facts

    apparmor = apparmor_facts.get('apparmor')
    assert type(apparmor) is dict
    assert 'status' in apparmor
    assert apparmor.get('status') in ['disabled', 'enabled']

# Generated at 2022-06-20 18:51:16.502264
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    assert f.collect()['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 18:51:19.668665
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collect = ApparmorFactCollector().collect
    assert collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }

# Generated at 2022-06-20 18:51:21.317848
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test empty
    ApparmorFactCollector(None)


# Generated at 2022-06-20 18:51:25.298791
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    collected_facts = fact_collector.collect(module=None, collected_facts=None)
    expected_facts = {'apparmor': {'status': 'enabled'}}
    assert collected_facts == expected_facts

# Generated at 2022-06-20 18:51:26.582328
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)


# Generated at 2022-06-20 18:51:28.624137
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  collector = ApparmorFactCollector()
  assert collector.collect() == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-20 18:51:30.899303
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:37.726411
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test collect method of class ApparmorFactCollector.
    """
    os.path.exists = MagicMock(return_value='True')
    apparmor_obj = ApparmorFactCollector()
    apparmor_obj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-20 18:51:48.707770
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Dummy class for setting value of     path_prefix
    class DummyOpts(object):
        def __init__(self):
            self.path_prefix = "ansible/module_utils/facts/collector/"
    import imp
    # Instantiating class to test its method collect
    mod = imp.load_source("somename", "./ansible/module_utils/facts/collector/apparmor.py")
    apparmor_fc = mod.ApparmorFactCollector(DummyOpts())
    # Stubbing values returned by os.path.exists("/sys/kernel/security/apparmor")
    from unittest.mock import Mock, patch
    os_path_exists = patch("ansible.module_utils.facts.collector.apparmor.os.path.exists")
    mocked_os_

# Generated at 2022-06-20 18:51:50.780694
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    cf = ApparmorFactCollector()
    assert cf.name == 'apparmor'
    assert len(cf._fact_ids) == 0


# Generated at 2022-06-20 18:51:54.337462
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    clsmembers = ApparmorFactCollector.get_clsmembers()
    clsmembers['apparmor'] = ApparmorFactCollector()
    assert clsmembers['apparmor'].name == 'apparmor'


# Generated at 2022-06-20 18:52:00.368009
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    import ansible.module_utils.facts.collector

    base_collector = ansible.module_utils.facts.collector.BaseFactCollector
    assert issubclass(ApparmorFactCollector, base_collector), "ApparmorFactCollector should subclass BaseFactCollector class"
    assert ApparmorFactCollector.name == 'apparmor', "ApparmorFactCollector.name should be equal to 'apparmor'"

# Unit test to testing collect method of class ApparmorFactCollector

# Generated at 2022-06-20 18:52:03.884790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    path = os.path.join(os.path.dirname(__file__), '../../../../')
    basedir = "file://%s/test/unit/module_utils/ansible_collections/ansible/community" % path
    facts = ApparmorFactCollector(basedir).collect()
    assert facts['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-20 18:52:06.256783
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    gfc = ApparmorFactCollector()
    assert gfc.collect() == {'apparmor': {}}

# Generated at 2022-06-20 18:52:10.601057
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    apparmor_collector_instance = get_collector_instance(ApparmorFactCollector)
    response = apparmor_collector_instance.collect()
    assert 'apparmor' in response

# Generated at 2022-06-20 18:52:13.158119
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-20 18:52:14.917811
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    myClass = ApparmorFactCollector()
    assert myClass.name == 'apparmor'


# Generated at 2022-06-20 18:52:23.530430
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector.name

# Generated at 2022-06-20 18:52:26.137649
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert not apparmor_fact_collector._fact_ids

# Generated at 2022-06-20 18:52:29.044505
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-20 18:52:30.214590
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-20 18:52:32.070968
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    m = ApparmorFactCollector()
    assert m.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:52:33.580946
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-20 18:52:37.642018
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:52:40.085989
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name
    # TODO: assert that _fact_ids is populated
    #assert True == ApparmorFactCollector._fact_ids



# Generated at 2022-06-20 18:52:41.623752
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:52:43.792560
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-20 18:53:00.010412
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    def mock_os_path_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True

    collector.get_file_content = lambda filename: ''
    collector.exec_command = lambda command, sudoable: ''
    collector.exists_executable = lambda executable: False
    collector.get_file_lines = lambda filename: []
    collector.check_file_is_link = lambda filename: True
    collector.get_mount_size = lambda mount_point: '0'
    collector.get_mount_device = lambda mount_point: 'test_device'
    collector.get_mount_options = lambda mount_point: 'test_options'
    collector.get_mount_path = lambda mount_point: 'test_mount_path'

# Generated at 2022-06-20 18:53:00.916605
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-20 18:53:04.639049
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:53:10.790306
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    Collector._fact_collectors = []
    Collector._fact_collectors.append(PlatformFactCollector)
    Collector._fact_collectors.append(ApparmorFactCollector)

    # collect all facts
    facts_dict = Collector.collect(None, None)

    # test if apparmor is present in the facts
    assert 'apparmor' in facts_dict

# Generated at 2022-06-20 18:53:17.377413
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts.name, str)
    assert apparmor_facts.name == 'apparmor'
    assert isinstance(apparmor_facts._fact_ids, set)
    assert len(apparmor_facts._fact_ids) == 0
    assert apparmor_facts._fact_ids == set()
    assert callable(apparmor_facts.collect)

# Generated at 2022-06-20 18:53:19.151892
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:53:23.299037
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    my_obj = ApparmorFactCollector(None)
    assert my_obj.name == 'apparmor'
    assert my_obj.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:53:26.737351
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert (isinstance(x, BaseFactCollector))
    assert (not hasattr(x, "name"))
    assert (hasattr(x, "_fact_ids"))


# Generated at 2022-06-20 18:53:29.033038
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    status = fact_collector.collect()['apparmor']['status']
    assert status == 'disabled' or status == 'enabled'

# Generated at 2022-06-20 18:53:35.043375
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create object of ApparmorFactCollector
    apparmor_test_obj = ApparmorFactCollector()

    # Call method collect of ApparmorFactCollector
    apparmor_test_obj.collect()

    # Variable to store the return value of method collect
    apparmor_test_val = apparmor_test_obj.collect()

    # Assertion to check the output of collect method for ApparmorFactCollector
    assert apparmor_test_val is not None

# Generated at 2022-06-20 18:53:48.609771
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_factcollector = ApparmorFactCollector()
    assert apparmor_factcollector.name == 'apparmor'
    assert apparmor_factcollector._fact_ids == set()


# Generated at 2022-06-20 18:53:54.651121
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    os.path.exists = Mock(return_value=True)
    facts_dict = afc.collect()
    assert facts_dict['apparmor']['status'] == 'enabled'
    os.path.exists = Mock(return_value=False)
    facts_dict = afc.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:03.968598
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import mock

    aaf = ApparmorFactCollector()
    if hasattr(aaf, '_collect'):
        aaf._collect()

    with mock.patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        aaf.collect()
        mock_exists.assert_called_once_with('/sys/kernel/security/apparmor')

    with mock.patch('os.path.exists') as mock_exists:
        mock_exists.return_value = False
        aaf.collect()
        mock_exists.assert_called_once_with('/sys/kernel/security/apparmor')

# Generated at 2022-06-20 18:54:05.239750
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    afc.collect()

# Generated at 2022-06-20 18:54:14.031176
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Unit test for method collect of class ApparmorFactCollector """

    # Create an instance of argument spec
    argument_spec = dict(
        gather_subset=dict(default=['!all'], type='list')
    )

    # initialize the ansible module
    module = AnsibleModule(argument_spec=argument_spec)

    # Create an instance of ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector(module=module)

    # Collect Apparmor facts
    apparmor_facts = apparmor_fact_collector.collect()

    # Assert method collect of class ApparmorFactCollector
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:54:16.600076
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_collector = ApparmorFactCollector()
    assert test_collector.name == 'apparmor'
    assert len(test_collector._fact_ids) == 0


# Generated at 2022-06-20 18:54:18.767598
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()


# Generated at 2022-06-20 18:54:29.879873
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector

    class MyApparmorFactCollector(ApparmorFactCollector):
        def __init__(self, module=None, collected_facts=None):
            pass

        def collect(self, module=None, collected_facts=None):
            return {}

    collector = MyApparmorFactCollector()

    # first, test when apparmor is not available
    # in order to do that, we have to mock os module
    with pytest.raises(RuntimeError) as exc_info:
        collector.collect()
    assert 'Unable to get Apparmor facts' in str(exc_info.value)

    # now, test when function

# Generated at 2022-06-20 18:54:32.354395
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Run the collect method to collect facts for file system
    """
    apparmor = ApparmorFactCollector()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']

# Generated at 2022-06-20 18:54:35.941218
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = {}
    factCollector = ApparmorFactCollector(facts, None)

    assert factCollector.name == 'apparmor'
    assert factCollector._fact_ids == set()
    assert sorted(factCollector.collect()) == sorted({'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-20 18:54:58.805433
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector_class = ApparmorFactCollector()
    collected_facts = collector_class.collect()
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:55:00.359658
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == 'apparmor'

# Generated at 2022-06-20 18:55:03.110176
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert isinstance(apparmor_collector.collect(), dict)

# Generated at 2022-06-20 18:55:06.594154
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Unit test to verify if the constructor of class ApparmorFactCollector works properly"""
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"

# Generated at 2022-06-20 18:55:09.576399
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:55:15.317374
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = type('Module', (object,), {'exit_json': None})
    input_params = {'gather_subset': ['all']}
    setattr(module, 'params', input_params)
    c = ApparmorFactCollector()
    collected_facts = {}
    collected_facts = c.collect(module=module, collected_facts=collected_facts)
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:55:16.342813
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collect = ApparmorFactCollector()
    assert collect.name == 'apparmor'

# Generated at 2022-06-20 18:55:17.988486
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert [x.__name__ for x in ApparmorFactCollector.__bases__] == ['BaseFactCollector']
    assert 'apparmor' in ApparmorFactCollector.name

# Generated at 2022-06-20 18:55:19.900968
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-20 18:55:23.191178
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_module = ApparmorFactCollector(module=None, collected_facts=None)
    assert fact_module.name == 'apparmor'
    assert fact_module._fact_ids == set()


# Generated at 2022-06-20 18:56:11.431965
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'


# Generated at 2022-06-20 18:56:13.028822
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    m = ApparmorFactCollector()
    assert m.collect()['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-20 18:56:16.261087
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)


# Generated at 2022-06-20 18:56:18.335381
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:56:27.703852
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test ApparmorFactCollector.collect()"""
    # Get a ApparmorFactCollector object
    apparmor_fc = ApparmorFactCollector()
    # Call method collect of the object
    apparmor_fact = apparmor_fc.collect()
    # Test if method returned dictionary
    assert isinstance(apparmor_fact, dict), "ApparmorFactCollector.collect() did not return a dictionary"
    # Test if method returned valid dictionary
    assert (apparmor_fact.get('apparmor') and isinstance(apparmor_fact.get('apparmor'), dict)) or apparmor_fact.get('apparmor') is None, "ApparmorFactCollector.collect() did not returned valid dictionary"

# Generated at 2022-06-20 18:56:29.197688
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-20 18:56:31.989098
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'
    assert ApparmorFactCollector()._fact_ids == set()


# Generated at 2022-06-20 18:56:33.989821
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None


# Generated at 2022-06-20 18:56:38.368526
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of the class being tested
    test_obj = ApparmorFactCollector()

    # Create a fake module object with a fake ansible.module_utils.facts.module.BaseFactCollector.
    # This is for the purpose of making it easy to test a function that uses the 'module' object.
    module = type('module', (object,), {'exit_json': lambda self, **kwargs: None})()
    module.params = {}

    # Create a fake ansible.module_utils.facts.module.BaseFactCollector object to be used by the class being tested
    base_fact_collector = type('base_fact_collector', (object,), {})()

    # Return the result of ansible.module_utils.facts.module.BaseFactCollector.populate_facts

# Generated at 2022-06-20 18:56:40.093221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfacts = ApparmorFactCollector()
    assert apparmorfacts.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:58:33.506055
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create an instance of ApparmorFactCollector
    collector = ApparmorFactCollector()
    # check if the name of collector returned by the collect method matches the name of collector
    assert collector.name == collector.collect()['ansible_facts']['apparmor']['ansible_collector']
    # check if the status key does not exists in the ansible_facts
    assert 'ansible_apparmor_status' not in collector.collect()['ansible_facts']

# Generated at 2022-06-20 18:58:35.548130
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    assert aafc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-20 18:58:43.057241
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    class TestApparmorFactCollector(ApparmorFactCollector):
        def __init__(self):
            self._path_exists = False

        def _path_exists(self, path):
            return self._path_exists

    # Test disabled case
    tafc = TestApparmorFactCollector()
    assert tafc.colect() == {}

    # Test enabled case
    tafc._path_exists = True
    assert tafc.collect() == {"apparmor": {"status": "enabled"}}

# Generated at 2022-06-20 18:58:46.320835
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    aafctest = aafc.collect()

# Generated at 2022-06-20 18:58:50.626707
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result['ansible_local']['apparmor']['status'] is not None

# Generated at 2022-06-20 18:58:53.411112
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-20 18:58:56.425882
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
  This can be used to test the method collect of this class
  """
    fc = ApparmorFactCollector()
    assert fc.collect(_module=None, collected_facts=None) == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-20 18:58:57.515308
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)


# Generated at 2022-06-20 18:59:00.391146
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class Module:
        def __init__(self, **kwargs):
            self.params = kwargs
            
    fact_collector = ApparmorFactCollector(Module(min_facts_to_gather=0))
    facts = fact_collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-20 18:59:01.565627
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()