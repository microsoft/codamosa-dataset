

# Generated at 2022-06-17 01:34:48.529557
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:34:51.785966
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:34:54.990750
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:34:59.447305
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:01.298809
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()


# Generated at 2022-06-17 01:35:05.161375
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:07.910291
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:12.355935
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:15.655825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:18.687923
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:35:25.300470
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:28.249939
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:35:33.147499
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:35:36.354465
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:35:39.754901
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:43.161851
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:46.374141
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:49.547471
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:51.613099
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:35:53.092509
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:57.669096
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:01.035610
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:36:05.660923
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:36:10.279248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:12.789898
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:17.444348
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:20.280764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:23.236771
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:27.244749
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:29.985852
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:38.029133
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:36:40.405793
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:36:42.840330
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:45.382046
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:36:48.238467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:51.036397
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:36:54.211170
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:57.952873
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:01.881592
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:37:06.887410
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:37:21.705187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:26.873344
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:30.416999
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:36.168239
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:39.447062
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:44.312001
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:47.976476
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:49.959761
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:37:52.546741
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:55.756979
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:19.722187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:24.297722
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:27.350370
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:32.924224
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:35.953063
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:41.303906
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:44.421854
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:47.485713
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:38:50.070748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:55.306996
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:44.584248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:47.544041
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:52.241224
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:39:55.473538
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:40:00.570748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:40:05.400613
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:40:10.254734
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:40:14.393568
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:40:17.025111
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:40:20.594001
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:42:08.002614
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:42:11.486368
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:42:16.656907
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:42:19.692983
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:42:21.959978
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:42:23.951825
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:42:25.947989
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:42:28.479216
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:42:34.509158
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:42:38.467943
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'