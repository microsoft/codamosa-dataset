

# Generated at 2022-06-17 01:34:50.087851
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:34:53.155531
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:34:56.340688
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:35:00.399016
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:04.684399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:09.426880
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:35:11.983277
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:15.382423
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:18.279182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:35:20.200292
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:27.092740
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:29.199254
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:34.937347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:38.001162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:42.441624
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:45.931305
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:47.643099
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:50.613596
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:53.246549
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:54.874768
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:36:04.257378
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:06.719332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:36:11.013628
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:13.408033
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:18.524461
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:21.260771
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:25.365662
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:28.239826
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:31.383585
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:33.197522
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:36:49.189073
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:51.599608
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:36:54.655935
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:57.513349
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:37:01.071819
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:05.650457
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:08.510162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:12.436938
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:15.240721
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:18.455294
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:43.157038
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:47.527169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:50.699437
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:54.875088
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:59.481230
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:38:03.074841
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:38:07.157966
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:12.947938
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:17.282516
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:38:20.231948
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:14.343889
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:17.541935
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:19.760829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:21.762070
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:25.203744
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:39:28.942552
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:32.073911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-17 01:39:35.072418
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:37.684501
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:39.457084
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:41:25.987027
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:29.482946
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:34.691002
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:37.254512
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:41:41.716016
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:44.313280
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:47.115211
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:49.473872
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:53.373685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:56.911451
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'