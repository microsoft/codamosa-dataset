

# Generated at 2022-06-17 01:34:51.139207
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:34:54.077352
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:34:55.606980
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:00.127805
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:04.019897
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:35:06.594414
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:35:10.134672
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:12.858714
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:15.940378
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:19.207460
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:26.112273
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:29.456382
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:34.969481
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:38.303398
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:35:43.028856
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:46.369326
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:47.867169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:50.802384
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:35:52.302752
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:35:56.765960
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:05.781807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:10.915562
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:15.463632
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert isinstance(apparmor_facts, dict)
    assert 'apparmor' in apparmor_facts
    assert isinstance(apparmor_facts['apparmor'], dict)
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:36:19.328214
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:36:22.647955
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:36:26.684283
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:29.497021
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:32.355494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:34.121754
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:36:36.836456
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:36:52.127347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-17 01:36:56.615672
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:37:00.561135
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:05.226149
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:08.101563
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:12.022335
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:13.980316
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:37:18.312045
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:24.072236
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:29.162492
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:37:55.341335
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:00.034348
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:05.297799
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:07.464630
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:10.775415
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:13.828508
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:17.469099
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:20.365043
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:24.642306
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:38:27.350121
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:39:20.686110
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:39:24.331839
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:27.694330
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:39:30.833611
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:33.876992
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:38.546418
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:43.312763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:39:46.750377
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-17 01:39:48.422803
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:39:52.577856
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-17 01:41:41.138829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:41:43.451997
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:46.328472
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:48.810051
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:53.183811
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:41:55.562000
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-17 01:41:58.554523
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-17 01:42:00.638524
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-17 01:42:03.630487
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-17 01:42:08.351920
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'