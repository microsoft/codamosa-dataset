

# Generated at 2022-06-23 00:37:30.468751
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    # certain values
    assert c.name == 'apparmor'
    assert len(c._fact_ids) == 0

# Generated at 2022-06-23 00:37:37.371994
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test whether ApparmorFactCollector.collect() works as expected
    test_collector = ApparmorFactCollector()
    test_facts = test_collector.collect()
    assert type(test_facts) is dict
    assert 'apparmor' in test_facts
    assert type(test_facts['apparmor']) is dict
    assert type(test_facts['apparmor']['status']) is str

# Generated at 2022-06-23 00:37:40.232715
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert(apparmor.name == 'apparmor')
    assert(len(apparmor._fact_ids) == 0)

# Generated at 2022-06-23 00:37:44.405394
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Init
    afc = ApparmorFactCollector()

    # Mock
    afc.collect = lambda x, y: {}

    # Call method
    facts_dict = afc.collect()

    # Assertions
    assert isinstance(facts_dict, dict)
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:37:48.697192
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Given
    class ModuleMock(object):
        pass

    apparmor_fact_collector = ApparmorFactCollector()

    # When
    actual_facts_dict = apparmor_fact_collector.collect(ModuleMock)

    # Then
    assert actual_facts_dict['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-23 00:37:50.532061
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    assert c.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:37:52.193965
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'


# Generated at 2022-06-23 00:37:55.721757
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()

    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']
    assert apparmor_facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:37:57.751331
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"


# Generated at 2022-06-23 00:38:00.859470
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:02.056977
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:38:05.661768
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()
    


# Generated at 2022-06-23 00:38:09.898441
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    # Required variables
    module = None
    collected_facts = None
    # Execute method collect
    fact_collector.collect(module, collected_facts)

# Generated at 2022-06-23 00:38:11.236627
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'



# Generated at 2022-06-23 00:38:14.652008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_collector = ApparmorFactCollector()
    fake_os = {}
    apparmor_facts_collector.collect(collected_facts=fake_os)
    assert 'apparmor' in fake_os
    assert 'status' in fake_os['apparmor']

# Generated at 2022-06-23 00:38:18.355858
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector.name
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-23 00:38:21.410182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert type(result) is dict
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:23.795282
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'


# Generated at 2022-06-23 00:38:25.762308
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:38:36.706592
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()

    # Unit test for scenario where apparmor is present
    def os_path_exists_side_effect_1(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False

    os.path.exists = lambda x: os_path_exists_side_effect_1(x)
    facts_dict = apparmor_collector.collect()
    assert facts_dict['apparmor']['status'] == 'enabled'

    # Unit test for scenario where apparmor is not present
    def os_path_exists_side_effect_2(path):
        if path == '/sys/kernel/security/apparmor':
            return False
        else:
            return False


# Generated at 2022-06-23 00:38:39.800908
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmor_dictionary = apparmorFactCollector.collect()
    assert type(apparmor_dictionary) == dict

# Generated at 2022-06-23 00:38:44.034330
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {'status': 'enabled'}}
    os.rmdir('/sys/kernel/security/apparmor')
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:38:48.562939
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict
    assert facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:38:54.916991
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {}
    collected_facts = {}
    apparmor_facts_collector = ApparmorFactCollector()
    facts = apparmor_facts_collector.collect(module, collected_facts)
    assert 'apparmor' in facts
    assert isinstance(facts['apparmor'], dict)
    assert 'status' in facts['apparmor']
    assert isinstance(facts['apparmor']['status'], str)

# Generated at 2022-06-23 00:38:57.547602
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    cf = ApparmorFactCollector()
    facts = cf.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:58.584075
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'

# Generated at 2022-06-23 00:39:02.020836
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:03.142771
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:39:05.573511
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert len(apparmor_facts._fact_ids) == 0

# Generated at 2022-06-23 00:39:14.636194
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create ApparmorFactCollector object
    apparmor_fact_collector = ApparmorFactCollector()

    # Call the collect method of class ApparmorFactCollector
    result = apparmor_fact_collector.collect()

    # Get the result
    apparmor_value = result['apparmor']

    # Check status
    assert 'status' in apparmor_value

# Generated at 2022-06-23 00:39:18.234223
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Test `ApparmorFactCollector` class constructor
    """
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:26.371534
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ''' Unit test for method collect of class ApparmorFactCollector '''
    facts = {}
    apparmor_facts = {}

    apparmor_facts['status'] = ''
    expected = {'apparmor': apparmor_facts}
    fact_collector = ApparmorFactCollector()

    actual = fact_collector.collect()

    assert expected == actual, 'Expected %s but got %s' % (expected, actual)

if __name__ == '__main__':
    test_ApparmorFactCollector_collect()

# Generated at 2022-06-23 00:39:26.949893
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:39:31.418729
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = {}

    # Test to collect facts when apparmor is not installed
    ApparmorFactCollector().collect(None, facts_dict)
    assert('apparmor' in facts_dict)
    assert('status' in facts_dict['apparmor'])
    assert(facts_dict['apparmor']['status'] == 'disabled')

# Generated at 2022-06-23 00:39:34.698646
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-23 00:39:38.154290
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    result = f.collect()
    assert 'apparmor' in result
    assert 'status' in result['apparmor']
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:49.433998
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        import mock
    except ImportError:
        from ansible.module_utils import mock

    m = mock.mock_open(read_data='apparmor loaded')
    with mock.patch('ansible.module_utils.facts.collector.ApparmorFactCollector.open', m):
        apparmor = ApparmorFactCollector()
        collected_facts = apparmor.collect()
        assert collected_facts['apparmor']['status'] == 'disabled'
    m = mock.mock_open(read_data='apparmor is loaded')
    with mock.patch('ansible.module_utils.facts.collector.ApparmorFactCollector.open', m):
        apparmor = ApparmorFactCollector()
        collected_facts = apparmor.collect()

# Generated at 2022-06-23 00:39:52.376518
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector != None


# Generated at 2022-06-23 00:39:53.254086
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect()
    assert result.get('apparmor')

# Generated at 2022-06-23 00:39:55.776838
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Testing constructor of class ApparmorFactCollector
    myapparmor = ApparmorFactCollector()
    assert myapparmor.name == 'apparmor'

# Generated at 2022-06-23 00:40:00.224103
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
        apparmor_facts = {
            'apparmor': {
                'status': 'disabled'
            }
        }
        apparmor_collector = ApparmorFactCollector()
        collected_facts = {}
        apparmor_collector.collect(collected_facts=collected_facts)
        assert collected_facts == apparmor_facts

# Generated at 2022-06-23 00:40:04.057457
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    factCollector = ApparmorFactCollector()
    assert factCollector.name == 'apparmor'
    assert factCollector._fact_ids == set()


# Generated at 2022-06-23 00:40:05.807808
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_facts = ApparmorFactCollector()

    print(apparmor_facts.collect())

# Generated at 2022-06-23 00:40:16.805152
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """This is the test for the module_utils/facts/collectors/apparmor.py module
    which is used to gather information about apparmor on the remote host.

    Command Line:
        python -m testtools.run
        python -m unittest tests.module_utils.facts.collectors.test_apparmor.
        test_ApparmorFactCollector_collect
    """
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result.get('apparmor') is not None, \
        "The method 'collect' in class ApparmorFactCollector returned an" \
        " empty dictionary."

# Generated at 2022-06-23 00:40:27.492720
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    #os.path.exists('/sys/kernel/security/apparmor') = True
    os.path.exists = MagicMock(return_value = True)
    apparmor_collector = ApparmorFactCollector()
    assert (apparmor_collector.collect()['apparmor']=={'status': 'enabled'})
    #os.path.exists('/sys/kernel/security/apparmor') = False
    os.path.exists = MagicMock(return_value = False)
    apparmor_collector = ApparmorFactCollector()
    assert (apparmor_collector.collect()['apparmor']=={'status': 'disabled'})

# Generated at 2022-06-23 00:40:29.521316
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:40:32.185494
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    # The module is not yet implemented, therefore the assert should fail
    #assert f.collect(module=None, collected_facts=None) == expected

# Generated at 2022-06-23 00:40:35.545505
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'
    assert isinstance(x._fact_ids, set)
    assert len(x._fact_ids) == 0

# Generated at 2022-06-23 00:40:37.008169
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    result = a.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:40:37.950869
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:40:40.469297
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    # Check that attributes exist
    assert a.name
    assert a._fact_ids
    # Check that constructor does not return None
    assert a is not None

# Generated at 2022-06-23 00:40:53.923760
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector
    """
    import sys
    import platform
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance

    if platform.system() != 'Linux':
        return

    apparmor_fact_collector = get_collector_instance('ApparmorFactCollector', module=sys.modules[__name__])
    apparmor_facts_dict = apparmor_fact_collector.collect()
    assert(len(apparmor_facts_dict.keys()) == 1)
    assert(len(apparmor_facts_dict['apparmor'].keys()) == 1)


# Generated at 2022-06-23 00:40:55.747264
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor=ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:40:59.401859
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    facts = fact.collect()

    # Apparmor fact could be enabled or disabled
    assert facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:41:07.633127
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = {}

    apparmor_facts['status'] = 'enabled'

    expected_facts = {'apparmor': apparmor_facts}

    if os.path.exists('/sys/kernel/security/apparmor'):
        os.path.exists = lambda path: True
        actual_facts = collector.collect(collected_facts)
    else:
        os.path.exists = lambda path: False
        actual_facts = collector.collect(collected_facts)

    assert expected_facts == actual_facts

# Generated at 2022-06-23 00:41:09.682364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  name = 'apparmor'
  apparmorfactcollector = ApparmorFactCollector(name)
  assert apparmorfactcollector.name == name

# Generated at 2022-06-23 00:41:15.718447
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    # If /sys/kernel/security/apparmor exists,
    # then apparmor_facts['status'] should be 'enabled'
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts.collect()['apparmor']['status'] == 'enabled'
    else:
        # If /sys/kernel/security/apparmor does not exist,
        # then apparmor_facts['status'] should be 'disabled'
        assert apparmor_facts.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:25.290072
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test to ensure facts are collected if
    /sys/kernel/security/apparmor exists
    """
    def get_read_data(self, path):
        if path == '/sys/kernel/security/apparmor':
            return 'present'
        return 'not_present'

    import __builtin__
    __builtin__.open = __builtin__.__dict__['open']
    __builtin__.open('/sys/kernel/security/apparmor', 'r').read = get_read_data
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:41:29.962420
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    # Check if all members of collected_facts exists in _fact_ids
    for fact in fact_collector.collect():
        assert fact in fact_collector._fact_ids


# Generated at 2022-06-23 00:41:37.251879
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_module = ApparmorFactCollector()
    apparmor_module._module = {
        'run_command': lambda cmd, check_rc=True: [0, 'enabled\n', '']
    }
    apparmor_module.collect()
    assert apparmor_module.data is not None
    assert 'apparmor' in apparmor_module.data
    assert 'status' in apparmor_module.data['apparmor']
    assert apparmor_module.data['apparmor']['status'] == 'enabled'

    apparmor_module = ApparmorFactCollector()
    apparmor_module._module = {
        'run_command': lambda cmd, check_rc=False: [0, "", ""]
    }
    apparmor_module.collect()
    assert apparmor_module.data is not None

# Generated at 2022-06-23 00:41:39.126821
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:41:40.961425
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector == ApparmorFactCollector()


# Generated at 2022-06-23 00:41:45.334902
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    # Get the name of class
    name = apparmor_facts.name
    # Get the set of fact ids
    fact_ids = apparmor_facts._fact_ids
    assert name == 'apparmor'
    assert fact_ids == set()

# Generated at 2022-06-23 00:41:47.508446
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {}
    fact = ApparmorFactCollector()
    facts = fact.collect(module)
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:41:49.670223
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pa = ApparmorFactCollector()
    assert pa.name == 'apparmor'
    assert pa._fact_ids == set()


# Generated at 2022-06-23 00:41:53.920842
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector
    assert hasattr(obj, "name")
    assert hasattr(obj, "_fact_ids")
    assert isinstance(obj.name, str)
    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-23 00:41:56.493667
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert 'apparmor' == x.name
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:42:02.848558
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert isinstance(ApparmorFactCollector.name, str)
    assert len(ApparmorFactCollector._fact_ids) == 0
    assert isinstance(ApparmorFactCollector._fact_ids, set)
    assert isinstance(ApparmorFactCollector.collect(), dict)

# Generated at 2022-06-23 00:42:07.241348
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()
    assert collector.collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }

# Generated at 2022-06-23 00:42:13.734790
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert isinstance(apparmor_fact_collector._fact_ids, set)
    assert len(apparmor_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 00:42:17.156758
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.name == 'apparmor'
    assert apparmor_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 00:42:20.453275
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:42:24.945983
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    print ("test_ApparmorFactCollector_collect()")
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:42:34.121424
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import DependencyError
    facts_dict = {'apparmor': { 'status': 'disabled'}}

    def __getattr__(self, attr):
        return None

    BaseFactCollector.__getattr__ = __getattr__

    testobj = ApparmorFactCollector()

    assert(testobj.collect() == facts_dict)
    assert(testobj.collect(collected_facts={'apparmor': {'status': 'enabled'}}) == collected_facts)



# Generated at 2022-06-23 00:42:36.142995
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:42:38.098816
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert(obj.name == 'apparmor')

# Generated at 2022-06-23 00:42:40.868648
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollection = ApparmorFactCollector()
    assert ApparmorFactCollection.name == 'apparmor'
    assert ApparmorFactCollection._fact_ids == set()


# Generated at 2022-06-23 00:42:44.129116
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == "apparmor"
    assert apparmor_collector._fact_ids == set()

# unit testing for collect method of class ApparmorFactCollector

# Generated at 2022-06-23 00:42:48.303859
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fixture_file_path = 'unit_tests/module_utils/ansible_test/_fixtures/apparmor_facts.json'
    with open(fixture_file_path, 'r') as f:
        expected_results = json.load(f)
    apparmor_facts = ApparmorFactCollector()
    results = apparmor_facts.collect()
    assert results == expected_results

# Generated at 2022-06-23 00:42:50.050800
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-23 00:42:53.658153
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    module = None
    collected_facts = None
    test_obj = ApparmorFactCollector()
    assert test_obj._fact_ids == set()
    assert test_obj.name == 'apparmor'



# Generated at 2022-06-23 00:42:56.828084
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert len(apparmor_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 00:43:03.053845
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test method collect of class ApparmorFactCollector
    """
    apparmor_facts = ApparmorFactCollector()
    facts_dict = apparmor_facts.collect()
    assert 'apparmor' in facts_dict, \
        "Facts for apparmor should be present in facts_dict"
    assert isinstance(facts_dict['apparmor'], dict), \
        "Value of apparmor fact should be of type dict"

# Generated at 2022-06-23 00:43:07.433526
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:43:11.149117
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:43:13.460917
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:43:17.188414
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facter = ApparmorFactCollector()
    assert facter.name == 'apparmor'
    assert facter._fact_ids == set()


# Generated at 2022-06-23 00:43:19.135216
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:43:22.133421
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.collect() == {
        "apparmor": {
            "status": "enabled"
        }
    }

# Generated at 2022-06-23 00:43:26.844625
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    # Test collect method of ApparmorFactCollector class
    # when apparmor is enabled
    apparmor_enabled_facts = apparmor_fact_collector.collect()
    assert apparmor_enabled_facts['apparmor']['status'] == 'enabled'



# Generated at 2022-06-23 00:43:28.858537
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()
    return


# Generated at 2022-06-23 00:43:30.127386
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'


# Generated at 2022-06-23 00:43:32.526709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None

# Generated at 2022-06-23 00:43:41.517628
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import tempfile

    # Create a directory under /sys/kernel/security
    tempdir = tempfile.mkdtemp()
    if os.path.exists('/sys/kernel/security/') is False:
        os.mkdir('/sys/kernel/security/')
    os.symlink(tempdir, '/sys/kernel/security/apparmor')

    afc = ApparmorFactCollector()
    facts = afc.collect()
    assert(facts['apparmor']['status'] == 'enabled')

    os.unlink('/sys/kernel/security/apparmor')
    if os.path.exists('/sys/kernel/security/apparmor') is False:
        assert(facts['apparmor']['status'] == 'disabled')
    else:
        assert(False)

# Generated at 2022-06-23 00:43:42.600807
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:43:44.211268
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector()
    assert instance.name == 'apparmor'

# Generated at 2022-06-23 00:43:47.054333
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:43:49.740447
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert len(apparmor._fact_ids) == 0


# Generated at 2022-06-23 00:43:53.835226
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    m = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected = dict(apparmor=dict(status='enabled'))
    else:
        expected = dict(apparmor=dict(status='disabled'))
    assert m.collect() == expected

# Generated at 2022-06-23 00:43:56.920379
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:57.884716
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:44:00.070541
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {}
    apparmorFact = ApparmorFactCollector(module, collected_facts=None)
    apparmorFact.collect()
    assert apparmorFact.collect() != None

# Generated at 2022-06-23 00:44:01.505115
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:44:02.846598
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'


# Generated at 2022-06-23 00:44:06.051844
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Collect facts of class ApparmorFactCollector
    ac = ApparmorFactCollector()
    assert ac.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:44:12.941621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = 'ansible_collections.ansible.community.plugins.module_utils.facts.collectors.apparmor.os'
    mocked_os = 'ansible_collections.ansible.community.plugins.module_utils.facts.collectors.apparmor.ApparmorFactCollector'
    with patch(mock_module) as mocked_object:
        mocked_object.path.exists.return_value = False
        apparmor_facts_collector = ApparmorFactCollector()
        assert apparmor_facts_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:44:18.850733
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Creating a class instance without arguments
    aafc = ApparmorFactCollector()
    # No arguments should return a facts dict with apparmor dict with status set to disabled
    assert 'apparmor' in aafc.collect()
    assert 'status' in aafc.collect()['apparmor']
    assert 'disabled' == aafc.collect()['apparmor']['status']

# Generated at 2022-06-23 00:44:21.418043
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:44:24.348588
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_instance = ApparmorFactCollector()
    collect_value = class_instance.collect()
    assert collect_value == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:44:25.335135
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-23 00:44:26.253434
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:44:29.331059
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:44:34.874452
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    foo = ApparmorFactCollector()
    print("Class Name: " + foo.__class__.__name__)
    print("Collector Name: " + foo.name)
    print("Collector IDs: " + str(foo._fact_ids))
    print("Facts: " + str(foo.collect()))

if __name__ == '__main__':
    test_ApparmorFactCollector()

# Generated at 2022-06-23 00:44:37.792904
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc
    assert hasattr(afc, 'name')
    assert hasattr(afc, '_fact_ids')

# Generated at 2022-06-23 00:44:41.337812
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect(module=module)
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:44.281381
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    dummy_module = None
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect()['apparmor']['status'] != ''

# Generated at 2022-06-23 00:44:46.540517
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()


# Generated at 2022-06-23 00:44:49.360269
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Construct class ApparmorFactCollector and make sure the name is set correctly
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == "apparmor"


# Generated at 2022-06-23 00:44:59.420858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    import mock
    import os
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO


    class MockFile():

        def __init__(self, content):
            self.content = content
            self.read = mock.MagicMock(return_value=self.content)

    class MockOs():

        def __init__(self, files=None):
            self.files = files

        def __getitem__(self, path):
            return self.files[path]

        def __contains__(self, path):
            return path in self.files

        def listdir(self, path):
            return self.files[path]


# Generated at 2022-06-23 00:45:03.286142
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:45:06.211355
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()
    assert ac.name == "apparmor"
    assert ac.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:45:08.659056
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:11.915380
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for ApparmorFactCollector.collect
    """
    apparmorfactcollector = ApparmorFactCollector()
    apparmorfactcollector.collect()

# Generated at 2022-06-23 00:45:16.005557
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:45:20.897597
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # There is no proper way to test this. It will always return one of the
    # two possible strings. We are just checking that it returns a dict and
    # that the key is present in it.
    apparmor_facts = ApparmorFactCollector()
    result = apparmor_facts.collect()
    assert "apparmor" in result.keys()

# Generated at 2022-06-23 00:45:22.916404
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:45:25.850709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.name == 'apparmor'


# Generated at 2022-06-23 00:45:33.494539
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    #Test1: Apparmor is disabled
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'Apparmor is disabled', ''))

    collector = ApparmorFactCollector(module=module)
    result = collector.collect()
    assert result == {}

    #Test2: Apparmor is enabled
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(1, 'Apparmor is enabled', ''))

    collector = ApparmorFactCollector(module=module)
    result = collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}



# Generated at 2022-06-23 00:45:38.302481
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts['apparmor'].get('status') == 'disabled' or collected_facts['apparmor'].get('status') == 'enabled'

# Generated at 2022-06-23 00:45:41.985777
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    sut = ApparmorFactCollector()
    assert sut.name is not None
    assert sut.name == 'apparmor'
    assert sut._fact_ids is not None
    assert len(sut._fact_ids) == 0


# Generated at 2022-06-23 00:45:45.171193
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = {}
    Apparmor_FactCollector = ApparmorFactCollector()
    Apparmor_FactCollector.collect(module, collected_facts)
    assert collected_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:45:47.769087
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector(None)
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:49.333496
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'


# Generated at 2022-06-23 00:45:59.463422
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_factCollector_obj = ApparmorFactCollector()
    apparmor_factCollector_obj.name = "apparmor"
    apparmor_factCollector_obj._fact_ids = set()
    collected_facts = {}
    returned_facts_dict = {}
    expected_facts_dict = {}
    apparmor_facts = {}
    apparmor_facts['status'] = "disabled"
    expected_facts_dict['apparmor'] = apparmor_facts

    returned_facts_dict = apparmor_factCollector_obj.collect(collected_facts = collected_facts)
    assert returned_facts_dict == expected_facts_dict

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 00:46:01.921836
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == 'apparmor'
    assert apparmor_fact._fact_ids == set()


# Generated at 2022-06-23 00:46:06.924031
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Dummy class for unit test
    class DummyModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = []
    dummy_collector = ApparmorFactCollector(DummyModule())
    assert dummy_collector.name == 'apparmor'
    assert set(dummy_collector.collect().keys()) == set(['apparmor'])

# Generated at 2022-06-23 00:46:10.812691
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # Constructor with no arguments
    def test_class_instance_no_args():
        aafc = ApparmorFactCollector()
        assert aafc.name == 'apparmor'

    test_class_instance_no_args()



# Generated at 2022-06-23 00:46:15.726283
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    os_objs = MockOS()
    os_objs.path.exists('/sys/kernel/security/apparmor')
    apparmor_fact_collector = ApparmorFactCollector(None, os_objs)
    result = apparmor_fact_collector.collect()
    assert result == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-23 00:46:18.203770
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    assert c.collect() == {
        'apparmor': {
            'status': 'disabled',
        }
    }

# Generated at 2022-06-23 00:46:20.680873
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
        Test ApparmorFactCollector.collect method
    """
    t = ApparmorFactCollector()
    assert t.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:23.109637
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_instance = ApparmorFactCollector()
    assert apparmor_instance
    assert apparmor_instance.name == 'apparmor'
    assert apparmor_instance._fact_ids == set()


# Generated at 2022-06-23 00:46:25.841850
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  # Create the object of class ApparmorFactCollector
  obj = ApparmorFactCollector()
  # Test the object
  assert obj
  # Test name of object
  assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:46:32.569426
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    facts_dict['apparmor'] = apparmor_facts

    # Test for class ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()
    assert facts_dict == apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:46:33.701949
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    result = ApparmorFactCollector()
    assert result

# Generated at 2022-06-23 00:46:39.667003
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Creating the instance of ApparmorFactCollector
    apparmor_collector = ApparmorFactCollector()
    # Calling the collect method of ApparmorFactCollector
    details = apparmor_collector.collect()
    # Validating the result of method collect
    assert 'apparmor' in details

# Generated at 2022-06-23 00:46:41.817289
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:43.144954
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmo

# Generated at 2022-06-23 00:46:46.736479
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    af = ApparmorFactCollector()
    assert af.name == 'apparmor'
    assert af._fact_ids == set()


# Generated at 2022-06-23 00:46:51.256179
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Tests that the apparmor fact collector collects facts in the correct manner.
    """
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] == 'enabled' or facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:46:54.063183
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor'] == {
        'status': 'disabled'
    }

# Generated at 2022-06-23 00:47:02.365404
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            pass
    collected_facts = {}
    module = MockModule()
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect(module, collected_facts)
    assert collected_facts
    assert collected_facts['apparmor']
    assert collected_facts['apparmor']['status']
    assert 'enabled' == collected_facts['apparmor']['status'] or 'disabled' == collected_facts['apparmor']['status']

# Generated at 2022-06-23 00:47:04.823404
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    testobj = ApparmorFactCollector()
    assert testobj.name == 'apparmor'
    assert testobj._fact_ids == set()



# Generated at 2022-06-23 00:47:07.580927
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:47:09.364056
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:47:11.079839
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert(apparmor_obj.name == 'apparmor')

# Generated at 2022-06-23 00:47:15.993433
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    mock_module = type('module', (object,), {})
    mock_module.get_bin_path = lambda x, *args, **kwargs: '/bin/%s' % x
    apparmor_facts = ApparmorFactCollector(mock_module).collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'


# Generated at 2022-06-23 00:47:17.750807
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'

# Generated at 2022-06-23 00:47:18.402375
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:47:20.781601
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect(collected_facts={})
    assert(isinstance(result, dict))

# vim: set et ts=4 sw=4:

# Generated at 2022-06-23 00:47:25.138223
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()
    assert isinstance(obj.collect(), dict)
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 00:47:27.137090
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    # Test that the method collect return a dictionary
    assert isinstance(fc.collect(), dict)

# Generated at 2022-06-23 00:47:29.319585
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts, ApparmorFactCollector)
    assert apparmor_facts.name == 'apparmor'
