

# Generated at 2022-06-23 00:37:33.345091
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:37:36.428857
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-23 00:37:38.197934
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:37:40.366125
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    if 'apparmor' in collector.collect():
        assert True
    else:
        assert False

# Generated at 2022-06-23 00:37:43.377385
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert not apparmor_fact_collector._fact_ids



# Generated at 2022-06-23 00:37:47.348476
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    am = ApparmorFactCollector()
    actual = am.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert actual['apparmor']['status'] == 'enabled'
    else:
        assert actual['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:37:49.986164
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert 'apparmor' in apparmor_facts
    apparmor_facts = apparmor_facts['apparmor']
    assert 'status' in apparmor_facts

# Generated at 2022-06-23 00:37:52.514828
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:37:53.040392
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-23 00:37:57.409613
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = AnsibleModule()
    collector = ApparmorFactCollector.collector()
    collector.collect()

    assert collector.name == 'apparmor'


# Generated at 2022-06-23 00:38:01.894659
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    facts = fc.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    os.environ['ANSIBLE_COLLECT_APPARMOR'] = '1'
    assert 'apparmor' in fc.collect()['apparmor']

# Generated at 2022-06-23 00:38:04.143391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor':{'status':'disabled'}}

# Generated at 2022-06-23 00:38:08.053904
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Instantiating ApparmorFactCollector object
    apparmor_fact_collector_obj = ApparmorFactCollector()
    # Calling collect method
    facts_dict = apparmor_fact_collector_obj.collect()
    # Checking for existence of key apparmor
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:38:09.945992
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:38:20.411040
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def _up_dir(path, n=1):
        for i in range(n):
            path = os.path.dirname(path)
        return path

    mock_module_path = _up_dir(os.path.realpath(__file__), n=3)
    mock_module_path = os.path.join(mock_module_path, 'mock_modules/ansible/module_utils/facts/collectors/apparmor.py')
    mock_collector = None
    mock_module = None
    exec(compile(open(mock_module_path).read(), mock_module_path, 'exec'))

    obj = ApparmorFactCollector()
    facts = obj.collect(mock_module)
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:25.152473
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:26.668528
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'


# Generated at 2022-06-23 00:38:38.422762
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/facts/collector/apparmor.py')
    path = os.path.normpath(path)
    my_module = __import__(path, globals(), locals(), ['ApparmorFactCollector'], 0)
    a = my_module.ApparmorFactCollector()
    # Testing when apparmor is enabled
    os.makedirs('/sys/kernel/security/apparmor')
    assert a.collect() == {'apparmor': {'status': 'enabled'}}
    os.removedirs('/sys/kernel/security/apparmor')
    # Testing when apparmor is disabled
    assert a.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:38:40.056632
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'


# Generated at 2022-06-23 00:38:43.944004
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert 'apparmor' in result.keys()
    assert 'status' in result['apparmor'].keys()
    assert result['apparmor']['status'] == "enabled"

# Generated at 2022-06-23 00:38:46.668566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    status = apparmor.collect()
    assert 'disabled' in status.values()[0].values()

# Generated at 2022-06-23 00:38:49.799460
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:54.830742
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_test_facts = {'apparmor': {'status': 'enabled'}}
    test_collector1 = ApparmorFactCollector()
    test_fact_dict1 = test_collector1.collect()
    assert test_fact_dict1 == apparmor_test_facts, 'Test Failed'

# Generated at 2022-06-23 00:39:03.869617
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class MockModule(object):
        def __init__(self, params=None):
            self.params = params

    class MockCollectedFacts(object):
        def __init__(self):
            self.data = {}

        def pop(self):
            return self.data

        def get(self):
            return self.data

    obj = ApparmorFactCollector()
    obj._module = MockModule({})
    obj._collect_platform_subset = lambda *args: {}

    ret = obj.collect(collected_facts=MockCollectedFacts())
    assert isinstance(ret, dict)

# Generated at 2022-06-23 00:39:05.432418
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    print(apparmorFactCollector.collect())

# Generated at 2022-06-23 00:39:11.876934
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Initialize the collector object
    my_obj = ApparmorFactCollector(None)
    # Try to collect the facts
    my_obj.collect(None, None)

# Generated at 2022-06-23 00:39:14.329644
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts_dict = {'apparmor': {'status': 'disabled'}}
    assert ApparmorFactCollector().collect() == facts_dict

# Generated at 2022-06-23 00:39:26.660274
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import Collector

    # This is a fake module
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # This is a fake ansible_facts
    collected_facts = {'ansible_facts': {}}

    # This is a fake os.path.exists, the method used in collect
    def fake_os_path_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False
    os_path_exists = os.__dict__.get('exists')
    os.path.exists = fake_os_path_exists

    # Create an instance of ApparmorFactCollector
    afc_instance

# Generated at 2022-06-23 00:39:30.260806
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    collected_facts = dict()
    module = dict()

    fc = ApparmorFactCollector()
    fc.collect(module, collected_facts)

    assert 'apparmor' in collected_facts
    assert collected_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:39:36.006622
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    apparmor_facts = fact_collector.collect(collected_facts={})

    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:39:38.666853
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:39:40.877246
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:39:42.935923
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'


# Generated at 2022-06-23 00:39:44.868895
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'


# Generated at 2022-06-23 00:39:47.771831
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for ApparmorFactCollector.collect()"""

    # Test implementation goes here.
    test_collector = ApparmorFactCollector()
    test_collector.collect()

# Generated at 2022-06-23 00:39:57.346114
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_facts = {
        'apparmor': '',
    }

    # Test if apparmor is enabled
    collector = ApparmorFactCollector()
    facts = collector.collect(collected_facts=ansible_facts)
    assert facts['apparmor']['status'] == 'enabled'

    # Test if apparmor is disabled
    ansible_facts = {
        'apparmor': None,
    }
    collector = ApparmorFactCollector()
    facts = collector.collect(collected_facts=ansible_facts)
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:59.972900
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    #assert not os.path.exists('/sys/kernel/security/apparmor')
    a = ApparmorFactCollector()
    #assert a.name == "apparmor"
    assert a._fact_ids is not None

# Generated at 2022-06-23 00:40:04.332810
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    test_facts = collector.collect()
    assert test_facts['apparmor']['status'] == 'enabled'

# Test case when there is no apparmor installed

# Generated at 2022-06-23 00:40:07.204080
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:40:10.882215
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    fact_data = apparmor_facts.collect()
    assert fact_data
    assert fact_data['apparmor']

# Generated at 2022-06-23 00:40:13.928146
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'



# Generated at 2022-06-23 00:40:16.162725
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert (ApparmorFactCollector.name == 'apparmor')
    assert (ApparmorFactCollector._fact_ids == set())

# Generated at 2022-06-23 00:40:28.475041
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    apparmor_fs = '/sys/kernel/security/apparmor'
    if os.path.exists(apparmor_fs):
        # Create a temp directory for testing
        import tempfile
        temp_dir = tempfile.mkdtemp()
        # Rename the apparmor fs
        os.rename(apparmor_fs, os.path.join(temp_dir, 'apparmor'))

# Generated at 2022-06-23 00:40:35.496250
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mock module input parameters
    module_params = {}
    # Setup the collector
    apparmor_facts = ApparmorFactCollector(module_params, None)
    # Run the collect method
    facts = apparmor_facts.collect(None, None)
    # Ensure the collected facts are of proper type
    assert isinstance(facts, dict)
    # Ensure the status is either enabled or disabled
    assert facts['apparmor']['status'] == 'enabled' or facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:37.995483
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorCollector = ApparmorFactCollector()
    assert apparmorCollector.name == 'apparmor'
    assert apparmorCollector._fact_ids == set()


# Generated at 2022-06-23 00:40:42.775936
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()
    assert apparmor_facts._fact_ids == set(['apparmor'])

# Generated at 2022-06-23 00:40:47.778498
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:40:49.140665
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj._name == 'apparmor'

# Generated at 2022-06-23 00:40:53.081795
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts
    apparmor_fact_collector.exit_json(ansible_facts=collected_facts)

# Generated at 2022-06-23 00:40:56.777886
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Required to test this
    module_mock = None
    collected_facts_mock = None

    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj is not None

# Generated at 2022-06-23 00:40:59.164891
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'apparmor'


# Generated at 2022-06-23 00:41:02.389717
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_factcollector_obj = ApparmorFactCollector()

    assert apparmor_factcollector_obj.collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }

# Generated at 2022-06-23 00:41:05.175725
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    class module:
        def fail_json(self, *args, **kwargs):
            pass

    collector = ApparmorFactCollector()

    assert collector.name == "apparmor"

# Generated at 2022-06-23 00:41:12.878949
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # If /sys/kernel/security/apparmor exists,
    # status should be "enabled" otherwise "disabled"
    if os.path.exists('/sys/kernel/security/apparmor'):
        status = 'enabled'
    else:
        status = 'disabled'
    return_dict = {'apparmor': {'status': status}}
    fact_collector = ApparmorFactCollector()
    return_data = fact_collector.collect()
    print("Returned data: {}".format(return_data))
    assert return_data == return_dict


# Generated at 2022-06-23 00:41:15.959364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorObject = ApparmorFactCollector()
    assert ApparmorObject.name == "apparmor"
    assert ApparmorObject.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:20.023275
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_ApparmorFactCollector = ApparmorFactCollector()
    test_apparmor_facts = test_ApparmorFactCollector.collect()
    assert isinstance(test_apparmor_facts['apparmor'], dict)
    assert 'status' in test_apparmor_facts['apparmor']

# Generated at 2022-06-23 00:41:22.641891
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector_obj = ApparmorFactCollector()
    assert type(ApparmorFactCollector_obj.collect()) == dict


# Generated at 2022-06-23 00:41:24.665245
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:26.503740
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:28.324391
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class_inst = ApparmorFactCollector()
    assert class_inst.name == 'apparmor'

# Generated at 2022-06-23 00:41:31.396969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()
    assert apparmor_collector.get_facts()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:41:34.926144
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected = {'apparmor': {'status': 'enabled'}}
    else:
        expected = {'apparmor': {'status': 'disabled'}}
    assert fact_collector.collect() == expected

# Generated at 2022-06-23 00:41:38.407630
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    result = apparmor.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:41:41.499592
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:41:50.529749
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_status = "enabled"
    apparmor_module = lambda: None
    apparmor_module.fail_json = lambda **args: None

    apparmor_collector = ApparmorFactCollector()
    path_exists_mock = lambda path: True
    getpwnam_mock = lambda name: True
    with patch.multiple(os.path, exists=path_exists_mock):
        with patch.multiple(pwd, getpwnam=getpwnam_mock):
            try:
                for key, value in apparmor_collector.collect():
                    assert(key == 'apparmor')
                    assert(value['status'] == apparmor_status)
            except TypeError:
                pass

# Generated at 2022-06-23 00:41:54.825829
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class args:
        pass

    arg = args()
    arg.gather_subset = ['all']
    arg.gather_timeout = 10

    facts_dict = ApparmorFactCollector.collect(arg)
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:56.710848
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()

    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-23 00:41:59.162260
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert(apparmor_fact_collector.collect() == dict(apparmor=dict(status='disabled')))

# Generated at 2022-06-23 00:42:03.250620
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:42:07.608455
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_obj = ApparmorFactCollector()
    facts = test_obj.collect()
    assert test_obj.name == 'apparmor'
    assert isinstance(test_obj._fact_ids, set)
    assert isinstance(facts, dict)
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:42:10.316871
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'



# Generated at 2022-06-23 00:42:11.140462
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-23 00:42:14.944911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    result = apparmor_facts.collect()
    assert result['apparmor']['status'] == 'disabled'
    assert result['apparmor']['status'] != 'enabled'

# Generated at 2022-06-23 00:42:18.724267
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    expected_apparmor_fact_collector_name = 'apparmor'
    actual_apparmor_fact_collector_name = ApparmorFactCollector().name
    assert expected_apparmor_fact_collector_name == actual_apparmor_fact_collector_name


# Generated at 2022-06-23 00:42:20.651608
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  aafc = ApparmorFactCollector()
  assert isinstance(aafc.collect(), dict)


# Generated at 2022-06-23 00:42:22.956166
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass


# Generated at 2022-06-23 00:42:23.724981
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:42:25.843444
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-23 00:42:28.882391
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:42:29.924698
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:42:33.881787
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:41.892744
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test method collect of class ApparmorFactCollector
    """
    # Test without apparmor
    apparmor_collector = ApparmorFactCollector()
    os.path.exists = lambda x: False
    result = apparmor_collector.collect()
    assert result['apparmor']['status'] == "disabled"
    # Test with apparmor
    os.path.exists = lambda x: True
    result = apparmor_collector.collect()
    assert result['apparmor']['status'] == "enabled"

# Generated at 2022-06-23 00:42:44.197705
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:42:46.006996
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector('apparmor').collect()
    assert apparmor['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:42:47.994709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()

# Generated at 2022-06-23 00:42:56.588917
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Testa method collect of class ApparmorFactCollector.
    """
    # Initialize
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = None
    apparmor_fact_collector._collect_subset = None
    apparmor_fact_collector._gather_subset = ['all']
    apparmor_fact_collector._validate_collect_subset = False
    apparmor_fact_collector._validate_gather_subset = False
    # Test
    collected_facts = apparmor_fact_collector.collect(apparmor_fact_collector._module, None)
    # Assertions
    assert 'apparmor' in collected_facts

# Generated at 2022-06-23 00:43:02.050040
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Check if apparmor is installed
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert ApparmorFactCollector().collect() == {
            'apparmor': {'status': 'enabled'}}
    else:
        assert ApparmorFactCollector().collect() == {
        'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:06.401550
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_instance = ApparmorFactCollector()
    assert apparmor_fact_instance is not None
    assert apparmor_fact_instance.name == 'apparmor'
    assert apparmor_fact_instance.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:10.569304
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)
    assert isinstance(apparmor_fact_collector.name, str)
    assert isinstance(apparmor_fact_collector._fact_ids, set)


# Generated at 2022-06-23 00:43:19.454526
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import sys
    if sys.version_info[:2] >= (2,7):
        # Need to mock the check for /sys/kernel/security/apparmor, because
        # it is not present on the testing environment
        from unittest.mock import patch
        with patch('os.path.exists') as mock_path_exists:
            mock_path_exists.return_value = True
            afc = ApparmorFactCollector()
            result = afc.collect()
            assert result['apparmor']['status'] == 'enabled'


# Generated at 2022-06-23 00:43:21.290995
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj_apparmor = ApparmorFactCollector()
    assert obj_apparmor.name == 'apparmor'

# Generated at 2022-06-23 00:43:26.367577
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    ansible_module = {}
    apparmor_fact_collector = ApparmorFactCollector(ansible_module)
    facts_dict = apparmor_fact_collector.collect()

    assert facts_dict == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-23 00:43:29.800743
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 00:43:35.477936
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    o = ApparmorFactCollector()
    assert o is not None
    assert o.name == 'apparmor'
    assert o._fact_ids == set()
    assert o.collect(1, 2) == {'apparmor': {'status': 'enabled'}}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 00:43:44.737022
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for check method collect of class ApparmorFactCollector"""
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts_dict['apparmor']['status'] == 'enabled'

    if not os.path.exists('/sys/kernel/security/apparmor'):
        assert facts_dict['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:43:47.701940
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()
    assert afc.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:49.208287
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()

# Generated at 2022-06-23 00:43:51.390320
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert isinstance(collector._fact_ids, set)

# Generated at 2022-06-23 00:43:56.113506
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_apparmor_facts = ApparmorFactCollector()
    apparmor_facts = class_apparmor_facts.collect()
    assert type(apparmor_facts) == dict
    assert 'apparmor' in apparmor_facts
    assert type(apparmor_facts['apparmor']) == dict
    assert type(apparmor_facts['apparmor']['status']) == str

# Generated at 2022-06-23 00:43:57.127918
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:43:59.491518
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector_instance = ApparmorFactCollector()
    assert apparmor_collector_instance.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:44:09.600573
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    If kernel has apparmor feature enabled return status as enabled.
    """
    os.path.exists = MagicMock(return_value=True)
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

    """
    If kernel has apparmor feature disabled return status as disabled.
    """
    os.path.exists = MagicMock(return_value=False)
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:44:12.237489
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert isinstance(facts['apparmor'], dict)

# Generated at 2022-06-23 00:44:13.733449
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:44:18.391889
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)
    assert apparmor_fact_collector.name == 'apparmor'
    assert not apparmor_fact_collector._fact_ids

# Generated at 2022-06-23 00:44:20.701204
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert('apparmor' == ApparmorFactCollector().name)

# Generated at 2022-06-23 00:44:26.348895
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    # Case 1 with disabled apparmor
    os.path.exists = lambda x: False
    result = collector.collect()

    assert result['apparmor']['status'] == 'disabled'

    # Case 2 with enabled apparmor
    os.path.exists = lambda x: True
    result = collector.collect()

    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:44:29.577268
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Check if we get right apparmor facts.
    """
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:44:37.170711
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup
    fake_module = None
    fake_collected_facts = {}
    fake_base_fact_collector = BaseFactCollector()
    fake_ApparmorFactCollector = ApparmorFactCollector(fake_base_fact_collector)
    fake_os_path = {'exists': return_true}
    fake_os = {'path': fake_os_path}
    fake_module=[fake_os]
    fake_ApparmorFactCollector._module = fake_module

    # Test
    facts_dict = fake_ApparmorFactCollector.collect(fake_module, fake_collected_facts)

    # Assert
    assert facts_dict == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-23 00:44:42.278604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_test_input = [{"ansible_facts": {"apparmor": {"status": "enabled"}}},
                    {"ansible_facts": {"apparmor": {"status": "disabled"}}}]

    apparmor_test_output = ApparmorFactCollector().collect()

    assert apparmor_test_output in apparmor_test_input



# Generated at 2022-06-23 00:44:44.556062
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'


# Generated at 2022-06-23 00:44:47.998192
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)


# Unit test to check if the collect() method of ApparmorFactCollector works

# Generated at 2022-06-23 00:44:52.394906
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:55.184370
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()


# Generated at 2022-06-23 00:44:56.174267
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-23 00:45:00.971007
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:45:02.501289
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'


# Generated at 2022-06-23 00:45:06.308516
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result == {
        "apparmor": {
            "status": "enabled"
        }
    }


# Generated at 2022-06-23 00:45:11.077017
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import collect_subset

    apparmor_subset = ['apparmor']
    collected_facts = collect_subset(apparmor_subset)
    assert ApparmorFactCollector.name in collected_facts["ansible_facts"]

# Generated at 2022-06-23 00:45:14.227673
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    apparmor_fc.collect()

# Generated at 2022-06-23 00:45:16.705617
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'



# Generated at 2022-06-23 00:45:19.621704
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect(collected_facts={})
    assert facts_dict is not None

# Generated at 2022-06-23 00:45:22.392696
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-23 00:45:25.062317
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:26.829721
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:29.204004
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert 'apparmor' in ApparmorFactCollector.collect().keys()


# Generated at 2022-06-23 00:45:30.105551
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name

# Generated at 2022-06-23 00:45:32.030341
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()    
    assert aafc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:45:39.212882
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_collect_test_object = apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_collect_test_object
    assert 'status' in apparmor_collect_test_object['apparmor']
    assert isinstance(apparmor_collect_test_object['apparmor']['status'], str)

# Generated at 2022-06-23 00:45:47.583463
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    a = ApparmorFactCollector()

    # test when files exist
    a.collect()
    assert 'apparmor' in a.collect()
    assert 'status' in a.collect()['apparmor']

    # test when files do not exist
    os.path.exists = os.path.exists_orig
    os.path.exists = lambda x: False
    assert 'apparmor' in a.collect()
    assert 'status' in a.collect()['apparmor']

# Generated at 2022-06-23 00:45:49.743944
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'



# Generated at 2022-06-23 00:45:51.274702
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:45:53.307939
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'


# Generated at 2022-06-23 00:45:58.190161
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Sample fact for Apparmor fact collector for tests
    data = {'apparmor': {'status': 'enabled'}}

    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector.collect() == data

# Generated at 2022-06-23 00:46:01.627004
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ifc = ApparmorFactCollector()
    ansible_facts_dict = ifc.collect()
    assert ansible_facts_dict == {'apparmor': {'status': 'disabled'}}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 00:46:02.984303
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = ApparmorFactCollector()
    assert isinstance(facts.collect(), dict)

# Generated at 2022-06-23 00:46:04.404873
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-23 00:46:06.552432
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {
        'apparmor': {'status': 'enabled'},
    }

# Generated at 2022-06-23 00:46:09.554987
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a.priority == 6


# Generated at 2022-06-23 00:46:11.599317
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert(a.collect() == {'apparmor': {'status': 'disabled'}})

# Generated at 2022-06-23 00:46:14.079894
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()

# Generated at 2022-06-23 00:46:16.123287
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:46:18.252857
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:46:21.131286
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-23 00:46:22.842537
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    assert aafc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:30.655356
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    afc = ApparmorFactCollector()

    try:
        import apparmor
        module = 'module'
        collected_facts = 'facts'
        aaf = afc.collect(module, collected_facts)
        assert aaf['apparmor']['status'] == 'enabled'
    except:
        aaf = afc.collect(module, collected_facts)
        assert aaf['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:33.705016
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # check if apparmor is disabled
    collector = ApparmorFactCollector()
    facts = collector.collect()
    status = facts['apparmor']['status']
    assert(status == 'disabled')

# Generated at 2022-06-23 00:46:39.151822
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    apparmor_collector = get_collector_instance('ApparmorFactCollector')
    assert apparmor_collector.collect == ApparmorFactCollector.collect

# Generated at 2022-06-23 00:46:41.379064
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()


# Generated at 2022-06-23 00:46:44.752516
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_ansible_module = FakeAnsibleModule()
    collector = ApparmorFactCollector()
    facts_dict = collector.collect(module=fake_ansible_module)
    assert isinstance(facts_dict['apparmor'], dict)


# Fake AnsibleModule

# Generated at 2022-06-23 00:46:47.443335
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:46:50.587611
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:46:53.821399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result_dict = fact_collector.collect(None, None)
    assert 'apparmor' in result_dict

# Generated at 2022-06-23 00:46:56.638794
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:47:02.842223
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance

    aafc = get_collector_instance('ApparmorFactCollector')
    assert isinstance(aafc, ApparmorFactCollector)

    # Returned value should be a dict.
    aafc_facts = aafc.collect()
    assert type(aafc_facts) is dict



# Generated at 2022-06-23 00:47:04.917666
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    lib = ApparmorFactCollector()
    assert lib.name == 'apparmor'
    assert lib._fact_ids == set()

# Generated at 2022-06-23 00:47:07.285276
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['apparmor']

# Generated at 2022-06-23 00:47:07.864717
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:47:09.476338
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:47:12.861367
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:47:16.677016
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == "apparmor"
    assert len(apparmor._fact_ids) == 0


# Generated at 2022-06-23 00:47:18.589778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}})

# Generated at 2022-06-23 00:47:22.478389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ap = ApparmorFactCollector()
    apparmor_facts = ap.collect()
    assert 'apparmor' in apparmor_facts.keys(), "apparmor_facts has no apparmor key."
    assert 'status' in apparmor_facts['apparmor'].keys(), "apparmor_facts['apparmor'] has no status key."

# Generated at 2022-06-23 00:47:25.526437
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'Apparmor'

# Unit testing for the collect method of class ApparmorFactCollector

# Generated at 2022-06-23 00:47:30.750133
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

from ansible.module_utils.facts.collector import BaseFactCollector
from ansible.module_utils.facts.collector import collect_subset

from ansible.module_utils.facts.collector import FactsCollector
from ansible.module_utils.facts.collector import get_collector_classes



# Generated at 2022-06-23 00:47:35.124173
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # test case 1: AppArmor is enabled
    apparmor_fact_collector.collect(collected_facts={})
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'enabled'