

# Generated at 2022-06-23 00:37:32.964543
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert type(ApparmorFactCollector().collect()['apparmor']['status']).__name__ == 'str'

# Generated at 2022-06-23 00:37:35.725678
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:37:44.540814
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # construct a fake module, with enough attributes and methods for the
    # ApparmorFactCollector
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self,**kwargs):
            pass
        def get_bin_path(self,name,default=None,required=True):
            return '/sbin/{}'.format(name)

    # create a fake AnsibleModule object, with the above FakeModule instance
    # as the _ansible_module attribute
    class FakeAnsibleModule(object):
        def __init__(self):
            self._ansible_module = FakeModule()

    collect = ApparmorFactCollector()
    assert not collect.collect(module=FakeAnsibleModule())

# Generated at 2022-06-23 00:37:47.017525
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids is not None
    assert ApparmorFactCollector.collect() is not None

# Generated at 2022-06-23 00:37:49.663143
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    runner = TestRunner()
    apparmor.collect(None, runner.collected_facts)
    assert runner.collected_facts['apparmor']['status'] is not None

# Generated at 2022-06-23 00:37:51.272898
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_apparmor = ApparmorFactCollector()
    assert test_apparmor is not None

# Generated at 2022-06-23 00:37:56.099949
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def mock_os_exists(path):
        return True
    module = mock.Mock()
    module.path.exists.side_effect = mock_os_exists
    apparmor_facts = ApparmorFactCollector.collect(module)
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    module.path.exists.assert_called_once_with('/sys/kernel/security/apparmor')


# Generated at 2022-06-23 00:38:00.078161
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert isinstance(apparmor, ApparmorFactCollector)
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()
    assert isinstance(apparmor.collect(), dict)

# Generated at 2022-06-23 00:38:01.883126
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'


# Generated at 2022-06-23 00:38:04.539017
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {}


# Generated at 2022-06-23 00:38:06.275265
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    factCollector = ApparmorFactCollector()
    assert factCollector.name == 'apparmor'


# Generated at 2022-06-23 00:38:08.758660
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aaf = ApparmorFactCollector()
    result = aaf.collect()
    assert result

# Generated at 2022-06-23 00:38:14.606599
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of a class that inherits from BaseFactCollector
    apparmor_fact_collector = ApparmorFactCollector()
    # This class has method collect that returns a dictionary
    # of facts about apparmor
    apparmor_facts = apparmor_fact_collector.collect()

    # Assert that the returned dictionary is not empty
    assert apparmor_facts

    # Assert that the returned dictionary has an element with key 'apparmor'
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:38:25.562209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    AapparmorFactCollector = ApparmorFactCollector()

    # Test when the path /sys/kernel/security/apparmor exists
    AapparmorFactCollector.file_exists_mock = lambda path: path == '/sys/kernel/security/apparmor'
    collected_facts = AapparmorFactCollector.collect()
    assert collected_facts['apparmor']['status'] == 'enabled'

    # Test when the path /sys/kernel/security/apparmor not exists
    AapparmorFactCollector.file_exists_mock = lambda path: path != '/sys/kernel/security/apparmor'
    collected_facts = AapparmorFactCollector.collect()
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:36.109293
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    with open('../ansible/test/unit/module_utils/facts/apparmor/apparmor_file.txt', 'r') as file:
        lines = file.readlines()
        line1 = lines[0]  # line contains the first line of file
        line2 = lines[1]  # line contains the second line of file
        line3 = lines[2]  # line contains the third line of file
        line4 = lines[3]  # line contains the fourth line of file
    assert line1 == '# -*- mode: ruby -*-\n'
    assert line2 == '# vi: set ft=ruby :\n'
    assert line3 == '\n'
    assert line4 == '# InSpec test for recipe ansible::default\n'

# Generated at 2022-06-23 00:38:39.250010
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()


# Generated at 2022-06-23 00:38:40.483751
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

# Generated at 2022-06-23 00:38:44.034528
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = {'apparmor': {'status': ''}}
    assert apparmor_fact_collector.collect(apparmor_facts) == apparmor_facts

# Generated at 2022-06-23 00:38:55.139107
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import tempfile
    import shutil
    from ansible.module_utils.facts.collector import get_collector_instance
    import json
    import pytest

    apparmor_fact_collector = get_collector_instance(ApparmorFactCollector)

    # mocking /sys/kernel/security/apparmor
    temp_sys_dir = tempfile.mkdtemp()

    # test when the file doesn't exist
    assert os.path.isdir(temp_sys_dir) is True
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

    # test when the file exists
    os.makedirs(os.path.join(temp_sys_dir, "/sys/kernel/security/apparmor"))

# Generated at 2022-06-23 00:38:58.720248
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:00.492244
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert hasattr(ApparmorFactCollector, 'name')
    assert ApparmorFactCollector.name == 'apparmor'

    assert hasattr(ApparmorFactCollector, '_fact_ids')
    assert isinstance(ApparmorFactCollector._fact_ids, set)


# Generated at 2022-06-23 00:39:03.253683
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    assert fc.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:39:04.274094
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:39:10.951454
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Unit test for constructor of class ApparmorFactCollector"""
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == 'set()'


# Generated at 2022-06-23 00:39:19.505442
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test with no args
    test_ApparmorFactCollector = ApparmorFactCollector()
    assert test_ApparmorFactCollector.name == 'apparmor'
    assert len(test_ApparmorFactCollector._fact_ids) == 0
    assert test_ApparmorFactCollector._disable_legacy_fact_names is False

    # Test with args
    test_ApparmorFactCollector = ApparmorFactCollector(
        'apparmor',
        set(['apparmor_fact_1', 'apparmor_fact_2']),
        False,
    )
    assert test_ApparmorFactCollector.name == 'apparmor'
    assert len(test_ApparmorFactCollector._fact_ids) == 2
    assert test_ApparmorFactCollector._disable_legacy_fact_names is False

# Generated at 2022-06-23 00:39:21.023520
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 00:39:23.938286
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'


# Generated at 2022-06-23 00:39:24.957050
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:39:25.926501
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name

# Generated at 2022-06-23 00:39:30.289027
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    module = None
    collected_facts = {'ansible_distribution': 'test-distribution', 'ansible_distribution_version': 'test-distribution-version'}
    apparmor = ApparmorFactCollector()
    output = apparmor.collect(module, collected_facts)
    assert 'apparmor' in output

# Generated at 2022-06-23 00:39:35.193115
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method collect of class ApparmorFactCollector
    """
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:37.933525
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:39:42.439248
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    expected_result = {'apparmor': {'status': 'enabled'}}
    module = AnsibleModule({})
    fact_collector = ApparmorFactCollector(module)
    result = fact_collector.collect()
    assert result['apparmor'] == expected_result['apparmor']

# AnsibleModule utility

# Generated at 2022-06-23 00:39:45.486485
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == "apparmor"
    assert apparmor_fc._fact_ids == set()


# Generated at 2022-06-23 00:39:48.005588
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()



# Generated at 2022-06-23 00:39:50.600285
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:39:53.837426
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:39:57.212770
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:39:59.160858
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorcol = ApparmorFactCollector()
    assert apparmorcol.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:03.824428
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert isinstance(collector, BaseFactCollector)
    facts = collector.collect()
    assert 'apparmor' in facts
    assert isinstance(facts['apparmor'], dict)
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:40:09.563112
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create an instance of the class to test
    aafc = ApparmorFactCollector()

    # Inject a  mock module with a specific set of values
    class Module:
        pass

    module = Module()
    module.params = dict()

    # Execute the collect function
    collected_facts = aafc.collect(module)

    # Assert that the collected facts are equal to a specific set of values
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:10.971170
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert set(ApparmorFactCollector()._fact_ids) == set()

# Generated at 2022-06-23 00:40:17.856107
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = None
    collected_facts = None
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_status = 'enabled'
    else:
        apparmor_status = 'disabled'
    assert obj.collect(module, collected_facts) == {'apparmor':
                                                    {'status': apparmor_status}}

# Generated at 2022-06-23 00:40:21.229783
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:40:24.929310
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:27.784377
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:29.918290
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:40:31.784292
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    assert a.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:39.378414
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    fake_data_files = {
        "/sys/kernel/security/apparmor": "",
    }

    module = MagicMock()

    ac = ApparmorFactCollector(module=module, collected_facts={})
    results = ac.collect(module=module, collected_facts={})
    assert results == {'apparmor': {'status': 'enabled'}}

    with patch.dict(ac.files_dict, fake_data_files):

        results = ac.collect(module=module, collected_facts={})
        assert results == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:43.947925
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_object = ApparmorFactCollector()
    assert apparmor_fact_collector_object.name == 'apparmor'
    assert apparmor_fact_collector_object._fact_ids == set()


# Generated at 2022-06-23 00:40:49.206711
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    p = ApparmorFactCollector()
    assert p.name == "apparmor"
    assert p.collect()

# Generated at 2022-06-23 00:40:51.013549
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'ApparmorFactCollector'

# Generated at 2022-06-23 00:40:54.725571
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test ApparmorFactCollector"""
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert 'apparmor' in apparmor_collector._fact_ids


# Generated at 2022-06-23 00:41:05.630076
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mock module instance
    module = type('module', (), {})()
    # Mock facts dictionary
    collected_facts = {}

    # Mock /sys/kernel/security/apparmor
    # that does not exist
    apparmor_dir = '/sys/kernel/security/apparmor'
    get_path_mock = 'ansible.module_utils.facts.collector.ApparmorFactCollector.os.path.exists'
    get_path_patch = 'ansible.module_utils.facts.collector.ApparmorFactCollector.os.path'
    path_mock_get = MagicMock(name=get_path_mock, return_value=False)
    path_mock_get.exists = path_mock_get

# Generated at 2022-06-23 00:41:14.950227
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Mock the parameters and results
    import os
    import sys
    mocked_module = type('MockedModule',(object,),{})()
    mocked_collected_facts = type('MockedCollectedFacts',(object,),{})()
    mocked_os = type('MockedOs',(object,),{'path':type('MockedPath',(object,),{})()})
    mocked_module.os = mocked_os
    mocked_os.path.exists = lambda x: True
    mocked_os.path.isfile = lambda x: True
    mocked_os.access = lambda x,y: True
    mocked_sys = type('MockedSys',(object,),{})()
    mocked_module.sys = mocked_sys
    mocked_sys.maxsize = 9223372036854775807
    mocked

# Generated at 2022-06-23 00:41:21.076488
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Test case for collect method of class ApparmorFactCollector """
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module.get_bin_path = lambda x: '/usr/bin/env'
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:41:22.592537
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-23 00:41:26.313283
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """ Unit test for constructor of class ApparmorFactCollector """
    apparmor = ApparmorFactCollector()
    assert ApparmorFactCollector.name == apparmor.name
    assert 'status' in apparmor.collect()['apparmor']


# Generated at 2022-06-23 00:41:28.473544
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    apparmor_fact = fact_collector.collect()
    assert 'apparmor' in apparmor_fact

# Generated at 2022-06-23 00:41:29.849920
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'status' in ApparmorFactCollector.collect()['apparmor'].keys()

# Generated at 2022-06-23 00:41:32.094505
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    # Check that the constructor created an object with the correct name
    assert fc.name == 'apparmor'

# Generated at 2022-06-23 00:41:34.120449
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert len(fc._fact_ids) == 0



# Generated at 2022-06-23 00:41:37.578419
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:41:39.081736
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.__doc__

# Generated at 2022-06-23 00:41:41.249445
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    obj = ApparmorFactCollector()
    assert 'apparmor' in obj.collect()


# Generated at 2022-06-23 00:41:46.384334
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = apparmor_fact_collector.collect(collected_facts)
    assert len(apparmor_facts) == 1
    assert 'apparmor' in apparmor_facts
    assert apparmor_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:41:48.147182
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_apparmor = ApparmorFactCollector()
    assert test_apparmor is not None


# Generated at 2022-06-23 00:41:51.748050
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = {}
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect(module, collected_facts)
    assert facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:54.170591
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"

# Generated at 2022-06-23 00:42:00.404332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector._fact_ids == set()

    if os.path.exists('/sys/kernel/security/apparmor'):
        ret = apparmor_fact_collector.collect()
        assert ret == {'apparmor': {'status': 'enabled'}}
    else:
        ret = apparmor_fact_collector.collect()
        assert ret == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:05.287374
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    facts = fc.collect()
    assert len(facts['apparmor']) > 0
    assert 'disabled' in facts['apparmor']['status'] or 'enabled' in facts['apparmor']['status']

# Generated at 2022-06-23 00:42:06.379773
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert True

# Generated at 2022-06-23 00:42:08.182095
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()



# Generated at 2022-06-23 00:42:12.179012
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert not apparmor_fc._fact_ids



# Generated at 2022-06-23 00:42:15.247073
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:42:16.783208
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    v = ApparmorFactCollector()
    assert v.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:25.811490
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aac = ApparmorFactCollector()

    # Test with Apparmor enabled
    with open('/sys/kernel/security/apparmor', 'w') as f:
        f.write('')
    aac.collect()
    status = aac.get_fact('apparmor', {})['status']
    assert status == 'enabled'

    # Test with Apparmor disabled
    os.remove('/sys/kernel/security/apparmor')
    aac.collect()
    status = aac.get_fact('apparmor', {})['status']
    assert status == 'disabled'

# Generated at 2022-06-23 00:42:29.280884
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    factCollector = ApparmorFactCollector()
    assert factCollector.name == 'apparmor'
    assert factCollector._fact_ids == set()



# Generated at 2022-06-23 00:42:31.383157
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  assert ApparmorFactCollector.name == "apparmor"
  assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:42:35.910804
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert isinstance(ApparmorFactCollector._fact_ids, set)

# Generated at 2022-06-23 00:42:41.416919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create a instance of FactCollector
    fact_collector = ApparmorFactCollector()

    # call method collect
    returned_facts_dict = fact_collector.collect()

    # assert that method collect returned the dictionary
    assert returned_facts_dict.get('apparmor', {}).get('status') == 'disabled'

# Generated at 2022-06-23 00:42:44.123445
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    assert test_obj.name == "apparmor"
    assert test_obj._fact_ids == set()


# Generated at 2022-06-23 00:42:46.237845
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:42:48.413055
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:42:53.610631
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()

    # Check whether instance has attibutes
    assert hasattr(ac, 'name')
    assert hasattr(ac, '_fact_ids')

    # Check whether attibute values are correct
    assert ac.name == 'apparmor'
    assert ac._fact_ids == set()


# Generated at 2022-06-23 00:42:56.775344
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    cur_obj = ApparmorFactCollector()
    return_obj = cur_obj.collect()
    assert isinstance(return_obj, dict)

# Generated at 2022-06-23 00:42:58.359631
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    object = ApparmorFactCollector()
    assert object.name == 'apparmor'

# Generated at 2022-06-23 00:42:59.580748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {}}

# Generated at 2022-06-23 00:43:02.802149
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    aafc._module = mock.MagicMock()
    aafc._collect()
    assert aafc._module.exit_json.called

# Generated at 2022-06-23 00:43:08.786197
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_dict = {
        'ansible_apparmor': {
            'status': 'enabled'
        }
    }
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    # Ensure that result is a dictionary
    assert(isinstance(result, dict))
    # Ensure that result is equal to test_dict
    assert(result == test_dict)

# Generated at 2022-06-23 00:43:10.194686
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:43:12.263021
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert not apparmor._fact_ids

# Generated at 2022-06-23 00:43:13.981667
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    x = {'apparmor': {'status': 'disabled'}}
    assert a.collect() == x

# Generated at 2022-06-23 00:43:17.088192
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:43:23.768661
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_apparmor_status = 'enabled'
    else:
        expected_apparmor_status = 'disabled'
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == expected_apparmor_status

# Generated at 2022-06-23 00:43:35.406317
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Path for Apparmor is not available
    def mocked_path_exists(path):
        return False

    # Path for Apparmor is available
    def mocked_path_exists_1(path):
        return True

    # Run the collect method
    ApparmorFactCollector().collect()
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

    original_path_exists = os.path.exists
    os.path.exists = mocked_path_exists
    # Run the collect method
    ApparmorFactCollector().collect()
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

    os.path.exists = mocked_path_exists_1
    # Run the collect method
    ApparmorFactCollector().collect

# Generated at 2022-06-23 00:43:42.062438
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts_dict = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    facts_dict['apparmor'] = apparmor_facts
    return facts_dict

# Generated at 2022-06-23 00:43:43.671613
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-23 00:43:48.093180
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = {
        'apparmor': {
            'status': 'enabled'
            }
        }
    assert apparmor_facts == apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:43:54.594656
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    apparmor_collector = ApparmorFactCollector()
    assert isinstance(apparmor_collector, BaseFactCollector)
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()
    apparmor_facts = apparmor_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}



# Generated at 2022-06-23 00:43:59.185104
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    apparmor_facts_collector_instance = ApparmorFactCollector()
    collected_facts = apparmor_facts_collector_instance.collect(module=module, collected_facts=collected_facts)
    assert type(collected_facts['apparmor']) is dict

# Generated at 2022-06-23 00:44:06.288453
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    def setup_module(self):
        module_mock = MagicMock()
        module_mock.params = {}
        ApparmorFactCollector.__init__(self, module=module_mock)

    def test_apparmor_enabled(self):
        def set_side_effect_for_call(p_sc_result, p_p_result):
            def side_effect_for_call(*args):
                if args[0] == 'systemctl status apparmor':
                    return p_sc_result
                else:
                    return p_p_result

            return side_effect_for_call

        if ApparmorFactCollector.__name__ in sys.modules:
            reload (sys.modules[ApparmorFactCollector.__name__])

        mock_module = MagicMock()

# Generated at 2022-06-23 00:44:07.539011
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    object = ApparmorFactCollector()
    assert object is not None
    assert object._fact_ids == set()
    assert object.name == 'apparmor'

# Generated at 2022-06-23 00:44:09.185652
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:44:11.239377
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect()['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:44:15.325297
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    obj = ApparmorFactCollector()
    obj.__path__ = []

    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    assert obj.collect() == {'apparmor': apparmor_facts}

# Generated at 2022-06-23 00:44:18.647125
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert set(['apparmor']) == collector._fact_ids
    assert collector.collect() == '{}'

# Generated at 2022-06-23 00:44:19.870026
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-23 00:44:22.668138
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect()
    assert 'apparmor' in result
    assert 'status' in result['apparmor']

# Generated at 2022-06-23 00:44:25.335812
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    res = collector.collect()
    assert "apparmor" in res
    assert res["apparmor"]["status"] in ["enabled", "disabled"]

# Generated at 2022-06-23 00:44:26.957013
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts= ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'

# Generated at 2022-06-23 00:44:33.102092
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import ansible.module_utils.facts.collector
    c = ansible.module_utils.facts.collector.get_collector('ApparmorFactCollector', {})
    facts = c.collect()
    assert facts.get('apparmor') == {'status': 'disabled'}

# Generated at 2022-06-23 00:44:35.426048
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    apparmor_facts = {}
    apparmor_facts = f.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:44:36.644045
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
        ApparmorFactCollector()

# Generated at 2022-06-23 00:44:39.762885
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:44:42.383555
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 00:44:43.814552
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test = ApparmorFactCollector()
    assert test is not None


# Generated at 2022-06-23 00:44:45.267077
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa = ApparmorFactCollector()
    assert aa.name == 'apparmor'

# Generated at 2022-06-23 00:44:48.268741
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-23 00:44:52.073935
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()
    assert collector.collect() == {}

# Generated at 2022-06-23 00:44:53.133973
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:45:01.476945
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    context = ApparmorFactCollector.collect.__globals__
    os_path_exists = context['os.path.exists']

    class Module:
        def __init__(self):
            self.params = {}

    def my_os_path_exists(path):
        return True

    context['os.path.exists'] = my_os_path_exists

    module = Module()

    # Run collect method
    result = ApparmorFactCollector.collect(module)

    # Reset the context
    context['os.path.exists'] = os_path_exists

    # Verify results
    assert({'apparmor': {'status': 'enabled'}} == result)


# Generated at 2022-06-23 00:45:06.869955
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector(None)
    os.path = MagicMock()
    os.path.exists = MagicMock(return_value=True)
    _apparmor_facts = apparmor_fact_collector.collect()
    assert _apparmor_facts['apparmor']['status'] == 'enabled'
# End of unit test

# Generated at 2022-06-23 00:45:07.767212
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-23 00:45:09.758389
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector(name='apparmor', collected_facts={})
    apparmor_collector.collect()
    assert True

# Generated at 2022-06-23 00:45:11.116361
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:45:14.231364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:21.286869
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import ansible.module_utils.facts.collector
    aafc = ApparmorFactCollector()
    aafc_dict = aafc.collect()
    assert 'apparmor' in aafc_dict.keys()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert aafc_dict['apparmor']['status'] == 'enabled'
    else:
        assert aafc_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:23.271008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector(None)
    assert collector.collect()['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:45:28.013158
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector('ApparmorFactCollector.collect')
    facts = c.collect()

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts['apparmor']['status'] == 'enabled'
    else:
        assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:30.654088
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None

if __name__ == '__main__':
    test_ApparmorFactCollector()

# Generated at 2022-06-23 00:45:32.921624
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_obj = ApparmorFactCollector()
    output = class_obj.collect()
    assert output == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:45:38.611915
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector_obj = ApparmorFactCollector()
    # Test with existing /var/lib/libvirt/images directory
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_collector_obj.name == 'apparmor'
        apparmor = apparmor_collector_obj.collect()
        for key in ['apparmor']:
            assert key in apparmor
            for key1 in ['status']:
                assert key1 in apparmor['apparmor']
                assert apparmor['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:45:41.126200
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.__class__.__name__ == 'ApparmorFactCollector'


# Generated at 2022-06-23 00:45:43.973218
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:45:46.812530
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    result = a.collect()
    print(result)
    assert result == {
        'apparmor': {
            'status': 'disabled'
        }
    }


# Generated at 2022-06-23 00:45:50.018262
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect()['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:45:51.546260
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-23 00:45:55.599769
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    expected_fact = {'apparmor': {'status': 'disabled'}}
    actual_fact = apparmor_fact_collector.collect()
    assert expected_fact == actual_fact

# Generated at 2022-06-23 00:45:59.255598
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfact = ApparmorFactCollector()
    assert apparmorfact.name == 'apparmor'
    assert apparmorfact._fact_ids == set()

if __name__ == '__main__':
    test_ApparmorFactCollector()

# Generated at 2022-06-23 00:46:00.802604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()
    facts = ac.collect()
    assert 'apparmor' in facts['apparmor']

# Generated at 2022-06-23 00:46:02.939015
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:46:04.760338
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """sampledata/ansible_facts.d/apparmor.fact"""


# Generated at 2022-06-23 00:46:06.539088
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'


# Generated at 2022-06-23 00:46:09.494688
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert "apparmor" in apparmor_collector.collect()

# Generated at 2022-06-23 00:46:11.513056
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:46:12.440141
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    print(ApparmorFactCollector())

# Generated at 2022-06-23 00:46:14.545771
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()

# Generated at 2022-06-23 00:46:22.091332
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    module = mock.Mock()
    collected_facts = {}
    module_path = os.path.dirname(os.path.realpath(__file__)) + '/systemd.py'
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_facts = {'apparmor': { 'status': 'enabled' } }
        assert expected_facts == ApparmorFactCollector().collect(module, collected_facts)
    else:
        expected_facts = {'apparmor': { 'status': 'disabled' } }
        assert expected_facts == ApparmorFactCollector().collect(module, collected_facts)

# Generated at 2022-06-23 00:46:24.058931
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:46:26.067276
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()

# Generated at 2022-06-23 00:46:28.612628
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:32.220405
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:35.281180
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor']
    assert 'status' in facts['apparmor'].keys()

# Generated at 2022-06-23 00:46:38.088394
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:46:42.648694
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import get_all_facts

    all_facts = get_all_facts(FactsCollector())
    assert 'apparmor' in all_facts
    assert not all_facts['apparmor']['status'] == 'unknown'

# Generated at 2022-06-23 00:46:45.209010
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Test for method get_fact_id of class ApparmorFactCollector

# Generated at 2022-06-23 00:46:52.063667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import mock

    ansible_module = mock.MagicMock()
    ansible_module.params = {}
    ansible_module.params['gather_subset'] = ['all']
    ansible_module.params['gather_timeout'] = 10
    ansible_module.params['filter'] = ['apparmor']

    path = '/sys/kernel/security/apparmor'
    if not os.path.exists(path):
        os.makedirs(path)

    apparmor_facts = ApparmorFactCollector.collect(ansible_module)

    assert apparmor_facts['apparmor']['status'] == 'enabled'

    os.rmdir(path)

    if os.path.exists(path):
        os.removedirs(path)

    apparmor_facts = ApparmorFact

# Generated at 2022-06-23 00:46:54.245125
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:47:00.566022
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    if not os.path.exists('/sys/kernel/security/apparmor'):
        os.makedirs('/sys/kernel/security/apparmor')
    assert ApparmorFactCollector().collect() == {'apparmor':
        {'status': 'enabled'}}
    os.rmdir('/sys/kernel/security/apparmor')
    assert ApparmorFactCollector().collect() == {'apparmor':
        {'status': 'disabled'}}

# Generated at 2022-06-23 00:47:03.084217
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == "apparmor"
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:47:10.882824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Override os.path.exists for testing purpose
    mp_exists = os.path.exists
    def my_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        return mp_exists(path)

    # Test with apparmor enabled
    os.path.exists = my_exists
    af = ApparmorFactCollector()
    result = af.collect()
    apparmor_facts = {'apparmor': {'status': 'enabled'}}
    assert result == apparmor_facts

    # Test with apparmor disabled
    def my_exists2(path):
        if path == '/sys/kernel/security/apparmor':
            return False
        return mp_exists(path)
    os.path.exists = my_exists2

# Generated at 2022-06-23 00:47:13.724453
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    apparmor_facts = apparmor_fc.collect()
    assert apparmor_facts['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:47:21.557391
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_module = None
    fake_collected_facts = dict()

    f = ApparmorFactCollector()
    f._module = fake_module
    f._collect_platform_facts = lambda x: None

    facts_dict = f.collect(fake_module, fake_collected_facts)
    assert dict == type(facts_dict)
    assert 1 == len(facts_dict)
    assert dict == type(facts_dict['apparmor'])

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 00:47:27.234050
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        expected_result = {'apparmor': {'status': 'enabled'}}
        result = collector.collect()
        assert result == expected_result
    else:
        expected_result = {'apparmor': {'status': 'disabled'}}
        result = collector.collect()
        assert result == expected_result


# Generated at 2022-06-23 00:47:28.564135
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact = ApparmorFactCollector()
    assert fact.name == 'apparmor'

# Generated at 2022-06-23 00:47:31.688809
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Check if class is initialised with the correct name
    assert ApparmorFactCollector.name == 'apparmor'