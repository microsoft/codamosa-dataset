

# Generated at 2022-06-23 00:37:35.524951
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()



# Generated at 2022-06-23 00:37:38.139588
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector is not None
    assert apparmor_collector.name == 'apparmor'
    assert not apparmor_collector._fact_ids

# Generated at 2022-06-23 00:37:41.650789
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor', 'Incorrect name'
    assert apparmor_facts.collect()['apparmor']['status'] == 'disabled', 'Incorrect Status'

# Generated at 2022-06-23 00:37:45.220303
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Unit test for method collect of class ApparmorFactCollector """
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}, 'test of method collect of class ApparmorFactCollector failed'

# Generated at 2022-06-23 00:37:47.296094
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    apparmor_facts = c.collect()
    assert 'apparmor' in apparmor_facts



# Generated at 2022-06-23 00:37:50.488165
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()

    facts = apparmor_collector.collect()

    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:37:51.454399
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:37:55.108246
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Construct the object
    apparmor_fc = ApparmorFactCollector(None)

    # Invoke the method
    facts_dict = apparmor_fc.collect()
    apparmor_facts = facts_dict['apparmor']
    assert (apparmor_facts['status'] == 'enabled') or (apparmor_facts['status'] == 'disabled')

# Generated at 2022-06-23 00:37:59.740730
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Tests the collect method of the ApparmorFactCollector classs
    """
    test_collector = ApparmorFactCollector()

    result = test_collector.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:02.258204
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aaf = ApparmorFactCollector()
    assert isinstance(aaf, ApparmorFactCollector)
    facts = aaf.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-23 00:38:05.173605
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = ApparmorFactCollector()
    assert type(facts._fact_ids) == set, "apparmor collectr didn't create a set for _fact_ids."


# Generated at 2022-06-23 00:38:07.247714
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:38:08.562437
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    apparmor_fact_collector = ApparmorFactCollector()


# Generated at 2022-06-23 00:38:11.235139
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:13.708343
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test = ApparmorFactCollector()
    result = test.collect()
    assert 'apparmor' in result

# Generated at 2022-06-23 00:38:19.144008
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a instance of class ApparmorFactCollector
    apparmor_collector = ApparmorFactCollector()

    # Run method collect of class ApparmorFactCollector
    results = apparmor_collector.collect()

    # Test method collect of class ApparmorFactCollector
    assert results['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:38:20.556293
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()

# Generated at 2022-06-23 00:38:24.613863
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    result = apparmor_collector.collect()
    assert result == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-23 00:38:26.458983
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts == {}

# Generated at 2022-06-23 00:38:27.898438
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fcol = ApparmorFactCollector()
    assert fcol.name == 'apparmor'

# Generated at 2022-06-23 00:38:32.508907
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Creating instance of ApparmorFactCollector class
    test_apparmor_collector = ApparmorFactCollector()
    # Calling collect funtion of class ApparmorFactCollector
    res = test_apparmor_collector.collect()
    # Asserting expected result with actual result for status key
    assert res['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:38:43.991382
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Mock module to return module.run_command
    class MockModule(object):
        pass
    module = MockModule()

    # Mock collected_facts
    collected_facts = {}
    class MockBaseFactCollector(object):
        pass
    base_fact_collector = MockBaseFactCollector()
    collected_facts['ansible_facts'] = { 'base_fact_collector' : base_fact_collector }

    # Mock os.path.exists
    import __builtin__
    original_exists = __builtin__.__dict__['exists']
    def mock_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return original_exists(path)

    __builtin__.__dict__['exists'] = mock_exists

# Generated at 2022-06-23 00:38:46.217140
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'


# Generated at 2022-06-23 00:38:49.651131
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # Give some input to the collector
    apparmor_fact_collector.collect()
    assert 'apparmor' in apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:38:53.392887
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:55.508325
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:38:58.214927
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == "apparmor"
    assert apparmor_fc._fact_ids == set()
    assert apparmor_fc.collect() == {"apparmor": {"status": "disabled"}}

# Generated at 2022-06-23 00:38:59.275512
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert(a.name == 'apparmor')
    assert(a._fact_ids == set())


# Generated at 2022-06-23 00:39:00.562848
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:39:02.159792
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()


# Generated at 2022-06-23 00:39:04.131891
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    amc = ApparmorFactCollector()
    facts = amc.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:39:06.379119
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()



# Generated at 2022-06-23 00:39:18.499597
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector
    from ansible.module_utils.facts import timeout

    def test_collect(self, module=None, collected_facts=None):
        facts_dict = {}
        apparmor_facts = {}
        if os.path.exists('/sys/kernel/security/apparmor'):
            apparmor_facts['status'] = 'enabled'
        else:
            apparmor_facts['status'] = 'disabled'

        facts_dict['apparmor'] = apparmor_facts
        return facts_dict

    BaseFactCollector._collect_platform_facts = ApparmorFactCollector.collect


# Generated at 2022-06-23 00:39:21.331750
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert isinstance(apparmor_collector.collect(), dict)

# Generated at 2022-06-23 00:39:26.023086
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )
    fact_collector = ApparmorFactCollector(ansible_module=ansible_module)
    apparmor_facts = fact_collector.collect()
    assert(apparmor_facts['apparmor']['status'] == 'disabled')

# Generated at 2022-06-23 00:39:26.607070
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:39:29.080925
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert 'apparmor' in apparmorFactCollector._fact_ids

# Generated at 2022-06-23 00:39:39.041486
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create a instance of class (not initialized)
    my_ApparmorFactCollector = ApparmorFactCollector()

    # Set property _fact_ids to a valid value
    ApparmorFactCollector._fact_ids = set()

    # Invoke method collect of class ApparmorFactCollector
    return_value = ApparmorFactCollector.collect()

    # Assert return value
    assert return_value == {}

    # Assert the key 'apparmor' does not exist
    assert 'apparmor' not in return_value

    # Assert _fact_ids property
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:39:44.817953
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # We first create an instance of the ApparmorFactCollector class
    apparmor_facts_collector = ApparmorFactCollector()

    # Then we run the collect method and store the result in a facts variable
    facts = apparmor_facts_collector.collect()

    # Then, we can assert that all the values are correct
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:48.672857
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    To test ApparmorFactCollector.collect method:
    """
    apparmorFactCollector = ApparmorFactCollector()

    assert apparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:39:51.602734
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test class ApparmorFactCollector."""
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:39:56.211828
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_result = apparmor_collector.collect()

    assert 'apparmor' in apparmor_result
    assert apparmor_result['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:39:56.996079
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:39:58.923210
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    app = ApparmorFactCollector()
    assert app.name == 'apparmor'
    assert app._fact_ids == set()


# Generated at 2022-06-23 00:40:01.643762
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert not apparmor_fact_collector._fact_ids

# Generated at 2022-06-23 00:40:05.585211
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Constructor of ApparmorFactCollector()
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:40:09.618820
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    test_facts_dict = {}
    apparmor_collector.collect(collected_facts=test_facts_dict)
    apparmor_facts = test_facts_dict['apparmor']
    assert isinstance(apparmor_facts, dict)
    assert 'status' in apparmor_facts

# Generated at 2022-06-23 00:40:12.394240
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Testing constructor of class ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:40:15.634666
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()

    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set([])

# Generated at 2022-06-23 00:40:17.787701
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:24.717868
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    def mock_os_path_exists(path):
        return True

    monkeypatch.setattr(os.path, 'exists', mock_os_path_exists)

    fc = ApparmorFactCollector()
    expected_result = {'apparmor': {'status': 'enabled'}}
    result = fc.collect()
    assert result == expected_result

# Generated at 2022-06-23 00:40:27.549517
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-23 00:40:30.920203
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_class = ApparmorFactCollector()
    assert test_class.name == 'apparmor'
    assert isinstance(test_class._fact_ids, set)
    assert 'apparmor' in test_class._fact_ids

# Generated at 2022-06-23 00:40:31.875441
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector()
    assert True

# Generated at 2022-06-23 00:40:36.877704
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = AnsibleModule({})
    ApparmorfactCollector = ApparmorFactCollector(module)
    collected_facts = {}
    expected = {'apparmor': {'status': 'enabled'}}
    ansible_facts = ApparmorfactCollector.collect(module, collected_facts)
    assert ansible_facts == expected



# Generated at 2022-06-23 00:40:39.925559
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()
    apparmor_facts = ac.collect()
    assert type(apparmor_facts) is dict
    assert 'apparmor' in apparmor_facts
    assert len(apparmor_facts['apparmor']) == 1

# Generated at 2022-06-23 00:40:43.715215
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    result = a.collect()
    assert 'apparmor' in result
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:51.707915
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
  a_fact_collector = ApparmorFactCollector()
  assert set(a_fact_collector.collect().keys()) == set(['apparmor'])
  # check that the returned dictionary is what we are expecting
  assert a_fact_collector.collect()['apparmor'].get('status') in ['enabled', 'disabled']

# Generated at 2022-06-23 00:40:57.143300
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    collected_facts = collector.collect()
    assert 'apparmor' in collected_facts

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert 'enabled' in collected_facts['apparmor']['status']
    else:
        assert 'disabled' in collected_facts['apparmor']['status']

# Generated at 2022-06-23 00:41:05.525641
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    command = "sudo " + "mkdir" + ' ' + "/sys/kernel/security/apparmor"
    os.system(command)
    apparmor_facts_collector_instance = ApparmorFactCollector()
    apparmor_facts_collector_instance.collect()
    assert apparmor_facts_collector_instance.fact_ids == set(['apparmor'])
    assert apparmor_facts_collector_instance.facts['apparmor']['status'] == 'enabled'
    command = "sudo rm -rf" + ' ' + "/sys/kernel/security/apparmor"
    os.system(command)

# Generated at 2022-06-23 00:41:09.227006
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_module = DummyAnsibleModule()
    ansible_module.params = {'collect_subset': ['all'], 'gather_timeout': 10,
                             'filter': '*'}
    facts_collector = ApparmorFactCollec

# Generated at 2022-06-23 00:41:12.921141
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    facts = c.collect()
    required_keys = [ 'status' ]

    for key in required_keys:
        assert key in facts['apparmor'], "required key {} not found in facts['apparmor']".format(key)

# Self test for ApparmorFactCollector

# Generated at 2022-06-23 00:41:17.131232
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()
    assert apparmor_facts.collect()['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:41:20.075064
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {u'apparmor': {u'status': u'disabled'}}

# Generated at 2022-06-23 00:41:23.725177
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Parameters
    apparmorFactCollector = ApparmorFactCollector()
    # Execution
    apparmorFactCollector.collect()
    # Assertion
    assert apparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:41:26.805736
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-23 00:41:29.095793
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc
    assert aafc.name == 'apparmor'


# Generated at 2022-06-23 00:41:32.293899
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect(None, None)
    # For the moment, we just check that the result is not empty
    assert result != None
    assert result['apparmor'] != None

# Generated at 2022-06-23 00:41:43.815073
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mod = AnsibleModule(argument_spec={})

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a buffer
    mybuf = cStringIO()

    # Create an AnsibleModule object
    mod = AnsibleModule(
        argument_spec = dict(
            foo = dict(required=False, default=None),
        ),
        supports_check_mode=True
    )
    # Create an ApparmorFactCollector object
    afc = ApparmorFactCollector(mod)
    # Create a variable for the result of the test
    result = dict(
        changed=False,
        ansible_facts=dict(
            apparmor=dict(
                status='enabled'
            )
        )
    )
    # Run collect method and compare with expected result

# Generated at 2022-06-23 00:41:54.625047
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector

    module = FakeModule()
    collected_facts = {}

    def fake_collection_execution(self, module, collected_facts,
                                  collectors=None, fact_ids=None):
        global results
        apparmor_facts = ApparmorFactCollector().collect(module, collected_facts)
        results = apparmor_facts

    collector = FactsCollector(module, collected_facts)
    collector._execute_collection = fake_collection_execution
    collector._execute_collection(module, collected_facts)

# Generated at 2022-06-23 00:41:56.787368
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:42:00.278526
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    test = ApparmorFactCollector()
    result = test.collect(module=module, collected_facts=collected_facts)
    assert result['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:42:01.775161
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:42:05.075310
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:42:07.561927
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:42:19.650805
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # test file exists
    file_exists = []
    class fake_os:
        class path:
            @staticmethod
            def exists(path):
                if path == '/sys/kernel/security/apparmor':
                    return True
                else:
                    return False
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect(os=fake_os)
    assert facts_dict['apparmor']['status'] == 'enabled'

    # test file does not exist
    file_exists = []
    class fake_os:
        class path:
            @staticmethod
            def exists(path):
                if path == '/sys/kernel/security/apparmor':
                    return False
                else:
                    return True
    apparmor_fact_collector = Apparmor

# Generated at 2022-06-23 00:42:22.956586
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'


# Generated at 2022-06-23 00:42:25.751197
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Test the constructor of class ApparmorFactCollector
    """
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    

# Generated at 2022-06-23 00:42:30.415518
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Run facts collection
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()

    # Verify expected results
    assert facts_dict == {'apparmor': {'status': 'disabled'}}
    assert isinstance(facts_dict, dict)


# Generated at 2022-06-23 00:42:33.986541
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()


# Generated at 2022-06-23 00:42:37.727972
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_id  == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set(['apparmor'])

# Generated at 2022-06-23 00:42:40.061659
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector.collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:42:44.484203
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a collector object
    collector = ApparmorFactCollector()
    # Create a facts dictionary
    facts_dict = {}
    # Execute the code to be tested
    facts_dict = collector.collect(collected_facts=facts_dict)
    # Verify the result
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:42:46.521560
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:42:48.744057
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    facts_dict = fc.collect()
    assert 'apparmor' in facts_dict.keys()
    assert 'status' in facts_dict['apparmor'].keys()

# Generated at 2022-06-23 00:42:51.051534
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:42:52.996284
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-23 00:42:55.591255
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert 'apparmor' in facts_dict.keys()

# Generated at 2022-06-23 00:43:06.464994
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    path = os.path.join(os.path.dirname(__file__), 'unit/output/Apparmor_output.yaml')
    print('Loading output from %s' % path)
    with open(path,'rb') as _file:
        ExampleOutput = _file.read()

    path = os.path.join(os.path.dirname(__file__), 'unit/output/Apparmor_expect.yaml')
    print('Loading expect from %s' % path)
    with open(path,'rb') as _file:
        ExpectedOutput = _file.read()

    Apparmor = ApparmorFactCollector()

    Result = Apparmor.collect()
    print('Returned results are:')
    print(Result)
    assert Result == eval(ExampleOutput)

# Generated at 2022-06-23 00:43:08.685735
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-23 00:43:11.550604
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    abc = ApparmorFactCollector()
    results = abc.collect()

    assert results['apparmor']['status'] == 'enabled' or results['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:13.520435
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    assert fc.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:18.364607
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name
    apparmor_collector = ApparmorFactCollector()
    assert set() == apparmor_collector._fact_ids
    assert 'apparmor' == apparmor_collector.name


# Generated at 2022-06-23 00:43:20.137014
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aaf = ApparmorFactCollector()
    assert aaf.name == 'apparmor'


# Generated at 2022-06-23 00:43:26.907512
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = object()
    mock_collect_facts = object()
    expected_facts = {
        "apparmor":{
            "status":"enabled"
        }
    }

    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect(module=mock_module, collected_facts=mock_collect_facts)
    assert collected_facts == expected_facts, "Facts not match"

# Generated at 2022-06-23 00:43:27.385472
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:43:29.837330
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector.name
    assert 'enabled' == apparmor_fact_collector.collect()['apparmor']['status']

# Generated at 2022-06-23 00:43:33.720149
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aaf = ApparmorFactCollector()
    assert aaf.name == "apparmor"
    assert aaf._fact_ids == set()


# Generated at 2022-06-23 00:43:35.637370
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'

# Generated at 2022-06-23 00:43:48.004033
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import sys
    import os.path
    import tempfile
    import shutil

    apparmor = ApparmorFactCollector()

    # No apparmor
    temp_dir = tempfile.mkdtemp()
    sys.modules['ansible.module_utils.facts.collector'].__ansible_module__ = None
    sys.modules['ansible.module_utils.facts.collector'].__ansible_version__ = None
    sys.modules['ansible.module_utils.facts.collector'].__ansible_facts__ = {}
    sys.modules['ansible.module_utils.facts.collector'].__ansible_verbosity__ = 1
    sys.modules['ansible.module_utils.facts.collector'].__ansible_cmdline__ = {'verbosity': 1}

# Generated at 2022-06-23 00:43:50.895180
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    actual_result = ApparmorFactCollector().name
    expected_result = "apparmor"

    assert actual_result == expected_result

# Generated at 2022-06-23 00:43:51.864203
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:43:55.103637
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Creating instance of class ApparmorFactCollector
    # and call method collect
    results = ApparmorFactCollector().collect()

    # If status is enabled, apparmor is present
    assert results == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:57.884213
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:44:00.578467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmor_facts = apparmorFactCollector.collect(None)
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:02.759754
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-23 00:44:05.552571
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'


# Generated at 2022-06-23 00:44:08.611196
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    _apparmor = ApparmorFactCollector()
    assert _apparmor.name == 'apparmor'
    assert _apparmor._fact_ids == set()


# Generated at 2022-06-23 00:44:12.292118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    # Test 'status' key
    apparmor.collect()
    status = apparmor.collect()['apparmor']['status']
    assert status in ['enabled', 'disabled']

# Generated at 2022-06-23 00:44:14.219600
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts, ApparmorFactCollector)

# Generated at 2022-06-23 00:44:15.800161
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    facts_dict = c.collect()
    assert facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:44:25.856283
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import MagicMock
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector

    my_collector = ApparmorFactCollector()
    my_test_class = FactCollector()
    my_test_class.collectors = [my_collector]

    my_module = MagicMock()
    my_module.get_bin_path.return_value = ''
    my_module.run_command.return_value = (0, "", "")
    my_module.params = {}

    my_collector.collect(module=my_module, collected_facts=None)

    # Now test if my_collector.collect() returns the right dict.
    assert my_collect

# Generated at 2022-06-23 00:44:28.206371
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    acl = ApparmorFactCollector()
    acl.collect()

# Generated at 2022-06-23 00:44:30.122927
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:44:36.294040
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    apparmor_collector = ApparmorFactCollector()
    facts_dict = apparmor_collector.collect(module=module, collected_facts=collected_facts)
    # Verifying the absence of 'apparmor' key in dictionary 'facts_dict' for SUSE based systems
    assert 'apparmor' in facts_dict
    apparmor_status = facts_dict.get('apparmor')
    # Verifying 'apparmor' key in dictionary 'facts_dict' returns a dictionary for SUSE based systems
    assert isinstance(apparmor_status, dict)

# Generated at 2022-06-23 00:44:43.097913
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()
    # Apparmor is enabled
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor.collect() == {'apparmor': {'status': 'enabled'}}
    # Apparmor is disabled
    else:
        assert apparmor.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:44:45.371397
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-23 00:44:51.205135
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = MagicMock()

# Generated at 2022-06-23 00:44:55.125540
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = {'apparmor': {'status': 'enabled'}}
    assert facts_dict == apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:44:58.121340
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()
    assert a.collect() == {'apparmor':{'status':'disabled'}}

# Generated at 2022-06-23 00:45:01.204532
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert not a._fact_ids

# Generated at 2022-06-23 00:45:03.433532
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() is not None

# Generated at 2022-06-23 00:45:09.061927
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of class ApparmorFactCollector
    apparmor_facts_collector = ApparmorFactCollector()
    # Result from method collect
    apparmor_facts = apparmor_facts_collector.collect()
    # Asserting if both are equal
    assert apparmor_facts == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-23 00:45:14.280554
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()
    assert ac is not None
    assert ac.name == "apparmor"
    assert isinstance(ac._fact_ids, set)
    assert ac.collect() is not None

# Generated at 2022-06-23 00:45:17.354356
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    fact_collector = ApparmorFactCollector()

    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:45:20.407677
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = {
        'apparmor': {
            'status': 'enabled'
        }
    }
    aafc = ApparmorFactCollector()
    assert aafc.collect() == result

# Generated at 2022-06-23 00:45:22.823328
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # TODO: Remove import of os from ansible.module_utils.facts.collector.py
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:45:25.406114
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector()
    assert instance.name == 'apparmor'
    assert instance._fact_ids == set()


# Generated at 2022-06-23 00:45:27.530835
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_mock = ApparmorFactCollector()

    result = apparmor_mock.collect()

    assert 'apparmor' in result

# Generated at 2022-06-23 00:45:29.894754
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()


# Generated at 2022-06-23 00:45:31.241737
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert(obj.name == 'apparmor')

# Generated at 2022-06-23 00:45:46.522736
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    os.path.exists = mock.Mock()
    # Before the collect method is called
    os.path.exists.return_value = False
    os.path.exists.mock_calls = []

    # The collect method is called
    apparmor_facts_dict = apparmor_fact_collector.collect()

    assert os.path.exists.mock_calls == [call('/sys/kernel/security/apparmor')]
    assert apparmor_facts_dict == {'apparmor': {'status': 'disabled'}}

    # The collect method is called
    os.path.exists.return_value = True
    apparmor_facts_dict = apparmor_fact_collector.collect()


# Generated at 2022-06-23 00:45:53.527681
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method ApparmorFactCollector.collect
    """
    apparmor_fact_collector = ApparmorFactCollector()

    facts_dict = apparmor_fact_collector.collect()
    assert 'apparmor' in facts_dict
    assert 'status' in facts_dict['apparmor']
    assert facts_dict['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:45:57.072428
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect()
    assert type(result) is dict
    assert 'apparmor' in result

    assert type(result['apparmor']) is dict
    assert 'status' in result['apparmor']

# Generated at 2022-06-23 00:46:00.569235
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    facts = {}
    apparmor_collector.collect(None, facts)
    assert ('apparmor' in facts)
    assert ('status' in facts['apparmor'])

# Generated at 2022-06-23 00:46:03.124841
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collector = ApparmorFactCollector()
    test_facts = test_collector.collect()
    assert test_facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:46:07.314434
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Instantiating a ApparmorFactCollector object
    apparmor_fact_collector = ApparmorFactCollector()
    # Calling method collect from the object
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:46:16.652172
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Mock os.path.exists
    module = 'ansible.module_utils.facts.linux.apparmor'
    old_exists = __import__(module, globals(), locals(), ['os']).os.path.exists
    def mock_exists(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        return old_exists(path)
    __import__(module, globals(), locals(), ['os']).os.path.exists = mock_exists

    collector = ApparmorFactCollector()
    result = collector.collect()

    assert 'apparmor' in result
    assert 'status' in result['apparmor']
    assert result['apparmor']['status'] == 'enabled'

    # Restore os.path.exists

# Generated at 2022-06-23 00:46:18.402294
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    result = apparmor_fc.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:46:20.507259
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:46:22.709684
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:25.429077
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Returns true if the class constructor is functional.
    """
    # Tested in unit test:
    # - test_apparmor.py
    #   - test_apparmor_facts
    return True

# Generated at 2022-06-23 00:46:28.513628
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()
    assert not obj.collect()

# Generated at 2022-06-23 00:46:31.052626
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    try:
        fc.collect()
    except Exception:
        pass
    else:
        assert False


# Generated at 2022-06-23 00:46:35.502505
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_collector.collect()['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:40.760991
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test with passing class ApparmorFactCollector object to
    collect method and check if it returns
    expected facts as output
    """
    apparmor_collector = ApparmorFactCollector()
    output = apparmor_collector.collect()
    assert output['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:46:43.929182
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect(None, None)

    apparmor_dict = apparmor_collector.get_facts()
    assert(apparmor_dict['apparmor'])

# Generated at 2022-06-23 00:46:46.853176
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:46:47.779313
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:46:51.119426
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {
        'apparmor': {
            'status': 'disabled'
        }
    }

# Generated at 2022-06-23 00:46:53.943137
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect() 
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:46:58.739231
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Check if ApparmorFactCollector class is defined or not -
    assert 'ApparmorFactCollector' in globals()
    # Create object of ApparmorFactCollector class
    apparmor_obj = ApparmorFactCollector()
    # Check if object of ApparmorFactCollector class is created or not -
    assert apparmor_obj is not None

# Generated at 2022-06-23 00:47:00.645758
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == 'apparmor'
    assert aafc._fact_ids == set()

# Generated at 2022-06-23 00:47:03.086041
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    class_under_test = ApparmorFactCollector()
    facts_dict = class_under_test.collect()
    assert 'apparmor' in facts_dict
    assert facts_dict['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-23 00:47:04.963740
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:47:07.331734
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_module = ApparmorFactCollector()
    facts = fact_module.collect()
    assert 'apparmor' in facts  # Check that facts are returned

# Generated at 2022-06-23 00:47:16.350367
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts import cached
    from ansible.module_utils._text import to_bytes

    collector_obj = ApparmorFactCollector()
    assert(collector_obj.name == 'apparmor')
    assert(collector_obj.collector == 'linux')
    assert(collector_obj.platform == 'Linux')
    assert(collector_obj._fact_ids == set())

    module_obj = None
    collected_facts_obj = None
    module_facts_obj = collector_obj.collect(module_obj, collected_facts_obj)
    temp_cached_obj = cached.FactCache()
    temp_cached_obj._cache = {}


# Generated at 2022-06-23 00:47:20.065638
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert not apparmor_fact_collector._fact_ids

# Generated at 2022-06-23 00:47:22.131117
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aaf = ApparmorFactCollector()
    assert aaf.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:47:25.619905
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.collect() == { 'apparmor': { 'status': 'disabled' } }

# Generated at 2022-06-23 00:47:28.616789
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Unit test for constructor of class ApparmorFactCollector
    """
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()



# Generated at 2022-06-23 00:47:35.720459
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Construct a ApparmorFactCollector object
    apparmor_facts_collector = ApparmorFactCollector()
    # Call method collect of ApparmorFactCollector
    apparmor_facts = apparmor_facts_collector.collect()
    # Assert method collect returns the expected value
    assert isinstance(apparmor_facts, dict)
    assert apparmor_facts != None
    assert apparmor_facts != {}