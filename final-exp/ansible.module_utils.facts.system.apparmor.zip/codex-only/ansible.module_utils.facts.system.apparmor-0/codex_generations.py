

# Generated at 2022-06-23 00:37:34.528271
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # GIVEN instance of class ApparmorFactCollector
    apparmor = ApparmorFactCollector()

    # WHEN
    # THEN
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:37:36.192370
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()

    # Check normal case
    c.collect()

# Generated at 2022-06-23 00:37:44.487593
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    try:
        # Injection of module stub
        class StubModule(object):
            pass
        module = StubModule()
        module.run_command = lambda *args, **kwargs: (0, '', '')

        # Injection of collected_facts stub
        collected_facts = {}

        file_obj = ApparmorFactCollector()
        newfacts = file_obj.collect(module, collected_facts)
        assert 'apparmor' in newfacts
    except:
        raise

# vim: set expandtab shiftwidth=4 softtabstop=4 tabstop=4

# Generated at 2022-06-23 00:37:45.823028
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'

# Generated at 2022-06-23 00:37:48.778846
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:37:52.109718
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = ApparmorFactCollector().collect()
    assert facts
    assert facts['apparmor']
    assert facts['apparmor']['status'] == 'enabled' or facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:37:54.174193
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()


# Generated at 2022-06-23 00:38:01.681461
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method collect of class ApparmorFactCollector
    """
    # Create an instance of ApparmorFactCollector
    apparmorfc = ApparmorFactCollector()
    # Call the method collect of class ApparmorFactCollector
    facts = apparmorfc.collect()
    # Check if facts dict is not empty
    assert facts != None
    # Check if facts dict is empty
    assert facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:38:03.346076
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:38:06.137365
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    class_module = ApparmorFactCollector()
    assert class_module.name == 'apparmor'
    assert isinstance(class_module._fact_ids, set)


# Generated at 2022-06-23 00:38:13.572919
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    #apparmor_path = './ansible/test/unit/utils/test_facts/test_apparmor_data/sys/kernel/security/apparmor'
    apparmor_path = '/sys/kernel/security/apparmor'
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    if os.path.exists(apparmor_path):
        assert result['apparmor']['status'] == 'enabled'
    else:
        assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:18.958408
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Creating an instance of ApparmorFactCollector
    instance = ApparmorFactCollector()
    # Calling the collect() of class ApparmorFactCollector
    result = instance.collect()
    # Asserting if facts_dict['apparmor']['status'] is disabled
    assert(result['apparmor']['status'] == 'disabled')

# Generated at 2022-06-23 00:38:22.346157
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:38:25.965500
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Arrange
    test_dict = {'apparmor': {'status': 'disabled'}}
    tester = ApparmorFactCollector()

    # Act
    result = tester.collect()

    # Assert
    assert result == test_dict

# Generated at 2022-06-23 00:38:26.503764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:38:29.844653
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:38:31.875968
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:38:36.108261
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create an instance of ApparmorFactCollector
    a = ApparmorFactCollector()
    # Assert private variables are set correctly
    assert a._fact_ids == set()
    assert a.name == 'apparmor'



# Generated at 2022-06-23 00:38:38.512724
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    to_test = ApparmorFactCollector()
    result = to_test.collect()
    assert 'apparmor' in result

# Generated at 2022-06-23 00:38:41.531628
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:38:43.990342
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()

# Generated at 2022-06-23 00:38:52.590552
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_file_exists = os.path.exists
    def mock_path_exists(path):
        return True
    os.path.exists = mock_path_exists
    assert ApparmorFactCollector().collect()['apparmor']['status'] == "enabled"
    def mock_path_doesnt_exist(path):
        return False
    os.path.exists = mock_path_doesnt_exist
    assert ApparmorFactCollector().collect()['apparmor']['status'] == "disabled"
    os.path.exists = apparmor_file_exists

# Generated at 2022-06-23 00:38:56.663621
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_collector = ApparmorFactCollector()
    ansible_facts = apparmor_collector.collect()

    assert 'apparmor' in ansible_facts

    assert 'status' in ansible_facts['apparmor']

# Generated at 2022-06-23 00:39:03.757826
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    """ Test for present apparmor directory """
    os.path.exists = lambda x: True
    facts_dict = collector.collect()
    assert facts_dict["apparmor"]["status"] == "enabled"

    """ Test for absent apparmor directory """
    os.path.exists = lambda x: False
    facts_dict = collector.collect()
    assert facts_dict["apparmor"]["status"] == "disabled"

# Generated at 2022-06-23 00:39:05.098631
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    assert f.collect() == {}

# Generated at 2022-06-23 00:39:11.876413
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    my_apparmor_facts = ApparmorFactCollector()
    assert os.path.exists('/sys/kernel/security/apparmor')
    assert len(my_apparmor_facts.collect()) == 1

# Generated at 2022-06-23 00:39:13.586564
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'


# Generated at 2022-06-23 00:39:16.566451
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:20.708968
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    assert aafc.name == "apparmor", "ApparmorFactCollector has wrong name"
    assert aafc._fact_ids == set(), "ApparmorFactCollector has wrong _fact_ids"

# Generated at 2022-06-23 00:39:24.288829
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:39:25.092328
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:39:27.629730
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()
    assert x.priority == 50

# Generated at 2022-06-23 00:39:29.326281
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:39:31.604042
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  expected_output = {'apparmor': {'status': 'disabled'}}
  a = ApparmorFactCollector()
  assert a.collect() == expected_output


# Generated at 2022-06-23 00:39:35.687589
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    facts_dict = afc.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:38.369419
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:39.352221
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name

# Generated at 2022-06-23 00:39:45.871693
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create instance
    collector = ApparmorFactCollector()

    # run collect
    try:
        collected_facts = collector.collect()
    except Exception:
        collected_facts = {}

    # assert key 'apparmor' exists
    assert "apparmor" in collected_facts
    # assert returned dict
    apparmor_status = collected_facts['apparmor']['status']
    assert apparmor_status in ('enabled', 'disabled')

# Generated at 2022-06-23 00:39:48.857022
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.collect() ==  {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:39:55.053669
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ap = ApparmorFactCollector()
    ansible_facts = {
        'apparmor': {
            'status': 'enabled'
        }
    }
    no_exist = {
        'apparmor': {
            'status': 'disabled'
        }
    }
    assert ap.collect() == ansible_facts or ap.collect() == no_exist

# Generated at 2022-06-23 00:39:57.351668
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:59.972648
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:40:01.997379
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:40:07.949456
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()

    os.path.exists = lambda x: False
    assert apparmor.collect()['apparmor']['status'] == 'disabled'

    os.path.exists = lambda x: True
    assert apparmor.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:40:11.631831
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == 'apparmor'

# Generated at 2022-06-23 00:40:15.194144
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    import json

    aafc = ApparmorFactCollector()
    assert 'apparmor' == aafc.name
    assert 0 == len(aafc._fact_ids)



# Generated at 2022-06-23 00:40:16.920513
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    r = ApparmorFactCollector()
    assert r.name == 'apparmor'
    assert r == "apparmor"

# Generated at 2022-06-23 00:40:19.492195
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fc = ApparmorFactCollector()
    collected_facts = {}
    assert fc.collect(collected_facts=collected_facts) is not None

# Generated at 2022-06-23 00:40:22.091780
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()


# Generated at 2022-06-23 00:40:23.674701
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:40:26.721733
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfact = ApparmorFactCollector()
    assert apparmorfact.name == 'apparmor'
    assert apparmorfact._fact_ids == set()


# Generated at 2022-06-23 00:40:31.793878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Return a fact called apparmor.status set to 'enabled'
    if the file /sys/kernel/security/apparmor exists. Otherwise
    return 'disabled'."""
    collector = ApparmorFactCollector()
    # Test that the apparmor status is enabled
    file_object = open("/sys/kernel/security/apparmor")
    # The file /sys/kernel/security/apparmor is open, so the apparmor status
    # is enabled.
    assert collector.collect() == {'apparmor': {'status': 'enabled'}}
    # Close the file and test that the apparmor status is disabled
    file_object.close()
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:33.042723
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()
    assert ac

# Generated at 2022-06-23 00:40:35.443887
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:40:41.680327
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = None
    aafc = ApparmorFactCollector()
    facts_dict = {}
    res_dict = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'
    facts_dict['apparmor'] = apparmor_facts
    res_dict = aafc.collect(module, collected_facts)
    assert res_dict == facts_dict

# Generated at 2022-06-23 00:40:53.358403
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector."""
    os.path.exists = MagicMock(return_value=True)
    apparmor_facts = {}
    apparmor_facts['status'] = 'enabled'
    collect_result = ApparmorFactCollector().collect()
    assert collect_result['apparmor'] == apparmor_facts

    os.path.exists = MagicMock(return_value=False)
    apparmor_facts = {}
    apparmor_facts['status'] = 'disabled'
    collect_result = ApparmorFactCollector().collect()
    assert collect_result['apparmor'] == apparmor_facts

# Generated at 2022-06-23 00:40:55.484198
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:40:57.098943
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'

# Generated at 2022-06-23 00:40:59.464237
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    base_fact_collector = BaseFactCollector()
    assert isinstance(base_fact_collector, BaseFactCollector)

# Generated at 2022-06-23 00:41:01.778437
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"

# Generated at 2022-06-23 00:41:07.488400
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:09.913196
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-23 00:41:15.186427
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Without apparmor, apparmor_status should be 'disabled'
    apparmor_status = ApparmorFactCollector().collect()['apparmor']['status']
    assert apparmor_status == 'disabled'

# Generated at 2022-06-23 00:41:17.327400
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()

# Generated at 2022-06-23 00:41:20.323541
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_collector = ApparmorFactCollector()

    assert apparmor_facts_collector.name == "apparmor"
    assert apparmor_facts_collector._fact_ids == set()

# Generated at 2022-06-23 00:41:25.185320
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os

    apparmor = ApparmorFactCollector()
    apparmor._module = os
    facts = apparmor.collect()

    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:34.333771
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.facts.fact_collector import _mock_module
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.facts.fact_collector import _mock_collector
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.facts.fact_collector import collect_only

    apparmor_collector = collect_only(ApparmorFactCollector, '.+apparmor', _mock_module, _mock_collector)
    assert type(apparmor_collector) is dict
    assert apparmor_collector['apparmor']['status'] == "disabled"

# Generated at 2022-06-23 00:41:37.896568
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
   apparmor = ApparmorFactCollector()
   assert apparmor.name == "apparmor"
   assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:41:40.192651
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:41:41.888282
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-23 00:41:44.683170
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-23 00:41:47.161394
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert facts['apparmor'].get('status', None) == "disabled"

# Generated at 2022-06-23 00:41:49.204667
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Pass
    try:
        a = ApparmorFactCollector()
        a.collect()
    except:
        assert False

    # Fail

# Generated at 2022-06-23 00:41:55.608256
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test function for module_utils.facts.apparmor.collect method."""

    # Create an instance of the ApparmorFactCollector class
    collector = ApparmorFactCollector()

    # Create a dictionary to hold Ansible facts
    ansible_facts = {}

    # Run the function under test
    collector.collect(None, ansible_facts)

    # Assert the expected values in the Ansible facts
    assert 'apparmor' in ansible_facts
    assert ansible_facts['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-23 00:41:56.209555
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:41:58.656536
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:42:00.605694
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Test collect
    apparmor = ApparmorFactCollector()
    apparmor.collect()
    # Test __str__
    apparmor.__str__()

# Generated at 2022-06-23 00:42:02.155426
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:42:05.539311
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_dict = apparmor_collector.collect()
    assert 'apparmor' in apparmor_dict

# Generated at 2022-06-23 00:42:07.378602
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfactcollector = ApparmorFactCollector()
    apparmorfactcollector.collect()


# Generated at 2022-06-23 00:42:11.039711
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 00:42:14.491157
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:18.917518
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create an instance of ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()

    # Get the value of its name attribute
    assert apparmor_fact_collector.name == 'apparmor'

    # Check the type of the value of its _fact_ids attribute
    assert isinstance(apparmor_fact_collector._fact_ids, set)


# Generated at 2022-06-23 00:42:21.819192
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorfactCollector = ApparmorFactCollector()
    assert apparmorfactCollector.name == "apparmor"


# Generated at 2022-06-23 00:42:23.128737
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:42:27.382982
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:29.777301
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-23 00:42:42.000356
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    import sys
    import os
    import tempfile
    import json

    def test_apparmor_facts_collector():

        path = tempfile.mkdtemp()

        # create a fake sysfs apparmor directory
        os.makedirs(os.path.join(path, 'sys/kernel/security/apparmor'))

        # make a backup of the current path to revert after the test
        original_path = sys.path

        # force the module to be loaded from our path
        sys.path.insert(0, path)

        # import the fake apparmor facts collector
        from ansible.module_utils.facts.apparmor.apparmor_facts import ApparmorFactCollector

        # attempting to collect facts
        facts_dict = ApparmorFactCollector().collect()

        # verify the correct facts are returned

# Generated at 2022-06-23 00:42:45.403449
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:47.452154
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    facts_dict = afc.collect()
    assert facts_dict == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-23 00:42:51.104951
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-23 00:42:53.481325
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'


# Generated at 2022-06-23 00:42:54.486172
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector != None

# Generated at 2022-06-23 00:42:59.009149
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """ Unit test for constructor of class ApparmorFactCollector """
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor', 'Name check failed'
    assert apparmor_obj._fact_ids is not None, 'Fact ids check failed'


# Generated at 2022-06-23 00:43:00.882997
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"


# Generated at 2022-06-23 00:43:03.613658
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x.collect()['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:43:06.765126
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:09.748825
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create object of ApparmorFactCollector
    apparmor = ApparmorFactCollector()

    # Check that it return the correct dict
    assert apparmor.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:13.369508
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collect = ApparmorFactCollector()
    assert collect.name == "apparmor"
    assert collect._fact_ids == set()


# Generated at 2022-06-23 00:43:18.230235
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {'path': {}}
    collected_facts = {}
    apparmor = ApparmorFactCollector(module=module, collected_facts=collected_facts)
    apparmor_facts = apparmor.collect()['apparmor']
    assert type(apparmor_facts) == dict

# Generated at 2022-06-23 00:43:29.194471
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import FactCollector

    from ansible.module_utils.facts import collectors
    import os

    facts = Facts()
    # Unit test for method collect of class ApparmorFactCollector
    def test_ApparmorFactCollector_collect():
        from ansible.module_utils.facts.facts import Facts
        from ansible.module_utils.facts.collector import FactCollector

        from ansible.module_utils.facts import collectors
        import os

        facts = Facts()
        if os.path.exists('/sys/kernel/security/apparmor'):
            apparmor_facts_status = 'enabled'
        else:
            apparmor_facts_status = 'disabled'

        collectors.pop('apparmor', None)

# Generated at 2022-06-23 00:43:31.919414
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector().collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:33.687541
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ar = ApparmorFactCollector()
    assert ar

# Unit test to verify return value of collect()

# Generated at 2022-06-23 00:43:36.675754
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert 'apparmor' in apparmor.fetch_facts()
    assert 'status' in apparmor.fetch_facts()['apparmor']

# Generated at 2022-06-23 00:43:42.339269
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import sys
    facts_dict = {}
    apparmor_facts = {}
    apparmor_facts['status']='disabled'
    facts_dict['apparmor'] = apparmor_facts
    a = ApparmorFactCollector()
    assert a.collect() == facts_dict

# Generated at 2022-06-23 00:43:44.737211
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    result = apparmor.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:46.988382
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    # Disable apparmor
    collector.collect()
    # Enable apparmor
    collector.collect()

# Generated at 2022-06-23 00:43:49.306017
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:43:54.549566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor'] is not None
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts['apparmor']['status'] == 'enabled'
    else:
        assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:56.275202
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.__class__.__name__ == 'ApparmorFactCollector'

# Generated at 2022-06-23 00:44:02.076458
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_data = ["status=enabled", "status=disabled"]

    apparmor_output = {}

    for status_option in apparmor_data:
        a = ApparmorFactCollector()
        a.collect = lambda x: {'apparmor': {'status': status_option.split('=')[1]}}
        apparmor_output.update(a.collect(module=None, collected_facts={}))

    assert apparmor_output['apparmor']['status'] in apparmor_data

# Generated at 2022-06-23 00:44:04.037367
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-23 00:44:06.922871
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:44:14.548242
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Collect facts related to selinux
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.


# Generated at 2022-06-23 00:44:15.856746
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa_fact_collector_obj = ApparmorFactCollector()
    assert aa_fact_collector_obj.name == "apparmor"

# Generated at 2022-06-23 00:44:18.748616
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFact = ApparmorFactCollector()
    apparmorFact.collect()
    # method collect should not return None
    assert apparmorFact.collect() is not None

# Generated at 2022-06-23 00:44:20.945799
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ap = ApparmorFactCollector()
    apparmor_facts = ap.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:44:26.870726
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test case 1: If there is no /sys/kernel/security/apparmor directory
    def test_ApparmorFactCollector_no_directory():
        temp = ApparmorFactCollector()
        assert temp.name == 'apparmor'

    # Test case 2: If there is /sys/kernel/security/apparmor directory
    def test_ApparmorFactCollector_directory():
        temp = ApparmorFactCollector()
        assert temp.name == 'apparmor'

# Generated at 2022-06-23 00:44:28.105037
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Test code to execute in the unit test envrionment """
    return

# Generated at 2022-06-23 00:44:32.287045
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    collector = ApparmorFactCollector()
    collected_facts = collector.collect()

    facts = {'apparmor': {'status': 'enabled'}}
    assert collected_facts == facts

# Generated at 2022-06-23 00:44:36.979705
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    appf = ApparmorFactCollector()
    result = appf.collect()
    assert result['apparmor']['status'] == 'disabled'
    os.environ['ansible_apparmor_status'] = 'enabled'
    result = appf.collect()
    assert result['ansible_apparmor']['status'] == 'enabled'


# Generated at 2022-06-23 00:44:38.386992
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    result = ApparmorFactCollector().collect()
    assert 'apparmor' in result

# Generated at 2022-06-23 00:44:40.275685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status']

# Generated at 2022-06-23 00:44:43.302745
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 00:44:45.577068
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    w = ApparmorFactCollector(None)
    test1 = w.collect()
    assert test1['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:48.582402
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collected_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts == apparmor_collected_facts

# Generated at 2022-06-23 00:44:54.701968
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()

    if os.path.exists('/sys/kernel/security/apparmor'):
        result_dict = {'apparmor': {'status': 'enabled'}}
    else:
        result_dict = {'apparmor': {'status': 'disabled'}}
    result = collector.collect()
    assert result_dict == result

# Generated at 2022-06-23 00:45:00.418708
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {'status': 'disabled'}
    
    class Mock_module_util:
        def __init__(self):
            pass

        def file_exists(self, path):
            return False
    module_util = Mock_module_util()

    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect(module=module_util)
    assert 'apparmor' in facts
    assert facts['apparmor'] == apparmor_facts

# Generated at 2022-06-23 00:45:05.831790
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # status is 'enabled'
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor']['status'] == 'enabled'
    # status is 'disabled'
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:09.880033
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Setup
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()
    # Testing
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids != None
    assert apparmor_facts.collect() != None

# Generated at 2022-06-23 00:45:12.524840
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert not ApparmorFactCollector._fact_ids
    assert isinstance(ApparmorFactCollector._fact_ids, set)


# Generated at 2022-06-23 00:45:14.712801
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert (len(ApparmorFactCollector().collect()) > 0)

# Generated at 2022-06-23 00:45:16.774680
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:45:19.679060
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()

    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:45:20.375318
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:45:22.754271
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:45:26.528162
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

    _ApparmorFactCollector = ApparmorFactCollector()
    assert _ApparmorFactCollector.name == 'apparmor'


# unit test for collect method of class ApparmorFactCollector

# Generated at 2022-06-23 00:45:28.319322
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:45:33.009704
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test of module_util.facts.apparmor.ApparmorFactCollector.collect()
    """
    c = ApparmorFactCollector()
    apparmor_facts = c.collect()
    assert isinstance(apparmor_facts, dict)
    assert isinstance(apparmor_facts['apparmor'], dict)
    assert apparmor_facts['apparmor'].keys() == {'status'}

# Generated at 2022-06-23 00:45:38.624185
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorCollector = ApparmorFactCollector()
    test_apparmor_facts = apparmorCollector.collect()["apparmor"]
    os.stat("/sys/kernel/security/apparmor")
    expected_apparmor_facts = {
        'status' : 'enabled'
    }
    assert test_apparmor_facts == expected_apparmor_facts

# Generated at 2022-06-23 00:45:41.126243
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    myApparmorFactCollector = ApparmorFactCollector()
    assert myApparmorFactCollector.name == 'apparmor'
    assert myApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:45:42.072018
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:45:44.524980
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_collector = ApparmorFactCollector()
    test_facts = test_collector.collect()
    assert test_facts.get('apparmor') is not None

# Generated at 2022-06-23 00:45:47.127054
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    apparmor_facts = aafc.collect()
    assert apparmor_facts is None or 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:45:53.029109
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {
        "apparmor": {
            'status': 'enabled'
        }
    }
    module = ansible_fake_module()
    apparmor_fact_collector = ApparmorFactCollector(module)
    assert apparmor_facts == apparmor_fact_collector.collect()


# Generated at 2022-06-23 00:45:55.271947
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'


# Generated at 2022-06-23 00:45:59.356282
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    expected_apparmor_facts = {
        'status': 'enabled'
    }
    assert expected_apparmor_facts == apparmor_facts

# Generated at 2022-06-23 00:46:00.241180
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()


# Generated at 2022-06-23 00:46:02.801959
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # test for disabled apparmor
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status'] == "disabled"


# Generated at 2022-06-23 00:46:05.721779
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert type(a._fact_ids) is set
    assert hasattr(a, 'collect')
    assert callable(a.collect)

# Generated at 2022-06-23 00:46:09.506732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {u'status': u'enabled'}
    expected = {u'apparmor': apparmor_facts}
    assert ApparmorFactCollector().collect(collected_facts=None) == expected

# Generated at 2022-06-23 00:46:12.447463
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'status' in facts['apparmor']
    assert facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:46:13.802547
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact = ApparmorFactCollector()
    assert fact.name == "apparmor"

# Generated at 2022-06-23 00:46:16.173661
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aaf = ApparmorFactCollector()
    assert aaf.name == 'apparmor'
    assert len(aaf._fact_ids) == 0


# Generated at 2022-06-23 00:46:17.124820
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector)

# Generated at 2022-06-23 00:46:19.394340
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector(None)
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:46:28.095691
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts_collector = ApparmorFactCollector()

    # Test 1: if /sys/kernel/security/apparmor exists, apparmor status should return 'enabled'
    apparmor_facts_collector.is_file = True
    apparmor_facts = apparmor_facts_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}, 'apparmor status returned is not correct'

    # Test 2: if /sys/kernel/security/apparmor does not exist, apparmor status should return 'disabled'
    apparmor_facts_collector.is_file = False
    apparmor_facts = apparmor_facts_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'disabled'}}, 'apparmor status returned is not correct'

# Generated at 2022-06-23 00:46:30.693163
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 00:46:31.416697
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-23 00:46:33.144356
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'

# Generated at 2022-06-23 00:46:36.130449
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    facts_dict = apparmor_collector.collect()
    assert facts_dict == {
        'apparmor': {
            'status': 'disabled',
        }
    }

# Generated at 2022-06-23 00:46:41.615664
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Run unit test
    result = ApparmorFactCollector().collect()

    assert result is not None
    assert 'apparmor' in result
    assert isinstance(result['apparmor'], dict)
    assert isinstance(result['apparmor']['status'], str)
    assert result['apparmor']['status'] in {'enabled', 'disabled'}

# Generated at 2022-06-23 00:46:46.014878
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_status = 'disabled'
    def mock_exist(path):
        if path == '/sys/kernel/security/apparmor':
            return True
        else:
            return False
    os.path.exists = mock_exist
    result = ApparmorFactCollector.collect()
    assert result['apparmor'] == {'status': apparmor_status}

# Generated at 2022-06-23 00:46:47.882631
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == "apparmor"
    assert len(apparmor_fact._fact_ids) == 0

# Generated at 2022-06-23 00:46:50.342328
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    assert 'status' in a.collect()['apparmor']

# Generated at 2022-06-23 00:46:53.029320
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"

# Generated at 2022-06-23 00:46:54.535276
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts is not None


# Generated at 2022-06-23 00:47:04.589424
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collectors.apparmor as apparmor_collector
    import os

    # Prepare test cases
    test_cases = [
        {
            'is_file_sys_apparmor_exist': True,
            'apparmor_facts': {
                'status': 'enabled'
            }
        },
        {
            'is_file_sys_apparmor_exist': False,
            'apparmor_facts': {
                'status': 'disabled'
            }
        }
    ]

    for test_case in test_cases:
        module_args = {}
        returned_facts = {}
        expected_facts = {}
        # Prepare method arguments and mock Method Side Effects

# Generated at 2022-06-23 00:47:06.986377
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-23 00:47:09.170262
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  assert ApparmorFactCollector.name == 'apparmor'
  assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:47:12.294002
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    factCollector = ApparmorFactCollector()
    returned_facts = factCollector.collect()
    assert dict == type(returned_facts)
    assert {'apparmor': {'status': 'disabled'}} == returned_facts

# Generated at 2022-06-23 00:47:20.371503
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_instance = ApparmorFactCollector()

    # Test when os.path.exists return true
    os.path.exists = lambda x: True
    collected_facts = test_instance.collect()

    assert collected_facts == {'apparmor': {'status': 'enabled'}}

    # Test when os.path.exists return false
    os.path.exists = lambda x: False
    collected_facts = test_instance.collect()

    assert collected_facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:47:25.478189
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = None
    collected_facts = {}

    collector = ApparmorFactCollector()
    output = collector.collect(module, collected_facts)

    assert 'apparmor' in output

    assert 'status' in output['apparmor']
    assert output['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:47:29.463553
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.apparmor import ApparmorFactCollector
    # instantiate class ApparmorFactCollector
    a = ApparmorFactCollector()
    # Verify collect method
    assert isinstance(a, BaseFactCollector)

# Generated at 2022-06-23 00:47:36.225824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_file = '/sys/kernel/security/apparmor'
    try:
        os.symlink('/etc/apparmor.d', apparmor_file)

        collector = ApparmorFactCollector()
        facts = collector.collect()
        assert facts['apparmor']['status'] == 'enabled'

    finally:
        try:
            os.remove(apparmor_file)
        except OSError:
            pass