

# Generated at 2022-06-23 00:37:30.637665
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector.name == "apparmor")
    assert(ApparmorFactCollector._fact_ids == set())


# Generated at 2022-06-23 00:37:33.656439
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:37:40.613201
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import shutil

    # Should return disabled with no /sys/kernel/security/apparmor directory.
    afc = ApparmorFactCollector({})
    assert afc.collect() == {'apparmor': {'status': 'disabled'}}

    # Should return enabled with /sys/kernel/security/apparmor directory.
    os.makedirs('/sys/kernel/security/apparmor')
    assert afc.collect() == {'apparmor': {'status': 'enabled'}}
    shutil.rmtree('/sys/kernel/security')

# Generated at 2022-06-23 00:37:42.893839
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # create instance of class ApparmorFactCollector
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'

# Generated at 2022-06-23 00:37:45.683249
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:37:48.108614
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    facts = apparmor_facts.collect()
    assert facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:37:49.702981
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'


# Generated at 2022-06-23 00:37:52.983510
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector
    assert apparmor_fact_collector.name == 'apparmor'

# unit test for collect() of class ApparmorFactCollector

# Generated at 2022-06-23 00:37:58.921488
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # Instantiate ApparmorFactCollector
    apparmor_fc = ApparmorFactCollector()
    # Check _fact_ids
    assert apparmor_fc._fact_ids == set()
    # Check name
    assert apparmor_fc.name == 'apparmor'

# Generated at 2022-06-23 00:38:02.358936
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # New instance of ApparmorFactCollector class
    apparmor_fc_1 = ApparmorFactCollector()
    # Check
    assert apparmor_fc_1.name == 'apparmor', 'Name of ApparmorFactCollector class should be apparmor'

# Generated at 2022-06-23 00:38:04.895954
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:38:07.293196
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_obj = ApparmorFactCollector()
    assert isinstance(apparmor_obj, ApparmorFactCollector)
    assert isinstance(apparmor_obj.collect(), dict)

# Generated at 2022-06-23 00:38:10.848861
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """ Unit test for constructor of class ApparmorFactCollector """
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:38:12.430074
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:38:14.016058
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:38:15.662135
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()
    print(ac.collect())

# Generated at 2022-06-23 00:38:17.713550
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = ApparmorFactCollector()
    assert module.name == 'apparmor'

# Generated at 2022-06-23 00:38:22.246098
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    status = apparmor_fact_collector.collect()['apparmor']['status']
    if status == 'enabled' or status == 'disabled':
        pass
    else:
        raise Exception("status should be 'enabled' or 'disabled'")

# Generated at 2022-06-23 00:38:32.941685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mock the os.path.exist method of the module ApparmorFactCollector
    old_exists = os.path.exists

# Generated at 2022-06-23 00:38:33.898100
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    pass

# Generated at 2022-06-23 00:38:36.290731
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert 'apparmor' in a._fact_ids


# Generated at 2022-06-23 00:38:39.760905
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    apparmor = ApparmorFactCollector()
    assert apparmor.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:38:41.332287
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert('apparmor' == ApparmorFactCollector.name)

# Generated at 2022-06-23 00:38:44.887264
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    target_apparmor_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts == target_apparmor_facts

# Generated at 2022-06-23 00:38:48.442860
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    apafc = ApparmorFactCollector()

    assert apafc
    assert apafc.name == 'apparmor'
    assert apafc._fact_ids == set()


# Generated at 2022-06-23 00:38:49.525115
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect()['apparmor']

# Generated at 2022-06-23 00:38:51.147393
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with apparmor enabled
    ApparmorFactCollector.collect(None)

# Generated at 2022-06-23 00:38:51.851157
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert True

# Generated at 2022-06-23 00:38:54.026009
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:38:55.704353
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()

# Generated at 2022-06-23 00:38:57.849380
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert hasattr(apparmor_collector, 'name')
    assert isinstance(apparmor_collector._fact_ids, set)

# Generated at 2022-06-23 00:38:58.789266
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'

# Generated at 2022-06-23 00:38:59.784766
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 00:39:02.697152
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict.get('apparmor') is not None

# Generated at 2022-06-23 00:39:06.071669
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj._fact_ids == set()
    assert obj.name == 'apparmor'
    assert obj.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:39:10.084606
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert issubclass(ApparmorFactCollector, BaseFactCollector)
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert isinstance(apparmor_fact_collector._fact_ids, set)

# Generated at 2022-06-23 00:39:11.498656
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = ApparmorFactCollector()
    assert facts.name == 'apparmor'

# Generated at 2022-06-23 00:39:14.055142
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:16.361761
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:39:20.067282
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_obj = ApparmorFactCollector()
    facts_dict = apparmor_fact_obj.collect()
    assert 'apparmor' in facts_dict, \
        "apparmor not found in facts_dict"

# Generated at 2022-06-23 00:39:23.837238
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert isinstance(apparmor._fact_ids, set)

# Generated at 2022-06-23 00:39:33.106244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    import __builtin__

    class MyMockBuiltins(object):
        def __init__(self):
            self.status = 0
            self.output = None

    my_builtin = MyMockBuiltins()
    my_builtin.status = 1

    class MockOs(object):
        def __init__(self):
            self.path = None

    my_path = MockOs()
    my_path.exists = lambda x: my_builtin.status

    my_builtin.open = lambda x: my_builtin

    # Mock module_utils.apparmor.py
    module = type('module', (object,), {
        'run_command': lambda *args, **kwargs: ['passwd', my_builtin.status, my_builtin.output]})

# Generated at 2022-06-23 00:39:36.155347
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    apparmor_fc.name = 'apparmor'
    apparmor_fc._fact_ids = set()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:39:39.166543
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.collect().get('apparmor') is not None

# Generated at 2022-06-23 00:39:41.788367
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"
    assert isinstance(ApparmorFactCollector._fact_ids, set)


# Generated at 2022-06-23 00:39:45.580940
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = object()
    collected_facts = object()
    fact_collector = ApparmorFactCollector(module)
    fact_collector.collect(module, collected_facts)
    assert fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:49.755780
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_dict = { 'status': 'disabled' }
    f = ApparmorFactCollector()
    assert(f.collect(collected_facts={}) == {'apparmor': apparmor_dict})
    del f

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 00:39:52.377438
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector._fact_ids == set()
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:39:53.127778
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts = {}
    ApparmorFactCollector().collect(None, facts)
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:39:55.702714
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert 'apparmor' in result

# Generated at 2022-06-23 00:39:58.461677
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:40:01.147235
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:40:05.125732
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()

# Generated at 2022-06-23 00:40:06.834000
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:40:10.971701
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:40:14.417805
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-23 00:40:16.882970
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:40:19.435309
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts.collect()
    assert apparmor_facts.collect() is not None

# Generated at 2022-06-23 00:40:31.313173
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for class ApparmorFactCollector.
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collect_to_dict
    from ansible.module_utils._text import to_bytes

    # Collect apparmor facts.
    mock_collector = Collector()
    mock_collector.collect_apparmor_facts = ApparmorFactCollector(mock_collector)
    test_apparmor_facts = collect_to_dict(mock_collector)
    print('test_apparmor_facts: %s' % test_apparmor_facts)
    assert 'apparmor' in test_apparmor_facts
    assert 'status' in test_apparmor_facts['apparmor']
    assert test_apparmor_facts['apparmor']['status']

# Generated at 2022-06-23 00:40:32.940857
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:40:35.745615
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == "apparmor"
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:40:39.003728
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test to make sure members are initialized correctly.
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-23 00:40:42.980751
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test constructor of class ApparmorFactCollector"""
    apparmor_collector = ApparmorFactCollector()
    assert isinstance(apparmor_collector, ApparmorFactCollector)

# Generated at 2022-06-23 00:40:47.415324
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-23 00:40:56.041679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    tmpdir = mkdtemp()
    try:
        # Don't have apparmor loaded
        apparmor_status = ApparmorFactCollector(tmpdir)
        apparmor_status.collect()
        assert apparmor_status.collect() == {'apparmor': {'status': 'disabled'}}

        # Have apparmor loaded
        os.makedirs('/sys/kernel/security/apparmor')
        apparmor_status = ApparmorFactCollector(tmpdir)
        apparmor_status.collect()
        assert apparmor_status.collect() == {'apparmor': {'status': 'enabled'}}
    finally:
        rmtree(tmpdir)

# Generated at 2022-06-23 00:40:58.475803
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()
    assert 'apparmor' in facts_dict

# Generated at 2022-06-23 00:41:02.551141
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector = ApparmorFactCollector()
    ApparmorFactCollector._host_data = {}
    assert ApparmorFactCollector.collect() == {
        'apparmor': {'status': 'disabled'},
    }

# Generated at 2022-06-23 00:41:13.437864
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = "ansible.module_utils.facts.collectors.apparmor.ApparmorFactCollector"
    mock_module_os = "ansible.module_utils.facts.collectors.apparmor.os"
    mock_os = "ansible.module_utils.facts.collectors.apparmor.os"
    with mock.patch(mock_module) as mock_sys:
        mock_sys = "ansible.module_utils.facts.collectors.apparmor.sys"
        with mock.patch(mock_module_os) as mock_sys:
            mock_sys = "ansible.module_utils.facts.collectors.apparmor.sys"

# Generated at 2022-06-23 00:41:19.231932
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # test initialization of ApparmorFactCollector
    apparmor_fact_collector_instance = ApparmorFactCollector()
    assert apparmor_fact_collector_instance.name == 'apparmor'
    assert len(apparmor_fact_collector_instance._fact_ids) == 1
    assert 'apparmor' in apparmor_fact_collector_instance._fact_ids



# Generated at 2022-06-23 00:41:21.756352
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector()
    assert instance.name == 'apparmor'
    assert len(instance._fact_ids) == 0

# Generated at 2022-06-23 00:41:22.674333
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert (ApparmorFactCollector.name == 'apparmor')

# Generated at 2022-06-23 00:41:24.294503
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    x = ApparmorFactCollector()
    x.collect()

# Generated at 2022-06-23 00:41:26.553125
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    d = ApparmorFactCollector()
    assert (d.collect()['apparmor']['status'] in ['enabled', 'disabled'])

# Generated at 2022-06-23 00:41:35.680503
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file named 'debian_version'
    f = open(os.path.join(tmpdir, "debian_version"), 'w')
    f.write("8.2")
    f.close()
    # Set environment variable to use the fake file
    os.environ['chroot'] = tmpdir

    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()

    # expected result
    result_dict = {}
    result_dict['apparmor'] = {'status': 'disabled'}

    # Check if the collected facts match with expected result
    assert facts == result_dict

    # Remove the temporary directory

# Generated at 2022-06-23 00:41:38.964951
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:41:41.206415
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'


# Generated at 2022-06-23 00:41:43.797364
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    my_collector = ApparmorFactCollector()
    assert my_collector.name == 'apparmor'
    assert my_collector._fact_ids == set()


# Generated at 2022-06-23 00:41:48.195852
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Test ApparmorFactCollector constructor"""
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj
    assert apparmor_fact_collector_obj.name == 'apparmor'
    assert apparmor_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 00:41:50.339996
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test with empty object
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'


# Generated at 2022-06-23 00:41:52.638713
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert 'apparmor' in fact_collector.collect()

# Generated at 2022-06-23 00:41:54.472704
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:41:55.885253
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    m = ApparmorFactCollector()
    assert m is not None


# Generated at 2022-06-23 00:42:00.368535
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()

    class mock_module:
        pass

    class mock_collected_facts:
        pass

    apparmor_facts = apparmor.collect(mock_module, mock_collected_facts)
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:42:03.610698
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'
    assert ApparmorFactCollector()._fact_ids == set()

# Generated at 2022-06-23 00:42:06.351337
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:42:09.826607
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:13.077657
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:42:20.115162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {}
    test_collector = ApparmorFactCollector()
    os.path.exists = MagicMock(return_value=True)
    apparmor_facts['status'] = 'enabled'
    assert test_collector.collect() == {'apparmor': {'status': 'enabled'}}
    os.path.exists = MagicMock(return_value=False)
    apparmor_facts['status'] = 'disabled'
    assert test_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:26.394813
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    tmp_collector = ApparmorFactCollector()
    tmp_ansible_module = AnsibleModuleMock()
    tmp_module_facts = {}
    tmp_collector_result = tmp_collector.collect(module=tmp_ansible_module, collected_facts=tmp_module_facts)
    assert {'apparmor': {'status': 'enabled'}} == tmp_collector_result
    assert tmp_module_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:42:30.123523
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_dict = {'apparmor': {}}
    test_class = ApparmorFactCollector()
    returned_dict = test_class.collect()

    assert returned_dict == test_dict


# Generated at 2022-06-23 00:42:42.320599
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import sys
    import imp
    import unittest
    import os

    class MockModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

    class MockOs(object):
        def __init__(self):
            self.path = os.path.realpath(__file__)

    module = MockModule()
    imp.reload(sys.modules[module.__module__])

    sys.modules['os'] = MockOs()

    fact_collector = ApparmorFactCollector()
    apparmor_facts = fact_collector.collect(module=module, collected_facts={})


# Generated at 2022-06-23 00:42:44.160637
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:46.536669
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_apparmor_fact_collector = ApparmorFactCollector()
    assert test_apparmor_fact_collector.name == 'apparmor'
    assert test_apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:49.674585
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_obj = ApparmorFactCollector()
    apparmor_obj.collect()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()

# Generated at 2022-06-23 00:42:58.477367
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import FactCollector

    # create a dummy class to allow test to set values that would normally be
    # set by the module
    class ConfModule(object):
        def __init__(self):
            self.params = {}

    conf_module = ConfModule()

    # mock return values for collect_file_facts that is used by the collect
    # method in ApparmorFactCollector
    original_collect_file_facts = FactCollector.collect_file_facts
    def mock_collect_file_facts(self, module, collected_facts):
        return collected_facts

    FactCollector.collect_file_facts = mock_collect_file_facts

    # mock os.path.exists and return true to simulate apparmor being installed
    original_exists = os.path.exists

# Generated at 2022-06-23 00:43:01.203116
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {'apparmor': {'status': 'enabled'}}
    ac = ApparmorFactCollector()
    assert ac.collect() == apparmor_facts

# Generated at 2022-06-23 00:43:03.092124
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()

# Generated at 2022-06-23 00:43:05.800050
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:08.488915
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    mock_module = MagicMock()

    mock_apparmor_factcollector = ApparmorFactCollector(mock_module)

    mock_apparmor_factcollector.collect()

# Generated at 2022-06-23 00:43:15.333915
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create a class instance of ApparmorFactCollector
    apparmor_fc = ApparmorFactCollector()
    # Create a empty dictionary
    collected_facts = {}
    # Create a empty dictionary
    apparmor_facts = {}
    # Create a dictionary with status key
    apparmor_facts['status'] = 'enabled'
    # Create a dictionary with key apparmor and value apparmor_facts
    apparmor_dict = {'apparmor': apparmor_facts}

    # Call the method collect of class ApparmorFactCollector
    apparmor_fc.collect(collected_facts)

    # Compare the output of method collect with expected output
    assert apparmor_fc.collect(collected_facts) == apparmor_dict

# Generated at 2022-06-23 00:43:19.825868
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module_mock = None
    collected_facts_mock = None

    apparmor_fact_collector_obj = ApparmorFactCollector()
    result = apparmor_fact_collector_obj.collect(module_mock, collected_facts_mock)
    assert result['apparmor']['status'] is not None

# Generated at 2022-06-23 00:43:22.039460
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()



# Generated at 2022-06-23 00:43:32.825646
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Mock collect
    filename_apparmor = '/sys/kernel/security/apparmor'
    filename_apparmor_mock = mock.mock_open(read_data='/sys/kernel/security/apparmor')
    with mock.patch('os.path.exists', return_value=True):
        with mock.patch('__builtin__.open', filename_apparmor_mock):
            if os.path.exists(filename_apparmor):
                apparmor_status = 'enabled'
            else:
                apparmor_status = 'disabled'
            ansible_module.exit_json(changed=False, ansible_facts=dict(apparmor=dict(status=apparmor_status)))


# Unit test playbook execute

# Generated at 2022-06-23 00:43:35.701535
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'
    assert apparmor_obj._fact_ids == set()


# Generated at 2022-06-23 00:43:39.457472
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    o = ApparmorFactCollector()
    assert o.name == 'apparmor'
    assert o._fact_ids == set()


# Generated at 2022-06-23 00:43:41.743481
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector = ApparmorFactCollector()
    assert ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:43:43.394034
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()


# Generated at 2022-06-23 00:43:48.044409
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of class ApparmorFactCollector
    apparmor_module = ApparmorFactCollector()
    # Invoke method collect
    apparmor_module.collect()
    # Check the result
    assert apparmor_module.name == 'apparmor'

# Generated at 2022-06-23 00:43:51.254767
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    anobj = ApparmorFactCollector()
    anobj.collect()
    assert anobj.name == 'apparmor'
    assert anobj._fact_ids == set()

# Generated at 2022-06-23 00:43:54.639135
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:43:58.590453
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    module = None
    collectedFacts = None
    result = collector.collect(module=module, 
            collected_facts=collectedFacts)

    assert result['apparmor'] == {'status': 'disabled'}

# Generated at 2022-06-23 00:43:59.420664
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:44:04.575768
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # stub data for testing
    stub_data = {
      'apparmor': {
          'status': 'disabled',
      }
    }
    # stub instance of class
    apparmor = ApparmorFactCollector()
    # stub instance of class AnsibleModule
    ansible_module = ansible.module_utils.basic.AnsibleModule
    # stub function collect
    ansible_module.collect_facts = apparmor.collect
    # run the function collect
    result = ansible_module.collect_facts()
    assert result == stub_data

# Generated at 2022-06-23 00:44:12.912155
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    fc = FactsCollector()
    aafc = ApparmorFactCollector()
    fc.collectors = [aafc]

    aafc.collect()
    print("fc.collectors: ")
    print(fc.collectors)
    facts = fc.collect()
    print("facts: " + str(facts))
    fact_ids = aafc.get_fact_ids()
    assert len(facts) == 2
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] == 'disabled'
    assert fact_ids == set(['apparmor'])

# Generated at 2022-06-23 00:44:16.201444
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()

# Generated at 2022-06-23 00:44:19.059187
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Testing ApparmorFactCollector().collect
    and returns a dictionary with the hardware facts """
    apparmor_obj = ApparmorFactCollector()
    apparmor_obj.collect()

# Generated at 2022-06-23 00:44:23.668843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Tests ApparmorFactCollector.collect() method
    """
    collector = ApparmorFactCollector()
    # Mock os.path.exists()
    collector.os.path.exists = lambda x: False
    facts = collector.collect()
    assert 'apparmor' in facts
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:27.937718
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create instance of ApparmorFactCollector
    obj = ApparmorFactCollector()
    assert obj is not None
    assert obj.name == 'apparmor'
    assert type(obj.collect()) == dict
    assert type(obj._fact_ids) == set
    assert type(obj.collect(collected_facts={})) == dict


# Generated at 2022-06-23 00:44:30.973046
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_mock = ApparmorFactCollector()
    apparmor_mock.collect()

# Generated at 2022-06-23 00:44:33.549807
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_test_object = ApparmorFactCollector()
    assert apparmor_test_object.name == 'apparmor'


# Generated at 2022-06-23 00:44:39.033276
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Test the method ApparmorFactCollector.collect of ApparmorFactCollector class
    """
    fact_collector = ApparmorFactCollector()
    # TODO: use mock to create a fake /sys/kernel/security/apparmor
    # and test the both cases: file exists and file not exists
    fact_collector.collect()

# Generated at 2022-06-23 00:44:42.124895
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert 'apparmor' == apparmor.name
    assert apparmor.name in apparmor._fact_ids

# Generated at 2022-06-23 00:44:45.628590
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts_dict = fact_collector.collect()
    assert 'apparmor' in facts_dict, \
        'ApparmorFactCollector.collect() must return "apparmor" key'

# Generated at 2022-06-23 00:44:46.876668
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == "apparmor"

# Generated at 2022-06-23 00:44:55.042204
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Arrange
    # Mock backported_pkg_resources.get_distribution() with
    # backports.tempfile.TemporaryDirectory - which is mocked with a temp
    # directory that does not exist.
    return_value = {u'apparmor': {u'status': u'disabled'} }

    # Act
    collector = ApparmorFactCollector()
    facts_dict = collector.collect()

    # Assert
    assert facts_dict == return_value
    assert collector.name == 'apparmor'

# Generated at 2022-06-23 00:44:57.061264
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:01.555623
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = {'apparmor': {}}
    facts_dict['apparmor']['status'] = 'disabled'
    assert collector.collect() == facts_dict

# Generated at 2022-06-23 00:45:10.193732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fake_module = object()
    fake_collector = ApparmorFactCollector()
    # when status is enabled
    fake_collector.python_version = 255
    fake_collector.get_mount_info = lambda: 0
    fake_collector.get_mount_points = lambda: 0
    fake_collector.get_mount_device = lambda: '/sys/kernel/security/apparmor'
    facts_dict = fake_collector.collect(fake_module)
    assert facts_dict == {'apparmor': {'status': 'enabled'}}
    # when status is disabled
    fake_collector.python_version = 255
    fake_collector.get_mount_info = lambda: 0
    fake_collector.get_mount_points = lambda: 0

# Generated at 2022-06-23 00:45:14.656175
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert 'apparmor' == apparmor.name


# Generated at 2022-06-23 00:45:18.360565
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor = apparmor_fact_collector.collect()['apparmor']
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor['status'] == 'enabled'
    else:
        assert apparmor['status'] == 'disabled'
    assert 'version' not in apparmor

# Generated at 2022-06-23 00:45:20.470334
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instantiated = ApparmorFactCollector()
    assert instantiated.name == 'apparmor'
    assert isinstance(instantiated._fact_ids, set)
    assert callable(instantiated.collect)

# Generated at 2022-06-23 00:45:29.097808
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    try:
        # Create the mocks
        module = {}
        collected_facts = {}

        # Create the class that inherits from BaseFactCollector and defines
        # the collect method
        class MockApparmorFactCollector(ApparmorFactCollector):
            def collect(self):
                apparmor_facts = {}
                apparmor_facts['status'] = 'enabled'
                return apparmor_facts

        apparmor_collector = MockApparmorFactCollector(module=module, collected_facts=collected_facts)
        assert apparmor_collector.collect()['apparmor']['status'] == 'enabled'

    except Exception:
        assert False

# Generated at 2022-06-23 00:45:31.154050
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert isinstance(apparmor_facts, ApparmorFactCollector)

# Generated at 2022-06-23 00:45:33.139109
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    expected_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.collect() == expected_facts

# Generated at 2022-06-23 00:45:46.763512
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Unit test for method collect of class ApparmorFactCollector
    '''
    from ansible.module_utils.facts.collector import Collector
    import pytest
    collector = Collector.get_collector('ApparmorFactCollector', {})
    # Test the case when apparmor is disabled
    test_collector = ApparmorFactCollector(module=None)
    test_collector.collect()
    facts_dict = test_collector.collect_fact()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}
    # Test the case when apparmor is enabled
    test_collector = ApparmorFactCollector(module=None)
    test_collector.collect()
    facts_dict = test_collector.collect_fact()

# Generated at 2022-06-23 00:45:50.404257
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()


# Unit test function collect of class ApparmorFactCollector

# Generated at 2022-06-23 00:45:52.865436
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:45:55.105589
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert True == isinstance(ApparmorFactCollector(), BaseFactCollector)


# Generated at 2022-06-23 00:45:57.920708
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:46:01.580245
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_module = { 'module_setup': True }

    test_ApparmorFactCollector = ApparmorFactCollector()
    test_ApparmorFactCollector.collect(test_module)
# End of unit test for method collect of class ApparmorFactCollector

# Generated at 2022-06-23 00:46:05.313824
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ac = ApparmorFactCollector()
    if ac.name != 'apparmor':
        raise AssertionError('mismatch of name')
    if 'apparmor' not in ac._fact_ids:
        raise AssertionError('apparmor not in fact identifiers')

# Generated at 2022-06-23 00:46:06.686840
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a is not None

# Generated at 2022-06-23 00:46:09.542951
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_fact_collector.name

# Generated at 2022-06-23 00:46:11.833170
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector


# Generated at 2022-06-23 00:46:12.846269
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:46:15.634990
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

# Generated at 2022-06-23 00:46:20.020979
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mocked_apparmor = ApparmorFactCollector()

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert mocked_apparmor.collect() == {'apparmor': {'status': 'enabled'}}
    else:
        assert mocked_apparmor.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:21.208910
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aaf = ApparmorFactCollector()
    aaf.collect()


# Generated at 2022-06-23 00:46:22.008481
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:46:23.150937
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afcobj = ApparmorFactCollector()
    assert afcobj is not None

# Generated at 2022-06-23 00:46:25.168086
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:46:32.530470
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # test_AAC_object is an instance of class ApparmorFactCollector
    test_AAC_object = ApparmorFactCollector()

    # apparmor enabled
    apparmor_enabled_facts = test_AAC_object.collect(
                                collected_facts={
                                    'kernel': 'Linux',
                                    'os_family': 'RedHat',
                                    'distribution': 'CentOS',
                                    'distribution_major_version': '7',
                                    'distribution_version': '7.4.1708',
                                }
                            )
    assert apparmor_enabled_facts['apparmor']['status'] == 'enabled'

    # apparmor disabled

# Generated at 2022-06-23 00:46:41.383619
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_dict = {'ansible_lsb': 
                    {'codename': 'trusty', 'description': 'Ubuntu 14.04.5 LTS', 
                     'id': 'Ubuntu', 'major_release': '14', 'release': '14.04'}, 
                'ansible_os_family': 'Debian', 'ansible_pkg_mgr': 'apt', 
                'gather_subset': ['all'], 'module_setup': True}

    apparmor_fact = ApparmorFactCollector()
    result = apparmor_fact.collect(collected_facts=mock_dict)
    assert result.get('apparmor').get('status') == 'disabled'


# Generated at 2022-06-23 00:46:43.799411
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    TestApparmorFactCollector = ApparmorFactCollector()
    assert TestApparmorFactCollector.name == 'apparmor'
    assert TestApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:46:47.821413
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:46:51.104324
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()

# Generated at 2022-06-23 00:46:54.873966
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:57.515921
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""

    test = ApparmorFactCollector()
    assert test.collect() == {"apparmor": {"status": "disabled"}}

# Generated at 2022-06-23 00:46:58.937063
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:47:03.366270
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create instance of class ApparmorFactCollector
    apparmor_collector = ApparmorFactCollector()

    # Assert that class is instance of BaseFactCollector
    assert isinstance(apparmor_collector, BaseFactCollector)

    # Assert that collect method is implemented
    assert callable(getattr(apparmor_collector, "collect"))

# Generated at 2022-06-23 00:47:07.235679
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:47:14.701078
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # collect in case of enabled apparmor
    file_path = '/sys/kernel/security/apparmor'
    with open(file_path, "w") as f:
         f.write('enables')
         with open(file_path, "r") as f:
             facts = {}
             ApparmorFactCollector().collect(None,facts)
             assert facts['apparmor']['status'] == 'enabled'

    # collect in case of apparmor disabled
    os.remove(file_path)
    facts = {}
    ApparmorFactCollector().collect(None,facts)
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:47:18.774106
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    apparmor_facts = apparmor.collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:47:22.262487
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    apparmor_facts = c.collect()
    assert 'apparmor' in apparmor_facts
    assert type(apparmor_facts['apparmor']) is dict
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-23 00:47:26.086836
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''Unit test for method collect of class ApparmorFactCollector'''
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect()
    assert type(facts_dict) == dict

# Generated at 2022-06-23 00:47:29.285972
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    collected_facts = {'ansible_facts':{}}
    expected_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_collector.collect(collected_facts=collected_facts)
    assert collected_facts == expected_facts