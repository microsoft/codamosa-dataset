

# Generated at 2022-06-23 00:37:34.028410
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test = ApparmorFactCollector()
    assert test.name == "apparmor"
    assert test._fact_ids == set()


# Generated at 2022-06-23 00:37:39.827546
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    mock_module = type('module', (object,), {})
    mock_collected_facts = type('collected_facts', (object,), {})
    mock_apparmor = type('apparmor', (object,), {})
    mock_apparmor.status = 'enabled'

    obj = ApparmorFactCollector()
    obj.collect(mock_module, mock_collected_facts)
    assert obj.facts['apparmor'].status == 'enabled'

# Generated at 2022-06-23 00:37:41.706326
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'



# Generated at 2022-06-23 00:37:43.050830
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    Ap = ApparmorFactCollector()
    assert Ap.name == 'apparmor'

# Generated at 2022-06-23 00:37:44.393210
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:37:48.338256
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert 'apparmor' == apparmor_collector.name
    assert 0 == len(apparmor_collector._fact_ids)
    assert 'ApparmorFactCollector' == apparmor_collector.__class__.__name__


# Generated at 2022-06-23 00:37:51.141168
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    os.stat = None
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:37:53.497207
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:37:58.308191
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFacts = ApparmorFactCollector()
    assert apparmorFacts._fact_ids == set()
    assert apparmorFacts.name == 'apparmor'

# Unit test Collect method

# Generated at 2022-06-23 00:38:00.263291
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    instance = ApparmorFactCollector()
    assert isinstance(instance, ApparmorFactCollector)


# Generated at 2022-06-23 00:38:05.445575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import json

    test_data = {
        'ansible_facts': {
            'apparmor': {
                'status': 'enabled'
            }
        }
    }

    apparmor_collector = ApparmorFactCollector()
    results = apparmor_collector.collect()
    assert results == test_data['ansible_facts']
    print(json.dumps({'changed': False, 'ansible_facts': results}, indent=4, sort_keys=True))

# Generated at 2022-06-23 00:38:07.873662
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    response = apparmor_collector.collect()
    assert response['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:38:12.121322
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """
    Verify constructor of class ApparmorFactCollector.
    """

    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.name == "apparmor"
    assert apparmor_fact_collector_obj.collect() == dict(apparmor=dict(status='disabled'))

# Generated at 2022-06-23 00:38:15.807467
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    facts_dict = apparmor_collector.collect()
    assert 'apparmor' in facts_dict
    assert isinstance(facts_dict['apparmor'], dict)
    assert 'status' in facts_dict['apparmor']

# Generated at 2022-06-23 00:38:17.807199
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'

# Generated at 2022-06-23 00:38:20.258866
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert hasattr(apparmor_fact, 'name')
    assert hasattr(apparmor_fact, '_fact_ids')

# Generated at 2022-06-23 00:38:21.313629
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:38:32.154367
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""

    def test_run_mock(module=None, collected_facts=None):
        """ Mock method in method collect of class ApparmorFactCollector """
        test_apparmor_facts = {'apparmor': {'status': 'enabled'}}
        return test_apparmor_facts

    # assign path to file
    m_open = mock_open()
    with patch('ansible.module_utils.facts.collector.open', m_open):
        # create an instance of ApparmorFactCollector
        apparmor_fact_collector = ApparmorFactCollector()
        # mock method collect of class ApparmorFactCollector
        apparmor_fact_collector.collect = test_run_mock
        # execute method collect of class ApparmorFactCollector
        result = app

# Generated at 2022-06-23 00:38:35.725447
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-23 00:38:38.468055
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    my_test_obj = ApparmorFactCollector()
    assert my_test_obj.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:38:40.102382
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'

# Generated at 2022-06-23 00:38:43.630366
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for ApparmorFactCollector.collect()"""

    apparmor_facts = {
       'apparmor': {'status': 'disabled'}
    }

    collector = ApparmorFactCollector()

    assert collector.collect() == apparmor_facts

# Generated at 2022-06-23 00:38:45.923372
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)


# Generated at 2022-06-23 00:38:50.738829
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    # apparmor should be in collected_facts
    assert 'apparmor' in apparmor_facts
    assert isinstance(apparmor_facts.get('apparmor').get('status'), str)

# Generated at 2022-06-23 00:38:51.907367
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:38:55.032009
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj.collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:38:59.985713
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()

    assert type(apparmor_facts) == dict
    assert type(apparmor_facts["apparmor"]) == dict
    assert apparmor_facts["apparmor"]["status"] == "disabled"

# Generated at 2022-06-23 00:39:02.471715
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_mock = ApparmorFactCollector()
    assert apparmor_mock.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:39:04.515887
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    app_fact_collector = ApparmorFactCollector()
    assert app_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:39:10.346360
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts_dict = {}
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    facts_dict['apparmor'] = apparmor_facts
    assert(facts_dict == 'ApparmorFactCollector.collect()')

# Generated at 2022-06-23 00:39:12.844645
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    f = ApparmorFactCollector()
    assert isinstance(f.collect(), dict)

# Generated at 2022-06-23 00:39:14.871955
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:18.904073
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollectorObj = ApparmorFactCollector()
    assert apparmorFactCollectorObj.name == 'apparmor'
    assert apparmorFactCollectorObj.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:39:21.771526
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_dict = apparmor_collector.collect()
    assert 'apparmor' in apparmor_dict
    assert 'status' in apparmor_dict['apparmor']
    assert type(apparmor_dict['apparmor']['status']) is str

# Test if file exists

# Generated at 2022-06-23 00:39:23.077140
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:39:25.346988
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact = ApparmorFactCollector()
    facts = fact.collect()
    key = fact.get_name()
    assert 'status' in facts[key]

# Generated at 2022-06-23 00:39:26.319504
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()


# Generated at 2022-06-23 00:39:29.548760
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:32.424101
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facts = {}
    o = ApparmorFactCollector(None, None)
    facts.update (o.collect())
    assert type(facts['apparmor']) == dict
    assert type(facts['apparmor']['status']) == str

# Generated at 2022-06-23 00:39:34.393385
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_test = ApparmorFactCollector()
    assert apparmor_fact_collector_test.name == 'apparmor'

# Generated at 2022-06-23 00:39:37.279678
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name.lower() == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:39:41.121866
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    facts_dict = apparmorFactCollector.collect()
    assert facts_dict['apparmor'] != None
    assert facts_dict['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:39:43.455752
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aafc = ApparmorFactCollector()
    facts = aafc.collect()
    assert type(facts) is dict
    assert facts.get('apparmor') is not None

# Generated at 2022-06-23 00:39:48.100535
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import ansible.module_utils.facts.collectors.platform.apparmor
    collector = ansible.module_utils.facts.collectors.platform.apparmor.ApparmorFactCollector()
    result = collector.collect()
    assert result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:39:54.919844
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Create a ApparmorFactCollector object
    a = ApparmorFactCollector()

    # Initialize a blank dict to collect ApparmorFacts
    facts = {}

    # Collect facts related to apparmor
    a.collect(module=None, collected_facts=facts)

    # Test if 'status' key is present in returned dict
    status = facts['apparmor']['status']
    assert status == 'disabled'

# Generated at 2022-06-23 00:39:58.924015
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == "apparmor"
    assert obj._fact_ids == set()
    assert obj.collect() == {"apparmor": {"status": "enabled"}}

# Unit test to check value of apparmor status 

# Generated at 2022-06-23 00:40:01.599807
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Method to test collect method of ApparmorFactCollector
    """
    fact = ApparmorFactCollector()
    result = fact.collect()
    assert result.get('apparmor') is not None

# Generated at 2022-06-23 00:40:05.204686
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert not(ApparmorFactCollector(None, None)._fact_ids)
    assert ApparmorFactCollector(None, None).name == 'apparmor'

# Generated at 2022-06-23 00:40:07.759836
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # collecting facts
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect()
    assert 'apparmor' in facts

# Generated at 2022-06-23 00:40:14.903027
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts['apparmor']
    assert apparmor_facts['apparmor']['status']
    if not os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:17.558926
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    test_dict = {'ansible_facts': {'apparmor': {'status': 'enabled'}}}

    assert apparmor_fact.collect() == test_dict

# Generated at 2022-06-23 00:40:21.444637
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert apparmor_collector._fact_ids == set()

# Generated at 2022-06-23 00:40:23.577209
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts == {}

# Generated at 2022-06-23 00:40:26.159867
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:40:29.353251
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.collect()["apparmor"]["status"] == "disabled"


# Generated at 2022-06-23 00:40:31.212421
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:32.844299
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector().name == 'apparmor')

# Generated at 2022-06-23 00:40:35.284118
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    c = ApparmorFactCollector()
    result = c.collect()
    assert result['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:40:37.070230
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert 'apparmor' == ApparmorFactCollector.name
    assert 'apparmor' == ApparmorFactCollector().name

# Generated at 2022-06-23 00:40:37.812699
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

# Generated at 2022-06-23 00:40:41.406940
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:40:50.124938
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    paths = ['/sys/kernel/security/apparmor']
    for path in paths:
        if os.path.exists(path):
            os.remove(path)
        open(path, 'a').close()
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-23 00:40:53.285838
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    ApparmorFactCollector = ApparmorFactCollector()
    print(ApparmorFactCollector.collect())




# Generated at 2022-06-23 00:40:54.883109
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'

# Generated at 2022-06-23 00:40:58.054708
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'
    assert base_collector in ApparmorFactCollector.__bases__


# Generated at 2022-06-23 00:41:02.295135
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    """Unit test for constructor of class ApparmorFactCollector"""
    apparmor_fact = ApparmorFactCollector()

    assert apparmor_fact._fact_ids == set()
    assert apparmor_fact.name == 'apparmor'

# Generated at 2022-06-23 00:41:08.854386
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_module = MockAnsible()
    test_collector = ApparmorFactCollector(ansible_module=ansible_module)
    apparmor_facts = {'status': 'disabled'}
    facts_dict = {'apparmor': apparmor_facts}
    assert facts_dict == test_collector.collect()


# Generated at 2022-06-23 00:41:10.391865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    m = ApparmorFactCollector()
    assert m.collect() == {}

# Generated at 2022-06-23 00:41:12.506336
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact._fact_ids == set()
    assert apparmor_fact.name == 'apparmor'


# Generated at 2022-06-23 00:41:15.141508
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact = ApparmorFactCollector()
    assert fact.name == 'apparmor'
    assert isinstance(fact._fact_ids, set)
    assert fact._fact_ids == set()

# Generated at 2022-06-23 00:41:18.887763
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()
    assert apparmor.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:26.957727
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Note that we do not need to specify paths for the /var/lib/dpkg/status
    # or /var/lib/dpkg/status-old files for unit testing as we mock this
    # call to the fake_file function which checks the input which we pass
    # in to check whether or not the file exists.
    module = None
    collected_facts = {}
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect(module=module, collected_facts=collected_facts)
    assert facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:29.108034
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()


# Generated at 2022-06-23 00:41:29.962505
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:41:32.225295
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    facter = ApparmorFactCollector()
    out = {'apparmor': {'status': 'enabled'}}
    assert facter.collect() == out

# Generated at 2022-06-23 00:41:33.394894
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:41:35.909312
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ftc = ApparmorFactCollector()
    ftc.collect()
    assert ftc.collect() == { 
        "apparmor": {
            "status": "enabled"
        }
    }

# Generated at 2022-06-23 00:41:46.493975
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import FactCollector
    # Initializing the collector
    fc = FactCollector()
    fc.collectors = [ApparmorFactCollector()]
    # Creating a mock module to pass as argument
    module = MockModule()
    # Executing the method with module as argument
    facts_dict = fc.collect(module, collected_facts=None)
    apparmor_facts = facts_dict['apparmor']
    assert apparmor_facts['status'] == 'n/a' or apparmor_facts['status'] == 'enabled' or apparmor_facts['status'] == 'disabled'


# Generated at 2022-06-23 00:41:48.885450
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:41:50.409861
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector(None, None)
    assert collector is not None

# Generated at 2022-06-23 00:41:52.739091
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:41:58.751376
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import json
    from ansible.module_utils.facts.collector import Collector

    x = Collector(None, None)
    x._collectors = [ApparmorFactCollector()]
    x._collected_facts = {}
    x.collect()
    assert json.loads(json.dumps(x._collected_facts)) == {
        "apparmor": {
            "status": "disabled"
        }
    }

test_ApparmorFactCollector_collect()

# Generated at 2022-06-23 00:42:00.686097
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert result['apparmor'] is not None

# Generated at 2022-06-23 00:42:02.284195
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:42:06.199456
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_collector_class = ApparmorFactCollector()
    assert test_collector_class.name == 'apparmor'
    assert set(test_collector_class._fact_ids) == set()

# Generated at 2022-06-23 00:42:09.293776
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector.collect()
    assert 'apparmor' in apparmor_fact
    assert isinstance(apparmor_fact['apparmor'], dict)

# Generated at 2022-06-23 00:42:12.664202
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    apparmor_facts = collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:42:15.567366
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert(a.name == "apparmor")
    assert(a._fact_ids == set())

# Unit tests for execute method of class ApparmorFactCollector

# Generated at 2022-06-23 00:42:20.690528
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    get_file_contents_mock = lambda x, encoding=None, errors='strict': ''
    module = None
    collected_facts = {}
    apparmor_fact_collector = ApparmorFactCollector(
        module=module,
        collected_facts=collected_facts,
        get_file_contents_mock=get_file_contents_mock
    )
    apparmor_fact_collector.collect(module, collected_facts)
    assert 'apparmor' in collected_facts

# Generated at 2022-06-23 00:42:24.580732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert(ApparmorFactCollector.collect()['apparmor']['status'] == 'disabled' or
    ApparmorFactCollector.collect()['apparmor']['status'] == 'enabled')

# Generated at 2022-06-23 00:42:29.176024
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert 'apparmor' in apparmor._fact_ids
    assert 'apparmor' not in apparmor.collect()

# Generated at 2022-06-23 00:42:33.085344
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:42:35.484077
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == "apparmor"

# Generated at 2022-06-23 00:42:37.063213
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect()

# Generated at 2022-06-23 00:42:40.278716
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    all_facts = {'apparmor': {'status': 'enabled'}}
    assert all_facts == apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:42:43.881666
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    expected_apparmor_info = {
        'status': 'enabled'
    }

    a = ApparmorFactCollector()
    b = a.collect()
    c = b['apparmor']

    assert c == expected_apparmor_info

# Generated at 2022-06-23 00:42:45.003318
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector is not None


# Generated at 2022-06-23 00:42:46.466632
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    result = fact_collector.collect()
    assert result

# Generated at 2022-06-23 00:42:50.583888
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    def __init__():
        self.name    = 'apparmor'
        self._fact_ids = set()

    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:42:53.374191
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect()
    assert facts['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:42:59.897221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """apparmor.py ApparmorFactCollector.collect() test case"""
    with open('/sys/kernel/security/apparmor', 'w') as apparmor_file:
        apparmor_file.write('foo')
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}
    os.remove('/sys/kernel/security/apparmor')
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:03.128778
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    apparmor_facts = fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:43:06.295685
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == \
    {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:08.931052
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_class = ApparmorFactCollector()
    assert test_class.name == 'apparmor'
    assert test_class._fact_ids == set()


# Generated at 2022-06-23 00:43:20.889409
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    default_apparmor_facts = {'apparmor': {'status': 'disabled'}}
    apparmor_status_enabled_facts = {'apparmor': {'status': 'enabled'}}
    apparmor_status_disabled_facts = {'apparmor': {'status': 'disabled'}}

    apparmor_fact_collector = ApparmorFactCollector()

    # Status is enabled when /sys/kernel/security/apparmor exists
    apparmor_fact_collector._file_exists = lambda x: True
    assert apparmor_status_enabled_facts == apparmor_fact_collector.collect()

    # Status is disabled when /sys/kernel/security/apparmor does not exist
    apparmor_fact_collector._file_exists = lambda x: False
    assert apparmor_status_disabled_facts == apparmor_fact_collect

# Generated at 2022-06-23 00:43:23.081125
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None


# Generated at 2022-06-23 00:43:26.419904
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts_collector = ApparmorFactCollector()

    assert apparmor_facts_collector.name == 'apparmor'
    assert apparmor_facts_collector._fact_ids == set()


# Generated at 2022-06-23 00:43:29.861570
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'
    assert apparmor_fc._fact_ids == set()


# Generated at 2022-06-23 00:43:39.138629
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """ Unit test for method collect of class ApparmorFactCollector """

    # Create instance of ApparmorFactCollector
    apparmor_collector_obj = ApparmorFactCollector()

    # Test case when apparmor is enabled
    apparmor_collector_obj._mounts = [ {'device': 'tmpfs', 'mount': '/sys/kernel/security/apparmor'} ]
    assert apparmor_collector_obj.collect() == {'apparmor': {'status': 'enabled'}}

    # Test case when apparmor is disabled
    apparmor_collector_obj._mounts = []
    assert apparmor_collector_obj.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:43:42.339178
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_c = ApparmorFactCollector()
    assert apparmor_c.name == 'apparmor'
    assert apparmor_c._fact_ids == set()

# Generated at 2022-06-23 00:43:44.359672
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmorFactCollector = ApparmorFactCollector()
    assert (apparmorFactCollector.name == "apparmor")

# Generated at 2022-06-23 00:43:45.357854
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:43:47.791783
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    try:
        ApparmorFactCollector()
    except:
        assert False



# Generated at 2022-06-23 00:43:51.437221
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_fact_collector.collect()
    assert apparmor_facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:57.097606
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = apparmor_fact_collector.collect( collected_facts=collected_facts)
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:58.753145
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector

# Generated at 2022-06-23 00:44:01.941643
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:44:03.918896
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids


# Generated at 2022-06-23 00:44:07.860368
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-23 00:44:09.684097
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:44:16.255712
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = {}
    apparmor_facts = apparmor_fact_collector.collect(collected_facts)
    expected_apparmor_facts = {'apparmor': {'status': 'disabled'}}
    assert apparmor_facts == expected_apparmor_facts

# Generated at 2022-06-23 00:44:22.001462
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    fake_facter_output = apparmor_fact_collector.collect()
    assert isinstance(fake_facter_output, dict)
    assert 'apparmor' in fake_facter_output
    assert 'status' in fake_facter_output['apparmor']
    assert fake_facter_output['apparmor']['status'] == "enabled"

# Generated at 2022-06-23 00:44:27.561662
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    factcollector = ApparmorFactCollector(None)
    facts = factcollector.collect()
    factcollector._fact_id = set()
    factcollector.collect_dir = {}
    factcollector._fact_id = set()
    factcollector.collect_dir = {}
    factcollector._fact_id = set()
    factcollector.collect_dir = {}
    assert 'apparmor' in facts.keys()

# Generated at 2022-06-23 00:44:32.159871
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    Test = ApparmorFactCollector()
    facts_dict = Test.collect()
    assert facts_dict["apparmor"]["status"] in ("enabled", "disabled")

# Generated at 2022-06-23 00:44:37.601102
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    # testing for constructor
    assert isinstance(apparmor_fact_collector, ApparmorFactCollector)

    # testing for name and fact_ids are read-only attribute
    with pytest.raises(AttributeError):
        apparmor_fact_collector.name = 'Apparmor'

    with pytest.raises(AttributeError):
        apparmor_fact_collector._fact_ids = 'Apparmor'

    # testing for collect method
    collected_facts = {}
    facts_dict = apparmor_fact_collector.collect(collected_facts)

    assert type(facts_dict) is dict

# Generated at 2022-06-23 00:44:48.404354
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    This is the unit test for the method ApparmorFactCollector.collect
    """

    # Apparmor is enabled if the path /sys/kernel/security/apparmor exists
    open_mock =  mock.mock_open(read_data='mock_data')
    with mock.patch('os.path.exists', return_value=True):
        with mock.patch('__builtin__.open', open_mock):
            apparmor_facts = ApparmorFactCollector.collect()
            expected_apparmor_facts = {'apparmor': {'status': 'enabled'}}
            assert apparmor_facts == expected_apparmor_facts

    # Apparmor is disabled if the path /sys/kernel/security/apparmor doesn't exists

# Generated at 2022-06-23 00:44:52.498863
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa_collector = ApparmorFactCollector()
    assert aa_collector.name == 'apparmor'
    assert aa_collector._fact_ids == set()


# Generated at 2022-06-23 00:44:54.899013
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:44:58.690978
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts['apparmor'] == {}
    assert 'apparmor' in collected_facts
    assert isinstance(collected_facts['apparmor'], dict)


# Generated at 2022-06-23 00:45:02.501755
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = None
    apparmor_fact_collector._collecting_facts = None

    apparmor_fact_collector.collect()


# Generated at 2022-06-23 00:45:04.325069
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert facts['apparmor']

# Generated at 2022-06-23 00:45:10.362274
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {}
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
    else:
        apparmor_facts['status'] = 'disabled'

    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result['apparmor'] == apparmor_facts

# Generated at 2022-06-23 00:45:14.665673
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    m = ApparmorFactCollector()
    assert m
    assert m.name == 'apparmor'


# Generated at 2022-06-23 00:45:15.753300
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'

# Generated at 2022-06-23 00:45:18.820579
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector._fact_ids.clear()
    ApparmorFactCollector().collect()
    assert ['apparmor'] == ApparmorFactCollector._fact_ids

# Generated at 2022-06-23 00:45:19.805136
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector.collect()

# Generated at 2022-06-23 00:45:23.538484
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj is not None
    assert isinstance(apparmor_obj, ApparmorFactCollector)
    assert isinstance(apparmor_obj, BaseFactCollector)

## Unit test for collect() of class ApparmorFactCollector

# Generated at 2022-06-23 00:45:25.116415
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    assert apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:28.168523
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    assertApparmorFactCollector = ApparmorFactCollector()
    assert "apparmor" == assertApparmorFactCollector.name

    assertApparmorFactCollector._fact_ids == set()

    assert "disabled" == assertApparmorFactCollector.collect()['apparmor']['status']

# Generated at 2022-06-23 00:45:30.054023
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Test with valid arguments
    assert ApparmorFactCollector().name == 'apparmor'
    assert ApparmorFactCollector()._fact_ids == set()

# Generated at 2022-06-23 00:45:33.959404
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()['apparmor']
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts['status'] == 'enabled'
    else:
        assert apparmor_facts['status'] == 'disabled'

# Generated at 2022-06-23 00:45:42.467336
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts_dict = apparmor_fact_collector.collect(collected_facts=None)
    assert facts_dict != None
    assert len(facts_dict) == 1
    assert 'apparmor' in facts_dict.keys()
    apparmor_facts = facts_dict['apparmor']
    assert apparmor_facts != None
    assert len(apparmor_facts) == 1
    assert 'status' in apparmor_facts.keys()
    assert (apparmor_facts['status'] == 'enabled' or apparmor_facts['status'] == 'disabled')

# Generated at 2022-06-23 00:45:45.584932
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # When Apparmor is not enabled
    fact_collector = ApparmorFactCollector()
    fact_collector.collect()
    assert fact_collector.collect() == { 'apparmor': {'status': 'disabled'} }

# Generated at 2022-06-23 00:45:48.870698
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set(['apparmor'])

# Generated at 2022-06-23 00:45:51.274596
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector().name, str)
    assert isinstance(ApparmorFactCollector()._fact_ids, set)

# Generated at 2022-06-23 00:45:51.925050
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    pass

# Generated at 2022-06-23 00:45:53.969007
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    test AppArmorFactCollector collect method
    """
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:46:00.004241
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    fact_dict = collector.collect()

    apparmor_fact = fact_dict['apparmor']
    assert 'status' in apparmor_fact

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert 'enabled' == apparmor_fact['status']
    else:
        assert 'disabled' == apparmor_fact['status']

# Generated at 2022-06-23 00:46:02.099292
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    c = ApparmorFactCollector()
    assert c.name == 'apparmor'
    assert c._fact_ids == set()

# Generated at 2022-06-23 00:46:04.580056
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:46:07.313063
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    os.environ['LANG'] = 'C'
    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:46:10.394843
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:13.497764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector._fact_ids.add('apparmor')
    facts = ApparmorFactCollector().collect()
    assert facts['apparmor']['status'] in ('enabled', 'disable')

# Generated at 2022-06-23 00:46:15.541457
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    module = object()
    collected_facts = object()
    ApparmorFactCollector(module, collected_facts)


# Generated at 2022-06-23 00:46:19.149902
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    ansible_module = mock_ansible_module()
    host_facts = apparmor_collector.collect(ansible_module)
    assert host_facts['apparmor']['status'] == 'disabled'


# Generated at 2022-06-23 00:46:27.624519
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test when apparmor is disabled
    with open('/sys/kernel/security/apparmor', 'wb') as f:
        f.write(b'NOPROB')
        ApparmorFactCollector(None)
        assert ApparmorFactCollector._fact_ids == set()
        f.close()
    # Test when apparmor is enabled
    with open('/sys/kernel/security/apparmor', 'wb') as f:
        f.write(b'ENABLED')
        fact = ApparmorFactCollector(None)
        assert 'apparmor' in fact.collect()
        assert fact.collect()['apparmor']['status'] == 'enabled'
        assert ApparmorFactCollector._fact_ids == {'apparmor'}
        f.close()

# Generated at 2022-06-23 00:46:30.692011
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_obj = ApparmorFactCollector()
    assert apparmor_fact_obj.name == "apparmor"
    assert apparmor_fact_obj._fact_ids == set()


# Generated at 2022-06-23 00:46:35.538926
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for ApparmorFactCollector.collect
    """
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert 'enabled' in facts['apparmor']['status']

# Generated at 2022-06-23 00:46:40.760994
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor.collect()['apparmor']['status'] == 'enabled'
    else:
        assert apparmor.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:46:42.134892
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_obj = ApparmorFactCollector()
    apparmor_obj.collect()

# Generated at 2022-06-23 00:46:43.800007
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:46:48.430777
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert len(apparmor_fact_collector._fact_ids) == 0
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:46:57.516148
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    # Test the instantiation of ApparmorFactCollector
    apparmor = ApparmorFactCollector()
    assert isinstance(apparmor, ApparmorFactCollector)
    assert hasattr(apparmor, 'name')
    assert hasattr(apparmor, '_fact_ids')
    assert isinstance(apparmor._fact_ids, set)
    assert hasattr(apparmor, 'collect')
    assert hasattr(apparmor, '_collect')
    assert isinstance(apparmor.name, str)
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()


# Generated at 2022-06-23 00:46:59.376302
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_collector = ApparmorFactCollector()
    assert apparmor_collector.name == 'apparmor'

# Generated at 2022-06-23 00:47:01.155763
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert isinstance(apparmor.collect(), dict)

# Generated at 2022-06-23 00:47:02.509275
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert hasattr(ApparmorFactCollector, '__init__')

# Generated at 2022-06-23 00:47:12.904693
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    This method tests different output of the method collect() of class
    ApparmorFactCollector according to the existence of file /sys/kernel/security/apparmor
    :return: True
    """
    result = {}
    # Initialize ApparmorFactCollector class
    apparmor_fact_collector = ApparmorFactCollector()
    # Test if file /sys/kernel/security/apparmor exists
    with open('/sys/kernel/security/apparmor', 'w') as file_handler:
        file_handler.write("Test file content")
    assert file_handler.closed
    result = apparmor_fact_collector.collect()
    assert result == {'apparmor': {'status': 'enabled'}}
    # Test if file /sys/kernel/security/apparmor does not exist

# Generated at 2022-06-23 00:47:18.447613
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert afc.collect()['apparmor']['status'] == 'enabled'
    else:
        assert afc.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:47:20.517230
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()



# Generated at 2022-06-23 00:47:23.552275
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:47:27.094254
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    # check if dictionary apparmor_facts exists
    assert 'apparmor' in apparmor_facts
    # check if dictionary fact contains key status
    assert 'status' in apparmor_facts['apparmor']

# Generated at 2022-06-23 00:47:27.990626
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()


# Generated at 2022-06-23 00:47:31.280087
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    gf = ApparmorFactCollector()
    result = gf.collect()

    assert type(result) == dict
    assert 'apparmor' in result