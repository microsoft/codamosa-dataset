

# Generated at 2022-06-23 00:37:34.957483
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()

# Unit test which tests collect method of class ApparmorFactCollector

# Generated at 2022-06-23 00:37:37.083419
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert isinstance(apparmor_fact_collector.collect(), dict)

# Generated at 2022-06-23 00:37:39.667473
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 00:37:41.541159
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
  apparmorFactCollector = ApparmorFactCollector()

  assert apparmorFactCollector is not None

# Generated at 2022-06-23 00:37:47.018854
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_facts = {}
    apparmor_facts['status'] = 'enabled'

    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_facts == apparmor_fact_collector.collect()
    else:
        apparmor_facts['status'] = 'disabled'
        assert apparmor_facts == apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:37:55.684266
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Arrange
    # Return value from function exists of os.path mock object is set to True
    os_path_mock = 'ansible.module_utils.facts.collector.os.path.exists'
    with mock.patch(os_path_mock) as mock_exists:
        mock_exists.return_value = True

        # Act
        apparmor_fact_collector = ApparmorFactCollector()
        result = apparmor_fact_collector.collect()

        # Assert
        # Check if the result is not None and has a key named apparmor
        assert result is not None
        assert result.has_key('apparmor')

        # Check if value of apparmor key is not None
        assert result.get('apparmor') is not None

        # Check if apparmor has a key named 'status'


# Generated at 2022-06-23 00:37:58.676484
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:38:00.125658
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact

# Generated at 2022-06-23 00:38:00.875954
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:38:04.536993
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert isinstance(obj, BaseFactCollector)
    # check instance variables
    assert 'apparmor' == obj.name
    assert set() == obj._fact_ids

# Generated at 2022-06-23 00:38:05.478766
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'

# Generated at 2022-06-23 00:38:07.920999
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_collector.collect()
    assert isinstance(apparmor_collector.collect(), dict)

# Generated at 2022-06-23 00:38:09.282122
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ap = ApparmorFactCollector()
    assert ap.name == 'apparmor'

# Generated at 2022-06-23 00:38:12.188567
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Creating an instance of class ApparmorFactCollector
    apparmor_facts = ApparmorFactCollector()

    # Testing the method collect of class ApparmorFactCollector
    apparmor_facts.collect()

# Generated at 2022-06-23 00:38:13.627339
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-23 00:38:15.709810
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'

# Generated at 2022-06-23 00:38:18.083670
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:38:19.098551
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector().name == 'apparmor'

# Generated at 2022-06-23 00:38:21.752319
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method collect of class ApparmorFactCollector
    of module AnsibleModuleUtils.Facts.apparmor_fact
    """
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:38:23.749315
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    apparmor_fc.collect()

# Generated at 2022-06-23 00:38:25.958289
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_obj = ApparmorFactCollector()
    assert apparmor_fact_collector_obj.name == "ApparmorFactCollector"

# Generated at 2022-06-23 00:38:31.488652
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()
    fact_collector = ApparmorFactCollector(facts_collector)
    facts_collector.add_collector(fact_collector)
    facts = facts_collector.collect(None, None)
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:38:35.677867
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Create an instance of ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()
    resp = apparmor_fact_collector.collect()
    assert resp.get('apparmor')['status'] == 'disabled'

# Generated at 2022-06-23 00:38:36.609006
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:38:38.282066
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:38:39.541936
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fc = ApparmorFactCollector()
    apparmor_fc.collect()

# Generated at 2022-06-23 00:38:40.442824
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:38:51.620754
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    why: Unit test for method collect of class ApparmorCollector

    coverage:
    - All code paths
    """

    # Collect facts for successful scenario
    apparmor_path = '/sys/kernel/security/apparmor'
    real_file_exists = os.path.exists
    os.path.exists = lambda p: p if apparmor_path in p else real_file_exists(p)
    a = ApparmorFactCollector()
    facts_dict = a.collect()
    os.path.exists = real_file_exists
    assert facts_dict['apparmor']['status'] == 'enabled'

    # Collect facts when apparmor is not enabled
    real_file_exists = os.path.exists
    os.path.exists = lambda p: False
    a = ApparmorFact

# Generated at 2022-06-23 00:38:55.209034
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    name = 'apparmor'
    apparmor_collector = ApparmorFactCollector()
    assert(apparmor_collector.name == name)
    assert(apparmor_collector._fact_ids == set())

# Generated at 2022-06-23 00:38:56.899523
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    assert afc.collect()

# Generated at 2022-06-23 00:38:59.927491
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Tests to ensure constructor initializes correctly
    apparmor_obj = ApparmorFactCollector()
    assert apparmor_obj.name == 'apparmor'



# Generated at 2022-06-23 00:39:04.693355
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts_dict = collector.collect(None, None)
    facts_dict_expected = {'apparmor': {'status': 'disabled'}}
    assert facts_dict == facts_dict_expected
# End of unit test of method collect of class ApparmorFactCollector

# Generated at 2022-06-23 00:39:07.806454
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.name == 'apparmor'
    assert fact_collector._fact_ids == set()

# Unit test to collect facts related to Apparmor

# Generated at 2022-06-23 00:39:12.140909
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:39:14.507258
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert apparmor._fact_ids == set()

# Generated at 2022-06-23 00:39:16.355108
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:39:17.838194
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:39:20.285935
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:39:30.753148
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import shutil
    if os.path.exists('/sys/kernel/security/apparmor'):
        shutil.move('/sys/kernel/security/apparmor', '/tmp/apparmor_save')

    apparmor_collector = ApparmorFactCollector()

    assert apparmor_collector.collect() == {'apparmor': {'status': 'disabled'}}
    os.makedirs('/sys/kernel/security/apparmor')
    assert apparmor_collector.collect() == {'apparmor': {'status': 'enabled'}}

    if os.path.exists('/tmp/apparmor_save'):
        shutil.move('/tmp/apparmor_save', '/sys/kernel/security/apparmor')

# Generated at 2022-06-23 00:39:35.370009
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:37.906272
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert not apparmor_fact_collector._fact_ids
    assert apparmor_fact_collector.name == "apparmor"


# Generated at 2022-06-23 00:39:41.309765
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    aa_fact_collector = ApparmorFactCollector()
    assert aa_fact_collector.name == 'apparmor'
    assert aa_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:39:44.609501
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_module = mock.Mock(params=dict())

    collector = ApparmorFactCollector()
    assert collector._collect_from_source(ansible_module) == dict(apparmor=dict(status='enabled'))

# Generated at 2022-06-23 00:39:46.548811
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:39:58.126359
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os

    class ModuleMock():
        pass
    module = ModuleMock()

    test_file = '/tmp/test_file.txt'
    with open(test_file, 'w') as f:
        f.write('Test file')
    os.chmod(test_file, 0o000)
    os.chown(test_file, 0, 0)

    apparmor_collector = ApparmorFactCollector()
    facts = {}

    fact_collector_result = apparmor_collector.collect(module, facts)
    assert fact_collector_result is not None
    assert facts == fact_collector_result
    assert isinstance(fact_collector_result, dict)
    assert fact_collector_result['apparmor'] == {'status': 'enabled'}

# Generated at 2022-06-23 00:40:01.508806
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()
    assert apparmor_fact_collector.collect() == {}

# Generated at 2022-06-23 00:40:03.317709
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:40:06.351424
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector(None)
    assert collector.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:11.096064
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()

    ansible_module = mock.Mock()
    apparmor_fact_collector.collect(module=ansible_module)
    assert ansible_module.exit_json.called

# Generated at 2022-06-23 00:40:13.663001
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == dict(apparmor=dict(status='disabled'))

# Generated at 2022-06-23 00:40:16.284531
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:40:18.520101
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:40:21.116240
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collecter = ApparmorFactCollector()
    apparmor_fact_collecter.collect()

# Generated at 2022-06-23 00:40:23.259675
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector is not None

# Generated at 2022-06-23 00:40:26.721296
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    result = apparmor_fact_collector.collect()
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:31.021502
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test whether we get facts related to apparmor"""
    apparmor_facts = ApparmorFactCollector()
    # If /sys/kernel/security/apparmor does not exist, apparmor is disabled
    # on the running system.
    assert apparmor_facts.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:40:33.097756
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    t = ApparmorFactCollector()
    assert t.name == "apparmor"


# Generated at 2022-06-23 00:40:35.495802
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:40:37.678772
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 00:40:39.962596
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    apparmor = apparmor_facts.collect()
    assert apparmor['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:40:43.760023
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    status = apparmor_fact.collect()['apparmor']['status']
    assert status == 'disabled'

# Generated at 2022-06-23 00:40:44.560765
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert(ApparmorFactCollector.name == 'apparmor')

# Generated at 2022-06-23 00:40:49.894423
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact = ApparmorFactCollector()
    assert apparmor_fact.name == 'apparmor'
    assert apparmor_fact._fact_ids == set()


# Generated at 2022-06-23 00:40:57.353905
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Using a fresh ApparmorFactCollector object
    apparmor_fact_collector = ApparmorFactCollector()

    fact_value = apparmor_fact_collector.collect()

    # If there is no apparmor on the host, the fact value should be
    # same to {'status': 'disabled'}
    # If there is apparmor on the host, the fact value should be
    # same to {'status': 'enabled'}
    assert fact_value['apparmor']['status'] in ('enabled', 'disabled')



# Generated at 2022-06-23 00:41:00.558732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    fact = fact_collector.collect()
    assert fact.has_key('apparmor') and fact['apparmor'].has_key('status')

# Generated at 2022-06-23 00:41:03.394524
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collected_facts = ApparmorFactCollector().collect()
    assert  apparmor_collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:41:04.251054
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert True

# Generated at 2022-06-23 00:41:13.601888
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Return an empty dictionary
    def mock_exec_command(cmd, *args, **kwargs):
        return (None, None)

    # Create a test for module_utils.linux.distribution.linux_distribution
    # with the side effect method
    m = module_utils.linux.distribution.linux_distribution
    module_utils.linux.distribution.linux_distribution = mock_exec_command

    # Create a test for get_distribution_version of
    # module_utils.linux.distribution with side effect method
    m2 = module_utils.linux.distribution.get_distribution_version
    module_utils.linux.distribution.get_distribution_version = mock_exec_command

    # Create a test for module_utils.facts.collector.BaseFactCollector.file_exists
    # with

# Generated at 2022-06-23 00:41:14.720742
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:41:18.181691
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:41:25.445513
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    # When apparmor is enabled
    apparmor_fact_collector.collect = lambda: {'apparmor': {'status': 'enabled'}}
    apparmor_facts = apparmor_fact_collector.collect()

    # When apparmor is disabled
    apparmor_fact_collector.collect = lambda: {'apparmor': {'status': 'disabled'}}
    apparmor_facts = apparmor_fact_collector.collect()

# Generated at 2022-06-23 00:41:28.423273
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()

    assert apparmor_fact_collector.name == "apparmor"
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:41:34.687783
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''Unit test for ApparmorFactCollector.collect'''
    path = '/sys/kernel/security/apparmor'
    if os.path.exists(path):
        os.remove(path)
    apparmor_facts = ApparmorFactCollector()
    apparmor_facts_dict = apparmor_facts.collect()
    assert 'apparmor' in apparmor_facts_dict
    assert 'status' in apparmor_facts_dict['apparmor']
    if os.path.exists(path):
        os.remove(path)

# Generated at 2022-06-23 00:41:37.948675
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    assert apparmor.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:44.219865
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    # Test with aiab-apparmor module available
    os.path.exists = lambda x: True
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}

    # Test without aiab-apparmor module available
    os.path.exists = lambda x: False
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:47.414192
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()


# Generated at 2022-06-23 00:41:49.068235
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:41:54.891346
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    '''
    Test whether apparmor facts are gathered properly if apparmor is
    already enabled
    '''
    import mock

    sys_kernel_security_apparmor = mock.PropertyMock(return_value=True)
    type(sys_kernel_security_apparmor).__module__ = 'test'
    type(sys_kernel_security_apparmor).__name__ = 'module'
    assert ApparmorFactCollector().collect()['apparmor']['status'] == 'enabled'

# Generated at 2022-06-23 00:41:56.371244
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'
    assert apparmor_facts._fact_ids == set()


# Generated at 2022-06-23 00:41:58.767618
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    result = afc.collect()
    assert result['apparmor']['status'] is not None

# Generated at 2022-06-23 00:42:02.339558
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    result = collector.collect()

    # Checking the status has been correctly collected
    assert result['apparmor']['status']

    # Checking the collected status is valid
    assert result['apparmor']['status'] == 'enabled' or result['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:42:04.805242
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector

# Generated at 2022-06-23 00:42:09.437632
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Test if the function returns a valid Python dictionary
    """
    apf = ApparmorFactCollector()
    results = apf.collect()
    assert isinstance(results, dict), "The method [ApparmorFactCollector.collect] must return a dictionary"

# Generated at 2022-06-23 00:42:10.587472
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:42:13.332345
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = {'apparmor': {'status': 'enabled'}}
    assert apparmor_facts == ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:42:16.348521
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    path = os.path.join('/include')
    f = ApparmorFactCollector(path)
    assert f.name == 'apparmor'
    assert f._fact_ids == set()
    

# Generated at 2022-06-23 00:42:20.023301
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    test_obj = ApparmorFactCollector()
    print("apparmor dict: ")
    print(test_obj.collect())


# Generated at 2022-06-23 00:42:23.398051
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    instance = ApparmorFactCollector({}, {})
    assert instance.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:42:33.004900
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Test with apparmor disabled
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ''
    os.environ['ANSIBLE_LIBRARY'] = ''
    os.environ['ANSIBLE_MODULE_UTILS'] = ''
    os.environ['ANSIBLE_FILTER_PLUGINS'] = ''

    apparmor = ApparmorFactCollector()
    assert apparmor.collect() == {'apparmor': {'status': 'disabled'}}


# Generated at 2022-06-23 00:42:35.910978
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'
    assert len(obj._fact_ids) == 0

# Generated at 2022-06-23 00:42:38.740913
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector._fact_ids == set()
    assert fact_collector.name == 'apparmor'


# Generated at 2022-06-23 00:42:42.372186
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {}
    collected_facts = {}
    apparmor_fact_collector = ApparmorFactCollector()
    fact = apparmor_fact_collector.collect(module, collected_facts)
    assert 'apparmor' in fact

# Generated at 2022-06-23 00:42:44.241797
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'

# Generated at 2022-06-23 00:42:50.693021
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    # Create some dummy file paths
    dirs = {
        '/proc/mounts': False,
        '/sys/kernel/security/apparmor': True
    }

    def exists(path):
        return dirs.get(path, False)

    # Execute constructor
    fc = ApparmorFactCollector(None, {}, None)

    # Set fact collector to use test exists function above
    fc.exists = exists

    # Test if paths are detected correctly
    assert fc.should_collect() is True

    # Test if facts are collected correctly
    assert fc.collect() == {
        'apparmor': {
            'status': 'enabled'
        }
    }


# Generated at 2022-06-23 00:42:53.471428
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x.name == 'apparmor'
    assert x._fact_ids == set()


# Generated at 2022-06-23 00:43:04.218957
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import os

    apparmor_collector = ApparmorFactCollector()
    fd = os.open('/sys/kernel/security/apparmor', os.O_RDONLY)
    os.close(fd)
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts
    assert 'status' in apparmor_facts['apparmor']
    assert apparmor_facts['apparmor']['status'] == 'enabled'

    no_apparmor_collector = ApparmorFactCollector()
    os.remove('/sys/kernel/security/apparmor')
    no_apparmor_facts = no_apparmor_collector.collect()
    assert 'apparmor' in no_apparmor_facts
    assert no_apparmor_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:08.193170
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    if apparmor_fact_collector is not None:
        pass
    else:
        raise Exception("Failed to instantiate ApparmorFactCollector class")


# Generated at 2022-06-23 00:43:12.174765
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    objCollector = ApparmorFactCollector()
    if os.path.exists('/sys/kernel/security/apparmor'):
        status = 'enabled'
    else:
        status = 'disabled'
    assert objCollector.collect() == {'apparmor': {'status': status}}

# Generated at 2022-06-23 00:43:13.905762
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    facts = fact_collector.collect(None, None)
    assert facts == {}

# Generated at 2022-06-23 00:43:17.006764
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    assert fact_collector.collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:43:20.734584
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    def mock_path_exists(path):
        return True
    os.path.exists = mock_path_exists
    apparmor_instance = ApparmorFactCollector()
    assert apparmor_instance.name == 'apparmor'
    assert apparmor_instance._fact_ids == set()


# Generated at 2022-06-23 00:43:22.930846
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor = ApparmorFactCollector()
    facts = apparmor.collect(None, None)
    assert isinstance(facts['apparmor'], dict)

# Generated at 2022-06-23 00:43:24.785485
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert(obj.name == 'apparmor')


# Generated at 2022-06-23 00:43:26.625591
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids is not None

# Generated at 2022-06-23 00:43:35.590793
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # create an instance of the ApparmorFactCollector
    aaf = ApparmorFactCollector()
    apparmor_facts = {}
    # check if status is enabled and it is the only item
    if os.path.exists('/sys/kernel/security/apparmor'):
        apparmor_facts['status'] = 'enabled'
        assert len(aaf.collect()['apparmor'].keys()) == 1
    # check if status is disabled and it is the only item
    else:
        apparmor_facts['status'] = 'disabled'
        assert len(aaf.collect()['apparmor'].keys()) == 1

# Generated at 2022-06-23 00:43:37.025692
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector()

# Generated at 2022-06-23 00:43:41.125197
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == "apparmor"
    assert ApparmorFactCollector().name == "apparmor"
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:43:42.228697
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'

# Generated at 2022-06-23 00:43:47.745789
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector_instance = ApparmorFactCollector(None)

    # file exists
    facts = fact_collector_instance.collect()
    assert facts['apparmor']['status'] == 'enabled'

    # file does not exists
    os.path.exists = lambda x: False
    facts = fact_collector_instance.collect()
    assert facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:43:51.244236
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Unit test for method collect of class ApparmorFactCollector"""
    aaf = ApparmorFactCollector()
    facts = aaf.collect()
    assert 'apparmor' in facts
    assert 'status' in facts['apparmor']

# Generated at 2022-06-23 00:43:54.628151
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    input = ApparmorFactCollector()
    expected_output = True
    assert input.collect() == expected_output


# Generated at 2022-06-23 00:43:58.155805
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect()
    assert facts['apparmor']['status'] in ('enabled', 'disabled')

# Generated at 2022-06-23 00:44:01.164228
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector().collect()
    # The apparmor status is either enabled or disabled
    assert ('enabled' in apparmor_facts['apparmor']['status']
            or 'disabled' in apparmor_facts['apparmor']['status'])

# Generated at 2022-06-23 00:44:02.795408
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    f = ApparmorFactCollector()
    assert f.name == 'apparmor'

# Generated at 2022-06-23 00:44:05.989970
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    afc = ApparmorFactCollector()
    afc_collect = afc.collect()
    assert afc_collect['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:08.664991
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fc = ApparmorFactCollector()
    assert apparmor_fc.name == 'apparmor'


# Generated at 2022-06-23 00:44:11.240483
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aa_fac = ApparmorFactCollector()
    apparmor_facts = aa_fac.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:44:13.121310
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert facts == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:44:24.195479
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    import json
    import platform
    import os

    # Create a instance of class ApparmorFactCollector
    apparmor_fact_collector = ApparmorFactCollector()

    # Test the collect method of ApparmorFactCollector class
    # get the distribution name
    distribution_name = platform.linux_distribution()[0]

    # Check the file and dir existence
    if os.path.exists('/sys/kernel/security/apparmor'):
        file_exists = True
    else:
        file_exists = False

    # Checking output
    if file_exists:
        if distribution_name == 'Red Hat':
            with open("../tests/unittest_data/RHEL7/expected_apparmor_collect") as expected_data:
                expected_output = json.load(expected_data)

# Generated at 2022-06-23 00:44:26.910278
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aapparmor_fact_collector = ApparmorFactCollector()
    aapparmor_fact_collector.collect(None) == {}

# Generated at 2022-06-23 00:44:30.909183
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'
    assert a._fact_ids == set()

# Generated at 2022-06-23 00:44:32.841617
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    collector = ApparmorFactCollector()
    assert collector.name == 'apparmor'

# Generated at 2022-06-23 00:44:39.193679
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # pylint: disable=redefined-outer-name
    """
    Test if ApparmorFactCollector is able to collect apparmor facts
    """
    test_apparmor_fact_collector = ApparmorFactCollector()
    test_apparmor_fact_collector.collect()
    assert 'apparmor' in test_apparmor_fact_collector._collected_facts
    assert 'status' in test_apparmor_fact_collector._collected_facts['apparmor']

# Generated at 2022-06-23 00:44:42.704573
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fc = ApparmorFactCollector()
    assert fc is not None
    assert fc.name == 'apparmor'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 00:44:49.280924
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    module = {'run_command': lambda *args, **kwargs: 'enabled'}
    ac = ApparmorFactCollector(module)
    collected_facts = ac.collect()
    assert collected_facts['apparmor']['status'] == 'enabled'

    module = {'run_command': lambda *args, **kwargs: 'disabled'}
    ac = ApparmorFactCollector(module)
    collected_facts = ac.collect()
    assert collected_facts['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:44:52.183675
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    afc = ApparmorFactCollector()
    assert afc.name == 'apparmor'
    assert afc._fact_ids == set()


# Generated at 2022-06-23 00:44:55.875896
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_facts = ApparmorFactCollector()
    result = apparmor_facts.collect()
    assert result.get('apparmor')

# Generated at 2022-06-23 00:44:58.242100
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_apparmor_facts = ApparmorFactCollector().collect()
    assert test_apparmor_facts['apparmor']['status'] in ['disabled','enabled']

# Generated at 2022-06-23 00:45:05.950665
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()

    # if apparmor is enabled
    open('/sys/kernel/security/apparmor', 'w').close()
    ans = ac.collect()
    assert ans == {'apparmor': {'status': 'enabled'}}
    os.remove('/sys/kernel/security/apparmor')

    # if apparmor is disabled
    ans = ac.collect()
    assert ans == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:45:07.667584
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    fact_collector = ApparmorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-23 00:45:10.934891
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts_dict = dict()
    test_class = ApparmorFactCollector(module=None, collected_facts=facts_dict)
    assert test_class.name == 'apparmor'
    assert not test_class._fact_ids

# Generated at 2022-06-23 00:45:14.654033
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_facts = ApparmorFactCollector()
    assert apparmor_facts.name == 'apparmor'

# Generated at 2022-06-23 00:45:20.930911
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    factCollector = ApparmorFactCollector()
    facts_dict = factCollector.collect()
    assert 'apparmor' in facts_dict
    assert 'status' in facts_dict['apparmor']
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert facts_dict['apparmor']['status'] == 'enabled'
    else:
        assert facts_dict['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:25.205122
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorFactCollector = ApparmorFactCollector()
    apparmorFactCollector.collect()
    assert apparmorFactCollector.name == 'apparmor'
    assert len(apparmorFactCollector._fact_ids) == 0

# Generated at 2022-06-23 00:45:26.957162
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    a = ApparmorFactCollector()
    a.collect()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:45:29.368277
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact = ApparmorFactCollector()
    facts_dict = apparmor_fact.collect()
    assert facts_dict == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:45:30.531358
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name

# Generated at 2022-06-23 00:45:33.077757
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():

    apparmorFactCollector = ApparmorFactCollector()
    assert apparmorFactCollector.name == 'apparmor'
    assert apparmorFactCollector._fact_ids == set()


# Generated at 2022-06-23 00:45:41.740426
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    apparmor_fact_collector._module = None
    apparmor_fact_collector._collector = None
    apparmor_fact_collector._collected_facts = {}
    apparmor_fact_collector.collect()
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert apparmor_fact_collector.collect()['apparmor']['status'] == 'enabled'
    else:
        assert apparmor_fact_collector.collect()['apparmor']['status'] == 'disabled'

# Generated at 2022-06-23 00:45:43.448813
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert ApparmorFactCollector.name == 'apparmor'
    assert ApparmorFactCollector._fact_ids == set()

# Generated at 2022-06-23 00:45:44.747977
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    obj = ApparmorFactCollector()
    assert obj.name == 'apparmor'

# Generated at 2022-06-23 00:45:47.432781
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    test_obj = ApparmorFactCollector()
    assert test_obj.collect() == {
        'apparmor': {
            'status': 'disabled',
        }
    }

# Generated at 2022-06-23 00:45:56.641566
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Return facts related to apparmor.

    ApparmorFactCollector.collect() is called to collect facts to get
    facts related to apparmor, which is used in the following tests.

        - test_apparmor_enabled
        - test_apparmor_disabled

    :returns: facts related to apparmor

    """
    facts_dict = {}
    apparmor_facts = {}
    apparmor_facts['status'] = 'disabled'

    facts_dict['apparmor'] = apparmor_facts
    return facts_dict

# Unit tests for module module_utils/facts/apparmor.py

# Generated at 2022-06-23 00:46:06.314736
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():

    class ansible_mock:

        def __init__(self):
            self.module_utils = module_utils_mock()

    class module_utils_mock:

        class distribution_mock:
            pass

        class package_mock:
            pass

        class system_mock:

            class distribution_mock:
                pass

            class release_mock:
                pass

        @staticmethod
        def get_distribution():
            return module_utils_mock.distribution_mock()

        @staticmethod
        def get_package_facts():
            return module_utils_mock.package_mock()

        @staticmethod
        def get_system_distribution():
            return module_utils_mock.system_mock.distribution_mock


# Generated at 2022-06-23 00:46:10.110517
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector = ApparmorFactCollector()
    ApparmorFactCollector.collect()
    apparmor_facts = ApparmorFactCollector.collect()
    assert apparmor_facts['apparmor'] == 'enabled'

# Generated at 2022-06-23 00:46:15.131575
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    # Crate an ApparmorFactCollector object
    fact_obj = ApparmorFactCollector()
    # Create ansible fact
    ansible_facts = {}
    # Call collect method
    result = fact_obj.collect(collected_facts=ansible_facts)
    # Check that result is valid and file exists
    assert os.path.exists('/sys/kernel/security/apparmor')

# Generated at 2022-06-23 00:46:19.892375
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    collected_facts = {}
    facts_dict = collector.collect(collected_facts)
    if os.path.exists('/sys/kernel/security/apparmor'):
        assert ('enabled' == facts_dict['apparmor']['status'])
    else:
        assert ('disabled' == facts_dict['apparmor']['status'])

# Generated at 2022-06-23 00:46:21.499595
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    fact_collector = ApparmorFactCollector()
    print (fact_collector.collect())


# Generated at 2022-06-23 00:46:24.013975
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    facts_dict = ApparmorFactCollector()
    assert isinstance(facts_dict, BaseFactCollector)
    assert facts_dict.name == 'apparmor'
    assert facts_dict._fact_ids == set()

# Generated at 2022-06-23 00:46:27.034738
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Unit test for method collect of class ApparmorFactCollector
    """
    fact_collector = ApparmorFactCollector()
    apparmor_facts = fact_collector.collect()
    assert 'apparmor' in apparmor_facts

# Generated at 2022-06-23 00:46:28.658941
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ac = ApparmorFactCollector()
    assert ac.collect()

# Generated at 2022-06-23 00:46:31.550840
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector = ApparmorFactCollector()
    assert apparmor_fact_collector.name == 'apparmor'
    assert apparmor_fact_collector._fact_ids == set()

# Generated at 2022-06-23 00:46:32.436745
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {}

# Generated at 2022-06-23 00:46:35.683582
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """
    Tests for the method 'collect' of class 'ApparmorFactCollector'
    """
    ApparmorFactCollectorObject = ApparmorFactCollector(None)
    assert isinstance(ApparmorFactCollectorObject.collect(), dict)

# Generated at 2022-06-23 00:46:38.484943
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'


# Generated at 2022-06-23 00:46:40.008513
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert isinstance(ApparmorFactCollector(), ApparmorFactCollector)

# Generated at 2022-06-23 00:46:42.511338
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_collector = ApparmorFactCollector()
    apparmor_facts = apparmor_collector.collect()
    assert 'apparmor' in apparmor_facts



# Generated at 2022-06-23 00:46:44.139452
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    assert ApparmorFactCollector().collect() == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:46:49.749699
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    assert hasattr(ApparmorFactCollector, 'name')
    assert isinstance(ApparmorFactCollector().name, str)
    assert hasattr(ApparmorFactCollector, '_fact_ids')
    assert isinstance(ApparmorFactCollector()._fact_ids, set)
    assert hasattr(ApparmorFactCollector, 'collect')
    assert callable(ApparmorFactCollector().collect)

# Generated at 2022-06-23 00:46:52.710034
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmorfc = ApparmorFactCollector()
    assert apparmorfc.collect() == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:46:54.820779
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    x = ApparmorFactCollector()
    assert x
    assert x.name == 'apparmor'

# Generated at 2022-06-23 00:46:55.860748
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ApparmorFactCollector().collect()

# Generated at 2022-06-23 00:46:56.898862
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    ApparmorFactCollector()

# Generated at 2022-06-23 00:47:05.867969
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    """Test that the method collect of class ApparmorFactCollector is working"""
    dummy_collector = ApparmorFactCollector()
    # Make sure that /sys/kernel/security/apparmor does not exist
    if os.path.exists('/sys/kernel/security/apparmor'): 
        os.rmdir('/sys/kernel/security/apparmor')
    assert dummy_collector.collect() == {'apparmor':{'status':'disabled'}}
    # Create a fake /sys/kernel/security/apparmor and check the collect method again
    os.mkdir('/sys/kernel/security/apparmor')
    assert dummy_collector.collect() == {'apparmor':{'status':'enabled'}}


# Generated at 2022-06-23 00:47:08.190661
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    collector = ApparmorFactCollector()
    apparmor_facts = collector.collect()
    assert apparmor_facts['apparmor']['status'] is not None

# Generated at 2022-06-23 00:47:11.080105
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor = ApparmorFactCollector()
    assert apparmor.name == 'apparmor'
    assert set() == apparmor._fact_ids
    assert type(apparmor) is ApparmorFactCollector

# Generated at 2022-06-23 00:47:12.656568
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    a = ApparmorFactCollector()
    assert a.name == 'apparmor'

# Generated at 2022-06-23 00:47:16.965016
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    resolved_object = ApparmorFactCollector()
    result = resolved_object.collect()
    assert isinstance(result, dict)
    assert result == {'apparmor': {'status': 'disabled'}}

# Generated at 2022-06-23 00:47:20.326258
# Unit test for constructor of class ApparmorFactCollector
def test_ApparmorFactCollector():
    apparmor_fact_collector_instance = ApparmorFactCollector()
    assert apparmor_fact_collector_instance.name == 'apparmor'
    assert apparmor_fact_collector_instance._fact_ids == set()


# Generated at 2022-06-23 00:47:24.749244
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    ansible_module = {}
    collected_facts = {}
    apparmor_fact_collector = ApparmorFactCollector()
    facts = apparmor_fact_collector.collect(ansible_module, collected_facts)
    assert facts == {'apparmor': {'status': 'enabled'}}

# Generated at 2022-06-23 00:47:27.600473
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    apparmor_fact_collector = ApparmorFactCollector()
    collected_facts = apparmor_fact_collector.collect()
    assert collected_facts == {'apparmor': {'status': 'enabled'}}


# Generated at 2022-06-23 00:47:31.232732
# Unit test for method collect of class ApparmorFactCollector
def test_ApparmorFactCollector_collect():
    aafc = ApparmorFactCollector()
    test_dict = {}
    aafc.collect(collected_facts=test_dict)
    assert 'apparmor' in test_dict