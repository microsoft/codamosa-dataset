

# Generated at 2022-06-22 08:28:57.167299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import time
    #Constructor for IE
    thestar_ie = TheStarIE(InfoExtractor)
    
    # Assert object is instance of InfoExtractor
    assert(isinstance(thestar_ie, InfoExtractor))
    
    # Assert _VALID_URL is same as the provided regex in constructor
    assert(thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    
    # Since _TEST is a valid URL, assert value of return of regular expression matching is same as display_id
    info = thestar_ie._extract_thestar_info(thestar_ie._TEST['url'])

# Generated at 2022-06-22 08:29:08.429615
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    title = 'Mankind: Why this woman started a men\'s skin care line'
    description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    webpage = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = '4732393888001'
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:10.233188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:17.318685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # get_url() is a private method
    # assert t.get_url() is None
    assert t._real_extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None


# Generated at 2022-06-22 08:29:19.265253
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:29:22.363389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:29:32.245603
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:29:35.642199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:39.330502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:41.399530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST)
    ie.extract()

# Generated at 2022-06-22 08:29:47.197071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._TEST
    ie._VALID_URL

# Generated at 2022-06-22 08:29:52.551739
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._downloader
    assert ie.br_url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.pattern == r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'

# Generated at 2022-06-22 08:29:54.296847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None
    

# Generated at 2022-06-22 08:29:57.573932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("testing TheStarIE constructor")
    thestar_ie = TheStarIE()
    assert(thestar_ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")


# Generated at 2022-06-22 08:30:02.041245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:05.639271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-22 08:30:17.721095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert thestar._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert thestar._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:30:28.900474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    setattr(TheStarIE, '_download_webpage', lambda self, *a, **kw: '<script>mainartBrightcoveVideoId: "13121312";</script>')
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._match_id(ie._TEST['url']) == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie._download_webpage(ie._TEST['url'], ie._match_id(ie._TEST['url'])) == '<script>mainartBrightcoveVideoId: "13121312";</script>'

# Generated at 2022-06-22 08:30:30.629384
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:30:34.584019
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test.test_get('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

if __name__ == '__main__':
	test_TheStarIE()

# Generated at 2022-06-22 08:30:48.465760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.get_ie_key())
    assert ie.IE_NAME == 'thestar.com'
    # Test constructor of class IE_NAME
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Test function extract

# Generated at 2022-06-22 08:30:58.674550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test classname
    TheStarIE = type('TheStarIE', (object,), {'__module__': '__main__'})
    assert TheStarIE.__name__ == 'TheStarIE'
    # test constructor
    TheStarIE()
    TheStarIE(0)
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:59.280424
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:02.679139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('', '')
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:12.369023
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._call_api(
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        '4732393888001')
    assert info == {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'upload_date': '20160201',
        'timestamp': 1454353482,
        'uploader_id': '794267642001',
    }

# Generated at 2022-06-22 08:31:13.160023
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:31:16.772859
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie


# Generated at 2022-06-22 08:31:26.009919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-22 08:31:27.137390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:31:28.268818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(object())

# Generated at 2022-06-22 08:31:50.592686
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._TEST['url'])
    assert ie.url == TheStarIE._TEST['url']
    #assert ie.display_id == TheStarIE._TEST['id']
    assert ie.get_smuggle_request() is None
    #assert ie.get_video_info() is None
    assert ie.get_song_info() is None

# Generated at 2022-06-22 08:31:51.638088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-22 08:32:04.110545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor_obj = InfoExtractor()
    TheStar_info_extractor_obj = TheStarIE(info_extractor_obj)._real_initialize()
    assert TheStar_info_extractor_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStar_url_result = TheStar_info_extractor_obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert TheStar_url_result[0] == 'domain'
    # url_result_list = TheStar_url_result[1]
   

# Generated at 2022-06-22 08:32:09.850999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	theStarIE = TheStarIE().suitable(url)

# Generated at 2022-06-22 08:32:11.868755
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE
    assert ie is not None



# Generated at 2022-06-22 08:32:13.117915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._downloader) is not None

# Generated at 2022-06-22 08:32:13.693638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:14.902625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-22 08:32:17.310362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    assert isinstance(tsi, InfoExtractor)

# Generated at 2022-06-22 08:32:28.219548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-22 08:32:48.927827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    The constructor of class TheStarIE is tested by the integration test
    in test_TheStarIE() in test_suite.py.

    Unit testing this constructor is not needed.
    """
    pass

# Generated at 2022-06-22 08:32:49.985718
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-22 08:32:53.730319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE()
    ie._VALID_URL()
    ie._TEST()
    ie._TEST()
    ie._real_extract()

# Generated at 2022-06-22 08:32:58.343314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Constructor of class TheStarIE
    """
    obj = TheStarIE(InfoExtractor())
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:33:02.548072
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(False)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:33:04.222243
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie) is TheStarIE

# Generated at 2022-06-22 08:33:05.320309
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: remove this
    pass

# Generated at 2022-06-22 08:33:08.228948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Return the constructor args of TheStarIE class
    """
    return TheStarIE

# Generated at 2022-06-22 08:33:12.118799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:13.700306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:54.961611
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert type(thestar_ie) == TheStarIE

# Generated at 2022-06-22 08:34:04.135475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:07.217785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return obj

# Generated at 2022-06-22 08:34:08.199933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-22 08:34:19.689018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:23.469864
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:26.135910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-22 08:34:33.168683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST.get('info_dict')
    assert ie._TEST.get('info_dict').get('id') == '4732393888001'
    assert ie._TEST.get('info_dict').get('ext')

# Generated at 2022-06-22 08:34:44.166738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.display_id = '4732393888001'
    ie.webpage = 'm3u8 download'
    ie.brightcove_id = '794267642001'
    assert ie.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie._URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:45.246302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:36:16.536547
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:27.072877
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:30.826196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:34.462118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:45.563489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    )
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:47.131554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE();
    assert test_obj != None

# Generated at 2022-06-22 08:36:51.181535
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for the correct constructor
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', "Invalid constructor."

# Generated at 2022-06-22 08:36:54.028470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == \
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:55.759083
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t != None


# Generated at 2022-06-22 08:36:57.358449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # create constructor of TheStarIE
    obj = TheStarIE()
    # calling extract_brightcove_url
    obj.extract_brightcove_url()