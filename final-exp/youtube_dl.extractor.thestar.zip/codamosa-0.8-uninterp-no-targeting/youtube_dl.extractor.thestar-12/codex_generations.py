

# Generated at 2022-06-22 08:28:52.360474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:28:53.621030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()

# Generated at 2022-06-22 08:28:56.189161
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    print(obj.TheStarIE)


if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-22 08:28:58.491053
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE
    assert obj.__class__

# Generated at 2022-06-22 08:29:02.214708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""TheStarIE constructor test"""
	url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	TheStarIE(url)

# Generated at 2022-06-22 08:29:06.744286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:29:11.500353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:29:20.937328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:25.206729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.VIDEO_URL == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001")

# Generated at 2022-06-22 08:29:29.452865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    # Test videoID argument in constructor
    TestVideoID = '4732393888001'
    TheStarIE(TestVideoID)
    
    # Test URL argument in constructor
    TestURL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(TestURL)
    

# Generated at 2022-06-22 08:29:40.636256
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Constructor should work when the class is initialized with a URL
    t = TheStarIE('http://www.thestar.com/news/queenspark/2016/04/09/kathleen-wynne-insists-ontarios-financial-ship-righted.html')
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:42.179062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    obj._real_initialize()

# Generated at 2022-06-22 08:29:47.692556
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:29:51.782067
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of class TheStarIE"""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:57.078748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert( ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-22 08:30:08.819910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of class TheStarIE"""
    site = TheStarIE()
    assert site._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:20.733809
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    sample_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:29.215666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print('test_TheStarIE is running...')
	# website url that have video
	with open('test_cases/test_case_2.txt', 'r') as f:
			test_case_1 = f.read().splitlines()
	# example of invalid url
	with open('test_cases/test_case_2.txt', 'r') as f:
			test_case_2 = f.read().splitlines()
	# example of invalid url
	with open('test_cases/test_case_2.txt', 'r') as f:
			test_case_3 = f.read().splitlines()

	ins_TheStarIE = TheStarIE()
	ins_TheStarIE._real_extract(test_case_1)

# Generated at 2022-06-22 08:30:32.045879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

   ie = TheStarIE()
   ie.BRIGHTCOVE_URL_TEMPLATE
   ie.download_webpage


# Generated at 2022-06-22 08:30:34.957939
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:49.161818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the url_result returned from _real_extract.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    result = ie._real_extract(url)
    assert result['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert result['extractor'] == 'BrightcoveNew'
    assert result['id'] == '4732393888001'

# Generated at 2022-06-22 08:30:51.028291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:52.503086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:03.604052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if extracting theStar.com video works
    star = TheStarIE()
    result = star.extract(r'https://www.thestar.com/news/world/2016/03/02/us-student-voted-most-likely-to-become-a-terrorist-sues-his-school.html')
    assert result['title'] == 'US student voted ‘most likely to become a terrorist’ sues his school'
    assert result['id'] == '4742145834001'

    # Test if extracting theStar.com video with a dash in the title works
    # It should not error out with: UnicodeEncodeError: 'ascii' codec can't encode character u'\u2013'
    # It should also return a dictionary of results.
    star = TheStarIE()

# Generated at 2022-06-22 08:31:04.187593
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:07.806117
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:11.556416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:31:15.372411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'brightcove' in ie._downloader.params.get('ydl_postprocessors')
    assert 'm3u8' in ie._downloader.params.get('preferredencoding')

# Generated at 2022-06-22 08:31:20.762764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:22.322827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:46.636084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
# TheStarIE.py
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:53.493855
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "../test_outputs/thestar.mp4")
    assert isinstance(ie, TheStarIE)
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.output_path == "../test_outputs/thestar.mp4"

# Generated at 2022-06-22 08:32:04.945263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:07.058176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie



# Generated at 2022-06-22 08:32:10.842400
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_TheStarIE = TheStarIE.TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-22 08:32:14.695569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:32:16.783803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE == TheStarIE()

# Generated at 2022-06-22 08:32:27.612182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    new_extractor = TheStarIE()
    assert new_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:32.419337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_instance = TheStarIE()
    assert(ie_instance.BRIGHTCOVE_URL_TEMPLATE == 
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:32:37.723711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    #assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId="

# Generated at 2022-06-22 08:33:15.769336
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:33:17.420114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    returns = obj.TheStarIE()
    assert returns


# Generated at 2022-06-22 08:33:27.689906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test 1
    # Test the constructor of class TheStarIE
    url1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url1)

    # Test 2
    # Test the constructor of class TheStarIE
    # when the URL format is incorrect
    url2 = 'http://www.thestar.com/life/2016/02/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    try:
        TheStarIE(url2)
        assert False, 'Should have raised when URL format is incorrect'
    except:
        assert True, 'Should have raised when URL format is incorrect'

# Generated at 2022-06-22 08:33:37.317479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:43.448198
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	i = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:33:49.161305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:33:53.057335
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') != None

# Generated at 2022-06-22 08:33:53.726959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:03.534876
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:14.584351
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:35:47.530624
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:48.917640
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._downloader.params['noplaylist']


# Generated at 2022-06-22 08:35:54.939735
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:36:01.177208
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    my_TheStarIE = TheStarIE()
    assert my_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:09.534115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-22 08:36:12.015857
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie.BRIGHTCOVE_URL_TEMPLATE % 'test'
    assert(obj == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=test')

# Generated at 2022-06-22 08:36:12.533688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:36:19.092848
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ext = TheStarIE()
    # Obtain an instance
    assert isinstance(ext, TheStarIE)
    # Calling the test function
    assert ext._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ext._real_extract(url) != None

# Generated at 2022-06-22 08:36:22.691780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # checks that we can call the class without arguments
    ie()
    # checks that we throw an exception if we don't pass the url
    try:
       ie.url_result()
       assert False
    except ValueError:
       pass

# Generated at 2022-06-22 08:36:26.034018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    theStarIE = TheStarIE()
    assert isinstance(theStarIE, InfoExtractor)

# Unit test to check for regex of '_VALID_URL'

# Generated at 2022-06-22 08:38:00.261339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    from .test_BrightcoveNew import (
        BrightcoveNewIE, BrightcoveNewTestCase)
    ie = TheStarIE()
    ie_test = BrightcoveNewIE(ie.BRIGHTCOVE_URL_TEMPLATE, BrightcoveNewTestCase)
    assert ie.__class__ == ie_test.__class__

# Generated at 2022-06-22 08:38:08.961657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:38:15.901557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    info = TheStarIE()._resolve_url(video_url)
    assert info['id'] == '4732393888001'
    assert info['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-22 08:38:26.790242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    Test_TheStarIE = TheStarIE()
    assert Test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:38:27.908277
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-22 08:38:30.940899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test if the constructor of TheStarIE works.
    """
    # Test if the constructor of class TheStarIE works without fail
    ie = TheStarIE()
    test_TheStarIE.ie = ie
    assert ie



# Generated at 2022-06-22 08:38:34.058203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:38:36.646661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Construct an instance of TheStarIE and call test_video_id()
    """
    ie = TheStarIE(None)
    ie.test_video_id(ie._TEST)
    

# Generated at 2022-06-22 08:38:37.345676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:38:45.618752
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_request_factory(lambda *args, **kwargs: None)
    ie.ie._build_request = lambda *args, **kwargs: None
    ie.ie.set_result_fetcher(lambda *args, **kwargs: None)
    assert ie.ie._BRIGHTCOVE_URL_TEMPLATE == ie.BRIGHTCOVE_URL_TEMPLATE