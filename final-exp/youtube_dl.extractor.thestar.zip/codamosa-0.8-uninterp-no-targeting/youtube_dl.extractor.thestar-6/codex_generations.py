

# Generated at 2022-06-22 08:28:52.696429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.extract(url)

# Generated at 2022-06-22 08:28:53.623385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    return None

# Generated at 2022-06-22 08:29:05.829916
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' in globals()
    assert 'InfoExtractor' in globals()
    global ie
    ie = TheStarIE()

# Unit tests for BrightcoveNew IE
#
# TODO: remove this in favor of the inheritance structure

# ref: http://en.wikipedia.org/wiki/YouTube#Quality_and_codecs, Nov. 01, 2014
YOUTUBE_VIDEO_FORMAT = 18
YOUTUBE_VIDEO_ENCODING = 'MP4'
YOUTUBE_VIDEO_EXTENSION = 'mp4'
YOUTUBE_VIDEO_RESOLUTION = '360p'
YOUTUBE_VIDEO_CODEC = 'H.264'
YOUTUBE_AUDIO_CODEC = 'AAC'

# Generated at 2022-06-22 08:29:11.895342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('../../test/data/test_thestar.html')
    ie.extract()
    assert ie.player_key == '2jNN7L8EtsNkobEC3XjHVudkKa63_kyb_gEX3p6qe'
    assert ie.account_id == '794267642001'

# Generated at 2022-06-22 08:29:12.469684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-22 08:29:15.735811
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:19.181292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    instance = ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:29:23.644170
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:27.074317
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-22 08:29:31.835108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:29:38.060617
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # assert that TheStarIE can be instatiated without errors
    TheStarIE()



# Generated at 2022-06-22 08:29:40.210445
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/food_wine/2015/09/19/indian-cooking-without-fear-recipes.html')

# Generated at 2022-06-22 08:29:41.341943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:29:42.441965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()

# Generated at 2022-06-22 08:29:54.231408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	assert ie.BRIGHTCOVE_EMBED_PREFIX == None
	assert ie.BRIGHTCOVE_ACCOUNTS == None
	assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:54.851425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-22 08:30:02.318347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    url = ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:05.484084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:07.366705
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')

# Generated at 2022-06-22 08:30:08.869587
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE, InfoExtractor)


# Generated at 2022-06-22 08:30:21.817464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:28.812494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'
    t.site_api_key = '794267642001'
    t.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:33.693949
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Will be false unless an exception is raised
    return True

# Generated at 2022-06-22 08:30:36.984737
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	try:
		TheStarIE()
	except:
		print("TheStarIE constructor failed")
		return False
	return True


# Generated at 2022-06-22 08:30:41.282150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	TheStarIE(url)

# Generated at 2022-06-22 08:30:45.457474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/news/canada/2016/02/20/why-these-indigenous-protesters-are-making-a-big-deal-over-treaties.html'
    obj = TheStarIE(url)
    print(obj)

# Unit test
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:30:48.069513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:49.557515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE.test()

# Generated at 2022-06-22 08:30:59.581830
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    object = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % TheStarIE._TEST['info_dict']['id'])
    assert object.suitable(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % TheStarIE._TEST['info_dict']['id']) == True
    assert object.IE_NAME == 'BrightcoveNew'
    assert object._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:09.889543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of class TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    # Test URL matching of class TheStarIE
    assert ie._match_id(url) == '4732393888001'
    # Test extraction of class TheStarIE
    info = ie.extract(url)
    assert info['id'] == '4732393888001'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-22 08:31:25.113991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("test class TheStarIE")

# test_TheStarIE()

# Generated at 2022-06-22 08:31:34.266351
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_downloader import FakeYDL
    from .extractor import YoutubeIE
    ydl = FakeYDL()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(ydl, {'logger': ydl})
    ie.url = url
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._T

# Generated at 2022-06-22 08:31:37.611326
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        ,{'skip_download':True})

# Generated at 2022-06-22 08:31:43.749259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # covers all cases: video, video with ad, live tv
    url = 'http://www.thestar.com/entertainment/television/2016/09/20/big-brother-canada-winner-promises-special-journey-in-season-5.html'
    thestar = TheStarIE()
    assert thestar.suitable(url)
    result = thestar._real_extract(url)
    assert result['url']
    assert result['id']
    assert result['ext']

# Generated at 2022-06-22 08:31:48.781486
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    youtube_ie = TheStarIE()
    assert youtube_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:50.294409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:54.500704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:56.715207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    try:
        ie.TheStarIE();
    except Exception:
        pass;

# Generated at 2022-06-22 08:32:02.643255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_dict = {
        'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
    }
    url = TheStarIE()._build_brighcove_url(test_dict)

# Generated at 2022-06-22 08:32:04.477680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    TheStarIE = __builtins__.__dict__.get('TheStarIE',None)
    try:
        ie_instance = TheStarIE()
        assert(type(ie_instance) == TheStarIE)
    except:
        print('type(ie_instance) = {}'.format(type(ie_instance)))
        raise


# Generated at 2022-06-22 08:32:35.300569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()   # Just create class object

# Generated at 2022-06-22 08:32:36.684862
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:32:37.246314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:44.240733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert t._VALID_URL == 'http://www.thestar.com/(?:[^/]+/)*(?P<id>.+)\\.html'
test_TheStarIE()

# Generated at 2022-06-22 08:32:46.546568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().download_media(TheStarIE()._TEST['url'])

# Generated at 2022-06-22 08:32:48.873917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Running test_TheStarIE() ...")
    TheStarIE()


# Generated at 2022-06-22 08:32:49.520680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:00.304437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.IE_NAME == 'thestar'
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:10.912263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:22.271822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test keys present in instance of TheStarIE
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__module__ == 'youtube_dl.extractor.thestar'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:03.349280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestarIE = TheStarIE()
    thestarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    thestarIE._download_webpage = lambda x,y : ''
    thestarIE._search_regex = (lambda x,y,z:x)
    thestarIE._real_extract(url)

# Generated at 2022-06-22 08:34:14.534913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert (TheStarIE()._TEST['url'] == TheStarIE._TEST['url'])
    TEST = TheStarIE()._TEST
    assert (TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert (TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')
    INFO_DICT = TheStarIE()._TEST['info_dict']
    assert (INFO_DICT['id'] == '4732393888001')

# Generated at 2022-06-22 08:34:17.588026
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2017/05/24/mindfulness-is-going-mainstream-so-now-what.html')

# Generated at 2022-06-22 08:34:28.622349
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for the constructor of class TheStarIE."""
    obj_test = TheStarIE()
    assert obj_test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj_test._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj_test._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:34:37.051214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert hasattr(ie, 'IE_NAME')
    assert ie.IE_NAME == 'thestar'
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-22 08:34:37.962142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:42.388973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:43.633643
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate an instance of the class
    ie = TheStarIE()


# Generated at 2022-06-22 08:34:48.319347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:50.583867
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._search_regex()

# Generated at 2022-06-22 08:36:10.067555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'

# Generated at 2022-06-22 08:36:19.666301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #test for a normal video
    TheStarIE(None)._test_extract_info_dict(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'BrightcoveNew')
    #test for a video with no brightcove ID
    TheStarIE(None)._test_extract_info_dict(
        'http://www.thestar.com/life/2015/12/14/i-have-a-new-video-of-my-cat-playing-with-a-laser-pointer.html',
        None, None)

# Generated at 2022-06-22 08:36:24.188219
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert 'theStar' in theStarIE._downloader.IE_NAME

# Generated at 2022-06-22 08:36:28.467071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Assert that the object of class TheStarIE is constructed without any errors
	assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-22 08:36:39.280064
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:36:42.439164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE.extractors_by_id['TheStar'], TheStarIE._VALID_URL, TheStarIE._TEST)

# Generated at 2022-06-22 08:36:42.959039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:36:45.237721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for constructor of class TheStarIE"""
    return TheStarIE()

# Generated at 2022-06-22 08:36:49.367944
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with using TheStarIE constructor
    test_instance = TheStarIE()
    # Test with using TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    test_instance_2 = test_instance.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:36:53.272323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE('TheStarIE', ['http://www.thestar.com/foo.html'])
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'