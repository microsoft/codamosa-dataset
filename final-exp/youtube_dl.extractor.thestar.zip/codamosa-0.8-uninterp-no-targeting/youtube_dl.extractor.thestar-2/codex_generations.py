

# Generated at 2022-06-22 08:28:53.086822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage('', '', {})
    ie._match_id('', '')
    ie._search_regex('', '', '')
    ie.url_result('', '')
    pass

# Generated at 2022-06-22 08:28:57.735633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._download_webpage()
    ie._search_regex()



# Generated at 2022-06-22 08:29:03.935691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    actual = ie.extract(url)
    expected = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }
    assert actual == expected

# Generated at 2022-06-22 08:29:08.180994
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # we check if it creates an object of the right class
    assert ie.__class__ == TheStarIE


# Generated at 2022-06-22 08:29:15.258715
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE().from_id('Mankind: Why this woman started a men\'s skin care line')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-22 08:29:20.631464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    details = {i for i in dir(TheStarIE) if not i.startswith('_')}
    assert details == {
        'BRIGHTCOVE_URL_TEMPLATE',
        '_TEST',
        '_VALID_URL',
        '_download_webpage',
        '_match_id',
        '_real_extract',
        '_search_regex',
        'url_result',
    }

# Generated at 2022-06-22 08:29:28.951036
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def getattr_mock(attr_name):
        if attr_name == '_VALID_URL':
            return TheStarIE._VALID_URL
        elif attr_name == '_TEST':
            return TheStarIE._TEST
        else:
            raise AssertionError('getattr_mock needs to be updated.')

    # Test that class constructor raises TypeError if `_VALID_URL` is not defined
    attrs_to_remove = ['_VALID_URL']
    for attr in attrs_to_remove:
        # Make a copy of TheStarIE attributes
        original_thestarie_attrs = TheStarIE.__dict__.copy()
        # Remove attribute `attr` from TheStarIE
        delattr(TheStarIE, attr)
        # Try to instantiate TheStar

# Generated at 2022-06-22 08:29:32.811635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("TheStarIE", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:29:37.915606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    see https://github.com/ytdl-org/youtube-dl/issues/5059
    """
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:29:50.315000
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test for 'www.thestar.com' url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    # test for 'thestar.com' url
    url = 'http://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-22 08:30:00.909282
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:04.130868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_under_test = TheStarIE

# Generated at 2022-06-22 08:30:11.812433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r = TheStarIE()
    assert r.__class__.__name__ is 'TheStarIE'
    assert r._VALID_URL is 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert r.BRIGHTCOVE_URL_TEMPLATE is 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return r


# Generated at 2022-06-22 08:30:16.838583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == TheStarIE._VALID_URL
    assert instance._TEST == TheStarIE._TEST
    assert instance.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-22 08:30:26.060062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for the case that TheStarIE is instantiated from the main
    # function (ie. __name__ == '__main__')
    if __name__ == '__main__':
        # mock the options and args
        class Options():
            def __init__(self):
                self.extract_flat = True
                self.usenetrc = False
        class Args():
            def __init__(self):
                self.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        # mock the params of TheStarIE
        TheStarIE._downloader = None
        TheStarIE.params = {}
        # create an instance of TheStarIE

# Generated at 2022-06-22 08:30:29.981376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert theStarIE._VALID_URL

# Generated at 2022-06-22 08:30:41.242989
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:30:43.936427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:30:50.798856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test initialization"""
    ie = TheStarIE()
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['info_dict']['id'] == '4732393888001'
    assert ie._TEST['info_dict']['uploader_id'] == '794267642001'
    assert ie._TEST['info_dict']['timestamp'] == 1454353482
    assert ie._TEST['info_dict']['title'] == "Mankind: Why this woman started a men's skin care line"

# Generated at 2022-06-22 08:30:53.750310
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:58.156326
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:03.524555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:31:07.354162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:10.689234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(url)

# Generated at 2022-06-22 08:31:14.115941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:23.043001
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL, r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:27.991184
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    try:
        theStarIE._real_extract(url)
    except TypeError:
        pass

# Generated at 2022-06-22 08:31:30.822281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:31:33.781591
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:40.806575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:49.923474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE();
    assert isinstance(star, TheStarIE)

# Generated at 2022-06-22 08:31:54.185695
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    vid = TheStarIE()
    vid._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:05.376708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert 'TheStar' == test_TheStarIE._VALID_URL
    assert 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' == test_TheStarIE._TEST
    assert 'BRIGHTCOVE_URL_TEMPLATE' == test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' == test_TheStarIE._real_extract

# Generated at 2022-06-22 08:32:14.811706
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_dict = {'id': '4732393888001',
                 'ext': 'mp4',
                 'title': 'Mankind: Why this woman started a men\'s skin care line',
                 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
                 'uploader_id': '794267642001',
                 'timestamp': 1454353482,
                 'upload_date': '20160201'
                 }
    assert TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').__dict__ == info_dict

# Generated at 2022-06-22 08:32:26.223975
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_obj = TheStarIE()

	assert test_obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:29.170682
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = InfoExtractor(TheStarIE.ie_key())
    info_extractor.extract(TheStarIE._TEST['url'])

# Generated at 2022-06-22 08:32:37.705882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_constructor = getattr(TheStarIE, 'suitable')
    assert class_constructor('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert class_constructor('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is True
    assert class_constructor('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is None

# Generated at 2022-06-22 08:32:49.003164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import InfoExtractor
    from .common import KNOWN_EXTENSIONS
    from .common import url_basename
    from .common import url_re

    assert InfoExtractor.is_suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert InfoExtractor.is_suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:50.069772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:58.578369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test case for verified TheStarIE._VALID_URL
    test_c = TheStarIE()
    assert test_c.suitable(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test case for non verified TheStarIE._VALID_URL
    assert not test_c.suitable(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:33:15.601595
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing for creating a TheStarIE object and testing its various attributes
    instance = TheStarIE()
    assert isinstance(instance, TheStarIE)
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

test_TheStarIE()

# Generated at 2022-06-22 08:33:24.477592
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def _assert_valid_url(url, regex, videoId):
        import re
        match = re.match(regex, url)

        assert match
        assert (match.group('id') is videoId)

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    regex = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    videoId = '4732393888001'

    _assert_valid_url(url, regex, videoId)

# Generated at 2022-06-22 08:33:29.342486
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.extract(url)

# Generated at 2022-06-22 08:33:35.414743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    print(TheStarIE._download_webpage(url, TheStarIE._match_id(url)))
    # print(TheStarIE._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id'))

# Generated at 2022-06-22 08:33:36.959293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    # For now, no testing needed

# Test cases for TheStarIE

# Generated at 2022-06-22 08:33:38.265295
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie != None

# Generated at 2022-06-22 08:33:38.839316
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:39.927845
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:33:46.119476
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	invariant = TheStarIE._VALID_URL
	assert invariant == 'https?://(?:www.)?thestar.com/(?:[^/]+/)*(?P<id>.+).html'
	assert invariant == 'https?://(?:www.)?thestar.com/(?:[^/]+/)*(?P<id>.+).html'

# Generated at 2022-06-22 08:33:47.102897
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Run constructor of TheStarIE
    TheStarIE()

# Generated at 2022-06-22 08:34:07.583346
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.test_test(test_TheStarIE())

# Generated at 2022-06-22 08:34:14.162373
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('')
    assert ie.url_result == ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._match_id == ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._search_regex == ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._download_webpage == ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-22 08:34:25.379564
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "Mankind", "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393222001")

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:27.430053
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u = TheStarIE() 
    assert u != None and isinstance(u, InfoExtractor)

# Generated at 2022-06-22 08:34:31.217071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage = lambda x: 'abc'
    ie._search_regex = lambda x, y, z: '123'
    ie._match_id = lambda x: 'abc'
    ie._real_extract(ie._TEST['url'], ie._TEST)

# Generated at 2022-06-22 08:34:42.297520
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    test_webpage = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    brighcove_id = '4732393888001'
    the_stare_ie = TheStarIE()

# Generated at 2022-06-22 08:34:46.735147
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:55.786247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.validate_url(url)
    assert ie.extract_id(url) == '4732393888001'

# Generated at 2022-06-22 08:35:03.250302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        video_id = '4732393888001'
        # test BrightcoveNew constructor
        e = TheStarIE()
        url_real = e.BRIGHTCOVE_URL_TEMPLATE % video_id
        url_virtual = e.url_result(url_real, 'BrightcoveNew', video_id)
        assert_raises(NotImplementedError, url_virtual.getbestvideo)
        assert_raises(NotImplementedError, url_virtual.getbestaudio)
        return True
    except Exception:
        return False


# Generated at 2022-06-22 08:35:12.664456
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:35:59.395902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:36:08.699066
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_class = TheStarIE()
    assert test_class._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test_class._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert test_class._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert test_class._TEST['params']['skip_download'] == True

# Generated at 2022-06-22 08:36:17.825691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)

    # Verify that the BRIGHTCOVE_URL_TEMPLATE is correct
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == expected

    # Verify that the _real_extract() function works for the first web page
    # in the TEST dictionary.
    test = ie._TEST
    expected = test['info_dict']['id']
    # Due to the use of YouTubeIE._download_webpage(), the value of info_dict[id]
    # cannot be checked directly.  It is expected to be a string that is composed
    # of digits.
    assert expected.isdigit()
    actual = ie._real_ext

# Generated at 2022-06-22 08:36:20.223152
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:31.585327
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    extractor._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    extractor._search_regex('mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', '', 'brightcove id')
    extractor.url_result(extractor.BRIGHTCOVE_URL_TEMPLATE % ('4732393888001'), 'BrightcoveNew', '4732393888001')

   

# Generated at 2022-06-22 08:36:37.905368
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    expected_value = TheStarIE._TEST['info_dict']
    expected_value.pop('upload_date')
    actual_value = ie.ie_key().get('info_dict')
    actual_value.pop('upload_date')
    assert expected_value == actual_value

# Generated at 2022-06-22 08:36:41.782858
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._real_extract
    ie._VALID_URL

# Generated at 2022-06-22 08:36:43.526314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie == TheStarIE(), "TheStarIE instance is not valid"


# Generated at 2022-06-22 08:36:53.296942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie.title == "Mankind: Why this woman started a men's skin care line"
    assert ie.ext == "mp4"
    assert ie.id == "4732393888001"

# Generated at 2022-06-22 08:36:54.584092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie


# Generated at 2022-06-22 08:38:40.283123
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:38:47.444234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_suite_class = TheStarIE.test_suite_class
    test_suite_class.__name__ = 'TestTheStarIE'

    class TestTheStarIE(test_suite_class):
        def test_suite(self):
            self.run_list_test(TheStarIE.ie_key())
            self.run_list_test(TheStarIE.ie_key(), test_data=False)

    test_TheStarIE = TestTheStarIE()
    test_TheStarIE.test_suite()