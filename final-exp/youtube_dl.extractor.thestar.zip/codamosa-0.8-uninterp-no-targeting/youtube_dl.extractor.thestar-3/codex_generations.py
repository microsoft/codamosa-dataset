

# Generated at 2022-06-22 08:28:57.632955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.og_search_title == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-22 08:29:00.966867
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:29:01.972874
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-22 08:29:07.515999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Date: 2016-02-06 19:40
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.get_brightcove_id() == '4732393888001'

# Generated at 2022-06-22 08:29:11.548330
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:29:12.817859
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' in globals()



# Generated at 2022-06-22 08:29:14.849018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE('thestar.com', {'thestar.com': 'thestar.com'})
    assert IE


# Generated at 2022-06-22 08:29:15.517330
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:16.128493
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-22 08:29:18.209642
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Object of class TheStarIE
    obj_test = TheStarIE()
    assert obj_test is not None


# Generated at 2022-06-22 08:29:27.319577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None


# Generated at 2022-06-22 08:29:38.178771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:29:45.285051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__name__ == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:49.519140
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(ie)

# Generated at 2022-06-22 08:29:59.881321
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    import os
    import sys
    import imp
    try:
        imp.find_module("testinfra")
        imp.find_module("testinfra.modules")
        imp.find_module("testinfra.backend")
    except ImportError:
        print("testinfra is not installed")
        sys.exit(1)

    from testinfra.backend import local as testinfra_local
    from testinfra.module import Command
    from testinfra.modules.base import Command

    host = testinfra_local.LocalHost()
    cmd = host.run("python3 -c 'import sys, imp; sys.path.append(\"" + os.getcwd() + "\"); imp.find_module(\"youtube_dl\"); from tests import test_TheStarIE; test_TheStarIE()'")

# Generated at 2022-06-22 08:30:03.168978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        obj = TheStarIE()
    except Exception as e:
        print("Exception thrown: " + str(e))
        return False
    else:
        return True


# Generated at 2022-06-22 08:30:10.394520
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for TheStarIE
    thestar = TheStarIE()

    # Unit test to check if function _real_extract works
    result = thestar._real_extract(test_TheStarIE._TEST['url'])
    assert('brightcove' in result['url'])
    assert(test_TheStarIE._TEST['info_dict']['id'] == result['id'])
    assert(test_TheStarIE._TEST['info_dict']['title'] == result['title'])

# Generated at 2022-06-22 08:30:17.922803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Use video page as URL
    video_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(TheStarIE.__name__)._real_initialize()
    TheStarIE(TheStarIE.__name__)._real_extract(video_url)


# Generated at 2022-06-22 08:30:23.408970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:26.770397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:41.975128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = ie.get_display_id(url)
    webpage = ie.download_webpage(url, display_id)
    brightcove_id = ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
    brighcove_url = ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id
    bc_url = ie.url_result(brighcove_url, 'BrightcoveNew', brightcove_id)
   

# Generated at 2022-06-22 08:30:49.052553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert e.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert e.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:51.014374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:53.239621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie)


# Generated at 2022-06-22 08:30:57.608233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:02.286456
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:31:11.676310
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

# Generated at 2022-06-22 08:31:15.477795
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:20.767181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html';
    TheStarIE()._real_extract(url)

# Generated at 2022-06-22 08:31:25.305175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:33.986691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   t = TheStarIE()
   assert t is not None

# Generated at 2022-06-22 08:31:34.761511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructorTest(TheStarIE)

# Generated at 2022-06-22 08:31:36.135216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	x = TheStarIE()

# Generated at 2022-06-22 08:31:37.064721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:31:46.495413
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Given a test, runs it and returns the value of the test."""
    # Constructor of info extractor

# Generated at 2022-06-22 08:31:47.512620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-22 08:31:52.557097
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie._real_extract(TheStarIE._TEST['url']) == TheStarIE._TEST['info_dict']

# Generated at 2022-06-22 08:31:59.854020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    

# Generated at 2022-06-22 08:32:05.117335
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create a test instance of class TheStarIE
    thestar_ie = TheStarIE()

    # Capture the output of __str__ of the instance of class TheStarIE
    name = thestar_ie.__str__()

    print(name)
    # Test if output of __str__ is "TheStarIE"
    assert name == "TheStarIE"

# Generated at 2022-06-22 08:32:08.231886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('url', 'brightcove_id', 'display_id', 'ext', 'title', 'description', 'uploader_id', 'timestamp')

# Generated at 2022-06-22 08:32:21.055423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # create object of class TheStarIE
    object_of_TheStarIE = TheStarIE()
    # pass the url to extract function
    object_of_TheStarIE._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:32:24.613853
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor without arguments
    o = TheStarIE()
    assert o.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:28.486129
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:32.771713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    ie = TheStarIE(params={})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:36.590402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	arguments = {'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'name': 'TheStarIE'}
	TheStarIE(**arguments)

# Generated at 2022-06-22 08:32:39.531935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('mmm', 'www', 'xyz')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-22 08:32:49.527773
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test 1: function name is correct
    assert TheStarIE.__name__ == "TheStarIE"

    # Test 2: TheStarIE accepts a url
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    try:
        TheStarIE(url)
    except:
        assert False

    # Test 3: TheStarIE extracts the url correctly
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    try:
        video = TheStarIE(url)
        video.extract()
    except:
        assert False

# Generated at 2022-06-22 08:32:50.573295
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-22 08:33:01.743947
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(unit_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(unit_test._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-22 08:33:03.342996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.br is None

# Generated at 2022-06-22 08:33:25.376557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        assert False

# Test for abstract method parse_info of class TheStarIE

# Generated at 2022-06-22 08:33:31.784181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:35.557978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert(TheStarIE()._VALID_URL is not None)
	assert(TheStarIE()._TEST is not None)
	assert(TheStarIE().BRIGHTCOVE_URL_TEMPLATE is not None)
	assert(TheStarIE()._real_extract is not None)

# Generated at 2022-06-22 08:33:38.432513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    TheStarIE = TheStarIE()

# Generated at 2022-06-22 08:33:42.203725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.FALLBACK_URL_TEMPLATE
    ie = TheStarIE.ie_key()== "thestar"

# Generated at 2022-06-22 08:33:53.381057
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Example of thestar.com URL
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    # Before accessing the variable, you should initalize the variable first.
    ie.initialize()
    assert ie.valid_url()
    assert ie.display_id() == '4732393888001'
    assert ie.title() == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description() == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.thumbnail() is None

# Generated at 2022-06-22 08:33:56.431526
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-22 08:33:57.072429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:00.317094
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:08.211905
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:59.126659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check basic plugin info.
    info = TheStarIE()._get_plugin_info()
    assert info['id'] == 'thestar'
    assert info['extractor'] == 'TheStarIE'
    assert info['title'] == 'thestar.com'
    assert info['description'] == 'thestar.com video downloads'
    assert info['thumbnail'] == 'https://bcsecure01-a.akamaihd.net/6/1642104304/201502/3174/1642104304_3300380098001_Mankind.jpg?pubId=1642104304'
    assert info['description'] == 'thestar.com video downloads'
    assert info['uploader'] == 'thestar.com'
    assert info['license'] == 'Standard YouTube license'
    assert info['duration'] is None

# Generated at 2022-06-22 08:35:00.797116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_starIE = TheStarIE()
    assert the_starIE.brightcove_id == '794267642001'

# Generated at 2022-06-22 08:35:07.748303
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:35:17.758080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:35:20.962200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    arg_dict = {}
    for arg in ['_VALID_URL', '_TEST']:
        try:
            arg_dict[arg] = globals()[arg]
        except:
            pass
    TheStarIE(**arg_dict)

# Generated at 2022-06-22 08:35:25.388697
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:35:28.682271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    # Test for _VALID_URL
    valid_url = obj._VALID_URL
    # Test for _TEST
    test = obj._TEST


# Generated at 2022-06-22 08:35:32.680378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:43.621679
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE();
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "TheStarIE.BRIGHTCOVE_URL_TEMPLATE should be 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', instead of '%s'" % the_star_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:35:47.141328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return x

# Generated at 2022-06-22 08:37:13.519518
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_object = TheStarIE()

# Generated at 2022-06-22 08:37:15.284361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST['url'])


# Generated at 2022-06-22 08:37:17.155613
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Unit test for constructor
	assert TheStarIE

# Generated at 2022-06-22 08:37:17.784282
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:37:21.121245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    u = 'http://www.thestar.com/life/'
    ie.url_result(u, "TheStarIE")

# Generated at 2022-06-22 08:37:31.001973
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:37:34.989357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:37:38.324563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    info = obj._real_extract(URL)

# Generated at 2022-06-22 08:37:42.015549
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:37:46.401200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test the constructor of class TheStarIE
    # expected: True
    assert getattr(TheStarIE, '_VALID_URL', True) == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', True