

# Generated at 2022-06-22 08:28:53.367827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-22 08:28:54.701751
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:29:05.390894
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    m_TheStarIE = TheStarIE()
    assert m_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert m_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
    m_TheStarIE._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", '4732393888001')

# Generated at 2022-06-22 08:29:13.985261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    v = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert v._match_id(v.url) == '4732393888001'
    assert v._match_id('http://www.thestar.com/life/2016/01/21/how-did-you-get-in-here-how-lazy-security-helps-get-criminals-into-canadian-homes.html') == '4729905469001'

# Generated at 2022-06-22 08:29:15.365717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.test_suite()

# Generated at 2022-06-22 08:29:18.893592
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    id = '4732393888001'
    TheStarIE(url, id)

# Generated at 2022-06-22 08:29:27.586318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:30.859606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert hasattr(the_star_ie, 'BRIGHTCOVE_URL_TEMPLATE')

# Generated at 2022-06-22 08:29:33.673092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Hi, I don't think this url is right.
    url = 'http://www.thestar.com/sports/golf/2016/03/14/the-masters-us-television-schedule.html'
    x = TheStarIE()
    x.BRIGHTCOVE_URL_TEMPLATE = 'http://nonexistent/%s'
    assert(x._real_extract(url) == None)

# Generated at 2022-06-22 08:29:39.650689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

   url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
   obj = TheStarIE()
   obj.url = url
   assert obj.url == url
   assert obj.non_zero_length == True

# Generated at 2022-06-22 08:29:47.097254
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    theStar._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:29:50.365100
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:53.101166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie.ie_key()
    assert obj == 'TheStar', 'expected: TheStar, actual: %s' % obj

# Generated at 2022-06-22 08:29:57.212508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.VALID_URL = TheStarIE._VALID_URL
    ie.TEST = TheStarIE._TEST

    # Calling _real_extract of TheStarIE
    ie._real_extract(ie.TEST['url'])

# Generated at 2022-06-22 08:30:01.984849
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test initialization of _video_id
    tempinfo = TheStarIE()._real_extract(TheStarIE._TEST['url'])
    assert(tempinfo['title'] == TheStarIE._TEST['info_dict']['title'])

# Generated at 2022-06-22 08:30:06.000223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    t = TheStarIE()
    t.extract(url)

# Generated at 2022-06-22 08:30:10.346211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Url of TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Constructor of TheStarIE
    TheStarIE(url)

# Generated at 2022-06-22 08:30:13.598035
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:30:14.944137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:30:18.216196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE, '_VALID_URL') and hasattr(TheStarIE, '_TEST') and hasattr(TheStarIE, 'BRIGHTCOVE_URL_TEMPLATE')

# Generated at 2022-06-22 08:30:30.820470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('bookmark://http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:30:31.687070
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE has no constructor test for now
    pass

# Generated at 2022-06-22 08:30:34.920255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    

# Generated at 2022-06-22 08:30:37.210203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:38.713796
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-22 08:30:45.238775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == thestar_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:30:46.101648
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-22 08:30:52.144359
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.thestar.com == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-22 08:31:03.459552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    temp_val_url = TheStarIE._VALID_URL
    TheStarIE._VALID_URL = 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
    TheStarIE_test = TheStarIE()
    assert TheStarIE_test._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE_test._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554' 
    assert TheStarIE_test._TEST['info_dict']['id'] == '4732393888001'
   

# Generated at 2022-06-22 08:31:11.440639
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from unittest import TestCase

    class TheStarIETest(TestCase):

        def test_constructor(self):
            thestarIE = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
            # Check the rest of TheStarIE instance variables here

    # Execute the test
    test = TheStarIETest()
    test.test_constructor()
    print("TheStarIE instance variables: ", vars(thestarIE))

# Generated at 2022-06-22 08:31:24.075447
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor and retrieve video info with YoutubeIE
    ie = TheStarIE()
    info_dict = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Check whether the video succeeded in downloading
    assert info_dict['id'] == '4732393888001'
    assert info_dict['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info_dict['uploader_id'] == '794267642001'

# Generated at 2022-06-22 08:31:29.640507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:32.456368
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:34.963051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # the following line is just to test that class constructor is called
    ie = TheStarIE('http://example.com/')
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-22 08:31:36.618667
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  instance = TheStarIE()

# Generated at 2022-06-22 08:31:39.437304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	class_ = TheStarIE

	# check if the class is an instance of InfoExtractor
	assert isinstance(class_, InfoExtractor)


# Generated at 2022-06-22 08:31:42.679687
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:48.297702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:31:51.142397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:03.548656
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.display_id = '4732393888001'
    assert ie.is_valid_url(ie.url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.display_id == '4732393888001'
   

# Generated at 2022-06-22 08:32:23.500855
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    except:
        return False;
    return True;

if __name__ == '__main__':
    test_TheStarIE();

# Generated at 2022-06-22 08:32:28.867468
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	# theStarIE = TheStarIE()
	# theStarIE._real_extract(test_url)
	assert True

# Generated at 2022-06-22 08:32:29.877105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert IE.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-22 08:32:33.519483
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:32:34.821801
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE

# Generated at 2022-06-22 08:32:42.313762
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    res = {
        u'id': '4732393888001',
        u'title': u"Mankind: Why this woman started a men's skin care line",
        u'description': u'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        u'uploader_id': '794267642001',
        u'timestamp': 1454353482,
        u'upload_date': u'20160201',
        u'ext': u'mp4',
        u'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        u'ie_key': u'BrightcoveNew',
        u'_type': u'url_transparent',
    }


# Generated at 2022-06-22 08:32:46.932579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # only for testing the class constructor
    video = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:32:50.837832
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:54.513016
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:00.503475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-22 08:33:35.686183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:40.925595
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor)._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE(InfoExtractor)._TEST == TheStarIE._TEST
    assert TheStarIE(InfoExtractor).BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE(InfoExtractor)._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:33:44.239810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:47.866732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE.TheStarIE = TheStarIE()
    test_TheStarIE.TheStarIE._downloader = None
    test_TheStarIE.TheStarIE.url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_TheStarIE.TheStarIE._real_extract()


# Generated at 2022-06-22 08:33:52.058390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    StarIE = TheStarIE()
    result = StarIE.extract(url)
    assert result is not None

# Generated at 2022-06-22 08:33:56.600730
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:33:59.253509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    test the constructor of class TheStarIE
    """

    # invalid parameters
    TheStarIE(None, None)

# Generated at 2022-06-22 08:34:07.734896
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    custom_TheStarIE = TheStarIE(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    )

    expected_build_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert custom_TheStarIE.BRIGHTCOVE_URL_TEMPLATE % custom_TheStarIE._match_id('4732393888001') == expected_build_result
    assert custom_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert custom_TheStarIE

# Generated at 2022-06-22 08:34:12.189478
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # TheStarIE._VALID_URL matches the passed URL in the assert
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:15.790494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert type(x) == TheStarIE

# Generated at 2022-06-22 08:35:37.666898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE()
    assert unit_test._VALID_URL is not None, 'Url not exist in TheStarIE'
    return unit_test._VALID_URL

# Generated at 2022-06-22 08:35:43.670269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:35:52.519900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test the constructor of class TheStarIE.
    '''
    test_case = TheStarIE()
    assert test_case._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:58.460113
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r = TheStarIE()
    assert r.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert r.extract('http://www.thestar.com/news/gta/2016/02/10/man-who-put-a-fatal-stake-through-the-heart-of-vampires-dies.html')

# Generated at 2022-06-22 08:36:00.103310
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE is not None

# Generated at 2022-06-22 08:36:01.506898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert type(TheStarIE) == type

# Generated at 2022-06-22 08:36:07.101464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(TheStarIE.IE_NAME, TheStarIE.IE_DESC).ie_key() == 'TheStar'
	assert TheStarIE(TheStarIE.IE_NAME, TheStarIE.IE_DESC).ie_key() == 'TheStar'
	assert TheStarIE(TheStarIE.IE_NAME, TheStarIE.IE_DESC).ie_key() == 'TheStar'

# Generated at 2022-06-22 08:36:17.460934
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for the brightcove_url_template
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test for the TheStarIE
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:20.595606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE({'url': 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'})


# Generated at 2022-06-22 08:36:21.173464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()