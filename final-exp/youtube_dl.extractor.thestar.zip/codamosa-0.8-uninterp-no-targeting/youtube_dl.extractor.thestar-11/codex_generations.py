

# Generated at 2022-06-22 08:28:54.567534
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST)

# Generated at 2022-06-22 08:28:57.238003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(ie._TEST['url'])
    assert ie._TEST['info_dict']['id'] == ie.br

# Generated at 2022-06-22 08:29:08.463278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _DATA = "<html><head><meta charset='UTF-8'></head><body><div class=\"story video-box\" id=\"video-box\" data-mainartBrightcoveVideoId='4732393888001' /></body></html>"
    TheStarIE(Priority.NORMAL)

# Generated at 2022-06-22 08:29:15.022449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    m = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    m._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-22 08:29:24.252720
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:25.090438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('794267642001')

# Generated at 2022-06-22 08:29:27.544224
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId'

# Generated at 2022-06-22 08:29:34.897020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = TheStarIE()
    instance.url = url
    assert instance._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert instance._TEST['url'] == url

# Generated at 2022-06-22 08:29:43.836688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_TheStarIE = TheStarIE(TheStarIE, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001', 'Mankind: Why this woman started a men\'s skin care line', 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', '794267642001', 1454353482, '20160201', '2c62dd4db2027e35579fefb97a8b6554')
	return test_TheStarIE

# Generated at 2022-06-22 08:29:55.336799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:10.295609
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:12.640988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().to_screen(TheStarIE()._TEST)

# Generated at 2022-06-22 08:30:19.209221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('video_id')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:30:20.903121
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:21.757803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:27.015153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:30:27.529173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:31.393531
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:42.481033
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assert an object of TheStarIE class is created
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Assert the value of attributes
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:49.928956
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create two objects, one of class TheStarIE, one of class TheStarIE_test
    # 1. TheStarIE class
    youtube_test = TheStarIE()
    # 2. TheStarIE_test class

# Generated at 2022-06-22 08:31:01.640811
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:05.667214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL, 'www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:09.397488
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check if there is any exception
    try:
        TheStarIE()
    except:
        assert False

    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-22 08:31:20.211315
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info = TheStarIE("https://www.thestar.com/news/world/2017/06/13/donald-trump-will-not-withdraw-from-paris-climate-deal.html")
	assert info._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:25.406323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    obj = TheStarIE()
    obj._real_extract(video_url)

# Generated at 2022-06-22 08:31:26.897636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:31:27.981197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-22 08:31:30.789870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test to create and initialize an object of TheStarIE
    """
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE, 'The class should be TheStarIE')

# Generated at 2022-06-22 08:31:32.370640
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name != None
    assert ie.name != ""

# Generated at 2022-06-22 08:31:32.903212
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:51.826822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Following code will create a TheStarIE object, it will check if
    # the class constructor has been implemented properly or not.
    ie = TheStarIE()

# Generated at 2022-06-22 08:31:55.181771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	import unittest
	class TestTheStarIE(unittest.TestCase):
		def setUp(self):
			self.thestar = TheStarIE()

		def test_module(self):
			self.assertEqual(self.thestar.ie_key(), 'TheStar')

	unittest.main()

# Generated at 2022-06-22 08:31:55.828787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:00.657644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.IE_NAME == 'thestar'
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:05.774238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    input = TheStarIE('test', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    output = (str(input))
    assert (output == 'TheStarIE(\'test\', \'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html\')')

# Generated at 2022-06-22 08:32:07.009781
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None) is not None

# Generated at 2022-06-22 08:32:16.149653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    init_instance = TheStarIE('init_url')
    assert init_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:26.798279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:32.560076
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ieObj = TheStarIE()
    # Test for IE class constructor
    assert ieObj.ie_key() == 'TheStar', ieObj.ie_key()
    assert ieObj.ie_url() == 'http://www.thestar.com/', ieObj.ie_url()
   
# Implementing test cases for TheStarIE

# Generated at 2022-06-22 08:32:36.396017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class TheStarIE_class(TheStarIE):
        # __init__
        class__ = 'TheStarIE'
        # constructor
        TheStarIE__init__ = TheStarIE.__init__
    TheStarIE_instance = TheStarIE_class()
    return TheStarIE_instance

# Generated at 2022-06-22 08:32:55.927253
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:01.849333
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:03.908441
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info = TheStarIE()
	assert info.__class__.__name__ == "_TheStarIE"

# Generated at 2022-06-22 08:33:07.523933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie != None

# Generated at 2022-06-22 08:33:14.265979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(the_star_ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")

# Generated at 2022-06-22 08:33:23.907502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    # Check the method of fetching Brightcove ID
    # By using "thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # As test case
    assert t._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        t._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
                            "test"),
        'brightcove id') == "4732393888001"

# Generated at 2022-06-22 08:33:28.317276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:37.610513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = thestarIE._download_webpage(url, '4732393888001')
    brightcove_id = thestarIE._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    print(thestarIE.BRIGHTCOVE_URL_TEMPLATE % brightcove_id)

# Generated at 2022-06-22 08:33:47.805429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	text = '''http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'''
	parsed_url = TheStarIE._VALID_URL.match(text)
	if parsed_url is not None:
		dic = parsed_url.groupdict()

# Generated at 2022-06-22 08:33:48.782695
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.test()

# Generated at 2022-06-22 08:34:42.539170
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if url is valid and can be instantiated.
    entry = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(entry, TheStarIE) is True
    # Test the video id extraction from url.
    assert entry.video_id == '4732393888001'
    # Test the JSON-LD data extraction of the video's title.
    assert entry.video_title == 'Mankind: Why this woman started a men\'s skin care line'
    # Test the JSON-LD data extraction of the video's description.
    assert entry.video_description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-22 08:34:44.120699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})
    assert(instance is not None)

# Generated at 2022-06-22 08:34:46.622088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:57.537196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE  == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL ==  r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:58.643894
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('url')


# Generated at 2022-06-22 08:35:04.542601
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    _ = TheStarIE(url)

# Calling of constructor of class TheStarIE
if __name__ == '__main__':
	test_TheStarIE()

# Generated at 2022-06-22 08:35:05.537948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:14.398961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "http://example.com"
    ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:18.637874
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:35:21.093504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This test ensures that TheStarIE constructor doesn't throw any error
    try:
        ie = TheStarIE()
    except:
        raise


# Generated at 2022-06-22 08:36:51.274068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.to_screen("Test object initialized")

# Generated at 2022-06-22 08:36:52.238080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t is not None

# Generated at 2022-06-22 08:36:52.860828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:37:02.462760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:07.387621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGTCOVE_URL_TEMPLATE = ie.BRIGHTCOVE_URL_TEMPLATE % 'test'
    ie._real_extract('http://www.thestar.com/test.html')

# Generated at 2022-06-22 08:37:17.695560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    module = "thestar"
    assert module in sys.modules
    obj = sys.modules[module]
    assert isinstance(obj, types.ModuleType)
    assert hasattr(obj, "TheStarIE")
    assert isinstance(obj.TheStarIE, type)
    instance = obj.TheStarIE
    assert isinstance(instance, obj.TheStarIE)
    assert hasattr(instance, "ie_key")
    assert instance.ie_key == "TheStar"
    assert hasattr(instance, "IE_NAME")
    assert instance.IE_NAME == "TheStar"
    assert hasattr(instance, "BRIGHTCOVE_URL_TEMPLATE")

# Generated at 2022-06-22 08:37:22.993257
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # A trivial unit test to ensure that the constructor of class TheStarIE doesn't throw any errors when called.
    try:
        TheStarIE(TheStarIE._VALID_URL)
    except Exception as e:
        assert False, 'Unexpected exception raised when constructing class TheStarIE: ' + type(e).__name__ + ": " + str(e)

# Generated at 2022-06-22 08:37:26.621188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:37:30.652017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL==r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:40.098415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'