

# Generated at 2022-06-22 08:28:52.868970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:28:55.831054
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'thestar'
    assert ie.description == 'The Star Online'
    assert ie.supports_subtitles == False

# Generated at 2022-06-22 08:28:57.730182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE is not None


# Generated at 2022-06-22 08:29:02.261513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
        Test TheStarIE constructor
    """
    ie = TheStarIE('https://www.thestar.com/entertainment/television/2016/02/01/faces-like-mine-a-doc-about-interracial-dating-and-its-effects-on-children.html')

# Generated at 2022-06-22 08:29:06.787584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:08.441496
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(isinstance(TheStarIE, InfoExtractor))


# Generated at 2022-06-22 08:29:12.912610
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:22.317054
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:29.887273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        theStarIE = TheStarIE()
        valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        assert theStarIE.suitable(valid_url), "TheStarIE does not handle valid URL"
        invalid_url = 'https://www.npr.org/2016/02/01/464506032/lost-in-transition-hong-kong-s-middle-class-feels-squeezed'
        assert not theStarIE.suitable(invalid_url), "TheStarIE does not handle invalid URL"
    except AssertionError:
        print ("AssertionError: TheStarIE does not handle valid URL")

test_TheStarIE()

# Generated at 2022-06-22 08:29:41.964087
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check case 1
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:29:50.772865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ is TheStarIE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == """http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"""



# Generated at 2022-06-22 08:29:52.289120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None, None)
    print(obj)
    assert isinstance(obj, TheStarIE)

# Generated at 2022-06-22 08:29:53.604239
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:55.164237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('TheStarIE', 'thestar.com')

# Generated at 2022-06-22 08:29:59.086866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor
    ie = TheStarIE('https://www.youtube.com/watch?v=0vxOhd4qlnA')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:59.825857
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-22 08:30:00.505243
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:04.182296
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:07.907487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:16.732242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Input string
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Expected output
    theStarIE = TheStarIE()
    testObj = theStarIE._real_extract(url)

    # Checks
    assert testObj.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'


# Generated at 2022-06-22 08:30:23.697926
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:24.694601
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL

# Generated at 2022-06-22 08:30:25.256638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:26.252224
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_obj = TheStarIE()

# Generated at 2022-06-22 08:30:28.226800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._constructor_test()

# Generated at 2022-06-22 08:30:37.500573
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    file_var = open("blob.txt","w")
    file_var.write("1")
    file_var.close()
    a = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",file_var)
    assert a != ''
    # import pdb;pdb.set_trace()
    # in_file_var = open("in_blob.txt","r")
    # in_file_var.read()
    # assert in_file_var != ''

# Generated at 2022-06-22 08:30:48.113303
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE() # 0 arguments
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:59.190262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    #print ie.extract_info(u'https://www.thestar.com/sports/leafs/2017/01/13/maple-leafs-take-on-winnipeg-jets-in-final-game-before-nhl-all-star-break.html')

# Generated at 2022-06-22 08:31:06.381714
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'
    #assert ie.point() == (1, 1)


# Generated at 2022-06-22 08:31:09.202746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie._VALID_URL)
    print(ie._TEST)
    print(ie.BRIGHTCOVE_URL_TEMPLATE)

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-22 08:31:21.355266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj != None
    assert obj._downloader != None
    assert obj._downloader.params != None
    assert obj._match_id != None
    assert obj._real_extract != None
    return


# Generated at 2022-06-22 08:31:22.047432
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:31:26.252544
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for constructor of class TheStarIE"""
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:31:26.741171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:28.240395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(TheStarIE.IE_NAME, False)

# Generated at 2022-06-22 08:31:37.862667
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert theStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert theStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert theStarIE._TEST['info_dict']['ext'] == 'mp4'
    assert the

# Generated at 2022-06-22 08:31:45.655218
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    ie = TheStarIE({})
    # assert that TheStarIE initialized properly
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # assert that TheStarIE initialized properly
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/]+)\.html'

# Generated at 2022-06-22 08:31:47.759878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:31:48.659306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-22 08:31:58.814403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test before changes due to brightcove updates
    #
    # Test to verify that class TheStarIE was created correctly
    # Unit test for constructor of class TheStarIE
    test_string = '''
        webpage = self._download_webpage(url, display_id)
        brightcove_id = self._search_regex(
            r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            webpage, 'brightcove id')
        return self.url_result(
            self.BRIGHTCOVE_URL_TEMPLATE % brightcove_id,
            'BrightcoveNew', brightcove_id)
    '''

# Generated at 2022-06-22 08:32:22.170684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Test the class TheStarIE
# Test case for __init__

# Generated at 2022-06-22 08:32:24.861828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

if __name__ == '__main__':
    # Test for constructor of class TheStarIE
    test_TheStarIE()

# Generated at 2022-06-22 08:32:32.983595
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # instantiate the class
    obj = TheStarIE('TheStarIE')
    # test member variables
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # TODO: test _TEST

# Generated at 2022-06-22 08:32:41.468166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_name = 'TheStarIE'
    class_ = globals()[class_name]
    # Test valid URL
    valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = class_(class_name, valid_url)
    assert instance.name == class_name
    assert instance.url == valid_url
    assert instance._VALID_URL == class_._VALID_URL
    # Test test attribute
    assert instance._TEST == class_._TEST
    assert instance._TEST['url'] == valid_url

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-22 08:32:48.681834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for 19.1.2012
    # http://www.thestar.com/mandelaclassic/article/1117554--mandela-s-international-legacy-to-be-honoured-in-toronto
    ie = TheStarIE('http://www.thestar.com/mandelaclassic/article/1117554--mandela-s-international-legacy-to-be-honoured-in-toronto')
    assert ie.display_id == '1117554--mandela-s-international-legacy-to-be-honoured-in-toronto'


# Generated at 2022-06-22 08:32:50.627364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:32:54.766187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.theglobeandmail.com/arts/film/film-reviews/review-putin-film-interviews-critics-but-no-tough-questions/article33929295/')
    assert ie.name == 'TheStar'

# Generated at 2022-06-22 08:32:58.482261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ it test the constructor of class
    TheStarIE """

    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:00.550936
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._VALID_URL).extract_info(TheStarIE._TEST['url'])

# Generated at 2022-06-22 08:33:05.134881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE("TheStarIE")
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:33:42.337505
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:43.847120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()

# Generated at 2022-06-22 08:33:47.247183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:53.915318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    obj.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:54.595360
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:33:55.908386
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-22 08:34:03.464816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    webpage = ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    brightcove_id = re.search(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage).group(1)
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-22 08:34:14.585014
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:18.302370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    if not hasattr(thestar_ie, "BRIGHTCOVE_URL_TEMPLATE"):
        raise Exception("Missing BRIGHTCOVE_URL_TEMPLATE attribute")

# Generated at 2022-06-22 08:34:19.884026
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test class constructor
    '''

    thestarIE = TheStarIE()

# Generated at 2022-06-22 08:35:52.772509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test case for class TheStarIE"""
    unit = TheStarIE()
    assert unit._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:01.732820
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:36:02.800039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ is TheStarIE


# Generated at 2022-06-22 08:36:06.982976
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:36:17.335327
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Initially the class has no id
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:18.240363
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract()

# Generated at 2022-06-22 08:36:21.411886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    #assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:36:29.519583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Valid input testing
    valid_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Invalid input testing
    invalid_url = "http://www.thestar.com/"

    # valid input object
    video_info_extractor = TheStarIE(valid_url)
    # invalid input object
    video_info_extractor_invalid = TheStarIE(invalid_url)


test_TheStarIE()

# Generated at 2022-06-22 08:36:30.629454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:36:42.192120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = '4732393888001'
    brightcove_id = '4732393888001'