

# Generated at 2022-06-22 08:28:53.821899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_video = TheStarIE()
    assert thestar_video

# Generated at 2022-06-22 08:28:59.698577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for video thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:29:04.645174
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:05.688440
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE(TheStarIE._downloader)

# Generated at 2022-06-22 08:29:06.542993
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:17.769934
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:18.673724
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test constructor
    TheStarIE()

# Generated at 2022-06-22 08:29:27.382555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    ie._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:29:35.218531
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = TheStarIE._TEST['url']
    ie = TheStarIE()._real_initialize(url)

    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-22 08:29:36.289379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL

# Generated at 2022-06-22 08:29:46.553260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Given
    theStarIE = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # When
    result = theStarIE._real_extract(url)
    # Then
    assert result['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-22 08:29:56.854838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:01.197187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")



# Generated at 2022-06-22 08:30:12.748210
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:13.919211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-22 08:30:15.700433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()


# Generated at 2022-06-22 08:30:24.505177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    inst = TheStarIE()
    inst.url = test_url
    inst.display_id = 'some_display_id'
    inst.webpage = '<html><body>Some Text</body></html>'
    inst.brightcove_id = 'some_brightcove_id'
    assert inst._download_webpage(inst.url, inst.display_id) == inst.webpage
    assert inst._match_id(inst.url) == inst.display_id
    assert inst._search_regex(r'(.+)', inst.webpage, 'some_group') == 'Some Text'
    assert inst

# Generated at 2022-06-22 08:30:28.018619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:39.778212
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = TheStarIE._TEST['url']
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert TheStarIE._TEST['info_dict']['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert TheStarIE._

# Generated at 2022-06-22 08:30:40.733721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Testing TheStariIE class
	pass

# Generated at 2022-06-22 08:30:48.266019
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:49.445202
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj


# Generated at 2022-06-22 08:30:59.565750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    info = TheStarIE(TheStarIE._VALID_URL, {})
    assert info._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert info._TEST.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert info._TEST.md5 == '2c62dd4db2027e35579fefb97a8b6554'
    assert info._TEST.info_dict.id == '4732393888001'
    assert info._TEST.info_dict.ext == 'mp4'
    assert info._TEST.info_dict

# Generated at 2022-06-22 08:31:03.886291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # these tests just check that the class requires a URL
    # and returns the right ie_key and ie_name
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_name() == 'TheStar'

# Generated at 2022-06-22 08:31:15.163416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:23.752451
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = '4732393888001'
    info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }
    ie = TheStarIE()
    ie_result = ie.extract(ie.BRIGHTCOVE_URL_TEMPLATE % video_id)
    assert ie_result['_type'] == 'url_transparent'
    assert ie_result['url'] == ie.BRIGHTCOVE_URL_

# Generated at 2022-06-22 08:31:27.174112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:30.537810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    me = class_()
    assert me.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:34.844297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.__name__ == 'thestar'
    assert ie.__class__.__name__ == 'TheStarIE'


# Generated at 2022-06-22 08:31:35.713987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:46.179439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(InfoExtractor), InfoExtractor)

# Generated at 2022-06-22 08:31:57.169555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Call class constructor
    thestar = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Create beautifulsoup object
    soup = BeautifulSoup(thestar.webpage,'html.parser')
    # Test that the link to the video is indeed the one used in the regex in the _real_extract function
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == thestar.url_result(thestar.BRIGHTCOVE_URL_TEMPLATE % thestar.BRIGHTCOVE_ID)

##############################################################################################################################


# Generated at 2022-06-22 08:32:01.746920
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-22 08:32:05.970584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie.download()

# Generated at 2022-06-22 08:32:09.951244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:19.028886
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:32:25.056670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.assertTrue(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:32:36.731108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    kwargs = { 'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'md5': '2c62dd4db2027e35579fefb97a8b6554', 'info_dict': { 'id': '4732393888001', 'ext': 'mp4', 'title': 'Mankind: Why this woman started a men\'s skin care line', 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'uploader_id': '794267642001', 'timestamp': 1454353482, 'upload_date': '20160201'} , 'params': { 'skip_download': True}}
    TheStarIE(**kwargs)


# Generated at 2022-06-22 08:32:40.356502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert isinstance(info_extractor, InfoExtractor)


# Generated at 2022-06-22 08:32:48.114275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'ie.url incorrect'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html', 'ie.display_id incorrect'

# Generated at 2022-06-22 08:33:14.436313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
        Constructor test
    """
    def __init__(self, url):
        super(TheStarIE, self).__init__()
        self._match_id(url)
    # Unit test
    print("TheStarIE Unit Test 0: Constructor")
    thestarIE = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("Finished")


# Generated at 2022-06-22 08:33:24.944750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:26.035150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-22 08:33:36.576624
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:38.021873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-22 08:33:40.977873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:33:44.680880
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert e.__class__ == TheStarIE

# Generated at 2022-06-22 08:33:46.858821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    assert TheStarIE()

# test_TheStarIE()

# Generated at 2022-06-22 08:33:47.489306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:52.477367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:35.846316
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-22 08:34:43.324580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_cases = [
        {
            'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
            'id': '4732393888001',
        },
    ]
    # Constructor of InfoExtractor will call the worker-function
    # _real_extract via calling extract()
    for test_case in test_cases:
        url = test_case['url']
        instance = TheStarIE()
        instance._real_extract(url)


# Generated at 2022-06-22 08:34:48.544575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.__class__.__name__ == 'TheStarIE'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:54.567166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    for test_value in ['http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'http://www.thestar.com/sports/leafs/2016/02/03/leafs-hockey-has-taken-its-toll-says-phaneufs-girlfriend.html']:
        TheStarIE(test_value)

# Generated at 2022-06-22 08:34:55.662182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.suite()


# Generated at 2022-06-22 08:34:59.940043
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star = TheStarIE()
    result = the_star.extract(url)

# Generated at 2022-06-22 08:35:01.256848
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:35:11.796721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for video with valid url
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    video_id = 4732393888001
    instance = TheStarIE(url) # create an instance of TheStarIE
    assert instance._VALID_URL == TheStarIE._VALID_URL
    assert instance._TEST == TheStarIE._TEST
    assert instance.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert instance._match_id(url) == video_id

    # Test for video with invalid url

# Generated at 2022-06-22 08:35:13.478028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        t = TheStarIE()
    except Exception as e:
        print(e)



# Generated at 2022-06-22 08:35:16.419919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(
        TheStarIE.ie,
        TheStarIE.test,
        TheStarIE._VALID_URL,
        TheStarIE.__name__,
        TheStarIE._TEST)


# Generated at 2022-06-22 08:36:40.000080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/opinion/editorials/2016/06/20/sudan-finally-grants-canadian-doctor-legal-status-editorial.html"
    TheStarIE(url)

# Generated at 2022-06-22 08:36:42.138129
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.test()

# Generated at 2022-06-22 08:36:43.862198
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE({ 'username': 'foo', 'password': 'bar' })
    a.info()

# Generated at 2022-06-22 08:36:48.009930
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import TheStarIE
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:36:51.319931
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:37:00.105331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:01.245835
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x != None

# Generated at 2022-06-22 08:37:03.991876
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
       TheStarIE()

# Generated at 2022-06-22 08:37:07.937937
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    myclass = TheStarIE()
    assert myclass.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:37:17.286747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Test video is fetched from brightcove"""
    data = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    
    result = TheStarIE().extract(data)
    assert result['id'] == '4732393888001'
    assert result['upload_date'] == '20160201'
    assert result['duration'] == 10
    assert result['formats'][0]['format_id'] == 'http-live-streaming'
    assert result['formats'][0]['ext'] == 'mp4'