

# Generated at 2022-06-22 08:28:54.072744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:29:04.289580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = ie._match_id(url)
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-22 08:29:06.310271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-22 08:29:12.162168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for unit test"""
    # if _TEST does not exist, fail
    video = TheStarIE(TheStarIE._TEST)
    # if the video id does not exist in the test case, fail
    assert video.video_id is not None

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:29:15.782037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:29:17.163429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(common.InfoExtractor)
    return

# Generated at 2022-06-22 08:29:22.385546
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.__class__ == TheStarIE)
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    
test_TheStarIE()

# Generated at 2022-06-22 08:29:32.233662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert theStarIE._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
    assert theStarIE._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'

# Generated at 2022-06-22 08:29:43.923040
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test class TheStarIE using _TEST from test.py

    """
    # TODO: This should be a test for a constructor of the class
    # but the constructor cannot be invoked with arguments.
    # Parse arguments.
    parser = argparse.ArgumentParser(description='Test class TheStarIE')
    parser.add_argument('query')
    parser.add_argument('--list', action='store_true')

    args = parser.parse_args()
    if args.list:
        # Print information on all supported extractors.
        print('Supported extractors:')
        for ie in gen_extractors():
            print('%s\t%s' % (ie.IE_NAME, ie.IE_DESC))
    else:
        # Run a test.
        test = TheStarIE(_TEST)


# Generated at 2022-06-22 08:29:44.690247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-22 08:29:50.365313
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    print("Test TheStarIE constructor")
    testVideo = TheStarIE()

# Generated at 2022-06-22 08:29:58.432537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.constructor_args[0] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._TEST["md5"] == "2c62dd4db2027e35579fefb97a8b6554"

# Generated at 2022-06-22 08:30:02.412960
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:05.587688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarie = TheStarIE()
    assert thestarie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:09.881032
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE()._TEST == TheStarIE._TEST
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:30:15.592982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test case: open url
    url_test = "http://www.thestar.com/sports/bluejays/2015/03/05/russell-martin-comfortable-without-being-comfortable.html"
    test_ie = TheStarIE()
    assert test_ie.suitable(url_test)

# Generated at 2022-06-22 08:30:21.084420
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s';
    return;

# Generated at 2022-06-22 08:30:32.815515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_class = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	
	assert test_class._downloader is not None
	assert test_class._downloader.params['outtmpl'] == '%(id)s-%(title)s.%(ext)s'
	assert test_class._downloader.params['noplaylist'] == False
	assert test_class._downloader.params['ignoreerrors'] == False
	assert test_class._downloader.params['no_warnings'] == False
	assert test_class._downloader.params['quiet'] == True
	assert test_class._downloader.params['no_color'] == False
	assert test_class._downloader

# Generated at 2022-06-22 08:30:36.149702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:42.095176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._downloader == None

# Generated at 2022-06-22 08:30:54.737389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:06.167725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:08.355461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert len(TheStarIE._TEST) == 5
	assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:09.344731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.init()

# Generated at 2022-06-22 08:31:10.635128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    d = TheStarIE()

# Generated at 2022-06-22 08:31:11.280289
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:14.698810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u"""
        This is a test for constructor of TheStarIE.
    """
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-22 08:31:22.854767
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._display_id == ('mankind-why-this-woman-started-a-men-s-skincare-line/')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:24.379677
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test instance is created
    assert TheStarIE()

# Generated at 2022-06-22 08:31:25.003742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:42.010717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert False

# Generated at 2022-06-22 08:31:43.274663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE, type)


# Generated at 2022-06-22 08:31:46.098405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

test = TheStarIE()
test_TheStarIE()

# Generated at 2022-06-22 08:31:56.924862
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-22 08:32:09.290414
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001', {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }, 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')


# Generated at 2022-06-22 08:32:13.129883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    example = TheStarIE()
    assert example._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-22 08:32:17.945850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("", "")
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:29.158659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert the_star.BRIGHTCOVE_URL_TEMPLATE % '4732393888001' == expected
    assert the_star._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:35.206599
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:42.497777
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None)

    # Test for _VALID_URL
    assert ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

    # Test for _TEST

# Generated at 2022-06-22 08:33:04.122349
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 8319)

# Generated at 2022-06-22 08:33:05.214018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:33:13.309261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	m = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
	webpage = '<html><body>ManKind: Why this woman started a men\'s skin care line</body></html>'
	brightcove_id = '4732393888001'

# Generated at 2022-06-22 08:33:23.815214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info_dict = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201'}
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:25.846458
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    instance = t
    assert isinstance(instance, TheStarIE)

# Generated at 2022-06-22 08:33:29.931294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE() == TheStarIE()
	assert TheStarIE()._downloader == TheStarIE()
	assert TheStarIE()._downloader.params == TheStarIE().params


# Generated at 2022-06-22 08:33:38.972118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.get('id') == '4732393888001'
    # assert obj.get('url') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert obj.get('ext') == 'mp4'
    assert obj.get('description') == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert obj.get('title') == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-22 08:33:41.995769
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    module = 'test'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = TheStarIE(module, url)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:33:53.107426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #case1
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    #case2
    TheStarIE('http://www.thestar.com/life/20160201/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    #case3
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    #case4

# Generated at 2022-06-22 08:33:54.147318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:36.818811
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("TheStarIE")

# Generated at 2022-06-22 08:34:39.768476
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:42.980479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('url')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:34:54.371460
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').test()
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').test_result()
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').test_playlist()

# Generated at 2022-06-22 08:34:56.296108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:59.543885
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:35:10.389159
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:35:19.072543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate TheStarIE class
    the_star_ie = TheStarIE()
    # Instantiate RegexNotFoundException class
    regex_not_found_exception = RegexNotFoundError()
    # Use this method to check if the regex matches
    regex_match = the_star_ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    try:
        # Use this method to check if the regex does not matches
        regex_match = the_star_ie._match_id("https://www.youtube.com/watch?v=Hn4sfC2Pbhg")
    except regex_not_found_exception:
        print("Regex doesn't match")

# Generated at 2022-06-22 08:35:25.582569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    name = "TheStarIE"
    t = TheStarIE
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:26.552509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)


# Generated at 2022-06-22 08:36:59.227684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #test code - use 'print' to show the results
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    from ..utils import ExtractorError
    try:
        TheStarIE()(url)
    except ExtractorError:
        pass

# Generated at 2022-06-22 08:37:02.462602
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:37:06.341038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:37:08.507609
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:37:13.362291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:13.943356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:37:14.691925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();

# Generated at 2022-06-22 08:37:26.565536
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	from .common import InfoExtractor
	from .TheStarIE import TheStarIE
	from .BrightcoveNewIE import BrightcoveNewIE

	# It is not possible to use test cases since the brightcove url is hardcoded
	t = TheStarIE()
	t.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'
	t.BRIGHT_COVE_DOMAIN = 'http://players.brightcove.net/'

	b = BrightcoveNewIE()
	b.BRIGHTCO

# Generated at 2022-06-22 08:37:36.366418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # The class name of TheStarIE
    info_extractor_class_name = 'TheStarIE'
    # The expected class name of TheStarIE
    expected_info_extractor_class_name = __name__ + '.TheStarIE'
    # Check whether the two class name are the same
    assert info_extractor_class_name == expected_info_extractor_class_name
    # Check if the info_extractor_class_name is of class InfoExtractor
    assert issubclass(type(info_extractor_class_name), InfoExtractor)
    # Check if the TheStarIE can be initialized
    assert TheStarIE(info_extractor_class_name)

# Generated at 2022-06-22 08:37:39.806495
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'