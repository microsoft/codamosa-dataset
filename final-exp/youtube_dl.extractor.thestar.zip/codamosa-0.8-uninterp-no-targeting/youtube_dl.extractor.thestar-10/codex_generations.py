

# Generated at 2022-06-22 08:29:02.404606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract(
        'http://www.thestar.com/sports/2014/10/17/toronto_maple_leafs_gm_dave_nonis_on_the_hot_seat_after_another_poor_start.html')
    ie.extract(
        'http://www.thestar.com/news/immigration/2016/02/04/iraqi-refugee-saves-canadian-soldier-from-suicide-bomb-attack.html')

# Generated at 2022-06-22 08:29:13.761747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-22 08:29:21.103877
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', download=False)

# Generated at 2022-06-22 08:29:21.688822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:32.054320
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE()
    unit_test._download_webpage = lambda x: '<html></html>'
    unit_test._match_id = lambda x: '4732393888001'
    unit_test._search_regex = lambda x, y, z: '4732393888001'
    url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url_result = unit_test._real_extract(url)
    assert url_result['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert url_result['ie_key'] == 'BrightcoveNew'

# Generated at 2022-06-22 08:29:35.903348
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance using constructor of class TheStarIE
    instance = TheStarIE()

    # check whether instance is created or not
    assert instance

    # check whether object is instance of class TheStarIE
    assert isinstance(instance, TheStarIE)

# Generated at 2022-06-22 08:29:39.833097
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    loader = TheStarIE(None)
    assert loader.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:40.944757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != None

# Generated at 2022-06-22 08:29:41.642909
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:42.728635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()



# Generated at 2022-06-22 08:29:47.344602
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance (TheStarIE(), InfoExtractor)

# Generated at 2022-06-22 08:29:48.470662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance

# Generated at 2022-06-22 08:29:54.086661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:59.319690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:03.045134
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:04.323252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:05.796151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    print(result)

# Generated at 2022-06-22 08:30:08.046673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
     obj = TheStarIE()
     assert obj

# Generated at 2022-06-22 08:30:10.435980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
        raise AssertionError("Unit test for constructor of class TheStarIE: failed")
    except AssertionError:
        pass

# Generated at 2022-06-22 08:30:17.969050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:28.837238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE('not a real URL')
    assert video.__class__.__name__ == TheStarIE.__name__

# Generated at 2022-06-22 08:30:29.724440
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:31.601851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test correct construction
    ie = TheStarIE({})
    assert ie != None


# Generated at 2022-06-22 08:30:34.846528
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:35.613903
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_class = TheStarIE()

# Generated at 2022-06-22 08:30:36.602022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-22 08:30:39.727978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:48.067793
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:53.541490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/]+\.html)'

# Generated at 2022-06-22 08:31:04.839866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == {'uploader_id': '794267642001', 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'upload_date': '20160201', 'ext': 'mp4', 'title': 'Mankind: Why this woman started a men\'s skin care line', 'id': '4732393888001', 'timestamp': 1454353482}

# Generated at 2022-06-22 08:31:32.036072
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:33.121988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj



# Generated at 2022-06-22 08:31:38.483557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Example from http://www.thestar.com/news/world/us_elections/2016/03/03/trump-pulls-off-three-state-sweep.html
    assert(ie._match_id('http://www.thestar.com/news/world/us_elections/2016/03/03/trump-pulls-off-three-state-sweep.html') == 'trump-pulls-off-three-state-sweep.html')

# Generated at 2022-06-22 08:31:39.074858
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:47.294852
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:57.668799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ins = TheStarIE()
    assert ins._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ins._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ins._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ins._TEST['info_dict']['id'] == '4732393888001'
    assert ins._TEST['info_dict']['ext'] == 'mp4'
    assert ins._TEST['info_dict']['title']

# Generated at 2022-06-22 08:31:58.916956
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:10.989511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # created by constructor
    ie = TheStarIE()
    # ie.BRIGHTCOVE_URL_TEMPLATE initialized
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # ie._VALID_URL initialized
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/]+)\.html'
    # ie.BRIGHTCOVE_URL_TEMPLATE initialized

# Generated at 2022-06-22 08:32:12.411155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-22 08:32:17.908611
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.extract('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001') 
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:33:01.746507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST['params']["skip_download"] == True

# Generated at 2022-06-22 08:33:05.981780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.example.com/eats.html')
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')


# Generated at 2022-06-22 08:33:09.453401
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:16.427017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = 'id_123'
    webpage = '<html><div mainartBrightcoveVideoId="%s"></div></html>' % video_id
    obj = TheStarIE()
    while True:
        try:
            brightcove_id = obj._search_regex(
                r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
                webpage, 'brightcove id')
            break
        except:
            pass
        
    assert brightcove_id == video_id

# Generated at 2022-06-22 08:33:21.061523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    #TheStarIE.__init__(url)
    assert ie._TEST.url == url

# Generated at 2022-06-22 08:33:31.312373
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_inst = TheStarIE()
    assert test_inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_inst._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-22 08:33:35.562898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:44.171157
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.add_info_extractor("thestar.com", TheStarIE)
    # ie.suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # ie.suitable("http://www.thestar.com/life/2016/02/01/as-they-see-it-retired-teachers-have-won-but-classroom-conditions-have-suffered.html")
    # ie.suitable("http://www.thestar.com/life/2016/02/01/as-they-see-it-a-good-reason-to-leave-teaching.html")
    # ie.suitable("http://www.thestar.com

# Generated at 2022-06-22 08:33:50.595905
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing TheStarIE class constructor
    ie = TheStarIE()
    assert ie.name == 'thestar'
    assert ie.url_re.pattern == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:00.979120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE % ('4732393888001') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Test for function _real_extract()

# Generated at 2022-06-22 08:35:24.644158
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:35:28.627566
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:35:30.460568
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:35:34.903982
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:35:35.885473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)

# Generated at 2022-06-22 08:35:37.779368
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert len(a.BRIGHTCOVE_URL_TEMPLATE) > 0

# Generated at 2022-06-22 08:35:38.379945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:39.009772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:42.600513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None).extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:35:46.156483
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'