

# Generated at 2022-06-22 08:28:48.694802
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:28:50.104906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """UnitTest for class TheStarIE"""
    TheStarIE()

# Generated at 2022-06-22 08:28:56.306194
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    result = instance.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result


# Generated at 2022-06-22 08:28:59.829591
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:00.740279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:02.214537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie == TheStarIE

# Generated at 2022-06-22 08:29:13.577637
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test a random url
    display_id = "4732393888001"
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
    url_result = ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id

# Generated at 2022-06-22 08:29:14.116381
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:22.097717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    youtube_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert youtube_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Create an instance of class TheStarIE using the constructor
    TheStarIE(u'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:29:23.025873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:31.731666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    brightcove_id = '4732393888001'
    assert TheStarIE._real_extract(TheStarIE(), None).url == TheStarIE.BRIGHTCOVE_URL_TEMPLATE % brightcove_id

# Generated at 2022-06-22 08:29:43.456816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.BRIGHTCOVE_URL_TEMPLATE
    # thestar.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    # thestar.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=5728953477001'
    # thestar.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    # thestar.BRIGHTCOVE_URL_TEMPL

# Generated at 2022-06-22 08:29:46.426177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Call class constructor with URL used in _TEST
    thestar_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert thestar_ie is not None

# Generated at 2022-06-22 08:29:48.137255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that TheStarIE can be instantiated
    ie = TheStarIE()

# Generated at 2022-06-22 08:29:55.692467
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Here, init a test object
    # I have chosen timesofindia.indiatimes.com as the sample url
    test_video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_instance = TheStarIE(test_video_url)

    # I am using the assert keyword to test if the object is correctly
    # initialized
    assert isinstance(test_instance, TheStarIE)
    return


# Generated at 2022-06-22 08:29:58.708140
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:03.969646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def test():
        ie = TheStarIE()
        ie.BRIGHTCOVE_URL_TEMPLATE
        ie._VALID_URL
        ie._TEST
        ie._download_webpage
        ie._search_regex
        ie._match_id
        ie.url_result
    test()
    return


# Generated at 2022-06-22 08:30:04.710727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-22 08:30:07.686922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """TheStarIE unit test."""
    assert TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-22 08:30:09.510375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST['url'])

# Generated at 2022-06-22 08:30:22.062986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-22 08:30:23.566289
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:24.601961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-22 08:30:27.796681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""

    # Instantiation of class TheStarIE
    # Not enough to test error catching (needs to be done in integration tests)
    object = TheStarIE()

# Generated at 2022-06-22 08:30:39.583614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:30:47.930153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html")
    assert(TheStarIE._TEST['url'] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(TheStarIE._TEST['md5'] == "2c62dd4db2027e35579fefb97a8b6554")
    assert(TheStarIE._TEST['info_dict']['id'] == "4732393888001")
    assert(TheStarIE._TEST['info_dict']['ext'] == "mp4")

# Generated at 2022-06-22 08:30:48.954032
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()

# Generated at 2022-06-22 08:30:59.509274
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId='
    ie.downloader = 'test_downloader'
    ie.downloader_kwargs = {'username': 'some user', 'password': 'some password'}
    ie._downloader = ie.downloader()
    ie._downloader.params.update(ie.downloader_kwargs)

    # Test download
    # test_TheStarIE.test_download_video
    ie.download_video(ie.BRIGHTCOVE_URL_TEMPLATE + '4732393888001')

    # Test extract
    # test_TheStarIE.test_extract_video

# Generated at 2022-06-22 08:31:03.525304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/news/gta/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:14.751077
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    instance._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-22 08:31:23.814838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:31:33.945479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie._VALID_URL == r'https?://(?:www\.|)thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:31:37.303302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test constructor of TheStarIE
    ie = TheStarIE('TheStarIE')

    # Test properties of TheStarIE
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_name() == 'TheStar'

# Generated at 2022-06-22 08:31:39.782959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from ytdl.extractor import TheStarIE
    obj = TheStarIE()
    assert obj.__class__ == TheStarIE


# Generated at 2022-06-22 08:31:40.618357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("test")

# Generated at 2022-06-22 08:31:52.268738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._NETRC_MACHINE == 'thestar'
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_download_webpage')

# Generated at 2022-06-22 08:32:04.786690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# test works fine
	import unittest

	class TestTheStarIE(unittest.TestCase):
		def setUp(self):
			self.instance = TheStarIE()

		def test_urls(self):
			test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

			self.instance = TheStarIE()
			self.assertEqual(self.instance._match_id(test_url), 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-22 08:32:11.260107
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:16.600285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:19.673274
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:32:36.731513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    instance = ie()
    assert isinstance(instance, TheStarIE)


# Generated at 2022-06-22 08:32:42.353211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert (a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:32:46.392253
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(the_url)

# Generated at 2022-06-22 08:32:57.446283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:58.579736
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie == TheStarIE


# Generated at 2022-06-22 08:33:00.252548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_class = TheStarIE

# Generated at 2022-06-22 08:33:03.964460
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");

# Generated at 2022-06-22 08:33:05.474657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(None), TheStarIE)

# Generated at 2022-06-22 08:33:13.406101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
	assert obj._TEST['info_dict']['id'] == '4732393888001'
	assert obj._TEST['info_dict']['ext'] == 'mp4'
	assert obj._TEST['info_dict']['title']

# Generated at 2022-06-22 08:33:15.629422
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:33:59.553174
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # mock class
    class MockDict(dict):
        def drop_duplicates(self):
            pass

        def ordered_extend(self):
            pass
    # mock class
    class MockVideoIE(object):
        def __init__(self):
            self.extractor_keywords = {
                'BrightcoveNew': ('brightcove_id', )
            }

    video_ie = MockVideoIE()
    TheStarIE.video_ie = video_ie
    TheStarIE.ie_keywords = MockDict({'BrightcoveNew': {'brightcove_id': 'BRIGHTCOVE_ID'}})
    TheStarIE._download_webpage = lambda x, y: '<html></html>'

    # Testing for the good cases

# Generated at 2022-06-22 08:34:02.030969
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    print(theStar)

# Generated at 2022-06-22 08:34:08.532301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert (ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-22 08:34:19.986376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._VALID_URL == "http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html")
    assert(TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')
    assert(TheStarIE._TEST['info_dict']['id'] == '4732393888001')
    assert(TheStarIE._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-22 08:34:22.975079
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    try:
        TheStarIE()
        print("Create TheStarIE object successfully")
    except:
        print("Failed to create TheStarIE object")
    


# Generated at 2022-06-22 08:34:26.456115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:34:33.245235
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    assert thestarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:37.181257
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html')

# Generated at 2022-06-22 08:34:38.937895
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert (ie.brightcove_id == '794267642001')

# Generated at 2022-06-22 08:34:49.782009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'https://test.com/test/test.html?test=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:36:19.727206
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert TheStarIE._TEST['url'] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert TheStarIE._TEST['md5'] == "2c62dd4db2027e35579fefb97a8b6554"
    assert TheStarIE._TEST['info_dict']['id'] == "4732393888001"
    assert TheStarIE._TEST['info_dict']['ext'] == "mp4"

# Generated at 2022-06-22 08:36:27.379896
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert(instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

if __name__ == '__main__':
    import sys
    sys.exit(test_TheStarIE())

# Generated at 2022-06-22 08:36:31.640296
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Testing class TheStarIE")
    ie = TheStarIE()
    class_name = ie.__class__.__name__
    assert class_name == "TheStarIE"
    print("%s test is done" % class_name)



# Generated at 2022-06-22 08:36:43.093984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:47.875615
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_brightcove_new import test_BrightcoveNew
    test_BrightcoveNew(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % TheStarIE._TEST['info_dict']['id']).run()

# Generated at 2022-06-22 08:36:48.326945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-22 08:36:49.331339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-22 08:36:51.366365
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    # Works only at night, b/c it's a news website
    # Would get the samples tested by internet

# Generated at 2022-06-22 08:37:01.984731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:05.622038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')