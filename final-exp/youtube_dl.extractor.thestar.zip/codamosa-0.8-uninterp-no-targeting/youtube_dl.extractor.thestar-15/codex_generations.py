

# Generated at 2022-06-22 08:28:53.820005
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE

# Generated at 2022-06-22 08:29:06.026904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Test when video is available
  info_dict = {
      'id': '4732393888001',
      'ext': 'mp4',
      'title': 'Mankind: Why this woman started a men\'s skin care line',
      'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
      'uploader_id': '794267642001',
      'timestamp': 1454353482,
      'upload_date': '20160201',
  }

# Generated at 2022-06-22 08:29:11.558247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:29:12.165523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:29:18.722536
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = '4732393888001'
    expected_result = ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id
    # run
    result = ie._real_extract(url)
    # verify
    assert(result['url'] == expected_result)

# Generated at 2022-06-22 08:29:20.061762
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t.ie = []
    t.index = 0

# Generated at 2022-06-22 08:29:28.540899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an object of class TheStarIE to test
    thestar_ie = TheStarIE()
    thestar_ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    # Input url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Actual output from _real_extract()
    actual = thestar_ie._real_extract(url)
    # Expected output from _real_extract()

# Generated at 2022-06-22 08:29:30.019084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:29:42.071013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	instance = TheStarIE()
	instance.url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	instance.display_id = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	instance.IE_NAME = 'thestar'
	instance.IE_DESC = 'The Star'

# Generated at 2022-06-22 08:29:42.729119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-22 08:29:53.696570
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

if __name__ == '__main__':
    import sys

    # Test class constructor
    test_TheStarIE()

    # Test extract function
    ie = TheStarIE()
    sys.exit(ie.extract(sys.argv[1]))

# Generated at 2022-06-22 08:29:57.206465
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:09.012142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .utils import make_extractor
    from .brightcove_new import BrightcoveNewIE
    from .utils import make_extractor

    # When the getvideoinfo function returns a video, a new instance
    # of type BrightcoveNewIE is created.
    # We have to provide the kwargs again here as the url has changed
    # Create a new instance of type TheStarIE
    ie = TheStarIE(make_extractor(TheStarIE), "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # create a new instance of type BrightcoveIE

# Generated at 2022-06-22 08:30:20.911038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:29.281218
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:30:38.082283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:40.315662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'


# Generated at 2022-06-22 08:30:42.811126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert issubclass(TheStarIE, InfoExtractor)
	ie = TheStarIE()
	assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:30:50.136884
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:30:52.401259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:05.349925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return the_star

# Generated at 2022-06-22 08:31:16.417853
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:25.702649
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:27.532135
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception as e:
        raise e


# Generated at 2022-06-22 08:31:30.578651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:31:34.265456
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:31:41.685252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # expected_output = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    from .common import TheStarIE
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:31:42.636297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:31:43.529457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:31:45.834662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE.test()

# Generated at 2022-06-22 08:32:04.999586
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	mozwebqa = TheStarIE(url)
	pass

# Generated at 2022-06-22 08:32:15.442757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    pattern = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    TheStarIE._VALID_URL = pattern
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'
    t = TheStarIE(url)
    assert t._match_id(url) == '1454353482'

# Generated at 2022-06-22 08:32:26.178066
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    with open(test_url, 'r') as f:
        webpage = f.readlines()
    webpage = ''.join(webpage)

# Generated at 2022-06-22 08:32:30.859568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:31.971582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert True

# Generated at 2022-06-22 08:32:34.635213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ds = TheStarIE()
    assert ds is not None
    assert ds.BRIGHTCOVE_URL_TEMPLATE is not None


# Generated at 2022-06-22 08:32:40.348245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._match_id(url) == '4732393888001'

test_TheStarIE()

# Generated at 2022-06-22 08:32:41.254813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:46.941453
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(0)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:57.810071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of class TheStarIE
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test _VALID_URL
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test _TEST
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-22 08:33:15.978709
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:26.405673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    info_dict = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }
    inst = class_(info_dict)
    assert inst._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:28.416487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()



# Generated at 2022-06-22 08:33:31.784865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_instance = TheStarIE()
	assert test_instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:33:34.554888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-22 08:33:36.733387
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Unit test for constructor of class TheStarIE : ")
    print(TheStarIE)



# Generated at 2022-06-22 08:33:39.166514
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    TheStarIE = TheStarIE()
    TheStarIE.test_main()

# Generated at 2022-06-22 08:33:50.643459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Downloaded webpage of "Mankind: Why this woman started a men's skin care line"
    webpage = open('thestar_page.html','r')
    # Test the constructor
    assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', webpage)

# Generated at 2022-06-22 08:33:53.472982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._TEST['url'] == ie._VALID_URL

# Generated at 2022-06-22 08:34:01.562767
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    meta_info = ie.BRIGHTCOVE_URL_TEMPLATE
    meta_info = dict(a="b")
    print ("\nmeta_info :: ", meta_info)
    meta_info = meta_info.values()
    print ("\nmeta_info :: ", meta_info)
    meta_info = [meta_info]
    print ("\nmeta_info :: ", meta_info)
    meta_info = meta_info[0]
    print ("\nmeta_info :: ", meta_info)

# test_TheStarIE()

# Generated at 2022-06-22 08:34:41.839565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:53.112636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Start with importing module class TheStarIE
    # and check if the correct class class TheStarIE is imported
    assert TheStarIE.__name__ == "TheStarIE"

    # Create an instance of class TheStarIE
    # and check if an instance class TheStarIE is created
    thestarie = TheStarIE()
    assert thestarie.__class__.__name__ == "TheStarIE"

    # Check if an instance variable of class TheStarIE
    # is of correct value
    assert thestarie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
    # Check if an instance variable of class TheStarIE
    # is of correct value
    assert thestarie.BRIGHTCOVE_URL_T

# Generated at 2022-06-22 08:34:53.731242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:54.331673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:54.954671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  TheStarIE()

# Generated at 2022-06-22 08:34:59.271255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  'Test constructor'
  exp = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
  res = TheStarIE._VALID_URL
  assert exp == res, \
     'Expected ' + exp + ' Received ' + res

# Generated at 2022-06-22 08:35:10.492030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor
    instance = TheStarIE()
    # Properties
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:11.619170
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:13.088394
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit tests for class TheStarIE
    TheStarIE()

# Generated at 2022-06-22 08:35:14.331715
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thes = TheStarIE()
    assert thes is not None


# Generated at 2022-06-22 08:36:34.849193
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("4732393888001")

# Generated at 2022-06-22 08:36:46.519942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:36:57.058818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:59.859157
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:37:02.301803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')
    assert ie.display_id == '4732393888001'

# Generated at 2022-06-22 08:37:12.017329
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.type == 'brightcove'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.id == '4732393888001'
    assert ie.duration == 0
    assert ie.timestamp == 1454353482
    assert ie.uploader_id == '794267642001'

# Generated at 2022-06-22 08:37:13.165280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Constructor
	TheStarIE()

# Generated at 2022-06-22 08:37:17.782630
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.id == '4732393888001'

# Generated at 2022-06-22 08:37:18.459350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-22 08:37:29.190768
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL)
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.htm      l')
    assert (ie.__name__ == 'TheStar')
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')