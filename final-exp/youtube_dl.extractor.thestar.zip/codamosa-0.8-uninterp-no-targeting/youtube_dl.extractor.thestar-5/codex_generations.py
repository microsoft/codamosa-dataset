

# Generated at 2022-06-22 08:28:55.442945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:28:56.960120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE(None, None)
    assert result != None

# Generated at 2022-06-22 08:29:02.017150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:07.287863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE()._TEST == TheStarIE._TEST
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE._BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:29:14.294868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHT_COVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-22 08:29:23.644990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    def _real_extract(url):
        display_id = TheStarIE._match_id(url)
        webpage = TheStarIE._download_webpage(url, display_id)

# Generated at 2022-06-22 08:29:26.358634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:29:27.728799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()

# Generated at 2022-06-22 08:29:32.710225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # obj = TheStarIE(TheStarIE._VALID_URL)
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:29:36.113878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_data = TheStarIE()._TEST
    passed = True
    try:
        TheStarIE(test_data, test_data['url'])
    except Exception:
        passed = False

    assert passed

# Generated at 2022-06-22 08:29:47.475266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__name__ == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:57.266870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'thestar.com' in ie.IE_NAME
    assert ie.VALID_URL.search('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.VALID_URL.search('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.VALID_URL.search('http://www.thestar.com/life/boating/2014/05/22/toronto_harbour_grand_prix_offers_chance_to_party_with_the_stars.html')
    assert ie.VALID_URL.search

# Generated at 2022-06-22 08:30:09.060799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star = TheStarIE()
    assert(the_star._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(the_star._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line')
    the_star._download_

# Generated at 2022-06-22 08:30:13.154366
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-22 08:30:17.262137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE();
    assert(theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s');

# Generated at 2022-06-22 08:30:21.004565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   pass


# Generated at 2022-06-22 08:30:24.105761
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

# Generated at 2022-06-22 08:30:31.565093
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor with no parameter
    try:
        TheStarIE()
    except TypeError:
        assert(False)
    except Exception:
        assert(True)
    # Test constructor with valid id parameter
    try:
        TheStarIE('4732393888001')
    except TypeError:
        assert(False)
    except Exception:
        assert(True)
    # Test constructor with invalid parameter
    try:
        TheStarIE('473239388800')
    except TypeError:
        assert(True)
    except Exception:
        assert(False)

# Generated at 2022-06-22 08:30:36.150251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.is_match() == True

# Generated at 2022-06-22 08:30:40.856731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:45.865037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ieObj = TheStarIE()
    assert isinstance(ieObj, TheStarIE)

# Generated at 2022-06-22 08:30:48.135340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:54.856184
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = object()
    res = ie.BRIGHTCOVE_URL_TEMPLATE % obj
    assert res == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + unicode(obj)

# Generated at 2022-06-22 08:30:56.840379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x

# Generated at 2022-06-22 08:30:57.856947
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:30:58.485834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:59.480251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE({})

# Generated at 2022-06-22 08:31:02.885833
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:07.745825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Just making sure the constructor of class TheStarIE is actually working"""
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BASE_URL == 'http://www.thestar.com'

# Generated at 2022-06-22 08:31:08.397196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE

# Generated at 2022-06-22 08:31:20.837001
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:31:27.431591
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:31.227504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Sets name of the class
    class_name = "TheStarIE"
    # Gets TheStarIE instance
    inst = TheStarIE()
    # Checks if the instance is of the right type
    assert isinstance(inst, TheStarIE)


# Generated at 2022-06-22 08:31:33.864726
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	assert test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:39.766975
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    a = TheStarIE()
    assert a._VALID_URL is not None
    assert a._TEST is not None
    assert a.BRIGHTCOVE_URL_TEMPLATE is not None
    #assert a._real_extract is not None
    #assert a._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None

# Generated at 2022-06-22 08:31:40.767083
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:31:44.157275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL is not None

# Generated at 2022-06-22 08:31:51.274790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.htm"
    expected_brightcove_id = "4732393888001"
    actual_brightcove_id = ie._real_extract(url)["id"]

    assert actual_brightcove_id == expected_brightcove_id

# Generated at 2022-06-22 08:31:53.787841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:06.028735
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import sys
    if sys.version_info.major != 2:
        print('Skip unit test of TheStarIE class')
        return
    import inspect
    import unittest
    import json

    class TestTheStarIE(unittest.TestCase):
        def test_constructor(self):
            instance = TheStarIE()
            self.assertTrue(inspect.isclass(TheStarIE))
            self.assertTrue(isinstance(instance, InfoExtractor))
            self.assertTrue(hasattr(instance, '_VALID_URL'))
            self.assertTrue(instance._VALID_URL is not None)
            self.assertTrue(hasattr(instance, '_TEST'))
            self.assertTrue(instance._TEST is not None)

# Generated at 2022-06-22 08:32:25.110795
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ies = TheStarIE()
    print(ies._real_extract(url))

# Generated at 2022-06-22 08:32:27.247127
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE != '';
    assert ie._VALID_URL != '';

# Generated at 2022-06-22 08:32:38.322150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.TheStarIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:49.358553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Test the constructor of TheStarIE
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-22 08:32:55.167253
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:57.629459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:58.722054
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.constructor()

# Generated at 2022-06-22 08:32:59.737681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()



# Generated at 2022-06-22 08:33:04.015839
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:09.260635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'


# Generated at 2022-06-22 08:33:54.334704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    def _md5(string):
        import hashlib
        return hashlib.md5(string).hexdigest()

    # Test 1
    _url = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert _url.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert _md5(_url.display_id) == '3362c48fcb741e4f5a5d3b70c9ef9f5a'
    assert _md5(_url.id) == '4732393888001'
    assert _

# Generated at 2022-06-22 08:34:03.958243
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._get_info(TheStarIE()._VALID_URL, TheStarIE()._VALID_URL)
    assert info.get('url') == TheStarIE()._TEST.get('url')
    assert info.get('ext') == TheStarIE()._TEST.get('ext')
    assert info.get('id') == TheStarIE()._TEST.get('id')
    assert info.get('title') == TheStarIE()._TEST.get('title')
    assert info.get('description') == TheStarIE()._TEST.get('description')
    assert info.get('uploader_id') == TheStarIE()._TEST.get('uploader_id')
    assert info.get('timestamp') == TheStarIE()._TEST.get('timestamp')

# Generated at 2022-06-22 08:34:04.973814
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:16.129455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
  assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:25.194708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.title == "Mankind: Why this woman started a men's skin care line"
    assert ie.description == "Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN."


# Generated at 2022-06-22 08:34:31.217340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/life/television/2016/02/04/when-is-the-eurovision-song-contest-2016-date-place-time-and-how-to-watch-it.html')

# Generated at 2022-06-22 08:34:35.699249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Check test
    ie = TheStarIE()
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:39.093319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:34:46.283953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = '4732393888001'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url, display_id)
    assert ie.video_id == video_id
    assert ie._display_id == display_id

# Generated at 2022-06-22 08:34:47.747921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_instance = TheStarIE()
    assert(ie_instance != None)

# Generated at 2022-06-22 08:36:11.771613
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html','4732393888001')

# Generated at 2022-06-22 08:36:14.677312
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:36:15.684258
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-22 08:36:21.260354
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert type(ie) == TheStarIE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-22 08:36:22.312008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-22 08:36:33.891404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert t._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert t._TEST['info_dict']['id'] == '4732393888001'
    assert t._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:36:37.314948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	instance = TheStarIE()
	instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:36:47.777060
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = ie._VALID_URL
    display_id = ie._match_id(url)
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    result = ie.url_result(ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id, 'BrightcoveNew', brightcove_id)
    assert result.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert not result is None

# Generated at 2022-06-22 08:36:50.910355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({}, {})
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._TEST
    assert ie._VALID_URL
    assert ie._real_extract

# Generated at 2022-06-22 08:36:53.727828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test for unit test for constructor of TheStarIE
    """
    loader = TestLoader()
    suite = TestSuite((
        loader.loadTestsFromTestCase(TheStarIE),
    ))
    return suite