

# Generated at 2022-06-22 08:28:55.052321
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests that the constructor of TheStarIE does not throw an exception
    try:
        # Create an instance of TheStarIE
        ie = TheStarIE()
    except Exception as e:
        assert False, 'Cannot create an instance of TheStarIE'

# Generated at 2022-06-22 08:28:56.093202
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();

# Generated at 2022-06-22 08:29:01.928377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = TheStarIE._TEST['url']
    test_display_id = TheStarIE._TEST['info_dict']['id']
    ie = TheStarIE()
    ie._real_extract(test_url)
    assert type(ie.BRIGHTCOVE_URL_TEMPLATE) == str

# Test to ensure that the class is instantiated with the correct URL template

# Generated at 2022-06-22 08:29:09.359979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
        Test if the constructor for TheStarIE
        followed the correct pattern
    '''
    valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test = TheStarIE(valid_url)
    assert test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:29:11.077779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})
    print(instance)

# Generated at 2022-06-22 08:29:18.421970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    import unittest
    class TestTheStar(unittest.TestCase):
        """Unit test class for TheStarIE"""
        def setUp(self):
            """Test case setup"""
            self.thestar_extractor = TheStarIE()
        def test_constructor(self):
            """Test case for constructor test"""
            self.assertIsNotNone(self.thestar_extractor)
    print("Testing class TheStarIE")
    unittest.main(module=__name__, buffer=True, exit=False)
    print("Testing complete")

# Generated at 2022-06-22 08:29:24.655680
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:29:32.176907
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "https://www.thestar.com/entertainment/music/2016/01/22/loves-a-strange-bird-after-50-years-together-the-poppy-family-is-over.html"
    ie._download_webpage = lambda *args: "abc"
    ie._search_regex = lambda *args: "1"
    ie.url_result = lambda *args: "abc"
    ie.url = url
    ie.display_id = ie._match_id(url)
    ie._real_extract(url) # test _real_extract

# Generated at 2022-06-22 08:29:36.010563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:29:40.395299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

# Generated at 2022-06-22 08:29:46.379664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert( isinstance( TheStarIE(), InfoExtractor ) )

# Generated at 2022-06-22 08:29:47.638061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("test", "test", "test")

# Generated at 2022-06-22 08:29:51.318142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:30:00.737494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:30:04.400653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    assert video.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:30:11.083941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.suitable('thestar')
    assert not TheStarIE.suitable('thestar_bad')
    assert TheStarIE.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert not TheStarIE.suitable('http://www.thestar.com/backend.html')

# Unit tests for methods of class TheStarIE

# Generated at 2022-06-22 08:30:17.697350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    video = TheStarIE().extract(url)

    # title
    assert video["title"] == "Mankind: Why this woman started a men's skin care line"
    
    # download url
    assert "TheStarIE.BRIGHTCOVE_URL_TEMPLATE" in video["url"]

# Generated at 2022-06-22 08:30:28.900834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    # Test with the URL for the first video
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    r = t.extract_url(url)
    # Test with the URL for the second video
    url = 'http://www.thestar.com/videozone/734599--premier-kathleen-wynne-reflects-on-lgbt-heros'
    r = t.extract_url(url)
    # Test with the URL for the third video

# Generated at 2022-06-22 08:30:36.096273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.display_id = 'www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie._real_extract(ie.url)

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-22 08:30:40.856711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # The star video test
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:50.601636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:30:52.128429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    # Assert for equality and not for identity
    assert inst is not TheStarIE()

# Generated at 2022-06-22 08:30:58.682971
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_player_url('http://players.brightcove.net/794267642001/default_default/index.html?videoId=12345')
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return True

# Generated at 2022-06-22 08:31:02.547308
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie) == TheStarIE
    assert ie.__class__.__bases__ == (InfoExtractor,)

# Generated at 2022-06-22 08:31:13.688901
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:14.552094
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-22 08:31:15.655446
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)

# Generated at 2022-06-22 08:31:18.284726
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:31:19.912973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("")

# Generated at 2022-06-22 08:31:25.977566
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')
    assert ie.description == ie.title == ie.timestamp == ie.upload_date == ie.uploader_id == ie.ext == None and ie.md5 == None

test_TheStarIE()

# Generated at 2022-06-22 08:31:49.888601
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:55.364658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    # Assert that the field 'url' was correctly set
    assert inst.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-22 08:32:00.604756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._download_webpage(ie._TEST['url'], ie._TEST['info_dict']['id'])

# Generated at 2022-06-22 08:32:09.133446
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    theStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    theStarIE._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:12.787492
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:16.071690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().match(TheStarIE().BRIGHTCOVE_URL_TEMPLATE % '12345')
    assert TheStarIE().match(TheStarIE().BRIGHTCOVE_URL_TEMPLATE % '678910')

# Generated at 2022-06-22 08:32:16.437843
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-22 08:32:16.957916
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:17.759721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    aTheStarIE = TheStarIE()

# Generated at 2022-06-22 08:32:19.335028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    request = TheStarIE()._request_webpage
    assert request is not None

# Generated at 2022-06-22 08:32:58.229703
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ClassOfTheStarIE=TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ClassOfTheStarIE.url=="http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-22 08:33:00.303133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Unit tests for TheStarIE._real_extract

# Generated at 2022-06-22 08:33:01.340335
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-22 08:33:05.134090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:13.282075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:17.592737
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE()
    # Check if the constructor generates a valid URL
    assert(o.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')


# Generated at 2022-06-22 08:33:28.286231
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE(TheStarIE.__name__)._call_api(
        'http://www.thestar.com/life/2016/02/01/mankind-why-thi-woman-started-a-men-s-skincare-line.html',
        '4732393888001', 'BrightcoveNew')
    assert info == {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }

# Unit

# Generated at 2022-06-22 08:33:31.150672
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Call _real_extract to see if there are any errors or exceptions
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-22 08:33:40.173045
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:42.809256
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = TheStarIE._VALID_URL
    inst = TheStarIE()
    assert inst._VALID_URL == url

# Generated at 2022-06-22 08:34:31.406613
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()

    # test if default value of _VALID_URL is correct
    assert IE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html?', \
        'The _VALID_URL value is not correct'

    # test if default value of _TEST is correct
    assert IE._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', \
        'The url value within _TEST is not correct'

    # test if default value of BRIGHTCOVE_URL_TEMPLATE is correct
    assert IE.BRIGHTCOVE_URL

# Generated at 2022-06-22 08:34:33.142155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:34:44.547317
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()

# Generated at 2022-06-22 08:34:55.688955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:34:56.258166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:34:59.538552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:35:10.735771
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:35:12.227941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie


# Generated at 2022-06-22 08:35:20.137858
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Here is a test URL
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # It should be valid according to the class pattern
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-22 08:35:20.844167
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:36:44.363766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-22 08:36:47.000340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE(TheStarIE._downloader)
    assert unit_test is not None, "Unit test failed"

# Generated at 2022-06-22 08:36:51.548562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print(instance._TEST["info_dict"]["id"])

# Generated at 2022-06-22 08:36:55.065105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE
    # Create an instance of this class
    u = TheStarIE()

# Generated at 2022-06-22 08:36:58.001003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:37:00.927114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(
        TheStarIE._downloader, 
        TheStarIE._VALID_URL)._VALID_URL == TheStarIE._VALID_URL

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:37:08.060052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == TheStarIE._VALID_URL
    assert instance._TEST == TheStarIE._TEST
    assert instance.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

    # test that setter works properly
    instance._VALID_URL = "URL"
    assert instance._VALID_URL == "URL"

# Generated at 2022-06-22 08:37:08.581553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert True

# Generated at 2022-06-22 08:37:09.522238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-22 08:37:16.340222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"