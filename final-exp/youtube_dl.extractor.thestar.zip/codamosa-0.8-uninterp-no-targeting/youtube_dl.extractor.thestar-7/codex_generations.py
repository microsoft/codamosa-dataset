

# Generated at 2022-06-22 08:28:58.443007
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("test: thestare")
	assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:05.390838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t
    assert t._VALID_URL 
    assert t._TEST
    assert t.BRIGHTCOVE_URL_TEMPLATE
    assert t._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:29:14.902246
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Unit test for constructor
	@precondition: tests/test.mp4 file exists and is valid and expectedValue is a string
	@postcondition: nothing
	@returns: nothing
	@raises: nothing
	"""
	import os
	import sys
	command_dir = os.path.dirname(os.path.realpath(__file__))
	sys.path.append(os.path.abspath(os.path.join(command_dir + "/../../../tests/")))
	import TestIE


	url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	expectedValue = "4732393888001"


	testObject = TestIE.TestIE()
	

# Generated at 2022-06-22 08:29:22.855900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    i = ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(i['uploader_id'] == '794267642001')
    assert(i['ext'] == 'mp4')
    assert(i['id'] == '4732393888001')
    assert(i['title'] == "Mankind: Why this woman started a men's skin care line")
    assert(i['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.')

# Generated at 2022-06-22 08:29:24.643141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:29:33.180747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE()
    o.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    #brightcove_id = o._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
    webpage = o._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-22 08:29:40.899886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert IE.__name__ == 'TheStar'
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:29:46.268856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # make sure assertIsInstance is called 
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-22 08:29:52.244234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie.download("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:30:00.415436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert the_star_ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-22 08:30:06.245278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'https://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == TheStarIE().BRIGHTCOVE_URL_TEMPLATE % '4732393888001'


# Generated at 2022-06-22 08:30:17.104293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Video link
    url = 'https://www.thestar.com/sports/2016/03/29/toronto-fc-seeks-revenge-against-red-bull-new-york.html'

    thestar = TheStarIE()
    thestar.url = url
    assert thestar.url == thestar._VALID_URL
    assert thestar._TEST['url'] == url
    assert thestar._TEST['info_dict']['id'] == thestar._match_id(url)
    assert thestar._TEST['info_dict']['title'] == thestar._download_webpage(
        url, None).title.replace('Video - thestar.com', '').strip()

# Generated at 2022-06-22 08:30:21.005105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()

# Generated at 2022-06-22 08:30:26.601092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""Unit test constructor of class TheStarIE"""
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:30:31.854466
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()
    assert extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', 'BRIGHTCOVE_URL_TEMPLATE value different from test value'

# Generated at 2022-06-22 08:30:33.128536
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	""" Unit test for TheStarIE """
	TheStarIE("thestar")

# Generated at 2022-06-22 08:30:40.555129
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test URL from '_TEST' object
    thestare_test_url1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star_ie = TheStarIE()
    the_star_ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    the_star_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 08:30:44.913513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # First check that I can create an instance of the class
    ie = TheStarIE()
    # Then test whether it matches the URL and if that is the case extracts the info
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:30:51.394169
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test case from _TEST of TheStarIE class
    # 
    # Test case requires mocking of request.
    # 
    # Response from fake webpage is not a webpage, but a json file.
    # 
    # Fake webpage contains a videoid of "4732393888001"
    # Fake webpage returns a Brightcove video
    # 
    # Expect that func returns the Brightcove url of the fake webpage
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    expected_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    result = TheStarIE()._real_extract

# Generated at 2022-06-22 08:30:59.398561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test simple instantiation of class TheStarIE
    TheStarIE()
    # Test that class TheStarIE has the attribute extractor
    assert(hasattr(TheStarIE, 'extractor'))
    # Test value of attribute extractor of class TheStarIE
    assert(TheStarIE.extractor=='The Star')
    # Test that class TheStarIE has the attribute _VALID_URL
    assert(hasattr(TheStarIE, '_VALID_URL'))
    # Test value of attribute _VALID_URL of class TheStarIE
    assert(TheStarIE._VALID_URL==r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-22 08:31:12.918691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Unit test of constructor on TheStarIE class
	# Testing with black box approach
		url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
		TheStarIE(url)
		# Testing with black box approach
		# url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
		# TheStarIE(url)

# Generated at 2022-06-22 08:31:16.145285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:31:25.433910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:31:29.265508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie._download == InfoExtractor._download
    assert ie._download_webpage == InfoExtractor._download_webpage



# Generated at 2022-06-22 08:31:30.664092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor should initialize all necessary variables
    assert TheStarIE()

# Generated at 2022-06-22 08:31:31.605116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()


# Generated at 2022-06-22 08:31:34.185909
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:31:37.536163
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Precondition:
    #   Extractor should be of instance
    #   of class InfoExtractor
    info_extractor = InfoExtractor()

    assert isinstance(info_extractor, InfoExtractor)



# Generated at 2022-06-22 08:31:39.942170
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie_new = ie.ie_key()
    ie_new_2 = ie.ie_key()
    assert(ie_new == ie_new_2)

# Generated at 2022-06-22 08:31:42.762014
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')



# Generated at 2022-06-22 08:32:02.909423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    #Test if function returns expected string.
    #assert IE._build_video_id('234234234') == 'default_default/index.html?videoId=234234234'

# Generated at 2022-06-22 08:32:09.950119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.name == 'The Star Video'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:32:11.304750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-22 08:32:21.456791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test case for TheStarIE"""
    # Create an instance of TheStarIE
    the_star_ie = TheStarIE()
    # Check if the instance is valid or not
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:33.229601
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-22 08:32:37.209635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:32:48.933098
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:32:50.043177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	assert obj is not None

# Generated at 2022-06-22 08:32:50.745628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:32:51.801887
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert True

# Generated at 2022-06-22 08:33:17.591936
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:19.591057
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    print(test_TheStarIE)

# Generated at 2022-06-22 08:33:30.924098
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.name =='thestar.com'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:33:32.858659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._check_ie_name() == 'TheStar'

# Generated at 2022-06-22 08:33:33.514378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:33:38.781692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    test_TheStarIE = TheStarIE()
    assert test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-22 08:33:50.175670
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-22 08:33:53.420173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-22 08:34:02.999473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # If a string is passed to it, TheStarIE makes a URL result
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert theStarIE.url_result('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'BrightcoveNew', '4732393888001') == theStarIE._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:34:12.373398
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = 'http://www.thestar.com/news/insight/2016/01/31/over-the-shoulder-boulder-holder-the-genius-of-the-bra-strap.html'
    ie = TheStarIE()
    ie.extract(url)

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-22 08:35:03.689966
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor of class TheStarIE shoule be a class of the package subclassing InfoExtractor.
    assert issubclass(TheStarIE, ie_module = InfoExtractor)
    # Create instance of TheStarIE.
    ie = TheStarIE()
    # Check if instance ie is an instance of its own class
    assert isinstance(ie, klass = TheStarIE)
    # Check if instance ie is an instance of its parent class InfoExtractor.
    assert isinstance(ie, klass = InfoExtractor)
    # Check if instance ie is an instance of its grand parent class InfoExtractor.
    assert isinstance(ie, klass = InfoExtractor)


# Generated at 2022-06-22 08:35:05.428322
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE.
    """
    TheStarIE()

# Generated at 2022-06-22 08:35:06.379627
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.constructor is not None

# Generated at 2022-06-22 08:35:09.456380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-22 08:35:10.069980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-22 08:35:20.366228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:35:25.467981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)

test_TheStarIE()

# Generated at 2022-06-22 08:35:26.079345
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:26.687799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-22 08:35:33.496462
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:06.209138
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', 'class constants in TheStarIE are broken'

# Generated at 2022-06-22 08:37:08.424034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE, "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-22 08:37:13.923372
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    extractor = TheStarIE()
    assert extractor.get_id_from_url(url) == '4732393888001'

# Generated at 2022-06-22 08:37:15.285668
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'


# Generated at 2022-06-22 08:37:27.036868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-22 08:37:37.562110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Imports
    import unittest

    # Create TheStarIE instance
    instance = TheStarIE()

    # Create unittest
    class TestTheStarIE(unittest.TestCase):
        def test_valid_url(self):
            # Test whether valid URL is indeed valid
            self.assertEqual(
                instance._VALID_URL,
                instance._VALID_URL,
                "Expected valid url to match _VALID_URL")

# Generated at 2022-06-22 08:37:48.456511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:37:59.799869
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-22 08:38:06.386621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    obj = TheStarIE()
    assert obj.__class__.__name__ == "TheStarIE"
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"


# Generated at 2022-06-22 08:38:16.950116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'