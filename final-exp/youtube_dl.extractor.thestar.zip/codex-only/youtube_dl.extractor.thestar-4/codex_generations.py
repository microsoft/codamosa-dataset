

# Generated at 2022-06-24 13:18:54.985900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:18:55.577242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:18:58.776265
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ('http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s');

# Generated at 2022-06-24 13:18:59.833651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:03.379116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:12.083448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # example url
    example_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie._VALID_URL == ie._build_regex(ie._VALID_URL)
    assert ie._VALID_URL.startswith(r'https?://(?:www\.)?')
    assert '/' in ie._VALID_URL
    assert ie._VALID_URL.endswith(r'.html')
    assert ie._TEST['url'] == example_url

# Generated at 2022-06-24 13:19:22.979014
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:19:26.440461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:19:34.161341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Step 1: Instantiation of Unit Test
    class_name = "TheStarIE"
    unit_test = TheStarIE()
    # Step 2: Get the object of Unit Test object
    class_object = getattr(unit_test, class_name)
    # Step 3: Check whether the class object is constructed properly
    class_id = class_object.__name__
    assert class_id == class_name
    # Step 4: Get the parent class and check whether class is inherited from parent
    parent_class = class_object.__bases__
    assert parent_class == (InfoExtractor,)
    # Step 5: Check the method of class
    class_method = dir(class_object)

# Generated at 2022-06-24 13:19:39.016776
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_initialize()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:42.291083
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:42.881416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:44.849919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie != None


# Generated at 2022-06-24 13:19:49.747639
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'Thestar'
    assert ie.ie_name() == 'Thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:56.855234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    info_dict = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
        }
    info = tsi._info(url, display_id=None, downloader=None)
    assert info == info_

# Generated at 2022-06-24 13:20:01.955306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie_object = ie.extract(ie.BRIGHTCOVE_URL_TEMPLATE % ie._TEST['info_dict']['id'])
    ie_id = ie_object.get('id')
    assert(ie_id == ie._TEST['info_dict']['id'])

# Generated at 2022-06-24 13:20:10.998946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:13.973518
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))

# Generated at 2022-06-24 13:20:18.972708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', 'The instance variable BRIGHTCOVE_URL_TEMPLATE has not been initialized correctly'

# Generated at 2022-06-24 13:20:20.916228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:29.534902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.get_url() == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj.get_id() == '4732393888001'
    assert obj.get_ext() == 'mp4'
    assert obj.get_name() == 'Mankind: Why this woman started a men\'s skin care line'
    assert obj.get_description() == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert obj.get_uploader_id() == '794267642001'
    assert obj.get_timestamp() == 1454353482
    assert obj.get_upload_date() == '20160201'


# Generated at 2022-06-24 13:20:40.538141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	the_star_ie = TheStarIE('http://www.thestar.com/videos/news/2016/03/03/how-to-make-torontos-skyscrapers-safe-from-tall-vehicles.html')
	# test 1: test the valid url
	assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	# test 2: test the test functions

# Generated at 2022-06-24 13:20:49.332197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor tests
    if __name__ == '__main__':
        ie = TheStarIE({})
        assert ie.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        assert ie.get_media_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'

# Generated at 2022-06-24 13:20:59.799922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the constructor
    # the URL is an example from real life
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # test the expected ID
    expected_id = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # test the expected type
    expected_type = 'TheStarIE'
    # test the expected info dict

# Generated at 2022-06-24 13:21:08.933563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.initiate_dictionary()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    webpage = ie._download_webpage(url, ie._match_id(url))
    assert ie.BRIGHTCOVE_URL_TEMPLATE % ie._search_regex(     # video id
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',  # regex expression
        webpage, 'brightcove id') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:21:17.294872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    ie = TheStarIE(None)
    assert ie.__class__.__name__ == 'TheStarIE'
    ie = TheStarIE('TheStarIE')
    assert ie.__class__.__name__ == 'TheStarIE'
    ie = TheStarIE(u'TheStarIE')
    assert ie.__class__.__name__ == 'TheStarIE'

import os, sys
if os.path.exists(sys.modules['__main__'].__file__):
    #Unit test for class TheStarIE
    import unittest


# Generated at 2022-06-24 13:21:20.662264
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    k = TheStarIE()
    print(k._VALID_URL)
    print(k._TEST)
    print(k.BRIGHTCOVE_URL_TEMPLATE)
    print(k.extract)
    print(k.extract(k._TEST['url']))


# Generated at 2022-06-24 13:21:23.485157
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:27.037068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test url to extract
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.extract(url)

# Generated at 2022-06-24 13:21:38.491869
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:43.362047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:52.178369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("the url is %s" % ie.url)
    print("the is_suitable is %s" % ie.is_suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"))
    print("the is_suitable is %s" % ie.is_suitable("http://www.thestar.com/"))
    

# Generated at 2022-06-24 13:21:52.557491
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:21:59.443564
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
        ie = TheStarIE()
        assert ie._match_id('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'
        assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:22:09.346895
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'thestar.com'
    assert ie.__name__ == 'thestar.com'
    assert ie.IE_NAME == 'thestar.com'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:18.523160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    from .testcases import TestVideoIE 
    # Construct an instance of TheStarIE
    ie = TheStarIE(TestVideoIE.test_data_dir)
    assert ie.__class__ == TheStarIE
    # Test result of extract() method
    result = ie.extract(TestVideoIE.THE_STAR_VIDEO_URL)
    assert result.__class__ == dict
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert result['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert result['uploader_id'] == '794267642001'
   

# Generated at 2022-06-24 13:22:21.769416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.download('4732393888001')
    assert ie.get_file_info() is not None


# Generated at 2022-06-24 13:22:30.032024
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:22:40.614282
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("TheStarIE")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:47.675619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    video_id = '4732393888001'
    player_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:22:56.016181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test TheStarIE.extract
    assert TheStarIE().extract
    # Test TheStarIE.extract's first param is url
    assert TheStarIE().extract.__code__.co_varnames[0] == 'url'

# Generated at 2022-06-24 13:22:56.576115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
		assert TheStarIE

# Generated at 2022-06-24 13:23:01.738760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')


# Generated at 2022-06-24 13:23:06.611737
# Unit test for constructor of class TheStarIE
def test_TheStarIE():        
    def create_ie(url, expected_output):
        ie = TheStarIE(url)
        assert ie.url == url
        assert ie.expected_output == expected_output
        return ie

    def test_match_id(url, expected_id):
        ie = create_ie(url, expected_id)
        assert ie._match_id(url) == expected_id

    test_match_id(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-starte    d-a-men-s-skincare-line.html',
        'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-24 13:23:09.390698
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    I = TheStarIE('test_TheStarIE')
    assert I.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:12.370394
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(test_TheStarIE.__dict__["_TEST"]["url"])

# Generated at 2022-06-24 13:23:14.960836
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:16.325605
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(None), InfoExtractor)

# Generated at 2022-06-24 13:23:24.874324
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:23:27.919828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert str(TheStarIE) != str(InfoExtractor)
    assert str(TheStarIE) != str(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert str(TheStarIE) != str(TheStarIE._VALID_URL)
    assert str(TheStarIE) != str(TheStarIE._real_extract)
    assert str(TheStarIE) == 'TheStarIE'

# Generated at 2022-06-24 13:23:28.783282
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie

# Generated at 2022-06-24 13:23:33.927569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # constructor with valid url
    STAR_TEST = TheStarIE(TheStarIE._TEST)
    assert STAR_TEST._VALID_URL == TheStarIE._VALID_URL
    assert STAR_TEST._TEST == TheStarIE._TEST
    assert STAR_TEST.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 13:23:39.590834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE
	assert ie._TEST
	assert ie._VALID_URL
	assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
test_TheStarIE()

# Generated at 2022-06-24 13:23:46.623290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	search_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	search_result = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	suite = TheStarIE(search_url)
	suite.suite()
	assert search_url is suite.url
	assert suite.is_valid(search_result)


# Generated at 2022-06-24 13:23:51.030681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert i._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:51.797774
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != None

# Generated at 2022-06-24 13:23:54.046236
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:57.052739
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.download('4732393888001')

# Generated at 2022-06-24 13:24:01.180583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:09.346192
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:10.584951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _TheStarIE = TheStarIE()

# Generated at 2022-06-24 13:24:18.582683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    #print ie._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")[0]
    #print ie._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.

# Generated at 2022-06-24 13:24:19.769729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:24:29.550597
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:37.067232
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info = TheStarIE._TEST
    url = test_info.url
    display_id = TheStarIE._VALID_URL
    webpage = TheStarIE._download_webpage(url,display_id)
    brightcove_id = TheStarIE._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage)
    print(brightcove_id)

#test_TheStarIE()

# Generated at 2022-06-24 13:24:46.747562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test on a valid url
    TheStarIE()._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Test on a invalid url
    TheStarIE()._real_extract("http://www.thestar.com/life/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    TheStarIE()._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-lin.html")

# Generated at 2022-06-24 13:24:54.805023
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:00.450359
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_request(None)
    # Assert values for attributes
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:25:04.114250
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:08.609031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    e = TheStarIE()
    e._setup_opener()
    r = e._call_api(test_url)

# Generated at 2022-06-24 13:25:16.557430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = ie._match_id(url)
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-24 13:25:19.414251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:29.119228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.brightcove_id == '4732393888001'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST

# Generated at 2022-06-24 13:25:29.946484
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:39.865761
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert inst._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert inst._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:25:42.848616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:25:53.093317
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:54.054080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _TheStarIE = TheStarIE("thestar")

# Generated at 2022-06-24 13:25:57.313171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Check if constructor of class TheStarIE
    raises an exception if URL is bad
    """
    bad_url = 'http://www.bad.com/'
    assert TheStarIE(bad_url) != 0

# Generated at 2022-06-24 13:26:02.037139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # assert that ie is an instance of InfoExtractor
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 13:26:02.373913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:26:03.732047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("testing")
    return


# Generated at 2022-06-24 13:26:04.318944
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return

# Generated at 2022-06-24 13:26:04.918647
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:26:11.238169
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None
    assert ie._VALID_URL is not None
    assert ie._TEST is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None


# Generated at 2022-06-24 13:26:15.900584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This gets a number of 404 pages and is otherwise painfully slow
    # please run only if needed.
    TheStarIE(test=True).test_IE()(
        'http://www.thestar.com/life/2015/12/08/15-recipes-for-making-quick-and-delicious-holiday-dip.html')

# Generated at 2022-06-24 13:26:17.177854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    assert test_object is not None

# Generated at 2022-06-24 13:26:18.226614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    if ie is None:
        raise AssertionError("TheStarIE() is None")

# Generated at 2022-06-24 13:26:20.532427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:23.155235
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Class to test the constructor of class TheStarIE if the unit test is not driven by pytest

# Generated at 2022-06-24 13:26:26.435095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Try to create an instance of the class and make sure that it's an instance of the class
    assert isinstance(TheStarIE("thestar.com"), TheStarIE)


# Generated at 2022-06-24 13:26:30.175331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:31.929512
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        test_TheStarIE()
#------------------------------------------------------
#
#Unit test for get_formats of class TheStarIE

# Generated at 2022-06-24 13:26:33.587029
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    objIE = TheStarIE()
    assert objIE is not None


# Generated at 2022-06-24 13:26:34.594552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print(TheStarIE)

# Generated at 2022-06-24 13:26:35.579364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:26:44.937693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/food/2016/02/06/lettuce-wrap-lobster-salad-demo-at-dariannys.html')
    ie.extract('http://www.thestar.com/life/2016/02/05/trumps-wild-day-leaves-gop-leaders-baffled.html')
    ie.extract('http://www.thestar.com/autoshow/2016/02/15/ford-gt-wows-at-north-american-intl-auto-show.html')


# Generated at 2022-06-24 13:26:46.442088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)


# Generated at 2022-06-24 13:26:48.392497
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarInstance = TheStarIE()
    theStarInstance.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 13:26:52.565674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # check if the ID matches the regex
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:26:54.029548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-24 13:26:59.906251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:08.001479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie._downloader is not None
	assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None

# Generated at 2022-06-24 13:27:12.698089
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE.format('4732393888001')

# Generated at 2022-06-24 13:27:18.092567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
    webpage = "Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN."
    brightcove_url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId="
    brightcove_id = "4732393888001"

    ie = TheStarIE()

    ie.new_extractor(TheStarIE)
    ie.new_extractor(TheStarIE)
    ie.new_extractor(TheStarIE)

# Generated at 2022-06-24 13:27:18.812736
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:24.360389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE(url)
    assert ie.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert ie.get_info()['id'] == '4732393888001'

# Generated at 2022-06-24 13:27:25.321837
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:27:35.550545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_to_test = TheStarIE
    instantiat_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    expected_id = '4732393888001'
    expected_title = 'Mankind: Why this woman started a men\'s skin care line'
    expected_description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    expected_uploader_id = '794267642001'
    expected_timestamp = 1454353482
    expected_upload_date = '20160201'

    unit_test = TheStarIE(class_to_test)
    unit_test.suitable(instantiat_url)
    unit_test.extract

# Generated at 2022-06-24 13:27:38.983954
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()
    assert info.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:39.596162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:43.861632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    sobj = TheStarIE()
    obj = sobj.ie_key()

# Generated at 2022-06-24 13:27:45.158527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStaIE(None)
    except:
        pass

# Generated at 2022-06-24 13:27:50.641655
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test for ThestarIE class
    TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % TheStarIE._TEST['info_dict']['id'])

    # Test for ThestarIE class
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:27:54.343884
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('TheStarIE')
    ie = TheStarIE(thestarie = 'thestarie')
    assert ie.name == 'TheStarIE'
    assert ie.title == 'thestarie'

# Generated at 2022-06-24 13:28:01.628833
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    instance = ie()
    # check if the class assigned correctly the url and return correctly the url of the video
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    r = instance._real_extract(url)
    assert r.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    # check if the class works correctly with another url
    url2 = "http://www.thestar.com/autos/2016/10/28/this-is-how-the-2017-acura-nsx-will-look.html"
    r2 = instance._real_

# Generated at 2022-06-24 13:28:03.282893
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE(thestar.com) == True)

# Generated at 2022-06-24 13:28:10.955063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert IE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert 'thestar.com' in IE._NETRC_MACHINE
    assert IE._GEO_COUNTRIES == ['CA']


# Generated at 2022-06-24 13:28:17.875366
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:24.326902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test TheStarIE 
    """
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TS = TheStarIE(url)
    assert TS.url == url
    assert TS.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:28.477018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:33.404175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE()
    unit_test._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert unit_test != None


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:28:38.736957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test_TheStarIE is implemented in test_lib.py in the parent directory.
    import os.path
    import sys
    base_path = os.path.dirname(os.path.abspath(os.path.dirname(__file__)))
    test_path = os.path.join(base_path, 'test')
    sys.path.insert(0, test_path)
    import test_lib
    sys.path.pop(0)
    test_lib.run_test(TheStarIE)

# Generated at 2022-06-24 13:28:44.800480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'