

# Generated at 2022-06-24 13:18:47.215458
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:18:49.855015
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    m = TheStarIE(None)
    m._download_webpage("", "")


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:18:55.440416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    correct_TheStarIE = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert correct_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:18:56.135599
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-24 13:18:57.096426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Not implemented
    pass

# Generated at 2022-06-24 13:19:01.105511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(attrs={'ID': '4732393888001'})
    expected_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    url = ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'
    assert url == expected_url

# Generated at 2022-06-24 13:19:04.988735
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE("thestar.com", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", 
        "")
    the_star_ie.extract()

# Generated at 2022-06-24 13:19:08.281242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skin-care-line.html')

test_TheStarIE()

# Generated at 2022-06-24 13:19:14.800076
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # basic tests
    instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert instance.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert instance.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert instance.id == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

    # tests to ensure the URL is in a valid

# Generated at 2022-06-24 13:19:25.995584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE.
    # Raises an error if accessing video information returned unexpected
    # result, that is, if resuls of accessing video information does not
    # contain expected video information.

    TheStarIE_instance = TheStarIE()
    info_dict = TheStarIE_instance.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    if info_dict['id'] != '4732393888001':
        raise AssertionError('id field is wrong')
    if info_dict['ext'] != 'mp4':
        raise AssertionError('ext field is wrong')

# Generated at 2022-06-24 13:19:26.950925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie == "thestarIE"

# Generated at 2022-06-24 13:19:29.811409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE(None)
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:31.465392
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE()

# Generated at 2022-06-24 13:19:39.652050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_dict = {}
    display_id = 'test'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = '<html><p>test_webpage</p><script>mainartBrightcoveVideoId : \'4732393888001\'</script></html>'
    brightcove_id = '4732393888001'
    expect_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    # Call function
    instance = TheStarIE()
    result = instance._real_extract(url)
    # Assert
    assert result['url'] == expect_url

# Generated at 2022-06-24 13:19:47.438034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    input_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_obj = TheStarIE()
    output_url = test_obj._real_extract(input_url)
    result=output_url['url']
    expected_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    # print(result)
    assert expected_result == result

# Generated at 2022-06-24 13:19:51.186528
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_info = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % TheStarIE._TEST['info_dict']['id']).extract()
    assert video_info['title'] == TheStarIE._TEST['info_dict']['title']

# Generated at 2022-06-24 13:19:51.616737
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:19:52.317297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    check_TheStarIE(TheStarIE())


# Generated at 2022-06-24 13:19:53.297650
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	object_TheSarIE = TheStarIE()
	assert object_TheSarIE

# Generated at 2022-06-24 13:19:54.870628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ies = list(TheStarIE._get_ies())
    assert len(ies) == 1

# Generated at 2022-06-24 13:20:04.754216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert TheStarIE._VALID_URL == ie._VALID_URL
    assert TheStarIE._TEST == ie._TEST
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._downloader is None
    assert ie._match_id('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:20:12.941981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Test a url with a single video
    url = 'http://www.thestar.com/opinion/2016/02/02/pandering-to-fear-is-not-the-answer-to-foreign-investment.html'
    ie = TheStarIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    brightcove_id = '4733586414001'
    assert ie._TEST['url'] == url
    assert ie._TEST['md5'] == 'aa28d26b6c2eb01053b74c0d6e3f40ff'
    assert ie._TEST['info_dict']['id'] == brightcove_id
   

# Generated at 2022-06-24 13:20:14.354057
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        assert False, "Exception"

# Generated at 2022-06-24 13:20:16.752719
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(TheStarIE._VALID_URL) != 1

# Generated at 2022-06-24 13:20:25.232223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
	assert ie.brighcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:20:34.601851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=$s"
    # Test the function _real_extract()
    result = ie._real_extract(url)
    assert result["id"] == "4732393888001"
    assert result["uploader_id"] == "794267642001"
    assert result["title"] == "Mankind: Why this woman started a men's skin care line"

# Generated at 2022-06-24 13:20:41.104635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:49.631321
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE')
    ie.set_downloader('test')
    ie.set_test(test=True)
    ie.set_test(test=False)
    ie.set_test()
    ie.add_default_info_extractors()
    ie.set_testurls(['http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'])

# Generated at 2022-06-24 13:20:54.009983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    thestar._match_id(url)

# Generated at 2022-06-24 13:20:57.042225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:59.644550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL is not None
    assert thestar_ie._TEST is not None
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE is not None

test_TheStarIE()

# Generated at 2022-06-24 13:21:08.259677
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/opinion/commentary/2016/02/08/stephen-marche-what-we-lose-when-we-lose-our-family-doctors.html')

# Generated at 2022-06-24 13:21:16.964046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Scenario 1: Brightcove New extractor used to extract info
	# of url
	tc1 = TheStarIE()
	tc1.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	tc1._match_id(url)
	webpage = tc1._download_webpage(url, '4732393888001')

# Generated at 2022-06-24 13:21:20.000432
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "4732393888001")
    assert inst != None


# Generated at 2022-06-24 13:21:25.377150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()
    # Test various assertions
    assert infoExtractor != None
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE != None
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    print("All tests passed!")

# Generated at 2022-06-24 13:21:36.112075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assign
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()

    # Act
    info = ie._real_extract(url)

    # Assert
    assert info['id'] == '4732393888001'
    assert info['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-24 13:21:44.153870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:21:54.396578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:56.838760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert (
        TheStarIE._VALID_URL ==
        "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    )

# Generated at 2022-06-24 13:22:01.768479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info = dict(TheStarIE()._TEST)
    url = test_info['url']
    assert TheStarIE._VALID_URL.match(url)
    id = TheStarIE._VALID_URL.match(url).groupdict()['id']
    assert len(id) > 0
    assert id == "mankind-why-this-woman-started-a-men-s-skincare-line"

# Generated at 2022-06-24 13:22:05.302757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Method to test constructor of class TheStarIE
    testID = 'Mankind: Why this woman started a men\'s skin care line'
    info = TheStarIE()
    info_value = info._match_id(testID)
    assert info_value == '4732393888001'

# Generated at 2022-06-24 13:22:15.117538
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.uploader_id == '794267642001'
    assert ie.brightcove_id == '4732393888001'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.id == '4732393888001'

# Generated at 2022-06-24 13:22:22.928263
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:22:24.893134
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    TheStarIE()

# Generated at 2022-06-24 13:22:27.021231
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.name == 'thestar'
	assert ie.description == 'thestar'
	assert ie.title == 'thestar'

# Generated at 2022-06-24 13:22:33.633408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL)
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:22:43.381993
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	#All of arguments should be set before calling the constructor
	url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	display_id = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	brightcove_id = "4732393888001"
	title = "Mankind: Why this woman started a men's skin care line"
	description = "Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN."
	uploader_id = "794267642001"
	timestamp = "1454353482"

# Generated at 2022-06-24 13:22:44.148696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()

# Generated at 2022-06-24 13:22:53.368480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Unit test for md5
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

    # Unit test for info_dict

# Generated at 2022-06-24 13:22:58.351109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert_equal(the_star_ie.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert_equal(the_star_ie._VALID_URL, 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:23:04.716688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  expected_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

  test = TheStarIE({})
  result = test._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

  if result['url'] != expected_url:
    print('Failed to extract correct url: ' + result['url'] + ' != ' + expected_url)

# Generated at 2022-06-24 13:23:11.281271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = "4732393888001"
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    _brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + video_id
    _info = {"id":"4732393888001","ext":"mp4","title":"Mankind: Why this woman started a men\'s skin care line","description":"Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.","uploader_id":"794267642001","timestamp":1454353482,"upload_date":"20160201"}
    test = TheStarIE()

# Generated at 2022-06-24 13:23:12.017477
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-24 13:23:12.783298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-24 13:23:17.495389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_name() == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:26.543466
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url_test = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:33.686211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
  assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
  assert TheStarIE._TEST['url'] == url
  assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
  assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:23:39.723373
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    name = 'thestar'
    type = 'brightcove:new'
    #print ie._extract_info(name, url, type)

# Generated at 2022-06-24 13:23:41.253997
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test should pass:
    TheStarIE._WORKING = True
    assert TheStarIE() is not None

# Generated at 2022-06-24 13:23:48.998035
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url= r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    regular_url= r'http://www.thestar.com/news/gta/2016/02/02/toronto-poised-for-record-snowfall-warns-weather-network.html'
    ie= TheStarIE()

    # test init
    if not(ie.is_suitable(video_url) and ie.is_suitable(regular_url)):
        raise AssertionError('TheStarIE.is_suitable not working')

# Generated at 2022-06-24 13:23:50.800783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:53.468276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test of TheStarIE constructor"""
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:23:54.340252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:23:58.985590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    video.BRIGHTCOVE_URL_TEMPLATE
    video.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:24:07.844350
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:11.146600
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar=TheStarIE()
    thestar._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:24:12.376559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result != None


# Generated at 2022-06-24 13:24:16.931348
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:22.453451
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_TheStarIE = TheStarIE("https://www.thestar.com/life/technology/2016/01/21/apple-sued-by-university-of-wisconsin-over-a-chip-patent.html")
    assert class_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "Check BRIGHTCOVE_URL_TEMPLATE"
    assert class_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', "Check _VALID_URL"

# Generated at 2022-06-24 13:24:24.725892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .TheStarIE import TheStarIE
    thestar = TheStarIE({})
    assert thestar is not None


# Generated at 2022-06-24 13:24:25.122603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:25.813885
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:24:27.138523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info_extractor = TheStarIE()
	assert info_extractor

# Generated at 2022-06-24 13:24:38.189603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:43.417672
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:44.356998
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-24 13:24:53.051821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for TheStarIE"""
    # Validate that expected test result is returned by constructor
    test_result = TheStarIE._TEST
    
    # Create instance of class TheStarIE
    test_instance = TheStarIE(test_result['url'])
    # Verify that the instance contains the basic properties
    assert test_instance.url == test_result['url']
    assert test_instance._match_id(test_result['url']) == '4732393888001'
    assert test_instance.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test

# Generated at 2022-06-24 13:24:55.856904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE=='http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:05.455117
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:07.214540
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)


# Generated at 2022-06-24 13:25:10.403895
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:11.650992
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    # Constructor should not raise any exception
    assert True

# Generated at 2022-06-24 13:25:12.221839
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:21.264201
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Arrange
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test = TheStarIE._TEST
    TheStarIE._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:23.567335
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:25:25.048228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()  # TODO: check that it raises no exception

# Generated at 2022-06-24 13:25:31.224410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("\nTesting TheStarIE constructor ...\n")
   # Create an object of the TheStarIE class
    thestar_ie_object = TheStarIE();
   # Check if the object was created correctly
    assert an_ie_object != None, "\nError: TheStarIE object was not created correctly"
    print("\nNew object was created correctly\n")

# Generated at 2022-06-24 13:25:41.066796
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:43.212919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:44.683449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:25:53.818434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	''' Unit test for constructor of class TheStarIE '''
	# We create an instance of class TheStarIE
	print("\nUnit test for constructor of class TheStarIE:")
	print("---------------------------------------------")
	theStarIE = TheStarIE()

	# We create an instance of class InfoExtractor using TheStarIE
	print("\nUnit test for constructor of class InfoExtractor:")
	print("-------------------------------------------------")
	infoExtractor = InfoExtractor(theStarIE)

	# We check if the type of the instance is InfoExtractor
	print("\nUnit test for type of class InfoExtractor:")
	print("-------------------------------------------")
	print(type(infoExtractor) is InfoExtractor)


# Generated at 2022-06-24 13:25:54.413311
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:58.131826
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'https://www.thestar.com/entertainment/movies/2016/12/04/la-la-land-review-a-sparkling-tribute-to-old-style-musicals.html'
    TheStarIE(url)

# Generated at 2022-06-24 13:26:02.429323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.constructor == TheStarIE


# Generated at 2022-06-24 13:26:03.776764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert that(TheStarIE.__name__).is_equal_to('TheStarIE')

# Generated at 2022-06-24 13:26:10.542581
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE.TheStarIE()
    test_TheStarIE._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    test_TheStarIE._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)','<script>\nvar\n$(document).ready(function()\n{\nvar\nmainartBrightcoveVideoId = "4732393888001";\n','4732393888001','brightcove id')

# Generated at 2022-06-24 13:26:13.868272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    if ie.BRIGHTCOVE_URL_TEMPLATE is not None:
        print("TheStarIE.BRIGHTCOVE_URL_TEMPLATE has a value")
    else:
        raise ValueError("TheStarIE.BRIGHTCOVE_URL_TEMPLATE is not defined")

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:22.317696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test the constructor of TheStarIE class.
    """
    sample_get_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    sample_get_id = 'Mankind: Why this woman started a men\'s skin care line'
    sample_get_title = 'Mankind: Why this woman started a men\'s skin care line'
    sample_get_description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    sample_get_uploader_id = '794267642001'
    sample_get_timestamp = 1454353482
    sample_get_upload_date = '20160201'
    sample_get_duration = None
   

# Generated at 2022-06-24 13:26:23.358676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:26:34.744958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._TEST['url'] == TheStarIE._VALID_URL

    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

    assert TheStarIE._TEST['info_dict']

    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'
    assert TheStarIE._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert TheStarIE._TEST['info_dict']['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert TheStarIE._

# Generated at 2022-06-24 13:26:38.949140
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE(TheStarIE._VALID_URL)

    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:43.556173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()
    assert extractor.__class__.__name__ == 'TheStarIE'
    assert extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:44.396362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None, None)

# Generated at 2022-06-24 13:26:53.442357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Sample url 
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = ie._download_webpage(url)
    # Check if webpage was downloaded
    assert webpage != None
    # Check for expected return value in _real_extract
    assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')['ext'] == 'mp4'

# Generated at 2022-06-24 13:27:03.132788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  """
  Unit test for constructor of class TheStarIE
  """
  test = TheStarIE()
  assert test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:05.527938
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert theStarIE._VALID_URL
    assert theStarIE._TEST

# Generated at 2022-06-24 13:27:12.000275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:20.454648
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test without video_id
    thestar_ie = TheStarIE()
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test with video_id
    thestar_ie = TheStarIE('4732393888001')
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:27.780153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.ie_key() == 'TheStar'

# Generated at 2022-06-24 13:27:31.068736
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    import os
    #assert(instance.thestar_id == os.path.splitext(os.path.basename(__file__))[0])
    assert(instance.thestar_id == 'thestar')

# Generated at 2022-06-24 13:27:32.252920
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()

# Generated at 2022-06-24 13:27:37.255682
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('TheStarIE test', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    #t._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(t._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))

# Generated at 2022-06-24 13:27:46.844824
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info_dict = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }
    expect_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    test_thestarIE = TheStarIE([])

# Generated at 2022-06-24 13:27:51.731194
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    TheStarIE()._real_initialize()
    print(type(TheStarIE))
    print(TheStarIE._VALID_URL)
    print(TheStarIE.BRIGHT_COVE_URL_TEMPLATE)
    print(TheStarIE._download_webpage)



# Generated at 2022-06-24 13:27:55.621439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of the class
    the_star_ie = TheStarIE()
    # Confirm it is an instance of the InfoExtractor
    assert isinstance(the_star_ie, InfoExtractor)


# Generated at 2022-06-24 13:27:56.507881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())

# Generated at 2022-06-24 13:28:05.596037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test case for constructor of class TheStarIE"""
    # test_TheStarIE_url_is_valid
    test_TheStarIE_url_is_valid = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE_url_is_valid = TheStarIE(test_TheStarIE_url_is_valid)
    assert TheStarIE_url_is_valid._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:12.670925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance, InfoExtractor)
    instance._download_webpage("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "4732393888001")
    instance._real_extract("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:28:14.269655
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE(), InfoExtractor)


# Generated at 2022-06-24 13:28:18.321790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:21.708603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:28:29.662972
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStarIE._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:30.251469
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:28:33.719196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:39.541004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.brightcove_id == "4732393888001"
    assert ie.display_id == "4732393888001"
    assert ie.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert ie._TEST['md5'] == ie.md5(ie._download_webpage(ie.url, ie.display_id))

# Generated at 2022-06-24 13:28:40.649560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.init()

# Generated at 2022-06-24 13:28:42.939808
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception:
        assert False
