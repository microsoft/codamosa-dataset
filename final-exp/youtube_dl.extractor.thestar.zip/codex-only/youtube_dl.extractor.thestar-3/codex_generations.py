

# Generated at 2022-06-24 13:18:42.564579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:18:47.617115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    print(obj)
    _ = obj.BRIGHTCOVE_URL_TEMPLATE
    return True

if __name__ == '__main__':
    t = test_TheStarIE()
    print(t)

# Generated at 2022-06-24 13:18:49.451628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    thestarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:18:52.412527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_object = TheStarIE(TheStarIE._VALID_URL)

# Generated at 2022-06-24 13:18:56.086168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_initialize()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:03.426244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:07.140336
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Unit test for TheStarIE
	"""
	ie = TheStarIE()
	assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:08.073748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:19:13.553694
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Class should recognize the URL according to its regex
    assert ie._is_valid_url(url), "Class failed to recognize Star.com URL according to its regex"
    # Class should return a valid Brightcove URL from the Star.com article
    assert ie._real_extract(url) == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', "Class failed to return a Brightcove URL"

# Generated at 2022-06-24 13:19:14.980094
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    d = TheStarIE()
    assert d

# Generated at 2022-06-24 13:19:17.506957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST)
    obj.suite()


# Generated at 2022-06-24 13:19:19.358281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.IE_NAME == 'thestar.com'

# Generated at 2022-06-24 13:19:21.196326
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Tests for the video downloader
import unittest
from sys import exit

# Generated at 2022-06-24 13:19:25.143583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t = TheStarIE()
	t._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:19:25.767050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:19:28.246353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:29.049813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	

# Generated at 2022-06-24 13:19:31.091523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test_TheStarIE = TheStarIE()
    unit_test_TheStarIE

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:19:32.717385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:19:33.431856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:19:35.927889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:42.428359
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(ie.BRIGHTCOVE_URL_TEMPLATE)
    print(ie._VALID_URL)
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' in ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 13:19:52.425818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from youtube_dl import YoutubeDL
    ydl = YoutubeDL({})
    ie = TheStarIE(ydl)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    with open('test_data/test_url.html', 'r') as url_file:
        url_content = url_file.read().decode('UTF-8')
    html_page = ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    assert html_page == url_content


# Generated at 2022-06-24 13:19:56.849367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    This is more a test for the __init__ for class TheStarIE
    '''
    try:
        thestar_ie = TheStarIE()
    except Exception as e:
        assert e.args[0] == 'No test appears to be defined for TheStarIE extractor'

# Generated at 2022-06-24 13:19:57.563816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:59.585269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:20:01.135664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie



# Generated at 2022-06-24 13:20:04.189030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:07.346247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:20:15.824302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE

    assert_equals(class_._TEST['url'], 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert_equals(class_._TEST['md5'], '2c62dd4db2027e35579fefb97a8b6554')
    assert_equals(class_._TEST['info_dict']['id'], '4732393888001')
    assert_equals(class_._TEST['info_dict']['ext'], 'mp4')
    assert_equals(class_._TEST['info_dict']['title'], 'Mankind: Why this woman started a men\'s skin care line')


# Generated at 2022-06-24 13:20:17.720482
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:26.768825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    url="http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    display_id="4732393888001"
    webpage="""<!DOCTYPE html>
<html>
  <head>
    <title>Mankind: Why this woman started a men's skin care line | Toronto Star</title>
    <meta name="description" content="Robert Cribb talks to Young Lee, the founder of Uncle Peter’s MAN." />
  </head>
<body>
<script type="text/javascript">
window.article = {
    mainartBrightcoveVideoId: 4732393888001
}
</script>
</body>
</html>"""
    bright

# Generated at 2022-06-24 13:20:36.613498
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:38.870186
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test if a TheStarIE object is created
    '''
    obj = TheStarIE()
    assert obj.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:20:48.514123
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:51.990954
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:20:55.690631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:20:58.178215
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        # TheStarIE(InfoExtractor)
        TheStarIE(InfoExtractor)
    except TypeError:
        assert False
    except Exception:
        pass

# Generated at 2022-06-24 13:21:04.833929
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE constructor
    from .test_brightcove import MockBrightcoveNewIE
    TheStarIE.ie_key = 'TheStar'
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/{account_id}/default_default/index.html?videoId={brightcove_id}'
    TheStarIE.ie = MockBrightcoveNewIE
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        {'account_id': '794267642001', 'brightcove_id': '4732393888001'})

# Generated at 2022-06-24 13:21:07.205982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor())._downloader.params['forced_codecs_prefix'] == 'mp4a.40.34-'


# Generated at 2022-06-24 13:21:15.149223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_brightcove import test_brightcove_new

    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    test_brightcove_new(TheStarIE, '794267642001', '4732393888001')

    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    test_brightcove_new(TheStarIE, '794267642001', '4732393888001')

# Generated at 2022-06-24 13:21:16.601291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:19.499732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST).title == 'Mankind: Why this woman started a men\'s skin care line'
    assert TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST).id == '4732393888001'

# Generated at 2022-06-24 13:21:19.912967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:26.514297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test doesn't check the field _VALID_URL because it is not a string
    assert TheStarIE._TEST_URL == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert TheStarIE._TEST_TITLE == "Mankind: Why this woman started a men's skin care line"
    assert TheStarIE._TEST_DESCRIPTION == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert TheStarIE._TEST_BRIGHTCOVE_ID == '4732393888001'
    assert TheStarIE._TEST_UPLOADER_ID == '794267642001'
    assert TheStarIE._TEST_TIMESTAMP == 14

# Generated at 2022-06-24 13:21:37.676369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/news/canada/2016/02/01/ontario-government-to-make-vaccines-mandatory-for-schoolchildren.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == "mankind-why-this-woman-started-a-men-s-skincare-line"
    # Constructor of class InfoExtractor should not be called.

# Generated at 2022-06-24 13:21:38.526452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Checking the constructor of class TheStarIE
    ie = TheStarIE()

# Generated at 2022-06-24 13:21:48.192353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    result = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result.get('id') == '4732393888001'
    assert result.get('title') == 'Mankind: Why this woman started a men\'s skin care line'
    assert result.get('description') == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert result.get('uploader_id') == '794267642001'
    assert result.get('upload_date') == '20160201'
    assert result.get('ext') == 'mp4'

# Generated at 2022-06-24 13:21:51.058197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.BRIGHTCOVE_URL_TEMPLATE
    thestar._VALID_URL
    thestar._TEST

# Generated at 2022-06-24 13:21:54.152681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:56.977996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()
    assert tester.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:03.900933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:07.529900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:12.327051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:13.868675
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:14.991430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	x = TheStarIE()

# Generated at 2022-06-24 13:22:17.861721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    xt = TheStarIE()
    assert xt.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:18.716330
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:19.173049
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:21.695600
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:23.780304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    c = TheStarIE()
    c._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:22:25.779007
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None, 'Failed to instantiate TheStarIE'


# Generated at 2022-06-24 13:22:34.095827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ids = ['4732393888001']
    for ID in ids:
        try:
            ie.url_result(ie.BRIGHTCOVE_URL_TEMPLATE % ID, 'BrightcoveNew', ID)
        except BaseException as e:
            print(e)
        print(ie.download_webpage(ie.BRIGHTCOVE_URL_TEMPLATE % ID, ID))

# Generated at 2022-06-24 13:22:34.709265
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:22:42.642868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	from .TheStarIE import TheStarIE
	from .common import InfoExtractor
	
	#url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	url = "http://www.thestar.com/news/world/2016/09/22/us-election-2016-how-to-watch-the-first-presidential-debate.html"
	thestar = TheStarIE()
	thestar._match_id(url)
	thestar._real_extract(url)
	

# Generated at 2022-06-24 13:22:44.704304
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:22:51.855862
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:22:58.807341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

    assert instance.get_metadata_value('id') == '4732393888001'
    assert instance.get_metadata_value('ext') == 'mp4'
    assert instance.get_metadata_value('title') == 'Mankind: Why this woman started a men\'s skin care line'
    assert instance.get_metadata_value('description') == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert instance.get_metadata_value('uploader_id') == '794267642001'
    assert instance.get_metadata_value('timestamp') == 1454353482
    assert instance.get_metadata_value('md5') == '2c62dd4db2027e35579fefb97a8b6554'
    assert instance.get_metadata_value

# Generated at 2022-06-24 13:23:07.380986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._test_matches('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == True

# Generated at 2022-06-24 13:23:08.680621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE is not None 

test_TheStarIE()

# Generated at 2022-06-24 13:23:14.261553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:23:15.591165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:23:23.465267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test case when the html page is downloaded successfully
    def test_download_success(self):
        # Test function _real_extract of TheStarIE
        def test_real_extract_success(self):
            # Test case when brightcove id is extracted successfully
            def test_real_extract_brightcove_success(self):
                # Test case when brightcove id is extracted successfully
                def test_brightcove_id_success(self, brightcove_id):
                    # Dummy thestar html file
                    html_filename = 'thestar.html'
                    # Dummy thestar url
                    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
                    # Dummy brightcove

# Generated at 2022-06-24 13:23:32.098086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Display id for url `http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html`
    display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
    # Http url for url `http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html`
    http_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Brightcove id from webpage of html content `<script type='text/javascript

# Generated at 2022-06-24 13:23:39.181878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/fashion_style/2015/02/02/how-to-keep-warm-and-stylish-in-a-toronto-winter.html'

    # Test for explicit constructor call
    ie = TheStarIE(url)

    # Make sure it returns an instance of class InfoExtractor
    assert isinstance(ie, InfoExtractor)

    # Make sure it returns the expected extractor id
    assert ie.ie_key() == 'TheStar'


# Generated at 2022-06-24 13:23:41.749452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Make sure that TheStarIE can be instantiated.
	TheStarIE()
	# Make sure that TheStarIE can be instantiated more than once.
	TheStarIE()


# Generated at 2022-06-24 13:23:43.080208
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.get_url()

# Generated at 2022-06-24 13:23:51.845632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test for the _VALID_URL attribute of TheStarIE class
    thestar_valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Test for the _TEST attribute of TheStarIE class

# Generated at 2022-06-24 13:23:53.242750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	global TheStarIE
	TheStarIE = TheStarIE()

# Generated at 2022-06-24 13:24:03.364532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    downloader = InfoExtractor()
    downloader.add_info_extractor(TheStarIE())
    result = downloader.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(result['id'] == '4732393888001')
    assert(result['ext'] == 'mp4')
    assert(result['title'] == 'Mankind: Why this woman started a men\'s skin care line')
    assert(result['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.')
    assert(result['uploader_id'] == '794267642001')
    assert(result['timestamp'] == 1454353482)

# Generated at 2022-06-24 13:24:08.263474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():#, returned_value):
    obj = TheStarIE()
    assert obj.__class__.__name__ == 'TheStarIE'
    obj.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._match_id(obj.url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:24:13.652273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 13:24:15.800987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:24:17.186380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

# Generated at 2022-06-24 13:24:22.429385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # testing if constructor is working or not
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s", "Constructor is not working.\n"


# Generated at 2022-06-24 13:24:25.894261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:29.800921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie is not None)
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Unit tests for url extraction

# Generated at 2022-06-24 13:24:39.172826
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:24:42.364825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:24:42.929174
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:46.837710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None, None)
    expected_URL = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert expected_URL == ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'

# Generated at 2022-06-24 13:24:48.159513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:24:49.503854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'

# Generated at 2022-06-24 13:24:50.004850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:51.496493
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    the_star.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:24:52.437505
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE();

# Generated at 2022-06-24 13:24:57.061988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('www.thestar.com', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:57.601871
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:00.620099
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:05.757240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:13.639123
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')['url'])

# Generated at 2022-06-24 13:25:17.041052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    assert test_object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:17.621164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:18.123002
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:27.949454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "%s/"
    # The path is the display id
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-24 13:25:29.069124
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()



# Generated at 2022-06-24 13:25:34.414826
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of class TheStarIE"""
    ie = TheStarIE()
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:25:37.273894
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert unit.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s", "TheStarIE.BRIGHTCOVE_URL_TEMPLATE key should be 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'"

# Generated at 2022-06-24 13:25:42.151382
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test an example url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Test that the url is correctly detected
    assert(ie.suitable(url))
    # Test that the download function can be called
    ie.download(url)

# Generated at 2022-06-24 13:25:47.551298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    class TestTheStarIE(unittest.TestCase):
        def test_constructor(self):
            try:
                TheStarIE()
            except TypeError:
                self.fail('TheStarIE:Error:TheStarIE constructor failed')

    unittest.main()

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:25:50.840431
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:53.582659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download("http://www.thestar.com/business/2016/03/09/calgary-at-forefront-of-homebuilding-innovation.html")

# Generated at 2022-06-24 13:26:04.453503
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of class TheStarIE
    thestar_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Checks the values of variables
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:05.752312
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:16.161991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:20.983844
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for just one content webpage
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._download_webpage(url, 'test')
    # Test for all article webpages
    # Test for malformed URL
    # Test for not found webpage
    # Test for generic URL

# Generated at 2022-06-24 13:26:25.288403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:26:27.723920
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    p = t.BRIGHTCOVE_URL_TEMPLATE
    print (p)

# Generated at 2022-06-24 13:26:28.714098
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()


# Generated at 2022-06-24 13:26:30.279405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # To check if the constructor raises no exceptions
    TheStarIE([], {})

# Generated at 2022-06-24 13:26:31.173657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_instance = TheStarIE({})
	assert isinstance(test_instance, InfoExtractor)

# Generated at 2022-06-24 13:26:39.089034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    webpage = ie._download_webpage(url, "4732393888001")
    brightcove_id = ie._search_regex(
            r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            webpage, 'brightcove id')
    assert brightcove_id == "4732393888001"

# Generated at 2022-06-24 13:26:47.461445
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == (
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:48.350398
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    assert e

# Generated at 2022-06-24 13:26:58.868871
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # input: url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # expected output: id and url
    expt_id = '4732393888001'
    expt_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

    # instantiate object
    the_star = TheStarIE()

    # call function
    actual_id, actual_url = the_star.get_brightcove_id_and_url(url)

    # compare actual and expected
    assert actual_id == expt_id
    assert actual_url == expt_url

# Generated at 2022-06-24 13:27:07.466706
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._downloader, urllib.parse.urlparse('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.suitable == True
    #assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:11.324923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:17.725731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Access to protected field (Class._field)
    info_extractor = TheStarIE._build_brighcove_url(TheStarIE.BRIGHTCOVE_URL_TEMPLATE, "4732393888001")
    assert info_extractor == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:27:21.407278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert not TheStarIE._match_id("http://www.thestar.com/fake.html" )
    assert "4732393888001" == TheStarIE._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:27:26.924353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    print ("thestar test passed.")

# Test for _real_extract

# Generated at 2022-06-24 13:27:36.860908
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Pass video_id as the url because url and id are required in VideoInfo
    url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    theStar = TheStarIE()
    # extract and test the video_url
    theStar.url = url
    theStar._downloader = None
    theStar._real_initialize()
    assert(theStar.url == url)
    assert(theStar._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-24 13:27:40.606059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('test')
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:44.702038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:27:47.568410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:52.376787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._BUILD_REQUEST(TheStarIE._TEST['url']).url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-24 13:28:00.808893
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:02.959120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assert that the constructor of TheStarIE does not throw an exception.
    assert TheStarIE()

# Generated at 2022-06-24 13:28:12.976339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of class TheStarIE
    obj = TheStarIE()
    assert obj is not None

    # Test constants on class TheStarIE
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:14.268989
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This constructor should do nothing
    TheStarIE(None)

# Generated at 2022-06-24 13:28:24.820909
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()._real_initialize()
    assert t._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:30.587025
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE("")
    thestarIE.BRIGHTCOVE_URL_TEMPLATE
    thestarIE._VALID_URL
    thestarIE._TEST['url']
    thestarIE._TEST['md5']
    thestarIE._TEST['info_dict']
    thestarIE._TEST['params']


# Generated at 2022-06-24 13:28:31.616980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(object)

# Generated at 2022-06-24 13:28:33.118989
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE(InfoExtractor())



# Generated at 2022-06-24 13:28:33.813847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:28:37.952952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:47.393059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'