

# Generated at 2022-06-24 13:18:51.883997
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:18:55.122614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:18:56.542193
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie != None)

# Generated at 2022-06-24 13:18:57.844871
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert "thestar.com" in ie.IE_NAME



# Generated at 2022-06-24 13:18:59.645427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:00.971019
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t is not None

# Generated at 2022-06-24 13:19:02.306436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE(InfoExtractor())
    assert theStarIE is not None

# Generated at 2022-06-24 13:19:06.200730
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = InfoExtractor(TheStarIE.ie_key())
    ie_new = ie.ie_key()
    # check that we have a brand new ie after new()
    assert ie_new != ie
    # check if the name of ie is correct
    assert ie_new.IE_NAME == 'thestar'

# Generated at 2022-06-24 13:19:09.262038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    input_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    _ = TheStarIE(input_url)

# Generated at 2022-06-24 13:19:19.546610
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # normal URL
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # special URL
    ie = TheStarIE(url='http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393892001')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # but invalid URL
    ie = TheStarIE(url='http://www.thestar.com/life/')
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:19:29.729657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarTest = TheStarIE("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    theStarTest._download_webpage("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:19:34.566258
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:36.556070
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None

# Generated at 2022-06-24 13:19:41.237726
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732411484001', '4732411484001')

# Generated at 2022-06-24 13:19:45.215362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor
    # Should initialize local variables
    loader = TheStarIE()
    assert(loader.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:19:48.233269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:51.143973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:52.578644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for user-defined class TheStarIE
    TheStarIE(None, None)._real_initialize()

# Generated at 2022-06-24 13:19:53.086741
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:56.370120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.url.startswith('http://players.brightcove.net/')
    assert ie.display_id == '4732393888001'

# Generated at 2022-06-24 13:20:07.086049
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    #assert ie._valid_url(url), "URL should be valid, %s" % url
    assert ie.match_id(url) == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
    
    # Downloading a video
    ie.download(url)

    # Downloading a video with a proxy
    ie.download(url, proxy_host="192.168.0.4", proxy_port=80)

    # Downloading a video with a password
    ie.download(url, username='foo', password='bar')




# Unit

# Generated at 2022-06-24 13:20:09.466133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarie = TheStarIE()
    assert thestarie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:20:19.646545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Construct instance of class TheStarIE
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:21.493460
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE with valid url
    # TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    pass

# Generated at 2022-06-24 13:20:22.095463
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:26.148986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''See https://github.com/rg3/youtube-dl/blob/master/youtube_dl/YoutubeDL.py
    '''
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:20:27.008949
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:20:30.091247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:40.839278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''Unit Test for the constructor of TheStarIE class.'''
    # Test with missing parameters
    test_thestarie_missing_params = TheStarIE(None, None)

    if test_thestarie_missing_params is None:
        raise ValueError('Missing parameters should raise exception.')
    elif test_thestarie_missing_params.name != 'thestar':
        raise ValueError('Missing parameters should raise exception.')
    elif test_thestarie_missing_params.host != 'www.thestar.com':
        raise ValueError('Missing parameters should raise exception.')

    # Test with valid parameters

# Generated at 2022-06-24 13:20:42.090192
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unitTest = InfoExtractor()
    assert unitTest is not None

# Generated at 2022-06-24 13:20:44.533513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.VALID_URL == TheStarIE._VALID_URL.decode('unicode_escape')

# Generated at 2022-06-24 13:20:46.289662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE('TheStar')
    assert thestar_ie

# Generated at 2022-06-24 13:20:54.300119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:58.088242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Unit test to check class TheStarIE """
    TheStarIE()._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:00.912556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Testing for TheStarIE.__init__ method
    """
    # testing for invalid input values
    assert TheStarIE(None)._VALID_URL is None
    assert TheStarIE('test').VALID_URL == r'^https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html$'

# Generated at 2022-06-24 13:21:03.887220
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:21:04.429633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:13.560000
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:16.657279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_url = TheStarIE()
	test_url._real_extract('http://www.thestar.com/news/gta/2016/04/11/blaine-high-school-student-killed-on-highway-13-near-toronto.html')


# Generated at 2022-06-24 13:21:20.703725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Returns the instance of class TheStarIE
    """
    test_url_1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = TheStarIE()
    instance.url = test_url_1
    return instance


# Generated at 2022-06-24 13:21:27.691439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    inst = TheStarIE(url)
    display_id = inst.display_id
    brightcove_id = inst._match_id(url)
    assert display_id == brightcove_id
    ret = inst._real_extract(url)
    assert ret['id'] == brightcove_id
    assert inst.BRIGHTCOVE_URL_TEMPLATE % brightcove_id == ret['url']

# Generated at 2022-06-24 13:21:31.293614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:37.965450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert(ie._VALID_URL == (r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'));
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == ('http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'));


# Generated at 2022-06-24 13:21:43.617689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.display_id() == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.url_result() == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"

# Generated at 2022-06-24 13:21:46.944749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._extract_brightcove_url('http://www.thestar.com/life/2016/02/01/sisters-had-their-pictures-taken-on-the-same-day-for-40-years.html')

# Generated at 2022-06-24 13:21:54.025766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE % thestar_ie._match_id(url) == expected

# Generated at 2022-06-24 13:21:54.635461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:22:00.519009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # This URL is from the example in the docstring of class TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url, '7', '9')
    assert ie.matchUrl(url) == True
    assert ie._real_extract(url) == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:22:08.181729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for testing constructor of class TheStarIE"""
    ie = TheStarIE(TheStarIE._downloader, TheStarIE._TEST['url'])

    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie._downloader is not None
    assert ie._match_id("") is None
    assert ie._real_extract("") is not None



# Generated at 2022-06-24 13:22:10.563456
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Creating a unit test for the constructor
    # of the class TheStarIE
    thestar = TheStarIE(TheStarIE._downloader)
    assert thestar is not None

# Generated at 2022-06-24 13:22:11.082747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:12.421216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 13:22:14.491149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #tstar = TheStarIE('<html>test</html>')
    print('constructor is OK')

# Generated at 2022-06-24 13:22:17.402017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None, None, {}).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:22:24.534106
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.__class__.__name__ == "TheStarIE"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:34.606426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r = TheStarIE()
    assert r._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    #assert r._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert r._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert r._TEST['info_dict']['id'] == '4732393888001'
    assert r._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:22:38.078034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert(thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:22:39.844334
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: Add something more meaningful here than just check if the class can be initialized.
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-24 13:22:47.041362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE(1, "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", 2)
    assert unit_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert unit_test.VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:22:53.128245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
    assert ie._match_id('http://www.thestar.com/entertainment/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'


# Generated at 2022-06-24 13:22:53.881306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:23:02.386795
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Constructor of the class TheStarIE
	"""
	_TheStarIE = TheStarIE()
	assert _TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:03.506411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')
    assert hasattr(ie, '_VALID_URL')


# Generated at 2022-06-24 13:23:06.161797
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # It's strange that it seems no assert statement in this test is executed
    thestar= TheStarIE()
    thestar._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')



# Generated at 2022-06-24 13:23:11.719869
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test for the regular expression in _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test for the dictionary type of variable '_TEST'
    assert type(ie._TEST) == dict
    # Test for the regular expression in BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:20.779005
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url_test = TheStarIE(test_url)
    assert url_test._match_id(test_url) == '4732393888001'
    assert url_test._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', r'<script>var mainartBrightcoveVideoId = "4732393888001";</script>', 'brightcove id') == '4732393888001'

# Generated at 2022-06-24 13:23:29.539530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_dict = {'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'}
    test = TheStarIE(test_dict)
    assert test.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # assert test.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # assert 0


# Generated at 2022-06-24 13:23:32.003866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.ie_key()
    ie._html_search_regex()
    ie._search_regex()


# Generated at 2022-06-24 13:23:42.086141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
    print('crawler.py test_TheStarIE 1')
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    print('crawler.py test_TheStarIE 2')
    ie._real_extract('http://www.thestar.com/news/canada/2016/03/01/new-elgin-street-patio-will-be-longest-in-canada-restaurant-says.html')

   

# Generated at 2022-06-24 13:23:42.766586
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:51.518181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test constructor of class TheStarIE
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:52.252512
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:23:54.324803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._TEST
    ie._TEST['url']

# Generated at 2022-06-24 13:23:58.226482
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    pass

# Generated at 2022-06-24 13:24:02.330782
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the constructor of TheStarIE
    # TheStarIE.__init__(TheStarIE) should return None
    ie = TheStarIE()
    ie
    # ie should be an instance of TheStarIE
    assert ie is not None and isinstance(ie, TheStarIE)


# Generated at 2022-06-24 13:24:03.625214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().get_supported_extensions() == ['mp4']

# Generated at 2022-06-24 13:24:08.859204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie =  TheStarIE(TheStarIE._create_get_info(TheStarIE._VALID_URL), None)._real_extract(url)
    assert ie == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:24:09.741215
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-24 13:24:13.103932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsie = TheStarIE()
    assert tsie.BRIGHTCOVE_URL_TEMPLATE=='http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:15.533931
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE()._real_extract(video_url)

# Generated at 2022-06-24 13:24:19.071619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:23.333388
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie) == TheStarIE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:27.036949
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	the_star_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:28.554060
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_instance = TheStarIE()
    print("Class = ", class_instance)

# Unit testing

# Generated at 2022-06-24 13:24:39.974259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            '<script>\nvar mainartBrightcoveVideoId = "4732393888001"\n</script>', 'brightcove id')
    ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
            'BrightcoveNew', '4732393888001')

# Generated at 2022-06-24 13:24:45.344259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    expected_result = '4732393888001'
    actual_result = test.BRIGHTCOVE_URL_TEMPLATE[-13:-2]
    assert expected_result == actual_result

# Generated at 2022-06-24 13:24:45.978105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:51.106862
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:24:51.481151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:59.888061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:09.075788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:13.091223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL
    assert ie._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:25:15.291040
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test for constructor of class TheStarIE
    """
    TheStarIE(InfoExtractor())

# Generated at 2022-06-24 13:25:22.599160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE(
        r'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(test_TheStarIE._TEST)
    assert(test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(test_TheStarIE._real_extract)

# Generated at 2022-06-24 13:25:25.592620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:29.988504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:31.095163
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL

# Generated at 2022-06-24 13:25:40.950129
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = '4732393888001'

    # Test the class constructor, which should go and find the brightcove_id for the given URL.
    the_star_ie = TheStarIE(url)

    # Test the get_display_id() method of the class
    assert the_star_ie.get_display_id() == display_id

    # Test the get_brightcove_id() method of the class, by comparing it to the known id

# Generated at 2022-06-24 13:25:41.445940
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:47.026314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST

# Generated at 2022-06-24 13:25:48.534784
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_ie = TheStarIE()
	assert(test_ie != None)
	return

# Generated at 2022-06-24 13:25:49.561810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance

# Generated at 2022-06-24 13:25:52.382777
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:25:55.480314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    curl = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:26:00.390529
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    if ie.BRIGHTCOVE_URL_TEMPLATE:
        assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE.find('%s') > 0

# Generated at 2022-06-24 13:26:02.307842
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(url)

# Generated at 2022-06-24 13:26:05.438622
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:07.960948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:14.414011
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/news/2015/05/25/rob-ford-i-just-want-to-apologize-to-the-people-of-toronto.html"
    thestar_ie = TheStarIE(url)
    assert thestar_ie
    assert thestar_ie.url == url
    assert thestar_ie.display_id == 'rob-ford-i-just-want-to-apologize-to-the-people-of-toronto'



# Generated at 2022-06-24 13:26:22.740544
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:26.995489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None
    print("TheStarIE() instantiated successfully")

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:31.359142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert hasattr(instance, '_download_webpage')
    assert hasattr(instance, '_search_regex')
    assert hasattr(instance, 'BRIGHTCOVE_URL_TEMPLATE')
    assert hasattr(instance, '_match_id')

# Generated at 2022-06-24 13:26:35.478911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert obj.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert type(obj.webpage) == unicode
    assert obj.brightcove_id == "4732393888001"

# Generated at 2022-06-24 13:26:38.256089
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = '#'

    ie._download_webpage = lambda a,b: '<html></html>'
    ie._search_regex = lambda c,d,e: '4732393888001'

    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:41.048727
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:26:41.793323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _TheStarIE = TheStarIE()

# Generated at 2022-06-24 13:26:42.696559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert('TheStarIE', TheStarIE)


# Generated at 2022-06-24 13:26:47.713702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    path = r'C:\Users\abhishek\Downloads\test.html'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = TheStarIE()
    obj._download_webpage(url, path)

# Generated at 2022-06-24 13:26:48.971911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:26:50.204726
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    test_TheStarIE = TheStarIE()

# Generated at 2022-06-24 13:27:00.449303
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = thestar.TheStarIE()

	#assert '__main__' == __name__
	#assert not obj.is_logged_in()
	#assert obj.username == 'example'
	#assert obj.password == 'example'
	#assert obj.geo_verification_headers() == {}
	#assert obj.geo_bypass(False)
	#assert obj.geo_bypass(True)
	#assert obj.parse_age_limit() is None
	#assert obj.parse_count() == (None, None)
	#assert obj.parse_duration() == None
	#assert obj.parse_filesize() == None
	#assert obj.parse_formats() == []
	#assert obj.parse_hex_digits() == []
	#assert obj.parse_json(None) ==

# Generated at 2022-06-24 13:27:04.334225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # run TheStar IE
    TheStarIE().download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-24 13:27:09.849308
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.remote_video_url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')

# Generated at 2022-06-24 13:27:19.421770
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test case with valid URL
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert theStarIE.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert theStarIE.IE_NAME == 'TheStar'
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:25.835618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert isinstance(the_star_ie, InfoExtractor)
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:27:29.345462
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None, {}, {})

    # Tested method
    obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:32.565919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:38.988271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert str(ie) == 'Brightcove:BrightcoveNew'
    assert ie._VALID_URL == '^https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html$'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:42.245878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:44.195771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.test()

# Unit test to extract the data from class TheStarIE

# Generated at 2022-06-24 13:27:45.158175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()


# Generated at 2022-06-24 13:27:51.992952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Call constructor of class to be unit tested
    thestar_ie = TheStarIE()

    # Check attributes are set, and set to the right values
    assert thestar_ie.ie_key() == 'thestar'
    assert thestar_ie.ie_desc() == 'The Star'

    # Check _VALID_URL
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Check _TEST

# Generated at 2022-06-24 13:27:53.477330
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE();
    assert test_obj != None


# Generated at 2022-06-24 13:27:58.613183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    expected = 'Mankind: Why this woman started a men\'s skin care line'
    info = ie._og_search_title(ie.downloader.cache.load(ie.url))
    assert info == expected

# Generated at 2022-06-24 13:27:59.621370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.example.com/')

# Generated at 2022-06-24 13:28:01.097183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)


# Generated at 2022-06-24 13:28:11.726590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for _VALID_URL class attribute of TheStarIE
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Test for _TEST class attribute of TheStarIE

# Generated at 2022-06-24 13:28:22.559017
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    brightcove_url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = brightcove_url
    
    # Test normal use case
    
    # TheStarIE.url = 
    # TheStarIE.extract = 
    # assert TheStarIE.url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    # assert result[0] = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    # assert result[1] = "BrightcoveNew"
   

# Generated at 2022-06-24 13:28:27.559912
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Raises an error if the URL does not match the regex
    TheStarIE('http://www.thestar.com/')



# Generated at 2022-06-24 13:28:29.880285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStare_obj = TheStarIE(0)
    assert test_TheStare_obj.__class__ == TheStarIE

# Generated at 2022-06-24 13:28:38.536207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    check_ie = TheStarIE()
    assert check_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert check_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:43.362226
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'