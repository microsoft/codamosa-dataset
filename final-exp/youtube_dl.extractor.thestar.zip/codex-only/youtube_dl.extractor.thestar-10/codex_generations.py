

# Generated at 2022-06-24 13:18:46.287825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        assert unicode(TheStarIE) == ''
    except Exception as inst:
        assert False

# Generated at 2022-06-24 13:18:51.368437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(ie.BRIGHTCOVE_URL_TEMPLATE)
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-24 13:18:53.869008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert ie._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-24 13:18:58.862127
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie._match_id(url) == display_id

# Generated at 2022-06-24 13:19:04.706268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    info = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info['id'] == '4732393888001'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-24 13:19:05.264559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:19:13.225853
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for the constructor and get_brightcove_video_id for the TheStarIE class
    """
    # Example of a video with a brightcove video id
    video_with_brightcove_id = TheStarIE()
    video_with_brightcove_id.get_brightcove_video_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

    # Example of a video without a brightcove video id
    video_without_brightcove_id = TheStarIE()

# Generated at 2022-06-24 13:19:24.397109
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:19:24.992807
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:25.614101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:26.142272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:28.478147
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:19:30.875558
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:39.216521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:40.389404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r = TheStarIE()

# Generated at 2022-06-24 13:19:41.324551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert 'TheStarIE' in globals()

# Generated at 2022-06-24 13:19:50.296742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.video_id == '4732393888001'
    assert ie.brightcove_id == '4732393888001'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:19:52.724217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:53.416369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    print(i)

# Generated at 2022-06-24 13:20:05.168005
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._downloader)._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:13.118879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # constructor with valid URL
    valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_instance = TheStarIE(valid_url)
    assert test_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:17.393087
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStar(url=s)

# Generated at 2022-06-24 13:20:19.097813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract_urls()
    ie.extract_urls()

# Generated at 2022-06-24 13:20:22.538104
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:20:30.754283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #input parameter
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    #attributes of TheStarIE
    ie = TheStarIE()
    ie.ie_key = 'TheStar'
    ie.ie_desc = 'The Toronto Star is Canada\'s largest daily newspaper, with one of the largest readerships in the country.'
    ie._WORKING = True

    #methods of InfoExtractor
    ie._downloader = None
    ie._download_webpage = None
    ie._html_search_regex = None
    ie._html_search_meta = None
    ie._html_search_meta = None
    ie._html_search_meta = None
    ie._html_search_

# Generated at 2022-06-24 13:20:38.876900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #url = 'http://www.thestar.com/videozone/4685702666001/beauty-mark-05-08-2015.html'
    url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)

# Generated at 2022-06-24 13:20:43.313365
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:46.925828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()
    assert(info.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:20:54.252288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL is not None
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:20:58.377489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._extract_brightcove_url('', '4732393888001')

# Generated at 2022-06-24 13:21:01.531397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE

    # Check the constructor
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = class_(url)

# Generated at 2022-06-24 13:21:03.642991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.youtube.com/watch?v=BaW_jenozKc")
    assert ie._is_valid()


# Generated at 2022-06-24 13:21:06.490903
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:07.207479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:08.831764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # positive test
    assert True
    # negative test
    assert False


# Generated at 2022-06-24 13:21:17.184975
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the constructor can get the right result without any exceptions being raised.
    assert TheStarIE('http://www.thestar.com/news/gta/2016/02/01/toronto-weather-feb-1-2016.html').display_id == 'toronto-weather-feb-1-2016'
    # Test if the constructor can get the right result with just the string of URL being passed in.
    assert TheStarIE('https://www.thestar.com/business/2016/02/01/why-oakville-brett-wilson-is-starting-an-investment-fund.html').display_id == 'why-oakville-brett-wilson-is-starting-an-investment-fund'
    # Test if the constructor can get the right result with a group of parameters being passed in.
    assert The

# Generated at 2022-06-24 13:21:18.341248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_instance = TheStarIE()
    assert ie_instance is not None

# Generated at 2022-06-24 13:21:21.683766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', ('4732393888001', '794267642001', '1454353482'))


# Generated at 2022-06-24 13:21:22.495324
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test.suite()

# Generated at 2022-06-24 13:21:29.733082
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of class TheStarIE
    # Create an instance of class TheStarIE
    ie = TheStarIE({})
    # Test whether name field is set by TheStarIE
    assert ie.name == 'thestar'
    # Test whether ie_key field is set by TheStarIE
    assert ie.ie_key == 'thestar'
    # Test whether the ie_key field is set by TheStarIE
    assert ie.ie_key == 'thestar'
    # Test whether the ie_key field is set by TheStarIE
    assert ie.ie_key == 'thestar'

# Generated at 2022-06-24 13:21:30.910635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-24 13:21:34.139731
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:21:36.393357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:21:39.142343
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL

# Generated at 2022-06-24 13:21:48.551195
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", {})
    soup = ie._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "")
    expected_url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert(soup.find('div', id="mainartBrightcoveVideoId").attrs.get('value') == "4732393888001")

# Generated at 2022-06-24 13:21:49.557567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert type(TheStarIE(None) is not None)

# Generated at 2022-06-24 13:21:58.384156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == TheStarIE._VALID_URL
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:22:03.861785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print('TheStarIE')
    print('\tUnit test for constructor of class TheStarIE')
    print('\t\t' + (True == len(TheStarIE._VALID_URL) > 0))
    print('\t\t' + (True == len(TheStarIE._TEST) > 0))
    print('\t\t' + (True == len(TheStarIE.BRIGHTCOVE_URL_TEMPLATE) > 0))

# Generated at 2022-06-24 13:22:13.742262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:16.862306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    except:
        assert False

# Generated at 2022-06-24 13:22:19.628731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:22:20.379058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-24 13:22:22.213863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE(InfoExtractor)
    except (TypeError, AttributeError) as e:
        return False
    return True


# Generated at 2022-06-24 13:22:24.339101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None

# Generated at 2022-06-24 13:22:27.550394
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_cases = (
        (TheStarIE, (1, 3)),
        (TheStarIE, (6,)),
    )
    for test_case in test_cases:
        assert len(test_case[1]) == test_case[0]()._TEST['url']

# Generated at 2022-06-24 13:22:38.397750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:41.122599
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage = lambda *a, **k: None
    ie._search_regex = lambda *a, **k: None
    ie._get_info = lambda *a, **k: None

# Generated at 2022-06-24 13:22:43.757291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(result)

# Generated at 2022-06-24 13:22:44.536636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:46.624566
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/travel/2016/02/02/these-are-the-worlds-top-10-ski-resorts.html')

# Generated at 2022-06-24 13:22:49.509883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()(url)

# Generated at 2022-06-24 13:22:52.236280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:22:52.767200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:53.289765
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:22:54.039988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-24 13:22:54.793025
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:58.083425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test constructor of class TheStarIE
    '''
    thestar = TheStarIE()
    assert thestar.url_result
    assert thestar.BRIGHTCOVE_URL_TEMPLATE
    assert thestar._VALID_URL
    assert thestar._TEST

# Generated at 2022-06-24 13:22:58.610379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:04.298985
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests an url and checks that the result is equal to the expected one
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = TheStarIE()._real_extract(url)


    assert result['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:23:06.368623
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:23:16.413716
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:18.521517
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:20.717646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:23:23.662843
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:23:27.106785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:29.616234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:23:39.639007
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(InfoExtractor())
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:40.919283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Check if the object TheStarIE is created
	obj = TheStarIE(None)
	assert obj != None
	assert type(obj) == TheStarIE

# Generated at 2022-06-24 13:23:41.791264
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:23:43.119443
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:46.028137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:23:53.855273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:55.343095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    info_extractor.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:59.034509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_name = TheStarIE.__name__
    constructor_args = {class_name: [],}
    instance = TheStarIE(class_name, constructor_args)


# Generated at 2022-06-24 13:24:07.880427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .constructor import _make_result
    # Test for the star extractor
    tsie = TheStarIE()
    assert tsie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:09.401125
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of TheStarIE.
    This should not fail.
    """
    TheStarIE()

# Generated at 2022-06-24 13:24:17.973984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test for the class object creation of TheStarIE
	thestar = TheStarIE()
	assert thestar
	assert isinstance(thestar, InfoExtractor)
	assert hasattr(thestar, '_VALID_URL')
	assert thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert hasattr(thestar, '_TEST')

# Generated at 2022-06-24 13:24:18.674555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Initialize class
  TheStarIE()

# Generated at 2022-06-24 13:24:28.900873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    print(type(thestar_ie))
    print(type(thestar_ie._VALID_URL))
    print(type(thestar_ie._TEST))
    print(type(thestar_ie._TEST['url']))
    print(type(thestar_ie._TEST['md5']))
    print(type(thestar_ie._TEST['info_dict']))
    print(type(thestar_ie._TEST['info_dict']['id']))
    print(type(thestar_ie._TEST['info_dict']['ext']))
    print(type(thestar_ie._TEST['info_dict']['title']))
    print(type(thestar_ie._TEST['info_dict']['description']))
   

# Generated at 2022-06-24 13:24:35.441237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'



# Generated at 2022-06-24 13:24:39.236999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:24:42.838222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert isinstance(obj, TheStarIE)


# Generated at 2022-06-24 13:24:51.846380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert isinstance(x, TheStarIE)
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert x._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:55.973233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:59.324921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    # Just for testing
    obj.test_real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:07.781122
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage = lambda url: None
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_display_id = ie._match_id(test_url)
    assert test_display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:10.701992
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:11.605216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    temp_instance = TheStarIE()

# Generated at 2022-06-24 13:25:12.529165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE();

# Generated at 2022-06-24 13:25:16.367794
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:17.663578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	class_TheStarIE = TheStarIE('TheStarIE')


# Generated at 2022-06-24 13:25:21.651568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:24.706532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    try:
        TheStarIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 13:25:26.576792
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        raise AssertionError("Construtor of class TheStarIE didn't work.")

# Generated at 2022-06-24 13:25:30.468471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE_test_data = TheStarIE()
    assert theStarIE_test_data._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:34.785288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:25:43.455252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Init of TheStarIE
    TheStarIE_obj = TheStarIE()

    # Property check
    assert TheStarIE_obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:46.722649
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:25:50.180786
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:53.007628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:25:54.332104
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the implementation of the class
    TheStarIE().test()

# Generated at 2022-06-24 13:26:05.106958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie2 = TheStarIE()
    ie2.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie3 = TheStarIE()
    ie3.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie != ie2 # test for object inequality
    assert not ie == ie2 # test for object equality
    assert ie == ie

# Generated at 2022-06-24 13:26:15.667591
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the constructor of the class
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE()._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:26:16.887609
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if isinstance(TheStarIE, type):
        TheStarIE()

# Generated at 2022-06-24 13:26:23.929415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    test_TheStarIE.zip is generated with the following command:
    wget -O test_TheStarIE.html \
        http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html &&
    sed 's/4732393888001/testid/g' test_TheStarIE.html > test_TheStarIE.zip
    '''
    ie = TheStarIE()
    ie.download(TheStarIE._TEST['url'])
    ie.download(TheStarIE._TEST['url'])
    assert(ie.url_result(ie._TEST['url'], ie._TEST['id']) is not None)

# Generated at 2022-06-24 13:26:35.278201
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Constructor test."""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.IE_DESC == 'TheStar'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:36.811241
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    This case is to test the funcionality of the constructor.
    """
    t = TheStarIE()

# Generated at 2022-06-24 13:26:41.359370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # This is a function. Should have name
    assert ie.name == 'thestar.com'
    # This is a function. Should have description
    assert ie.description == 'TheStar.com Videos'
    # This is a function. Should have ie key
    assert ie.ie_key == 'TheStar'

# Generated at 2022-06-24 13:26:42.294576
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(TheStarIE._VALID_URL)

# Generated at 2022-06-24 13:26:45.142554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:48.708509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.download(url)

# Generated at 2022-06-24 13:26:56.237471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.id == '4732393888001'
    assert ie.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.name == 'BrightcoveNew'

# Generated at 2022-06-24 13:26:57.610272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-24 13:27:06.338965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:07.973092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())


# Generated at 2022-06-24 13:27:11.567260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star_ie = TheStarIE()
    assert star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:21.683119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    website = TheStarIE()
    assert website._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert website._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert website._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:27:26.534632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:27:30.585950
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(TheStarIE.create_ie(), url)
    assert ie._match_id(url) != None

# Generated at 2022-06-24 13:27:36.648407
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE('foo')
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert inst == 'foo'

# Generated at 2022-06-24 13:27:38.267197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the class initializes correctly.
    assert TheStarIE ()


# Generated at 2022-06-24 13:27:38.891013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:43.513805
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id(ie.ie_key())
    ie._download_webpage(ie.ie_key())
    ie._search_regex(ie.ie_key(), ie.ie_key())
    ie.url_result(ie.ie_key())
    ie._real_extract(ie.ie_key())

# Generated at 2022-06-24 13:27:45.007473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:46.527158
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# A short main program that displays the content of the class TheStarIE

# Generated at 2022-06-24 13:27:48.213669
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' in globals()
    assert isinstance(globals()['TheStarIE'](), TheStarIE)

# Generated at 2022-06-24 13:27:51.065658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test to check if the constructors of the class works fine
    test_TheStarIE = TheStarIE()


# Generated at 2022-06-24 13:27:54.698647
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:56.294620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert not TheStarIE() == TheStarIE()


# Generated at 2022-06-24 13:28:07.264646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.get_video_info('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html')
    ie.get_video_info('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.get_video_info('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html/4732393888001')

# Generated at 2022-06-24 13:28:08.399924
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	cs = TheStarIE()
	print(cs)

# Generated at 2022-06-24 13:28:11.361092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:15.828370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(thestarIE, url)
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    constructor = Test.TheStarIE(url)
    assertEqual(constructor, url)

# Generated at 2022-06-24 13:28:26.224565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:29.970089
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:28:35.772563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert ie.IE_NAME == "TheSarIE"

# Generated at 2022-06-24 13:28:42.395262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   assert isinstance(
       TheStarIE(),
       TheStarIE
   )
   # Unit test for method _real_extract of class TheStarIE
   TheStarIE._real_extract(
       TheStarIE(),
       "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
   )

# Generated at 2022-06-24 13:28:43.362153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE class
    TheStarIE()

# Generated at 2022-06-24 13:28:45.470914
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie._VALID_URL)
    print(ie._TEST)