

# Generated at 2022-06-24 13:18:45.871075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:18:46.864904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-24 13:18:50.312720
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Makes sure the TheStarIE is constructed.
    '''
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-24 13:18:59.779698
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    To test the constructor of class TheStarIE
    """
    obj = TheStarIE(TheStarIE._VALID_URL)

    # Test the attribute
    expected = True
    actual = hasattr(obj, "BRIGHTCOVE_URL_TEMPLATE")
    assert actual == expected

    expected = True
    actual = hasattr(obj, "_TEST")
    assert actual == expected

    expected = True
    actual = hasattr(obj, "_VALID_URL")
    assert actual == expected

    expected = TheStarIE._VALID_URL
    actual = obj._VALID_URL
    assert actual == expected

    expected = TheStarIE._TEST
    actual = obj._TEST
    assert actual == expected

    expected = TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:19:07.902038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mannnnnkind-why-this-woman-started-a-men-s-skinnnnncare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.BRIGHTCOVE_URL_TEMPLATE != "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s2"


# Generated at 2022-06-24 13:19:14.601284
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = '4732393888001'

    # Instantiate and test TheStarIE constructor
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.br == None
    assert t.bc == None
    assert t._downloader == None
    assert t._cache == None
    assert id(t) > 0
    assert type(t) == TheStarIE
    assert t._type == 'brightcove:new'

# Test functions _

# Generated at 2022-06-24 13:19:23.286559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.id == "4732393888001"
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert ie.ext == "mp4"

# Generated at 2022-06-24 13:19:25.668968
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST

# Generated at 2022-06-24 13:19:34.228834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def constructor_test(url):
        TheStarIE(url)

# Generated at 2022-06-24 13:19:36.233393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.TheStar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:44.944617
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    assert ie.match_url(url).groupdict().get('id') == '4732393888001', ie.match_url(url).groupdict()
    assert ie.match_url('http://www.thestar.com/news/canada/2016/02/02/how-long-does-it-take-to-get-a-gopass-in-canada.html').groupdict().get('id') == '4732729073001', ie.match_url(url).groupdict()

# Generated at 2022-06-24 13:19:54.188415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # test 1

# Generated at 2022-06-24 13:20:05.982522
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(IE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(IE._TEST['url'] ==  'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:20:12.040984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testcase = TheStarIE()
    assert testcase._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:12.678674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:21.406443
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert (TheStarIE().extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')) == {'upload_date': '20160201', 'uploader_id': '794267642001', 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'id': '4732393888001', 'ext': 'mp4', 'title': 'Mankind: Why this woman started a men\'s skin care line', 'timestamp': 1454353482}


test_TheStarIE()

# Generated at 2022-06-24 13:20:22.714140
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(object())._downloader, object)



# Generated at 2022-06-24 13:20:23.654734
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test initial constructor
    assert TheStarIE()

# Generated at 2022-06-24 13:20:25.970508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:26.924772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:20:29.376479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:40.333582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = '4732393888001'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

    # When a url is supplied to the constructor
    the_star_ie = TheStarIE(url)
    assert the_star_ie.url == url
    assert the_star_ie.display_id == brightcove_id
    assert the_star_ie.url_result == brightcove_url

# Generated at 2022-06-24 13:20:44.489802
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #test the initialization of the class
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE =='http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:20:46.626922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    tsi = TheStarIE()
    assert tsi != None

# Generated at 2022-06-24 13:20:52.676544
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    # Test for validation of URL, for instance
    ie.VALID_URL = ie._VALID_URL
    ie.match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:56.160673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:57.908547
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    import pdb; pdb.set_trace()
    return star

# Generated at 2022-06-24 13:20:59.682189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', {})

# Generated at 2022-06-24 13:21:06.432637
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "%s/%s"
    ie._download_webpage = lambda url, display_id: '{"mainartBrightcoveVideoId": "01234"}'
    assert ie._real_extract('http://www.thestar.com/foo.html') == {
            '_type': 'url',
            'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=01234',
            'ie_key': 'BrightcoveNew',
            'id': '01234'}

# Generated at 2022-06-24 13:21:09.951568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:21:12.154283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructors of TheStarIE
    assert TheStarIE(TheStarIE._VALID_URL)
    assert TheStarIE(TheStarIE._TEST)

# Generated at 2022-06-24 13:21:13.352602
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None


# Generated at 2022-06-24 13:21:16.444689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    ie = TheStarIE()
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:21:21.058164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert repr(ie.BRIGHTCOVE_URL_TEMPLATE) == repr("http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:21:21.866589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()

# Generated at 2022-06-24 13:21:25.021875
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.video_id == '4732393888001'

# Generated at 2022-06-24 13:21:26.110444
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None

# Generated at 2022-06-24 13:21:28.779943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.extractor == TheStarIE._VALID_URL
    assert ie.extract_doc == InfoExtractor._download_webpage


# Generated at 2022-06-24 13:21:38.170281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE) == TheStarIE
    # Test whether the constructor raises an exception if the website is wrong.
    assert TheStarIE.__name__ == "TheStarIE"
    # Test whether the constructor raises an exception if the ID is wrong.
    TheStarIE(u'https://www.x.com/watch?v=jNQXAC9IVRw')
    # Test whether the constructor raises an exception if the URL is wrong.
    TheStarIE(u'www.youtube.com')
    TheStarIE(u'youtube.com')
    TheStarIE(u'jNQXAC9IVRw')

# Generated at 2022-06-24 13:21:42.731461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:21:45.137699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.name == "thestar"
    assert instance.description == 'thestar.com'
    assert instance.ie_key() == 'thestar'

# Generated at 2022-06-24 13:21:51.253990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie != None
    # Test the properties
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:52.322403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    assert isinstance(ie,TheStarIE)

# Generated at 2022-06-24 13:21:55.120308
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    info_extractor = class_('TheStarIE', {}, False)
    assert (info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:21:58.716319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    # Since the URL is hard coded in the test (brittle!), I can assert that its format
    # is the expected one
    assert (obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:22:02.561385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global ie
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:08.275638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.br.get_url() == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:09.713690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('')

# Generated at 2022-06-24 13:22:10.604293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return

# Unit test function for TheStarIE

# Generated at 2022-06-24 13:22:10.996683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:14.757944
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test case for constructor of class TheStarIE
    """
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:19.215023
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    starie = TheStarIE.TheStarIE(url)
    assert starie._match_id(url)
    assert starie.RE_TEST
    assert starie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:22:19.762626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE().test()


# Generated at 2022-06-24 13:22:21.089087
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testObj = TheStarIE()
    print(testObj)


# Generated at 2022-06-24 13:22:25.208509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/';
    mock_star = TheStarIE(url);
    assert mock_star.url == url and mock_star.display_id == '' and mock_star.title == None and mock_star.thestar == None

# Generated at 2022-06-24 13:22:27.714240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:28.277769
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:28.818384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:32.808983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("testing constructor of class TheStarIE")
	TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:22:38.395715
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.url == "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-24 13:22:44.560190
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    url = 'http://www.thestar.com/news/gta/2016/03/03/cassandra-france-of-citytv-local-news-anchor-dies-at-39.html'
    obj = TheStarIE(url)
    assert obj.name == "The Star"
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:45.390268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:52.353573
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ier = TheStarIE()
    assert ier._html_search_regex(ier.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', '4732393888001', 'brightcove id')
    assert ier._html_search_regex(ier.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', '794267642001', 'uploader id')
    assert ier._html_search_regex(ier.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', '1454353482', 'timestamp')
   

# Generated at 2022-06-24 13:22:55.011500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that a instance of TheStarIE is constructed correctly
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:23:03.395967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	thestar = TheStarIE()
	if thestar.ie_key() is None:
		assert False, "Internal error: Failed to extract ie_key"
	if thestar.ie_key() != 'TheStar':
		assert False, "Internal error: ie_key returned '%s', expected 'TheStar'" % thestar.ie_key()
	if thestar.ie_url() is None:
		assert False, "Internal error: Failed to extract ie_url"
	if thestar.ie_url() != 'http://www.thestar.com/':
		assert False, "Internal error: ie_url returned '%s', expected 'http://www.thestar.com/'" % thestar.ie_url()

# Generated at 2022-06-24 13:23:04.632865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # No method because no test download since no media URL has been found
    pass

# Generated at 2022-06-24 13:23:07.744272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:09.220059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:19.427012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    # Default URL
    theStar = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    
    # Test to see if _VALID_URL is set properly
    assert theStar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
    # Test to see if BRIGHTCOVE_URL_TEMPLATE is set properly
    assert theStar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
    # Test to see

# Generated at 2022-06-24 13:23:28.842624
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.example.com")
    ie.suitable("http://www.thestar.com/sports/hockey/2016/02/15/how-the-leafs-plan-to-stay-in-the-playoff-hunt-phil-kessel-james-van-riemsdyk/")
    ie.suitable("http://www.example.com")
    ie.suitable("http://www.example.com/foo/bar/")
    ie.suitable("http://www.example.com/foo/bar/baz.html")
    ie.suitable("http://www.example.com/foo/bar/baz.html?a=b&c=d")


# Generated at 2022-06-24 13:23:34.778227
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test 1
    unit_test_url1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    unit_test_url1_id1 = '4732393888001'
    unit_test_url1_id2 = '794267642001'
    unit_test_url1_mankind_why_this_woman_started_a_men_s_skincare_line = "Mankind: Why this woman started a men's skin care line"
    unit_test_url1_mankind_why_this_woman_started_a_men_s_skincare_line_id = '4732393888001'
    unit_test_url1_mankind_why_this_woman_

# Generated at 2022-06-24 13:23:44.490563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test for the valid URL
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test for the test URL
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Test for the test MD5
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    # Test for the test info_dict

# Generated at 2022-06-24 13:23:46.454182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check if TheStarIE is constructor of InfoExtractor
    assert issubclass(TheStarIE, InfoExtractor)

# Generated at 2022-06-24 13:23:52.787610
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:55.943138
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE._TEST == TheStarIE._TEST
    assert TheStarIE._TESTS[0].get("notes") == TheStarIE._TESTS[0].get("notes")

# Generated at 2022-06-24 13:23:56.489065
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE({})

# Generated at 2022-06-24 13:24:01.858374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.get_info is not None
    assert ie._download_webpage is not None
    assert ie._match_id is not None

# Generated at 2022-06-24 13:24:09.690795
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
# Testing concatenate of URL
	assert 'http://' + 'www' + '.' + 'thestar' + '.' + 'com' + '/' == 'http://www.thestar.com/'
# Testing pattern-matching of URL
	assert ''.join(re.findall(r'^https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html$', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')) == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:24:18.207493
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def test_url(input_url, expected_id, expected_player_page):
        assert TheStarIE(None)._valid_url(input_url)
        match = TheStarIE(None)._VALID_URL.match(input_url)
        assert match.group('id') == expected_id
        assert TheStarIE(None).BRIGHTCOVE_URL_TEMPLATE % expected_id == expected_player_page

    test_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
            '4732393888001',
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')
test_

# Generated at 2022-06-24 13:24:19.951709
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url


# Generated at 2022-06-24 13:24:20.614293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-24 13:24:25.561337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:28.798286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    thestarIE.extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    )

# Generated at 2022-06-24 13:24:40.157294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Example of url which is handled by TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Creating TheStarIE instance
    ie = TheStarIE()
    # Extracting information from url
    info = ie._real_extract(url)
    # Checking for expected result
    assert info['id'] == '4732393888001' and not isinstance(info['id'], unicode)
    assert info['ext'] == 'mp4' and not isinstance(info['ext'], unicode)
    assert info['uploader_id'] == '794267642001' and not isinstance(info['uploader_id'], unicode)

# Generated at 2022-06-24 13:24:41.911425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
     # Testing if TheStarIE is a subclass of InfoExtractor
     assert issubclass(TheStarIE, InfoExtractor)

# Generated at 2022-06-24 13:24:51.065573
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:53.564418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:25:01.510176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

    # Unit test for this function is _real_extract
    info_extractor._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Unit test for this function is _download_webpage
    #info_extractor._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-24 13:25:04.992929
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    #test_TheStarIE._TEST = 
    thestar_test = thestarIE.BRIGHTCOVE_URL_TEMPLATE
    return thestar_test


# Generated at 2022-06-24 13:25:07.886928
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('test_TheStarIE')
	assert ie._VALID_URL is not None
	assert ie._TEST is not None
	assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 13:25:10.827245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:14.301525
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:15.098574
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:16.864785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Testing constructor of class TheStarIE")
	print("Test is passed")


# Generated at 2022-06-24 13:25:18.503263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Arrange
	extractor = TheStarIE()

	# Act
	# Assert


# Generated at 2022-06-24 13:25:28.788010
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:32.707946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check if url is valid
    url = r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE.suitable(url) == 1

# Generated at 2022-06-24 13:25:37.803945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t
    # Test the case of _check_formats to see if _match_available_formats gets called
    t._check_formats = lambda formats: True
    t.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')



# Generated at 2022-06-24 13:25:43.422027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', {}, 'TheStarIE')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.display_id == '4732393888001'

# Generated at 2022-06-24 13:25:53.548572
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from utils import TestExecutor
    test = TestExecutor()


# Generated at 2022-06-24 13:25:54.572616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:02.037387
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    the_star_ie.BRIGHTCOVE_URL_TEMPLATE = 'test'
    the_star_ie.url_result = 'test'
    actual = \
    the_star_ie._real_extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert actual == 'test'

# Generated at 2022-06-24 13:26:10.396474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test the brightcove url template
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test the info extraction from a test page
    # What we get from _real_extract we should get from extract()

# Generated at 2022-06-24 13:26:11.893710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'thestar.com'

# Generated at 2022-06-24 13:26:13.446465
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._downloader) is not None

# Generated at 2022-06-24 13:26:14.692449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:26:15.252186
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    TheStarIE()

# Generated at 2022-06-24 13:26:23.285799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE."""
    t= TheStarIE() # Should fetch some cookies

    # Init mocks of functions, that are called by TheStarIE
    def urljoin(base, url): return "(just_called_urljoin)"
    def _download_webpage(self, url, display_id, note=None, errnote=None, fatal=False, encoding='utf-8', data=None,
                          headers=None, query={}, cookie=None, form_data_encoding='utf-8'):
        return "(just_called_download_webpage)"
    def _search_regex(self, pattern, string, name='', default=NO_DEFAULT, fatal=True, flags=0, group=None):
        return "(just_called_search_regex)"

# Generated at 2022-06-24 13:26:27.153082
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:26:29.120122
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsie = TheStarIE()
    assert tsie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:26:34.805250
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    object = TheStarIE()
    object.url = test_url
    test_id = "4732393888001"
    test_display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert object._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-24 13:26:35.817580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:40.454619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test TheStarIE constructor."""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE.startswith('http://players.brightcove.net/')
    assert ie.BRIGHTCOVE_URL_TEMPLATE.endswith('index.html?videoId=%s')

# Generated at 2022-06-24 13:26:43.474305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the constructor
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST
    ie._TESTS
    ie._real_extract

# Generated at 2022-06-24 13:26:50.698909
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()
    extractor = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    extractor = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE, TheStarIE._VALID_URL)
    extractor = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE, TheStarIE._VALID_URL, TheStarIE._TEST)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:56.525727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    ie = TheStarIE()
    
    url = ie._VALID_URL
    ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/.+\.html'

    
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
    # Test for function _real_extract
    def _real_extract(self, url):
        display_id = self._match_id(url)
        webpage = self._download_webpage(url, display_id)

# Generated at 2022-06-24 13:27:00.982660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    if not ie.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'):
        raise Exception('Unit test for constructor of class TheStarIE failed')

# Generated at 2022-06-24 13:27:02.220963
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert type(TheStarIE('TheStarIE', {})) is TheStarIE

# Generated at 2022-06-24 13:27:03.776699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert not TheStarIE(TheStarIE.ie_key()).working()


# Generated at 2022-06-24 13:27:04.192471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:10.371086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'TheStar.com'
    assert ie.ie_key() == 'thestar'
    assert ie.suitable(TheStarIE._VALID_URL) == True
    assert ie.suitable('https://www.thestar.com/entertainment/movies.html') == False
    assert ie.suitable('https://www.thestar.com/news/canada.html') == False

# Generated at 2022-06-24 13:27:11.374913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-24 13:27:17.179021
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    thestar = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.get_download_link(thestar)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:27:21.270042
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE('test')._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert video['id'] == '4732393888001'
    assert video['title'] == 'Mankind: Why this woman started a men\'s skin care line'


# Generated at 2022-06-24 13:27:24.031256
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie.extract()

# Generated at 2022-06-24 13:27:29.297480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Going to test constructor of class TheStarIE
    # Case 1: Correct input
    thestar = TheStarIE()
    assert thestar.name == 'thestar'
    assert len(thestar.ie_keywords) == 1
    assert thestar.ie_keywords['thestar'][0] == TheStarIE
    assert thestar.ie_keywords['thestar'][1] == 'TheStarIE'



# Generated at 2022-06-24 13:27:32.473150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.__class__.__name__ == 'TheStarIE'
    assert theStarIE.name == 'thestar.com'


# Generated at 2022-06-24 13:27:34.009323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != None


# Generated at 2022-06-24 13:27:36.653935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #  Constructor function
            #  Create an object for the class
            #  This will return an object of class TheStarIE
    video_ie = TheStarIE()

# Generated at 2022-06-24 13:27:37.520932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:38.114345
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:27:40.627378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Simple test, just see whether the object can be created
	info = InfoExtractor()
	thestar = TheStarIE(info)
	assert thestar is not None

# Generated at 2022-06-24 13:27:42.338196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Testing constructor of class TheStarIE")
    TheStarIE("8pvN6owbmhc")

# Generated at 2022-06-24 13:27:45.360752
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:46.895478
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    if obj:
        assert True
    else:
        assert False


# Generated at 2022-06-24 13:27:50.497911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:59.920618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:10.771692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.urls = [
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        'http://www.thestar.com/life/2015/09/27/a-fist-full-of-data-how-many-fist-bumps-could-one-solar-panel-pump.html',
        'http://www.thestar.com/life/2016/01/17/sexpert-column-is-this-cheating.html',
        'http://www.thestar.com/life/2015/11/24/hall-monitor-kyle-rasmussen-features-neat-things-in-his-hallway.html'
        ]

# Generated at 2022-06-24 13:28:13.273243
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:28:17.638972
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:28:27.046244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    ie.webpage = '''{"title": "Mankind: Why this woman started a men's skin care line",
      "mainartBrightcoveVideoId": "4732393888001",
      "mainartBrightcovePlayerId": "794267642001"}'''

# Generated at 2022-06-24 13:28:32.634523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie_test = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(ie_test)
    assert ie_test['id'] == '4732393888001'

test_TheStarIE()


# Generated at 2022-06-24 13:28:39.993448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  test_TheStarIE_id = 'test123'
  test_TheStarIE_title = 'test title'
  test_TheStarIE_description = 'test description'
  test_TheStarIE_thumbnail = 'https://cdn.thestar.com/thestar/images/logo.png'
  test_TheStarIE_uploader = 'test uploader'
  test_TheStarIE_timestamp = 1387444444
  test_TheStarIE_upload_date = '20131224'
  test_TheStarIE_view_count = 10

  # initiate class

# Generated at 2022-06-24 13:28:41.192096
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj1 = TheStarIE();

# Generated at 2022-06-24 13:28:45.001568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'