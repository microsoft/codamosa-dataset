

# Generated at 2022-06-24 13:18:51.746382
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor, instance attributes and methods
    ie_inst = TheStarIE()
    # '_VALID_URL'
    assert ie_inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # '_TEST'

# Generated at 2022-06-24 13:18:54.986579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        thestarie = TheStarIE()
        assert thestarie
    except Exception as e:
        print('ERROR: Unable to create a TheStarIE() object')
        print(e)
        return -1
    return 0


# Generated at 2022-06-24 13:18:56.039380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:19:03.657935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ix = TheStarIE()
    assert ix._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:09.695822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:12.914136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE.replace("794267642001", "default_default")

# Generated at 2022-06-24 13:19:13.537805
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  TheStarIE()

# Generated at 2022-06-24 13:19:18.444422
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    p = t._search_regex(None, None, r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)')
    assert p == r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'

# Generated at 2022-06-24 13:19:19.496578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)

# Generated at 2022-06-24 13:19:23.429554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    res = TheStarIE()
    assert res.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:26.849905
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-24 13:19:30.698438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:19:39.085942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStarIE._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:43.045614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor for class TheStarIE"""
    ie = TheStarIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:19:52.942159
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    assert i.getId() == "4732393888001";
    assert i.getUrl() == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html";
    assert i.getExt() == "mp4";
    assert i.getTitle() == "Mankind: Why this woman started a men\'s skin care line";
    assert i.getDescription() == "Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.";

# Generated at 2022-06-24 13:20:04.476960
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.get_url() == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.get_name() == 'TheStarIE'
    assert ie.is_suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:07.297391
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:20:08.158177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:20:10.281913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('www').BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:15.151560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:15.776509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:21.757748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:20:24.814169
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = '4732393888001'
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + video_id
    TheStarIE()._real_extract(url)

# Generated at 2022-06-24 13:20:32.354259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    assert e
    assert e._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert e._TEST['info_dict']['id'] == '4732393888001'
    assert e._TEST['info_dict']['ext'] == 'mp4'
    assert e._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert e._TEST['info_dict']['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-24 13:20:33.768009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # No error should be raised when constructor is called
    TheStarIE()

# Generated at 2022-06-24 13:20:42.689076
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE

    thestar = TheStarIE()

    thestar.sui = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId='

    thestar.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

test_TheStarIE()

# Generated at 2022-06-24 13:20:45.966143
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:54.724531
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	id = "4732393888001"
	display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
	TheStarIE = TheStarIE(url, display_id, id)
	assert(TheStarIE.url == url)
	assert(TheStarIE.id == id)
	assert(TheStarIE.display_id == display_id)
# test

# Generated at 2022-06-24 13:21:00.205360
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test web page URL

    # Test video ID
    video_id = '4732393888001'
    # Test video URL
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + video_id
    assert ie.BRIGHTCOVE_URL_TEMPLATE % video_id == brightcove_url

# Generated at 2022-06-24 13:21:02.729653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # test_TheStarIE()

# Generated at 2022-06-24 13:21:03.602167
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:21:12.735163
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:21:13.936213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Basic test to ensure class initializes
    ie = TheStarIE()


# Generated at 2022-06-24 13:21:14.880478
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert(i != 0)

# Generated at 2022-06-24 13:21:16.799579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:17.308376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:21:21.607013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:21:22.070971
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:23.673732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_player_url('http://some_url')
    ie.initialize()
    assert(ie.player_url == 'http://some_url')

# Generated at 2022-06-24 13:21:24.037313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:27.477712
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract()

# Generated at 2022-06-24 13:21:28.106899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:37.575497
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie = TheStarIE('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2062.124 Safari/537.36')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:40.320933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:43.362052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # only test unit test for constructor, because it's inherited from
    # test_download_format_url() and test_download_json_formats()
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL


test_TheStarIE()

# Generated at 2022-06-24 13:21:53.234242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    #
    # Tests constructor for class TheStarIE.
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL =="https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert ie.BRIGHTCOVE_URL_TEMPLATE !="http://players.brightcove.net/794267642001/default_default/index.html?videoId="

 # Unit test for _real_extract() of class TheStarIE

# Generated at 2022-06-24 13:21:54.534671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert isinstance(theStarIE, TheStarIE)

# Generated at 2022-06-24 13:22:00.079360
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    check_for_urls = [
        'http://www.thestar.com/life/2016/01/29/why-do-so-many-older-men-marry-much-younger-women.html',
        'http://www.thestar.com/life/2016/01/27/top-fashion-hacks-to-try-this-year.html',
        'http://www.thestar.com/life/2016/01/26/how-to-max-out-your-diet-without-maxing-out-your-health.html',
    ]
    for url in check_for_urls:
        assert TheStarIE(url)

# Generated at 2022-06-24 13:22:00.603224
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:08.650825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE();

    # Check if the class is initialized correctly
    if not isinstance(thestar_ie, InfoExtractor):
        raise TypeError('TheStarIE must inherit from InfoExtractor')

    if thestar_ie.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s':
        raise ValueError('BRIGHTCOVE_URL_TEMPLATE should be initialized as http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:22:11.649385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    t._download_webpage()

# Generated at 2022-06-24 13:22:20.602584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:23.841988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:27.007015
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:22:30.350019
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:33.047554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        obj_TheStarIE = TheStarIE(None)
    except:
        assert False
    assert True


# Generated at 2022-06-24 13:22:42.317337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	# Download the webpage from the given url
	webpage = download_webpage(url, '4732393888001')
	# Initialize the class TheStarIE
	TheStarIE()
	# Find the brightcove id
	brightcove_id = _search_regex(
		r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
	print(self.BRIGHTCOVE_URL_TEMPLATE % brightcove_id)

# Generated at 2022-06-24 13:22:42.947055
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:22:49.221062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_name() == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:50.474347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 13:22:54.455777
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+).html'

# Generated at 2022-06-24 13:22:59.569692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit tests for basic class.
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:23:00.622645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-24 13:23:02.145682
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._TEST['url'] == TheStarIE._TEST['info_dict']['url']

# Generated at 2022-06-24 13:23:05.291804
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.is_valid() == True

# Generated at 2022-06-24 13:23:08.855210
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE('https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.join.html')
    assert(x.brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:23:19.066578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' in ie.BRIGHTCOVE_URL_TEMPLATE
    assert '4732393888001' in ie._TEST['info_dict']
    assert 'Mankind: Why this woman started a men\'s skin care line' in ie._TEST['info_dict']
    assert 'Rob' in ie._TEST['info_dict']['description']
    assert '794267642001' in ie._TEST['info_dict']
    assert 1454353482 in ie._TEST['info_dict']
    assert '20160201' in ie._TEST['info_dict']

# Generated at 2022-06-24 13:23:28.441671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE()._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:23:34.589213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:43.000997
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        'TheStarIE',
        'TheStarIE',
        '<title>The Star | Canada\'s largest daily</title>'
    )
    assert obj.name == 'TheStarIE'
    assert obj.ie_key == 'TheStarIE'
    assert obj.page_webpage == '<title>The Star | Canada\'s largest daily</title>'
    assert obj.expected_title == "Mankind: Why this woman started a men's skin care line"

# Generated at 2022-06-24 13:23:44.479356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE should not raise any exception
    ie = TheStarIE(None)
    pass

# Generated at 2022-06-24 13:23:47.879668
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE instance test
    instance = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:23:48.284903
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    TheStarIE()

# Generated at 2022-06-24 13:23:50.860713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie_object = ie.suitable('https://www.thestar.com/entertainment/television/2016/01/04/a-new-season-of-wrecked-brings-out-the-comic-drama-of-a-cast-away-situation.html')
    assert ie_object == True

# Generated at 2022-06-24 13:24:00.816742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:03.001881
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:05.606050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:11.331743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()

# Generated at 2022-06-24 13:24:11.908500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:14.398419
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        assert 0, 'Fail to create an instance of class TheStarIE'
    else:
        assert 1, 'Successfully create an instance of class TheStarIE'

# Generated at 2022-06-24 13:24:16.999187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_info = TheStarIE(u'The Star')
    assert thestar_info is not None
    

# Generated at 2022-06-24 13:24:20.610321
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie.display_id = "/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"



# Generated at 2022-06-24 13:24:28.423370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test normal case
    ie = TheStarIE({})
    assert isinstance(ie.BRIGHTCOVE_URL_TEMPLATE, str)
    # test if string is empty
    ie = TheStarIE({})
    ie.BRIGHTCOVE_URL_TEMPLATE = ''
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ''
    # test if string is NULL
    ie = TheStarIE({})
    ie.BRIGHTCOVE_URL_TEMPLATE = None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == None


# Generated at 2022-06-24 13:24:32.310875
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('http://thestar.com/entertainment/2016/03/03/lauren-graham-on-gilmore-girls-return-i-knew-we-were-done.html')


# Generated at 2022-06-24 13:24:43.017173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert i._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert i._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:24:45.936532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:46.885081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(object())


# Generated at 2022-06-24 13:24:48.207135
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()

# Generated at 2022-06-24 13:24:48.677008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:24:50.676818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()

# Generated at 2022-06-24 13:24:51.889661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE initialization argument
    TheStarIE(
        # Input argument
        # Output argument
        )

# Generated at 2022-06-24 13:24:54.467918
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:57.558593
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/sports/raptors/2016/02/01/raptors-manage-to-keep-game-close-but-cant-pull-out-win.html')
    instance = ie()
    assert instance != []

# Generated at 2022-06-24 13:24:58.593988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  TheStarIE('',{})


# Generated at 2022-06-24 13:25:02.221128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        BrightcoveNewIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    except:
        return False
    return True

# Generated at 2022-06-24 13:25:05.591420
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	extractor = TheStarIE()
	assert (extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")

# Generated at 2022-06-24 13:25:09.603105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:12.572063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:25:16.417953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:18.360006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for constructor of class TheStarIE
    try:
        TheStarIE()
    except AssertionError:
        assert False

# Generated at 2022-06-24 13:25:27.312860
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:25:28.207941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('', '')

# Generated at 2022-06-24 13:25:32.196494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing for Youtube video url
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE()._real_extract(url)

# Generated at 2022-06-24 13:25:33.209314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:25:36.566432
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('https://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')



# Generated at 2022-06-24 13:25:37.431573
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)


# Generated at 2022-06-24 13:25:38.547302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	tsie = TheStarIE()

# Generated at 2022-06-24 13:25:39.200574
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    print(x)

# Generated at 2022-06-24 13:25:42.737148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of TheStar class
    ie = TheStarIE()
    # Assign web page id to the variable web
    web = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Create an instance of url_result for calling url_result method
    url_result = ie.url_result
    # Assign the url to the variable url
    url = web
    assert url is not None
    # Assign the video_id to the variable video_id
    video_id = '4732393888001'
    assert video_id is not None

# Generated at 2022-06-24 13:25:46.380934
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return ie

# Generated at 2022-06-24 13:25:50.232940
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_subclass_instance = TheStarIE()
    assert test_subclass_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:54.009634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Run constructor of class TheStarIE
    d = TheStarIE()
    # Run method
    d._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:04.799578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for proper initialization of class TheStarIE
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:15.581084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	extractor = TheStarIE()
	# Check if input url is a valid url
	assert extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	# Check if url matches the above template
	assert extractor._VALID_URL.match('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	# Check if test urls are valid
	assert extractor._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	# Check

# Generated at 2022-06-24 13:26:23.386305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #constructor
    temp = TheStarIE()
    assert temp.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert len(temp.BRIGHTCOVE_URL_TEMPLATE) != 0
    #check _VALID_URL
    assert temp._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert len(temp._VALID_URL) != 0
    #check _TEST

# Generated at 2022-06-24 13:26:24.905757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:28.223828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:30.241217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:33.993881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:35.772568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE is not None


# Generated at 2022-06-24 13:26:43.227737
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:46.717753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE.__bases__[0] == InfoExtractor
	# TheStarIE.__init__(self, ie_name=None, downloader=None, ie=None)
	TheStarIE_instance = TheStarIE(ie_name=None, downloader=None, ie=None)

# Generated at 2022-06-24 13:26:57.081786
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:03.216386
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie._download_webpage(ie.url, '4732393888001')
    print(ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'))

# Generated at 2022-06-24 13:27:13.648163
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# _VALID_URL 1
	event = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert event._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert event._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert event._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
	assert event._TEST['params']

# Generated at 2022-06-24 13:27:17.871355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:18.888474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()

test_TheStarIE()

# Generated at 2022-06-24 13:27:28.059000
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    theStarIE = TheStarIE()
    # Test theStarIE.BRIGHTCOVE_URL_TEMPLATE to 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test theStarIE._VALID_URL to r'https?://(?:www\.)?thestar\.com/(?:[^/]+

# Generated at 2022-06-24 13:27:29.764271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()
	print('\nUnit test for class TheStarIE(InfoExtractor) has been completed')

# Generated at 2022-06-24 13:27:33.121148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "")

# Generated at 2022-06-24 13:27:35.069339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:27:36.038225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t is not None

# Generated at 2022-06-24 13:27:39.842899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.extract("4743938961001") == True

# Generated at 2022-06-24 13:27:43.418241
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:45.063984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert((TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'))
    assert(True)


# Generated at 2022-06-24 13:27:48.391850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor = TheStarIE._extract_url
    assert constructor('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
test_TheStarIE()

# Generated at 2022-06-24 13:27:55.282043
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert isinstance(the_star_ie, TheStarIE)
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "TheStarIE's BRIGHTCOVE_URL_TEMPLATE is not correct."


# Generated at 2022-06-24 13:27:59.047323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE('https://www.thestar.com/news/canada/2017/01/09/saskatoon-police-dog-bites-man-during-arrest-on-alleged-drug-charge.html')
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised')

# Generated at 2022-06-24 13:28:03.696840
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test invalid URL
    TheStarIE('https://www.thestar.com')
    # Test valid URL
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:10.253077
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:12.823550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:19.078660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "BRIGHTCOVE_URL_TEMPLATE does not match the expected value"

# Test to check if class TheStarIE is the right class to parse a thestar.com url

# Generated at 2022-06-24 13:28:19.838877
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:28:21.622439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:28:27.846693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:28:31.709923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._download_webpage)
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:28:33.161266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('test_name', 'test_url') is not None

# Generated at 2022-06-24 13:28:34.505060
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  testIE = TheStarIE({})
  assert testIE != None

# Generated at 2022-06-24 13:28:43.037396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    a = ie.BRIGHTCOVE_URL_TEMPLATE
    assert a == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

