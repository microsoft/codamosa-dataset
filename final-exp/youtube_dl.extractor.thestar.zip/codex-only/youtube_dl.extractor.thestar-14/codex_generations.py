

# Generated at 2022-06-24 13:18:45.267955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Test the constructor of TheStarIE")

# Generated at 2022-06-24 13:18:52.364319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass
    """
    star = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # There's something wrong with the regex for brightcove ID
    #star._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    """

# Generated at 2022-06-24 13:18:58.212212
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test object creation
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test URL extraction
    url_1 = ie.extract(ie.url)
    url_2 = ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'
    assert url_1 == url_2

# Generated at 2022-06-24 13:19:06.109553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', 'Invalid TheStar IE! BRIGHTCOVE_URL_TEMPLATE should be %s instead of %s' % ('http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', ie.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 13:19:06.685693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:07.521267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert True

# Generated at 2022-06-24 13:19:12.708915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(7)
    #print ie.__module__
    #print ie.__class__
    #print type(ie)
    #print type('TheStarIE')
    assert(ie.__module__ == 'youtube_dl.extractor.thestar')
    assert(ie.__class__.__name__ == 'TheStarIE')
    assert(type(ie) == type(TheStarIE))
    assert(type('TheStarIE') == type(TheStarIE))
    assert(type('TheStarIE') == type(ie))

# Generated at 2022-06-24 13:19:15.344154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-24 13:19:24.443992
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test whether a known url is recognized
    # expected to be True
    t = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert t
    # test whether a known url is recognized
    # expected to be False
    f = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert not f
    
# unit test for _real_extract()

# Generated at 2022-06-24 13:19:26.572709
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None)
    assert ie

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:19:27.465535
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:19:32.979562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x= TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    x._download_webpage(url,1)
    assert(x.BRIGHTCOVE_URL_TEMPLATE=='http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:19:40.661069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Constructor test for TheStarIE"""
    thestari = TheStarIE()

    assert isinstance(thestari, TheStarIE)
    assert hasattr(thestari, '_VALID_URL')
    assert hasattr(thestari, 'BRIGHTCOVE_URL_TEMPLATE')

    # If a class provides a getter for a property, it should also provide a setter.
    assert not hasattr(thestari, '_VALID_URL')
    assert not hasattr(thestari, 'BRIGHTCOVE_URL_TEMPLATE')

    # If a class provides a setter for a property, it should also provide a getter.
    assert not hasattr(thestari, '_VALID_URL')

# Generated at 2022-06-24 13:19:44.620332
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    new_TheStarIE = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(new_TheStarIE, TheStarIE)

# Generated at 2022-06-24 13:19:48.044491
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:19:53.808358
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    result = TheStarIE()._real_extract(test_url)
    print(result)
    assert result.get('id') == '4732393888001'
    assert result.get('title') == 'Mankind: Why this woman started a men\'s skin care line'


# Generated at 2022-06-24 13:19:58.185206
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    me = TheStarIE()
    me = TheStarIE('')
    me = TheStarIE(None)
    me = TheStarIE(1)

# Unit test cases for TheStarIE._real_extract

# Generated at 2022-06-24 13:20:03.185124
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that TheStarIE is initialised correctly (i.e., no errors occur)
    ie = TheStarIE('https://www.thestar.com/news/canada/2017/12/31/new-year-new-you-9-best-reads-for-your-self-improvement-plan.html')
    return ie

# Generated at 2022-06-24 13:20:04.239484
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("")


# Generated at 2022-06-24 13:20:09.323393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # this is test url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # check if it has correct id
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:20:11.966241
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._extract_url_result('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:12.547999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:14.772749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        pass
    else:
        assert False, "Failure to assert TheStarIE"

# Generated at 2022-06-24 13:20:18.868025
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:27.763301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:32.354495
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._real_extract(url)['id'] == '4732393888001'

# Generated at 2022-06-24 13:20:43.585470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:47.270166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:51.315294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:21:01.228921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
	assert ie.id == '4732393888001'
	assert ie.ext == 'mp4'
	assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-24 13:21:10.234417
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__name__ == "TheStarIE"
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:11.096157
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('TheStarIE')

# Generated at 2022-06-24 13:21:12.375576
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor) != None

# Generated at 2022-06-24 13:21:16.775402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:22.877188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:21:26.065331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:34.896949
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 13:21:42.090318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/entertainment/2016/02/03/are-kim-and-kanye-getting-married-this-weekend.html", None)
    # test that URL is successfuly created
    expected_url = ie.BRIGHTCOVE_URL_TEMPLATE % "4733596265001"
    assert(ie.url == expected_url)
    # test that webpage is downloaded and extracted
    assert(ie._search_regex(ie._VALID_URL, ie.webpage, ie.display_id) == ie.display_id)

# Generated at 2022-06-24 13:21:44.152142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE(InfoExtractor) is a class, test whether it's an instance
    assert isinstance(TheStarIE(InfoExtractor()), TheStarIE)

# Generated at 2022-06-24 13:21:52.360248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.BRIGHTCOVE_URL_TEMPLATE
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    test._VALID_URL
    assert test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    test._TEST
    assert type(test._TEST) == dict



# Generated at 2022-06-24 13:21:56.803006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    vid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    video_info = TheStarIE()._real_extract(vid_url)
    assert video_info['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:21:59.365524
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:06.193931
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This test case should be removed once TheStarIE is merged into the codebase.
    info_extractor = TheStarIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:07.181699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ = TheStarIE()

# Generated at 2022-06-24 13:22:10.752188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.remove_dirs = False
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:18.832520
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._real_extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info == {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201'
    }

# Generated at 2022-06-24 13:22:25.097354
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    assert(e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(e._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:22:25.943203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:27.761833
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('brightcove')
    ie = TheStarIE('brightcove', '7')

# Generated at 2022-06-24 13:22:38.579128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.h"
    e = TheStarIE(url)

    assert e.BRIGHTCOVE_URL_TEMPLATE is not None
    assert e.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

    assert e._TEST is not None

# Generated at 2022-06-24 13:22:41.822058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:22:44.432088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None


# Generated at 2022-06-24 13:22:50.378183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    expected_result = {
        '_type': 'url_transparent',
        'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'id': '4732393888001',
        'ie_key': 'BrightcoveNew'
    }
    assert thestar_ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == expected_result

# Generated at 2022-06-24 13:22:53.195383
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    return;

# Unit test:
#   Download video file and compare with original video.

# Generated at 2022-06-24 13:22:54.210242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import TheStarIE
    TheStarIE.TheStarIE(None)

# Generated at 2022-06-24 13:23:02.616480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:23:11.966959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:13.809410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert isinstance(obj, TheStarIE)


# Generated at 2022-06-24 13:23:16.630621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(True)

# Generated at 2022-06-24 13:23:24.232629
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:29.618228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tse = TheStarIE()
    assert tse._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # assert tse._TEST == {'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'md5': '2c62dd4db2027e35579fefb97a8b6554', 'info_dict': {'title': 'Mankind: Why this woman started a men\'s skin care line', 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'uploader_id': '794267642001', 'timestamp':

# Generated at 2022-06-24 13:23:31.802562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except NameError as e:
        print("Name Error: " + str(e))
        assert False
    except:
        assert True


# Generated at 2022-06-24 13:23:37.090430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE()
    """

    # TheStarIE
    thestar_ie = TheStarIE(InfoExtractor())
    assert thestar_ie
    assert thestar_ie.ie_key() == 'TheStar'

    # test_real_extract
    test_real_extract(thestar_ie)


# Generated at 2022-06-24 13:23:38.022160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

# Generated at 2022-06-24 13:23:44.359635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	#TheStarIE._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001', 'True')
	test = TheStarIE._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert test['ext'] == 'mp4'

# Generated at 2022-06-24 13:23:52.934557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # New TheStarIE instance
    instance = TheStarIE()

    # Test for following members of instance:
    # | TheStarIE._VALID_URL
    assert(hasattr(instance, '_VALID_URL')
           and instance._VALID_URL == TheStarIE._VALID_URL)
    # | TheStarIE._TEST
    assert(hasattr(instance, '_TEST')
           and instance._TEST == TheStarIE._TEST)
    # | TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert(hasattr(instance, 'BRIGHTCOVE_URL_TEMPLATE')
           and instance.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    # | TheStarIE._real_

# Generated at 2022-06-24 13:23:58.774779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    assert test_object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # assert test_object.brigthcove_video_id == '1225348843001'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:24:07.695249
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:08.857816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()
    assert infoExtractor is not None

# Generated at 2022-06-24 13:24:10.822051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	find_TheStarIE_class(ie)


# Generated at 2022-06-24 13:24:13.449985
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:20.269532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.SUFFIX == 'thestar'
    assert ie.IE_NAME == 'thestar'
    assert ie.IE_DESC == 'thestar.com'
    assert ie.service_to_protocol == TheStarIE.service_to_protocol
    assert ie.service_to_protocol == {'http': 'http', 'https': 'http'}

# Generated at 2022-06-24 13:24:24.065119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:28.655617
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): # -*- coding: utf-8 -*-
    """ Unit test for test_TheStarIE """
    test_object = TheStarIE()
    assert test_object is not None

# Example usage of class TheStarIE
if (__name__ == "__main__"):
    print("Running  TheStarIE  Unit Test...")
    test_TheStarIE()
    print("Done.")

# Generated at 2022-06-24 13:24:40.067008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.video_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.ie_key == 'TheStar'
    assert ie.BRIGHTCOVE_URL_T

# Generated at 2022-06-24 13:24:49.463899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("thestar.com")
    # Assertion for object of class TheStarIE
    assert isinstance(obj, TheStarIE)
    # Assertion for _VALID_URL
    assert obj._VALID_URL, r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Assertion for _TEST

# Generated at 2022-06-24 13:24:56.817674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        url1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        url2 = 'http://www.thestar.com/life/2016/03/03/beauty-vlogger-emily-noel-83-on-the-power-of-youtube.html'
        url3 = 'http://www.thestar.com/opinion/editorials/2016/03/03/toronto-is-falling-behind-in-planning-for-uber.html'

# Generated at 2022-06-24 13:25:06.408755
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:25:08.560711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Unit test for constructor of class TheStarIE """
    # Pass
    TheStarIE()


# Generated at 2022-06-24 13:25:09.428596
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	assert obj

# Generated at 2022-06-24 13:25:17.442616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    validUrl = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    invalidUrl = 'http://www.thestar.com'

    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    assert ie._real_extract(validUrl).get('id') == '4732393888001'
    assert ie._real_extract(invalidUrl) is None

# Generated at 2022-06-24 13:25:27.915575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # Expected results for the test video
    expected_result = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }

    ie = TheStarIE()
    ie.download = lambda x: (1,x)
    ie.extract(url=TheStarIE._TEST['url'])

    assert ie.result['id'] == expected_result['id']


# Generated at 2022-06-24 13:25:35.645705
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Check that URL matches regex
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Check that URL matches regex with the test URL
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_TheStarIE()



# Generated at 2022-06-24 13:25:36.846055
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    assert class_

# Generated at 2022-06-24 13:25:44.386009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/energy-and-environment/quiz/2015/12/08/how-green-is-your-electricity-provider.html')
    assert ie.display_id == 'how-green-is-your-electricity-provider.html'
    assert ie.url == 'https://www.thestar.com/life/energy-and-environment/quiz/2015/12/08/how-green-is-your-electricity-provider.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:25:54.475059
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:26:05.272067
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:26:15.812884
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # List of all the valid youtube urls
    valid_youtube_urls = [
        "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
        "www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
        "thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ]

    for url in valid_youtube_urls:
        print("Testing valid youtube video url: " + url)
        test_youtube_video_url = TheStarIE(url)
        test_youtube

# Generated at 2022-06-24 13:26:16.713500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Unit tests for class TheStarIE

# Generated at 2022-06-24 13:26:23.831633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('BrightcoveNew', '4732393888001')

    assert(obj.BRIGHTCOVE_URL_TEMPLATE ==
           'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(obj.IE_NAME == 'brightcove:new')
    assert(obj.ie_key() == 'brightcove:new:4732393888001')
    assert(obj.url_result(u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
                          'BrightcoveNew', u'4732393888001').ie_key() ==
           obj.ie_key() )

# Generated at 2022-06-24 13:26:28.877699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert str(ie) == 'The Star', 'Expected The Star, got %s' % ie
    assert ie.VALID_URL, 'Expected VALID_URL = True'
    assert ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 13:26:39.317535
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._valid_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'TheStarIE') == True

# Generated at 2022-06-24 13:26:47.093475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Check the result of instanciating TheStarIE
    the_star_ie = TheStarIE()
    assert the_star_ie

    # Check the result of method _real_extract
    assert the_star_ie._real_extract(u'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == {'id': '4732393888001', '_type': 'url', 'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', 'ie_key': 'BrightcoveNew'}


# Generated at 2022-06-24 13:26:49.439115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:26:52.258154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    #assert ie.VALID_URL is
    #assert ie.TEST is



# Generated at 2022-06-24 13:26:54.059533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 13:26:55.781409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-24 13:27:00.165832
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test URL provided by The Star web site.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    i = TheStarIE()
    i.extract(url)

# Generated at 2022-06-24 13:27:05.032433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skin-care-line.html'
    self.assertTrue(TheStarIE(url)._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')


# Generated at 2022-06-24 13:27:07.652330
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:08.613119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:16.253904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    test_result = ie.is_suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_result == True
    test_result = ie.is_suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.htm')
    assert test_result == False

# Generated at 2022-06-24 13:27:18.011314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(None), InfoExtractor)

# Generated at 2022-06-24 13:27:26.843206
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:34.970276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    tester = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert tester.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:42.515598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    data = TheStarIE()
    result = data._real_extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result == {
        'id': '4732393888001',
        'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'ie_key': 'BrightcoveNew',
        'display_id': '4732393888001'
    }

# Generated at 2022-06-24 13:27:45.556407
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie = TheStarIE(ie)
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:27:52.212425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'dummy'
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = ie._real_extract(test_url)
    assert result == {
        '_type': 'URL',
        'id': '4732393888001',
        'display_id': 'mankind-why-this-woman-started-a-men-s-skincare-line',
        'url': 'dummy4732393888001',
        'ie_key': 'BrightcoveNew',
        'extractor': 'TheStarIE'
    }

# Generated at 2022-06-24 13:28:00.716750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test case 1
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test case 2
    ie = TheStarIE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Test case 3
    ie = TheStarIE({})

# Generated at 2022-06-24 13:28:11.449182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test 1: input is URL
    test = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    test._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'mankind-why-this-woman-started-a-men-s-skincare-line')
    print(test._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', '<script>var mainartBrightcoveVideoId = "4732393888001"', 'brightcove id'))

# Generated at 2022-06-24 13:28:13.819492
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    content = '<1648519097001>'
    unit = TheStarIE('')
    assert unit.id_from_uri(content) == '1648519097001' 


# Generated at 2022-06-24 13:28:20.946799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test URL http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    thestarIE = TheStarIE()
    thestarIE.set_group_name('Uploader')
    thestarIE.set_duration(None)
    thestarIE.set_new_format(['mp4'])

# Test for function _real_extract()

# Generated at 2022-06-24 13:28:29.104378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.is_logged() == False
    assert ie.is_next_page_enabled() == False
    assert ie.is_download_enabled() == False
    assert ie.is_subtitle_enabled() == False
    assert ie.is_JSON_download_enabled() == False
    assert ie.get_headers() == {}
    assert ie.get_client_args() == {}
    assert ie.get_info_extractor() == None
    assert ie.get_info_extractors() == []
    assert ie.get_required_args() == []
    assert ie.get_suitable() == False
    assert ie.get_skip_download() == False
    assert ie.get_downloader() == None
    assert ie.get_params() == {}
    assert ie.get_outtm

# Generated at 2022-06-24 13:28:30.111797
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-24 13:28:38.680482
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit = TheStarIE()
    assert unit._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert unit.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    T = unit._TEST

# Generated at 2022-06-24 13:28:42.744602
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    assert(test_object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:28:48.115528
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_ogv = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    test_ogv = TheStarIE(test_ogv)
    assert (test_ogv.BRIGHTCOVE_URL_TEMPLATE ==
            "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")