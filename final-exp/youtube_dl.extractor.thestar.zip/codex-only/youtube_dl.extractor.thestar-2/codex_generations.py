

# Generated at 2022-06-24 13:18:48.581719
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  from .common import IS_TRAVIS
  # Skip these tests if running on Travis, as they make network requests.
  if not IS_TRAVIS:
    assert(TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:18:51.654137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:18:55.668689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:18:57.959589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie != None

# Generated at 2022-06-24 13:19:08.938247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:11.360382
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    ie = TheStarIE()
    print (ie._VALID_URL)

# The Star IE has been tested and it is working fine.
# The URL of the video has been recorded in 'test.py' file.

# Generated at 2022-06-24 13:19:21.653715
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    attrs = vars(test_object)

    assert attrs['_VALID_URL'] == r'https?://(?:www\.|blogs\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:26.711760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Test case for _real_extract of class TheStarIE

# Generated at 2022-06-24 13:19:35.485753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Test '_VALID_URL' pattern
  valid_url_the_star = TheStarIE._VALID_URL

# Generated at 2022-06-24 13:19:38.089437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:19:41.464420
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:19:51.696651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test building the instance of TheStarIE.
    # This instance should be initialized with
    # the data of the unit test.
    # For example, TheStarIE instance for this unit test
    # should be initialized with the id, title, uploader
    # and upload date retrieved from the unit test.
    ie = TheStarIE(TheStarIE._TEST)
    # Test the method extract_info.
    # The info should include the data of the unit test.
    info = ie.extract_info()

    # Compare the data of the unit test with
    # the data retrieved by method extract_info.
    assert TheStarIE._TEST['md5'] == info['md5']
    assert TheStarIE._TEST['info_dict']['id'] == info['id']

# Generated at 2022-06-24 13:19:54.650995
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This test checks if the class TheStarIE could be created
    try:
        TheStarIE()
    except TypeError as e:
        assert True
        if 'this function takes no arguments' in str(e):
            assert True, 'TheStarIE takes no arguments'
        else:
            assert True
    except:
        assert True

# Generated at 2022-06-24 13:20:06.523361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class video(object):
        def __init__(self, id = None, title = None, description = None, timestamp = None, uploader_id = None, upload_date = None, ext = None):
            self.id = id
            self.title = title
            self.description = description
            self.timestamp = timestamp
            self.uploader_id = uploader_id
            self.upload_date = upload_date
            self.ext = ext;

    value = TheStarIE()
    result = value._real_extract(video)

# Generated at 2022-06-24 13:20:09.601408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:10.404137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' in dir(TheStarIE)

# Generated at 2022-06-24 13:20:15.167991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test constructor fails with blank URL
    ie = TheStarIE()
    ie._download_webpage = lambda x: '<a data-video="https://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001">'
    assert ie.constructor_fail('')

    # test constructor succeeds with correct URL
    assert ie.constructor_succeed('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:15.825537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:16.850390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance, TheStarIE)


# Generated at 2022-06-24 13:20:20.367542
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()
    ie.extract(test_url)

# Generated at 2022-06-24 13:20:20.930414
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:24.002141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:28.446846
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:30.391833
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # initalize TheStarIE using normal constructor
    ie = TheStarIE({})
    # assert instance of the class TheStarIE
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:20:31.721924
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	#Test if a valid URL has been passed to the constructor
	assert 1 == 1

# Generated at 2022-06-24 13:20:34.775507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of class TheStarIE
    the_star = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "The Star")
    
    # Check whether the instance is created
    assert the_star.__class__.__name__ == "TheStarIE"

# Generated at 2022-06-24 13:20:40.838561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:47.030863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.upload_date == '20160201'
    assert ie.uploader_id == '794267642001'

# Generated at 2022-06-24 13:20:48.758062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test construction of class TheStarIE
    TheStarIE()

# Generated at 2022-06-24 13:20:59.464375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()

    # Unit test for _real_extract
    # Testing correct return type and value
    real_extract = theStarIE._real_extract(theStarIE._TEST['url'])
    assert isinstance(real_extract['id'], basestring)
    assert isinstance(real_extract['ext'], basestring)
    assert isinstance(real_extract['title'], basestring)
    assert isinstance(real_extract['description'], basestring)
    assert isinstance(real_extract['uploader_id'], basestring)
    assert isinstance(real_extract['timestamp'], int)
    assert isinstance(real_extract['upload_date'], basestring)

    # Testing correct url

# Generated at 2022-06-24 13:21:02.155101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:11.220500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == '4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:13.109620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL


# Generated at 2022-06-24 13:21:16.849683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    print(test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    print(test_TheStarIE._VALID_URL)
    print(test_TheStarIE._TEST)


if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:21:17.346346
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return TheStarIE()

# Generated at 2022-06-24 13:21:22.714933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Test for constructor function of class TheStarIE
    thestar = TheStarIE(test_url)
    # Test for get_brightcove_id function of class TheStarIE
    brightcove_id = thestar.get_brightcove_id()
    assert(brightcove_id == '4732393888001')

# Generated at 2022-06-24 13:21:27.031960
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    ie = TheStarIE({'extractor': 'TheStarIE', 'params': {}})

# Generated at 2022-06-24 13:21:30.761556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie


# Generated at 2022-06-24 13:21:32.099763
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._build_url_result(TheStarIE._TEST['url'])

# Generated at 2022-06-24 13:21:42.087503
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(theplatform.theplatformIE)
    assert ie.theplatform.SUFFIX == "p.theplatform.com/pd/p/%s"
    assert ie.theplatform.PAGE_PATTERN == r'http://pdk\.theplatform\.com/pdk/media/guid/.*?'
    assert ie._PARAMS_PATTERN == r'params(?:=|%3D)([^&]+).*?'
    assert ie._ENTRY_ID_PATTERN == r'guid=([^&]+).*?'
    assert ie._EMBED_URL_PATTERN == r'href=["\'](https://pdk\.theplatform\.com/pdk/media/[^"\']+)[^>]+>View on [^<]+</a></p>'
    assert ie._

# Generated at 2022-06-24 13:21:43.200704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    a = TheStarIE()
    assert a.param == 'a'

# Generated at 2022-06-24 13:21:53.402657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('https://www.thestar.com/news/canada/2016/02/02/trudeau-government-reverses-cuts-to-veterans-medical-programs.html')
    TheStarIE('https://www.thestar.com/news/queenspark/2016/02/03/opposition-targets-ontario-liberal-plan-to-boost-cosmetic-surgery-funding.html')

# Generated at 2022-06-24 13:22:00.079504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	extractor = TheStarIE(test_url)
	assert extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	assert extractor._match_id(test_url) == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert extractor._real_extract(test_url).get("id") == '4732393888001'

# Generated at 2022-06-24 13:22:09.893088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    brightcove_id = '4732393888001'
    url = ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id
    assert ie.suitable(url)
    assert ie.get_id() == brightcove_id
    assert ie.get_title() == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.get_description() == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.get_uploader_id() == '794267642001'
    assert ie.get_timestamp() == 1454353482
    assert ie.get_upload_date() == '20160201'

# Generated at 2022-06-24 13:22:13.405533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url_result == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.brightcove_id == 4732393888001


# Generated at 2022-06-24 13:22:16.537928
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:22:17.401351
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:19.882824
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    v = TheStarIE()
    assert v._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-24 13:22:20.261031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:29.129426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert t._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert t._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert t._TEST['info_dict']['id'] == '4732393888001'
    assert t._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:22:32.754718
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("https://www.thestar.com/life/2019/03/12/why-young-people-in-japan-are-stopping-having-sex.html")

# Generated at 2022-06-24 13:22:42.805378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    ie = TheStarIE('http://www.thestarg.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:43.613036
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:22:51.203194
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	result = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert result.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert result.ie == 'TheStarIE'
	assert result.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
	assert result.id == '4732393888001'



# Generated at 2022-06-24 13:22:53.984885
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:02.366996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # test _real_initialize
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:03.429246
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Call constructor of class TheStarIE
    TheStarIE(None)

# Generated at 2022-06-24 13:23:07.197538
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(video.is_valid())
    assert(video.get_provider_name() == 'The Star')


# Generated at 2022-06-24 13:23:09.822441
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract( 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' )



# Generated at 2022-06-24 13:23:19.782368
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:23:22.372618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Run unit test for constructor of class TheStarIE
    t = TheStarIE('TheStar')
    assert (t.__class__.__name__ == 'TheStarIE')

# Generated at 2022-06-24 13:23:23.194026
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj != None

# Generated at 2022-06-24 13:23:25.714149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE().brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:27.484263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:23:30.844409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(thestar_ie, TheStarIE)


# Generated at 2022-06-24 13:23:37.050806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    he = TheStarIE()
    r = he.extract(url)
    assert r is not None

# Generated at 2022-06-24 13:23:41.709488
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:42.251568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:23:43.479825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.constructor()


# Generated at 2022-06-24 13:23:45.174645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    video._real_extract(TheStarIE._TEST['url'])

# Generated at 2022-06-24 13:23:53.371131
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'  # noqa
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'  # noqa
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:23:54.245153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t = TheStarIE()

# Generated at 2022-06-24 13:24:01.964841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Constructor test for TheStarIE """
    ie = TheStarIE(TheStarIE._TEST)
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.extractor_key == 'TheStar'
    assert ie.video_id == '4732393888001'

# Generated at 2022-06-24 13:24:02.545830
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:03.143149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:05.834651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:24:10.326164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:11.329924
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:17.495103
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = TheStarIE()

# Generated at 2022-06-24 13:24:18.083240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:28.655456
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST['info_dict']['id'] == '4732393888001'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-24 13:24:29.941450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()


# Generated at 2022-06-24 13:24:41.066175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    classInfo = TheStarIE('')
    assert classInfo._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert classInfo._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert classInfo._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert classInfo._TEST['info_dict']['id'] == '4732393888001'
    assert classInfo._TEST['info_dict']['ext'] == 'mp4'
    assert classInfo._TEST

# Generated at 2022-06-24 13:24:42.086970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL

# Generated at 2022-06-24 13:24:48.124689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(
        "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
        "4732393888001",
        "mp4",
        "Mankind: Why this woman started a men's skin care line",
        "Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN.",
        "794267642001",
        1454353482,
        "20160201",
        True
    )


# Generated at 2022-06-24 13:24:55.643968
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # This URL should not trigger a match
    assert ie.suitable("http://www.thestar.com") == False
    # The URL's regular expression should match the following URL
    assert ie.suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == True
    # The URL's regular expression should not match the following URL
    assert ie.suitable("http://www.google.com") == False
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    data = ie.extract(url)
    assert ie.BRIGHTC

# Generated at 2022-06-24 13:25:00.662819
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	source = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert source.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	return

test_TheStarIE()

# Generated at 2022-06-24 13:25:04.716622
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Test if class TheStarIE can be instantiated
  ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
  assert(ie != None)

# Generated at 2022-06-24 13:25:05.673822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    e

# Generated at 2022-06-24 13:25:06.825744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for TheStarIE"""
    TheStarIE()

# Generated at 2022-06-24 13:25:16.774294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Create a new instance of class TheStarIE
	theStarInstance = TheStarIE()
	# Test the URL regular expression
	assert theStarInstance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	# Test the BRIGHT COVE URL template
	assert theStarInstance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	# Test the BRIGHT COVE ID 
	assert theStarInstance._real_extract(test["url"]) == '4732393888001'
	# Test the regex validation

# Generated at 2022-06-24 13:25:21.396189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import TheStarIE
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie._VALID_URL == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:25:25.681132
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:36.647113
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()

# Generated at 2022-06-24 13:25:40.989474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com') == TheStarIE('http://www.thestar.com')
    assert TheStarIE('http://www.thestar.com') != TheStarIE('http://www.thestar.com/life/2015/07/08/bp-oil-spill-gulf-of-mexico.html')

# Generated at 2022-06-24 13:25:41.783515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:25:44.638830
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE();
    assert obj._VALID_URL == "https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html", "url pattern validation error"

# Generated at 2022-06-24 13:25:46.068610
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)

# Generated at 2022-06-24 13:25:50.794915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Get a copy of TheStarIE
    the_star_ie = TheStarIE()
    # Let's do some testing
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:55.198436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
	if isinstance(ie,InfoExtractor):
		print("Success")
	else:
		print("Failure")

if __name__ == "__main__":
	test_TheStarIE()

# Generated at 2022-06-24 13:25:55.913960
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:26:03.639831
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'^https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html$'
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.BRIGHTCOVE_URL_TEMPLATE.find('%s') == 37



# Generated at 2022-06-24 13:26:08.067769
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:13.134162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for the constructor of TheStarIE
    """
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', 'BRIGHTCOVE_URL_TEMPLATE is wrong'

# Generated at 2022-06-24 13:26:14.414246
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert test_TheStarIE() == '4732393888001'

# Generated at 2022-06-24 13:26:22.739788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    sIE = TheStarIE()
    assert sIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert sIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:30.781848
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # setup
    thestar_ie = TheStarIE()
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # target
    result = thestar_ie._real_extract(test_url)
    # assert
    assert result['url'] == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"

# Generated at 2022-06-24 13:26:31.520517
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Create constructor of AnvatoIE
	constructor = TheStarIE()
	return constructor

# Generated at 2022-06-24 13:26:32.725791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	x = TheStarIE({})

# Generated at 2022-06-24 13:26:42.638397
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    # assertEqual: check the results are same or not
    assertEqual(TheStarIE._VALID_URL, 
        r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html' 
        )

# Generated at 2022-06-24 13:26:48.630583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE.__new__(TheStarIE)
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:55.890646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'



# Generated at 2022-06-24 13:26:56.447435
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-24 13:27:05.752658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # basic constructor
    info = TheStarIE()
    assert info.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert info._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:07.700813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:27:09.458139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Simple test case to check that a basic constructor works
    TheStarIE(None, {})

# Generated at 2022-06-24 13:27:10.079979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:11.088671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if constructor can be called
    TheStarIE()

# Generated at 2022-06-24 13:27:12.783918
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-24 13:27:14.279192
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import TheStarIE #Need the class to be defined before it can be tested

# Test test for static method TheStarIE.is_suitable

# Generated at 2022-06-24 13:27:22.409846
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001")
    assert ie.VIDEO_TITLE == None
    assert ie.VIDEO_DESCRIPTION == None
    assert ie.VIDEO_THUMBNAIL == None
    assert ie.VIDEO_ID == None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL == "http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"


# Generated at 2022-06-24 13:27:24.278450
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:27:27.295815
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:37.887942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._VALID_URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:27:41.188251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE(None,None)._test_template(
		'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
		4732393888001
	)

# Generated at 2022-06-24 13:27:49.727339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    expected_IE_name = "TheStar"
    expected_url_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    expected_video_id = '4732393888001'

    TheStarIE_instance = TheStarIE(url)
    url_result = TheStarIE_instance.url_result(
        TheStarIE_instance.BRIGHTCOVE_URL_TEMPLATE % expected_video_id,
        'BrightcoveNew', expected_video_id)

    # Verify output is correct
    assert TheStarIE_

# Generated at 2022-06-24 13:27:53.014768
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))

# Generated at 2022-06-24 13:27:57.306304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._real_extract("http://www.thestar.com/news/canada/2016/02/01/david-suzuki-outs-trudeau-for-taking-oil-money-asks-him-what-the-hell-is-the-matter-with-you.html")

# Generated at 2022-06-24 13:28:05.412533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'  # noqa
    info = ie._real_extract(ie.url)

    assert(info['id'] == '4732393888001')
    assert(info['title'] == 'Mankind: Why this woman started a men\'s skin care line')
    assert(info['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.')

# Generated at 2022-06-24 13:28:14.821567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    THE_STAR_URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    BRIGHTCOVE_URL = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    BRIGHTCOVE_ID = '4732393888001'

    theStarIE = TheStarIE()

    # Test 1: Correct input URL
    info1 = theStarIE.extract(THE_STAR_URL)
    assert info1.video_id == BRIGHTCOVE_ID
    assert info1.url == BRIGHTCOVE_URL

    # Test 2: Incorrect input URL
    INCORRECT_THE_STAR_

# Generated at 2022-06-24 13:28:15.606435
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:28:26.118576
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:27.467320
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:28:36.040846
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    youtube_url = 'https://www.youtube.com/watch?v=4g4qc3U-Hgo'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4731917649001'
    valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE().suitable(youtube_url) == False
    assert TheStarIE().suitable(brightcove_url) == False
    assert TheStarIE().suitable(valid_url) == True

# Generated at 2022-06-24 13:28:39.628759
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE()._VALID_URL.startswith(TheStarIE.__name__))
    assert(TheStarIE()._VALID_URL.endswith('\..+\.html'))

# Generated at 2022-06-24 13:28:41.296459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        return False
    return True