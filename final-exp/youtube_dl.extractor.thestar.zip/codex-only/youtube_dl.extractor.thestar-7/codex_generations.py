

# Generated at 2022-06-24 13:18:49.040745
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Note: the 'skip_download' parameter above is to skip the test because
    # Brightcove doesn't allow multiple requests for the same video on
    # their test platform.
    ie = TheStarIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-24 13:18:52.412312
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert_equal(ie.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:18:55.669501
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
 

# Generated at 2022-06-24 13:18:58.167987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    entry = TheStarIE._TEST
    assert (TheStarIE._VALID_URL % {'id': entry['info_dict']['id']} == entry['url'])

# Generated at 2022-06-24 13:19:01.261872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:19:03.348215
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL is not None
    assert info_extractor._TEST is not None

# Generated at 2022-06-24 13:19:08.115614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(params={})
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._TEST
    ie._VALID_URL
    ie._real_extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:08.773653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:11.148345
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie_object = ie.extract(ie._TEST['url'])

# Generated at 2022-06-24 13:19:14.587922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == "__main__":
        obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        obj.extract()

# Generated at 2022-06-24 13:19:20.375657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test initialization of class TheStarIE
    # Create an instance of class TheStarIE, with args (ie_key and ie_info)
    ie = TheStarIE(ie_key=None, ie_info=None)
    assert ie.ie_key == None # Assert the ie_key attribute value is None
    assert ie.ie_info == None # Assert the ie_info attribute value is None


# Generated at 2022-06-24 13:19:27.377324
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_youtube_dl import FakeYDL
    from .test_info_extractor import expected_results, expected_warnings

    ydl = FakeYDL()
    thestar_test = expected_results['test_TheStarIE']
    ie = TheStarIE(ydl, thestar_test['params'])
    result = ie._extract_info(thestar_test['url'], expected_warnings)
    assert result.__dict__ == thestar_test['info_dict'].__dict__

# Generated at 2022-06-24 13:19:28.646910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert 'TheStarIE' == TheStarIE('TheStarIE')


# Generated at 2022-06-24 13:19:32.447762
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that only instance of InfoExtractor created
    assert TheStarIE is TheStarIE.ie_key()
    # Test that we are returning the right instance
    ie = InfoExtractor.get_info_extractor(TheStarIE.ie_key())
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:19:35.441001
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:36.436039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.set_default_intl_parameters()

# Generated at 2022-06-24 13:19:37.542951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie == TheStarIE()

# Generated at 2022-06-24 13:19:47.863128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    ie._VALID_URL

# Generated at 2022-06-24 13:19:50.942175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-24 13:19:51.371538
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:56.148020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ts_ie = TheStarIE()
    assert ts_ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ts_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:57.929409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie == TheStarIE)

# Generated at 2022-06-24 13:20:01.280700
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:05.934034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #make sure the constructor of class is functioning properly
    infoextractor = TheStarIE()
    assert (infoextractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

#Unit test for _real_extract function

# Generated at 2022-06-24 13:20:08.522045
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:10.717882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:20:11.685933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t.test()

# Generated at 2022-06-24 13:20:16.798305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001' == expected

# Generated at 2022-06-24 13:20:22.093239
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    This function constructs a TheStarIE instance and calls its method
    _real_extract(url).
    '''
    ts = TheStarIE()
    url = r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ts.url = url
    ts._real_extract(url)


# Generated at 2022-06-24 13:20:23.384204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:20:26.354532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:27.533091
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t != None 


# Generated at 2022-06-24 13:20:29.659914
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 13:20:30.432412
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE

# Generated at 2022-06-24 13:20:37.625109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("URL: " + thestarie._VALID_URL)
    print("ID: " + thestarie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"))


# Generated at 2022-06-24 13:20:38.635438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()

# Generated at 2022-06-24 13:20:40.839313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie != None

# Generated at 2022-06-24 13:20:43.735259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.suitable(url)

    assert ie.extract(url) is not None

# Generated at 2022-06-24 13:20:46.117791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE(TheStarIE.create_geo_restricted_options({'geo_countries': ['CA']}))
    pass

# Generated at 2022-06-24 13:20:47.011020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()

# Generated at 2022-06-24 13:20:58.228488
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Try to initialize TheStarIE with an invalid URL
    t = TheStarIE()
    try:
        t.set_url("https://www.thestar.com")
    except:
        pass

    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE.set_url("https://www.thestar.com")
    assert t.valid() == False
    t.set_url(url)
    assert t.valid() == True
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert t.BRIGHTCOVE_URL_T

# Generated at 2022-06-24 13:20:59.346240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        print('Unit test failed')


# Generated at 2022-06-24 13:21:04.689506
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # this test case is a simple test for instantiating a working class object
    #   from the the class TheStarIE
    #   without testing any of the methods of the class TheStarIE
    # test purpose: check if the class object can be instantiated
    #   successfully and does not throw any exception
    # passed if:
    #   the instantiation succeeds
    #   and no exception was thrown during the instantiation
    #   and the created object can be assigned to a local variable
    #   and the assigned local variable is not None
    var = TheStarIE()
    assert var is not None


# Generated at 2022-06-24 13:21:07.731791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:12.986443
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ TheStarIE test unit """
    INSTANCE = TheStarIE()._parse_playlist_result(
        [],
        'http://www.thestar.com/sports/leafs/video_index.html',
        [])
    RESPONSE = INSTANCE.result  # pylint: disable=E1101
    # check the name of the class
    assert type(RESPONSE).__name__ == 'list'

# Generated at 2022-06-24 13:21:15.773298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().url_result("http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001", type="BrightcoveNew", video_id="4732393888001")

# Generated at 2022-06-24 13:21:16.444027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    object_ = TheStarIE(InfoExtractor())

# Generated at 2022-06-24 13:21:16.965328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:21.866984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(object)._VALID_URL.pattern == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE(object)._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'



# Generated at 2022-06-24 13:21:24.048792
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    # test for class TheStarIE being instance of InfoExtractor
    assert isinstance(class_, InfoExtractor)


# Generated at 2022-06-24 13:21:26.246344
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE.test_TheStarIE = TheStarIE('test_TheStarIE')

test_TheStarIE()

# Generated at 2022-06-24 13:21:37.305720
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    #assert ie._TEST == {
        #'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        #'md5': '2c62dd4db2027e35579fefb97a8b6554',
        #'info_dict': {
            #'id': '4732393888001',
            #'ext': 'mp4',
            #'title': 'Mankind: Why this woman started a men\'s skin care line',
            #'description': 'Robert

# Generated at 2022-06-24 13:21:38.940434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None, 'http://example.com') is not None

# Generated at 2022-06-24 13:21:43.935126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:48.322956
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE()._real_initialize(url)

# Generated at 2022-06-24 13:21:54.395965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('test', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:55.227624
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE
test_TheStarIE()

# Generated at 2022-06-24 13:22:00.249286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    # test the constructor of class TheStarIE
    assert inst._VALID_URL == TheStarIE._VALID_URL
    assert inst._TEST == TheStarIE._TEST
    assert inst.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
# test for class TheStarIE
t = TheStarIE()
# test for function _real_extract of class TheStarIE
t._real_extract(t._TEST['url'])

# Generated at 2022-06-24 13:22:08.661998
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:22:14.131981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = '4732393888001'
    webpage = ie._download_webpage(url, display_id)
    assert ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
                             webpage, 'brightcove id') == '4732393888001'

# Generated at 2022-06-24 13:22:17.060269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info_extractor = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
	assert info_extractor is not None

# Generated at 2022-06-24 13:22:23.376284
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst_TheStarIE = TheStarIE()
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    test_display_id = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    test_id = "4732393888001"
    inst_TheStarIE._match_id(test_url) == test_id
    inst_TheStarIE._match_id(test_url) == test_id

# Generated at 2022-06-24 13:22:28.339424
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:28.862316
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:37.492655
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    A test for the class TheStarIE.
    '''
    # url = url from the test dictionary
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Create the TheStarIE object
    thestarIE = TheStarIE()
    # Test the _real_extract method using the previously assigned url
    thestarIE._real_extract(url)

# Unit test of the _real_extract method of class TheStarIE

# Generated at 2022-06-24 13:22:39.225377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #I should find a way to auto download a video, and then test if the constructor works
    pass

# Generated at 2022-06-24 13:22:47.744299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:50.856515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:52.401806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST['url'])

# Generated at 2022-06-24 13:22:55.327673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://video.thestar.com/videos/2361347649001/toronto-dog-rescue-dogs-rescued-from-overcrowded-shelter-arrive-at-toronto-shelter/', True, True)

# Generated at 2022-06-24 13:23:03.623496
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar_get_id = thestar._match_id(thestar_url)
    thestar_download = thestar._download_webpage(thestar_url, thestar_get_id)
    thestar_search_brightcove = thestar._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', thestar_download, 'brightcove id')
    thestar_url_url = thestar.BRIGHTCOVE_URL_TEMPLATE % thestar_search_brightcove
    the

# Generated at 2022-06-24 13:23:07.749502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("\nUnit test for class TheStarIE for constructor\n")
    print("object initialized and it is a " + str(type(ie)))


# Generated at 2022-06-24 13:23:13.508384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('')
    assert t.url_result == u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.BRIGHTCOVE_URL_TEMPLATE == u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:15.331398
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '123')
    assert ie.brightcove_id == '123'
    assert ie.url == TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '123'

# Generated at 2022-06-24 13:23:16.109234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Simple test for The Star Class
    """
    TheStarIE()

# Generated at 2022-06-24 13:23:23.865765
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_class = TheStarIE()
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_url2 = 'https://www.thestar.com/news/canada/2017/04/14/2-months-post-surgery-trudeau-is-back-to-work-and-still-taking-antibiotics.html'
    video_id = '4732393888001'
    video_id2 = '4765141077001'

    # Actual test for constructor of class TheStarIE
    if ie_class.get_url_re(test_url) != ie_class._VALID_URL:
        raise AssertionError

    # Actual test for get

# Generated at 2022-06-24 13:23:32.305178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('','')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:36.049118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:37.185209
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()



# Generated at 2022-06-24 13:23:40.518290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:45.786110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:23:46.171313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:23:52.511246
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:23:55.142814
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().extract(r"http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:24:01.512199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.name == 'thestar.com'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:07.391196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test TheStarIE
    info_extractor = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    info_extractor.extract(url)
    # test class BrightcoveNew
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    info_extractor.extract(url)

# Generated at 2022-06-24 13:24:16.160308
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE_expected = TheStarIE(
        'http://www.cbc.ca/news/canada/ottawa/bruce-mcarthur-case-1.4545891',
        {},
        InfoExtractor)
    IE_expected._rargs = {}
    IE_actual = TheStarIE(
        'http://www.cbc.ca/news/canada/ottawa/bruce-mcarthur-case-1.4545891',
        {},
        InfoExtractor)
    assert IE_expected._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:24:27.127764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST)
    # Variable check
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:38.190779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    assert tsi._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:40.064798
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    assert isinstance(thestarIE, TheStarIE)


# Generated at 2022-06-24 13:24:41.086029
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:42.475012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        from . import TheStarIE
    except:
        pass

# Generated at 2022-06-24 13:24:44.496056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

test_TheStarIE.func_doc += '\n\n' + TheStarIE.__doc__

# Generated at 2022-06-24 13:24:49.804415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = TheStarIE(url)

# Generated at 2022-06-24 13:24:57.082672
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:00.048506
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:09.170389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({'extractor': 'theStar'})
    assert ie.display_id() is None
    assert ie.display_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.display_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:25:13.360653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_class = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(test_class)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:25:18.599236
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
  assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:28.787866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    input = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',)
    output = TheStarIE._extract_urls(input)
    assert type(output) is tuple, "The output is not a tuple"
    assert len(output) == 1, "The output tuple is not of length 1"
    assert type(output[0]) is tuple, "The output tuple is not a tuple"
    assert len(output[0]) == 3, "The output tuple is not of length 3"
    assert output[0][0] == '4732393888001', "The brightcove id is wrong"
    assert output[0][1] == 'BrightcoveNew', "The downloader is wrong"

# Generated at 2022-06-24 13:25:30.752786
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 13:25:40.597061
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:25:41.754303
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check for correct type
    ie = TheStarIE()
    assert type(ie) == TheStarIE

# Generated at 2022-06-24 13:25:43.648837
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.brightcove_url_template = "xxx"
    assert ie.brightcove_url_template == "xxx"

# Generated at 2022-06-24 13:25:44.164096
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:25:54.266187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert hasattr(ie, "_TEST")
    assert isinstance(ie._TEST, dict)
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:25:55.252585
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = TheStarIE()

# Generated at 2022-06-24 13:25:58.974271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_name = TheStarIE.__class__.__name__
    assert class_name == 'TheStarIE'

    instance_of_class = TheStarIE()
    assert isinstance(instance_of_class, TheStarIE)

# Generated at 2022-06-24 13:26:02.429688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:02.892995
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE();

# Generated at 2022-06-24 13:26:09.226411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    starIE = TheStarIE()
    test = starIE._TEST
    
    result = starIE._real_extract(url)
    expected = test['url']
    assert result == expected, '_real_extract of TheStarIE did not return expected result'

# Generated at 2022-06-24 13:26:12.881788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE.value == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:13.800376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:18.016427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(1, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    filename = ie.download('4732393888001')
    assert(filename.endswith('.mp4'))

# Generated at 2022-06-24 13:26:21.654586
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	extractor = TheStarIE()
	data = extractor._real_extract(url)
	assert(data['id'] == '4732393888001')

# Generated at 2022-06-24 13:26:23.614094
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    instance = TheStarIE()
    assert instance

# Generated at 2022-06-24 13:26:33.741353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId="
    thestar._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        'mainartBrightcoveVideoId\':\'4732393888001\',', '4732393888001')
    thestar._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:26:42.120775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:52.196413
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__dict__ == TheStarIE.__class__.__base__.__dict__
    assert TheStarIE.__doc__ == InfoExtractor.__doc__
    assert TheStarIE.BRIGTHCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:53.682994
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE(InfoExtractor)




# Generated at 2022-06-24 13:26:58.995702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:00.542346
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print('Testing TheStarIE constructor...')
    TheStarIE()

# Generated at 2022-06-24 13:27:06.120361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # A simple test of TheStarIE constructor
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    assert ie.url == url
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'



# Generated at 2022-06-24 13:27:12.398091
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	thestar_ie = TheStarIE()
	thestar_ie.BRIGHTCOVE_URL_TEMPLATE
	thestar_ie._VALID_URL
	thestar_ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:27:14.161426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._downloader is None

# Generated at 2022-06-24 13:27:22.974327
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST_URL == r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST_BRIGHTCOVE_ID == r'4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:23.531967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:28.343771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:31.926190
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# This is to test if class TheStarIE has been defined.
	# Please also check if you have imported all dependencies
	# properly in __init__.py
	instance = TheStarIE()
	assert isinstance(instance, TheStarIE)

# Generated at 2022-06-24 13:27:35.161802
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:40.880352
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE('TheStarIE')
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert class_._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:43.648396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # simple test of the constructor
    oTheStarIE = TheStarIE("")
    assert oTheStarIE.__class__.__name__ == "TheStarIE"

# Generated at 2022-06-24 13:27:47.298753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i._VALID_URL == ('https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html')

# Generated at 2022-06-24 13:27:48.534230
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._VALID_URL)

# Generated at 2022-06-24 13:27:56.157474
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'BrightcoveNew', '4732393888001', 
        'Mankind: Why this woman started a men\'s skin care line')


# Generated at 2022-06-24 13:27:59.269275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    pass

# Generated at 2022-06-24 13:28:03.145981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:03.742872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:28:05.460162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: refactor to use mock
    TheStarIE(InfoExtractor(None)).to_do()
    return True

# Generated at 2022-06-24 13:28:06.062300
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-24 13:28:08.094051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructing class TheStarIE
    The_Star = TheStarIE()
    print(The_Star)

# Generated at 2022-06-24 13:28:16.281851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    assert_equal(the_star._VALID_URL, r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:28:17.730660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:28:21.844522
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    instance = ie.get_instance()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:27.268046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'The Star'
    assert ie.description == 'TheStar.com'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:33.119029
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._TEST)
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    ie2 = TheStarIE(TheStarIE._TEST)
    assert ie == ie2
    assert ie != object

# Generated at 2022-06-24 13:28:36.343369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("""
    <html>
    <body>
    <script type="text/javascript">
        var mainartBrightcoveVideoId = '4732393888001';
    </script>
    </body>
    </html>
    """)

# Generated at 2022-06-24 13:28:40.430294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:43.925114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test creation of an instance of TheStarIE
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert ie.get_media_id() is None

# Generated at 2022-06-24 13:28:45.355917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._test_cases()

test_TheStarIE()