

# Generated at 2022-06-24 13:18:43.879434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._TEST == ie.ie._TEST
    assert ie._VALID_URL == ie.ie._VALID_URL

# Generated at 2022-06-24 13:18:55.214560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:18:55.804011
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert True == True

# Generated at 2022-06-24 13:18:59.855780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = TheStarIE._TEST["url"]
	brightcove_id = TheStarIE._TEST["info_dict"]["brightcove_id"]
	assert url == TheStarIE._TEST["url"]
	assert brightcove_id == TheStarIE._TEST["info_dict"]["brightcove_id"]

# Generated at 2022-06-24 13:19:05.263006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:09.189892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.__class__ == TheStarIE
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:19:10.046727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:12.994781
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:19.220037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x.NAME == 'thestar'
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert x._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:27.117697
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test unit for constructor of class TheStarIE"""
    # Case normal
    ie = TheStarIE()
    assert ie.suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

    # Case not valid
    ie = TheStarIE()
    assert not ie.suitable("http://www.torontosun.com/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line")

# Generated at 2022-06-24 13:19:27.594597
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:36.539133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test case 1
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test case 2
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test case 3
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    id = '4732393888001'
    ext = 'mp4'

# Generated at 2022-06-24 13:19:40.496677
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Test constructor of class TheStarIE
	"""
	# Case 1
	TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-24 13:19:43.713801
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:44.529320
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): test = TheStarIE()

# Generated at 2022-06-24 13:19:50.857022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()
    ie.extract(video_url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:53.488368
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:54.789649
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert issubclass(TheStarIE, InfoExtractor)


# Generated at 2022-06-24 13:20:06.658379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL

    # The mock_download_webpage method should be called once.
    # The mock_download_webpage method should be called with the url
    # and the expected display_id
    url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    display_id = "mankind-why-this-woman-started-a-men-s-skincare-line"
    webpage = '<script type="text/javascript">\n' \
    '    if (typeof(jQuery) === "undefined") { \n' \
    '        var jQuery = django.jQuery; \n' \
    '    } \n'

# Generated at 2022-06-24 13:20:07.090933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:08.073666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.build_url_result()

# Generated at 2022-06-24 13:20:08.676700
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:12.344375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # verify the class.
    assert TheStarIE is not None

    # test instantiation
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    t = TheStarIE(test_url)
    assert t is not None

# Generated at 2022-06-24 13:20:13.004963
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:13.973534
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None

# Generated at 2022-06-24 13:20:14.537152
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return TheStarIE()

# Generated at 2022-06-24 13:20:24.856865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    url = ie._TEST['url']
    md5 = ie._TEST['md5']
    info_dict = ie._TEST['info_dict']
    params = ie._TEST['params']
    assert ie._VALID_URL in url
    assert ie._TEST is not None
    assert ie._download_webpage is not None
    assert ie._search_regex is not None
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie._real_extract is not None
    assert ie.BRIGH

# Generated at 2022-06-24 13:20:27.919128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.name == 'thestar.com'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == r'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:29.091827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return InfoExtractor.test_extractors(TheStarIE)



# Generated at 2022-06-24 13:20:32.621732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:20:39.037663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert '<!DOCTYPE html>' in theStarIE.download("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:20:48.348323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None
    # Test URL check
    assert ie._valid_url("http://toronto.com/help", "invalid url") == None
    assert ie._valid_url("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "invalid url") == "4732393888001"
    assert ie._valid_url("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "invalid url") == "4732393888001"
    # Test class instance
    TheStarIE() is not None

# Generated at 2022-06-24 13:20:57.318442
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def _test_create_TheStarIE_object(url):
        ie = TheStarIE(TheStarIE.create_ie(url))
        assert ie != None
    
    _test_create_TheStarIE_object('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    _test_create_TheStarIE_object('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:21:01.848598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:10.940704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Unit test for constructor of class TheStarIE
    '''
    properties = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201'
    }
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url, properties)


# Generated at 2022-06-24 13:21:11.777811
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-24 13:21:14.990059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    sample_url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(TheStarIE.create_ie(), sample_url)

# Generated at 2022-06-24 13:21:17.149440
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._VALID_URL
    ie._download_webpage
    ie._search_regex
    ie._real_extract
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.url_result
    ie.url_result
    # no need to test others, just to make this a valid unit test.

# Generated at 2022-06-24 13:21:18.297561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    assert(ie!=None)


# Generated at 2022-06-24 13:21:25.443502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:26.068917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:37.116614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test 1: common case
    the_starIE = TheStarIE()
    # valid url
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    info = the_starIE.extract(url)
    assert info == {
        '_type': 'url',
        'id': '4732393888001',
        'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'ie_key': 'brightcove_new',
    }
    # Test 2: invalid url

# Generated at 2022-06-24 13:21:39.141693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test class TheStarIE"""
    obj = TheStarIE()
    assert obj.__name__=="TheStarIE"

# Generated at 2022-06-24 13:21:42.176049
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:45.183696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    attrs = vars(TheStarIE)
    instance = TheStarIE()

    # Test that BRIGHTCOVE_URL_TEMPLATE exists
    assert 'BRIGHTCOVE_URL_TEMPLATE' in attrs


# Generated at 2022-06-24 13:21:49.024428
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test if URL is valid using _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test sample URL in the _TEST object
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Test sample md5 of encrypted video
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:21:50.204556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    return a

# Generated at 2022-06-24 13:21:53.190435
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t != None
    assert t.BRIGHTCOVE_URL_TEMPLATE != None
    assert t._VALID_URL != None


# Generated at 2022-06-24 13:21:54.713283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()

# Generated at 2022-06-24 13:21:56.260575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)

if __name__ == '__main__':
    TheStarIE_test()

# Generated at 2022-06-24 13:21:59.638673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:05.114325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ''' Unit test for constructor of class TheStarIE '''
    name = 'test'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(name)
    TheStarIE(name, url)
    TheStarIE(name, url, '4732393888001')


# Generated at 2022-06-24 13:22:14.950941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    #ie = TheStarIE('thestar')
    #assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == "__main__":
    import sys
    test_TheStarIE()
    sys.exit(0)

# Generated at 2022-06-24 13:22:19.404440
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:23.726999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    video = ie.extract("4732393888001")
    assert video.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert video.title == "Mankind: Why this woman started a men's skin care line"

# Generated at 2022-06-24 13:22:30.957199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(InfoExtractor())
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:22:41.495907
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:48.185285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    exp_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

    # test the constructor of class TheStarIE
    instance = TheStarIE()

    # test __init__()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

    # test _match_id()
    res = instance._match_id(url)

# Generated at 2022-06-24 13:22:53.869084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Basic unit test for TheStarIE
    """
    ie = TheStarIE(False)

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:22:54.614185
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE, "__init__")

# Generated at 2022-06-24 13:22:57.572508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:05.097723
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:11.624208
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html' 

# Generated at 2022-06-24 13:23:20.742645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:21.354513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:30.631812
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('www.thestar.com', 'Mankind: Why this woman started a men\'s skin care line', '4732393888001', 'mp4', 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', '794267642001', 1454353482, '20160201', None, None)
    assert type(obj) == TheStarIE
    assert obj.url == 'www.thestar.com'
    assert obj.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert obj.brightcove_id == '4732393888001'
    assert obj.ext == 'mp4'
    assert obj.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-24 13:23:40.268489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:43.238607
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:47.329439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that the constructor for a new class is properly calling the
    # base class constructor.
    ie = TheStarIE("test")

    # Test that the base class is initialized properly.
    assert ie.ie_key() == 'TheStar'
    assert 'thestar.com' in ie.working_urls()

# Generated at 2022-06-24 13:23:48.801851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)


# Generated at 2022-06-24 13:23:55.555454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:59.661146
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:24:02.909887
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie != None


# Generated at 2022-06-24 13:24:03.822283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate an instance of class TheStarIE
    TheStarIE()

# Generated at 2022-06-24 13:24:12.497690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:19.183204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit tests do not have a display ID
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.browser == 'curl'
    assert ie.player_cache == {}
    assert ie.params == {}
    assert ie.ie_key == 'TheStar'
    assert ie.error_catcher == None
    assert ie.cache
    assert ie.FileDownloader == None
    assert ie.youtube_dl

# Generated at 2022-06-24 13:24:24.674935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:24:34.721924
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert('TheStarIE' in ie.IE_NAME)
    assert('thestar.com' in ie.IE_DESC)
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:24:38.049645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert(TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:24:39.191756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE(TheStarIE._TEST)

# Generated at 2022-06-24 13:24:39.605671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:24:40.869490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    temp = TheStarIE(None)

# Generated at 2022-06-24 13:24:47.344927
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    ie.BRIGHTCOVE_URL_TEMPLATE % "4732393888001"
    ie._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-24 13:24:55.192639
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE, TheStarIE._VALID_URL, '794267642001')
    assert obj._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._NETRC_MACHINE == '794267642001'
    assert obj.ie_key() == 'TheStar'
    # Confirm that it is possible to call static method from class name
    assert TheStarIE.ie_key() == 'TheStar'

# Generated at 2022-06-24 13:24:56.689298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assert that a TheStarIE class has been created
    assert 'TheStarIE' in globals()

# Generated at 2022-06-24 13:24:57.561090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-24 13:25:07.087147
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    theStar = TheStarIE()

    theStar._VALID_URL = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStar._TEST['url'] = theStar._VALID_URL

# Generated at 2022-06-24 13:25:10.269739
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:13.688374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_instance = TheStarIE()
    if ie_instance:
        print("\ntest TheStarIE successfully\n")
    else:
        print("\ntest TheStarIE Failure\n")

# Unit testing of 'extract' function

# Generated at 2022-06-24 13:25:22.084712
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Unit test for constructor of class TheStarIE """

    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:25.546393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:36.606448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    assert theStar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:44.663342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    _VALID_URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:25:49.466747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:54.676896
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE(
        "thestar_ie", "thestar_ie", {}, "thestar_ie")
    assert thestar_ie.name == "thestar_ie"
    assert thestar_ie.ie_key == "thestar_ie"
    assert thestar_ie._downloader.params == {}
    assert thestar_ie._downloader.ydl_opts == "thestar_ie"


# Generated at 2022-06-24 13:25:55.601110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()

# Generated at 2022-06-24 13:26:00.375084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._master_regex == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie._BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:26:02.672186
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Checks if it's instance of InfoExtractor class
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:26:10.765239
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:14.961146
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # On a windows machine, If you run the command "py.test", the command will get stuck so you have to run
    # the command "py.test name_of_file.py" to run the test on a specific file
    tester = TheStarIE()

# Generated at 2022-06-24 13:26:23.088053
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:27.354234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:28.763500
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:26:35.678325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/travel/2016/08/30/review-air-canada-economy-perk-up-your-own-in-flight-meal.html')
    assert ie.name == 'TheStar.com'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 13:26:45.050886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/\?]+)\.html'

# Generated at 2022-06-24 13:26:47.990647
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/news/canada/2015/10/22/canadian-airlines-boost-in-flight-wifi.html')

# Generated at 2022-06-24 13:26:54.387208
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing a YouTube entry
    TheStarIE('https://www.thestar.com/yourtoronto/2016/05/02/how-to-make-the-perfect-smoothie.html')

    # Testing a BrightCove entry
    TheStarIE('http://www.thestar.com/news/world/2016/04/22/somalias-rebel-group-al-shabaab-claims-responsibility-for-deadly-attack-on-uganda-base.html')

# Generated at 2022-06-24 13:26:55.228820
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result != None

# Generated at 2022-06-24 13:26:57.249396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == "__main__":
        url = TheStarIE()
        url.test()

# Generated at 2022-06-24 13:26:59.410447
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for creating an instance
    theStarIE = TheStarIE()
    assert isinstance(theStarIE, TheStarIE)


# Generated at 2022-06-24 13:27:02.462778
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:09.556789
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test url construction
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    display_id = ie._match_id(url)
    assert display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    # Test video extraction
    video = ie.extract(url)
    assert video.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert video.description == "Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN."
    assert video.upload_date == '20160201'
    assert video.timestamp == 1454353482
   

# Generated at 2022-06-24 13:27:12.578880
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    theStarIE = TheStarIE(
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
        '4732393888001')

    assert theStarIE.embed_code == '4732393888001'

# Generated at 2022-06-24 13:27:16.951756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'), TheStarIE)

# Generated at 2022-06-24 13:27:18.812816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ = TheStarIE(None, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:19.323204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:22.610529
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:27:28.818933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie._real_extract(ie.url)
    ie.url = 'http://www.thestar.com/life/2016/01/18/two-women-find-their-way-back-to-each-other-and-themselves.html'
    ie._real_extract(ie.url)

# Generated at 2022-06-24 13:27:31.644824
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._real_extract(TheStarIE._TEST['url'])
    assert info['id'] == TheStarIE._TEST['info_dict']['id']

# Generated at 2022-06-24 13:27:32.243693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL

# Generated at 2022-06-24 13:27:40.255733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie.name == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:27:49.068746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:52.872114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:56.895911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 1, "test_TheStarIE() failed"


# Generated at 2022-06-24 13:28:01.006342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Dummy url for testing
    url_test = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE().suitable(url_test)

# Generated at 2022-06-24 13:28:08.630119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.name == 'thestar.com'
    assert obj.ie_key() == 'thestar'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:09.690967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:28:17.145410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import test, play
    try:
        from . import Video, Playlist
    except:
        from . import video_py3 as Video
        from . import playlist_py3 as Playlist
    url = 'https://www.thestar.com/world/2016/01/28/france-weightlifter-who-dropped-barbell-on-his-neck-dies.html'
    info = TheStarIE(test).get_info(url)
    assert info['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4719253356001'
    assert info['name'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4719253356001'

# Generated at 2022-06-24 13:28:19.757742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:23.653222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instance = TheStarIE()
    instance.initialize(url)
    assert instance.extract(url) is not None

# Generated at 2022-06-24 13:28:28.293886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == "thestar"
    assert TheStarIE._VALID_URL == ie._VALID_URL
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:28:35.343375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
	return True

# Generated at 2022-06-24 13:28:40.519476
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of class TheStarIE
    star = TheStarIE()
    # Check the value of member variable _VALID_URL
    expected = 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert star._VALID_URL == expected
    # Check the value of member variable BRIGHTCOVE_URL_TEMPLATE
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert star.BRIGHTCOVE_URL_TEMPLATE == expected

# Generated at 2022-06-24 13:28:41.298189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:28:49.637685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST.get('info_dict').get('id') == '4732393888001'
    assert ie._TEST.get('info_dict').get('ext') == 'mp4'