

# Generated at 2022-06-24 13:18:43.507537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    str(instance)

# Generated at 2022-06-24 13:18:50.717550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-24 13:19:00.079832
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import imp
    import sys
    import os.path
    from tester import Tester # File tester.py

    # Get the command line arguments passed to this program
    sys.argv = sys.argv[:1]

    # Add parent directory to module search path so import can work
    parent_dir = os.path.split(os.path.abspath(os.path.dirname(__file__)))[0]
    sys.path.append(parent_dir)

    # Import the test module
    TheStar = imp.load_source('TheStar', os.path.join(parent_dir, os.path.basename(__file__)))
    t = Tester() # Create an instance of the tester class

    # Construct an instance of class TheStarIE with arguments

# Generated at 2022-06-24 13:19:03.086657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert test_instance._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:07.206409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:19:08.115536
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #TODO
    pass

# Generated at 2022-06-24 13:19:08.653744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:14.594646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._match_id = util.url_basename
    ie._download_webpage = lambda *a, **kw: '''
        <div data-mainart-brightcove-video-id="4732393888001"/>
    '''
    ie._search_regex = lambda *a, **kw: '4732393888001'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = '4732393888001'


# Generated at 2022-06-24 13:19:15.251629
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:19:19.359271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ief = TheStarIE()
    video_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ief.extract(video_url)

# Generated at 2022-06-24 13:19:24.197496
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test of the class constructor
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:27.072513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

# Generated at 2022-06-24 13:19:31.153199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE with url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url, 'md5', 'id', 'title', 'description', 'uploader_id', 'timestamp', 'upload_date').download()

# Generated at 2022-06-24 13:19:34.228705
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:42.567579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # example:
    # http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    tc = TheStarIE()
    assert '4732393888001' == tc._VALID_URL
    assert '2c62dd4db2027e35579fefb97a8b6554' == tc._TEST
    assert 'tnajboljse_hladno_vreme_ji_bo_svoje_zemljevide_da_so_nekateri_se_bodo_v_druga_osredoto%C4%8Dil_na_druge_zemljevide' == tc.display_id

# Generated at 2022-06-24 13:19:46.120434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:54.934030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:59.793644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:20:09.443638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    ie.extract("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");

# Generated at 2022-06-24 13:20:14.488906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:17.212004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = TheStarIE._TEST['url']
    TheStarIE(test_url)



# Generated at 2022-06-24 13:20:18.174980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-24 13:20:23.383374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:24.333136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	extractor = TheStarIE()
	print(extractor)

# Generated at 2022-06-24 13:20:27.323604
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE({})
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:30.090906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.get_url_re() is not None
    assert ie.get_re_obj() is not None
    assert ie.get_valid_url() is not None


# Generated at 2022-06-24 13:20:31.765939
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 13:20:34.091405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception:
        assert False, 'TheStarIE constructor test fail.'


# Generated at 2022-06-24 13:20:35.019556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-24 13:20:42.481434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(TheStarIE._TEST)
    assert obj.IE_NAME == 'TheStar'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:20:43.769072
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:20:45.229064
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t.videourl

# Generated at 2022-06-24 13:20:49.159562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:53.547999
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Gives True if video-id is valid
    the_star_ie = TheStarIE()
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:55.287063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'TheStarIE' == ie.IE_NAME


# Generated at 2022-06-24 13:21:00.364957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:21:09.789139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id("https://www.thestar.com/sports/leafs/2016/05/17/auston-matthews-sets-bar-high-for-bill-dineen.html")
    ie._download_webpage("https://www.thestar.com/sports/leafs/2016/05/17/auston-matthews-sets-bar-high-for-bill-dineen.html", "auston-matthews-sets-bar-high-for-bill-dineen.html")

# Generated at 2022-06-24 13:21:10.654240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-24 13:21:15.461685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # Test an extractor of TheStarIE
    extractor = TheStarIE()
    assert extractor._VALID_URL is not None
    assert extractor._TEST['url'] is not None
    assert extractor._TEST['md5'] is not None
    assert extractor._TEST['info_dict'] is not None
    assert extractor._TEST['params'] is not None

# Generated at 2022-06-24 13:21:19.588687
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Compare a sample of values in test with the values in actual (TheStarIE.extract()) output dictionary
# In this unit test, we check that sample values in the webpage, url and expected result match

# Generated at 2022-06-24 13:21:25.797766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(
		'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
		)._real_extract(
		'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	)[1] == 'BrightcoveNew'

test_TheStarIE()

# Generated at 2022-06-24 13:21:31.819213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of class TheStarIE
    ie = TheStarIE()

    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:21:32.425131
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()

# Generated at 2022-06-24 13:21:34.139343
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.get_id() == "TheStar"

# Generated at 2022-06-24 13:21:37.116171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    # Should return a TheStarIE object
    assert TheStarIE(TheStarIE._VALID_URL)


# Generated at 2022-06-24 13:21:42.085884
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:21:48.323050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"

# Generated at 2022-06-24 13:21:51.207276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

test_TheStarIE()

# Test for constructor of class TheStarIE
# test = TheStarIE()


# Generated at 2022-06-24 13:21:58.761594
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
  # test that the constructor got _VALID_URL, _TEST and BRIGHTCOVE_URL_TEMPLATE
  assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
  assert 'url' in ie._TEST
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:03.650237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    result = TheStarIE(url)
    result.url
    result.config.get("http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001")

# Generated at 2022-06-24 13:22:05.112481
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:22:09.668955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.SUITABLE_URL == 'https?://'
    assert obj.IE_NAME == 'Thestar'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:10.918959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Unit test of class TheStarIE

# Generated at 2022-06-24 13:22:15.711970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = _make_result(TheStarIE)
    assert ie.__name__ == 'TheStarIE'
    assert ie.ie_key() == 'thestar:4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:18.213230
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return obj

# Generated at 2022-06-24 13:22:19.687778
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import TheStarIE
    t = TheStarIE.TheStarIE()
    t.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:22:20.082731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()

# Generated at 2022-06-24 13:22:22.362395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.thestarIE_brightcove_URL_TEMPLATE

# Generated at 2022-06-24 13:22:24.615163
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE is not None

# Generated at 2022-06-24 13:22:34.656654
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert i._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert i._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:22:39.271096
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE(params={'test':'test'})
    # Test for relative_url
    ie.url_result(
            ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
            'BrightcoveNew', '4732393888001')

# Generated at 2022-06-24 13:22:42.446548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
  i = InfoExtractor()
  assert TheStarIE.can_extract(i, url) == True

# Generated at 2022-06-24 13:22:43.085219
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:48.229603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for class TheStarIE
    url = TheStarIE()._VALID_URL
    url_match = TheStarIE._TEST
    
    print(TheStarIE()._real_extract(url))
    #print(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    print(url_match['url'])
    print(url_match['md5'])
    print(url_match['info_dict'])
    #print(TheStarIE._extract_brightcove_url(url_match['url']))
    print(url_match['params'])


# Generated at 2022-06-24 13:22:51.326078
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE(None)
    assert star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:52.024787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:55.095987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_converter import get_test_files_dir
    from os.path import join
    file_path = join(get_test_files_dir(), 'test.mp4')
    assert TheStarIE._test_suite(TheStarIE._TEST, {'test.mp4': file_path})

# Generated at 2022-06-24 13:23:03.464289
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:04.674928
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # The constructor is tested with #test_BrightcoveNewIE.
    pass

# Generated at 2022-06-24 13:23:07.119542
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

# Generated at 2022-06-24 13:23:08.606283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE()
    ie = TheStarIE()

# Generated at 2022-06-24 13:23:15.271548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert '4732393888001' == ie.brightcove_id
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == ie.brightcove_url


# Generated at 2022-06-24 13:23:23.326957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:31.973283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj1 = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    assert obj1.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:36.960300
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 0, {'skip_download': False, 'test': False, 'outtmpl': '%(id)s.%(ext)s', 'sleep': 0})

# Generated at 2022-06-24 13:23:46.454661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global unit_test_result

    unit_test_result = {}

    def _test_ie(test_dict):
        global unit_test_result
        try:
            test_dict['expect_result']
        except KeyError:
            test_dict['expect_result'] = True

        try:
            ie = TheStarIE()
            result = ie._real_extract(test_dict['url'])

            unit_test_result['actual_result'] = result
            unit_test_result['expect_result'] = test_dict['expect_result']
            unit_test_result['url'] = test_dict['url']
            unit_test_result['status'] = True
        except Exception as e:
            unit_test_result['actual_result'] = e

# Generated at 2022-06-24 13:23:53.910263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
    assert obj._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
    assert obj._match_id('http://www.thestar.com/life.html') == 'life'
    assert obj._match_id('http://www.thestar.com/life/life.html') == 'life'


# Generated at 2022-06-24 13:23:56.103164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test import make_test_instance

    test = make_test_instance(TheStarIE)
    assert test.br.video_id == '4732393888001'

# Generated at 2022-06-24 13:24:00.185702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', {}, {}, {}) != None

# Generated at 2022-06-24 13:24:08.706927
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''Unit test for constructor of class TheStarIE'''
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:14.049499
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_obj = TheStarIE()
    video_id = info_obj._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert video_id == "mankind-why-this-woman-started-a-men-s-skincare-line", "video_id does not match"

# Generated at 2022-06-24 13:24:14.728155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE("TheStar")

# Generated at 2022-06-24 13:24:16.087876
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == "thestar"
    assert ie.ie_name() == "TheStar"

# Generated at 2022-06-24 13:24:17.429111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE()
    assert(isinstance(o, TheStarIE))


# Generated at 2022-06-24 13:24:23.183757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:28.332651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie1 = InfoExtractor()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE != ie1.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:24:34.367389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:35.186870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:24:41.202738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"


# Unittest for method _real_extract() of class TheStarIE

# Generated at 2022-06-24 13:24:42.179925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:24:50.276345
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_main import test_main

# Generated at 2022-06-24 13:24:52.628937
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    pass

# Generated at 2022-06-24 13:25:00.085288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for title of extracted video for 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    input = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    extractor = TheStarIE()
    extractedDict = extractor._real_extract(input)
    assert extractedDict['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert extractedDict['id'] == '4732393888001'

# Generated at 2022-06-24 13:25:06.864105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = TheStarIE()
    result = obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'

# Generated at 2022-06-24 13:25:09.052984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE.TheStarIE()

# Generated at 2022-06-24 13:25:09.597559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:14.442069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST
    ie._ENTRY_PROTOCOL
    ie._real_extract()
    ie._download_webpage()
    ie._match_id()
    ie._search_regex()
    ie.url_result()

# Generated at 2022-06-24 13:25:18.797434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._download_webpage('https://www.thestar.com/news/world/2016/01/11/researchers-monitor-blue-whale-feeding-grounds-off-east-coast.html', 'researchers-monitor-blue-whale-feeding-grounds-off-east-coast.html')


# Generated at 2022-06-24 13:25:24.321375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:24.905415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:36.238947
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:38.094019
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:25:43.865397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(isinstance(ie, TheStarIE))

if __name__=='__main__':
    if len(sys.argv) >= 2:
        url = sys.argv[1]
    else:
        url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    ie = TheStarIE()
    output = ie.extract(url)
    print(output)

# Generated at 2022-06-24 13:25:51.595314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE({}, {}, {}, TheStarIE._TEST['url'])
    assert thestar.VALID_URL == TheStarIE._TEST['url']
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/794267642001/default/index.html?videoId=%s'
    return

# Generated at 2022-06-24 13:25:54.473499
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:26:01.074854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    obj1 = IE(TheStarIE._TEST)
    assert(obj1.url == TheStarIE._TEST['url'])
    assert(obj1._VALID_URL == TheStarIE._VALID_URL)
    assert(obj1._TEST == TheStarIE._TEST)
    assert(obj1._real_extract(obj1.url)['id'] == '4732393888001')

# Generated at 2022-06-24 13:26:09.781632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
	assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:11.576811
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    with pytest.raises(TypeError):
        TheStarIE('www.thestar.com')

# Generated at 2022-06-24 13:26:13.978975
# Unit test for constructor of class TheStarIE
def test_TheStarIE():  
    thestar_obj = TheStarIE()  
    return thestar_obj

# Unit test to get the title name

# Generated at 2022-06-24 13:26:19.147275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate the class
    brightcove_id = '4732393888001'
    the_star = TheStarIE(None, {})
    assert the_star.BRIGHTCOVE_URL_TEMPLATE % brightcove_id == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert the_star.IE_NAME == 'TheStar'

# Generated at 2022-06-24 13:26:23.398568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL = 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:24.903997
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    

# Generated at 2022-06-24 13:26:35.725735
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert theStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert theStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:26:36.514841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie is not None)


# Generated at 2022-06-24 13:26:37.129315
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:26:41.637062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Unit test for constructor of class TheStarIE")
	ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
	print(ie.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 13:26:42.277843
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract(None)

# Generated at 2022-06-24 13:26:52.426822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:26:53.525139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extractor = TheStarIE()
    print("tests")

# Generated at 2022-06-24 13:27:00.494795
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.test_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    ie.test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.test_params = {
            'skip_download': True,
    }
    assert ie.test()

# Generated at 2022-06-24 13:27:02.477055
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:27:03.034725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:05.714384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:11.275775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:11.843668
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:27:21.844194
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Constructor test
	try:
		TheStarIE()
		print("Constructor test success!\n")
	except:
		print("Constructor test fail!\n")

	# test_url_result test
	url_result_instance = TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	try:
		url_result_instance["url"]
		url_result_instance["ie_key"]
		url_result_instance["video_id"]
		print("test_url_result test success!\n")
	except:
		print("test_url_result test fail!\n")


# Generated at 2022-06-24 13:27:31.598603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._downloader != None
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:34.828259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return ie

# Generated at 2022-06-24 13:27:41.684104
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Constructor test for class TheStarIE
    """
    # Constructor test for class TheStarIE
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:27:42.653092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print(TheStarIE())


# Generated at 2022-06-24 13:27:44.260932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-24 13:27:45.199717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    init_unit_test(TheStarIE)

# Generated at 2022-06-24 13:27:47.238501
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the class could be instantiated
    thestar_class = TheStarIE('TheStarIE')
    assert isinstance(thestar_class, TheStarIE)

# Generated at 2022-06-24 13:27:51.471512
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-24 13:28:00.362236
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url="http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie.id="4732393888001"
    ie.format="mp4"
    ie.title="Mankind: Why this woman started a men's skin care line"
    ie.description="Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN."
    ie.channel="The Star"
    ie.timestamp=1454353482
    ie.upload_date="20160201"
    ie.age_limit=0
    ie.creator="Toronto Star"
    ie.title="Mankind: Why this woman started a men's skin care line"

# Generated at 2022-06-24 13:28:11.239569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:17.684491
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:21.423369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:23.038378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    TheStarIE('TheStarIE')
    test_TheStarIE()

# Generated at 2022-06-24 13:28:26.820372
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that constructor raises no errors
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:30.111754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:36.127754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE() #Create a TheStarIE object

    assert the_star_ie is not None #Check if it exists
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE != None #Check if it has a BRIGHT_COVE_URL_TEMPLATE
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE != '' #Check if it has a BRIGHT_COVE_URL_TEMPLATE
    assert the_star_ie._VALID_URL != None #Check if it has a VALID_URL
    assert the_star_ie._VALID_URL != '' #Check if it has a VALID_URL
    assert the_star_ie._TEST != None #Check if it has a TEST
    assert the_star_ie._TEST != ''

# Generated at 2022-06-24 13:28:42.395261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:44.567487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, TheStarIE)