

# Generated at 2022-06-24 13:18:46.244178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance._real_extract(instance._TEST['url'])

# Generated at 2022-06-24 13:18:47.266259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE)

# Generated at 2022-06-24 13:18:47.876655
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:18:53.229310
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for constructor of class TheStarIE"""
    video_information_extractor = TheStarIE()

    assert video_information_extractor.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert video_information_extractor.id == '4732393888001'

# Generated at 2022-06-24 13:18:56.183889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:03.737016
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert ie.video_id == "4732393888001"

# Generated at 2022-06-24 13:19:07.817616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(InfoExtractor)
    TheStarIE(InfoExtractor)._real_extract(url)

# Generated at 2022-06-24 13:19:10.609345
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:15.944550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE()
    assert unit_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert unit_test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:16.805047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:21.096671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar_test1 = TheStarIE()
    p = theStar_test1._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:28.008636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html')
    assert ie._match_id('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html') == 'mankind-why-this-woman-started-a-mens-skincare-line.html'

# Generated at 2022-06-24 13:19:29.216388
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'


# Generated at 2022-06-24 13:19:30.293813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})

# Generated at 2022-06-24 13:19:38.777702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE._VALID_URL=='https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:49.358112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-24 13:19:50.077293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:19:57.072550
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:20:07.462978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _info = TheStarIE().extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    #_info is a dictionary containing these following informations about the video:
    # _info['id']: i.e. the video id
    # _info['ext']: i.e. the video file extension
    # _info['title']: i.e. the video title
    # _info['description']: i.e. the video description
    # _info['uploader_id']: i.e. the uploader id
    # _info['timestamp']: i.e. the timestamp when the video was uploaded
    # _info['upload_date']: i.e. the date when the video was uploaded


# Generated at 2022-06-24 13:20:09.114172
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print('[+] Inside UT of TheStarIE')
	TheStar = TheStarIE()
	print('[-] Successfully completed UT of TheStarIE')
	return TheStar

# Generated at 2022-06-24 13:20:13.896710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Here is the url of main art, we have to extract easybrightcove from the html source.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE()
    theStarIE._real_extract(url)
    # Expected: http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001

# Generated at 2022-06-24 13:20:16.275592
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This just tests the constructor for now
    # TODO develop unit tests for TheStarIE
    ie = TheStarIE()

# Generated at 2022-06-24 13:20:21.449400
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    #assert ie.get_count() is 1
    #assert ie.get_uploader_id() is '794267642001'
    #assert ie.get_upload_date() is '20160201'

# Generated at 2022-06-24 13:20:23.119568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:20:25.775328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None)._VALID_URL == (
        'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:20:28.590931
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-24 13:20:39.036468
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_values = {
        'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
        'display_id': 'mankind-why-this-woman-started-a-men-s-skincare-line',
        'brightcove_id': '4732393888001'
    }
    thestar_ie = TheStarIE()
    thestar_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    actual_value = thestar_ie._real_extract(test_values['url'])

# Generated at 2022-06-24 13:20:45.038524
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance to test TheStarIE instance
    info_extractor = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

    # Test proper id returned
    assert '4732393888001' == info_extractor.test_info_dict['id']

# Generated at 2022-06-24 13:20:45.567862
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:56.996742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:21:02.696578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Declaring new instance of class TheStarIE
	TheStarIE_test = TheStarIE()
	# Assigning URL to test for
	url_test = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	# Calling _real_extract function of TheStarIE class with test URL as parameter
	TheStarIE_test._real_extract(url_test)
	print("Unit test for TheStarIE class test passed")

# Generated at 2022-06-24 13:21:06.176225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:21:06.757235
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:11.214600
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-24 13:21:12.445882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	obj.TheStarIE()


# Generated at 2022-06-24 13:21:19.334303
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:21.803729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("TheStarIE", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:31.721560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Instantiate class with different URLs
    test_url1 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_url2 = 'http://www.thestar.com/sports/basketball/raptors/2016/02/02/raptors-lose-to-clippers.html'
    test_url3 = 'http://www.thestar.com/entertainment/music/2016/02/03/tragically-hip-announces-2016-tour.html'
    test_url4 = 'http://www.thestar.com/business/2016/02/04/walmart-to-hire-10000-in-canada-this-year.html'

# Generated at 2022-06-24 13:21:32.657012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:42.483500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:43.002561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:21:45.480205
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__bases__[0].__name__ == 'InfoExtractor'


# Generated at 2022-06-24 13:21:47.543356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except TypeError:
        pass
    except OSError:
        pass
    return

# Generated at 2022-06-24 13:21:53.234068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/videozone/4732393888001/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/videozone/4732393888001/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:21:55.431829
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:21:58.722635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	from .brightcovenew import BrightcoveNewIE
	assert TheStarIE._downloader == BrightcoveNewIE._downloader
	assert TheStarIE._VALID_URL == BrightcoveNewIE._VALID_URL
	assert TheStarIE._TEST == BrightcoveNewIE._TEST



# Generated at 2022-06-24 13:22:04.724328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-24 13:22:14.758395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:17.601985
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    the_star_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:19.992455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TestVideo1 = TheStarIE()
    assert TestVideo1._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:28.986305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:30.625728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	#Unit test code here
	assert True


# Generated at 2022-06-24 13:22:32.002879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert True


# Generated at 2022-06-24 13:22:34.809740
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test class constructor 
	assert TheStarIE().brightcove_url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId'

# Generated at 2022-06-24 13:22:35.435051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:44.749331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    assert tsi._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert tsi._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert tsi._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:22:51.888136
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:22:54.480164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:55.281787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:22:55.983913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:58.466436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:22:59.923917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE() # Just instantiate an object of TheStarIE :D


# Generated at 2022-06-24 13:23:04.043273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._downloader is not None
    assert ie._WORKING is True
    assert ie.IE_NAME == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:06.848648
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:07.994590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE().BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:18.127663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:23:20.853618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Given
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")



# Generated at 2022-06-24 13:23:24.469102
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    y = TheStarIE()
    y.BRIGHTCOVE_URL_TEMPLATE
    y.BRIGHTCOVE_URL_TEMPLATE.find('.html?videoId=')
    y.BRIGHTCOVE_URL_TEMPLATE[y.BRIGHTCOVE_URL_TEMPLATE.find('.html?videoId=') + 15: ]


# Generated at 2022-06-24 13:23:26.157690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor is not None


# Generated at 2022-06-24 13:23:30.742451
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:23:31.236328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:36.778611
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')



# Generated at 2022-06-24 13:23:40.145006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:45.723292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:49.968165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.urls == ['http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001']

# Generated at 2022-06-24 13:23:50.548148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:00.320419
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test without url passed
    thestar_ie = TheStarIE()
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test with url passed
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar_ie = TheStarIE(url=url)
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:08.797808
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    StarIE = TheStarIE()
    assert StarIE.suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert not StarIE.suitable("http://www.bsd.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert StarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:09.358695
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:24:13.062512
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # test the existence of the class
    assert ie is not None


# Generated at 2022-06-24 13:24:15.788758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:26.900429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.__class__.__name__ == 'TheStarIE'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = info_extractor._match_id(url)
    assert display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    webpage = '<script>var mainartData={"brightCove":{"autoStart":"1","videoID":"4732393888001","playerID":"1290257590001"},"mainartBrightcoveVideoId":"4732393888001"};'
    brightcove_id = info_extractor._search_

# Generated at 2022-06-24 13:24:29.312941
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test constructor of class TheStarIE
    '''
    ieobj = TheStarIE()
    assert isinstance(ieobj, InfoExtractor)
    

# Generated at 2022-06-24 13:24:38.582508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.display_id == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:48.028152
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:49.334427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' == TheStarIE.ie_key()


# Generated at 2022-06-24 13:24:49.889599
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert True

# Generated at 2022-06-24 13:24:57.143396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar = TheStarIE()
    assert thestar.ie_key() == 'TheStar'
    assert thestar.suitable(url) == True
    assert thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:02.268151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.mmtimes.com/index.php/business/item/7643-myanmar-is-looking-for-alternative-sources-of-capital.html'
    ie = TheStarIE(url)
    inst = ie._real_extract(url)

# Generated at 2022-06-24 13:25:05.273543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:06.485082
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    re = TheStarIE()
    print(re)
	

# Generated at 2022-06-24 13:25:16.640232
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    This test verifies that TheStarIE correctly constructs URLs for
    TheStar, and returns the expected XML.
    """
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    star = TheStarIE(url=url, ie=None)

    url = star._real_extract(url)['url']
    xml = star._download_xml(url, url)

    # Check for expected XML at the end of the Brightcove video page.
    # This is how we verify that we're using the correct Brightcove video ID.
    # The full XML has a lot more stuff at the beginning.

# Generated at 2022-06-24 13:25:23.804882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.BRIGHTCOVE_URL_TEMPLATE != ""


# Generated at 2022-06-24 13:25:29.168781
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.name == 'thestar.com'
    assert the_star_ie.ie_key() == 'thestar'
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE is not None


# Generated at 2022-06-24 13:25:30.374160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-24 13:25:34.321821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:37.641342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:39.301433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE('TheStarIE', {}, False)
    assert inst


# Generated at 2022-06-24 13:25:39.754951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:25:46.180228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_name = "TheStarIE"
    imp_module = __import__('%s.%s' % (__package__, class_name), globals(), locals(), [class_name])
    imp_class = getattr(imp_module, class_name)
    imp_instance = imp_class()
    assert imp_instance.__class__.__name__ == class_name
    assert imp_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:47.834006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(isinstance(TheStarIE, InfoExtractor))


# Generated at 2022-06-24 13:25:56.093021
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    """unit test for class TheStarIE""" 
    import unittest

    class TestTheStarIE(unittest.TestCase): 
        """unit test for class TestTheStarIE""" 

        def setUp(self): 
            """set up for each test cases""" 
            pass 

        def tearDown(self): 
            """tear down for each test cases""" 
            pass 

        def test_TheStarIE(self): 
            """unit test for function TheStarIE""" 
            info_extractor = TheStarIE([])
            info_extractor.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') 

    test_suite = unittest.TestSuite

# Generated at 2022-06-24 13:25:57.754566
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Testing: The Star")
	module = TheStarIE()

# Generated at 2022-06-24 13:26:01.683208
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ts = TheStarIE(url)

# Generated at 2022-06-24 13:26:09.923203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE();
    thestar._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    thestar._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html','4732393888001');
    thestar._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');
    thestar.BRIGHTCOVE_URL_TEMPLATE;

# Generated at 2022-06-24 13:26:13.219935
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:26:17.433244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()
    tester.BRIGHTCOVE_URL_TEMPLATE
    tester._VALID_URL
    tester._real_extract
    tester._TEST
    tester.test()

# Main execution for testing purposes
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:26:20.255873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:21.425944
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:26:30.123197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This code only runs when 'test_TheStarIE' is called from the command line.
    ex = TheStarIE()
    # Use the next line to print all available information
    # print (ex.extract("http://video.thestar.com/kanary-superhero-one-year-later-1.4266398"))
    # Use the next line for partial results
    print (ex.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"))

# Generated at 2022-06-24 13:26:33.723965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    this_class = TheStarIE()
    assert (this_class._VALID_URL ==
            r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert (this_class._TEST['url'] ==
            'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert (this_class._TEST['md5'] ==
            '2c62dd4db2027e35579fefb97a8b6554')


# Generated at 2022-06-24 13:26:38.013455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    # Arguments for constructor
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'

    # Constructor 
    theStarIE = TheStarIE()
    webpage = theStarIE._download_webpage(url, display_id)
    brightcove_id = theStarIE._search_regex(
            r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            webpage, 'brightcove id')

    # Assertion
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-24 13:26:39.046156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	_ = TheStarIE({}, {})

# Generated at 2022-06-24 13:26:42.639279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(TheStarIE._downloader)._real_extract(url)

# Generated at 2022-06-24 13:26:52.966959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:56.566708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE({'_downloader': 'dummy', 'url': 'foo'})
    obj._login()
    obj._real_initialize()
    obj._real_extract({'_downloader': 'dummy', 'url': 'foo'})


# Generated at 2022-06-24 13:26:58.301608
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.to_screen("Unit test for TheStarIE")

# Generated at 2022-06-24 13:26:59.773041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    newInstance = TheStarIE()
    assert newInstance == newInstance

# Generated at 2022-06-24 13:27:07.945085
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    my_class = TheStarIE()
    my_class.BRIGHTCOVE_URL_TEMPLATE = 'thestar url: %s'
    
#         assert my_class.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert my_class.BRIGHTCOVE_URL_TEMPLATE == 'thestar url: %s'
    assert my_class._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:27:11.181536
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:27:18.318046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.video_info('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.video_info('http://www.thestar.com/news/canada/2016/02/01/progressive-conservative-party-of-ontario-elects-interim-leader-vic-fedeli.html')


# Generated at 2022-06-24 13:27:26.553740
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.__name__ == 'TheStar'
    assert ie.ie_key() == 'thestar'
    assert ie.test()['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:27:36.861638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:27:46.727530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test if the constructor of class TheStarIE works correctly,
       without going through the network"""
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'invalid url'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line', 'invalid display_id'
    assert ie.query == '4732393888001', 'invalid query'
    assert ie.BRIGHTCOVE_URL_

# Generated at 2022-06-24 13:27:49.198058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    assert thestarIE

# Generated at 2022-06-24 13:27:59.146273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test TheStarIE._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test TheStarIE._TEST
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._

# Generated at 2022-06-24 13:28:00.568740
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for a URL and basic functionality
    TheStarIE(TheStarIE._TEST)

# Generated at 2022-06-24 13:28:11.446700
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:22.381039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    assert class_._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert class_._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert class_._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:28:26.169561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(
        TheStarIE.ie_key()
    ).extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:28.429120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST['url'])

# Generated at 2022-06-24 13:28:31.770156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:33.453028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:28:34.259384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-24 13:28:35.107011
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:28:37.953136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

test_TheStarIE()

# Generated at 2022-06-24 13:28:39.674415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	obj.constructor_test()


# Generated at 2022-06-24 13:28:48.874373
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("234234")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'