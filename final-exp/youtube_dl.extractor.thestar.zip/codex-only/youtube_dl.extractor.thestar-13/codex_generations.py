

# Generated at 2022-06-24 13:18:48.682304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    assert thestarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:18:54.013203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, {}, None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE._TEST['params']['skip_download']



# Generated at 2022-06-24 13:18:54.571042
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:18:58.518251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, TheStarIE)


# Generated at 2022-06-24 13:19:02.870435
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:11.702432
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:19:15.740326
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_obj = TheStarIE({})
    ie_obj.BRIGHTCOVE_URL_TEMPLATE
    ie_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:17.407900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    p = TheStarIE()
    assert p.extractor_key == 'TheStar'

# Generated at 2022-06-24 13:19:20.887996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tst = TheStarIE()
    assert tst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:21.503450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:27.638519
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:28.591537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-24 13:19:31.479883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "common"))
    import t
    t.test_module_IE('TheStarIE')

# call test_TheStarIE()

# Generated at 2022-06-24 13:19:33.834629
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:36.694747
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', InfoExtractor)

# Generated at 2022-06-24 13:19:38.110085
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-24 13:19:38.645713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:19:42.611783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._real_extract({}) is not None

# Generated at 2022-06-24 13:19:52.579698
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(123)
    assert ie.__class__.__name__ == "TheStarIE"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-24 13:20:00.185524
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:03.780311
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:20:12.191080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert TheStarIE.is_suitable(test_url)
    ie = TheStarIE()
    assert ie.is_suitable(test_url)
    assert ie.url_result(test_url, 'TheStarIE', '4732393888001')
    assert str(ie.url_result(test_url, 'TheStarIE', '4732393888001')) == '<url_result TheStarIE 4732393888001>'
    assert ie.url_result(test_url, 'BrightcoveNew', '4732393888001')

# Generated at 2022-06-24 13:20:22.048200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with no params
        obj = TheStarIE()
        # Test with valid value for id
        assert obj.TheStarIE(id='4732393888001')
        # Test with valid value for url
        assert obj.TheStarIE(url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        # Test with invalid value for url
        assert obj.TheStarIE(url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.htmlssssssssssssssssssssssssssssssssssss')

# Generated at 2022-06-24 13:20:26.435672
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  obj = TheStarIE()

# Generated at 2022-06-24 13:20:29.213507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
        print("\nUnit test for constructor of class TheStarIE ran properly\n")
    except:
        print("\nUnit test for constructor of class TheStarIE failed\n")
    return


# Generated at 2022-06-24 13:20:34.326849
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance_class_name = str(type(instance))
    expected_class_name = '<class \'__main__.TheStarIE\'>'
    assert instance_class_name == expected_class_name, 'expected class name ' + expected_class_name + ' was got instead of ' + instance_class_name


# Generated at 2022-06-24 13:20:34.927427
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:38.228661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:42.583704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return 0


# Generated at 2022-06-24 13:20:45.569480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # pylint: disable=protected-access, no-value-for-parameter
    assert TheStarIE._VALID_URL == TheStarIE.__dict__['_VALID_URL']


# Generated at 2022-06-24 13:20:50.516619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that constructor of class TheStarIE is defined
    ie = TheStarIE()
    # Test type of ie variable
    assert type(ie) is TheStarIE
    # Check that "thestar" is defined in IE_DESC
    assert ie.IE_DESC in TheStarIE.IE_DESC

# Generated at 2022-06-24 13:20:54.398898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:02.858059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # since the IE is not classed as 'youtube' or 'generic'
    # the constructor will fail without the '_VALID_URL'
    # class member.
    ie = TheStarIE('www.thestar.com','some_id','some_url')
    #assert ie == None

# Generated at 2022-06-24 13:21:07.566958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("TheStarIE", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:10.530289
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert x

# Generated at 2022-06-24 13:21:18.592913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert (instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert (instance._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert (instance._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert (instance._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')

# Generated at 2022-06-24 13:21:19.270190
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 13:21:28.390682
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    URL = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    info_extractor._match_id(URL)
    info_extractor._download_webpage(URL, "mankind-why-this-woman-started-a-men-s-skincare-line")
    BRIGHTCOVE_URL = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    info_extractor

# Generated at 2022-06-24 13:21:31.964130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:34.078860
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Uses a hack to avoid requiring an actual network connection """
    ie = TheStarIE.ie_key()
    ie.BRIGHTCOVE_URL_TEMPLATE = '%s'
    ie.fetch_page = lambda url: '#EXTM3U\n'
    ie.url_result = lambda _: None
    ie._real_extract('foo')

# Generated at 2022-06-24 13:21:43.142154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for TheStarIE.__init__()
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE

    # Test for TheStarIE._valid_url()
    validURL = theStarIE.VALID_URL
    testValidURL = theStarIE._VALID_URL
    assert testValidURL == validURL
    test_cases = [
        ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', True),
        ('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', True)
    ]

# Generated at 2022-06-24 13:21:46.412203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:46.991206
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:21:48.145273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor)

# Generated at 2022-06-24 13:21:57.326730
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	
	# This function will test all the assertions in the constructor of class TheStarIE
	
	# Initializing test case
	info_extractor_test_case = InfoExtractor()
	info_extractor_test_case.set_url('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	info_extractor_test_case.set_md5('2c62dd4db2027e35579fefb97a8b6554')

# Generated at 2022-06-24 13:22:06.921150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''test TheStarIE constructor'''
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    id = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url, id)

# Generated at 2022-06-24 13:22:16.417437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Test class constructor
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.extractor_key == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test extract method
    result_dict = ie.extract(url)
    assert result_dict['id'] == '4732393888001'
    assert result_dict['ext'] == 'mp4'

# Generated at 2022-06-24 13:22:22.969207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    result = ie.extract(url)
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert result['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert result['uploader_id'] == '794267642001'
    assert result['timestamp'] == 1454353482
    assert result['upload_date'] == '20160201'

# Generated at 2022-06-24 13:22:23.515497
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:30.814889
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:22:32.175552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('thestar.com')

# Generated at 2022-06-24 13:22:32.811238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:37.594551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for TheStarIE
    info_extractor = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    info_extractor.extract(u'4732393888001')

# Generated at 2022-06-24 13:22:42.722307
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:22:43.794463
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE(InfoExtractor)

# Generated at 2022-06-24 13:22:44.187779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-24 13:22:47.185565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that _BRIGHTCOVE_URL_TEMPLATE of class TheStarIE contains %s
    assert '%s' in TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:22:47.735375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:22:50.862463
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:58.531571
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from computed_property import computed_property

    # print(hasattr(TheStarIE, 'url'))
    print(hasattr(TheStarIE, 'referer'))

    print(hasattr(InfoExtractor, 'params'))
    print(hasattr(InfoExtractor, '_download_webpage'))
    print(hasattr(InfoExtractor, '_real_initialize'))
    print(hasattr(InfoExtractor, '_download_json'))
    print(hasattr(InfoExtractor, 'report_warning'))


    # print(hasattr(thestarie, 'referer'))
    print(hasattr(TheStarIE, 'BRIGHTCOVE_URL_TEMPLATE'))
    print(hasattr(TheStarIE, '_download_webpage'))


# Generated at 2022-06-24 13:23:05.251105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    info_extractor = TheStarIE()
    result = info_extractor._real_extract(url)
    assert result[0] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert result[1] == 'BrightcoveNew'
    assert result[2] == "4732393888001"

# Generated at 2022-06-24 13:23:15.095043
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:23.197613
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:23:24.219764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()


# Generated at 2022-06-24 13:23:25.202953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-24 13:23:33.089615
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE(None)
    assert test_object.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'  # noqa
    assert test_object._VALID_URL == \
        r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:34.811263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None, "Constructor of class TheStarIE is not defined"

# Generated at 2022-06-24 13:23:39.051689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test of constructor of class TheStarIE
    # The constructor of class TheStarIE
    # actually constructs an instance of class
    # TheStarIE with the given parameters and return that instance
    thestar_instance = TheStarIE(None)

test_TheStarIE()

# Generated at 2022-06-24 13:23:39.640177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:45.454575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    #url = 'https://www.thestar.com/sports/hockey/2016/01/16/nhl-says-it-wont-pull-2016-all-star-game-from-nashville.html'
	extractor = TheStarIE()
	extractor.url_result(url)

# Generated at 2022-06-24 13:23:47.237249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie is not None


# Generated at 2022-06-24 13:23:54.544367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:03.753552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Test for if URL matches regex
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test for if URL of webpage is correct
    assert ie._downloader.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'


# Generated at 2022-06-24 13:24:05.008085
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert(repr(theStarIE))

# Generated at 2022-06-24 13:24:05.499292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:06.912275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE(None)

    assert test.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 13:24:15.346635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Run unit test for TheStarIE constructor
    """
    # Test with a valid URL
    ie = TheStarIE('https://www.thestar.com/entertainment/music/2016/02/12/jann-arden-announces-new-album-and-tour.html')
    ie.extract_info()
    assert ie.url == 'https://www.thestar.com/entertainment/music/2016/02/12/jann-arden-announces-new-album-and-tour.html'
    assert ie.domain == 'www.thestar.com'
    assert ie.video_id == '4740451275001'
    assert ie.display_id == 'jann-arden-announces-new-album-and-tour.html'

# Generated at 2022-06-24 13:24:19.716754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(theStar.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 13:24:25.942239
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    match_obj = ie._match_id(url)
    assert match_obj == "mankind-why-this-woman-started-a-men-s-skincare-line.html"


# Generated at 2022-06-24 13:24:36.709102
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    For unittest, the parameters for constructor of class TheStarIE is
        brightcove_id: the id of video from brightcove
        ie: instance of the InfoExtractor class
    """
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE._VALID_URL
    assert TheStarIE._TEST
    assert TheStarIE._TEST['url']
    assert TheStarIE._TEST['md5']
    assert TheStarIE._TEST['info_dict']
    assert TheStarIE._TEST['info_dict']['id']
    assert TheStarIE._TEST['info_dict']['ext']
    assert TheStarIE._TEST['info_dict']['title']
    assert TheStarIE._TEST['info_dict']['description']

# Generated at 2022-06-24 13:24:39.054070
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # constructor of class InfoExtractor
    InfoExtractor(1,2)
    # constructor of class TheStarIE
    TheStarIE(3,4)

# Generated at 2022-06-24 13:24:48.475363
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCO

# Generated at 2022-06-24 13:24:55.977783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:56.526753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:59.202761
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:25:08.518452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = ie._match_id(url)
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + brightcove_id

# Generated at 2022-06-24 13:25:13.638145
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:15.584003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert isinstance(thestar_ie, InfoExtractor)


# Generated at 2022-06-24 13:25:22.740613
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Test invalid URL
    try:
        obj = TheStarIE()
        assert False, 'Obj not expected to be created'
    except:
        assert True
    #Test valid URL
    obj = TheStarIE(url="http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj._match_id() == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert obj._real_extract(url="") == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    return True

# test_TheStarIE()

# Generated at 2022-06-24 13:25:23.375161
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:25:27.385663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return ie


# Generated at 2022-06-24 13:25:37.470102
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from bs4 import BeautifulSoup as bs
    from lxml import html
    test_TheStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    expected = '2c62dd4db2027e35579fefb97a8b6554'
    assert (test_TheStarIE._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'Mankind-Why-this-woman-started-a-men-s-skincare-line').md5 == expected)
    expected = '4732393888001'

# Generated at 2022-06-24 13:25:40.444530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:46.490018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    _VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:47.646663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert True


# Generated at 2022-06-24 13:25:48.622268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""Function to test TheStarIE"""


# Generated at 2022-06-24 13:25:50.369891
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE("TheStarIE", "http://www.thestar.com/")

# Generated at 2022-06-24 13:25:50.934486
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:53.338979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance, TheStarIE)
    instance = TheStarIE(False)
    assert isinstance(instance, TheStarIE)

# Generated at 2022-06-24 13:25:54.877086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.url == None


# Generated at 2022-06-24 13:25:55.470048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:59.974343
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'HTTPError' in str(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', {'skip_download': True}))

# Generated at 2022-06-24 13:26:09.045075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	thestarIE=TheStarIE()
	assert(thestarIE._VALID_URL=='https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
	assert(thestarIE._TEST.has_key('url'))
	assert(thestarIE._TEST.has_key('md5'))
	assert(thestarIE._TEST.has_key('info_dict'))
	assert(thestarIE._TEST.has_key('params'))
	assert(thestarIE._TEST['params'].has_key('skip_download'))

# Generated at 2022-06-24 13:26:13.406969
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None and "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s" == ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 13:26:17.976623
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._TEST['url'])
    assert ie._match_id(TheStarIE._TEST['url']) == '4732393888001'
    # test fetching YouTube video from The Star website
    assert ie._download_webpage(ie._TEST['url'], ie._match_id(ie._TEST['url'])) == ''

# Generated at 2022-06-24 13:26:24.667230
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    Star=TheStarIE()

    assert Star._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')=='mankind-why-this-woman-started-a-men-s-skincare-line.html'

    #Unit test for the skip download flag
    assert Star.params['skip_download']==True
    #Unit test for the URL template and the id of the video

# Generated at 2022-06-24 13:26:25.135165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

# Generated at 2022-06-24 13:26:29.710533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_result = TheStarIE('example', 'example', 'example')
    assert test_result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 13:26:31.174271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:26:38.356646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_TheStarIE = TheStarIE()
    # Assert attributes of class TheStarIE
    assert class_TheStarIE._VALID_URL.find(r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html') > -1
    assert class_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:26:40.952575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:43.268935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE()._VALID_URL == TheStarIE._VALID_URL)
    assert(TheStarIE()._TEST == TheStarIE._TEST)


# Generated at 2022-06-24 13:26:49.097544
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None)
    assert ie.name == "thestar"

    # Test url_result
    url = ie._real_extract(ie._TEST['url'])
    assert url['id'] == ie._TEST['url']
    assert url['url'] == ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'
    assert url['ie_key'] == 'BrightcoveNew'

# Generated at 2022-06-24 13:26:50.504446
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit_test = TheStarIE()
    assert not unit_test


# Generated at 2022-06-24 13:27:00.725658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert str(ie) == "TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')"
    assert str(ie._VALID_URL) == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:04.087548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:10.869750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = InfoExtractor()

    # Test 1: for the class, is if the URL is a valid one
    thestar_instance = TheStarIE(test_instance)
    thestar_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert (thestar_instance._is_valid_url(thestar_url) == True)

    # Test 2: for the class, is if the URL is an invalid one
    bbc_instance = TheStarIE(test_instance)
    bbc_url = 'http://www.bbc.co.uk/iplayer/episode/b06z2c6v'

# Generated at 2022-06-24 13:27:15.388961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of TheStarIE class
    theStar = TheStarIE()
    # Test its ID
    expected_id = 'TheStar'
    assert theStar._WORKING == True
    assert theStar.IE_NAME == expected_id


# Generated at 2022-06-24 13:27:23.395948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:27:26.371677
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:36.647628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# TheStarIE(info_dict)
	ie = TheStarIE( { 'id': '4732393888001',
            'ext': 'mp4',
            'title': 'Mankind: Why this woman started a men\'s skin care line',
            'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
            'uploader_id': '794267642001',
            'timestamp': 1454353482,
            'upload_date': '20160201'
	 } )
	assert ie.ext == 'mp4'
	assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
	assert ie.uploader_id == '794267642001'
	assert ie.timestamp == 1454353482

# Generated at 2022-06-24 13:27:37.885856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-24 13:27:39.224037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE(InfoExtractor)
    assert isinstance(instance, object)

# Generated at 2022-06-24 13:27:40.296478
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: Implement test
    assert False

# Generated at 2022-06-24 13:27:41.965031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie= TheStarIE()
    print ("Test browser of TheStarIE finished")

# Generated at 2022-06-24 13:27:50.224751
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Verify arguments are as expected
    assert thestarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Verify attributes are as expected
    assert thestarIE.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:53.160756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        test_f = TheStarIE()
    except Exception as e:
        print('Test constructor of TheStarIE class failed', e)
        raise


# Generated at 2022-06-24 13:27:59.178108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Should construct an instance of TheStarIE
    """
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-24 13:28:00.226776
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # type: () -> None
    TheStarIE()

# Generated at 2022-06-24 13:28:03.648921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:12.630743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Set up the mocks
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    webpage = "<script>var content = {mainartBrightcoveVideoId: '4732393888001'};</script>"
    ie = TheStarIE(None)
    ie._download_webpage = lambda url, id: webpage
    ie.url_result = lambda url, ie_key, video_id=None: ie_key

    # Execute the code to be tested
    result = ie._real_extract(url)

    # Verify the result
    assert result == 'BrightcoveNew'

# Generated at 2022-06-24 13:28:16.647591
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:25.024174
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Setup a mock for unit testing
    class MockIE(object):
        def url_result(self, url, ie, video_id):
            return url, ie, video_id

        def _download_webpage(self, url, display_id):
            return ''

        def _search_regex(self, pattern, string, name):
            return 'brightcoveId'

    mock_inst = MockIE()
    test_video = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    mock_inst.extract(test_video)

# Generated at 2022-06-24 13:28:29.287397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    val = TheStarIE()
    assert val.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:28:32.726991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:35.812033
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_object = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
	assert test_object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:45.733552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r"""
    >>> from pycaption import DFXPReader
    >>> from pprint import pprint
    >>> from youtube_dl.extractor import YoutubeIE
    >>> url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    >>> TheStarIE()._real_extract(url)['display_id']
    u'mankind-why-this-woman-started-a-men-s-skincare-line'
    >>> yt = YoutubeIE()
    >>> pprint(TheStarIE()._real_extract(url))

    """
    pass
