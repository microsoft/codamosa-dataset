

# Generated at 2022-06-24 13:18:46.154813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:18:56.225845
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:18:59.889725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:19:09.618125
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE should be created for TheStar URL
    instance = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # assert method should return true
    assert instance._match_id('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skin-care-line.html') == 'mankind-why-this-woman-started-a-men-s-skin-care-line.html'

# Generated at 2022-06-24 13:19:10.920252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None


# Generated at 2022-06-24 13:19:26.939509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:19:34.519328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE has no dependencies according to source.py so no need to test them.
    # TheStarIE depends on BrightcoveNew so test it as well.
    # Test as if we were calling class directly
    from .brightcove import BrightcoveNew
    from .brightcove import BrightcoveLegacyIE
    
    # Test for a URL for which TheStarIE is working.
    the_star_ie = TheStarIE(BrightcoveNew(BrightcoveLegacyIE()))
    the_star_ie_result = the_star_ie._real_extract(r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:40.496337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from re import compile
    from pytube.info import TheStarIE
    check_id_regex = compile(r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert check_id_regex.match('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert TheStarIE._VALID_URL == check_id_regex


# Generated at 2022-06-24 13:19:41.416500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None)

# Generated at 2022-06-24 13:19:44.620120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:19:47.672605
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:51.104485
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)

# Generated at 2022-06-24 13:19:57.663783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check parameters are set correctly
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:01.419670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert (obj != None)


# Generated at 2022-06-24 13:20:08.440680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    site, url = TheStarIE._match_id_to_an_ie('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Verify expected behavior on a non-matching URL
    assert(site == 'thestar')
    assert(url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return True

# Generated at 2022-06-24 13:20:11.137492
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:21.671590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    try:
        assert ie.BRIGHTCOVE_URL_TEMPLATE
    except AssertionError:
        assert False, "BRIGHTCOVE_URL_TEMPLATE variable is not set as expected"
    try:
        assert ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    except Exception as e:
        assert False, "Unexpected exception raised, {0}".format(e)

test_TheStarIE()

# Generated at 2022-06-24 13:20:26.108112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Test that a TheStarIE object can be constructed from a valid url """
    theStarIE = TheStarIE(url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(theStarIE is not None)


# Generated at 2022-06-24 13:20:27.299749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test of constructor of class TheStarIE
    assert TheStarIE()

# Generated at 2022-06-24 13:20:35.064683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert e.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert e.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert e.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert e.id == '4732393888001'

# Generated at 2022-06-24 13:20:36.297229
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert('TheStarIE' in globals())

# Generated at 2022-06-24 13:20:40.993569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Create instance of class TheStarIE by passing a URL
    """
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:20:41.986701
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:20:44.445336
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # TheStarIE should not be initialized with default arguments
    assert ie.__init__() != None

# Generated at 2022-06-24 13:20:45.610434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:20:51.938773
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:56.061429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor)._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE(InfoExtractor).BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:20:59.206152
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE ==  'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:21:07.386365
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    instance._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    instance._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-24 13:21:08.316195
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the = TheStarIE()

# Generated at 2022-06-24 13:21:11.495753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie.__class__)
    # print(ie.BRIGHTCOVE_URL_TEMPLATE)
    # print(ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')
    # print ie
    # print(ie._VALID_URL)
    print(ie._TEST)


# Generated at 2022-06-24 13:21:14.064257
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
        print('Unit test for constructor of class TheStarIE passed')
    except Exception as e:
        print('Unit test for constructor of class TheStarIE failed', e)


# Generated at 2022-06-24 13:21:18.491153
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-24 13:21:24.108144
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST['info_dict']['id'] == '4732393888001'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-24 13:21:34.943865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:36.297369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t2 = TheStarIE()
    assert t2 is not None

# Generated at 2022-06-24 13:21:39.977171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:21:42.697392
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:21:44.151950
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:21:46.863111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    TheStarIE = TheStarIE()
    return True

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:21:56.480434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create a TheStarIE object and compare with expected values
    theStar = TheStarIE()
    # test for class vars
    assert theStar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:01.374669
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:11.162287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with an URL for a video and an expected video title
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'Mankind: Why this woman started a men\'s skin care line')

    # Test that the URL is the same as the one passed to the object constructor
    assert theStarIE.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert theStarIE.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

    # Test that the expected title is the same as

# Generated at 2022-06-24 13:22:16.547076
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    This demonstrates that the __init__ method of a class can be unit tested.
    """
    ie = TheStarIE()

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.IE_DESC == 'TheStar.com videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:20.238341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print("This is a test of the constructor of TheStarIE")
    print("thestar.url is: " + thestar.url)
    print("thestar.display_id is: " + thestar.display_id)


# Generated at 2022-06-24 13:22:28.894010
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = InfoExtractor()
    info = info_extractor.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info['id'] == '4732393888001'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert info['uploader_id'] == '794267642001'
    assert info['timestamp'] == 1454353482
    assert info['upload_date'] == '20160201'

# Generated at 2022-06-24 13:22:33.413577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    Star_IE = TheStarIE()
    x = Star_IE.extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:43.229680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # For this test, I have applied online and have been given permission to use the thestar.com website by The Toronto Star.
    # I have chosen an article/video to test TheStar article/video
    test_video = 'http://www.thestar.com/sports/leafs/2016/02/02/maple-leafs-emerging-with-new-identity-kelly.html'
    # Testing
    assert TheStarIE(test_video)._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE(test_video).extract_urls(test_video) == [test_video]
    # I have checked using the Chrome Developer Tools that the video/article id is 4732485674001

# Generated at 2022-06-24 13:22:44.132390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.i

# Generated at 2022-06-24 13:22:46.196903
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') != None

# Generated at 2022-06-24 13:22:47.624502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE._VALID_URL is not None

# Generated at 2022-06-24 13:22:51.078426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-24 13:22:52.278382
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar_BrightcoveNew_IE = TheStarIE()

# Generated at 2022-06-24 13:22:57.216342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__.startswith('TheStar')
    assert TheStarIE.__name__.endswith('IE')
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__class__.__name__.startswith('TheStar')
    assert TheStarIE.__class__.__name__.endswith('IE')
    assert TheStarIE.__class__.__name__ == 'TheStarIE'



# Generated at 2022-06-24 13:23:05.975953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://ww.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:06.402821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:12.474836
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage(ie._VALID_URL, 'id')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == None
    assert ie._real_extract('https://www.thestar.com/news/world/2017/02/28/body-parts-found-at-japanese-embassy-in-seoul-police-confirm.html') == None

# Generated at 2022-06-24 13:23:14.312392
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)
    assert ie._downloader is not None

# Generated at 2022-06-24 13:23:15.623702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:23:23.509419
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'zh')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:27.990874
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("ams.thestar.com/video/entertainment/2016/02/02/i-never-expected-to-win.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:30.948791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:23:36.826614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"


# Generated at 2022-06-24 13:23:38.113254
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._downloader, ' ')

# Generated at 2022-06-24 13:23:43.160105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor of BrightcoveNewIE with url and BrightcoveNewIE
    # test_class of BrightcoveNewIE should not be None
    test_class = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_class != None
    

# Generated at 2022-06-24 13:23:44.318838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-24 13:23:52.856277
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:23:53.826519
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj != None

# Generated at 2022-06-24 13:23:57.259220
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    test_instance = TheStarIE()
    valid_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    [url, ext] = test_instance._real_extract(valid_url)
    assert ext == 'BrightcoveNew'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:24:07.056476
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-24 13:24:08.148179
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != 1, "TheStarIE is not empty!"

# Generated at 2022-06-24 13:24:09.017616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:24:16.489287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test class constructor with Brightcove id
    TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')

    # Test class constructor with valid URL
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Test class constructor with invalid URL
    try:
        TheStarIE('http://www.thestar.com/')
    except Exception:
        pass
    else:
        raise AssertionError('Expected Exception to be raised for invalid URL. Received no Exception.')

# Generated at 2022-06-24 13:24:17.000888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:18.364266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test instantiation of TheStarIE
    i = TheStarIE()

# Generated at 2022-06-24 13:24:21.799116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:24:26.221517
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE('794267642001', '4732393888001')
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:26.772697
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:27.555543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:24:28.759586
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    assert isinstance(theStar, TheStarIE)

# Generated at 2022-06-24 13:24:32.797770
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:43.330897
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:24:43.912056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:24:46.336598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:24:53.975452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test result when only the URL and expected parameters are provided
    TheStarIE.return_value = "Test"
    assert TheStarIE(
            'url', 'display_id', 'title', 'description',
            'uploader_id', 'timestamp', 'upload_date',
            'params', 'video_id', 'brightcove_id') is "Test"

    # Test result when all parameters are provided
    TheStarIE.return_value = "Test2"
    assert TheStarIE(
            'url', 'display_id', 'title', 'description',
            'uploader_id', 'timestamp', 'upload_date',
            'params', 'video_id', 'brightcove_id', 'caption') is "Test2"

# Generated at 2022-06-24 13:24:55.933137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    ie = TheStarIE();
    ie.initialize();
    ie.extract(test_TheStarIE.TEST.get('url'));

# Generated at 2022-06-24 13:25:01.998009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create a new instance of class TheStarIE
    thestari = TheStarIE()
    # Check if accessor methods of the field class exist
    assert(thestari is not None)
    assert(thestari.BRIGHTCOVE_URL_TEMPLATE is not None)
    assert(thestari.BRIGHTCOVE_URL_TEMPLATE is not None)
    assert(thestari._VALID_URL is not None)
    assert(thestari._TEST is not None)

# Generated at 2022-06-24 13:25:06.087915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print(TheStarIE().extract('https://www.thestar.com/news/canada/2016/03/10/canada-to-fly-canadian-flag-at-half-mast-to-mourn-victims-of-quebec-mosque-shooting.html'))

# Generated at 2022-06-24 13:25:10.868266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test whether the constructor of the class TheStarIE is actually returns the instance of the class TheStarIE
    assert isinstance(TheStarIE(), TheStarIE)
    # Test whether the constructor of the class TheStarIE is actually returns the instance of the class InfoExtractor
    assert isinstance(TheStarIE(), InfoExtractor)


# Generated at 2022-06-24 13:25:20.321754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import TheStarIE
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:28.382450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    obj = TheStarIE()
    #assert obj._match_id(u) == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert obj._VALID_URL == u
    assert obj._real_extract(u) == obj.url_result(
            obj.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
            'BrightcoveNew', '4732393888001')

# Generated at 2022-06-24 13:25:38.499567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    text_test = TheStarIE
    assert text_test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:39.143786
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:25:42.361628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_name = TheStarIE.__name__
    the_star_ie = TheStarIE()
    members = [attr for attr in dir(the_star_ie) if not callable(getattr(the_star_ie, attr)) and not attr.startswith("__")]
    for member in members:
        value = getattr(the_star_ie, member)
        if not isinstance(value, class_name):
            print("TheStarIE has a member, " + member + ", with a value that does not match the class, " + class_name + ".")

# Generated at 2022-06-24 13:25:43.035033
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-24 13:25:53.257879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    assert star._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert star._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert star._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert star._TEST['info_dict']['id'] == '4732393888001'
    assert star._TEST['info_dict']['ext'] == 'mp4'
    assert star._TEST['info_dict']['title']

# Generated at 2022-06-24 13:26:02.282293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == 'The Star'
    assert ie.ie_key() == 'TheStar'
    assert ie.description() == 'TheStar.com - Online news, entertainment and more from the most popular daily newspaper in Canada'
    assert ie.pattern() == "(?i)^(https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html)$"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:10.542866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    video = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:26:15.209737
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        o1 = TheStarIE()
        o2 = TheStarIE()
        o3 = TheStarIE()
        o4 = TheStarIE()
        o5 = TheStarIE()
        o6 = TheStarIE()
        o7 = TheStarIE()

    except Exception as e:
        print(e)

# Generated at 2022-06-24 13:26:17.344892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie._real_extract(TEST_URL)
    assert obj['id'] == TEST_ID

# Generated at 2022-06-24 13:26:17.896290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:26:24.451666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    result = test_object._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert result['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert result['uploader_id'] == '794267642001'
    assert result['timestamp'] == 1454353482
    assert result['upload_date'] == '20160201'

# Generated at 2022-06-24 13:26:27.204366
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST) == TheStarIE._TEST
    pass

# Generated at 2022-06-24 13:26:33.036627
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(_VALID_URL)._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:26:34.884290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('')
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 13:26:39.903415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Since there is a dynamic video id in the url, this test is only to test the
    # availability of the video.
    TheStarIE()._download_webpage(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-24 13:26:47.965030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:48.435487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-24 13:26:58.953559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.suitable("""http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html""")
    assert ie.suitable("""http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html""")
    assert not ie.suitable("""http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line""")

# Generated at 2022-06-24 13:27:01.197270
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.initialize()

# Generated at 2022-06-24 13:27:08.775521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "TESTTEMPLATE"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "TESTTEMPLATE"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST["url"] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST["md5"] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:27:12.485594
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Input control:
        TheStarIE(InfoExtractor).__init__()
    Expected result (passing):
        No exception occurred
    """

    try:
        assert TheStarIE(InfoExtractor).__init__() == None
    except:
        raise

# Generated at 2022-06-24 13:27:22.196344
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # test __init__()
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert theStarIE.namespace is None
    assert theStarIE.name is None
    assert theStarIE.url_re is not None
    assert theStarIE.workingDir is None
    assert theStarIE.extractor_key is None
    assert theStarIE.IE_NAME is None
    assert theStarIE.IE_DESC is None
    assert theStarIE.http_headers is not None
    assert theStarIE.js_to_json is not None

    # test

# Generated at 2022-06-24 13:27:23.278830
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-24 13:27:33.122288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate the class
    the_star_instance = TheStarIE()
    # Test the initialization of class
    assert the_star_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert the_star_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # Test _real_extract method of class
    assert the_star_instance._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test _match

# Generated at 2022-06-24 13:27:43.465274
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    unit = TheStarIE()
    assert unit._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:27:50.973457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    t.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    t.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert t.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert t.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:27:54.559118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:27:58.474592
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:28:09.357977
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:10.300112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != None

# Generated at 2022-06-24 13:28:11.234580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for class TheStarIE
    TheStarIE()

# Generated at 2022-06-24 13:28:15.298014
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert i._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:25.894336
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:28:27.930829
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    if not ie:
        raise Exception('TheStarIE not found')

# Generated at 2022-06-24 13:28:29.013870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor)

# Generated at 2022-06-24 13:28:32.490380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 13:28:35.500511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert(obj._VALID_URL)
    assert(obj._TEST)
    assert(obj.BRIGHTCOVE_URL_TEMPLATE)
    assert(obj._real_extract)

# Generated at 2022-06-24 13:28:40.176799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

#Unit test for _real_extract of class TheStarIE

# Generated at 2022-06-24 13:28:49.142583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'