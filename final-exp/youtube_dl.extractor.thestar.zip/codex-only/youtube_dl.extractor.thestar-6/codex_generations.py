

# Generated at 2022-06-24 13:18:49.092080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with a video URL
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar_ie = TheStarIE(video_url)
    # Test with an image URL
    image_url = 'http://www.thestar.com/content/dam/thestar/life/2016/02/17/in-a-relationship-how-to-keep-your-friendships-alive/refugees.jpg'
    thestar_ie = TheStarIE(image_url)

# Unit test suite for class TheStarIE

# Generated at 2022-06-24 13:18:58.820720
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # At time of writing, the test url is the only url actually working with TheStarIE
    # Test url is used as the parameter to constructor of TheStarIE
    ie = TheStarIE(url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test if the right type of string is returned
    assert isinstance(ie.BRIGHTCOVE_URL_TEMPLATE, str)
    # Test if the result of method _real_extract has the right key-value pairs
    assert ie._real_extract(url=ie.url).get('id') == '4732393888001'
    assert ie._real_extract(url=ie.url).get('ext') == 'mp4'
   

# Generated at 2022-06-24 13:19:00.968883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL, ie

# Generated at 2022-06-24 13:19:07.945990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_TheStarIE = TheStarIE()
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    test_TheStarIE._match_id(url)
    test_TheStarIE._real_extract(url)

# Generated at 2022-06-24 13:19:09.854527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').extract()

# Generated at 2022-06-24 13:19:12.624256
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_brightcove import BrightcoveNewTestCase
    class TheStarTestCase(BrightcoveNewTestCase):
        provider_key = 'thestar'
    TheStarTestCase().run()

# Generated at 2022-06-24 13:19:13.585319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:19:14.589670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()

# Generated at 2022-06-24 13:19:25.766049
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert IE.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert IE.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-24 13:19:30.674790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    inst = TheStarIE(None)
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:35.441095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:19:44.945837
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:50.557772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert class_._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:19:50.965125
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:19:53.908652
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # A test case for TheStarIE
    TheStar_test_result = TheStarIE()
    assert TheStar_test_result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:20:01.419483
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert '4732393888001' == ie. brightcove_id
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == ie.result

# Generated at 2022-06-24 13:20:04.523690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:20:07.220405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar._downloader = "UnitTest"
    thestar.download_webpage = lambda *args, **kwargs: (
        "<html><head></head><body>The page</body></html>")
    assert thestar._real_extract('http://www.thestar.com/something')

# Generated at 2022-06-24 13:20:08.076175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_ex = TheStarIE()


# Generated at 2022-06-24 13:20:09.244355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    assert ie.__class__ is TheStarIE

# Generated at 2022-06-24 13:20:19.332072
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:20.657184
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert ("TheStarIE" in dir(TheStarIE))
	assert (TheStarIE.__name__ == "TheStarIE")

# Generated at 2022-06-24 13:20:21.222063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:20:24.291664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:20:30.472509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	A test for constructor of class TheStarIE
	"""
	test_args = {
		'listformats': True,
		'extract_flat': True,
		'age_limit': 18,
		'disable_adblock': True,
		'quiet': True
	}
	theStarIE = TheStarIE(**test_args)

	assert theStarIE.listformats
	assert theStarIE.extract_flat
	assert theStarIE.age_limit == 18
	assert theStarIE.disable_adblock
	assert theStarIE.quiet

# Generated at 2022-06-24 13:20:33.907958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:20:36.248633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie.ie_key()
    assert obj == 'TheStar'


# Generated at 2022-06-24 13:20:37.125225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL is not None

# Generated at 2022-06-24 13:20:47.369661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE(None)
    assert test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:58.467408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()
    assert tester._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:20:59.243393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == "TheStarIE"

# Generated at 2022-06-24 13:20:59.767464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testClass = TheStarIE()

# Generated at 2022-06-24 13:21:00.599447
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:21:04.833683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'placeholder'
    # check regEx for class field VALID_URL
    test_case = TheStarIE._TEST
    assert ie._match_id(test_case['url']) == test_case['info_dict']['id']

# Generated at 2022-06-24 13:21:05.351254
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert True

# Generated at 2022-06-24 13:21:06.574640
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj_TheStarIE = TheStarIE()


# Generated at 2022-06-24 13:21:13.725806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/news/canada/2016/02/01/canadian-astronaut-describes-life-as-space-underdog.html')
    assert ie._download_webpage is not None
    assert ie._match_id('http://www.thestar.com/news/canada/2016/02/01/canadian-astronaut-describes-life-as-space-underdog.html') == 'canadian-astronaut-describes-life-as-space-underdog'
    assert ie._search_regex is not None

# Generated at 2022-06-24 13:21:20.913899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test extraction with embeded brightcove video
    # from http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    video_id = '4732393888001'
    test_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' % video_id
    test = TheStarIE()
    assert test._VALID_URL == TheStarIE._VALID_URL
    assert test._TEST[0] == TheStarIE._TEST[0]
    assert test._TEST[1] == TheStarIE._TEST[1]
    test_obj = test.url_result(test_url, 'TheStar')
    assert test

# Generated at 2022-06-24 13:21:23.291726
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:21:33.641411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check class variables
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert len(TheStarIE._TEST) == 5
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'

# Generated at 2022-06-24 13:21:35.645437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  t = TheStarIE(TheStarIE.__name__)
  assert isinstance(t, InfoExtractor)

# Generated at 2022-06-24 13:21:43.911557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:21:54.152953
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:21:56.694492
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:03.158121
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE_obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'Mankind: Why this woman started a men\'s skin care line', 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'md5:2c62dd4db2027e35579fefb97a8b6554', '4732393888001', 'mp4', '794267642001', 1454353482, '20160201')

# Generated at 2022-06-24 13:22:06.239681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    print(theStar)

# Unit test, comment out if you want to manually run all tests
# instead
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:22:11.203006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:13.218570
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None, None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:17.640899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:22:19.103557
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check if the class that is being tested is the right one
    assert('TheStarIE' == TheStarIE.__name__)

# Generated at 2022-06-24 13:22:24.169919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:22:26.832993
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');

# Generated at 2022-06-24 13:22:30.487254
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #test TheStarIE constructor
    test_obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-24 13:22:37.746933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert obj.display_id == "4732393888001"
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 13:22:45.446281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert a._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert a.IE_NAME == 'brightcove:new'
    assert a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert a.IE_NAME == 'brightcove:new'
    assert a.IE_DESC == 'BrightcoveNew'

# Generated at 2022-06-24 13:22:46.286287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(1, 2)

# Generated at 2022-06-24 13:22:48.518685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:22:56.617486
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = InfoExtractor()
    info.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    info.src = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    info.ext = '.mp4'
    info.id = '4732393888001'
    info.title = 'Mankind: Why this woman started a men\'s skin care line'
    info.description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    info.uploader_id = '794267642001'
    info.timestamp = 1454353482

# Generated at 2022-06-24 13:22:58.918818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')

# Generated at 2022-06-24 13:23:06.133126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_utils import get_testdata_files
    from .test_utils import load_tests, do_tests
    from .test_utils import print_expected, print_expected_results, print_actual, print_actual_results
    from .test_utils import assertEquals
    import os

    testdata_files = get_testdata_files(os.path.splitext(__file__)[0])

    tests = load_tests(
        (TheStarIE, ),
        testdata_files,
        )

    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://localhost/%s'

    do_tests(TheStarIE, tests)

# Generated at 2022-06-24 13:23:12.448851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    VIDEOID = '4732393888001'
    VIDEOIFRAME = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' % VIDEOID
    VIDEOURL = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732058289001'

    test_info = TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_

# Generated at 2022-06-24 13:23:15.794787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == True


# Generated at 2022-06-24 13:23:18.742539
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:23:24.293225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    # Test build URL
    assert t.ie_key() == 'TheStar'
    assert t.video_id == '4732393888001'
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.video_id == '4732393888001'

# Generated at 2022-06-24 13:23:24.872521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor = TheStarIE("TheStarIE")

# Generated at 2022-06-24 13:23:25.438587
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-24 13:23:26.543310
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())

# Generated at 2022-06-24 13:23:27.108407
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-24 13:23:28.031595
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-24 13:23:30.013216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    assert tsi.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:23:32.036908
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # To Run the unit test, we need to create an instance of the class first
    instance = TheStarIE()
    assert isinstance(instance, TheStarIE) == True

# Generated at 2022-06-24 13:23:38.067685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' in ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')


# Generated at 2022-06-24 13:23:38.764471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:23:39.455693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:40.348262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("TheStarIE", "The Star")

# Generated at 2022-06-24 13:23:40.880406
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:42.143260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ is TheStarIE

# Generated at 2022-06-24 13:23:42.805079
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE

# Generated at 2022-06-24 13:23:50.312362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This is a test for the constructor of class TheStarIE
    # It checks whether the correct extractor is selected for an URL.
    #
    # First, we have to create an instance of class InfoExtractor.
    # We get a list of all registered extractors via get_info_extractor().
    # We know that the TheStarIE extractor is the 15th in that list,
    # so we can use that.
    ie = InfoExtractor.get_info_extractor(15)
    # Now we can use the instance of TheStarIE that we have created.
    # We shall check whether it can handle the URL of The Star.
    assert ie._WORKING == True


# Generated at 2022-06-24 13:23:50.762893
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:23:56.063262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie != None)
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:23:58.265715
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-24 13:23:59.221664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())

# Generated at 2022-06-24 13:24:08.045255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
                   "http://player.theplatform.com/p/7wvmTC/MSNBCEmbeddedOffSite?guid=n_obama_ol_150515")
    assert ie.BRIGHTCOVE_URL_TEMPLATE =='http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:09.573766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    TheStarIE()

if __name__ == '__main__':

    test_TheStarIE()

# Generated at 2022-06-24 13:24:17.836031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("")
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie.extract("https://www.thestar.com/authors.kelly_grant.html")
    ie.extract("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie.extract("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-24 13:24:28.423188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:24:29.660450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-24 13:24:40.745350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for constructor of TheStarIE.
    # The constructor should return an object of type TheStarIE.
    # The constructor should take in one argument which is a string of the URL for the video.
    # The video being tested is http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    test_obj = TheStarIE(test_url)
    # The constructor should return an object of type TheStarIE.
    # Type returns the class type of the object.  It can also be used to test
    # the type of

# Generated at 2022-06-24 13:24:42.524717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    assert TheStarIE(TheStarIE._VALID_URL)

# Generated at 2022-06-24 13:24:51.582748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert inst._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert inst._TEST['info_dict']['id'] == '4732393888001'
    assert inst._TEST['info_dict']['ext'] == 'mp4'
    assert inst._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-24 13:24:56.132059
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor_obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info_extractor_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:24:59.806551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    the_star_result = t.extract('http://www.thestar.com/sports/basketball/2015/01/19/raptors-host-hollywood-nights-in-los-angeles.html')
    assert the_star_result is not None

# Generated at 2022-06-24 13:25:01.594660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Make sure constructor of class TheStarIE is correct
    instance = TheStarIE()
    assert instance

# Generated at 2022-06-24 13:25:09.319493
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # confirm that the web page is parsed correctly by the constructor.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(None)
    ie.extract(url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-24 13:25:09.846170
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:15.291221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiate the IE
    ie = TheStarIE()

    # URL to test
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Extract the video
    video = ie.extract(url)

    # Print the video details
    print(video)



# Generated at 2022-06-24 13:25:21.177932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:25:25.144156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:30.977057
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # get “TheStarIE” object
    ie = TheStarIE()
    # download any video from thestar.com
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:25:34.234325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("TheStarIE", "thestar.com")
    if obj.__class__.__name__ == 'TheStarIE':
        assert True
    else:
        assert False


# Generated at 2022-06-24 13:25:37.553588
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert(info_extractor.BRIGHTCOVE_URL_TEMPLATE ==
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-24 13:25:38.095339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:38.891889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	theStarIE = TheStarIE()
	theStarIE

# Generated at 2022-06-24 13:25:41.413691
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-24 13:25:44.887982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of class TheStarIE
    thestarie = TheStarIE()
    # Unit test for TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert thestarie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-24 13:25:49.089963
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert isinstance(the_star, TheStarIE)

# Generated at 2022-06-24 13:25:50.470352
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie is not None

# Generated at 2022-06-24 13:25:51.073390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:51.691743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:25:54.542680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    inst._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:25:55.555387
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE() is not None

# Generated at 2022-06-24 13:26:04.046744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = TheStarIE()
    the_star_info_extractor = InfoExtractor(obj._VALID_URL)
    assert the_star_info_extractor.suitable(url)
    assert the_star_info_extractor.IE_NAME == 'Thestar'

    # Calling real_extrat method of class TheStarIE
    the_star_info_extractor._real_extract(url)

# Generated at 2022-06-24 13:26:05.970819
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE({})
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError')

# Generated at 2022-06-24 13:26:14.328709
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from YoutubeDL.extractor.TheStar import TheStarIE

    # test for constructor
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', 'BrightcoveNew', '4732393888001')

# Generated at 2022-06-24 13:26:22.678056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-24 13:26:25.130246
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 13:26:29.299505
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

test_TheStarIE()

# Generated at 2022-06-24 13:26:32.876383
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(1)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-24 13:26:34.296110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie)

# Generated at 2022-06-24 13:26:36.439353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert type(ie) == TheStarIE

# Generated at 2022-06-24 13:26:39.947005
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:42.364407
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Testing TheStarIE class for constructor.
    """
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(url)

# Generated at 2022-06-24 13:26:45.254513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:46.642298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert callable (TheStarIE)

# Generated at 2022-06-24 13:26:47.094796
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:26:47.909061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-24 13:26:51.862946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.name() == 'The Star'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:26:52.507339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-24 13:27:02.418687
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Function to test class TheStarIE
	"""
	Video = TheStarIE()
	
	#display_id
	display_id = Video.extract_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

	try:
		assert display_id == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
	except AssertionError:
		print ("Extract id is not working..")	
	
	# correct url

# Generated at 2022-06-24 13:27:07.589959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.set_url("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.get_url() == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    return ie


# Generated at 2022-06-24 13:27:10.653752
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(
		TheStarIE.ie_key(), 
        TheStarIE._VALID_URL % {'id': '4732393888001'}
    )

# Generated at 2022-06-24 13:27:20.314817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    
    # Class instantiation by url
    thestar = TheStarIE()

    # Tests url value
    assert thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/]+)\.html'

    # Tests object instantiation
    assert isinstance(thestar, InfoExtractor)

    # Tests get_id function
    assert thestar._match_id(url) == '4732393888001'



# Generated at 2022-06-24 13:27:21.836881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# create constructor for class TheStarIE
	TheStarIE()

# Generated at 2022-06-24 13:27:24.610186
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    expected_result = TheStarIE
    assert type(ie) == expected_result, "unit test for TheStarIE.__init__() failed"


# Generated at 2022-06-24 13:27:28.785678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """The purpose of this Unit test is to check the constructor of class TheStarIE"""
    instance_1 = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert len(instance_1._VALID_URL) == 78
    assert len(instance_1._TEST) == 5
    assert len(instance_1.BRIGHTCOVE_URL_TEMPLATE) == 92
    # Test if the initialized URL is valid when downloading
    instance_1._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test if the initialized URL is

# Generated at 2022-06-24 13:27:30.978395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test the creation of TheStarIE
    """
    ie = TheStarIE()
    print(ie)
    assert ie


# Generated at 2022-06-24 13:27:36.343446
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test normal run
    instance = TheStarIE()
    instance._login()
    assert True    # TODO: implement your test here

    # Test exception cases
    try:
        pass    # TODO: implement your test here
    except Exception:
        pass    # TODO: implement your test here

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-24 13:27:37.933840
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE('TheStarIE'), InfoExtractor)

# Generated at 2022-06-24 13:27:39.315221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL is not None


# Generated at 2022-06-24 13:27:40.671375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that the TheStarIE class can be initialized.
    TheStarIE()

# Generated at 2022-06-24 13:27:42.011953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE

# Generated at 2022-06-24 13:27:43.277822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-24 13:27:44.195678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-24 13:27:45.512946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE.__name__ == 'TheStarIE')

# Generated at 2022-06-24 13:27:51.788666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor())._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE(InfoExtractor()).BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE(InfoExtractor())._TEST == TheStarIE._TEST
    assert TheStarIE(InfoExtractor()).BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert TheStarIE(InfoExtractor()).IE_DESC == 'brightcove:new'
    assert TheStarIE(InfoExtractor())._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-24 13:27:56.060002
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.new_video_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-24 13:27:57.652789
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    assert star


# Generated at 2022-06-24 13:28:01.472357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor)._WORKING == True
    assert TheStarIE(InfoExtractor)._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE(InfoExtractor)._TEST == TheStarIE._TEST


# Generated at 2022-06-24 13:28:05.040032
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:14.556240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj.TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-24 13:28:18.644434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    thestar._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-24 13:28:20.347126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # From file test_thestar_ie.py
    TheStarIE.test()

# Generated at 2022-06-24 13:28:22.780149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ test if TheStarIE can create an info extractor """
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-24 13:28:23.868985
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj


# Generated at 2022-06-24 13:28:28.204211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:31.529278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-24 13:28:34.180570
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t is not None, "object creation fails"

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-24 13:28:36.857511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'



# Generated at 2022-06-24 13:28:43.314923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'