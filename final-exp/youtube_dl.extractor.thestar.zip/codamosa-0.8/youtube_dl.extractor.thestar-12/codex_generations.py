

# Generated at 2022-06-12 18:17:30.204205
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    "Unit test for constructor of class TheStarIE"
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:35.306212
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:17:38.917315
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(TheStarIE._VALID_URL)

# Generated at 2022-06-12 18:17:42.989422
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()

    assert thestar_ie._VALID_URL 
    assert thestar_ie._TEST
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:17:44.712211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-12 18:17:49.681195
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    original_type = TheStarIE._real_extract
    TheStarIE._real_extract = lambda *args: '_real_extract'
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE._real_extract = original_type

# Generated at 2022-06-12 18:18:00.467130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/10/14/the-most-disruptive-force-in-the-world-today-is-climate-change-wake-up-to-this-reality-science-is-telling-us.html'
    brightcove_id = '4957510681001'

# Generated at 2022-06-12 18:18:06.368428
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # URL of a video that exists in The Star
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Create an instance of The Star InfoExtractor
    theStarIE = TheStarIE()
    # Test whether the url is suitable for this IE
    if (theStarIE._match_id(url)):
        # If it is, extract the video
        theStarIE.extract(url)
    # If not, throw an error
    else:
        # Since IE is a subclass of InfoExtractor, we can use its method
        raise Exception('URL does not match the pattern')

# Generated at 2022-06-12 18:18:07.555323
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor
    # TheStarIE()
    assert True

# Generated at 2022-06-12 18:18:17.350332
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the page is successfully download.
    # Because the page is relatively stable, so we only check the page length.
    # If the page length is less than 1000, then the page is not correctly downloaded.
    req = urllib2.Request('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    webpage = urllib2.urlopen(req).read()

    # Test the validity of video ID.
    # We only check the video ID of sample video.
    assert re.search(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',webpage).group(1)=='4732393888001'

    # Test the validity of video URL.

# Generated at 2022-06-12 18:18:20.497092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie) == TheStarIE

# Generated at 2022-06-12 18:18:21.490399
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-12 18:18:25.661089
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test a normal case
    TheStarIE()

    # test an error case i.e invalid URL or ID
    from . import _test_utils
    test_utils = _test_utils.ExtractorTest()

    with test_utils.assertRaisesRegexp(ValueError, 'Invalid URL'):
        TheStarIE()._real_extract('www.example.com')

    with test_utils.assertRaisesRegexp(ValueError, 'Invalid ID'):
        TheStarIE()._real_extract('http://www.thestar.com')

# Generated at 2022-06-12 18:18:28.377625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        print('constructor of class TheStarIE failed')
        return False
    return True


# Generated at 2022-06-12 18:18:37.597943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' 

# Generated at 2022-06-12 18:18:40.935075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Make sure that TheStarIE has implemented BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:18:42.376227
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:18:42.937123
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:43.524876
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:52.648215
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:58.267279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Args: test
    TheStarIE('test')

# Generated at 2022-06-12 18:19:00.613473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:04.412990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BCOV_ACCOUNT_ID == '794267642001'

# Generated at 2022-06-12 18:19:15.758939
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == "TheStarIE"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:16.337207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:24.494173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:25.653010
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie =TheStarIE()
    assert ie is not None

# Generated at 2022-06-12 18:19:26.648021
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj

# Generated at 2022-06-12 18:19:29.065914
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert test_TheStarIE


# Generated at 2022-06-12 18:19:34.045165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._download_webpage()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._download_webpage()
    ie._search_regex()
    ie._real_extract()
    ie._real_extract(ie._TEST['url'])
    ie._TEST['info_dict']['title']
    ie._real_extract(ie._TEST['url'])
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-12 18:19:50.775508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE();
    video._download_webpage = lambda url: url
    video._search_regex = lambda pattern, video, id: video

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    video_id = video._match_id(url)
    assert(video_id == '4732393888001')

    url_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:19:54.404268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('www.thestar.com')
    x = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print (x)
    # pass if no expections raised
    pass

# Generated at 2022-06-12 18:19:58.134664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Constructor
  assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
  

# Generated at 2022-06-12 18:20:02.181622
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert obj._TEST['info_dict']['id'] == '4732393888001'
    assert obj._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:20:04.908217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-12 18:20:11.180355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BASE_URL == "http://www.thestar.com"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.TIMEOUT == 15
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:20:13.833500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("TheStarIE", "thestar.com")
    print("Unit test for constructor of class TheStarIE")
    print("Result for test_TheStarIE: {}".format(ie != None))


# Generated at 2022-06-12 18:20:23.655724
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    # the url of brightcove video should be constructed using BRIGHTCOVE_URL_TEMPLATE with brightcove_id subbed in
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE % '12345' == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=12345'

    assert info_extractor._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

    # test when the url is not valid
    assert info_extractor._match

# Generated at 2022-06-12 18:20:24.572052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-12 18:20:26.883292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:20:49.899702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_TheStarIE = TheStarIE()
    TheStarIE._download_webpage = lambda *args: ""
    TheStarIE._search_regex = lambda *args: ""
    TheStarIE.url_result = loca

# Generated at 2022-06-12 18:20:52.889196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE =="http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s" 
    
    
    # Test the case where this the website is not accesible

# Generated at 2022-06-12 18:20:55.556257
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == "TheStarIE"

# Generated at 2022-06-12 18:21:00.544991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/auth/login.html?destination=http%3A%2F%2Fwww.thestar.com%2Flife%2F2016%2F02%2F01%2Fmankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:03.283133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:08.545245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	test.BRIGHTCOVE_URL_TEMPLATE
	test._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:09.298117
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._downloader)

# Generated at 2022-06-12 18:21:10.286868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()

# Generated at 2022-06-12 18:21:12.282119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:17.557418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:59.556673
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:22:06.107626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'thestar')
    test_queue = [
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
    ]

    # Loop through test urls, initiating appropriate extractors and printing info
    for url in test_queue:
        video = ie.url_result(url, 'TheStarIE')

# Generated at 2022-06-12 18:22:13.246619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test constructor no arguments
	obj = TheStarIE()
	assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert obj._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert obj._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:22:14.074618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor = TheStarIE(None)

# Generated at 2022-06-12 18:22:17.540114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_TheStar = TheStarIE(None)
    assert ie_TheStar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# --------------------------------------- TEST ---------------------------------


# Generated at 2022-06-12 18:22:19.102030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:22:19.651947
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-12 18:22:21.870317
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE(None)
	assert ie != None

# Generated at 2022-06-12 18:22:31.512379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.id == '4732393888001'
    assert ie.ext == 'mp4'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.uploader_id == '794267642001'
    assert ie.timestamp == 1454

# Generated at 2022-06-12 18:22:33.837662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert(t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-12 18:24:09.751000
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()
    # Exercise function.
    assert ie.IE.__name__ == "BrightcoveNew"
    ie.extract(url)

# Generated at 2022-06-12 18:24:18.250058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Test for the instance of BrightcoveNew
    try:
        assert isinstance(ie, InfoExtractor)
    except:
        # This is not an instance of BrightcoveNew
        return False

    # Test for video type and ID

# Generated at 2022-06-12 18:24:23.465287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert info_extractor._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert info_extractor._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert info_extractor

# Generated at 2022-06-12 18:24:24.114075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()


# Generated at 2022-06-12 18:24:28.706597
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.__class__ == TheStarIE, "factory failed to return TheStarIE"
    input_url = ie._url
    assert input_url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', \
    "TheStarIE expected input_url: http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html, but got: %s" %input_url
    regex_

# Generated at 2022-06-12 18:24:37.709885
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    current_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Test constructor of class TheStarIE when arguments are valid
    test_TheStarIE = TheStarIE(current_url)
    assert test_TheStarIE._TEST['url'] == current_url
    assert test_TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert test_TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert test_TheStarIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:24:47.605105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar.ie_key() == 'BrightcoveNew'
    assert thestar.BRIGHTCOVE_URL_TEMPLATE is not None
    assert thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert thestar._TEST is not None
    assert thestar._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert thestar._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert thestar._TEST

# Generated at 2022-06-12 18:24:49.979867
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    assert (TheStarIE._VALID_URL)


# Generated at 2022-06-12 18:24:52.781843
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    thestar_ie = TheStarIE()
    assert isinstance(thestar_ie.BRIGHTCOVE_URL_TEMPLATE, str)

# Generated at 2022-06-12 18:24:56.333989
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    info_extractor = TheStarIE()
    info_extractor._match_id(url)
    info_extractor._real_extract(url)