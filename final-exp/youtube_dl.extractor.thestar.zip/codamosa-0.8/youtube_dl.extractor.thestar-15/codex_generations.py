

# Generated at 2022-06-12 18:17:23.956527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:17:31.045873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.constructor_url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:36.283691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE('TheStarIE','http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info

# Generated at 2022-06-12 18:17:47.202661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL[0] == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE()._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:17:48.567456
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    expected = TheStarIE
    assert ie.__class__ == expected


# Generated at 2022-06-12 18:17:49.264262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:17:51.334759
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie == TheStarIE(None)
    assert ie is not None
    assert ie == InfoExtractor(None)


# Generated at 2022-06-12 18:18:01.802066
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # import needed libs, it's very important to import the module
    # of test class in first place
    from utils import mocker, urlopen_mock
    # this is the url to be tested on class, feel free to use all
    # available urls of extractor
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # download test page
    content = urlopen_mock(url)

    ie = TheStarIE()
    ie._download_webpage = mocker(ie._download_webpage, content)

    # create TheStarIE instance
    # if this method does not return data or raise error, test fail
    ie.extract(url)
    # if program goes here

# Generated at 2022-06-12 18:18:05.124635
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return test_TheStarIE()

print(TheStarIE())

# Generated at 2022-06-12 18:18:06.726800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(thestarcom_videoinfo_from_url=('',''))

# Generated at 2022-06-12 18:18:14.967527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    expected_result = "TheStarIE"
    assert t.__class__.__name__ == expected_result


# Generated at 2022-06-12 18:18:20.100810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of class TheStarIE
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:23.978100
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:27.423305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        assert False, 'Error with TheStarIE constructor'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:18:27.769276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-12 18:18:28.128398
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-12 18:18:29.148751
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE)

# Generated at 2022-06-12 18:18:33.247278
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.extract()

# Generated at 2022-06-12 18:18:37.215149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)
    #print ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:18:41.754654
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()
    assert ie._VALID_URL == url

# Generated at 2022-06-12 18:18:47.383454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:58.740831
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for instantiating TheStarIE object
    assert TheStarIE.__bases__[0] == InfoExtractor
    assert TheStarIE.__module__ == 'youtube_dl.extractor.thestar'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:04.781718
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # For some reason, the name of this test is one of the keys that make up
    # a test. I'm not entirely sure why this is, but this seems to be the
    # convention, so I'll follow it. This test creates an instance of
    # the class TheStarIE, and confirms that the creator of the instance
    # of that class is, in fact, TheStarIE.
    test_class = TheStarIE()
    assert test_class._downloader.__class__.__name__ == "TheStarIE"

# Generated at 2022-06-12 18:19:06.571729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-12 18:19:08.818765
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(None), TheStarIE)

# Generated at 2022-06-12 18:19:18.996673
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:19:21.252540
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.builtin == '4.4.20'

# Unit tests for module TheStarIE
import unittest


# Generated at 2022-06-12 18:19:24.253793
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(dict())
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001' == expected

# Generated at 2022-06-12 18:19:32.825489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert type(the_star_ie) == TheStarIE
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:33.731048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download(ie._VALID_URL)

# Generated at 2022-06-12 18:19:41.823191
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-12 18:19:45.479095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html").constructor() == 'TheStarIE'

# Generated at 2022-06-12 18:19:46.883973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()
    assert 'TheStarIE' in str(info)

# Generated at 2022-06-12 18:19:53.859097
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("test")
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "TheStarIE failed constructor test 1"
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', "TheStarIE failed constructor test 2"

# Generated at 2022-06-12 18:19:54.436961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:19:54.829132
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:04.163344
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s_info = TheStarIE._build_url_result('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert s_info == (None, 'BrightcoveNew', '4732393888001', {'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201'})

# Generated at 2022-06-12 18:20:08.179043
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj != None
    assert(obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-12 18:20:11.132279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-12 18:20:20.907211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Constructor test for class TheStarIE"""
    module = 'thestar_ie'
    thestarIE = TheStarIE()
    assert hasattr(thestarIE, '_download_webpage')
    assert thestarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:41.598503
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:45.988640
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE();
    except:
        raise AssertionError("TheStarIE constructor failed to create an instance of TheStarIE");
    assert True;


# Generated at 2022-06-12 18:20:47.093543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-12 18:20:51.506889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #TODO assert that the video has video_url
    the_star = TheStarIE()
    the_star.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-12 18:20:53.265748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test.test()

# Generated at 2022-06-12 18:20:58.308268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    expect = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    actual = instance.BRIGHTCOVE_URL_TEMPLATE % "4732393888001"
    assert expect == actual

# Generated at 2022-06-12 18:21:02.400621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    # testing for __init__ method
    assert tsi.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

#Unit test for _real_extract of class TheStarIE

# Generated at 2022-06-12 18:21:03.205081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()


# Generated at 2022-06-12 18:21:03.759423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:04.652180
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()

# Generated at 2022-06-12 18:21:48.199281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', None)

# Generated at 2022-06-12 18:21:51.241836
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:53.553764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for successful instantiation of an object of class TheStarIE
    assert TheStarIE() != None

# Generated at 2022-06-12 18:22:03.500698
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert result
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'
    assert result['title'] == u'Mankind: Why this woman started a men\'s skin care line'
    assert result['description'] == u'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert result['uploader_id'] == '794267642001'
    assert result['timestamp'] == 1454353482
    assert result['upload_date'] == '20160201'

# Generated at 2022-06-12 18:22:04.038946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:07.270472
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(id='/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None


# Generated at 2022-06-12 18:22:11.645749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:22:15.345098
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:22:21.809668
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert result._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:22.715967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None).to_screen('Test passed')

# Generated at 2022-06-12 18:23:54.356957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:56.221454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Checks that the constructor of TheStarIE works.
    """
    ies = TheStarIE()
    # Test that this doesn't raise
    str(ies)


# Generated at 2022-06-12 18:23:57.945831
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(ie._TEST['url'])


# Generated at 2022-06-12 18:24:00.015164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_desc() == 'The Star'

# Generated at 2022-06-12 18:24:04.861045
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing constructor of class TheStarIE using test data
    thestar = TheStarIE({}, {})

    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:05.374211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:24:07.450062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for correct class name.
    theStarIE = TheStarIE()
    assert theStarIE.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:24:12.330237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(ie)
    print(ie.ie_key())
    print(ie.ie_keywords())
    print(ie.get_settings())
    print(ie.get_settings_xml())
    print(ie.get_params())
    print(ie.get_params_xml())


# Generated at 2022-06-12 18:24:19.560772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    assert thestarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:20.243923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
