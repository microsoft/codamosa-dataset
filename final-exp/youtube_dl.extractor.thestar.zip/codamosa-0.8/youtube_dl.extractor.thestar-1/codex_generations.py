

# Generated at 2022-06-12 18:17:30.005485
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import InfoExtractor
    from .brightcove import BrightcoveNewIE
    from .theplatform import ThePlatformIE

    i = InfoExtractor(TheStarIE.ie_key())
    assert i.ie_key() == "TheStar"
    assert i.working == True
    assert i.suitable("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert i.suitable("https://www.thestar.com/news/canada/2016/02/01/song-and-dance-man-premier-kathleen-wynne-visits-broadway.html")

# Generated at 2022-06-12 18:17:35.117983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:17:46.149553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(
        TheStarIE._VALID_URL,
        TheStarIE._BRIGHTCOVE_URL_TEMPLATE,
        TheStarIE._TEST)
    assert (ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:17:55.880396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test the class TheStarIE
    '''
    import sys
    if sys.version_info.major == 2:
        import urllib
        url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        video_id = TheStarIE._match_id(url)
        assert video_id == 'mankind-why-this-woman-started-a-men-s-skincare-line.html'

        # test _real_extract(url)
        host = urllib.splithost(url)
        host = urllib.splittype(host[0])[0] # get scheme. For example, get 'http' from 'http://www.thestar.

# Generated at 2022-06-12 18:17:59.193608
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:00.077582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE
    assert InfoExtractor

# Generated at 2022-06-12 18:18:06.674684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = ie.url_result(
        ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
        'BrightcoveNew', '4732393888001')
    assert obj.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert obj.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert obj.uploader_id == '794267642001'
    assert obj.timestamp == 1454353482
    assert obj.upload_date == '20160201'

# Generated at 2022-06-12 18:18:07.232760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:17.016533
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:18:24.148824
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:27.414086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('test')


# Generated at 2022-06-12 18:18:36.998658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:38.981547
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-12 18:18:39.531981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:40.358216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().extractor_key() == 'TheStar'

# Generated at 2022-06-12 18:18:48.928198
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert info.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert info.ext == "mp4"
    assert info.title == "Mankind: Why this woman started a men\'s skin care line"
    assert info.description == "Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN."
    assert info.id == None
    assert info.uploader_id == "794267642001"
    assert info.timestamp == 1454353482

# Generated at 2022-06-12 18:18:59.421685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    inst._VALID_URL = 'https://www.thestar.com/content/thestar/news/gta/2016/03/22/at-least-one-victim-of-toronto-park-shooting-has-gta-gang-ties-sources-say.html'

# Generated at 2022-06-12 18:19:03.302553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie.get_id()=='4732393888001'


# Generated at 2022-06-12 18:19:07.505351
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Basic test cases for testing the constructor of TheStarIE
    """

    # Valid cases
    # Case 1: thestar.com
    try:
        TheStarIE(TheStarIE.ie_key())
    except Exception:
        assert False

    # Invalid cases
    # Case 1: No parameter
    try:
        TheStarIE()
        assert False
    except TypeError:
        pass

    # Case 2: empty parameter
    try:
        TheStarIE('')
        assert False
    except AssertionError:
        pass



# Generated at 2022-06-12 18:19:14.660037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:26.055527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # For testing this video, the source video is not available, it is set to a video which can be test
    obj = TheStarIE()
    obj._download_webpage = lambda url, display_id: open("test_html","r").read()
    obj._search_regex = lambda regex, string, name: "4732393888001"

# Generated at 2022-06-12 18:19:26.487780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-12 18:19:34.316434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for valid url
    result = TheStarIE._build_brighcove_url('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    right_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert result == right_result
    # test for invalid url
    result = TheStarIE._build_brighcove_url('https://www.thestar.com/life/2016/02/01/mankind-why-this-woasdfasdft-started-a-men-s-skincare-line.html')
    assert result is None

# Generated at 2022-06-12 18:19:36.333287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE, InfoExtractor)

# Generated at 2022-06-12 18:19:36.929271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:38.724634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    assert isinstance(tsi, TheStarIE)


# Generated at 2022-06-12 18:19:42.028826
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE.TheStarIE = TheStarIE('test_TheStarIE')
    print('test_TheStarIE.TheStarIE.constructor done')

test_TheStarIE()

# Generated at 2022-06-12 18:19:46.445277
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ieobj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Unit test for method extract of class TheStarIE
    ieobj.extract()

# Generated at 2022-06-12 18:19:51.797612
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of class TheStarIE and test its constructor
    print ("\nTesting constructor of class TheStarIE...")
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:19:54.559179
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:20:07.301154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._download_webpage(
		'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
		'4732393888001')

# Generated at 2022-06-12 18:20:11.369178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE()
    instance = theStarIE.suitable(url)
    assert instance == True



# Generated at 2022-06-12 18:20:21.076905
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:26.086393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    brightcove = TheStarIE()
    assert brightcove.BRIGHTCOVE_URL_TEMPLATE is 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert brightcove._VALID_URL is 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'


# Generated at 2022-06-12 18:20:31.809850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ie = TheStarIE()
    assert(_ie.name == "TheStarIE")
    assert(_ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")

# Generated at 2022-06-12 18:20:32.577266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-12 18:20:33.513033
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-12 18:20:36.341111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None


# Generated at 2022-06-12 18:20:39.538807
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    extractor = TheStarIE()
    assert isinstance(extractor, TheStarIE)
    assert isinstance(extractor, InfoExtractor)


# Generated at 2022-06-12 18:20:45.387907
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE = 'url'
    ie._downloader
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:21:02.517061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    objTheStarIE = TheStarIE(None)
    assert objTheStarIE

# Generated at 2022-06-12 18:21:09.264305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == "Mankind: Why this woman started a men's skin care line"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:21:10.769731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        assert(TheStarIE())
    except NotImplementedError:
        assert(1 == 0)

# Generated at 2022-06-12 18:21:13.102652
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert 'TheStarIE' == type(the_star).__name__

# Generated at 2022-06-12 18:21:19.062550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing for TheStarIE with brightcove_id
    brightcove_id = '4732393888001'
    test_example = TheStarIE(brightcove_id)
    assert test_example.BRIGHTCOVE_URL_TEMPLATE % brightcove_id == test_example.url_result

# Generated at 2022-06-12 18:21:22.224867
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor of TheStarIE class
    TheStarIE()

# Generated at 2022-06-12 18:21:23.547046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    it = TheStarIE()

# Generated at 2022-06-12 18:21:24.807987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert isinstance(a, TheStarIE)

# Generated at 2022-06-12 18:21:25.596716
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:21:29.403108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of class TheStarIE
    theStarIE = TheStarIE()
    # Check for class attribute _VALID_URL
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:08.670387
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:12.014461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance.BRIGHTCOVE_URL_TEMPLATE
    instance.star_template
    if __name__ == '__main__':
        test_TheStarIE()

# Generated at 2022-06-12 18:22:15.066868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:15.583922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-12 18:22:16.945554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:23.002554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = the_star._real_extract(url)
    assert result['id'] == '4732393888001'

# Generated at 2022-06-12 18:22:32.333222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_b = TheStarIE({'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'})
    assert ie_b._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie_b._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie_b._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie_b

# Generated at 2022-06-12 18:22:33.721120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html','7-Zip')

# Generated at 2022-06-12 18:22:37.987589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    data = {}
    data['id'] = '4732393888001'
    data['ext'] = 'mp4'
    data['title'] = 'Mankind: Why this woman started a men\'s skin care line'
    data['description'] = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    data['uploader_id'] = '794267642001'
    data['timestamp'] = 1454353482
    data['upload_date'] = '20160201'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    temp_class = TheStarIE()
    assert url == temp_class._TEST['url']
    assert temp_class._

# Generated at 2022-06-12 18:22:40.999039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert hasattr(theStarIE, '_type')
    assert hasattr(theStarIE, 'ie_key')
    assert hasattr(theStarIE, 'BRIGHTCOVE_URL_TEMPLATE')

# Generated at 2022-06-12 18:24:16.618155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()

# Generated at 2022-06-12 18:24:17.334582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().IE_NAME == "TheStar"

# Generated at 2022-06-12 18:24:22.823281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # Initializes a TheStarIE instance
    thestar_ie = TheStarIE()
    # Verifies the class attributes
    assert thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:23.500291
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    TheStarIE()

# Generated at 2022-06-12 18:24:28.068473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.jsinterp import JSInterpreter
    from youtube_dl.extractor import get_info_extractor

    url = 'http://www.thestar.com/entertainment/2016/06/30/miley-cyrus-to-perform-at-mtv-video-music-awards-with-dead-petz.html'
    display_id = 'miley-cyrus-to-perform-at-mtv-video-music-awards-with-dead-petz'

# Generated at 2022-06-12 18:24:37.196498
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE(object, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:47.476230
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/business/2016/01/20/ontario-budget-takes-hits-for-employment-and-economic-planning.html')
    expected_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4730306414001'

# Generated at 2022-06-12 18:24:48.490397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie != None

# Generated at 2022-06-12 18:24:57.630171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.(?P<suffix>html)'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST

# Generated at 2022-06-12 18:25:01.748955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert(the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
