

# Generated at 2022-06-12 18:17:26.136410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:31.543361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # pylint: disable=line-too-long
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE(TheStarIE, url)
    instance = theStarIE._download_webpage(url, '4732393888001')
    # pylint: enable=line-too-long

# Generated at 2022-06-12 18:17:33.879507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE.IE_NAME, TheStarIE._VALID_URL)._VALID_URL == TheStarIE._VALID_URL


# Generated at 2022-06-12 18:17:34.875375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()


# Generated at 2022-06-12 18:17:41.255951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._download_webpage = lambda url, display_id: ''
    ie._search_regex = lambda regex, webpage, name: ''
    # Test the published field (upload_date)
    assert ie._real_extract(ie._VALID_URL)['published'] == '20160201'

# Generated at 2022-06-12 18:17:44.952613
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        # Unit Test
        TestTheStarIE = TheStarIE()
        assert(TestTheStarIE != None)
    except:
        # Unit Test
        print("Failed to create instance of TheStarIE")
        assert(False)

# Generated at 2022-06-12 18:17:45.525298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-12 18:17:46.531347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-12 18:17:55.052211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'https://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.id == '4732393888001'
    assert ie.timestamp == 1454353482


# Generated at 2022-06-12 18:18:03.769079
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:17.426598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE_instance = TheStarIE()

# Generated at 2022-06-12 18:18:19.997868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:18:20.739048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-12 18:18:26.731943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:27.763005
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()



# Generated at 2022-06-12 18:18:33.140988
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:33.744247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:36.341088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test instance creation
	instance = TheStarIE()
	# Test whether the instance created successfully or not
	assert instance != None

# Generated at 2022-06-12 18:18:37.384643
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()._TEST


# Generated at 2022-06-12 18:18:39.026905
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert isinstance(a, InfoExtractor)

# Generated at 2022-06-12 18:18:50.474664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:51.095402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:53.861800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsie = TheStarIE()
    assert tsie._VALID_URL



# Generated at 2022-06-12 18:18:57.215940
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_ = TheStarIE()
    assert(test_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')


# Generated at 2022-06-12 18:18:59.724267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    e._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:19:02.196892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.assertTrue(isinstance(ie, InfoExtractor))
    ie.assertTrue(isinstance(ie, TheStarIE))

# Generated at 2022-06-12 18:19:02.751235
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:05.470581
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
	return 1;

# Generated at 2022-06-12 18:19:16.916879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
	assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
	assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'
	assert TheStarIE._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-12 18:19:17.804932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:27.014047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'BrightcoveNew'

# Generated at 2022-06-12 18:19:32.519558
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests only the constructor
    info_extractor = TheStarIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:19:36.087936
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    m = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert_equal(e.BRIGHTCOVE_URL_TEMPLATE % ('4732393888001'), m)

# Generated at 2022-06-12 18:19:44.930644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for case when url valid
    test_case = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE(test_case)
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theStarIE._downloader.params['usenetrc'] == True
    assert theStarIE._downloader.params['verbose'] == False
    assert theStarIE._downloader.params['quiet'] == False
    assert theStarIE._downloader.params['no_warnings'] == False

# Generated at 2022-06-12 18:19:51.441897
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests that class constructor correctly determines whether it can handle a link.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Tests that class constructor correctly determines whether it can handle a link.
    extractor = TheStarIE()
    assert extractor.suitable(url) is True

    # Tests that class constructor recognizes a support link as unsuitable for this extractor.
    url = 'https://flash.rtl.be/index.php?videoid=2188709'
    assert extractor.suitable(url) is False

# Generated at 2022-06-12 18:19:51.925656
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:53.742744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert str(ie.__class__) == '%s.TheStarIE' % __name__

# Generated at 2022-06-12 18:19:55.729966
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-12 18:19:57.307884
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:58.335410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("url", "name")

# Generated at 2022-06-12 18:20:21.543979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage = lambda url, display_id: test_TheStarIE._TEST_HTML
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

test_TheStarIE._TEST_HTML = r'''
<html>
<head>
  <script>
    var mainartBrightcoveVideoId = "4732393888001";
  </script>
</head>
</html>
'''

# Generated at 2022-06-12 18:20:24.302775
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:20:29.729855
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = '4672937485001'
    brightcove_id = '4672937485001'
    display_id = 'good-lookin-out/'
    url = 'http://www.thestar.com/good-lookin-out/'
    theStar_instance = TheStarIE(url, display_id)
    assert theStar_instance._match_id(url)
    theStar_instance._download_webpage(url, display_id)
    theStar_instance._real_extract(url)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:20:31.681792
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE(None, None)
    assert tsi.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:33.354489
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStar = TheStarIE(thestarcom.TheStarIE._create_ie_instance())
    print(test_TheStar)


# Generated at 2022-06-12 18:20:37.146134
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Test constructor of class TheStarIE
	"""
	# Test the class can be constructed
	ext = TheStarIE()
	# Test the class constructor function returns instance of class TheStarIE
	assert isinstance(ext, TheStarIE)

# Generated at 2022-06-12 18:20:40.782173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})
    info = instance._real_extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:20:45.533135
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/sports/basketball/2016/01/31/raptors-next-stop-in-their-make-or-break-road-trip-is-chicago.html")
    print (ie.url)
    print (ie.BRIGHTCOVE_URL_TEMPLATE)
    print (ie._VALID_URL)
    print (ie._TEST)
    print (ie._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "Life"))
    print (ie)

# Generated at 2022-06-12 18:20:47.253550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Constructor test for TheStarIE
    """
    info_extractor = TheStarIE()


# Generated at 2022-06-12 18:20:51.366437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == \
           'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:21:30.947910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Testing the YouTube constructor
	ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", {})
	assert ie.get_domain() == "thestar.com"
	assert ie.get_name() == "thestar"

# Generated at 2022-06-12 18:21:31.478784
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:32.620622
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test to ensure that the class name is correct
    assert ie.ie_key() == 'TheStar'

# Generated at 2022-06-12 18:21:39.344242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(repr(ie).find('TheStarIE(') != -1)
    assert(ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:21:45.287124
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').BRIGHTCOVE_URL_TEMPLATE % '4732393888001'

# Generated at 2022-06-12 18:21:46.378791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.test()

# Generated at 2022-06-12 18:21:49.456195
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert( the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' )

# Generated at 2022-06-12 18:21:50.803799
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	return ie


# Generated at 2022-06-12 18:21:54.901736
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:22:04.797108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    l_thumb = "http://www.thestar.com/content/dam/thestar/life/2016/02/01/"
    l_thumb = l_thumb + "mankind-why-this-woman-started-a-men-s-skincare-line/woman-men-skin-care.jpg"

    r1 = ie.youtube_ie_extract_urls(url)
    r2 = ie.extract_urls(url)


# Generated at 2022-06-12 18:23:29.737717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.name == "TheStar"
    assert ie.description == "thestar.com"
    assert ie.valid_urls == ["http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"]

# Generated at 2022-06-12 18:23:31.834584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:34.691976
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    assert obj.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-12 18:23:42.629214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_object.BRIGHTCOVE_URL_TEMPLATE.encode('utf-8') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_object.URL_VALID_TEMPLATE.encode('utf-8') == '(?i)https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-12 18:23:48.275859
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.interprets('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.interprets('http://www.thestar.com/news/canada/2016/02/05/canada-post-sterling-figurines-sell-for-thousands-on-ebay.html')

# Generated at 2022-06-12 18:23:54.924472
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t1 = TheStarIE()
    assert t1.__class__.__name__ == 'TheStarIE'
    assert t1._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert t1.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:23:57.763593
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:00.910479
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    test_obj = ie.test()
    assert test_obj['id'] == '4732393888001'
    assert test_obj['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-12 18:24:05.765574
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie=TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._TEST
    ie._TEST['url']
    ie._TEST['md5']
    ie._TEST['info_dict']
    ie._TEST['params']

# Generated at 2022-06-12 18:24:08.649304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:27:21.780069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
