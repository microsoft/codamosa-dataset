

# Generated at 2022-06-12 18:17:31.857757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test TheStarIE constructor, return True if it passes. False otherwise."""
    ie = TheStarIE()
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    test_brightcove_id = '4732393888001'
    test_result_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + test_brightcove_id
    test_result = 'BrightcoveNew' + test_brightcove_id

# Generated at 2022-06-12 18:17:33.368297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract(TheStarIE._TEST.get('url'))

# Generated at 2022-06-12 18:17:36.244590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Instantiation
    TheStarIE()

    # following code is needed for coverage to count instantiation
    if False:
        assert False

    # test_TheStarIE of class TheStarIE


# Generated at 2022-06-12 18:17:44.462539
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._setup_downloader()
    expected = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    result = ie.url_result("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "Brightcove")
    assert(expected == result.url)
    assert("4732393888001" == result.video_id)

# Generated at 2022-06-12 18:17:45.044470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:17:46.771863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test TheStarIE
	x = TheStarIE('_VALID_URL')
	assert x
	print (x)

# Generated at 2022-06-12 18:17:47.711027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-12 18:17:51.891341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:53.855224
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	global ie
	ie = TheStarIE()

# Test for extracting URLs

# Generated at 2022-06-12 18:18:03.100327
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().brighcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:16.758022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tst= TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html','4732393888001')
    assert tst.BRIGHTCOVE_URL_TEMPLATE== 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert tst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:18.831948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == TheStarIE.BRIGHTCOVE_URL_TEMPLATE.replace('%s', r'(\d+)')

# Generated at 2022-06-12 18:18:21.316631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:18:33.009130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	mock_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	expected_args = {
			'id': '4732393888001',
			'ext': 'mp4',
			'title': 'Mankind: Why this woman started a men\'s skin care line',
			'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
			'uploader_id': '794267642001',
			'timestamp': 1454353482,
			'upload_date': '20160201',
		}

# Generated at 2022-06-12 18:18:34.326298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarAward.py')
    assert ie.param == 2

# Generated at 2022-06-12 18:18:37.684514
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for the class constructor TheStarIE
    test_result = TheStarIE()
    assert(test_result.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")

# Generated at 2022-06-12 18:18:39.255475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert str(TheStarIE) == "<class '__main__.TheStarIE'>"

# Generated at 2022-06-12 18:18:44.564118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Testing constructor of class TheStarIE.
    # To test that constructor works properly, list of arguments of constructor
    # are passed to the constructor, and it is checked that
    # new object returned by constructor is instance of class TheStarIE.
    the_star_ie = TheStarIE()
    assert isinstance(the_star_ie, TheStarIE)


# Generated at 2022-06-12 18:18:56.003920
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download(TheStarIE._TEST['url'])
    ie.download(TheStarIE._TEST['url'], order='zip')
    ie.download(TheStarIE._TEST['url'], order='asc')
    ie.download(TheStarIE._TEST['url'], order='random')
    ie.download(TheStarIE._TEST['url'], order='new')
    ie.download(TheStarIE._TEST['url'], order='recent')
    ie.download(TheStarIE._TEST['url'], order='relevance')
    ie.download(TheStarIE._TEST['url'], order='popular')
    ie.download(TheStarIE._TEST['url'], order='comments')

# Generated at 2022-06-12 18:18:58.213192
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None) is not None

# Generated at 2022-06-12 18:19:17.009851
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_ID_REGEX == r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'
    assert ie._TEST.get('url') == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST.get

# Generated at 2022-06-12 18:19:20.039437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(t, TheStarIE)

# Generated at 2022-06-12 18:19:25.897956
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Make sure it can be constructed
	object = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert object


# Generated at 2022-06-12 18:19:26.914375
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-12 18:19:30.395233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:38.456299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Check instance created with right attributes
	assert TheStarIE._VALID_URL is not None
	assert TheStarIE._TEST is not None
	assert TheStarIE.BRIGHT_COVE_URL_TEMPLATE is not None
	assert TheStarIE.__name__ is  not None
	assert TheStarIE._real_extract is not None
	assert TheStarIE._download_webpage is not None

# Generated at 2022-06-12 18:19:40.795351
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    module = 'thestar'
    instance = TheStarIE(module)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 18:19:50.082933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:19:54.947583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.extractor_key is not None
    assert ie._VALID_URL is not None
    assert ie._TEST["url"] is not None
    assert ie._TEST["md5"] is not None
    assert ie._TEST["info_dict"] is not None

# Generated at 2022-06-12 18:19:59.827971
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:10.801699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:13.797743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE(None)
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:20:23.618512
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:20:27.011928
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test cases for constructor of class TheStarIE"""
    test = TheStarIE()
    test.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:20:27.831579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()

# Generated at 2022-06-12 18:20:36.239198
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = u'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    parser = TheStarIE()
    assert parser.BRIGHTCOVE_URL_TEMPLATE == u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert parser._VALID_URL == u'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'
    assert parser.IE_NAME == u'thestar'

# Generated at 2022-06-12 18:20:37.784015
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:20:39.369841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    return ie

# Generated at 2022-06-12 18:20:43.483125
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:44.088494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()

# Generated at 2022-06-12 18:20:59.753533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:02.594628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:09.894559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id = '4732393888001'
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=' + video_id
    the_star_ie = TheStarIE()
    assert the_star_ie.ie_key() == 'TheStar'
    assert the_star_ie.suitable(url) == True
    assert the_star_ie.suitable(url) == True
    assert the_star_ie.brigtcovenew.ie_key() == 'BrightcoveNew'
    assert the_star_ie.brigtcovenew.suitable(url) == True
    assert the_star_ie.brigtcovenew.suitable(url) == True

# Generated at 2022-06-12 18:21:12.159227
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:13.561746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-12 18:21:22.552267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = InfoExtractor()

    instance = TheStarIE(
        ie.downloader,
        ie.params,
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert instance.constructor_url(ie) == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert instance.constructor_display_id(ie) == '4732393888001'

# Generated at 2022-06-12 18:21:23.839504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:21:26.944295
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:33.174390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import sys
    print >> sys.stderr, '\nUnit test for TheStarIE - starts\n'
    g = globals()
    for k, v in g.items():
        if k.startswith('TheStarIE'):
            print >> sys.stderr, 'Unit test for %s - starts\n' % k
            v().download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
            print >> sys.stderr, 'Unit test for %s - finishes\n' % k

if __name__ == '__main__':
    # Unit tests for TheStarIE
    test_TheStarIE()

# Generated at 2022-06-12 18:21:34.765220
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the constructor of TheStarIE is working.
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-12 18:22:17.676840
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst_ie = TheStarIE()
    assert inst_ie is not None
    assert inst_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test the get_brightcove_id function
    inst_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    inst_ie.BRIGHTCOVE_URL = r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'

# Generated at 2022-06-12 18:22:19.576779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert_true(isinstance(TheStarIE(), InfoExtractor))


# Generated at 2022-06-12 18:22:23.641653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:25.343934
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   test_obj = TheStarIE()
   assert test_obj is not None

# Generated at 2022-06-12 18:22:26.203356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('<div/>')

# Generated at 2022-06-12 18:22:30.983333
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """TheStarIE construct should be able to handle and extract the video id """
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    testObject = TheStarIE(url=url)
    assert testObject.match_id == '4732393888001'

# Generated at 2022-06-12 18:22:31.711817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('Local testing')
    return ie

# Generated at 2022-06-12 18:22:34.225993
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print('TheStarIE url: ' + ie.url)
    print('TheStarIE brighcove id: ' + ie.brightcove_id)
    
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:22:36.838914
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:46.550922
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:24:18.308181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStar', True)
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:24:20.037933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:23.465822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    try:
        url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        obj = TheStarIE(url, debug=True)

    except Exception as error:
        print ("error!")

# Generated at 2022-06-12 18:24:26.112437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:27.128850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE({}), TheStarIE)


# Generated at 2022-06-12 18:24:33.388363
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = TheStarIE()
    x = TheStarIE._TEST
    x["url"] = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    x["md5"] = "2c62dd4db2027e35579fefb97a8b6554"
    return s._real_extract(x)

# Generated at 2022-06-12 18:24:39.110452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of TheStarIE
    the_star_ie = TheStarIE()

    # Check if BRIGHTCOVE_URL_TEMPLATE is set
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:24:42.449245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:52.463968
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:24:53.370461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)