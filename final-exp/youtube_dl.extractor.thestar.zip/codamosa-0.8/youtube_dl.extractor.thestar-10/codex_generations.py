

# Generated at 2022-06-12 18:17:21.423944
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().ie_key() == 'TheStar'

# Generated at 2022-06-12 18:17:26.039340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-12 18:17:30.998103
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-12 18:17:32.204943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Test of function _real_extract

# Generated at 2022-06-12 18:17:37.984877
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extractor_key = 'thestar'
    ie.BRIGHTCOVE_URL_TEMPLATE = ie.BRIGHTCOVE_URL_TEMPLATE
    ie.extractor_key = 'thestar'
    assert ie.extractor_key == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:38.554364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  assert True

# Generated at 2022-06-12 18:17:49.356471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    
# Test for test_TheStarIE()._real_extract()

# Generated at 2022-06-12 18:17:51.661133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for the constructor of class TheStarIE."""
    ie = TheStarIE()
    assert ie.name  == 'TheStar'
    assert ie.extractor_key == 'TheStar'


# Generated at 2022-06-12 18:17:56.801389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s', "BRIGHTCOVE_URL_TEMPLATE of TheStarIE is not correct"

# Generated at 2022-06-12 18:17:59.620385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:03.804160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of class TheStarIE
    c = TheStarIE()
    c.BRIGHTCOVE_URL_TEMPLATE
    c.extract_formats()
    c.extract_subtitles()


# Generated at 2022-06-12 18:18:07.271448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("link")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:08.170634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t = TheStarIE(None, None, )

# Generated at 2022-06-12 18:18:11.249441
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:18:17.388846
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert(thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')


# Generated at 2022-06-12 18:18:19.668188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert str(ie.get_url_re()) == TheStarIE._VALID_URL
    assert ie.get_id_re() == TheStarIE._VALID_URL

# Generated at 2022-06-12 18:18:21.298466
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("")
    assert ie

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-12 18:18:22.931501
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = Test_TheStarIE()
    inst.test_TheStarIE()


# Generated at 2022-06-12 18:18:27.617546
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:28.150430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-12 18:18:33.366530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert type(TheStarIE({})) == TheStarIE

# Generated at 2022-06-12 18:18:34.281360
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert True

# Generated at 2022-06-12 18:18:37.180755
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:42.046530
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests with no expection
    test1 = TheStarIE()
    assert test1.brightcove_id is None
    assert test1.thestar_id is None

    # Tests with exception
    try:
        test2 = TheStarIE(brightcove_id = 'abc')
    except Exception:
        assert True

# Generated at 2022-06-12 18:18:42.978674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ = TheStarIE()

# Generated at 2022-06-12 18:18:52.173191
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of the class TheStarIE.

    Arguments:
    :param - None
    Returns:
    :return: None
    """
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:56.208981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:02.581670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:03.468990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-12 18:19:04.368291
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    

# Generated at 2022-06-12 18:19:14.950118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("https://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    

# Generated at 2022-06-12 18:19:18.063767
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:19:18.617772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:26.055984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:30.954580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE.startswith('http')
    assert ie._VALID_URL is not None
    assert ie._VALID_URL.startswith('https?://')

# Generated at 2022-06-12 18:19:42.046868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Usage:
		python -m unitest discover -v -s . -t .
	"""
	from unittest import TestCase
	from ykdl.util.html import get_content
	from ykdl.util.match import match1
	from ykdl.extractors.thestar import TheStarIE
	from ykdl.compact import compact_bytes
	class TestTheStar(TestCase):
		def setUp(self):
			self.vid = '4732393888001'
			self.vid_url = self.__class__.ie.BRIGHTCOVE_URL_TEMPLATE % self.vid

# Generated at 2022-06-12 18:19:49.458084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import re
    from urlparse import urlparse
    result = TheStarIE()
    assert isinstance(result, InfoExtractor)
    assert isinstance(result.br, BrightcoveNew)
    assert isinstance(result.BRIGHTCOVE_URL_TEMPLATE, unicode)
    assert isinstance(result._VALID_URL, re._pattern_type)
    assert isinstance(result._TEST, dict)
    # _VALID_URL regex compiles
    o=urlparse(result._TEST['url'])
    assert result._VALID_URL.match(o.path)

# Generated at 2022-06-12 18:19:52.477364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """test TheStarIE constructor"""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:53.621828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    expect = TheStarIE({})
    assert(expect)

# Generated at 2022-06-12 18:19:56.829022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:18.516378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Test extract method
    ie.extract('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:24.095273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/news/world/2015/01/24/europe-batters-arctic-with-record-breaking-cold.html")
    assert ie.name == "The Star"
    assert ie.extractorClass == "TheStarIE"
    assert ie.url == "https://www.thestar.com/news/world/2015/01/24/europe-batters-arctic-with-record-breaking-cold.html"

# Generated at 2022-06-12 18:20:30.899889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert 'brightcove new' in info_extractor._downloader.IE_NAME_MAP
    assert info_extractor._VALID_URL == r'https?://(?:www\.|gaming.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:32.911115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from TheStarIE import TheStarIE
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-12 18:20:36.861612
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test the constructor of class TheStarIE"""
    tst = TheStarIE('')
    assert(hasattr(tst, 'BRIGHTCOVE_URL_TEMPLATE'))

# Generated at 2022-06-12 18:20:37.612277
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(_download_webpage)

# Generated at 2022-06-12 18:20:41.178584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:45.944496
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:54.123141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global theStarIE
    # class TheStarIE(
    #     InfoExtractor,
    #     BrightcoveNewIE,
    #     DrtvIE,
    #     TedIE,
    #     ThePlatformIE,
    #     YoutubeIE,
    # ):
    theStarIE = TheStarIE()

    # void _real_extract(self, url)
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = theStarIE._real_extract(url)
    assert result['id'] == '4732393888001'

# Generated at 2022-06-12 18:20:57.281092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE, [
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
    ])

# Generated at 2022-06-12 18:21:47.322112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Check for our test case
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

    # Check for _

# Generated at 2022-06-12 18:21:48.703562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:21:59.426606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r"""
    Unit test for constructor of class TheStarIE.
    """
    # Initialize object of TheStarIE.
    t = TheStarIE()

    # Check function TheStarIE._real_extract().
    # This function takes an url and return a dictionary.
    # The dictionary has the following keys:
    # 'id', 'ext', 'title', 'description', 'uploader_id', 'timestamp', and 'upload_date'.
    example_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result_dict = t._real_extract(example_url)

# Generated at 2022-06-12 18:22:01.630365
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    TheStarIE('test_TheStarIE','test_TheStarIE')

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:22:04.078818
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 18:22:05.620803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return UnitTest(TheStarIE, False)


# Generated at 2022-06-12 18:22:10.021314
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    # Test brightcove id is found for the url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    brightcove_id = info_extractor._real_extract(url)
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-12 18:22:15.693206
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:22:21.022504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:22:26.129377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-12 18:24:02.538258
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:24:10.994455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.suitable('http://www.thestar.com/sports/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:18.842567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:21.001968
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    #Test if the url is correct
    assert ie.match_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'


# Generated at 2022-06-12 18:24:21.499297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ = TheStarIE()

# Generated at 2022-06-12 18:24:22.131552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE(None)

# Generated at 2022-06-12 18:24:25.837020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie = TheStarIE('TheStar', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie = TheStarIE('TheStar', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')


# Generated at 2022-06-12 18:24:27.858710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');

# Generated at 2022-06-12 18:24:31.156419
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None, None)._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:38.757524
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'