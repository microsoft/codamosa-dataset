

# Generated at 2022-06-12 18:17:26.038982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:17:27.422013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for default constructor
    assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-12 18:17:37.172475
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:17:38.507865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_case = TheStarIE()
    assert test_case

# Generated at 2022-06-12 18:17:39.295202
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:49.901439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:00.662637
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Testing url of the video
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    #Expected id
    expected_id = '4732393888001'
    download = TheStarIE(url)

    #Testing the id
    id = download.id
    assert(expected_id == id)
    #Testing the url
    url = download.url
    assert(url == url)
    #Testing the title
    expected_title = 'Mankind: Why this woman started a men\'s skin care line'
    title = download.title
    assert(title == expected_title)
    #Testing the description

# Generated at 2022-06-12 18:18:05.449117
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:18:06.400416
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('', {})

# Generated at 2022-06-12 18:18:15.923973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:18:20.844197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = InfoExtractor()


# Generated at 2022-06-12 18:18:25.490702
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:31.495979
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:18:34.758810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:36.878238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-12 18:18:45.282884
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance for testing
    thestar_ie = TheStarIE()
    # Verify that it's instance of InfoExtractor
    if not isinstance(thestar_ie, InfoExtractor):
        raise AssertionError("thestar_ie should be an instance of InfoExtractor")
    # Test that it recognize the URL
    if not thestar_ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None:
        raise AssertionError("thestar_ie should recognize URL")

# Generated at 2022-06-12 18:18:49.905165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-12 18:18:52.394041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ test_TheStarIE: test for constructor of class TheStarIE """
    tstar = TheStarIE()
    assert tstar != None, "constructor of class TheStarIE should return success"

# Generated at 2022-06-12 18:18:58.263001
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:19:08.818305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = '4732393888001'
    webpage = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    brightcove_id = '4732393888001'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    TheStarIE._download_webpage = lambda *args: webpage
    TheStarIE._match_id = lambda *args: display_id
    TheStarIE._search_regex = lambda *args: brightcove_id
    TheStarIE.url_

# Generated at 2022-06-12 18:19:20.291996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = TestTheStarIE._TEST['url']
    ie.params = TestTheStarIE._TEST['params']
    ie.webpage = TestTheStarIE._TEST['webpage']
    ie.video_id = TestTheStarIE._TEST['video_id']

# Generated at 2022-06-12 18:19:22.787969
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for one class TheStarIE
    """
    print(TheStarIE._VALID_URL)

# Generated at 2022-06-12 18:19:27.577050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_obj = TheStarIE()
    assert class_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:34.038111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "test_TheStarIE")
    # Should pass either assert

# Generated at 2022-06-12 18:19:40.031022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:19:43.815252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE()
    assert o.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:51.875914
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  t = TheStarIE()
  assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:01.576470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:11.252255
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of TheStarIE
    """
    # Valid input
    thestar = TheStarIE(None)
    assert thestar._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:14.968902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_object = TheStarIE()
    assert ie_object.name == "thestar.com"
    assert ie_object.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:20:33.176433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    with open('./testid', 'r') as f:
        cid = f.read()
        return TheStarIE(cid)

# Generated at 2022-06-12 18:20:36.250449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-12 18:20:37.247091
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Ensure that YouTubeIE's constructor does not fail
    ie = TheStarIE()

# Generated at 2022-06-12 18:20:37.979250
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:40.375155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        test_TheStarIE()

# Generated at 2022-06-12 18:20:45.497136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:20:50.902411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    ie = TheStarIE(url, display_id)
    return ie

# Generated at 2022-06-12 18:20:58.803296
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", True, "Mankind: Why this woman started a men's skin care line", "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001", "4732393888001", True, False, False, False, False)

# Generated at 2022-06-12 18:21:01.423462
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Inaccessible URL
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:05.849887
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('test')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:47.370393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return TheStarIE()

# Generated at 2022-06-12 18:21:53.021136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.get_url_re() is not None
    assert ie.get_url_re().match("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") is not None
    assert ie.get_url_re().match("https://www.thestar.com/news/world/2016/03/08/donald-trump-threatens-to-send-his-supporters-to-bergens-rallies.html") is not None

# Generated at 2022-06-12 18:21:56.911350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-12 18:22:00.131566
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testObj = TheStarIE()
    assert testObj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:03.920746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().ie == 'TheStarIE'
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:22:09.037176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_instance = TheStarIE()
    assert ie_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:11.233137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE(thestar_ie)
    return (thestar_ie)

# Generated at 2022-06-12 18:22:14.340071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert (info_extractor.BRIGHTCOVE_URL_TEMPLATE ==
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-12 18:22:21.136847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:22:27.081176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("test TheStarIE constructor")
    ie = TheStarIE(None, None)
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._real_extract(None)
    ie._VALID_URL
    ie._TEST
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-12 18:24:04.132978
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:24:11.504688
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test the constructor of the class TheStarIE
    test_TheStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:15.661182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert isinstance(test, InfoExtractor)
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test.IE_NAME == 'thestar'


# Generated at 2022-06-12 18:24:18.869614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Create instance of class TheStarIE
    thestarIE = TheStarIE()

    # Check whether the functions return what we expect
    assert thestarIE.BRIGHTCOVE_URL_TEMPLATE
    assert thestarIE._real_extract
    assert thestarIE._download_webpage
    assert thestarIE._search_regex
    assert thestarIE._match_id

# Generated at 2022-06-12 18:24:21.519672
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("\nInside the unit test for constructor of class TheStarIE\n")

# Generated at 2022-06-12 18:24:23.250003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().ie_key() == 'thestar'

# Generated at 2022-06-12 18:24:24.282390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import CommonIE
    TheStarIE().constructor_test(CommonIE)

# Generated at 2022-06-12 18:24:28.856607
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
   

# Generated at 2022-06-12 18:24:37.735594
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info = TheStarIE()
	assert info._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:44.205156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://thestar.com/life/tech/tech_news/2017/12/18/facebook-backed-internet-org-is-renamed-and-reorganized-to-fight-backlash.html')
    ie = TheStarIE('https://thestar.com/life/tech/tech_news/2017/12/18/facebook-backed-internet-org-is-renamed-and-reorganized-to-fight-backlash.html')
    print(ie._download_webpage)

# Generated at 2022-06-12 18:26:21.752467
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE(InfoExtractor()), '_download_webpage')

# Generated at 2022-06-12 18:26:25.152540
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', {})._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:26:25.616774
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-12 18:26:31.681391
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# TODO: add test for url, display_id, webpage, brightcove_id
	pertinent_args = {
		'url': 'url',
		'display_id': 'display_id',
		'webpage': 'webpage',
		'brightcove_id': 'brightcove_id',
	}
	pertinent_kwargs = {}
	ins = TheStarIE(**pertinent_args, **pertinent_kwargs)
	assert isinstance(ins, TheStarIE)

	# TODO: add more tests here


# Generated at 2022-06-12 18:26:37.520350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check the media id of a video
    assert TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')['id'] == '4732393888001'
    # Check that the correct brightcove URL is build
    assert TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:26:40.171684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    r"""Unit test for constructor of class TheStarIE"""
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(url).extract_video_info()

# Generated at 2022-06-12 18:26:43.246812
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:26:52.369872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/news/city_hall/2014/07/22/rob_ford_to_receive_treatment_for_alcohol_abuse.html")
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:26:52.809306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:26:53.291889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return TheStarIE(InfoExtractor)