

# Generated at 2022-06-12 18:17:30.086610
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    class TheStarIE(InfoExtractor):
        _VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:17:34.729376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """

    # Case where TheStar url is empty
    url = ""
    ie = TheStarIE(url, {})
    assert ie._VALID_URL == ""
    
    # Case where TheStar url is None
    url = None
    ie = TheStarIE(url, {})
    assert ie._VALID_URL == ""

# Generated at 2022-06-12 18:17:37.625078
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('brightcove-new:id')
    assert ie.count == -1
    assert ie.offset == 0
    assert ie.playlist_count == 0
    assert ie.playlist_index == -1

# Generated at 2022-06-12 18:17:40.217587
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception:
        pass
    else:
        raise AssertionError('TheStarIE should raise exception')

# Generated at 2022-06-12 18:17:40.984921
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:50.781509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:17:52.891004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    # Work with class instance thestar
    pass

# Generated at 2022-06-12 18:18:02.235927
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    #    instance = TheStarIE()
    # Unit test for _real_extract method of class TheStarIE
    instance = TheStarIE()
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    #    url,display_id  = instance._real_extract(test_url)
    url, display_id  = instance._real_extract(test_url)
    assert url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert display_id == '4732393888001'

# Generated at 2022-06-12 18:18:12.763682
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE.
    """
    instance = TheStarIE("TheStarIE")
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:14.813461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE(TheStarIE._VALID_URL) # No error should be thrown

test_TheStarIE()

# Generated at 2022-06-12 18:18:19.471540
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:18:20.810156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check to ensure the class is instantiable
    assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-12 18:18:22.951362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	theStar = TheStarIE()
	theStar._login()
	theStar._real_initialize()
	theStar._real_extract(TheStarIE._TEST.get('url'))


# Generated at 2022-06-12 18:18:34.326075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    actual_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    actual_output = info_extractor.extract(actual_url)
    expected_output = {
        'id': '4732393888001',
        'ext': 'mp4',
        'title': 'Mankind: Why this woman started a men\'s skin care line',
        'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'upload_date': '20160201',
    }

# Generated at 2022-06-12 18:18:40.855404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	e = TheStarIE()
	video_id = e.extract_id(test_url)
	assert video_id == '4732393888001'

# Generated at 2022-06-12 18:18:42.287062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('', {})

# Generated at 2022-06-12 18:18:45.008967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:52.394805
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	p = TheStarIE()

	assert(p._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
	assert(p.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-12 18:18:53.862367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:18:58.708502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:04.908915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:06.719149
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:19:07.326238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:08.819513
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-12 18:19:10.662959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    my_object = TheStarIE(...)
    assert my_object.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:19:11.364020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:19:12.560095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	i = TheStarIE()

# Generated at 2022-06-12 18:19:21.838366
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    title = 'Mankind: Why this woman started a men\'s skin care line'
    description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    id = 4732393888001
    timestamp = 1454353482
    upload_date = '20160201'
    uploader_id = 794267642001
    md5_id = '2c62dd4db2027e35579fefb97a8b6554'
    video_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732400573001'

# Generated at 2022-06-12 18:19:27.703753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/')
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:34.083840
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert instance._TEST["url"] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert instance._TEST["md5"] == "2c62dd4db2027e35579fefb97a8b6554"
    assert instance._TEST["info_dict"]["id"] == "4732393888001"
    assert instance._TEST["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-12 18:19:45.305653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # To test TVO.ca IE, we must test all those attributes.
    # _VALID_URL, _TEST, BRIGHTCOVE_URL_TEMPLATE, _real_extract
    import doctest
    doctest.testmod(TheStarIE)

# Generated at 2022-06-12 18:19:46.222461
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:19:48.909685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE')
    assert ie._TEST.get('md5') == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:19:51.777142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .bases import test_generate_ie_suite
    test_generate_ie_suite(TheStarIE,
                           override_defaults={
                               'extract_flat': 'inherit',
                               'skip_download': True,
                           })

# Generated at 2022-06-12 18:19:57.673248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("TheStarIE", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", {})
    assert(obj.display_id == "4732393888001")
    assert(obj.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001")

# Generated at 2022-06-12 18:19:58.283863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-12 18:19:58.851451
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:20:06.206108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:08.911676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Unit test for class constructor """
    thestar_ie = TheStarIE()

    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:20:11.804217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:30.659604
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE._TEST['info_dict']['id']
    assert TheStarIE()._TEST['md5'] == TheStarIE._TEST['md5']
    assert TheStarIE()._TEST['info_dict']['title'] == TheStarIE._TEST['info_dict']['title']


# Generated at 2022-06-12 18:20:33.138204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    e.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:37.679599
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    obj = ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("obj: " + str(obj))


test_TheStarIE()

# Generated at 2022-06-12 18:20:39.538996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ies = InfoExtractor.get_info_extractor('TheStar.com')
    expected_IE = TheStarIE
    assert isinstance(ies, expected_IE)

# Generated at 2022-06-12 18:20:39.985918
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:42.341551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({},{})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:20:45.901788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    'Test if TheStarIE object can be created'

    thestar_ie = TheStarIE()
    assert (thestar_ie)

# Generated at 2022-06-12 18:20:46.440004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:54.377721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from __main__ import TheStarIE
    from __main__ import InfoExtractor
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(InfoExtractor())
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    # assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == {
    #     'id': '4732393888001',
    #     'ext': 'mp4',
    #     '

# Generated at 2022-06-12 18:21:03.798102
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:44.080065
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-12 18:21:45.766436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('www.thestar.com','')

# Generated at 2022-06-12 18:21:48.606415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:50.037207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    expected = TheStarIE
    assert (expected == type(TheStarIE()))

# Generated at 2022-06-12 18:21:52.016556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test TheStarIE is subclass of InfoExtractor
    assert issubclass(TheStarIE, InfoExtractor)

# Generated at 2022-06-12 18:21:54.998607
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.youtube.com/watch?v=uV6wKP6i0R0', 'TheStarIE')


# Generated at 2022-06-12 18:21:58.289079
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:59.426281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    print(instance)

# Generated at 2022-06-12 18:22:02.271046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:08.894355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        c = TheStarIE()
        c = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        c = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    except Exception as e:
        print(e)

# Generated at 2022-06-12 18:23:34.075183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    # TSIE = TheStarIE('http://www.thestar.com/news/gta/2016/01/29/suspect-in-arrest-of-2-ontario-judges-identified.html')
    TSIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:23:40.783129
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:23:42.835110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    q = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-wh...')
    assert q.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:44.101403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    with open('test.html', 'r') as source:
        content = source.read()


# Generated at 2022-06-12 18:23:47.206958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"


# Generated at 2022-06-12 18:23:48.138477
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()


# Generated at 2022-06-12 18:23:54.534226
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    Star = TheStarIE()
    assert(Star.IE_NAME == 'thestar')
    assert(Star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(Star._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:24:02.243068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:05.968518
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:13.422974
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert obj._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-12 18:27:24.124161
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Instantiation of class
	TheStarIE()
	# TheStarIE._real_extract()
	# 1. url, display_id
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
	T = TheStarIE._real_extract(url, display_id)
	# 2. webpage, brightcove_id
	webpage = 'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'
	brightcove_id = '4732393888001'
	T2 = TheStarIE._real_