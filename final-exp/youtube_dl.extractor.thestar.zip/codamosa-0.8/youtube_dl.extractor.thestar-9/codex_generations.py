

# Generated at 2022-06-12 18:17:21.077183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:17:24.805549
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def teardown():
        pass

    def setup():
        pass

    test_TheStarIE.setup = setup
    test_TheStarIE.teardown = teardown

# Generated at 2022-06-12 18:17:28.180528
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:34.782305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that we can pass the test case with a URL without a filename in it and it actually finds the video
    sample_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    instr = TheStarIE()
    instr.extract(sample_url)


# Generated at 2022-06-12 18:17:38.571704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert info_extractor.match_url(url)
    info_extractor.extract(url)

# Generated at 2022-06-12 18:17:39.717779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    asser

# Generated at 2022-06-12 18:17:43.264331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # No need to test the constructor here
    # All it does is a call to super method
    test_TheStarIE.test_TheStarIE = lambda self : None
    TheStarIE().test_TheStarIE()

# Generated at 2022-06-12 18:17:44.906880
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(InfoExtractor._downloader) != None


# Generated at 2022-06-12 18:17:50.854842
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  test_object = TheStarIE()
  assert 'TheStarIE' == test_object.ie_key()
  assert 'thestar' == test_object.IE_NAME
  assert 'thestar.com' == test_object.ie._downloader.params['extractor_key']
  assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == test_object._download_webpage(None, None, None)

# Generated at 2022-06-12 18:17:55.301926
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:09.720165
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    brightcove_id = '4732393888001'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    player_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:18:11.622721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check that the object is created or not
    assert TheStarIE(TheStarIE._VALID_URL)


# Generated at 2022-06-12 18:18:20.879520
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:26.796952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testArgs = {'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'}
    testClass = TheStarIE(testArgs)
    # Test for method url_result
    testMethod = testClass.url_result(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', 'BrightcoveNew', '4732393888001')
    if testMethod == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001':
        print('Method url_result - Pass')
    else:
        print('Method url_result - Fail')


# Generated at 2022-06-12 18:18:35.528626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Class initial
    theStar = TheStarIE()
    REGEX = r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'
    METHOD = '_search_regex'
    
    # Test cases
    webpage = '''
    <article>
    <div class="mainartBrightcoveVideoId" value="4732393888001">
    </article>
    '''
    brightcove_id = '4732393888001'
    
    # run test cases
    result = theStar._search_regex(REGEX, webpage, 'value')
    print (brightcove_id, result)
    assert (brightcove_id == result)

# Generated at 2022-06-12 18:18:38.347270
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__doc__ == InfoExtractor.__doc__


# Generated at 2022-06-12 18:18:43.958965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:50.041126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._real_extract('http://www.thestar.com/content/dam/thestar/news/world/2016/02/07/obama-to-push-islamic-state-fight-with-unprecedented-coalition-meeting/obama.jpg.size.xxlarge.promo.jpg')

# Generated at 2022-06-12 18:18:53.279568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testobj = TheStarIE('test string')
    assert testobj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:55.468483
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestTheStar))
    return suite

# Generated at 2022-06-12 18:19:01.338767
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print('test_TheStarIE(): instantiated class TheStarIE successfully')


# Generated at 2022-06-12 18:19:02.920182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  objTheStarIE = TheStarIE()
  assert objTheStarIE != None


# Generated at 2022-06-12 18:19:12.794379
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:19:21.991068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    test_inst = TheStarIE('TheStarIE', 'thestar.com', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert test_inst.name == 'TheStarIE'
    assert test_inst.ie_key == 'thestar.com'
    assert test_inst.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert test_inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test_inst._TEST

# Generated at 2022-06-12 18:19:26.170249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None).extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:19:27.133151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tc = TheStarIE()

# Generated at 2022-06-12 18:19:27.862724
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:19:29.790961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
	assert test

# Generated at 2022-06-12 18:19:33.265572
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result
    return result

# Generated at 2022-06-12 18:19:37.813380
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

test_TheStarIE.func_doc = "Unit test for constructor of class TheStarIE"
test_TheStarIE.__doc__ = "Unit test for constructor of class TheStarIE"


# Generated at 2022-06-12 18:19:53.693469
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    #assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == {u'_type': u'url', u'url': u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',

# Generated at 2022-06-12 18:19:58.765425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    # Input value for testing and expected output
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    id = '4732393888001'

    # Check if we can get the brightcove_id
    brightcove_id = test._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
                                       test._download_webpage(url, id), 'brightcove id')
    # Check if we can get the correct result

# Generated at 2022-06-12 18:20:01.899385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    fmt = 'https://www.thestar.com/entertainment/television/2016/03/03/full-frontal-host-samantha-bee-is-worth-watching.html'
    TheStarIE(fmt)

# Generated at 2022-06-12 18:20:03.974933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://')

if __name__ == '__main__':
    import unittest
    # unittest.main()
    test_TheStarIE()

# Generated at 2022-06-12 18:20:08.270487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        g = globals()
        for k, v in g.items():
            print(k, v)
    ie = TheStarIE()
    ie._match_id('https://www.thestar.com/life/the_fixer/2016/02/12/the_fixer_i_must_be_out_of_my_mind_to_take_on_this_warranty_giant.html')


# Generated at 2022-06-12 18:20:11.221671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:19.742832
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.video_id == "4732393888001"
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"


# Generated at 2022-06-12 18:20:20.830280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-12 18:20:25.322658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:20:26.121643
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    res = TheStarIE()
    assert res

# Generated at 2022-06-12 18:20:44.372017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-12 18:20:46.889480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._downloader, TheStarIE._TEST['url'])
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:20:49.160852
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def test_constructor_for_url(url):
        try:
            ie = TheStarIE()
            ie.compat_str(ie.url_result(url))
        except Exception as e:
            return str(e)

        return True

    assert test_constructor_for_url('') == True



# Generated at 2022-06-12 18:20:50.140554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   pass

# Generated at 2022-06-12 18:20:51.366923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE

# Generated at 2022-06-12 18:21:02.676565
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:21:10.468176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    test_url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._match_id(test_url) == display_id, \
        'Invalid match id for url: %s' % test_url
    data = ie._download_webpage(test_url, display_id)
    assert data is not None and len(data) > 0, \
        'Failed to download webpage for url: %s' % test_url

# Generated at 2022-06-12 18:21:10.877848
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-12 18:21:14.744271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = TheStarIE.BRIGHTCOVE_URL_TEMPLATE + ' %s'
    # FIXME: Add real tests
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001' == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001 4732393888001'

# Generated at 2022-06-12 18:21:17.453490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(br'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == br'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:22:06.771485
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    theStar.brightcove_url_template
    theStar.BRIGHTCOVE_URL_TEMPLATE
    
#
# Main
#
if __name__ == '__main__':
    # Unit test
    import sys
    import os
    import unittest
    import TheStarIE

    test_TheStarIE()
    
    # Run unit test
    #suite = unittest.TestLoader().loadTestsFromTestCase(TheStarIE)
    #unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 18:22:17.238114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # TheStarIE.extract()
    ie.extract(url, download=True)
    ie.extract(url, download=False)
    # TheStarIE.extract_from_url()
    ie.extract_from_url(url, download=True)
    ie.extract_from_url(url, download=False)
    # TheStarIE.extract_from_urls()

# Generated at 2022-06-12 18:22:23.096050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test of constructor of class TheStarIE
    '''
    # Url provided by the user
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Required values to be found
    test_id = '4732393888001'
    test_title = 'Mankind: Why this woman started a men\'s skin care line'
    test_description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    test_timestamp = 1454353482
    test_upload_date = '20160201'
    # creation of TheStarIE object

# Generated at 2022-06-12 18:22:26.432260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:28.503031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(hasattr(TheStarIE, "BRIGHTCOVE_URL_TEMPLATE"))


# Generated at 2022-06-12 18:22:33.042238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of TheStarIE
    star_ie = TheStarIE()

    # URL for a page of Star IE
    star_url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Test whether the class is able to download the page from the given URL
    assert(star_ie.suitable(star_url))

# Generated at 2022-06-12 18:22:35.094259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    video.extract(  'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:22:37.679889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'TheStarIE.BRIGHTCOVE_URL_TEMPLATE'
    TheStarIE._downloader = None
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'TheStarIE.BRIGHTCOVE_URL_TEMPLATE'


# Generated at 2022-06-12 18:22:40.689100
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    

# Generated at 2022-06-12 18:22:49.682806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._downloader, TheStarIE._TEST['url'])
    print(ie.__dict__)


# Generated at 2022-06-12 18:24:30.676473
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # It should be a subclass of class InfoExtractor

    IE = TheStarIE(None)
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-12 18:24:31.197821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:24:32.045847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-12 18:24:33.773652
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = TheStarIE()
    assert s is not None

# Generated at 2022-06-12 18:24:45.251628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Test to check all of the fields in an instance of the TheStarIE class
	"""
	class_TheStarIE = TheStarIE();
	assert class_TheStarIE._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-12 18:24:45.982641
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # pass
    assert True

# Generated at 2022-06-12 18:24:56.101431
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Tests regular case with video id and url as input."""
    test = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert test.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert test.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert test.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId="
    assert test.bright

# Generated at 2022-06-12 18:24:58.595469
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:25:09.072616
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:25:12.944922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.googledocs_valid_url("https://docs.google.com/uc?export=download&id=0B0OXc-L2x8QiRE1hTlU2TkU0T00")
