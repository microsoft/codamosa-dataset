

# Generated at 2022-06-12 18:17:26.271304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor of class InfoExtractor is not public, it is tested with TheStarIE
    # class, which is derived from InfoExtractor class
    test_case = TheStarIE._TEST
    if test_case['url']:
        ie = TheStarIE(test_case['url'])
        # ie is of type InfoExtractor
        assert isinstance(ie, InfoExtractor)
        assert ie.initialize()
        assert ie._real_extract(test_case['url']) == test_case

# Generated at 2022-06-12 18:17:36.051695
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:17:39.476550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert o is not None

# Generated at 2022-06-12 18:17:43.464603
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    t.extract()

# Generated at 2022-06-12 18:17:51.814866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    id = '4732393888001'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    result = ie._real_extract(url)
    assert result['id'] == id
    assert result['display_id'] == display_id

# Generated at 2022-06-12 18:18:00.544062
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:18:06.187868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # the input url is not a valid format
    video_URL = 'ftps://http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.suitable(video_URL) is False
    # the input url is a valid format
    video_URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.suitable(video_URL) is True
	


# Generated at 2022-06-12 18:18:13.198728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    theStarIE = TheStarIE(url)
    assert theStarIE.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert theStarIE.brigthcoveID == "4732393888001"
    return


# Generated at 2022-06-12 18:18:18.064015
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    return True


# Generated at 2022-06-12 18:18:20.308692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    return obj.BRIGHTCOVE_URL_TEMPLATE

# Run unit test for class TheStarIE
test_TheStarIE()

# Generated at 2022-06-12 18:18:34.892838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    webpage = '<html><div class="mainartBrightcoveVideoId" id="4732393888001"></div></html>'
    brightcove_id = '4732393888001'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:18:37.609788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert isinstance(i, TheStarIE)


# Generated at 2022-06-12 18:18:46.631515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.__name__ ==  'thestar'
    assert ie.BUILD_TEST ==  True
    assert ie.BUILD_BRIGHTCOVE_URL == 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=%s'

# Generated at 2022-06-12 18:18:58.095056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:07.801081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Obtain constructor of TheStarIE
    cons = TheStarIE.ie_key()
    obj = cons(TheStarIE._VALID_URL)
    
    # Create test case
    # For example, if you want to test _TEST in TheStarIE._TEST, create a test case like below.
    # You can get test code by clicking 'Test code' button on the right side.

# Generated at 2022-06-12 18:19:18.787021
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test the constructors of TheStarIE"""
    expected_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    thestar_ie = TheStarIE()
    thestar_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar_ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-12 18:19:20.415185
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST)


# Generated at 2022-06-12 18:19:25.555534
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.TheStarIE._TEST
    r = ie.TheStarIE._TEST
    r['url']
    r['md5']
    r['info_dict']
    r['params']


# Generated at 2022-06-12 18:19:33.337287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor of TheStarIE
    STAR_IE = TheStarIE()
    assert STAR_IE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert STAR_IE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert STAR_IE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert STAR_IE._TEST['info_dict']['id'] == '4732393888001'
    assert STAR_IE._TEST['info_dict']['ext']

# Generated at 2022-06-12 18:19:38.185003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._extract_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', display_id='4732393888001')

# Generated at 2022-06-12 18:19:49.562634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:19:58.809644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:20:08.271918
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Initialize class TheStarIE with url
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Check if url property is set correctly

# Generated at 2022-06-12 18:20:13.063748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert (ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')


# Generated at 2022-06-12 18:20:14.106140
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:20:20.218636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info_extractor = TheStarIE()
	assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:21.662109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: how to test this
    pass


# Generated at 2022-06-12 18:20:22.170405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:29.496437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    display_id = ie._match_id(u'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    brightcove_id = ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', webpage, 'brightcove id')
    url_result = ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id
    url_result_class = 'BrightcoveNew'

    assert display_id == u'mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:20:38.001247
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '2c62d',
        'BrightcoveNew',
        '4732393888001')
    
    # Test extracted id
    assert ie._match_id(ie.url) == '2c62d'

    # Test brightcove id
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'\
           == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    
    # Test generated url

# Generated at 2022-06-12 18:20:47.012497
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:20:50.469122
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

test_TheStarIE()

# Generated at 2022-06-12 18:20:55.269313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = ie._download_webpage(url, '4732393888001')
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    ie.url_result(
        ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id,
        'BrightcoveNew', brightcove_id)

# Generated at 2022-06-12 18:21:00.670836
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:04.450725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t_ie = TheStarIE()
    t_ie.BRIGHTCOVE_URL_TEMPLATE
    assert t_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-12 18:21:06.641452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        test_TheStarIE
    except NameError:
        print("NameError: name 'test_TheStarIE' is not defined")


# Generated at 2022-06-12 18:21:10.245490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = InfoExtractor()
    t = TheStarIE(info_extractor)
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.name == 'thestar.com'



# Generated at 2022-06-12 18:21:10.683238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:14.033656
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', None)

# Generated at 2022-06-12 18:21:17.386565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert isinstance(thestar_ie, InfoExtractor)

# Generated at 2022-06-12 18:21:47.753728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE.
    """
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_site = TheStarIE(TheStarIE.create_ie())
    actual = test_site._real_extract(test_url)
    assert actual == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert actual.startswith('http://players.brightcove.net/')
    assert actual.find('BrightcoveNew') != -1


# Generated at 2022-06-12 18:21:50.371638
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): 
    vid = '4732393888001'
    expected = TheStarIE.BRIGHTCOVE_URL_TEMPLATE % vid
    thestar_ie = TheStarIE(thestar_ie)
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == expected

# Generated at 2022-06-12 18:22:00.210281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print('当前运行的是第 %d 个case' % 4)
    ie = TheStarIE('TheStarIE')
    print('当前运行的是第 %d 个case' % 5)
    print('TheStarIE.__doc__', TheStarIE.__doc__)
    print('TheStarIE.__name__', TheStarIE.__name__)
    print('TheStarIE.__module__', TheStarIE.__module__)
    print('TheStarIE.__bases__', TheStarIE.__bases__)
    print('TheStarIE.__dict__', TheStarIE.__dict__)
    print('ie', ie)

# Generated at 2022-06-12 18:22:00.818054
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.initialize()

# Generated at 2022-06-12 18:22:06.616721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    open('test_TheStarIE.html', 'w').write(file('TheStarIE.html').read())
    ie = TheStarIE()
    ie.download(url='file://' + os.path.join(os.getcwd(), 'test_TheStarIE.html'))
    os.remove('test_TheStarIE.html')
    return os.path.exists('4732393888001.mp4')

# Generated at 2022-06-12 18:22:07.003744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:17.502222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor
    assert (TheStarIE._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html")
    assert (TheStarIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")

# Generated at 2022-06-12 18:22:22.307751
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:26.705110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with the sample url
    url = "https://www.youtube.com/watch?v=wZZ7oFKsKzY"
    # Test with a wrong video id
    id = "wZZ7oFKsKzY"

    # Test 1: Confirm that instantiation of class TheStarIE is successful
    TheStarIE(url, id)

# Generated at 2022-06-12 18:22:34.777880
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:23:28.737183
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    query_str = ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    assert ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', query_str, 'brightcove id') == '4732393888001'

# Generated at 2022-06-12 18:23:29.765465
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:23:34.550318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(" http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.name == 'TheStar'
    assert ie.ie_key() == 'TheStar'
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert ie.valid() is True

# Generated at 2022-06-12 18:23:37.586016
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    info = ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("\ninfo: %s\n" % info)

# Generated at 2022-06-12 18:23:43.794678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    obj = TheStarIE()
    expected_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    expected_id = '4732393888001'
    expected_ext = 'mp4'
    expected_title = 'Mankind: Why this woman started a men\'s skin care line'
    expected_description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    expected_uploader_id = '794267642001'
    expected_upload_date = '20160201'

# Generated at 2022-06-12 18:23:47.837661
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inputs = [['http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 
				'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001']]
    outputs = []
    for input in inputs:
        outputs.append(TheStarIE._real_extract(None, input[0]))
    assert outputs == inputs

# Generated at 2022-06-12 18:23:50.892225
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:00.215356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Make sure it gives correct video ID from URL
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url_regex = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    regex_str = 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    url_regex

# Generated at 2022-06-12 18:24:01.224244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test an object of the class TheStarIE
	TheStarIE()

# Generated at 2022-06-12 18:24:04.557041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarE = TheStarIE()
    assert thestarE is not None


# Generated at 2022-06-12 18:25:33.857585
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE(url)

# Generated at 2022-06-12 18:25:35.012700
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    	assert TheStarIE(None)

# Generated at 2022-06-12 18:25:39.236749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie == TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:25:40.199892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	return TheStarIE(object)

# Generated at 2022-06-12 18:25:47.300218
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:25:47.873098
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-12 18:25:48.253986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:25:53.006262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    thestar_ie = TheStarIE()
    assert thestar_ie is not None
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestar_ie.url = url


# Generated at 2022-06-12 18:25:54.141608
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:25:54.717881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()