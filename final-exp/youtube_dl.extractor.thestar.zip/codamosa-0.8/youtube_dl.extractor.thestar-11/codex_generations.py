

# Generated at 2022-06-12 18:17:30.398037
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    xt = TheStarIE()
    xt.get_urls(test_TheStarIE)

# Generated at 2022-06-12 18:17:31.052458
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-12 18:17:31.589788
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:32.454671
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-12 18:17:32.998720
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:34.387229
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://thestar.com/', None)



# Generated at 2022-06-12 18:17:35.404433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-12 18:17:39.476113
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _test_TheStarIE = TheStarIE("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert _test_TheStarIE.get_source() == "The Star"

# Generated at 2022-06-12 18:17:50.026418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:17:55.106258
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/news/canada/2016/02/01/canadas-carbon-problem-proves-champagne-is-as-canadian-as-hockey.html')
    assert ie.__class__ == TheStarIE
    

# Generated at 2022-06-12 18:17:59.393311
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()

    # Check if the constructor correctly sets the URL template
    expected_template = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == expected_template

# Generated at 2022-06-12 18:18:02.598761
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', 'BrightcoveNew', '4732393888001') == ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:09.324976
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BASE_URL == 'https://thestar.com/'
    assert ie.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:10.141041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    assert TheStarIE

# Generated at 2022-06-12 18:18:10.683408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:18.683285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test constructor of class TheStarIE
    '''

    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:19.870370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/')

# Generated at 2022-06-12 18:18:20.667441
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()

# Generated at 2022-06-12 18:18:21.121090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE()

# Generated at 2022-06-12 18:18:22.930966
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE

# Generated at 2022-06-12 18:18:35.235748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This is a test for constructor of TheStarIE class
    # Parameters:
    #  url: expect value is None
    #  ie: expect value is 'brightcove:new'
    # Return:
    #  _VALID_URL: expect value is 'http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    ie = TheStarIE(url=None, ie='brightcove:new')
    assert ie._VALID_URL == 'http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:18:35.781079
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:39.528645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")


# Generated at 2022-06-12 18:18:45.129689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:50.992078
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    a = i.url_result("http://players.brightcove.net/794267642001/default_default/index.html?videoId=4807503819001", 'BrightcoveNew', 4807503819001)
    print(a)

# Generated at 2022-06-12 18:18:54.627727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Test if class is created correctly. """
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL

# Generated at 2022-06-12 18:18:56.638957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    my_TheStarIE = TheStarIE()

# Generated at 2022-06-12 18:19:03.174504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test class instantiation
    the_star = TheStarIE()
    assert the_star.__name__ == 'TheStar'
    assert the_star.IE_NAME == 'TheStar'
    assert the_star.enabled == True
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:12.136342
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.base_url == 'http://www.thestar.com/'
    assert t.extract_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == '4732393888001'
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t.brightcove_new == 'BrightcoveNew'

# Generated at 2022-06-12 18:19:12.885709
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:19:22.563537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-12 18:19:24.930786
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:19:28.657376
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    print(obj._TEST['url'])
    print(obj._TEST['md5'])
    print(obj._TEST['info_dict'])

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:19:31.382495
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:19:37.155890
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:38.833192
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:43.946496
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.IE_NAME == "TheStarIE"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"


# Generated at 2022-06-12 18:19:49.315090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("id is:",ie.getVideoId())
    print("Title is:",ie.getTitle())
    print("Description is:",ie.getDescription())
    print("Thumbnail is:",ie.getThumbnail())


# Thumbnail is not set
# Description is not set

# Generated at 2022-06-12 18:19:58.496050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie._download_webpage = lambda url, foo, bar=None: url
    ie.BRIGHTCOVE_URL_TEMPLATE = lambda x: 'brightcove_url_template'
    ie._search_regex = lambda pattern, string, name: 5
    info = ie.extract(url)
    assert info['url'] == 'brightcove_url_template5'
    assert info['id'] == 5
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-12 18:19:59.057173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  pass

# Generated at 2022-06-12 18:20:19.009648
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test provided in https://github.com/rg3/youtube-dl/issues/15017
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:24.140424
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    return ie

# Generated at 2022-06-12 18:20:26.378738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-12 18:20:31.941139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
#test_TheStarIE()

# Generated at 2022-06-12 18:20:42.484563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  """Test for constructor of class TheStarIE.
  """
  extractor = TheStarIE()
  assert_equals(extractor._VALID_URL, 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:20:53.079458
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:03.321646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    instance = TheStarIE(url)
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:07.138521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    try:
        assert ie.get_info_extractor()
    except Exception:
        assert ie.get_info_extractor()

# Generated at 2022-06-12 18:21:09.024012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = InfoExtractor(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')
    ie.extract('4732393888001')

# Generated at 2022-06-12 18:21:12.913722
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-12 18:21:55.896179
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie != None)



# Generated at 2022-06-12 18:21:59.918060
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'mankind-why-this-woman-started-a-men-s-skincare-line')

# Generated at 2022-06-12 18:22:09.182596
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:22:10.537223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    

# Generated at 2022-06-12 18:22:12.090800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tst = TheStarIE(None)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:22:19.687480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor())._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:30.410393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    # Previous version of test (before 20160201) which was testing the
    # old method to access videos on thestar.com.
    # url = 'http://www.thestar.com/news/canada/2014/04/10/citytv_anchor_and_thestar_columnist_kevin_frankish_livetweets_brain_surgery.html'
    # url = 'http://www.thestar.com/news/gta/2014/04/10/toronto_serial_killers_alleged_elderly_victim_pleaded_for_help_before_death.html'

# Generated at 2022-06-12 18:22:32.827803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:33.242520
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:38.586742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId='
    ie.BRIGHTCOVE_URL_TEMPLATE = ie.BRIGHTCOVE_URL_TEMPLATE + '%s'
    ie.url_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.url_result = ie.url_result + '&brightcove_id=' + '%s'
    url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.BRIGHTCOVE

# Generated at 2022-06-12 18:24:21.163035
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL.match("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert TheStarIE._VALID_URL.match("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert TheStarIE._VALID_URL.match("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-12 18:24:29.540332
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    # TheStarIE.__init__(self, ie_name=None, ie_id=None, downloader=None)
    i = TheStarIE()
    
    
    
    
    
    
    # TheStarIE._real_extract(self, url)
    i._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    
    
    
    # TheStarIE._real_extract(self, url)
    i._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:37.904234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for TheStarIE
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._TEST.keys() == ['url', 'md5', 'info_dict', 'params']
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:24:40.165288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie is not None


# Generated at 2022-06-12 18:24:46.056681
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    # is a page with a video
    # The url for the video is displayed in a js object.
    url = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') 
    thestarIE = TheStarIE()
    thestarIE.extract(url)

# Generated at 2022-06-12 18:24:48.407695
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor (should not raise error)
    class_instance = TheStarIE()


# Generated at 2022-06-12 18:24:51.860248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:54.433655
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:57.594423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:24:59.681626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Unit test for constructor of class TheStarIE
    TheStarIE = TheStarIE()
    assert hasattr(TheStarIE, '_download_webpage')