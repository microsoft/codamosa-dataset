

# Generated at 2022-06-12 18:17:19.829061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:20.788475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	verifyObject(TheStarIE, TheStarIE)

# Generated at 2022-06-12 18:17:27.376353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarie = TheStarIE()
    thestarie.BRIGHTCOVE_URL_TEMPLATE
    thestarie._VALID_URL
    thestarie.test()
    thestarie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:17:30.664596
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    url = info_extractor._TEST['url']
    assert url == info_extractor._VALID_URL
    assert '4732393888001' == info_extractor._TEST['info_dict']['id']

# Generated at 2022-06-12 18:17:39.293377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test 1 - Test a valid url 
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url_obj = TheStarIE(url)
    # At this point, ensure that we have a TheStarIE object
    assert isinstance(url_obj,TheStarIE)
    # Verify if the url is in _VALID_URL for TheStarIE
    assert(url_obj.IE_NAME=='TheStarIE')
    # Ensure that the _VALID_URL is of the form "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-12 18:17:49.534268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._downloader.http.add_responses([
        (ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001',
         {'status': '200', 'body': 'test-brightcove-id'}),
    ])
    t = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert t != None
    assert t['id'] == '4732393888001'
    assert t['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:17:50.040109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:51.521590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST)

# Generated at 2022-06-12 18:17:56.317249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    cls = TheStarIE
    ins = cls()
    assert ins.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:17:59.581534
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    m=TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert m!=None

# Generated at 2022-06-12 18:18:13.160503
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'
    assert ie._TEST.get("url") == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-12 18:18:14.438175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:18:22.801674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = obj._match_id(url)
    webpage = obj._download_webpage(url, display_id)
    brightcove_id = obj._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    # I don't know how to assign the value of brightcove_id to id

# Generated at 2022-06-12 18:18:24.720790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert infoExtractor.has_key('TheStar')

# Generated at 2022-06-12 18:18:35.108563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.PLAYER_URL == "http://players.brightcove.net/794267642001/default_default/index.html"

# Generated at 2022-06-12 18:18:35.657837
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:42.793899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:45.434857
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:57.582980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test class TheStarIE
    """
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    test_ie = TheStarIE()
    
    # Test for internal static variables
    assert test_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
    # Test for private class variables
    assert test_ie._TEST['url'] == url


# Generated at 2022-06-12 18:19:00.058143
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This is a test for the constructor of class TheStarIE
    ie = TheStarIE()
    ie.brightcove_url_template # This should not cause any exceptions
    # If it gets to this point, it passes!


# Generated at 2022-06-12 18:19:12.365606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:13.407868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-12 18:19:14.563328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    print(instance)

# Generated at 2022-06-12 18:19:15.492780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()


# Generated at 2022-06-12 18:19:20.655759
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"


# Generated at 2022-06-12 18:19:28.783695
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:29.630620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALI

# Generated at 2022-06-12 18:19:32.632438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-12 18:19:34.841983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.extract(ie._VALID_URL)

# Generated at 2022-06-12 18:19:42.841973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:06.605807
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", factory=True)

    assert ie.IS_REQUIRED_TO_PASS_URL_TO_CONSTRUCTOR == True
    assert ie.IS_REQUIRED_TO_USE_FACTORY == True
    assert ie.IS_SUITABLE_FOR_UNITTEST == True
    assert ie.IS_SUITABLE_FOR_INTEGRATIONTEST == False
    assert ie.IS_SUITABLE_FOR_GOLDTEST == False
    assert ie.IE_NAME == "TheStar"

# Generated at 2022-06-12 18:20:16.640866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:25.847084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-12 18:20:32.169984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.display_id == "4732393888001"
    assert ie.webpage == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.brightcove_id == "4732393888001"

# Generated at 2022-06-12 18:20:37.925838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE().extract('http://www.thestar.com/videozone/2013/12/13/revealing_the_hidden_treasures_of_scarborough.html')

# Generated at 2022-06-12 18:20:38.977678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test: no exceptions in constructor
    assert ie

# Generated at 2022-06-12 18:20:44.912728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert i is not None
    if (i.VALID_URL == ""):
        assert i.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    if (i.TEST['url'] == ""):
        assert i.TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    if (i.TEST['md5'] == ""):
        assert i

# Generated at 2022-06-12 18:20:48.254051
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
  assert obj._VALID_URL is not None

# Generated at 2022-06-12 18:20:51.901638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:55.739329
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    b = TheStarIE()

# Generated at 2022-06-12 18:21:41.527068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    # Construct an instance of TheStarIE
    inst = TheStarIE()

# Generated at 2022-06-12 18:21:49.400628
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:21:50.120290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:53.290704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Creating object of class TheStarIE
    TheStarObject = TheStarIE()

    # checking class variables
    assert TheStarObject._TEST
    assert TheStarObject.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:21:54.048156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:58.674865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # A simple test to check the url template of constructor is correct or not
    url_template = ie.BRIGHTCOVE_URL_TEMPLATE
    assert url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:22:02.573754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE({})
    assert 'BrightcoveNew' == thestarIE.ie_key()
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' == thestarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:22:07.233223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert TheStarIE._VALID_URL == ie._VALID_URL
    assert TheStarIE._TEST == ie._TEST
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:22:17.500867
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:19.538665
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._TEST['url'] == TheStarIE._VALID_URL)

# Generated at 2022-06-12 18:23:11.089379
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-12 18:23:14.971034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:23:16.192371
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # No-op.  The test for this class is in test_suite.py
    pass

# Generated at 2022-06-12 18:23:17.265714
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie)



# Generated at 2022-06-12 18:23:20.303534
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:23:22.780498
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:23:24.427211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructing object of class TheStarIE
    obj = TheStarIE()
    return True

# Generated at 2022-06-12 18:23:25.999374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE() # Shouldn't raise any exception

# Generated at 2022-06-12 18:23:33.263910
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # 
    # Test 1: constructor with single argument
    #
    TheStarIE(options={'listformats': False})
    TheStarIE(options={'outtmpl': '%(id)s-%(ext)s'})
    TheStarIE(options={'outtmpl': None})
    TheStarIE(options={'quiet': True})
    TheStarIE(options={'verbose': True})
    TheStarIE(options={'stderr': True})
    TheStarIE(options={'no_warnings': True})

    # 
    # Test 2: constructor with multiple argument
    #
    TheStarIE(
        options={'listformats': False},
        params={'simulate': True}
    )

# Generated at 2022-06-12 18:23:36.629120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.name == 'TheStar.com'
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:25:08.392723
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None


# Generated at 2022-06-12 18:25:11.618798
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:25:18.794292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:25:20.847188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').__class__.__name__ == "TheStarIE"

# Generated at 2022-06-12 18:25:23.225110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.constructor.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:25:24.335948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert isinstance(inst, TheStarIE)

# Generated at 2022-06-12 18:25:28.193394
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    parsed_url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    inst = TheStarIE(parsed_url)
    assert True == inst.__class__._TEST['md5'].startswith('2')


# Generated at 2022-06-12 18:25:30.314872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL


# Generated at 2022-06-12 18:25:39.910012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("test", "www.thestar.com", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "4732393888001")
    assert obj.VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.TEST["url"] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert obj.TEST["md5"] == "2c62dd4db2027e35579fefb97a8b6554"


# Generated at 2022-06-12 18:25:47.062426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'