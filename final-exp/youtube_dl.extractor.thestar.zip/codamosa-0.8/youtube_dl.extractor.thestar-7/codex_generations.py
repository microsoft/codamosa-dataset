

# Generated at 2022-06-12 18:17:23.219083
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()

# Generated at 2022-06-12 18:17:24.071273
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-12 18:17:28.540148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    Test for TheStar video.
    '''
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(None)._real_extract(video_url)

# Generated at 2022-06-12 18:17:30.800804
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

# Generated at 2022-06-12 18:17:34.242034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)

# Generated at 2022-06-12 18:17:37.233464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:37.845727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:40.281494
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from sys import argv
    if len(argv) < 2:
        print('Usage: %s <url>' % argv[0])
        exit(1)

    i = TheStarIE()
    i._downloader = None
    i.url_result(argv[1])

# Generated at 2022-06-12 18:17:46.065743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()

    # Test regex matches
    expected = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    actual = the_star._get_url('Mankind: Why this woman started a men\'s skin care line')
    assert expected == actual

# Generated at 2022-06-12 18:17:49.176772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:53.751757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:03.032620
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def get_info(url):
        ie = TheStarIE()
        return ie.extract(url)

    info = get_info('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info['id'] == '4732393888001'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info['thumbnail'] == 're:https?://.*\.jpg'
    assert info['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert info['uploader_id'] == '794267642001'

# Generated at 2022-06-12 18:18:09.363545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info = TheStarIE(TheStarIE._TEST)._TEST
    assert len(test_info) > 0
    url = test_info['url']
    test_info = TheStarIE(url)._real_extract(url)
    assert test_info.url == TheStarIE._TEST['params']['skip_download']
    assert test_info.display_id == TheStarIE._TEST.get('display_id', TheStarIE._TEST['id'])

# Generated at 2022-06-12 18:18:18.794917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create TheStarIE object
    theSTAR_ie_obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert theSTAR_ie_obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theSTAR_ie_obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:18:20.980711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:18:27.817622
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'url_template'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'url_template'

# Generated at 2022-06-12 18:18:37.279911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE()
    assert e._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:43.918721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE_instance = TheStarIE()
    assert test_TheStarIE_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert test_TheStarIE_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:50.589155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    try:
        TheStarIE(None)
        TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', None)
    except Exception as e:
        # Need print e for complete the debug for the error
        print(e)
        assert(False)


# Generated at 2022-06-12 18:18:54.142453
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.download('4732393888001')

# Generated at 2022-06-12 18:19:04.280411
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-12 18:19:12.792423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check if constructor throws exception in case of incorrect URL
    # ie = TheStarIE('https://www.thestar.com/news.html')  # assertRaises
    # ie = TheStarIE('https://www.thestar.com/news/news.html')  # assertRaises
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html')
    assert ie._VALID_URL == ie._VALID_URL
    return ie

# Generated at 2022-06-12 18:19:17.670888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    # Instantiate an object of class TheStarIE
    thestar_ie = TheStarIE()
    # Check that the id for this instance is correct
    assert(thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:19:20.972758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE != None
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:22.107553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    pass

# Generated at 2022-06-12 18:19:30.286970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:30.787868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:31.265378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:19:34.082865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)

# Generated at 2022-06-12 18:19:40.032452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # If a test fails, return False
    print('\nRunning unit test for class TheStarIE')
    test_TheStarIE_instance = TheStarIE()
    if test_TheStarIE_instance.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s':
        return False
    print('Unit test passed.')
    return True

# Generated at 2022-06-12 18:19:50.634843
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	test.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:19:58.538214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test object creation
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie.extract(url)
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:19:59.101058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:02.216831
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:02.690823
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:05.342204
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:20:07.696193
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE()

# Generated at 2022-06-12 18:20:09.755589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:20:11.984676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test for TheStarIE.BRIGHTCOVE_URL_TEMPLATE 
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:20:17.585701
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = TheStarIE()._valid_url("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-12 18:20:37.505744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = InfoExtractor.getInfoExtractor(TheStarIE.ie_key(), TheStarIE.ie_key())
    assert ie.name == TheStarIE.ie_key()


# Generated at 2022-06-12 18:20:39.373646
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-12 18:20:40.966569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.get_video_info()

# Generated at 2022-06-12 18:20:50.938746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:51.926779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-12 18:20:56.463475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE._VALID_URL is not None
	assert TheStarIE._TEST is not None
	assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-12 18:20:56.991878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  return True

# Generated at 2022-06-12 18:21:00.670360
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Test if TheStarIE is an instance of InfoExtractor
  ie = TheStarIE();
  assert(isinstance(ie, InfoExtractor));
  
# Test for the _real_extract function of class TheStarIE

# Generated at 2022-06-12 18:21:02.477121
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE()._TEST == TheStarIE._TEST

# Generated at 2022-06-12 18:21:06.952760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert TheStarIE('https://www.thestar.com/news/gta/2016/04/03/toronto-police-respond-to-shooting-at-jane-and-finch.html')

# Generated at 2022-06-12 18:21:37.343442
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test no upload_date and timestamp
    ie._downloader.cache.remove('4732393888001')
    ie.urls = ['http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html']
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie.extract()

# Generated at 2022-06-12 18:21:46.442178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    #Test for class inheritance
    assert isinstance(ie, InfoExtractor)
    #Test for instance attributes
    assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:21:47.878746
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    assert True == True

# Generated at 2022-06-12 18:21:50.473686
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
   thestar = TheStarIE(InfoExtractor())
   # thestar = thestar._real_extract(url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:52.200356
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:21:53.234817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:57.072060
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:02.231041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE(InfoExtractor)
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:04.267898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE._downloader) != None

# Unit tests for TheStarIE

# Generated at 2022-06-12 18:22:11.768712
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie._url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._video_id == '4732393888001'
    assert ie._display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-12 18:22:55.696207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(object).ie_key() == 'TheStar'

# Generated at 2022-06-12 18:22:58.618493
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    nie = TheStarIE()
    assert nie._VALID_URL == r'^https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html$'
    assert nie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:07.475210
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE_test = TheStarIE()
    brightcove_id = '4865942404001'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' % brightcove_id
    TheStarIE_test.BRIGHTCOVE_URL_TEMPLATE = brightcove_url
    assert TheStarIE_test.BRIGHTCOVE_URL_TEMPLATE == brightcove_url
    display_id = 'test_thestar_url'
    assert TheStarIE_test._match_id(display_id) == display_id

# Generated at 2022-06-12 18:23:09.495805
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:09.996555
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)

# Generated at 2022-06-12 18:23:19.332541
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE()
    assert thestarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert thestarIE._TEST[
               'url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert thestarIE._TEST[
               'md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-12 18:23:21.673693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:22.472028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(isinstance(TheStarIE, InfoExtractor))

# Generated at 2022-06-12 18:23:24.357101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:23:25.251578
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:24:57.446471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-12 18:25:01.418902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    TheStarIE._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:25:02.590077
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    return ie

# Generated at 2022-06-12 18:25:12.908188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie._match_id("www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    ie._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "mankind-why-this-woman-started-a-men-s-skincare-line")

# Generated at 2022-06-12 18:25:14.550793
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except(AttributeError, TypeError):
        pass
    else:
        raise Exception('Unit test failed.')

# Generated at 2022-06-12 18:25:17.788758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.suitable(url)
    assert "4732393888001" == ie._match_id(url)

# Generated at 2022-06-12 18:25:20.162870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    response = requests.get("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    html_doc = response.text
    print(html_doc)

# Generated at 2022-06-12 18:25:24.088657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.get_id() == 'TheStar'
    assert ie.get_name() == 'TheStar'
    assert ie.get_edition() == 'en-US'

# Generated at 2022-06-12 18:25:26.817518
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'), InfoExtractor)

# Generated at 2022-06-12 18:25:31.617357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.validate_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie.BRIGHTCOVE_URL_TEMPLATE