

# Generated at 2022-06-12 18:17:23.608455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:27.772402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_case = TheStarIE()
    assert test_case._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-12 18:17:36.625075
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:40.632732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("4732393888001")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:17:42.405538
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:17:47.942711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == TheStarIE._VALID_URL
    assert ie.IE_NAME == 'thestar'
    assert ie.SCREEN_NAME == 'thestar'

# Generated at 2022-06-12 18:17:49.175173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    UnitTestTheStarIE = TheStarIE()
    assert isinstance(UnitTestTheStarIE, TheStarIE)

# Generated at 2022-06-12 18:17:51.555248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE(0)
    assert t._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-12 18:18:00.077749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("test_TheStarIE:")
    theStar = TheStarIE()
    expected = u'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    print("TheStarIE: The expected value is: %s" % expected)
    print("TheStarIE: The actual value is: %s" % theStar.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')
    assert(theStar.BRIGHTCOVE_URL_TEMPLATE % '4732393888001' == expected)

# Generated at 2022-06-12 18:18:01.002861
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        test = TheStarIE()
    except:
        raise AssertionError('TheStarIE class instantiation')


# Generated at 2022-06-12 18:18:08.550933
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    web_page = ie._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '')
    assert '4732393888001' in web_page

# Generated at 2022-06-12 18:18:11.038706
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-12 18:18:14.009298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:22.771169
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:23.354139
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:31.406758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE( 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' )
        assert True
    except:
        print ("ERR: TheStarIE 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'")
        assert False

# Generated at 2022-06-12 18:18:33.562954
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Testing constructor of class TheStarIE")
	t = TheStarIE()
	print("class TheStarIE is tested")


# Generated at 2022-06-12 18:18:34.146945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:35.445463
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE

# Generated at 2022-06-12 18:18:46.069576
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._VALID_URL = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:18:55.060974
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(TheStarIE.IE_NAME, True)


# Generated at 2022-06-12 18:19:02.477018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:19:04.001407
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-12 18:19:10.174288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert thestar_ie.brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?vedeoId=%s'

# Generated at 2022-06-12 18:19:20.165621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    from .test_ThePlatformIE import _build_mock_extractor
    from .test_BrightcoveNew import _build_mock_course_info

    class MockIE(TheStarIE):
        @staticmethod
        def _build_course_info(course_code, course_url, course_name, course_number, course_info, course_chapter_info):
            return _build_mock_course_info(course_code, course_url, course_name, course_number, course_info, course_chapter_info)

        @staticmethod
        def _build_platform_extractor(platform_url, *args, **kwargs):
            return _build_mock_extractor(platform_url, *args, **kwargs)


# Generated at 2022-06-12 18:19:22.321583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:19:29.221766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None
    assert ie.IE_NAME == 'TheStar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-12 18:19:35.574398
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:19:37.644794
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""Unit test for constructor of class TheStarIE"""
	# Make sure that the constructor is working properly
	assert TheStarIE()

# Generated at 2022-06-12 18:19:44.461876
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:01.779156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:02.245588
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:04.934084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:05.750048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(1,1,1)

# Generated at 2022-06-12 18:20:08.276396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('test')  # args: 'TheStarIE' and 'self'

# Generated at 2022-06-12 18:20:10.171685
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert isinstance(the_star_ie, TheStarIE)


# Generated at 2022-06-12 18:20:12.636142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-12 18:20:13.167092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:17.625008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie.name == "TheStar"
	assert ie.ie_key() == "TheStar"
	assert ie.get_hostname() == "TheStar"
	assert ie.description == "TheStar"
	assert ie.get_domain() == "TheStar"
	assert ie.url_result == "TheStarIE"

# Generated at 2022-06-12 18:20:19.960878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:20:42.082077
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test for validating the URL for Brightcove player
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test for validating the URL for Brightcove API
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

    # Test for matching the valid URL for extracting the video
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # Test for extracting the video ID from the URL

# Generated at 2022-06-12 18:20:42.998364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-12 18:20:43.646014
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:20:44.245856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.constructor()

# Generated at 2022-06-12 18:20:45.818863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').check_url() == True

# Generated at 2022-06-12 18:20:50.482388
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:20:54.973128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test extraction of video ID
    assert ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            '<script type="text/javascript">var mainartBrightcoveVideoId = "4732393888001"', 'video id')
    assert ie._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            '<script type="text/javascript">var mainartBrightcoveVideoId = "4732393888001";', 'video id')

# Generated at 2022-06-12 18:20:56.297506
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_obj = TheStarIE()
    print(ie_obj._TEST)

# Generated at 2022-06-12 18:20:59.909470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_test = TheStarIE()
    assert thestar_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:05.371449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.video_id == '4732393888001'


# Generated at 2022-06-12 18:21:46.568678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:21:49.340633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    from youtube_dl.utils import make_HTTPS_handler

    class Test(unittest.TestCase):
        def setUp(self):
            self.ie = TheStarIE()

    Test().setUp()

# Generated at 2022-06-12 18:21:55.896386
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html' 


# Generated at 2022-06-12 18:21:56.822305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:22:00.051294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:22:02.449178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tmp_TheStarIE = TheStarIE("TheStarTest", {}, {}, {})
    assert tmp_TheStarIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-12 18:22:11.110134
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:16.648012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    inst = TheStarIE()
    # constructor
    TheStarIE(inst)
    # test _real_extract
    result = TheStarIE._real_extract(inst, url)
    assert display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-12 18:22:17.846217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert (TheStarIE() != None)

# Generated at 2022-06-12 18:22:19.208523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:23:59.184293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    if ie.BRIGHTCOVE_URL_TEMPLATE != "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s":
        assert False
    if ie._VALID_URL != r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html':
        assert False

# Generated at 2022-06-12 18:24:01.246009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE, "__init__")
    assert "InfoExtractor" in TheStarIE.__bases__

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-12 18:24:10.720972
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	thestar_ie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	# thestar_ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	# thestar_ie._TEST = {
	# 	'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
	# 	'md5': '2c62dd4db2027e35579fefb97a8b6554',
	# 	'info

# Generated at 2022-06-12 18:24:18.640110
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:20.050035
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test constructor of class TheStarIE
    """
    url = TheStarIE._VALID_URL
    ie = TheStarIE(url)
    assert ie
    assert ie._VALID_URL == url

# Generated at 2022-06-12 18:24:20.462371
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:24:21.151964
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-12 18:24:21.849762
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()


# Generated at 2022-06-12 18:24:22.448058
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-12 18:24:27.986980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for url in the form:
    # http://www.thestar.com/…/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    # i.e. url contains ".html"
    url = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE().suitable(url)
