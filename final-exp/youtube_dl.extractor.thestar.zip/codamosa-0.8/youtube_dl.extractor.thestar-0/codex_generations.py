

# Generated at 2022-06-12 18:17:33.105358
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # As of writing this unit test, the webpage for `url` is not live
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:17:34.532092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	a=TheStarIE()

# Generated at 2022-06-12 18:17:38.933758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    obj._download_webpage = lambda x,y,z: False
    obj._search_regex = lambda x,y,z: False
    obj._match_id = lambda x,y: False

    assert callable(obj._download_webpage)
    assert callable(obj._search_regex)
    assert callable(obj._match_id)

# Generated at 2022-06-12 18:17:41.029388
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor
    assert TheStarIE()


# Generated at 2022-06-12 18:17:44.712220
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:46.058978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.br != ""

# Generated at 2022-06-12 18:17:50.190361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert(TheStarIE(TheStarIE._downloader, TheStarIE._VALID_URL)._VALID_URL == TheStarIE._VALID_URL)
	assert(TheStarIE(TheStarIE._downloader, TheStarIE._TEST['url'])._VALID_URL == TheStarIE._VALID_URL)


# Generated at 2022-06-12 18:17:51.081727
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None

# Generated at 2022-06-12 18:17:55.580749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None, None, None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:17:57.374133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assert that the test for the constructor of class TheStarIE is created.
    assert TheStarIE._TEST

# Generated at 2022-06-12 18:18:02.376507
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert isinstance(result, TheStarIE) == True


# Generated at 2022-06-12 18:18:05.530320
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check whether the constructed class is TheStarIE
    assert isinstance(TheStarIE(), TheStarIE)

# Generated at 2022-06-12 18:18:06.132347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:08.998829
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Make sure the class constructor is accessible
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-12 18:18:18.646056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE() 
    TheStarIE.__init__(theStarIE)
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:22.035589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStarIE._download_webpage = lambda x, y, z: '4732393888001'
    ie._real_extract('')

# Generated at 2022-06-12 18:18:33.518369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    this_instance = TheStarIE()
    assert(this_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-12 18:18:34.459203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._TEST)

# Generated at 2022-06-12 18:18:36.827615
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE, type)

# Generated at 2022-06-12 18:18:37.385835
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  pass

# Generated at 2022-06-12 18:18:45.324607
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:18:50.731899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'), TheStarIE)


# Generated at 2022-06-12 18:18:54.245163
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	id 	= "4732393888001"
	url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	TheStarIE(id, url)

# Generated at 2022-06-12 18:19:02.044387
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    from csuf_ie import TheStarIE
    from csuf_images import TheStar

    # Test for constructor of TheStarIE
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST['info_dict']['id'] == '4732393888001'
    assert ie._

# Generated at 2022-06-12 18:19:03.594733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie is not None


# Generated at 2022-06-12 18:19:06.381764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This is simple test case to verify that class TheStarIE is 
    # instantiated correctly.
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:19:11.049113
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if the class TheStarIE has been initialized
    TheStarIE_test = TheStarIE()

# Generated at 2022-06-12 18:19:19.874850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tests for each kind of video
    # TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # TheStarIE("http://www.thestar.com/news/crime/2014/05/09/witness_testifies_rob_ford_smoked_crack_during_australia_trip.html")
    TheStarIE("http://www.thestar.com/news/gta/2016/02/01/toronto-police-looking-for-gun-link-as-shooting-death-of-teen-is-first-homicide-of-2016.html")

# Generated at 2022-06-12 18:19:21.902766
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-12 18:19:26.026181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	x = TheStarIE()
	if x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' and\
	x._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html':
		return 1
	else:
		return 0


# Generated at 2022-06-12 18:19:35.082068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test(TheStarIE)

# Generated at 2022-06-12 18:19:36.287146
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-12 18:19:45.067834
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # get test data from instance of TheStarIE class
    test = ie._TEST
    # get url from test data
    url = test['url']
    # get ID from url using _match_id function
    display_id = ie._match_id(url)
    # get webpage data using _download_webpage function
    webpage = ie._download_webpage(url, display_id)
    # get brightcove_id from webpage data using _search_regex function
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    # get url result from url_result function

# Generated at 2022-06-12 18:19:45.609550
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-12 18:19:48.685095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:49.381915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-12 18:19:58.585337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    train_ie = TheStarIE()
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    webpage = train_ie._download_webpage(test_url, None)
    brightcove_id = train_ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    test_url = train_ie.BRIGHTCOVE_URL_TEMPLATE % brightcove_id
    train_ie.url_result(test_url, 'BrightcoveNew', brightcove_id)


# Generated at 2022-06-12 18:20:02.867284
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.webpage = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie.has_get_video_url() == False
    assert ie.has_get_playlist_entries() == False
    assert ie.has_get_video_info() == False

# Generated at 2022-06-12 18:20:04.645775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(str(TheStarIE({})) != '')

# Generated at 2022-06-12 18:20:08.710651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        # Initialize the class object
        the_star_ie = TheStarIE()
        # Test if the object is not null
        assert the_star_ie is not None
    except Exception:
        # Throw the error so that we can see the exception
        raise AssertionError

# Generated at 2022-06-12 18:20:24.972470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:20:28.631389
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    instance._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:20:29.848378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://example.com/random')
    assert ie.options['skip_download'] is True

# Generated at 2022-06-12 18:20:31.941012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'


# Generated at 2022-06-12 18:20:33.512855
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie is not None


# Generated at 2022-06-12 18:20:40.175579
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # assert that the constructor of class TheStarIE can be invoked
    try:
        # invoke constructor of class TheStarIE
        ie = TheStarIE()
    except:
        assert False, "constructor of class TheStarIE can not be invoked"
    else:
        assert True, "constructor of class TheStarIE is invoked"



# Generated at 2022-06-12 18:20:40.592367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    asser

# Generated at 2022-06-12 18:20:43.953216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # has at least one instance specific function
    assert hasattr(ie, '_real_extract')
    # has at least one instance specific attribute
    assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')

# Generated at 2022-06-12 18:20:52.122093
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    star = TheStarIE(url) # create instance of TheStarIE class
    assert star.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert star.display_id == "4732393888001"
    assert star.url == url

# Generated at 2022-06-12 18:21:00.224721
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', 'BrightcoveNew', '4732393888001') == ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'

# Generated at 2022-06-12 18:21:43.329443
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/entertainment/2016/02/01/bruce-springsteen-cover-band-ramps-up-police-union-pressure.html')

# Generated at 2022-06-12 18:21:44.224457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:21:47.705863
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check the case of the class is constructed with wrong arguments.
    obj = TheStarIE(InfoExtractor._downloader, None, None)
    assert obj is not None, "TheStarIE instance is constructed with wrong arguments."

# Generated at 2022-06-12 18:21:52.765850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage = lambda *x: None
    ie._search_regex = lambda *x: '4732393888001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.url_result(ie.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', 'BrightcoveNew', '4732393888001').url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-12 18:22:01.098455
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert(hasattr(TheStarIE, '_download_webpage'))
	assert(hasattr(TheStarIE, '_match_id'))
	assert(hasattr(TheStarIE, '_search_regex'))
	assert(hasattr(TheStarIE, 'url_result'))
	assert(hasattr(TheStarIE, 'BRIGHTCOVE_URL_TEMPLATE'))
	assert(hasattr(TheStarIE, '_VALID_URL'))
	assert(hasattr(TheStarIE, '_TEST'))
	assert(hasattr(TheStarIE, '_real_extract'))

# Generated at 2022-06-12 18:22:04.545986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:22:12.365123
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.getOpenGraphTitle(u'<meta property="og:title" content="TheStar">') == u'TheStar'
    assert ie.getOpenGraphTitle(u'<meta property="og:title" content="The Star">') == u'The Star'
    assert ie.getOpenGraphTitle(u'<meta property="og:title" content="The Star - Less than 4 characters">') == u'The Star - Less than 4 characters'
    assert ie.getOpenGraphTitle(u'<meta property="og:title" content="Mankind: Why this woman started a men\'s skin care line">') == u'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-12 18:22:19.914061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.display_id == '4732393888001'
    assert ie.get_id() == '4732393888001'

# Generated at 2022-06-12 18:22:23.223954
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar_ie = TheStarIE()
    # test that TheStarIE extends the InfoExtractor class
    assert isinstance(theStar_ie, InfoExtractor)

# Generated at 2022-06-12 18:22:24.683549
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import TheStarIE
    TheStarIE(None, None)

# Generated at 2022-06-12 18:24:03.417953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test with a live URL
    result = TheStarIE().result("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");

    # Test with a local file containing HTML
    #with open("/tmp/test.html", "rb") as f:
    #    result = TheStarIE().result_from_file(f);

    # Test with a URL that doesn't exist
    #result = TheStarIE().result("http://www.thestar.com/doesnotexist");

    # Make sure the link is a valid one
    assert result.get("_type", "") == "url", "We didn't get a URL from TheStarIE()"

# Generated at 2022-06-12 18:24:11.095770
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:13.411275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE('http://www.thestar.com/sports/olympics/2014/02/13/canabalt_top_of_the_world_games.html');

# Generated at 2022-06-12 18:24:15.234111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    tsi = TheStarIE(unittest.TestCase())
    assert tsi.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:23.323444
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert (TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"))._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+).html'

# Generated at 2022-06-12 18:24:24.557041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_downloader import _test_downloader
    _test_downloader(TheStarIE)

# Generated at 2022-06-12 18:24:26.937686
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:28.870337
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    unittest.TestCase.assertEqual(TheStarIE('test').test_test_test, 'OK')

# Generated at 2022-06-12 18:24:33.504313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:24:45.119355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert inst._URL_TEMPLATE == 'http://www.thestar.com/{display_id}.html'
    assert inst._DOMAINS == ['thestar.com']