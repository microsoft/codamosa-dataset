

# Generated at 2022-06-12 18:17:32.086453
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie._download_webpage = lambda *args: None
    info = ie._real_extract(url)

# Generated at 2022-06-12 18:17:34.486617
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:17:35.118915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-12 18:17:35.846230
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:17:37.973540
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	class_ = TheStarIE
	instance = class_(None)
	assert isinstance(instance, class_)


# Generated at 2022-06-12 18:17:42.404783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    info = ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:17:50.394234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # Load the test video
  thestar = TheStarIE()
  thestar.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

  # Load the test video
  thestar.extract('http://www.thestar.com/entertainment/music/2016/02/01/macklemore-and-ryan-lewis-talk-hip-hop-and-childhood-on-the-starcom.html')

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-12 18:18:01.159906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_info = {
      'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
      'ext': 'mp4',
      'id': '4732393888001',
      'md5': '2c62dd4db2027e35579fefb97a8b6554',
      'timestamp': 1454353482,
      'title': 'Mankind: Why this woman started a men\'s skin care line',
      'upload_date': '20160201',
      'uploader_id': '794267642001',
      'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    }

    TheStarIE_obj = The

# Generated at 2022-06-12 18:18:05.277234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # test that the url match
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = ie.suitable(url)
    # test that the url match
    assert result == True
    # test that the url dont match
    url = 'http://www.ted.com/talks/hans_rosling_the_magic_washing_machine'
    result = ie.suitable(url)
    assert result == False
    # test result dictionary of match
    result = ie.extract(url)
    assert result['id'] == '4732393888001'
    assert result['ext'] == 'mp4'

# Generated at 2022-06-12 18:18:06.228790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:09.560509
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    site = TheStarIE()
    assert site.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 18:18:19.156827
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:18:24.182269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Validate with correct URL
    correct_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(TheStarIE._downloader).suitable(correct_url)

    #Validate with false URL
    false_url = 'http://www.thestar.com/news/gta/2013/05/16/toronto_expert_says_self_driving_car_crash_in_california_raises_challenging_questions.html'
    TheStarIE(TheStarIE._downloader).suitable(false_url)

# Generated at 2022-06-12 18:18:27.475279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    result = TheStarIE._build_url_result(url)
    assert(result == {'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001', 'ie_key': 'BrightcoveNew', 'video_id': '4732393888001'}
) 




# Generated at 2022-06-12 18:18:37.037175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("TheStarIE")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:18:44.480658
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    expect = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert info_extractor._real_extract(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ) == info_extractor.url_result(expect, 'BrightcoveNew', '4732393888001')

# Generated at 2022-06-12 18:18:45.173554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:47.164420
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:18:49.554734
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor) == True


# Generated at 2022-06-12 18:18:52.437501
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-12 18:19:06.946065
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:19:14.006265
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:19:22.805708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert result['id'] == '4732393888001'
    assert result['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert result['ext'] == 'mp4'
    assert result['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert result['timestamp'] == 1454353482
    assert result['upload_date'] == '20160201'
    assert result['uploader_id'] == '794267642001'

# Generated at 2022-06-12 18:19:32.643626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Setup
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Run
    ie = TheStarIE()._real_extract(url)
    # Test
    assert ie.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.video_id == '4732393888001'
    assert ie.ext == 'mp4'
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.uploader_id

# Generated at 2022-06-12 18:19:36.780403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # url is for testing
    url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # standard call of TheStarIE
    info = TheStarIE()._real_extract(url)
    # assert-statement: if expression1 is equal to expression2, execution will continue; otherwise, execution will stop and an AssertionError will be raised.
    assert info['id'] == '4732393888001', "TheStarIE id is %s and expected is 4732393888001" % info['id']

# Generated at 2022-06-12 18:19:45.439946
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:19:47.256133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:19:54.265597
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    test_suite = unittest.TestSuite()

    # test for function _real_extract with valid input
    test_suite.addTest(
        TheStarIE(
            'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        ).real_extract(
            'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
        )
    )

    # test for function real_extract with invalid input

# Generated at 2022-06-12 18:19:58.805594
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-12 18:20:07.018785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:20:17.624403
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:20:21.257305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.suitable(TheStarIE.create_ie(TheStarIE,'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))

# Generated at 2022-06-12 18:20:22.806644
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE
    except Exception as e:
        assert False, 'Constructor for class TheStarIE does not work'


# Generated at 2022-06-12 18:20:24.824985
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = TheStarIE('www.thestar.com/some/path.html').display_id
    assert s == "path"

 # 2nd Unit test class TheStarIE

# Generated at 2022-06-12 18:20:26.727588
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        theStarIE = TheStarIE()
    except:
        return False
    return True

# Generated at 2022-06-12 18:20:28.289457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Unit test to test TheStarIE class
	"""
	# Testing the browser is created.
	assert TheStarIE()._downloader is not None

# Generated at 2022-06-12 18:20:31.107109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    page = "Test Page"
    validation_string = "4732393888001"

    # _real_extract extracts the ID from the page using regex
    assert ie._real_extract(page,validation_string) == ie.BRIGHTCOVE_URL_TEMPLATE % validation_string

# Generated at 2022-06-12 18:20:42.232499
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of TheStarIE
    '''
    This unit test is to check whether class TheStarIE can be created
    successfully or not. To check correctness of the class, we will check
    whether some fields of the class can be access or not.
    '''
    ie = TheStarIE()
    '''
    This unit test is to check whether the class field _VALID_URL can be
    access or not. If the class field _VALID_URL can be access, the unit
    test is considered as passed, otherwise it is considered as failed.
    '''
    ie._VALID_URL

# Generated at 2022-06-12 18:20:53.026733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>[^/]+)\.html'

# Generated at 2022-06-12 18:21:00.413130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	newvideo = TheStarIE()
	assert newvideo.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	if newvideo.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s':
		print('TheStarIE class has been modified.')


# Generated at 2022-06-12 18:21:19.304394
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-12 18:21:30.292858
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test for constructor of class TheStarIE"""
    from .thestar import TheStarIE
    t = TheStarIE()
    assert t.name == 'TheStar'
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    t2 = TheStarIE(t.name, t.BRIGHTCOVE_URL_TEMPLATE, t._VALID_URL)
    assert t2.name == 'TheStar'

# Generated at 2022-06-12 18:21:37.931608
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print('Testing TheStarIE constructor')
    assert(TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')

# Generated at 2022-06-12 18:21:43.234193
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    video.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:46.172904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    the_star_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-12 18:21:52.616283
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE(InfoExtractor())
    thestarIE._download_webpage = lambda url, display_id: """
<html>
    <head>
        <meta name="twitter:image" content="https://www.thestar.com/content/dam/thestar/uploads/2016/02/01/skincare_mankind_2.jpg.size.custom.crop.324x288.jpg" />
    </head>
    <body>
        <div class="mainartBrightcoveVideoId">4732393888001</div>
    </body>
</html>
    """
    thestarIE._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:21:56.618864
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:21:59.514973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Construct instance of the class TheStarIE
	instantce_TheStarIE = TheStarIE()
	# Check if instance of TheStarIE is created
	assert type(instantce_TheStarIE) == TheStarIE

# Generated at 2022-06-12 18:22:00.052678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:01.497820
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE('', '', '', '', '')
    except Exception:
        pass
    else:
        assert False, "Test failed!"


# Generated at 2022-06-12 18:22:36.726970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-12 18:22:37.436848
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('TheStarIE')

# Generated at 2022-06-12 18:22:38.378406
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:22:39.771112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t._VALID_URL
    assert t._TEST

# Generated at 2022-06-12 18:22:45.559189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:22:54.439929
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for constructor of class TheStarIE
    # Test to see if the Test case for TheStarIE is constructed properly
    obj = TheStarIE({})

# Generated at 2022-06-12 18:22:56.480907
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-12 18:23:02.033055
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL =="https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert TheStarIE.__name__ == 'TheStarIE'
    assert TheStarIE.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-12 18:23:05.934986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:23:07.891353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:24:39.255710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:24:48.549196
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from . import YoutubeIE
    from . import BrightcoveLegacyIE
    from . import BrightcoveNewIE
    from . import BrightcoveIE
    from . import mtvservicesIE
    from . import mtvIE

    print("\nTesting TheStarIE")
    # Setup a mock class for direct instantiation.
    class MockTheStarIE(TheStarIE):
        def _real_initialize(self):
            return
    mock_instance = MockTheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    # Test the instance initialized properly by checking the value of its info dictionary.

# Generated at 2022-06-12 18:24:50.268608
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print(TheStarIE())

# Generated at 2022-06-12 18:24:58.367609
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-12 18:25:01.297402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# For this class, the following URL will be passed to TheStarIE class constructor.
	url = "http://wwww.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	TheStarIE(url)
# End of Unit test for constructor of class TheStarIE

# Generated at 2022-06-12 18:25:07.776257
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    # test _real_extract
    TheStarIE._real_extract(ie, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-12 18:25:11.323178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie


# Generated at 2022-06-12 18:25:12.799176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor())._VALID_URL == TheStarIE._VALID_URL

# Generated at 2022-06-12 18:25:13.266551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-12 18:25:15.836424
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'