

# Generated at 2022-06-26 12:51:54.487182
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:51:55.519362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:05.393105
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
    assert the_star_i_e_0._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:08.161958
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        assert (len(the_star_i_e_0.ie_key()) > 0)
    except:
        assert (False)


# Generated at 2022-06-26 12:52:17.410064
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    id = '4732393888001'
    title = 'Mankind: Why this woman started a men\'s skin care line'
    description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    uploader_id = '794267642001'
    timestamp = 1454353482
    upload_date = '20160201'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    params = {'skip_download': True}

    assert (the_star_i_e_0.url == url)
    assert (the_star_i_e_0.display_id == '4732393888001')

# Generated at 2022-06-26 12:52:19.659908
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:30.874545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:34.010096
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()
    assert the_star_i_e_1 is not None



# Generated at 2022-06-26 12:52:34.904563
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()

# Generated at 2022-06-26 12:52:40.386285
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e
    assert isinstance(the_star_i_e, TheStarIE) or isinstance(the_star_i_e, InfoExtractor)


# Generated at 2022-06-26 12:52:45.553286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert callable(TheStarIE)


# Generated at 2022-06-26 12:52:46.342856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:48.180361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:50.088430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(the_star_i_e_0, TheStarIE)

# Generated at 2022-06-26 12:53:00.081272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:02.026515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:53:04.924743
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        # Object creation
        TheStarIE()
    except Exception as e:
        assert False , 'Unable to create object for TheStarIE'


# Generated at 2022-06-26 12:53:07.973952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e != None



# Generated at 2022-06-26 12:53:09.301237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:53:10.447259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:53:15.717130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:53:18.878298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()

# Generated at 2022-06-26 12:53:28.338756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_inst = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie_inst._VALID_URL == 'http://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:33.873023
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:53:41.521767
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    not_implemented = 'raise NotImplementedError('
    for attr in ('url_result', '_real_extract', '_search_regex'):
        assert not_implemented not in getattr(TheStarIE, attr).__str__()
    ie = TheStarIE
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert 'BrightcoveNew' == ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:53:48.295452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:53:54.169423
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.url_result(
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=5722678024001',
        'BrightcoveNew', '5722678024001')

# Generated at 2022-06-26 12:54:02.221287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    t = TheStarIE()

    assert 'BrightcoveNew' == t.ie_key()

    url = 'rtsp://v5.cache3.c.youtube.com/CiILENy73wIaGQnhycnrJQ8qmRMYDSANFEgGUgZ2aWRlb3MM/0/0/0/video.3gp'
    url_result = t.url_result(url, 'BrightcoveNew')
    
    assert url == url_result.url
    assert 'BrightcoveNew' == url_result.ie_key()
    assert url_result == t.url_result(url, 'BrightcoveNew', '1234567890')
    
    # Test for _real_extract
    # I skip that test because the test url is likely changed all the time.


# Generated at 2022-06-26 12:54:02.851047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:03.290332
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return True

# Generated at 2022-06-26 12:54:19.878568
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    Video("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "4732393888001")
    Video("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "4732393888001", "Mankind: Why this woman started a men's skin care line")

# Generated at 2022-06-26 12:54:21.462949
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tsi = TheStarIE()
    return tsi

# Generated at 2022-06-26 12:54:25.854374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert(test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:54:32.121040
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj is not None

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:54:33.583567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE

# Generated at 2022-06-26 12:54:34.667778
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()

# Generated at 2022-06-26 12:54:35.822956
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-26 12:54:46.114516
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Test for constructor of class TheStarIE """
    obj = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-26 12:54:47.869783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract("test url");

# Generated at 2022-06-26 12:54:48.873923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()._real_extract(test_TheStarIE.__dict__["_TEST"]["url"])


# Generated at 2022-06-26 12:55:12.659197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Simple test for constructor of class TheStarIE
    """
    if not hasattr(TheStarIE, '_download_json'):
        TheStarIE._download_json = True
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:13.412753
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:16.301113
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:19.028664
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor test
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:20.059046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:55:21.578855
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:55:22.840090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE("TheStarIE", "TheStar")


# Generated at 2022-06-26 12:55:28.706754
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test = TheStarIE(url)
    assert test.URL.value == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-26 12:55:29.643339
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create instance of class TheStarIE
    thestar = TheStarIE()
    assert isinstance(thestar,TheStarIE)


# Generated at 2022-06-26 12:55:32.722084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.thestar_test == None

# Generated at 2022-06-26 12:56:08.843756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.constructor() == (None, None)

# Generated at 2022-06-26 12:56:18.582815
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:56:19.451371
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()


# Generated at 2022-06-26 12:56:20.623959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL

# Generated at 2022-06-26 12:56:21.421716
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(TheStarIE._VALID_URL, TheStarIE._TEST)

# Generated at 2022-06-26 12:56:27.032779
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # class TheStarIE(InfoExtractor)
    ['TheStarIE',
     'TheStarIE._VALID_URL',
     'TheStarIE._TEST',
     'TheStarIE.BRIGHTCOVE_URL_TEMPLATE',
     'TheStarIE._real_extract']
    # super class:

# Generated at 2022-06-26 12:56:33.853666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .tools import assertExtraction
    from .test_extractors import ExtractorTest as ET
    test = ET('/Users/teddywing/Projects/odm/youtube-dl_test/test_video/thestar.py', 'thestar.com', 'TheStarIE', module_relative=False, skip_setup=True)
    assertExtraction(test.run(), 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'TheStarIE')

# Generated at 2022-06-26 12:56:34.866472
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    inst.test_test()

# Generated at 2022-06-26 12:56:44.033281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Initialize the test object
    t1 = TheStarIE()
    # Add Test data

# Generated at 2022-06-26 12:56:51.940815
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:58:27.572492
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:58:33.029543
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    test_fixture = ie._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:58:41.388870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    t = TheStarIE()

    # Check using constructor
    assert t.BRIGHTCOVE_URL_TEMPLATE is not None
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:58:41.956981
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()


# Generated at 2022-06-26 12:58:43.188164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-26 12:58:54.668756
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:58:56.801480
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ''' The constructor of class TheStarIE '''
    assert TheStarIE.__name__ == "TheStarIE"

# Generated at 2022-06-26 12:59:02.925371
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_info_extractor = InfoExtractor()
    test_info_extractor.add_info_extractor(TheStarIE)
    test_info_extractor.download('http://www.thestar.com/news/canada/2016/01/24/british-columbia-familys-sick-puppy-dies-after-receiving-rabies-vaccine.html')

# Generated at 2022-06-26 12:59:11.083503
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor Test
    ie_obj = TheStarIE()
    ie_obj.extractor = '//www.youtube.com/watch?v=BaW_jenozKc'
    ie_obj.url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie_obj.display_id = 'BaW_jenozKc'
    assert ie_obj.extractor == 'BaW_jenozKc'
    assert ie_obj.url == 'https://www.youtube.com/watch?v=BaW_jenozKc'
    assert ie_obj.display_id == 'BaW_jenozKc'

# Generated at 2022-06-26 12:59:14.952828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE._VALID_URL % TheStarIE._TEST)
    assert ie.__class__ == TheStarIE
    print(ie.extract())