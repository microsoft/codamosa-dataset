

# Generated at 2022-06-26 12:51:55.886748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:51:57.006080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0!=None


# Generated at 2022-06-26 12:51:58.020433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:51:58.922504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:00.876692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e



# Generated at 2022-06-26 12:52:03.525395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructor for class TheStarIE
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:04.501457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert test_case_0() is None

# Generated at 2022-06-26 12:52:06.500970
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert isinstance(the_star_i_e, InfoExtractor)



# Generated at 2022-06-26 12:52:16.452633
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    http_proxy = None
    https_proxy = None

# Generated at 2022-06-26 12:52:27.542954
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:32.883156
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:35.386912
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    item = TheStarIE()
    TheStarIE._VALID_URL
    TheStarIE._TEST

# Generated at 2022-06-26 12:52:48.234145
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:53.428783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_obj = TheStarIE()
    assert ie_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:53:01.584137
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-26 12:53:02.773968
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-26 12:53:05.123560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception:
        assert False,"constructor failed"
    else:
        assert True


# Generated at 2022-06-26 12:53:10.317177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:15.314090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('www.thestar.com', 'Mankind: Why this woman started a men\'s skin care line', '4732393888001',
                   'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')



# Generated at 2022-06-26 12:53:19.718773
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._TEST['info_dict']['id'] == TheStarIE._TEST['url'].split('/')[-1].split('.')[0]

# Generated at 2022-06-26 12:53:25.267516
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ies = TheStarIE()
    assert ies != None

# Generated at 2022-06-26 12:53:26.541559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:27.705791
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:33.882648
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()
    ie.extract(test_url)

# Generated at 2022-06-26 12:53:40.182625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('thestar.com')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    # This test is for testing the constructor of class TheStarIE
    # with a random url that does not belong to thestar.com.
#    ie = TheStarIE('www.thestar.com')
#    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:41.521162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE({}).BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:53:44.156095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")



# Generated at 2022-06-26 12:53:45.748316
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({"url": "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"})
    result = ie.extract()

# Generated at 2022-06-26 12:53:46.498240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:57.245188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(inst.name == 'TheStarIE')
    assert(inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:54:07.534625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_pure_class = 'TheStar'
    thestar = TheStarIE()
    #print(thestar.params)
    #print(thestar.HLS_URL_TEMPLATE)
    #print(thestar.url)
    #print(thestar.ie_key())

# Generated at 2022-06-26 12:54:08.593511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:11.282118
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-26 12:54:13.600267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE._TEST)


# Generated at 2022-06-26 12:54:18.432771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:20.966707
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert 'TheStarIE' in globals()


# Generated at 2022-06-26 12:54:25.573405
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:28.064850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:54:36.934289
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert thestarie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert thestarie.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'


# Generated at 2022-06-26 12:54:41.648038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:02.647418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('url')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:04.463433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        a = TheStarIE()
        assert False
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-26 12:55:16.444837
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:27.062143
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html?test=test')
    assert ie.match_id('http://www.thestar.com/entertainment/television/2016/02/05/smells-like-team-spirit-for-snl-alum-taran-killam.html')

# Generated at 2022-06-26 12:55:28.217821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == "TheStarIE"

# Generated at 2022-06-26 12:55:31.181031
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("In test_TheStarIE")
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:55:32.644872
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Test constructor of class TheStarIE """
    theStarIE = TheStarIE()



# Generated at 2022-06-26 12:55:33.227404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' not in globals()

# Generated at 2022-06-26 12:55:36.755519
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:44.641659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
                   TheStarIE._download_webpage, "4732393888001")
    assert ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-26 12:56:26.671787
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert(instance._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))
    assert(instance._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').group('id'))
    assert(instance._match_id('http://www.thestar.com/news/gta/2016/02/02/you-didnt-see-that-boldly-tacky-church-signs-are-a-toronto-tradition.html').group('id'))

# Generated at 2022-06-26 12:56:28.510816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test._download_webpage('http://www.google.com', 'toto')
    print('Test: OK')

# Generated at 2022-06-26 12:56:38.052987
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert str(ie) == '<TheStarIE 4732256797001: Mankind: Why this woman started a men\'s skin care line>'
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:56:40.282676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    class_name = test_TheStarIE.__class__.__name__
    assert class_name == 'TheStarIE'


# Generated at 2022-06-26 12:56:44.938630
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Set server URL
    video_url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Instantiate class TheStarIE
    the_star_ie = TheStarIE()
    # Test the return of function _real_extract

# Generated at 2022-06-26 12:56:52.908102
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:53.761063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:55.722241
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  assert(TheStarIE(TheStarIE._TEST['url'], InfoExtractor._downloader) != None )

# Generated at 2022-06-26 12:56:57.109069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE({})
    assert(thestar is not None)



# Generated at 2022-06-26 12:56:59.823114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:58:38.766730
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie


# Generated at 2022-06-26 12:58:40.257290
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:58:44.634003
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj_TheStarIE = TheStarIE()
    expected_value_TheStarIE = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    actual_value_TheStarIE = obj_TheStarIE._VALID_URL
    assert actual_value_TheStarIE == expected_value_TheStarIE


# Generated at 2022-06-26 12:58:55.098136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % "4732393888001", "thestart.com")
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['id'] == '4732393888001'
    assert ie._TEST['ext'] == 'mp4'
    assert ie._TEST['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie._

# Generated at 2022-06-26 12:58:56.304704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('')

# Generated at 2022-06-26 12:59:06.751187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	info_dict = TheStarIE._TEST
	url = info_dict['url']
	md5 = info_dict['md5']
	info_dict = info_dict['info_dict']
	params = info_dict['params']
	ext = info_dict['ext']
	title = info_dict['title']
	description = info_dict['description']
	uploader_id = info_dict['uploader_id']
	timestamp = info_dict['timestamp']
	upload_date = info_dict['upload_date']
	
	info_dict = TheStarIE._TEST
	url = info_dict['url']
	md5 = info_dict['md5']
	info_dict = info_dict['info_dict']
	params = info_dict['params']
	ext = info_dict['ext']

# Generated at 2022-06-26 12:59:07.582584
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:08.803829
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    assert star is not None

# Generated at 2022-06-26 12:59:13.817913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    print("\nExecuting Test for class TheStarIE")
    if video._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html':
        print("Test Constructor of class TheStarIE: Passed")
    else:
        print("Test Constructor of class TheStarIE: Failed")
        

# Generated at 2022-06-26 12:59:22.044280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie == ('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
                  'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
                  '4732393888001')