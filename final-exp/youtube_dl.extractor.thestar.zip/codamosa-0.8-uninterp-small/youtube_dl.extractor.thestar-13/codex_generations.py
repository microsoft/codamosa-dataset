

# Generated at 2022-06-26 12:51:55.327421
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:51:57.236946
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:51:58.411974
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()


# Generated at 2022-06-26 12:51:59.490261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:01.201026
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:01.755281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:04.125468
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:05.731358
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(the_star_i_e_0, TheStarIE)


# Generated at 2022-06-26 12:52:09.361231
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:09.941091
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:52:16.226249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None
    assert ie._TEST is not None
    assert ie._VALID_URL is not None

# Generated at 2022-06-26 12:52:29.175578
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:30.591074
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print(TheStarIE)

# Generated at 2022-06-26 12:52:35.424898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:42.510041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE();
	assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s';
	assert obj.__class__.__name__ == 'TheStarIE';

# Generated at 2022-06-26 12:52:46.527430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:58.349125
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s';
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html';

# Generated at 2022-06-26 12:53:03.159008
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    # Test with Real URL
    url = info_extractor.BRIGHTCOVE_URL_TEMPLATE % '4732393888001'
    assert info_extractor.suitable(url)
    assert info_extractor._download_webpage(url, display_id='4732393888001')
    # Test with Video ID
    url = '4732393888001'
    assert info_extractor.suitable(url)
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE % url == info_extractor._real_extract(url)

# Generated at 2022-06-26 12:53:03.849602
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:08.757396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Unit test for constructor of class TheStarIE")
	assert(TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:53:20.492734
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for constructor of class TheStarIE
    ie = TheStarIE()
    # Ensure that __init__() checks the required attributes
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:25.562011
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:53:26.289136
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:38.679531
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url_test = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	test = TheStarIE()
	assert(test._match_id(url_test) == 'mankind-why-this-woman-started-a-men-s-skincare-line')
	assert(test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
	assert(test._TEST['url'] == url_test)
	assert(test._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')

# Generated at 2022-06-26 12:53:48.939210
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()
    assert tester._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:49.741410
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:53:51.267980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie)

# Generated at 2022-06-26 12:53:57.834086
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:05.985449
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # print( ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732400647001') )
    # print( ie.BRIGHTCOVE_URL_TEMPLATE )
    # # print( ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') )

# Generated at 2022-06-26 12:54:10.167013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:28.872789
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:54:30.423556
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-26 12:54:32.986350
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE();
    assert obj.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:54:35.841892
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:54:46.112209
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

# Generated at 2022-06-26 12:54:55.391025
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == TheStarIE._VALID_URL
    assert ie._TEST == TheStarIE._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._real_extract(ie._TEST['url']) == ie._TEST

# Generated at 2022-06-26 12:55:05.122088
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % "4732393888001")
    assert obj._real_extract('http://www.thestar.com/foo.html') == {
        '_type': 'url_transparent',
        'display_id': 'http://www.thestar.com/foo.html',
        'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'id': '4732393888001',
        'ie_key': 'BrightcoveNew',
    }

# Generated at 2022-06-26 12:55:09.457825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
        Unit test for constructor of class TheStarIE
    '''
    testobj = TheStarIE()
    assert isinstance(testobj, TheStarIE)

# Generated at 2022-06-26 12:55:10.257457
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:13.078704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:55:30.985957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_starIE = TheStarIE()
    assert the_starIE

# Generated at 2022-06-26 12:55:32.952173
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE("Input URL", {"url": "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"})

# Generated at 2022-06-26 12:55:39.366678
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/food_wine/restaurant_reviews/2016/02/01/picks-an-eclectic-city-favourite.html')
    webpage = ie._download_webpage(ie.url, ie.display_id)
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-26 12:55:40.456035
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:55:42.908101
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Quickly tests that TheStarIE outputs the expected format of a single video
    """
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:52.003665
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE_STAR = TheStarIE()
    assert IE_STAR._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:52.832515
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:55.600762
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().extract_url("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:55:57.848430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie !=None 
    


# Generated at 2022-06-26 12:56:00.821069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:56:41.097309
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:56:49.194401
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:50.201554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()

# Generated at 2022-06-26 12:56:51.369996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.url_result()

# Generated at 2022-06-26 12:57:00.029325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  testObj = TheStarIE()
  assert(testObj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:57:04.874853
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"


# Generated at 2022-06-26 12:57:08.932674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Class to test correct instantiation of TheStarIE objects
    """
    from utils import run_test_cases
    from .common import get_testcases
    from .common import test_brightcove_info_dict

    test_cases = get_testcases(__name__, module_name='thestar.com')

# Generated at 2022-06-26 12:57:13.538300
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This test is used to verify the class TheStarIE is constructed properly
    # initialize an instance of class TheStarIE
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:20.508277
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ != '__main__':
        return
    host = 'www.thestar.com'
    path = '/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    url = 'http://' + host + path
    br = Browser()
    br.open(url)
    url = br.geturl();
    assert url.startswith('http://')
    assert host in url, url
    assert path in url, url
    print('url: ', url)
    #print('read: ', br.read())
    print('title: ', br.title())

# Generated at 2022-06-26 12:57:28.107109
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Init a instance for class TheStarIE
    theStarIE = TheStarIE()
    # Get test information about TheStarIE
    testInfo = theStarIE._TEST
    # Test for class TheStarIE

# Generated at 2022-06-26 12:59:06.473972
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    # Test if URL matches the required one
    assert x._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # Test the test property
    assert x._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert x._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert x._TEST['info_dict']['id'] == '4732393888001'
    assert x._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:59:10.705212
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ConstructorTest(
        TheStarIE,
        [
            "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",
        ],
        {"skippable": True},
        False,
        False,
    )

# Generated at 2022-06-26 12:59:15.548429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = InfoExtractor()
    info_extractor.get_info('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:59:18.791364
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for TheStarIE constructor
    test_TheStarIE = TheStarIE()
    # Assert isinstance of TheStarIE
    assert isinstance(test_TheStarIE, TheStarIE)

# Generated at 2022-06-26 12:59:20.724465
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance = TheStarIE(info_dict={})


# Generated at 2022-06-26 12:59:29.526778
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'TheStarIE')
    assert theStarIE.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert theStarIE.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert theStarIE.id == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-26 12:59:38.856362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  class_ = TheStarIE
  res = class_(object()).BRIGHTCOVE_URL_TEMPLATE
  assert res == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Print some unit test for class TheStarIE

# Generated at 2022-06-26 12:59:41.320889
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:59:49.136467
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test the constructor of class TheStarIE."""

    # Construct an instance of TheStarIE
    the_star_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

    # Test whether the instance's url_result() method
    # returns the expected result.
    expected_result = the_star_ie.url_result("http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001",
                                             "BrightcoveNew", "4732393888001")

# Generated at 2022-06-26 12:59:54.126293
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from youtube_dl.utils import DateRange
    TheStarIE(downloader=None)._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')
    TheStarIE(downloader=None)._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001', query={'range': DateRange(None, None)})