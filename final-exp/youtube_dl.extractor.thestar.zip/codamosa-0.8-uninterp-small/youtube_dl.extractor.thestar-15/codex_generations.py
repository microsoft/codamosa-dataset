

# Generated at 2022-06-26 12:51:55.483081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE() # On creation of a class -> assert isinstance(the_star_i_e, TheStarIE)
    # On construction of a class using the testcase -> assert isinstance(the_star_i_e_0, TheStarIE)


# Generated at 2022-06-26 12:51:56.876272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_p = test_case_0()
    assert the_star_p != None


# Generated at 2022-06-26 12:51:58.305717
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    testcase1 = TheStarIE()

test_case_0()
test_TheStarIE()

# Generated at 2022-06-26 12:52:01.582355
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        the_star_i_e_0 = TheStarIE()
    except:
        print("Constructor for class TheStarIE is failed")
    else:
        print("Constructor for class TheStarIE is passed")


# Generated at 2022-06-26 12:52:12.714211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Running unit test for constructor of class TheStarIE")
    the_star_i_e_0 = TheStarIE()
    the_star_i_e_1 = TheStarIE()
    assert(the_star_i_e_0._downloader.params['forceurl'] is False)
    assert(the_star_i_e_0._downloader.params['forcetitle'] is False)
    assert(the_star_i_e_0._downloader.params['forcethumbnail'] is False)
    assert(the_star_i_e_0._downloader.params['forcedescription'] is False)
    assert(the_star_i_e_0._downloader.params['forcefilename'] is False)

# Generated at 2022-06-26 12:52:13.684800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:15.998111
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

if __name__ == "__main__":
    test_case_0()
    test_TheStarIE()

# Generated at 2022-06-26 12:52:18.162854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    new_object = TheStarIE()

# Generated at 2022-06-26 12:52:19.160868
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:20.581437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert not TheStarIE()

# Generated at 2022-06-26 12:52:31.782287
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:35.414643
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:40.140912
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

	# Test instantiation of TheStarIE class
	obj_thestareie = TheStarIE()
	assert obj_thestareie != None



# Generated at 2022-06-26 12:52:49.534790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    info_extractor.BRIGHTCOVE_URL_TEMPLATE
    info_extractor._VALID_URL
    info_extractor._TEST
    info_extractor._download_webpage('http://www.thestar.com/entertainment/music/2016/02/01/the-star-gets-a-first-listen-to-david-bowies-latest-album-blackstar.html', 'thestar')
    info_extractor._download_webpage('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'thestar')

# Generated at 2022-06-26 12:52:59.523852
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:09.763146
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Unit test for TheStarIE._real_extract
    assert isinstance(ie, InfoExtractor)

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE.startswith('http')
    assert ie.BRIGHTCOVE_URL_TEMPLATE.endswith('html?videoId=%s')

# Generated at 2022-06-26 12:53:17.553577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-26 12:53:22.794925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:53:24.195598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x is not None

# Generated at 2022-06-26 12:53:26.664442
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie is not None


# Generated at 2022-06-26 12:53:39.100696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE({})
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:40.154378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert isinstance(thestar_ie, TheStarIE)


# Generated at 2022-06-26 12:53:43.659391
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE()
    test_obj.br
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:53:47.240895
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert thestar_ie


# Generated at 2022-06-26 12:53:48.809385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__init__()

# Generated at 2022-06-26 12:53:54.773697
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE(TheStarIE.suitable(url))

# Generated at 2022-06-26 12:53:58.776542
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # Test url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Test validity of URL
    ie.suitable(url)
    # Test extract method
    ie.extract(url)

# Generated at 2022-06-26 12:54:08.299441
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ConStarIE = TheStarIE(1)
    assert ConStarIE.title == "Toronto Star Video"
    assert ConStarIE.br == "794267642001"
    assert ConStarIE.page_info == "http://players.brightcove.net/794267642001/default_default/index.html?videoId="
    assert ConStarIE.url == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    assert ConStarIE.ext == "mp4"
    assert ConStarIE.uploader == "Toronto Star"
    assert ConStarIE.uploader_id == "794267642001"
    assert ConStarIE.upload_date == "20160201"
    assert ConStarIE.duration == 231
    assert ConStarIE.tim

# Generated at 2022-06-26 12:54:13.526226
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    if ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s':
        print ("Pass")

# Generated at 2022-06-26 12:54:17.582638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test
	ie = TheStarIE()

	# This function is used to test the extractor,
	# and will not be called when the tests are run.
	ie.test('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:37.188621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #define an instance
    test_instance = TheStarIE()
    
    assert test_instance._downloader == None

    # test the class attribute of the instance
    assert test_instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:54:38.016490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print("Testing TheStarIE")
	TheStarIE()
	print("Passed TheStarIE")

# Generated at 2022-06-26 12:54:46.414630
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TestIE = type('TestIE', (TheStarIE,), {'_download_webpage': lambda self, *args: '<br>mainartBrightcoveVideoId :"%s"<br>' % args[1]})
    ie = TestIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').url

# Generated at 2022-06-26 12:54:48.148943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert test

# Generated at 2022-06-26 12:54:55.122561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    instance._match_id('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    instance._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:55:05.057081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # 1. Test for valid Brightcove URL
    test_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    test_url_ie = TheStarIE(None)
    result = test_url_ie.suitable(test_url)
    assert result == True
    # 2. Test for invalid URL
    test_url = 'http://www.thestar.com/video_index.html'
    test_url_ie = TheStarIE(None)
    result = test_url_ie.suitable(test_url)
    assert result == False

# Generated at 2022-06-26 12:55:16.629965
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test URL # 1
    url = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    test_TheStarIE._TEST['url'] = url
    # Actual URL of the webpage
    webpage_url = ('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Expected URL of the webpage
    expect_webpage_url = (test_TheStarIE._TEST['url'])
    assert(expect_webpage_url == webpage_url)
    # Actual url_result
    url_result = (test_TheStarIE._VALID_URL)
   

# Generated at 2022-06-26 12:55:27.262171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:55:30.279227
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    return ie.extractor_key

# Generated at 2022-06-26 12:55:32.251699
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:55:59.802315
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE()._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'


# Generated at 2022-06-26 12:56:00.324414
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:56:02.987684
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:56:12.881651
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:13.419886
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-26 12:56:16.674825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    s = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(str(s) == "<class '__main__.TheStarIE'>")

# Generated at 2022-06-26 12:56:23.639854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test by a url which has an unique id in The Star
    url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie._download_webpage = lambda x, y: "mainartBrightcoveVideoId\" : \"4732393888001\""

    ie._real_extract(url)
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._real_extract(url)

# Generated at 2022-06-26 12:56:32.374108
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:56:36.574256
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('','')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    module = 'youtube_dl.extractor.thestar'
    assert module == ie.module

# Generated at 2022-06-26 12:56:38.125013
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.constructor()


# Generated at 2022-06-26 12:57:28.426199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of TheStarIE"""
    # Testing sample url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Create instance
    inst = TheStarIE()
    # Test for the parameters of constructor
    assert inst.VALID_URL_TEMPLATES == [
        'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html']
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:34.136642
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert theStarIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:57:34.929502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._real_extract()

# Generated at 2022-06-26 12:57:36.793675
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:37.133907
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:37.992282
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_class = TheStarIE()
    test_class_instance = test_class(test_class)

# Generated at 2022-06-26 12:57:43.723217
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    if __name__ == '__main__':
        print("Unit test for constructor of class TheStarIE")
        thestar_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "TheStarIE")
        print("Expected result: http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001")
        print("Actual result: " + thestar_ie.BRIGHTCOVE_URL_TEMPLATE % thestar_ie._match_id(thestar_ie._VALID_URL))

# Generated at 2022-06-26 12:57:44.801713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test reading the class name from the module
    assert TheStarIE.ie_key() == 'TheStar', 'TheStarIE class name lookup failed'

# Generated at 2022-06-26 12:57:48.647897
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    This function test the constructor of TheStarIE class
    """
    # Set the params for extractor
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

    # Get the instance of TheStarIE
    TheStar_ie = TheStarIE()
    print(TheStar_ie)

    print(TheStar_ie.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-26 12:57:51.840468
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:59:15.033191
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:59:15.851596
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #Nothing to be done
    pass

# Generated at 2022-06-26 12:59:16.965061
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__ == TheStarIE

# Generated at 2022-06-26 12:59:19.009482
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert isinstance(x, InfoExtractor)

# Generated at 2022-06-26 12:59:23.186631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert (
    TheStarIE(
        TheStarIE.extract_info(),
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE(),
        TheStarIE.extract_info(),
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE()
        )
    )

# Generated at 2022-06-26 12:59:32.060952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:32.600175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  TheStarIE()

# Generated at 2022-06-26 12:59:33.977009
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_obj = TheStarIE()
    pass

# Generated at 2022-06-26 12:59:35.342680
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE('TheStarIE', 'BrightcoveNew')

# Generated at 2022-06-26 12:59:36.307710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
