

# Generated at 2022-06-26 12:51:53.428864
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Constructor test case 1
#     the_star_i_e = TheStarIE()
    pass



# Generated at 2022-06-26 12:51:54.367506
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0


# Generated at 2022-06-26 12:51:55.419537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return "ok"

#Test on extracting VideoId from the Brightcove Page

# Generated at 2022-06-26 12:52:04.174768
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return_value_0 = isinstance(test_case_0(), TheStarIE)
    assert return_value_0
    return_value_1 = TheStarIE()._VALID_URL
    return_value_2 = TheStarIE().BRIGHTCOVE_URL_TEMPLATE
    return_value_3 = TheStarIE()._TEST
    return_value_4 = TheStarIE()._download_webpage
    return_value_5 = TheStarIE()._real_extract
    return_value_6 = TheStarIE()._match_id
    return_value_7 = TheStarIE()._search_regex
    return_value_8 = TheStarIE()._extract_url

# Generated at 2022-06-26 12:52:05.435866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:15.520845
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    brightcove_id = '4732393888001'

# Generated at 2022-06-26 12:52:18.238235
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0 != None

# Generated at 2022-06-26 12:52:30.359582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:31.728676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
     the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:40.050816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url_0 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star_i_e = TheStarIE()
    assert the_star_i_e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert not the_star_i_e._match_id(url_0)
    assert the_star_i_e.ie_key() == 'TheStar'
    assert the_star_i_e.ie_key() in the_star_i_e.SUITABLE_DEFAULT
    assert the_star_i_e.BRIGH

# Generated at 2022-06-26 12:52:42.989112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test if instance of class TheStarIE can be constructed
    ie = TheStarIE()

# Generated at 2022-06-26 12:52:44.971810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_TheStarIE=TheStarIE()
    print ("Testing start")
    assert class_TheStarIE != None

# Generated at 2022-06-26 12:52:48.685758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'Ad')

# Generated at 2022-06-26 12:52:52.136904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('"')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:52.638554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:05.004267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    info_dict_ = {'id': '4732393888001'}
    title_ = 'Mankind: Why this woman started a men\'s skin care line'
    uploader_id_ = '794267642001'
    upload_date_ = '20160201'
    timestamp_ = 1454353482
    description_ = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    url_ = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    kwargs = None
    video_ = class_(kwargs, url_)
    video_.extract()
    eq_('4732393888001', video_.id)
   

# Generated at 2022-06-26 12:53:06.974909
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('4732393888001')

# Generated at 2022-06-26 12:53:10.451279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:15.601439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.display_id == "mankind-why-this-woman-started-a-men-s-skincare-line"
    

# Generated at 2022-06-26 12:53:18.733650
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE)
    assert ie != None

# Generated at 2022-06-26 12:53:28.572434
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:39.441032
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(TheStarIE()._extract_brightcove_url(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')
    assert(TheStarIE()._extract_brightcove_url(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
        == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')
   

# Generated at 2022-06-26 12:53:43.028577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	sample_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	url_object = TheStarIE()
	result = url_object._real_extract(sample_url)
	assert(result.find('4732393888001')>-1)

# Generated at 2022-06-26 12:53:44.439888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()

# Generated at 2022-06-26 12:53:50.410733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    e = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(e.name == 'Mankind: Why this woman started a men\'s skin care line')
    assert(e._TEST['url'] == e.url)
    assert(e._TEST['md5'] == e.md5)
    assert(e._TEST['info_dict']['title'] == e.title)
    assert(e._TEST['info_dict']['uploader_id'] == e.uploader_id)
    assert(e._TEST['info_dict']['id'] == e.id)

# Generated at 2022-06-26 12:53:52.742112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-26 12:53:56.340895
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:54:01.418437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:06.801188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE = TheStarIE()
    assert TheStarIE.brightcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE.valid_urls == [r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html']

# Generated at 2022-06-26 12:54:18.432810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    class_TheStarIE = TheStarIE()

# Generated at 2022-06-26 12:54:30.626189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:33.710676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE(None)

if __name__ == '__main__':
    from tests import run_main
    run_main(__name__)

# Generated at 2022-06-26 12:54:35.054634
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.match()
    assert ie.validate()

# Generated at 2022-06-26 12:54:36.313562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # A basic test
    TheStarIE()

# Generated at 2022-06-26 12:54:43.936215
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with valid url
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Test without valid url
    try:
        # Test without valid url
        TheStarIE(url=None)
    except AssertionError:
        pass  # Success

# Test if TheStarIE raise an error if it receive a non valid url 

# Generated at 2022-06-26 12:54:52.165824
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Constructor test for class TheStarIE"""
    thestar_ie = TheStarIE()
    assert '<iframe src="http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"' in thestar_ie._download_webpage(thestar_ie._TEST['url'], thestar_ie._TEST['info_dict']['id'])

# Generated at 2022-06-26 12:54:53.235240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:54:55.751676
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-26 12:54:56.948392
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  result = TheStarIE()


# Generated at 2022-06-26 12:55:01.799395
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert test._TEST == TheStarIE._TEST
    assert test.BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:55:19.268621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'))

# Generated at 2022-06-26 12:55:21.278844
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _obj = TheStarIE(None)
    assert isinstance(_obj, TheStarIE)

# Generated at 2022-06-26 12:55:28.179657
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    try:
        ie.get_url_for_video('4728216573001')
        assert(False)
    except:
        assert(True)

    try:
        assert(ie.get_url_for_video('4732393888001') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-26 12:55:36.028558
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert ie.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	assert ie.id == '4732393888001'
	assert ie.ext == 'mp4'
	assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
	assert ie.description == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
	assert ie.uploader_id == '794267642001'
	assert ie.timestamp == 1454

# Generated at 2022-06-26 12:55:39.263154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:42.211619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:43.259775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Constructor
    TheStarIE()


# Generated at 2022-06-26 12:55:47.545871
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # A simple test of value of the _TEST dictionary
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    actual = TheStarIE()._TEST['url']
    assert expected == actual


# Generated at 2022-06-26 12:55:51.928560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:53.768070
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("https://www.youtube.com/watch?v=00iOoOzSUSQ")
    print(ie)

# Generated at 2022-06-26 12:56:35.355511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    search_regex = getattr(TheStarIE, '_search_regex')
    match_id = getattr(TheStarIE, '_match_id')
    download_webpage = getattr(TheStarIE, '_download_webpage')


# Generated at 2022-06-26 12:56:39.417841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video = TheStarIE()
    video.brightcove_id = '4732393888001'
    video.url_result(video.BRIGHTCOVE_URL_TEMPLATE % video.brightcove_id, 'BrightcoveNew', video.brightcove_id)

# Generated at 2022-06-26 12:56:47.420764
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("TheStarIE","http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html",{"md5":"2c62dd4db2027e35579fefb97a8b6554","ext":"mp4","title":"Mankind: Why this woman started a men's skin care line","description":"Robert Cribb talks to Young Lee, the founder of Uncle Peter's MAN.","uploader_id":"794267642001","timestamp":1454353482,"upload_date":"20160201"},"4732393888001")
    assert ie.result["url"] == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001" 
    assert ie

# Generated at 2022-06-26 12:56:48.321175
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert thestar

# Generated at 2022-06-26 12:56:56.791954
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest
    class TheStarIETest(unittest.TestCase):
        def testConstructor(self):
            ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
            self.assertEqual(ie._VALID_URL, 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:56:59.262773
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # get an instance of the class
    myObj = TheStarIE()
    assert myObj  # is an object
    assert isinstance(myObj, InfoExtractor)  # is of type InfoExtractor

# Generated at 2022-06-26 12:57:00.083759
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:01.767359
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test to see if constructor is able to create an object instance.
    test_obj = TheStarIE()

# Generated at 2022-06-26 12:57:05.805155
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = InfoExtractor()
    i.add_info_extractor(TheStarIE)
    url = 'https://www.youtube.com/watch?v=Yn00Rw8_cPQ'
    extractor = i.IE_resolve(url)
    expected = 'youtube'
    actual = extractor.IE_NAME
    assert actual == expected



# Generated at 2022-06-26 12:57:06.995469
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Unit test for constructor of class TheStarIE
	"""
	constructor = TheStarIE(20)
	assert constructor == 20


# Generated at 2022-06-26 12:58:42.593800
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:58:45.799816
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  info_extractor = TheStarIE()
  assert (info_extractor.constructor.__name__ == TheStarIE.__name__)

# Generated at 2022-06-26 12:58:55.429497
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert info_extractor._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert info_extractor._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert info_extractor._TEST['info_dict']['id'] == '4732393888001'

# Generated at 2022-06-26 12:59:06.233838
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor)._VALID_URL == ['http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html']
    assert TheStarIE(InfoExtractor).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:08.614911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:59:15.270856
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_imports import make_test_url
    URL = make_test_url('brightcove:%s' % str('Mankind: Why this woman started a men\'s skin care line'))
    ie = TheStarIE(URL)
    assert ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
                        'BrightcoveNew', '4732393888001')

# Generated at 2022-06-26 12:59:25.676408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    video = ie.extract(url)
    assert video.get('url') == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert video.get('title') == 'Mankind: Why this woman started a men\'s skin care line'
    assert video.get('description') == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert video.get('id') == '4732393888001'
    assert video.get('ext') == 'mp4'

# Generated at 2022-06-26 12:59:34.721659
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie._TEST['info_dict']['id'] == '4732393888001'
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:59:40.144430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    

# Generated at 2022-06-26 12:59:42.639917
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	class_instance = TheStarIE()
	assert class_instance._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'