

# Generated at 2022-06-26 12:52:05.056991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    display_id_0 = '4732393888001'
    url_0 = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star_i_e_0 = TheStarIE(display_id=display_id_0, url=url_0)
    brightcove_url_0 = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    result_0 = the_star_i_e_0.url_result(brightcove_url_0, 'BrightcoveNew', display_id_0)
    assert '4732393888001' == result_0['id']

# Unit

# Generated at 2022-06-26 12:52:07.370047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
    assert the_star_i_e_0 is not None


# Generated at 2022-06-26 12:52:08.287238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass


# Generated at 2022-06-26 12:52:13.360713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Unit test for TheStarIE class\n")
    # Test for case where no url argument is passed
    try:
        the_star_i_e_0 = TheStarIE()
        print("Unit test success\n")
    except TypeError as e:
        print("Unit test failed\n")
        print("Raised: " + str(e))


# Generated at 2022-06-26 12:52:16.879906
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        the_star_i_e_0 = TheStarIE()
        the_star_i_e_0 = TheStarIE(the_star_i_e_0)
    except:
        print("Error creating object of class TheStarIE")
        return 1


# Generated at 2022-06-26 12:52:29.338828
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0._VALID_URL
    assert 'thestar.com' in the_star_i_e_0._VALID_URL

# Generated at 2022-06-26 12:52:35.350707
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-26 12:52:46.078822
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
    assert the_star_i_e_0._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert the_star_i_e_0.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:52:47.967482
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return test_case_0()


# Generated at 2022-06-26 12:52:51.063725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e is not None


# Generated at 2022-06-26 12:52:53.975122
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:53:01.797200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:11.176960
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:17.923402
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._downloader = 'downloader'
    ie._download = 'downloader_down'
    ie._match_id = 'match_id'
    ie._real_extract = 'real_extract_f'
    ie._search_regex = 'search_regex_f'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'bc'
    ie.url_result = 'url_result'
    ie._download_webpage = 'webpage'
    unit_test(ie, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', '4732393888001')

# Generated at 2022-06-26 12:53:24.746448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    variables = (
        'BRIGHTCOVE_URL_TEMPLATE',
        '_VALID_URL',
        'IE_DESC',
        'IE_NAME',
    )
    for v in variables:
        assert getattr(TheStarIE, v, None) is not None, 'Must define %s class attribute' % v

# Generated at 2022-06-26 12:53:29.982263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE("TheStar", "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("Test : Success")

# Generated at 2022-06-26 12:53:35.534642
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)
    obj._match_id(None)
    obj._search_regex(None, None, None)
    obj._real_extract(None)

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-26 12:53:42.754236
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t = TheStarIE();
	t._match_id('');
	t._download_webpage('');
	t._search_regex(r'mainartBrightcoveVideoId', '', 'brightcove id');
	t.url_result('');
	t._real_extract('');

# Generated at 2022-06-26 12:53:44.720974
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    run_test(TheStarIE, TheStarIE._TEST)

# Generated at 2022-06-26 12:53:46.287789
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Ensure that constructor doesn't throw an exception
    try:
        TheStarIE()
    except Exception:
        assert False

# Generated at 2022-06-26 12:53:50.825264
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-26 12:53:53.717667
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	IE = TheStarIE()

if __name__ == '__main__':
	test_TheStarIE()

# Generated at 2022-06-26 12:53:58.576172
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_TheStarIE = TheStarIE()
    if (test_TheStarIE.suitable(url) == True):
        print('pass')
    else:
        print('fail')


# Generated at 2022-06-26 12:54:05.599393
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:06.381915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-26 12:54:10.032609
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:14.800306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance.BRIGHTCOVE_URL_TEMPLATE, basestring)
    assert '%s' in instance.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:54:15.362252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:18.858249
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.get_login_form() is None
    assert ie.get_login_info() is None
    assert ie.get_login_method() is None

# Generated at 2022-06-26 12:54:20.825471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-26 12:54:39.134703
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:43.628341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE.IE._download_webpage = lambda self, url, display_id: '{}'
    BrightcoveNewIE.extract('http://players.brightcove.net/794267642001/default_default/index.html?videoId=123456')

# Generated at 2022-06-26 12:54:44.889883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()


# Generated at 2022-06-26 12:54:51.517450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    regex = r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'
    webpage = '<html><body></body></html>'
    assert InfoExtractor._search_regex(regex, webpage, 'brightcove id') == None, 'OK'

# Generated at 2022-06-26 12:54:57.073050
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	thestarchannel = TheStarIE(url)
	assert thestarchannel.get_url() == url
	return thestarchannel

# Unit test to check the case that the URL requested is not available

# Generated at 2022-06-26 12:55:06.949448
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

    assert instance.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert instance.suitable('http://www.thestar.com/news/gta/2016/02/01/canada-post-cancels-all-remaining-home-delivery-by-2019.html')
    assert instance.suitable('http://www.thestar.com/news/gta/2016/02/01/onto-expects-record-ridership-on-first-weekend-of-february.html')

# Generated at 2022-06-26 12:55:09.543631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that TheStarIE instance is created
    TheStarIE()

# Generated at 2022-06-26 12:55:14.947861
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(
        TheStarIE._downloader,
        TheStarIE,
        TheStarIE._match_id,
        TheStarIE._download_webpage,
        TheStarIE._search_regex,
        TheStarIE.BRIGHTCOVE_URL_TEMPLATE,
        TheStarIE.url_result
    )

# Generated at 2022-06-26 12:55:24.664628
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:34.165162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    This unit test checks the constructor of class TheStarIE
    """
    # Input: sample url for TheStarIE
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    ie = TheStarIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', \
    "ie._VALID_URL should equal r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'"

# Generated at 2022-06-26 12:56:02.684663
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_ie = TheStarIE("https://www.thestar.com/business/2016/02/02/trump-clinging-to-nh-win-as-voters-head-south-to-weigh-in.html")
    assert test_ie.get_BRIGHTCOVE_URL_TEMPLATE() == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert test_ie.get_VALID_URL() == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:07.495078
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test cases for different URLs.
    TheStarIE()._extract_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE()._extract_url('http://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE()._extract_url('http://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html/')

# Generated at 2022-06-26 12:56:13.077804
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    inst = TheStarIE(url)
    assert inst.display_id == 'mankind-why-this-woman-started-a-men-s-skincare-line'
    assert inst.url == url

# Generated at 2022-06-26 12:56:13.932302
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE("unit test")

# Generated at 2022-06-26 12:56:15.248528
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global thestar
    thestar = TheStarIE(InfoExtractor)



# Generated at 2022-06-26 12:56:16.756200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    return the_star_ie


# Generated at 2022-06-26 12:56:20.036219
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:56:21.939203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from unit.test_ie_utils import get_testcases
    TheStarIE()._download_webpage()
    TheStarIE()._match_id()
    TheStarIE()._real_extract()

# Generated at 2022-06-26 12:56:25.295878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	instance = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert instance._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	assert instance._search_regex

# Generated at 2022-06-26 12:56:25.747258
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-26 12:57:08.233927
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj = TheStarIE()
	obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:57:11.769127
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test constructing a BrightcoveId object
    obj = TheStarIE()
    assert isinstance(obj, object)
    assert(obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:57:13.190189
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = InfoExtractor()

# Generated at 2022-06-26 12:57:14.025751
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	yt_ie = TheStarIE()

# Generated at 2022-06-26 12:57:15.054146
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t


# Generated at 2022-06-26 12:57:15.581642
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:18.423991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

test_TheStarIE()

# Generated at 2022-06-26 12:57:23.679545
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    failing_absolute_url = 'http://www.thestar.com/content/thestar/news/world/2016/02/13/how-the-star-came-to-possess-the-dying-moments-of-claudia-wiederhold.html'
    assert TheStarIE()._match_id(failing_absolute_url) is None
    assert_raises(AssertionError, TheStarIE()._match_id, 'invalid')

# Generated at 2022-06-26 12:57:30.537131
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Brightcove video ID
    video_id = "4732393888001"
    # URL of video page
    webpage_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # URL of brightcove player
    brightcove_url = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001"
    # Formatted URL for unit test
    formatted_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincove-line.html"

    # Unit test for extraction

# Generated at 2022-06-26 12:57:31.770016
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception:
        raise AssertionError('Failed to build TheStarIE.')

# Generated at 2022-06-26 12:58:59.512318
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-26 12:59:02.432625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    try:
        ie.get_IEByURL('')
        ie.get_info_extractor('')
    except:
        assert False

# Generated at 2022-06-26 12:59:08.187295
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import unittest2
    from youtube_dl.utils import ExtractorError

    class TestTheStarIE(unittest2.TestCase):
        def testWrongURL(self):
            self.assertRaises(ExtractorError,
                TheStarIE._match_id,
                'http://www.thestar.com/business/2016/01/19/bookstore-owners-say-they-are-not-ready-for-kobo-merger.html')

    unittest2.main()

# Generated at 2022-06-26 12:59:10.606452
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj_TheStarIE = TheStarIE()
    obj_TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    obj_TheStarIE._VALID_URL
    obj_TheStarIE._TEST

# Generated at 2022-06-26 12:59:15.428076
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE('TheStar')
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:25.848030
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  def assertEqual(a, b):
    return (a == b)
  def assertIsInstance(a, b):
    return isinstance(a, b)
  def assertRaises(a, b, c):
    try:
      a(b, c)

    except Exception as e:
      return e

  thestar_ie = TheStarIE()

  assertIsInstance(thestar_ie, TheStarIE)
  assertEqual(thestar_ie._VALID_URL, r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:59:34.871619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    site = TheStarIE({})
    assert TheStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:43.354569
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE('')
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:44.364485
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)


# Generated at 2022-06-26 12:59:46.512645
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert (result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')