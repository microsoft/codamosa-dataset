

# Generated at 2022-06-26 12:51:58.300937
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# self.assertTrue()


# Generated at 2022-06-26 12:52:04.081463
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e.BRIGHTCOVE_URL_TEMPLATE
    assert the_star_i_e._VALID_URL
    assert the_star_i_e._TEST
    assert the_star_i_e.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:52:14.173809
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:17.223888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert the_star_i_e_0.suitable(url) is True

# Generated at 2022-06-26 12:52:20.652378
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_the_star_i_e = TheStarIE()
    print('test_TheStarIE')


# Generated at 2022-06-26 12:52:22.944990
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:24.871242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:52:26.540865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:27.787251
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:37.753899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(the_star_i_e_0.brightcove_id == brightcove_id)
    assert(the_star_i_e_0.display_id == display_id)
    assert(the_star_i_e_0.ext == ext)
    assert(the_star_i_e_0.id == id)
    assert(the_star_i_e_0.url == url)
    assert(the_star_i_e_0.uploader_id == uploader_id)
    assert(the_star_i_e_0.title == title)
    assert(the_star_i_e_0.upload_date == upload_date)


# Generated at 2022-06-26 12:52:49.444187
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    cobj = TheStarIE()
    assert cobj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:51.332063
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE('/','/')
    assert test is not None

# Generated at 2022-06-26 12:52:53.226797
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie) is TheStarIE

# Generated at 2022-06-26 12:52:55.121572
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # assert that TheStarIE is an instance of InfoExtractor
    TheStarIE()

# Generated at 2022-06-26 12:52:55.594344
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:53:02.324470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie
    assert ie._VALID_URL
    assert ie._TEST
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# A unit test for the _real_extract(url) method
# We can't really test the output, so we simply test that the method works correctly

# Generated at 2022-06-26 12:53:08.891697
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.brigthcove_url_template == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-26 12:53:13.171442
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Test Results
	u = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	test_object = TheStarIE(u)
	assert isinstance(test_object, TheStarIE)
	assert test_object.name() == "thestar"
	assert test_object.domain() == "thestar.com"

# Generated at 2022-06-26 12:53:18.024261
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for TheStarIE."""
    ie = TheStarIE.TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-26 12:53:19.583537
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj

# Generated at 2022-06-26 12:53:26.023882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:34.207606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.params['m3u8_id'] = 'm3u8'
    ie.params['m3u8'] = 'm3u8'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:34.997180
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:37.792739
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:53:43.296825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    valid_url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

    ie = (TheStarIE(url) is TheStarIE(valid_url))
    ie = True
    #ie = (TheStarIE(url) is TheStarIE(valid_url))
    if ie:
        print("TheStarIE: equal urls")

    #print(TheStarIE(url)._real_extract(TheStarIE(url)))
    #TheStarIE(url).download_video_by_vid(473

# Generated at 2022-06-26 12:53:48.617242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	brightcove_id = "4732393888001"
	assert TheStarIE._search_regex(
            r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
            url, 'brightcove id') == brightcove_id

# Generated at 2022-06-26 12:53:53.943502
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:58.159213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class MockClass(object):
        pass

    # Args parsed
    mock_args = MockClass()
    mock_args.password = 'toto'
    mock_args.username = 'toto'
    ie = TheStarIE(mock_args)

    # Args not parsed
    ie = TheStarIE(False)

# Generated at 2022-06-26 12:54:02.897538
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:05.501229
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE
    possbile_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert possbile_url in ie._VALID_URL
    assert ie != None

# Generated at 2022-06-26 12:54:18.788048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_pattern = r'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    thestarie = TheStarIE(test_pattern)

    assert thestarie.url == test_pattern
    assert thestarie.video_id == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' 



# Generated at 2022-06-26 12:54:28.485897
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from checksum import md5
    thestar = TheStarIE()
    thestar._download_webpage = lambda url, display_id: '''
<html>
<script>
    mainartBrightcoveVideoId = "12345";
</script>
</html>'''
    info_dict = thestar._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info_dict['id'] == '12345'
    assert info_dict['url'] == thestar.BRIGHTCOVE_URL_TEMPLATE % info_dict['id']

# Generated at 2022-06-26 12:54:33.584169
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:39.658967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == "TheStarIE"
    assert TheStarIE.__doc__ == "Toronto Star articles and videos"
    assert TheStarIE.BROWSER_PARAMS.keys() == {'headers'}
    assert TheStarIE.BROWSER.__class__.__name__ == "FakeHeadersBrowser"
    assert TheStarIE._BRIGHT_COVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"


# Generated at 2022-06-26 12:54:40.358432
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    assert True

# Generated at 2022-06-26 12:54:42.646233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().match('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:43.525264
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test.test()

# Generated at 2022-06-26 12:54:55.721253
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    def video_extractor_testing_factory(extractor_class, expected_video_id, expected_provider):
        def test_valid_video(extractor_class, expected_video_id, expected_provider):
            if not isinstance(expected_video_id, str):
                expected_video_id, expected_provider = expected_video_id

            if extractor_class == 'BrightcoveNew':
                url = TheStarIE.BRIGHTCOVE_URL_TEMPLATE % expected_video_id
            else:
                raise ValueError("Unknown %s extractor" % extractor_class)

            extractor = TheStarIE()
            video_info = extractor.extract(url)
            assert video_info is not None
            assert video_info['id'] == expected_video_id
            assert video

# Generated at 2022-06-26 12:55:00.498859
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-26 12:55:01.943304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie

# Generated at 2022-06-26 12:55:17.022044
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:18.178119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert True 


# Generated at 2022-06-26 12:55:23.151638
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.title == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.uploader_id == '794267642001'

# Generated at 2022-06-26 12:55:24.584128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("https://www.google.com/search?q=python")

# Generated at 2022-06-26 12:55:34.097048
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:42.544969
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''Unit test for constructor of class TheStarIE'''
    obj = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:55:43.620707
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('')

# Generated at 2022-06-26 12:55:52.297168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST is not None
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None

# test for object TheStarIE
test_TheStarIE()

# Generated at 2022-06-26 12:55:57.449228
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Simple test for class TheStarIE
    """
    ie = TheStarIE()
    test = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    print(test)

# Generated at 2022-06-26 12:55:58.334304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert isinstance(TheStarIE, InfoExtractor)

# Generated at 2022-06-26 12:56:33.568806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:34.038497
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:56:38.017095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test for public function
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:56:41.292915
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert(info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(info_extractor.service_name == 'TheStar')

# Generated at 2022-06-26 12:56:42.395847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:44.538127
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').get_from_url()

# Generated at 2022-06-26 12:56:52.483454
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-26 12:56:56.285707
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._real_extract(TheStarIE._TEST['url'])
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:57:02.938107
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    print(instance._TEST)
    assert 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001' == instance._TEST['url']
    assert 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html' == instance._TEST['url']
    assert '2c62dd4db2027e35579fefb97a8b6554' == instance._TEST['md5']

# Generated at 2022-06-26 12:57:05.390156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Create an instance of TheStarIE class
    the_Star_IE = TheStarIE()

    # Verify that we are constructing the correct object
    assert the_Star_IE.ie_key() == "thestar"

# Generated at 2022-06-26 12:58:38.427168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})
    assert isinstance(instance, TheStarIE)

# Generated at 2022-06-26 12:58:39.327222
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert True

# Generated at 2022-06-26 12:58:42.942357
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:58:52.005327
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
test_TheStarIE()

# Generated at 2022-06-26 12:58:57.646271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    my_object = TheStarIE("My_Extractor_Name", "My_Extractor_Description", "My_Extractor_IE_Key",
                          "My_Extractor_URL_RE", "My_Extractor_Title", "My_Extractor_Thumbnail")


# Generated at 2022-06-26 12:59:05.409605
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    result = ie._real_extract(url)
    assert result.get('id') == '4732393888001'
    assert result.get('title') == 'Mankind: Why this woman started a men\'s skin care line'
    assert result.get('description') == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-26 12:59:06.273433
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)

# Generated at 2022-06-26 12:59:16.545710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:27.302471
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:30.019298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'