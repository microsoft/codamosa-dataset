

# Generated at 2022-06-26 12:51:53.165292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:52:01.000004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    the_star_i_e = TheStarIE()

    the_star_i_e.thestar_com(url)
    the_star_i_e.thestar_com("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    the_star_i_e.thestar_com("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:52:09.282027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from unittest import TestCase
    from .common import InfoExtractor

    class TheStarIETestCase(TestCase):
        def test___init__(self):
            id_ = '794267642001'
            title = 'Mankind: Why this woman started a men\'s skin care line'
            description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
            timestamp = 1454353482
            the_star_i_e_0 = TheStarIE()

    return TheStarIETestCase


# Generated at 2022-06-26 12:52:11.630301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test with 'var' key in constructor input.
    the_star_i_e = TheStarIE()

test_case_0()
test_TheStarIE()

# Generated at 2022-06-26 12:52:13.262725
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(the_star_i_e_0, TheStarIE)


# Generated at 2022-06-26 12:52:14.218690
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass;


# Generated at 2022-06-26 12:52:15.518294
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:18.238962
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert True


# Generated at 2022-06-26 12:52:30.391419
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    brightcove_url_template_0= 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    _VALID_URL_0 = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:32.365313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:34.877967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:52:43.304297
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:46.381425
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._download_webpage('str') == "TheStarIE"
    assert ie._match_id('str') == "TheStarIE"

# Generated at 2022-06-26 12:52:49.947777
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of test_TheStarIE"""
    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-26 12:52:50.347325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert True

# Generated at 2022-06-26 12:52:52.751462
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:52:53.566943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()



# Generated at 2022-06-26 12:52:55.477242
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:53:07.582352
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:12.093901
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:18.733604
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE()

# Generated at 2022-06-26 12:53:20.665748
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(InfoExtractor())._name == 'TheStar'

# Generated at 2022-06-26 12:53:22.654237
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE(), '_download_webpage')

# Generated at 2022-06-26 12:53:29.254897
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """

    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    theStarIE = TheStarIE()
    assert theStarIE._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert theStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-26 12:53:30.122974
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:40.042924
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  """Test constructing a TheStarIE object."""

  # Example of "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
  url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

  # Create a TheStarIE object given the above url
  theStarIE = TheStarIE()

  # Get the display ID
  display_id = theStarIE._match_id(url)

  # Get the webpage of the url
  webpage = theStarIE._download_webpage(url, display_id)

  # Get the Brightcove ID
  brightcove_id = theStar

# Generated at 2022-06-26 12:53:49.363548
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_object = TheStarIE()
    # test the TheStarIE._VALID_URL meets our expectations
    assert test_object._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    # test the TheStarIE._TEST meets our expectations

# Generated at 2022-06-26 12:53:54.169313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:57.356588
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor = TheStarIE(None)
    assert constructor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:01.228511
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Should not raise any error
    try:
        TheStarIE()
    except:
        raise AssertionError('Fail to instantiate TheStarIE')


# Generated at 2022-06-26 12:54:15.053156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:15.857866
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-26 12:54:20.682467
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:54:25.126114
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:25.610821
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-26 12:54:26.907477
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE('TheStarIE')

# Generated at 2022-06-26 12:54:35.842860
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for constructor of class TheStarIE
    """
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie._match_id(url) == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-26 12:54:39.486400
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
        video_id = '4732393888001'
        url = TheStarIE._build_brightcove_url(video_id)
        assert TheStarIE._VALID_URL in url

# Generated at 2022-06-26 12:54:40.652311
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'TheStarIE' == ie.__class__.__name__


# Generated at 2022-06-26 12:54:42.933437
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:01.445252
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(str(TheStarIE) == 'TheStarIE')

# Generated at 2022-06-26 12:55:07.036420
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        thestarie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
        url = thestarie.get_url()
        assert(url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    except:
        print("Exception raised in constructor of class TheStarIE")



# Generated at 2022-06-26 12:55:17.278274
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # we want to test TheStarIE, but in order to do that we need to create
    # a constructor object of InfoExtractor.
    ie = InfoExtractor()

    # here comes where classes are actually instantiaded.
    # The method returns a TheStarIE constructed object
    # named the_star_ie
    the_star_ie = ie.construct_ie("TheStar")

    # We test if the TheStarIE constructed object is a
    # TheStarIE-type.
    the_star_is_a_TheStarIE = isinstance(
        the_star_ie,
        TheStarIE)

    # if the_star_is_a_TheStarIE is True, then the test
    # passes. If it is false, the test fails.
    assert the_star_is_a_TheStarIE

# Generated at 2022-06-26 12:55:22.258691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    assert TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001')._match_id(
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == \
           '4732393888001'

# Generated at 2022-06-26 12:55:24.022071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = None

# Generated at 2022-06-26 12:55:33.595961
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # For unit testing purpose, we need to create a subclass of class TheStarIE to pass in the class name to super().__init__()
    class TestTheStarIE(TheStarIE):
        IE_NAME = 'test_TheStarIE'
    ie = TestTheStarIE(TestTheStarIE.IE_NAME, 'www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Get attributes that are initialized in __init__()
    assert ie.name == 'test_TheStarIE'

# Generated at 2022-06-26 12:55:39.827618
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Make sure that one instance of class TheStarIE actually gets created
    test_instance = TheStarIE()
    # Now see if the data that gets received when the download is parsed is correct
    actual_data = test_instance._real_extract(test_instance._TEST['url'])
    # This is the expected result
    expected_result = '4732393888001'
    # Check to see if the data that was actually received matches the expected result
    assert actual_data['id'] == expected_result

# Generated at 2022-06-26 12:55:41.582239
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.ie_key() == 'TheStar'


# Test for the constructor
# Test for the method _real_extract

# Generated at 2022-06-26 12:55:42.362523
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  t = TheStarIE()
  assert t is not None

# Generated at 2022-06-26 12:55:45.125890
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:28.667397
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('https://www.thestar.com/entertainment/2016/02/02/rapper-bryson-tiller-skyrockets-after-surprise-album-drops.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:56:31.908945
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:56:40.671840
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_dict = TheStarIE()._extract_brightcove_info('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert info_dict['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info_dict['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert info_dict['thumbnail'] == 'http://bcdownload.gannett.edgesuite.net/toronto/41242235001/201602/2023/41242235001_4732393933001_4732393888001-vs.jpg?pubId=41242235001&videoId=4732393888001'

# Generated at 2022-06-26 12:56:43.480396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:56:51.370438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert obj._T

# Generated at 2022-06-26 12:56:54.221533
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:57:00.388687
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import os
    import tempfile
    import subprocess
    filename = os.path.basename(tempfile._get_candidate_names()[0])
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    subprocess.call(['youtube-dl', '-o', filename, video_url])

    # Output: <filename> is downloaded
    print('%s is downloaded' % filename)

# Generated at 2022-06-26 12:57:03.349028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Assert URL is correctly parsed by constructor.
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:57:04.139938
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE == type(TheStarIE({}))

# Generated at 2022-06-26 12:57:11.734929
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .test_downloader import _test_downloader
    r = _test_downloader(TheStarIE)
    assert r['output'] == '[BrightcoveNew] 4732393888001: Downloading webpage'
    r['output'] = r['output'].replace('Downloading ', '')
    assert r['output'] == '[BrightcoveNew] 4732393888001: Downloading brightcove info JSON metadata'
    assert r['output'].find('Downloading %s.mp4' % r['output'].split(' ')[1])
    assert r['info_dict']['url'] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    # test for real downloading

# Generated at 2022-06-26 12:58:51.943780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:58:53.296438
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # This is not a real test yet, only check the constructor
    TheStarIE()

# Generated at 2022-06-26 12:58:53.912084
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE

# Generated at 2022-06-26 12:58:54.387959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-26 12:58:56.395071
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    run_test(TheStarIE)

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:58:56.962080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:04.730904
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    args = [
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ]
    kwargs = {
        'video_id': '4732393888001',
        'display_id': 'mankind-why-this-woman-started-a-men-s-skincare-line.html'
    }
    assert(TheStarIE(*args, **kwargs))


# Generated at 2022-06-26 12:59:09.333068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE.find('%s') != -1
    assert ie.IE_NAME == 'TheStar'
# test_TheStarIE()


# Generated at 2022-06-26 12:59:09.918551
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:11.161845
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie.BRIGHTCOVE_URL_TEMPLATE)