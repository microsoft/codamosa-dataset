

# Generated at 2022-06-26 12:51:53.671835
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:51:55.264100
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from youtube_dl.extractor import brightcove
    assert TheStarIE(brightcove.BrightcoveNewIE())


# Generated at 2022-06-26 12:51:56.248141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check TheStarIE
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:51:57.403414
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(issubclass(TheStarIE, InfoExtractor))


# Generated at 2022-06-26 12:51:57.879614
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:51:59.107937
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj_instance = TheStarIE()
    assert None is obj_instance


# Generated at 2022-06-26 12:52:00.108359
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:11.135328
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE('test', 'test', 'test')
    assert the_star_i_e_1.type == 'test'
    assert the_star_i_e_1.geo_countries == 'test'
    assert the_star_i_e_1.ie_key() == 'test'
    assert the_star_i_e_1.ie_key(True) == 'test:'
    assert the_star_i_e_1.ie_key(False) == 'test'
    assert the_star_i_e_1.pprint() == 'test'
    assert isinstance(the_star_i_e_1.BRIGHTCOVE_URL_TEMPLATE, basestring)


# Generated at 2022-06-26 12:52:12.082982
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_case_0()

# Generated at 2022-06-26 12:52:13.360200
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()

# Generated at 2022-06-26 12:52:18.864662
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	output = "TheStarIE"
	TheStarIE().to_screen(output)
	assert output == "TheStarIE"

# Generated at 2022-06-26 12:52:21.666418
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	try:
		TheStarIE();
	except:
		assert False;


# Generated at 2022-06-26 12:52:23.235082
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:52:24.658704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie is not None

# Generated at 2022-06-26 12:52:25.848205
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:52:28.975708
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class Test:
        def __init__(self):
            self.init = True

    obj = TheStarIE(Test())
    assert obj.init == True

# Generated at 2022-06-26 12:52:30.449116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:52:38.883099
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    '''
    This is a quick demo of how to write a test for this specific case.

    Explanation:
      1. Create an instance of the class TheStarIE
      2. Create a "parsed" dictionary type to be used in the test.
      3. Create the test cases to be run in the main test
      4. Run the test
    '''


# Generated at 2022-06-26 12:52:49.301749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE({'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'md5': '2c62dd4db2027e35579fefb97a8b6554','info_dict': {'id': '4732393888001', 'ext': 'mp4', 'title': 'Mankind: Why this woman started a men\'s skin care line', 'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.', 'uploader_id': '794267642001', 'timestamp': 1454353482, 'upload_date': '20160201'},'params': {'skip_download': True}})
    assert(obj)

# Generated at 2022-06-26 12:52:53.897761
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:59.039783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj != None

# Generated at 2022-06-26 12:53:00.661749
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_under_test = TheStarIE(InfoExtractor())
    assert class_under_test

# Generated at 2022-06-26 12:53:09.376577
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    _MainartBrightcoveVideoId= '4732393888001'
    exp_result = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    ie = TheStarIE(_url)
    result = ie.BRIGHTCOVE_URL_TEMPLATE % _MainartBrightcoveVideoId

    # Assert that result and exp_result have the same value
    assert result == exp_result


# Generated at 2022-06-26 12:53:11.077404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(TheStarIE._TEST.get('url'))

# Generated at 2022-06-26 12:53:11.511374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:53:13.325508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TestTheStarIE = TheStarIE()
	test_TheStarIE()

# Generated at 2022-06-26 12:53:15.749150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert type(ie)==TheStarIE
    assert ie.BRIGHTCOVE_URL_TEMPLATE!=""


# Generated at 2022-06-26 12:53:24.955362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStar = TheStarIE()
    theStar._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    theStar._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:53:35.493683
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.url[0] == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')
    assert(ie.url[1] == 'BrightcoveNew')
    assert(ie.url[2] == '4732393888001')

# Generated at 2022-06-26 12:53:41.041742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:59.540693
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Test if the object is created
    assert ie

    # Check if the URL is accepted
    assert ie._run_suite('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Check if it's not accepted if the URL is wrong
    assert not ie._run_suite('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Check if it's not accepted

# Generated at 2022-06-26 12:54:06.289763
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:11.213813
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    classname = TheStarIE.__name__
    classinst = TheStarIE()
    assert classname == "TheStarIE"
    assert classinst != None

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-26 12:54:13.526850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert isinstance(thestar, TheStarIE)

# Generated at 2022-06-26 12:54:20.644798
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:23.222263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert('BrightcoveNew' == TheStarIE._get_brightcove_new_ie('BrightcoveNew'))

# Generated at 2022-06-26 12:54:30.272653
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    # Test for url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = instance._download_webpage(url, '4732393888001')
    pattern = r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)'
    brightcove_id = instance._search_regex(pattern, webpage, 'brightcove id')
    # A test to check that the url is not a false positive
    assert brightcove_id == '4732393888001'

# Generated at 2022-06-26 12:54:32.651572
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """TheStarIE test

    test for constructor of class TheStarIE.
    """
    TheStarIE()

# Generated at 2022-06-26 12:54:34.824119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'


# Generated at 2022-06-26 12:54:41.050898
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    'Test constructor of class TheStarIE'
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-26 12:55:06.521156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:09.171806
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()
    assert i.constructor() == True

# Generated at 2022-06-26 12:55:17.767242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()

# Generated at 2022-06-26 12:55:18.309286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:21.619272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:55:24.703729
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:31.417280
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("TheStarIE")
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html'

# Generated at 2022-06-26 12:55:32.622927
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        print('Unit test for constructor of class TheStarIE failed.')


# Generated at 2022-06-26 12:55:33.782500
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = IeTestClass(TheStarIE)
    ie.run()

# Generated at 2022-06-26 12:55:38.964669
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.video_id == '4732393888001'



# Generated at 2022-06-26 12:56:21.819951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Testing the url extraction with url of TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Testing the url extraction with url of TheStarIE
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

    # Testing the url extraction with ID of TheStarIE
    id = '4732393888001'

    # Testing the url extraction with ID of TheStarIE
    id = '4732393888001'

    # Testing the url extraction with ID of TheStarIE
    id = '4732393888001'

    # Testing the url extraction with

# Generated at 2022-06-26 12:56:22.628626
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    print(result)

# Generated at 2022-06-26 12:56:23.811453
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    print (obj.get_fields('4732393888001'))

# Generated at 2022-06-26 12:56:25.414728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE()
    assert isinstance(class_, InfoExtractor)

# Generated at 2022-06-26 12:56:33.918313
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    #assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:56:42.985567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_id1 = '4737851389001'
    brightness_cove_url1 = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4737851389001'
    brightness_cove_id1 = '4737851389001'
    expected_result1 = {
        'id': '4737851389001',
        'ext': 'mp4',
        'title': 'Down the road to the NHL draft',
        'description': 'NCAA player profile on Mississauga’s Logan Brown.',
        'uploader_id': '794267642001',
        'timestamp': 1454427382,
        'upload_date': '20160202',
        }
    brightness_cove_player_url1 = TheStarIE()._extract

# Generated at 2022-06-26 12:56:50.877271
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    IE Constructor unit test
    """
    ie = TheStarIE()

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:52.522417
# Unit test for constructor of class TheStarIE
def test_TheStarIE(): # cannot be named test_TheStarIE because TheStarIE inherits InfoExtractor
    ie = TheStarIE()
    ie.initialize()

# Generated at 2022-06-26 12:57:01.535755
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  # This test file is a temporary file to test the initialization of class constructor
  # You are free to update this file to test a different class
  if not os.path.exists('test'):
    os.makedirs('test')

  if not os.path.exists('test/TheStarIE'):
    os.makedirs('test/TheStarIE')

  if not os.path.exists('test/TheStarIE/valid_url_test'):
    os.makedirs('test/TheStarIE/valid_url_test')

  # Test for valid_url
  the_star_ie = TheStarIE()
  # Print out True if the url is valid, or False if the url is invalid

# Generated at 2022-06-26 12:57:04.399022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

# Generated at 2022-06-26 12:58:45.549318
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:58:53.765321
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test with a valid url
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # test with a bad url
    from .common import ExtractorError
    from .common import compat_http_client
    try:
        TheStarIE('http://www.thestar.com')
    except ExtractorError as e:
        assert(e.cause == compat_http_client.IncompleteRead)

# Generated at 2022-06-26 12:58:54.524279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

# Generated at 2022-06-26 12:58:55.214916
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:00.349053
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE(TheStarIE.ie_key()).suitable(url)


# Generated at 2022-06-26 12:59:09.298080
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    assert star._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:10.597567
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE(TheStarIE.ie)
    assert info.name == TheStarIE.ie

# Generated at 2022-06-26 12:59:15.687943
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    the_star_ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId="
    assert(the_star_ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=")


# Generated at 2022-06-26 12:59:18.555128
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except:
        assert False, 'FAIL: class TheStarIE'
    assert True, 'PASS: class TheStarIE'


# Generated at 2022-06-26 12:59:19.138559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass