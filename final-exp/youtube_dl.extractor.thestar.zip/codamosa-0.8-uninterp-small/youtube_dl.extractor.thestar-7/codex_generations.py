

# Generated at 2022-06-26 12:51:55.718532
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e


# Generated at 2022-06-26 12:52:01.364621
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_i_e._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:52:03.680527
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:06.412607
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    # Assert that the constructor creates an instance of the class TheStarIE
    assert isinstance(the_star_i_e, TheStarIE)

# Generated at 2022-06-26 12:52:07.725049
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert test_case_0() is None

# Generated at 2022-06-26 12:52:17.102390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'preferredquality' in the_star_i_e_0._DEFAULT_FIELDS
    assert 'siteUrl' in the_star_i_e_0._DEFAULT_FIELDS
    assert 'title' in the_star_i_e_0._TESTS[0]
    assert '2d3da1fb58c2f8b342d3b3e7564ad30f' in the_star_i_e_0._TESTS[0]
    assert 'http://www.thestar.com/life/video_games/2015/02/13/e-sports-the-year-video-games-got-big-for-real.html' in the_star_i_e_0._TESTS[0]

# Generated at 2022-06-26 12:52:19.447199
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:30.790976
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()
    assert the_star_i_e_1._downloader is None
    assert the_star_i_e_1._match_id('match_id') == 'match_id'
    assert the_star_i_e_1._VALID_URL is 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert the_star_i_e_1.BRIGHTCOVE_URL_TEMPLATE is 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:32.731126
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:40.387857
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    BrightcoveNewIE_0 = BrightcoveNewIE()
    BrightcoveLegacyIE_0 = BrightcoveLegacyIE()
    assert_equals(BrightcoveNewIE_0.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s')
    assert_equals(BrightcoveNewIE_0._SUFFIX, '_default')
    assert_equals(BrightcoveLegacyIE_0._TEMPLATE_URL, 'http://link.brightcove.com/services/link/bcpid%%s?bckey=%%s&bctid=%%s')

# Generated at 2022-06-26 12:52:46.382873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import TheStarIE
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:52:49.948923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_instance = TheStarIE()
    assert str(test_instance).find("TheStarIE") != -1


# Generated at 2022-06-26 12:53:00.654327
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:53:10.352012
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._

# Generated at 2022-06-26 12:53:11.078299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:17.798090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor = TheStarIE(InfoExtractor())
    assert constructor._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:21.319871
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    class_name = ie.__class__.__name__
    assert class_name == "TheStarIE"

# Generated at 2022-06-26 12:53:22.723696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    _ = TheStarIE({}).get_info()

# Generated at 2022-06-26 12:53:25.495221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Call the constructor of the class TheStarIE
    # and check that it is an instance of InfoExtractor
    assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-26 12:53:27.084942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE is not None

# Generated at 2022-06-26 12:53:35.616429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(True) == (TheStarIE(TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')) == True)

# Generated at 2022-06-26 12:53:45.075674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inp = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    out = '4732393888001'
    assert TheStarIE._search_regex(r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)', inp, 'brightcove id') == out

# Generated at 2022-06-26 12:53:47.311234
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:50.660263
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.IE_NAME == 'thestar'
    assert ie.IE_DESC == 'thestar.com'

# Generated at 2022-06-26 12:53:52.965951
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('sample_url',{},{})
    assert obj != None

# Generated at 2022-06-26 12:53:54.996151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    assert class_ is not None

# Generated at 2022-06-26 12:53:55.680814
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:01.294055
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = InfoExtractor({})
    info_extractor.add_info_extractor(TheStarIE)
    assert info_extractor.get_info_extractor(TheStarIE._VALID_URL) == TheStarIE

# Generated at 2022-06-26 12:54:08.542585
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()
    assert (info_extractor.BRIGHTCOVE_URL_TEMPLATE ==
            'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert (info_extractor._VALID_URL ==
            r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert (info_extractor._TEST['url'] ==
            'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:54:19.106065
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:54:31.233233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:54:36.128942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    the_star_ie = TheStarIE(class_)
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:37.589865
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()


# Generated at 2022-06-26 12:54:46.614151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.__name__ == 'thestar'
    assert ie.IE_NAME == 'thestar'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.IE_DESC == 'thestar.com'

# Generated at 2022-06-26 12:54:50.874713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Verify that an exception is thrown for a missing url
    try:
        ie = TheStarIE(None)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-26 12:54:55.721254
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Check if the TheStarIE can be constructed by using the TheStarIE class
    """
    ie = TheStarIE()
    assert ie.__clas__ == TheStarIE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:54:56.524522
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:06.754810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:15.322016
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie.extract()
    assert ie.url_result == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert ie.display_id == '794267640'

# Generated at 2022-06-26 12:55:18.832439
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:55:37.610773
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE(TheStarIE.BRIGHTCOVE_URL_TEMPLATE % '4732393888001', [])

# Generated at 2022-06-26 12:55:38.932952
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info_extractor = TheStarIE()

# Generated at 2022-06-26 12:55:41.246675
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except NameError as e:
        if "name 'TheStarIE' is not defined" in str(e):
            return True
    return False

# Generated at 2022-06-26 12:55:42.075203
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()


# Generated at 2022-06-26 12:55:44.278305
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:48.759020
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Do not add any input to this test, because it will result in an empty
    # output, which is very difficult in debugging
    ie = TheStarIE('www.thestar.com')
    # Test for different expected outputs:
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL

# Generated at 2022-06-26 12:55:53.418205
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ret = TheStarIE({})
    assert ret._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    ret = TheStarIE({'params': {}})
    assert ret._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:57.308390
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Quickly test if the constructor for this class (TheStarIE) is working
    """
    my_TheStarIE = TheStarIE()
    assert my_TheStarIE


# Generated at 2022-06-26 12:56:03.283984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie.__class__.__name__ == 'TheStarIE'
    assert thestar_ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-26 12:56:05.872057
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	'''
	test = TheStarIE()
	# test.to_screen('test successful')
	test._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	'''

# Generated at 2022-06-26 12:56:44.368967
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    #constructor should not raise exception
    #if this is a valid URL
    TheStarIE(url="https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:56:49.611459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	instance1 = TheStarIE()
	instance2 = instance1.url_result(instance1.BRIGHTCOVE_URL_TEMPLATE, 'BrightcoveNew', instance1.extract_brightcove_id(instance1._download_webpage(instance1._match_id, instance1._match_id)))
	instance3 = None

# Generated at 2022-06-26 12:56:50.805292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    assert x is not None

# Generated at 2022-06-26 12:56:58.897430
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Valid
    sample_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    expected = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert '<iframe src="' + expected + '" ></iframe>' in TheStarIE(sample_url).run()
    # Invalid
    sample_url_invalid = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-skincare-line.html'
    assert TheStarIE(sample_url_invalid).run() is None

# Generated at 2022-06-26 12:57:03.348810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_cases = [
        'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ]
    for url in test_cases:
        assert TheStarIE().suitable(url) == True

# Generated at 2022-06-26 12:57:05.454583
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/business/economy/2013/06/23/harper_goes_back_to_the_future_with_fracking.html')

# Generated at 2022-06-26 12:57:06.152686
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    c = TheStarIE()

# Generated at 2022-06-26 12:57:07.120262
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:57:07.807677
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:08.977989
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/videozone/37246772001/video/37246772001/')

# Generated at 2022-06-26 12:58:46.128404
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    # First test
    assert ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Second test
    assert ie._match_id("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "mankind-why-this-woman-started-a-men-s-skincare-line.html") == "mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-26 12:58:50.696978
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html");
    pass

# Generated at 2022-06-26 12:58:52.427731
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie != None

# Generated at 2022-06-26 12:58:56.259864
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "TheStar")
    assert type(ie) == TheStarIE


# Generated at 2022-06-26 12:59:00.393384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()
    assert the_star.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:02.184864
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    return test_TheStarIE


# Generated at 2022-06-26 12:59:06.753259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.suitable(url)
    assert ie.working == True


# Generated at 2022-06-26 12:59:09.920029
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:11.161619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE()
    except Exception as e:
        logger.exception(e)


# Generated at 2022-06-26 12:59:12.499544
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.match()