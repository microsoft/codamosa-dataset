

# Generated at 2022-06-26 12:51:54.912361
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:51:55.613091
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()



# Generated at 2022-06-26 12:51:56.749817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0 != None


# Generated at 2022-06-26 12:52:06.837636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert hasattr(TheStarIE, '_match_id'), '_match_id not in TheStarIE class'
    assert hasattr(TheStarIE, 'BRIGHTCOVE_URL_TEMPLATE'), 'BRIGHTCOVE_URL_TEMPLATE not in TheStarIE class'
    assert hasattr(TheStarIE, '_real_extract'), '_real_extract not in TheStarIE class'
    assert hasattr(TheStarIE, '_download_webpage'), '_download_webpage not in TheStarIE class'
    assert hasattr(TheStarIE, '_search_regex'), '_search_regex not in TheStarIE class'
    assert hasattr(TheStarIE, 'url_result'), 'url_result not in TheStarIE class'

# Generated at 2022-06-26 12:52:11.588094
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
    assert the_star_i_e_0.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:52:13.203995
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    assert 'TheStarIE'
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:14.491450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:15.721973
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()

# Generated at 2022-06-26 12:52:17.729383
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:19.939464
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)


# Generated at 2022-06-26 12:52:23.511498
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Verify if the class TheStarIE is constructed correctly"""
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:25.013272
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TODO: Add unit test for constructor of class TheStarIE
    return

# Generated at 2022-06-26 12:52:31.356560
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:52:37.913873
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """

    Initialize the class and test the
    name, description, and supported
    URL.
    """

    ie = TheStarIE()

    # Test the name of the class
    assert ie.IE_NAME == "thestar"

    # Test the description of the class
    assert ie.IE_DESC == "The Star"

    # Test the supported URL format
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:48.653300
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test import statement above whether it works
    assert TheStarIE is not None
    # unit test to check whether TheStarIE class could get video URL
    # by providing the video page URL
    # this will check whether the TheStarIE constructor works
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    urls = []
    for it in TheStarIE()._real_extract(url):
        urls.append(it)
    assert len(urls) == 1
    for url in urls:
        assert url.startswith('http://players.brightcove.net')

# Generated at 2022-06-26 12:52:50.480691
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == True


# Generated at 2022-06-26 12:52:53.254888
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:52:54.015598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:57.136783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """TheStarIE unit test."""
    instance = TheStarIE()
    assert instance

    assert instance.BRIGHTCOVE_URL_TEMPLATE != None
    

# Generated at 2022-06-26 12:53:02.099046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:07.005718
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)._get_instance()


# Generated at 2022-06-26 12:53:09.238598
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print (ie._VALID_URL)
    print (ie._TEST)
    print (ie.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-26 12:53:17.285374
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    display_id = '4732393888001'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    webpage = 'mainartBrightcoveVideoId="4732393888001";'

# Generated at 2022-06-26 12:53:24.745935
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.suitable('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') == True

# Generated at 2022-06-26 12:53:37.888301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    assert(theStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(theStarIE._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(theStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')

# Generated at 2022-06-26 12:53:40.115470
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    expected_output = TheStarIE(None)
    assert expected_output is not None

# Generated at 2022-06-26 12:53:40.536112
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:49.500396
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t_TheStarIE = TheStarIE()
	t_TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	# the URL of the video
	url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	# get the content of the webpage
	webpage = t_TheStarIE._download_webpage(url, '')

# Generated at 2022-06-26 12:53:57.614312
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
		obj = TheStarIE(url="http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
		assert obj.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
		assert obj.url == obj._VALID_URL


# Generated at 2022-06-26 12:54:01.983957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/opinion/commentary/2016/02/02/associations-and-intimacy.html')




# Generated at 2022-06-26 12:54:17.028132
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._download_webpage == '<webpage_content>'

# Generated at 2022-06-26 12:54:28.573353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	obj1 = TheStarIE("TestArg1", "TestArg2");
	assert obj1.name == "TestArg1";
	assert obj1.url == "TestArg2";
	assert obj1.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s";
	assert obj1._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html';

# Generated at 2022-06-26 12:54:29.689759
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:54:31.571066
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 'TheStarIE' == TheStarIE().IE_NAME

# Generated at 2022-06-26 12:54:33.051975
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:54:41.099240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  test_ie = TheStarIE(InfoExtractor())
  assert test_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:43.525298
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	print ("test_TheStarIE")
	# Instantiation
	print ("Instantiation")
	TheStarIE()


# Generated at 2022-06-26 12:54:55.720558
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.release_date = datetime.date(2016, 2, 1)
    ie.headline = 'Mankind: Why this woman started a men\'s skin care line'
    ie.type = 'video'
    ie.thumbnail = 'http://www.thestar.com/content/dam/thestar/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line/young_lee.jpg'
    ie.description = 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    ie.slug = 'mankind-why-this-woman-started-a-mens-skincare-line'

# Generated at 2022-06-26 12:55:06.440034
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    ie = InfoExtractor(TheStarIE)

    def http_request(self, url):
        pass
        return {'url': url}
    ie._http_request = http_request
    try:
        ie.extract('unknown_video_id')
        raise Exception('None Video ID expected')
    except:
        pass

    ie = InfoExtractor(TheStarIE)
    ie._http_request = http_request
    
    res = ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:55:17.131047
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.get_id() == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.get_webpage_url() == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.get_display_id() == "mankind-why-this-woman-started-a-men-s-skincare-line")

# Generated at 2022-06-26 12:55:42.509459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    # Check if the url is correct
    assert thestar._VALID_URL == url
    # Check if the url has a valid extractor
    assert thestar._TESTS
    # md5 of file downloaded successfully: 2c62dd4db2027e35579fefb97a8b6554
    assert thestar._TESTS['url'] == url
    assert thestar._TESTS['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-26 12:55:43.293092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE() 
    assert ie.name

# Generated at 2022-06-26 12:55:43.762660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:50.770774
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    this_class = TheStarIE(url)
    assert this_class.url == url
    assert this_class.display_id == '4732393888001'
    assert this_class.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:52.961714
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE(None)._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE(None)._TEST == TheStarIE._TEST

# Generated at 2022-06-26 12:55:53.796585
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()

# Generated at 2022-06-26 12:55:55.643401
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Test constructor of class TheStarIE."""
    assert TheStarIE(123) == "Hello World"

# Generated at 2022-06-26 12:56:01.113097
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t_theStar = TheStarIE();
    t_theStar.BRIGHTCOVE_URL_TEMPLATE
    t_theStar._VALID_URL
    t_theStar._TEST
    t_theStar.BRIGHTCOVE_URL_TEMPLATE
    t_theStar._real_extract(t_theStar._TEST['url'])
    pass

# Generated at 2022-06-26 12:56:06.500221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE
    ie = TheStarIE()
    ie.download = lambda *args, **kwargs: 'Test webpage'
    ie._download_webpage = lambda *args, **kwargs: 'Test webpage'

    url ='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = ie._match_id(url)
    webpage = ie._download_webpage(url, display_id)
    brightcove_id = ie._search_regex(
        r'mainartBrightcoveVideoId["\']?\s*:\s*["\']?(\d+)',
        webpage, 'brightcove id')


# Generated at 2022-06-26 12:56:07.686236
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:56:50.805899
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	"""
	Tests for the constructor of the TheStarIE class.
	"""
	url_input = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	assert TheStarIE._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
	assert TheStarIE._TEST['url'] == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"

# Generated at 2022-06-26 12:56:58.891826
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:57:02.231268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:05.165377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_test = TheStarIE()
    assert thestar_test._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:57:12.979148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for class TheStarIE
    reference_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = '4732393888001'
    webpage = 'test'
    brightcove_id = '4732393888001'
    brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    
    # check for url_result
    url_result_video = TheStarIE(None).url_result(brightcove_url, 'BrightcoveNew', brightcove_id)

# Generated at 2022-06-26 12:57:17.377696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # check_IE(TheStarIE, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:57:17.851760
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-26 12:57:25.776758
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie =TheStarIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie._TEST == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:57:26.485119
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	tp = TheStarIE()

# Generated at 2022-06-26 12:57:29.672038
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
	result = TheStarIE()._real_extract(test_url)
	assert result['id'] == '4732393888001'

# Generated at 2022-06-26 12:59:01.145593
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	# Check specific expected attributes
	assert hasattr(ie, '_VALID_URL')
	assert hasattr(ie, '_TEST')
	assert hasattr(ie, 'BRIGHTCOVE_URL_TEMPLATE')
	assert hasattr(ie, '_real_extract')

# Generated at 2022-06-26 12:59:05.663549
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE({})
    obj.BRIGHTCOVE_URL_TEMPLATE = 'dummy'
    obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:59:12.895041
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:59:15.032686
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    i = TheStarIE()

# Generated at 2022-06-26 12:59:25.594116
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    import sys
    from youtube_dl.utils import parse_query
    from tests.test_utils_ie import test_TheStarIE as test_class, test_html
    from nose.tools import assert_equal, assert_true, assert_in
    from mock import Mock, patch
    TheStarIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-26 12:59:26.455756
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:59:35.781977
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert (ie._VALID_URL == 'https?://(?:www\\.)?thestar\\.com/(?:[^/]+/)*(?P<id>.+)\\.html')
    assert (ie._downloader.params['username'] == '9qWYm1QvYNxVPxud2zglJnAV8wvzoyGp')

# Generated at 2022-06-26 12:59:41.177388
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # ie = IE_test('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._TEST['url'] == ie._VALID_URL

# Generated at 2022-06-26 12:59:44.536450
# Unit test for constructor of class TheStarIE
def test_TheStarIE():    
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
# Test TheStarIE._real_extract()    
test_TheStarIE._real_extract = _real_extract

# Generated at 2022-06-26 12:59:46.487006
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'