

# Generated at 2022-06-26 12:51:55.983825
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from unittest import mock
    from unittest import TestCase
    from ytdl.extractor.thestar import TheStarIE
    the_star_i_e_0 = TheStarIE()
    test_case_0.checkResult(test_case_0)

test_case_0()

# Generated at 2022-06-26 12:51:57.104150
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    manitoba_i_e = TheStarIE()

# Generated at 2022-06-26 12:51:58.122529
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:52:07.810270
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    arg0 = "Test"
    arg1 = "Test"
    arg2 = "Test"
    arg3 = "Test"
    arg4 = "Test"
    arg5 = "Test"
    arg6 = "Test"
    arg7 = "Test"
    arg8 = "Test"
    arg9 = "Test"
    arg10 = "Test"
    arg11 = "Test"
    arg12 = "Test"
    arg13 = "Test"
    the_star_i_e_0 = TheStarIE(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13)



# Generated at 2022-06-26 12:52:10.025122
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

test_case_0()
test_TheStarIE()

# Generated at 2022-06-26 12:52:10.584143
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 1==1

# Generated at 2022-06-26 12:52:15.475882
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
  the_star_i_e_1 = TheStarIE(url);
  assert "4732393888001" == the_star_i_e_1.brightcove_id

test_TheStarIE()

# Generated at 2022-06-26 12:52:17.579018
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_case_0()

# Generated at 2022-06-26 12:52:29.515415
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    # self.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert True == ('http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s' in dir(the_star_i_e))
    # self._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:31.507181
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert (TheStarIE() != None), "Unable to instantiate TheStarIE class"

# Generated at 2022-06-26 12:52:36.755475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:52:38.388490
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()


# Generated at 2022-06-26 12:52:43.734780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    with InfoExtractor('TheStarIE') as ie:
        ie.BRIGHTCOVE_URL_TEMPLATE
        ie._VALID_URL
        ie._TEST
        ie._real_extract('TheStarIE')

# Generated at 2022-06-26 12:52:48.591728
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    website_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    video_id = '4732393888001'
    assert ie.constructor(TheStarIE, website_url).extract() == ie.constructor(TheStarIE, video_id).extract()

# Generated at 2022-06-26 12:52:59.085325
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._match_id('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == 'mankind-why-this-woman-started-a-men-s-skincare-line'

# Generated at 2022-06-26 12:52:59.819576
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:53:02.101991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:07.274983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    

# Generated at 2022-06-26 12:53:14.156319
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:15.165115
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None

# Generated at 2022-06-26 12:53:24.050937
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # When test case is run on command line.
    if __name__ == '__main__':
        # The test case class is called directly by the test 
        # runner, and object of the class is created.
        assert TheStarIE(None)

# Generated at 2022-06-26 12:53:27.087499
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.__class__.__name__ == 'TheStarIE'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:53:27.843547
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:32.849817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-26 12:53:39.101983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestarIE = TheStarIE(
        "https://www1.thestar.com/content/dam/thestar/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line/mankind.jpg",
        "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:53:41.378292
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    return ie


# Generated at 2022-06-26 12:53:46.727783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  ie = TheStarIE()
  assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
  ie._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
  assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:53:49.335632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:54:00.000069
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Test with a valid parameter
    theStar = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Test with a valid parameter with preceeding and trailing whitespace
    theStar = TheStarIE(' \t \n http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html \n \t ')

    # Test with a valid paramter not including a display_id
    theStar = TheStarIE('http://www.thestar.com')

    # Test with a invalid paramter

# Generated at 2022-06-26 12:54:03.005223
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    #test_TheStarIE()
    

# Generated at 2022-06-26 12:54:12.688932
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t is not None

# Generated at 2022-06-26 12:54:16.743231
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assertTheStarIE = TheStarIE()
    assert assertTheStarIE.get_url() != "", "The URL is empty"
    assert assertTheStarIE.get_md5() != "", "The MD5 value is empty"
    assert assertTheStarIE.get_id() != "", "The ID is empty"
    assert assertTheStarIE.get_ext() != "", "The FILETYPE is empty"
    assert assertTheStarIE.get_title() != "", "The TITLE is empty"
    assert assertTheStarIE.get_description() != "", "The DESCRIPTION is empty"
    assert assertTheStarIE.get_timestamp() != "", "The TIMESTAMP is empty"
    assert assertTheStarIE.get_upload_date() != "", "The UPLOAD_DATE is empty"
    assert assertThe

# Generated at 2022-06-26 12:54:25.282710
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    parser = TheStarIE("TheStarIE")
    assert parser.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert parser._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:37.128850
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print('\nIn test for The Star\n')
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    thestar_ie = TheStarIE()
    assert(thestar_ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:54:42.373922
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:54:43.384341
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() != None

# Generated at 2022-06-26 12:54:45.583279
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert isinstance(ie, TheStarIE)
    return ie


# Generated at 2022-06-26 12:54:46.585564
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:54:47.802948
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:49.277221
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    
    TheStarIE()

# Generated at 2022-06-26 12:55:16.526021
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

    print("Valid URL: " + str(("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html" == ie.valid_url("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", None))))


# Generated at 2022-06-26 12:55:27.143243
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._VALID_URL.match(url)
    assert TheStarIE._TEST['url'] == url
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert TheStarIE._TEST['info_dict']['id'] == '4732393888001'
    assert TheStarIE._TEST['info_dict']['ext'] == 'mp4'
    assert TheStarIE._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'

# Generated at 2022-06-26 12:55:30.713171
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('TheStarIE', 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Following should not throw an exception
    repr(ie)

# Generated at 2022-06-26 12:55:33.006046
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    obj = TheStarIE(url)
    assert obj.url == url

# Generated at 2022-06-26 12:55:33.588332
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# This is easy to test this class
	pass

# Generated at 2022-06-26 12:55:42.508459
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    assert ie.get_url() == url
    assert ie.get_md5() == '2c62dd4db2027e35579fefb97a8b6554'
    assert ie.get_title() == 'Mankind: Why this woman started a men\'s skin care line'
    assert ie.get_description() == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'
    assert ie.get_uploader_id() == '794267642001'
    assert ie.get_timestamp() == 1454353482
    assert ie.get_upload_

# Generated at 2022-06-26 12:55:50.339893
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

    info = ie.extract_info(
        ie.url_result(ie.BRIGHTCOVE_URL_TEMPLATE, 'BrightcoveNew', 'id'),
        'http://video.thestar.com/4732393888001/4732393888001_4732393554001_vs-4732393564001.mp4?pubId=794267642001&videoId=4732393888001')

    assert info['title'] == 'Mankind: Why this woman started a men\'s skin care line'
    assert info['description'] == 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.'

# Generated at 2022-06-26 12:55:56.673197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test that the TheStarIE constructor doesn't have any error
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.VALID_URL.pattern == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:56:05.522168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.version == '0.0.1'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:06.074213
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:44.101087
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:52.015759
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:56:56.684259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    extracted = TheStarIE('www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert extracted.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:57:04.744267
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE._make_test({
        'url': 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
    })
    assert test_TheStarIE.display_id.string() == "mankind-why-this-woman-started-a-men-s-skincare-line"
    assert test_TheStarIE.url.string() == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert not test_TheStarIE.extract()

# Generated at 2022-06-26 12:57:08.806027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE(InfoExtractor())
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE2
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE3
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE4
    test_TheStarIE._BRIGHTCOVE_FEED_BASE
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE2
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE3
    test_TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:57:11.871783
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"),
    TheStarIE)

# Generated at 2022-06-26 12:57:20.296022
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:57:21.563775
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    x = TheStarIE()
    return

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:57:28.902619
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None
    #assert ie.validate_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == True
    assert ie.validate_url('http://www.thestar.com/halifax/video/2016/02/02/halifax-dog-rescued-from-the-ice-of-the-north-west-arm.html') == True
    #assert ie.validate_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') == True

# Generated at 2022-06-26 12:57:31.091757
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html') is not None


# Generated at 2022-06-26 12:59:01.706953
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:06.711713
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert thestar_ie != None
    assert thestar_ie.name == "TheStar"
    assert thestar_ie.ie_key() == "TheStar"

# Generated at 2022-06-26 12:59:09.330870
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:59:12.303547
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:15.868144
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE
    obj = ie('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.url == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'

# Generated at 2022-06-26 12:59:19.621343
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie != None


# Generated at 2022-06-26 12:59:20.765092
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:59:21.294133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	pass

# Generated at 2022-06-26 12:59:22.738152
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie is not None


# Generated at 2022-06-26 12:59:31.744404
# Unit test for constructor of class TheStarIE