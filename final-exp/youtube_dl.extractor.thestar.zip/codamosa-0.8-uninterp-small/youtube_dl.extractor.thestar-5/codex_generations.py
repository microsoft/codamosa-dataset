

# Generated at 2022-06-26 12:51:54.396997
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert callable(TheStarIE)

# Generated at 2022-06-26 12:51:56.906784
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert(the_star_i_e is not None)
    assert(the_star_i_e._VALID_URL is not None)
# Unit test of _real_extract

# Generated at 2022-06-26 12:52:01.000265
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    val_0 = TheStarIE()
    assert val_0._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'
    assert val_0._TEST['info_dict']['title'] == 'Mankind: Why this woman started a men\'s skin care line'


# Generated at 2022-06-26 12:52:12.113521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # make sure the class of the_star_i_e_0 is TheStarIE
    assert str(type(the_star_i_e_0)) == "<class '__main__.TheStarIE'>"
    # make sure the class of the_star_i_e_0._downloader is YoutubeDL
    assert str(type(the_star_i_e_0._downloader)) == "<class 'youtube_dl.YoutubeDL'>"
    # make sure the class of the_star_i_e_0._downloader._ie_key_map['brightcovenew'] is BrightcoveNewIE
    assert str(type(the_star_i_e_0._downloader._ie_key_map['brightcovenew'])) == "<class 'youtube_dl.extractor.brightcove.BrightcoveNewIE'>"


# Generated at 2022-06-26 12:52:14.491220
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Check if instance of TheStarIE is created
    assert isinstance(TheStarIE(), TheStarIE) == True

# Unit tests for _real_extract method

# Generated at 2022-06-26 12:52:15.762565
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e= TheStarIE()

# Generated at 2022-06-26 12:52:16.897955
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:29.336741
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()
    assert the_star_i_e_1.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_i_e_1._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert the_star_i_e_1.VALID_URL == TheStarIE.VALID_URL

    assert the_star_i_e_1._downloader is None
    assert the_star_i_e_1.ie_key() == 'TheStar'
    assert the_star_i_e_1

# Generated at 2022-06-26 12:52:36.179078
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
# Function test_case_0() case count: 1
# Function test_TheStarIE() case count: 1
test_case_1 = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'Life')


# Generated at 2022-06-26 12:52:37.330377
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:52:46.490287
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # The following test documents the current behavior of the constructor.
    # Any change in this behaviour should be considered a regression.
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._build_url_result(url, 'brightcove:4732393888001')

# Generated at 2022-06-26 12:52:48.391938
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()



# Generated at 2022-06-26 12:52:56.058883
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:53:03.848269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert(ie.extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") != "")

# Generated at 2022-06-26 12:53:08.757373
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    

test_TheStarIE()

# Generated at 2022-06-26 12:53:14.376711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.url_result('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html',
                        'BrightcoveNew', '4732393888001')

test_TheStarIE()

# Generated at 2022-06-26 12:53:24.271506
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    name = 'TheStarIE'
    module = '__main__'
    thestar_ie = TheStarIE()
    assert thestar_ie.name == name
    assert thestar_ie.tbr == None
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar_ie.module == module

# Generated at 2022-06-26 12:53:28.571301
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()

    # Test get ID from URL
    inst.get_ID_from_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    # Test generate URL
    inst.BRIGHTCOVE_URL_TEMPLATE % inst.get_ID_from_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

test_TheStarIE() # Call the constructed method

# Generated at 2022-06-26 12:53:38.441260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    url = "https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.suitable(url), "URL is suitable"
    assert ie._VALID_URL == "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"

# Generated at 2022-06-26 12:53:43.094723
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .common import TheStarIE
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:56.645559
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # url = 'https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html'
    url = 'http://www.thestar.com/news/world/2016/05/20/beard-politics-take-over-at-sochi-music-festival.html'
    assert TheStarIE().suitable(url)
    assert TheStarIE().extract(url)['title'] == 'Beard politics take over at Sochi music festival'

# Generated at 2022-06-26 12:54:05.272244
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    fetch_url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    instance = TheStarIE()
    result = instance._real_extract(fetch_url)
    assert (isinstance(result, dict) and
            result["id"] == "4732393888001" and
            result["uploader_id"] == "794267642001")

# Generated at 2022-06-26 12:54:06.557445
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    object = TheStarIE()

# Generated at 2022-06-26 12:54:08.590606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(None)._real_extract('')

# Generated at 2022-06-26 12:54:15.932000
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(None, None)
    # valid url
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie._real_initialize(url)
    assert ie.url == url
    assert ie.display_id == '4732393888001'

# Generated at 2022-06-26 12:54:21.322983
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:23.829156
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test TheStarIE constructor
    instance = TheStarIE()
    assert instance is not None


# Generated at 2022-06-26 12:54:26.155881
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE('TheStarIE')
    ie = InfoExtractor.get_info_extractor('TheStarIE')

# Generated at 2022-06-26 12:54:27.406732
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:54:36.934186
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'thestar'
    assert ie.ie_url() == 'thestar.com'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_VIDEO_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:54:45.269785
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE()

# Generated at 2022-06-26 12:54:46.786151
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:54:54.363428
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	ie = TheStarIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
	#assert ie._real_extract() ==

# Generated at 2022-06-26 12:55:01.661765
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test Video
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    # Instantiate object
    thestar = TheStarIE(dummy_args)
    thestar.extract(url)

# Generated at 2022-06-26 12:55:07.993666
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:17.441925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-26 12:55:18.630391
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL


# Generated at 2022-06-26 12:55:22.628190
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Verify that TheStarIE works via http scheme.
    ie = TheStarIE()
    ie._valid_url('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:32.491259
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:37.731269
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ test constructor of class TheStarIE (TheStar Information Extractor) """
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert obj.extractor_key == 'BrightcoveNew'
    assert obj.new_url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:55:59.115286
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    TheStarIE('TheStarIE', '4732393888001')

# Generated at 2022-06-26 12:55:59.764281
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:56:03.062036
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    try:
        TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    except:
        return False
    return True


# Generated at 2022-06-26 12:56:05.656481
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    print("Constructor of class TheStarIE")
    assert callable(TheStarIE.suitable)
    assert callable(TheStarIE.extract)
    print("END of test_TheStarIE()")

# Unit testing for _real_extract of class TheStarIE

# Generated at 2022-06-26 12:56:07.557362
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    TheStarIE Instantiation
    """
    assert TheStarIE(_VALID_URL, _TEST)

# Generated at 2022-06-26 12:56:11.287817
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')


# Generated at 2022-06-26 12:56:14.014670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:56:15.009439
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE({})

# Generated at 2022-06-26 12:56:22.918744
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	t = TheStarIE()
	assert t._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:31.243874
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test
    assert TheStarIE(None)._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:12.530188
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:15.982980
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Run all tests of TheStarIE class to make sure that it is ok """
    ie = TheStarIE();
    ie._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');

# Generated at 2022-06-26 12:57:18.518041
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "default", "default")

# Generated at 2022-06-26 12:57:19.225878
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:20.326211
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert("thestarie" in vars(TheStarIE))

# Generated at 2022-06-26 12:57:23.505912
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:57:30.138087
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    from .TheStarIE import TheStarIE
    thestar = TheStarIE()
    thestar1 = TheStarIE()
    thestar2 = TheStarIE()
    thestar3 = TheStarIE()

# Generated at 2022-06-26 12:57:30.651823
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(TheStarIE(), InfoExtractor)

# Generated at 2022-06-26 12:57:31.773276
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	x = TheStarIE()
	x._real_extract("Valid URL")
	x._real_extract("Invalid URL")

# Generated at 2022-06-26 12:57:33.570590
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:03.807574
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:59:05.620991
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    a = TheStarIE()
    assert a.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:59:06.242371
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:59:09.329229
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:20.149738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:29.756802
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE()
    assert(thestar._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(thestar._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(thestar._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554')
    assert(thestar._TEST['info_dict']['id'] == '4732393888001')
    assert(thestar._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-26 12:59:30.585347
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE().test()

# Generated at 2022-06-26 12:59:34.322406
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    assert the_star_ie.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:36.382929
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()
	assert test != None
	assert test.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:59:37.362508
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(TheStarIE._VALID_URL)