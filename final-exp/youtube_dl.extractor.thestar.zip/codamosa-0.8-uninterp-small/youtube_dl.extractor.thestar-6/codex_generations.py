

# Generated at 2022-06-26 12:52:07.333742
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:08.289120
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_case_0()

# Generated at 2022-06-26 12:52:09.457162
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:17.850854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test for case when database is empty
    the_star_i_e = TheStarIE()
    assert the_star_i_e.db_host == "localhost"
    assert the_star_i_e.db_name == "news"
    assert the_star_i_e.db_user == "root"
    assert the_star_i_e.db_password == "root"

    # Test for case when database is not empty
    the_star_i_e = TheStarIE("localhost", "news", "root", "root")
    assert the_star_i_e.db_host == "localhost"
    assert the_star_i_e.db_name == "news"
    assert the_star_i_e.db_user == "root"
    assert the_star_i_e.db_password

# Generated at 2022-06-26 12:52:29.600776
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    input_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    output_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'

# Generated at 2022-06-26 12:52:31.005141
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star = TheStarIE()


# Generated at 2022-06-26 12:52:32.364587
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert 1 == 1

# Generated at 2022-06-26 12:52:40.265735
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert the_star_i_e_0._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:41.079068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:45.482942
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    video_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    the_star_ie = TheStarIE(url=video_url)
    # Return the new object
    assert the_star_ie
    # Return the object URL
    assert the_star_ie.url == video_url


# Generated at 2022-06-26 12:52:57.174174
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # test_constructor: TheStarIE(InfoExtractor)
    # test_constructor: TheStarIE.BRIGHTCOVE_URL_TEMPLATE: String
    # test_constructor: TheStarIE._VALID_URL: RegexNotFoundError
    # test_constructor: TheStarIE._TEST: dict
    thestar_ie = TheStarIE()
    assert thestar_ie
    assert thestar_ie.BRIGHTCOVE_URL_TEMPLATE
    try:
        thestar_ie._VALID_URL
    except RegexNotFoundError as e:
        assert e
    assert thestar_ie._TEST

# Generated at 2022-06-26 12:52:58.553630
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	test = TheStarIE()

# Generated at 2022-06-26 12:52:59.851340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:53:00.334777
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:02.718696
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()
    assert result.__class__.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:53:03.406317
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:53:04.594007
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())

# Generated at 2022-06-26 12:53:10.517911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # TheStarIE is a subclass of InfoExtractor, test its constructor
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE.__class__ == unicode
    assert ie.VALID_URL.__class__ == str


# Generated at 2022-06-26 12:53:17.924384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	from utils import TestUrls # import TestUrls class
	from utils import get_cached_video_file # import function get_cached_video_file
	from utils import extractor_test # import function extractor_test
	from utils import make_output_directory # import function make_output_directory
	from extractor import make_extractor # import function make_extractor
	from extractor import ExtractorError # import ExtractorError error
	from extractor import _parse_mpd_formats # import function _parse_mpd_formats

	# Create instance of TestUrls class with url and url type

# Generated at 2022-06-26 12:53:20.158790
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE(None)

# Generated at 2022-06-26 12:53:25.181752
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    assert test != None

# Generated at 2022-06-26 12:53:27.910810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract(test_TheStarIE['url'])

# Generated at 2022-06-26 12:53:30.701750
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE = TheStarIE(InfoExtractor)
    assert TheStarIE is not None


# Generated at 2022-06-26 12:53:35.247233
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:48.150670
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	# Unit test for constructor of class TheStarIE
	thestar_ie = TheStarIE()
	assert isinstance(thestar_ie, InfoExtractor)
	assert thestar_ie._downloader is not None
	assert thestar_ie._AR_COUNT_RE == re.compile(r'(\d+)')
	assert thestar_ie._AR_KEY_RE == re.compile(r'[a-zA-Z0-9_-]{11}(?=:)')
	assert thestar_ie._formats == None

# Generated at 2022-06-26 12:53:49.470074
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE() is not None

# Generated at 2022-06-26 12:53:53.114052
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test invalid url
    ie = TheStarIE()
    ie._VALID_URL = ''
    assert not ie._real_extract('')

# Generated at 2022-06-26 12:53:54.548245
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()


# Generated at 2022-06-26 12:54:02.388504
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj.BRIGHT_COVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:05.953875
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    t = TheStarIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    assert t._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'


# Generated at 2022-06-26 12:54:16.959064
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:23.773494
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:54:31.053166
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE(url)
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    display_id = 'mankind-why-this-woman-started-a-men-s-skincare-line'
    brightcove_id = '4732393888001'
    html = ie._download_webpage(url, display_id)

# Generated at 2022-06-26 12:54:35.434854
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert isinstance(obj, TheStarIE)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:40.640214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    thestar_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:52.793193
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:57.910589
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u = 'http://www.torontosun.com/2015/04/10/bystanders-brave-smoke-to-rescue-woman-from-blaze'
    TheStarIE(u)

# Generated at 2022-06-26 12:55:07.167168
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # set up test variables
    url = 'https://www.thestar.com/news/immigration/2016/01/30/federal-judge-rules-house-of-commons-security-a-must-in-resettlement-of-syrian-refugees.html'
    display_id = 'federal-judge-rules-house-of-commons-security-a-must-in-resettlement-of-syrian-refugees'

# Generated at 2022-06-26 12:55:08.937039
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    print(ie)

# Generated at 2022-06-26 12:55:13.410024
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:55:33.221521
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    global TheStarIE
    infoExtractor = TheStarIE()
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:55:37.267625
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE()
    test._match_id(url='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

test_TheStarIE()

# Generated at 2022-06-26 12:55:38.268130
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test getting the class instance
    instance = TheStarIE()

# Generated at 2022-06-26 12:55:41.506913
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

if __name__ == "__main__":
    test_TheStarIE()

# Generated at 2022-06-26 12:55:43.979469
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:55:53.299631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    class_ = TheStarIE
    assert class_._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:03.256426
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    url ='http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html', 'TheStarIE._VALID_URL is wrong'
    assert TheStarIE._TEST['url'] == url, 'TheStarIE._TEST is wrong'
    assert TheStarIE._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554', 'TheStarIE.TEST.md5 is wrong'

# Generated at 2022-06-26 12:56:10.233148
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:13.412154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    args = ['TheStarIE']
    kwargs = {'url': TheStarIE._VALID_URL, 'data': TheStarIE._TEST}
    return TheStarIE(*args, **kwargs)

# Generated at 2022-06-26 12:56:15.048595
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie = TheStarIE()
    ie = TheStarIE()

# Generated at 2022-06-26 12:56:53.872698
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:56:59.787516
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.url == "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert ie.display_id == "4732393888001"
    assert ie.brightcove_id == "4732393888001"

# Generated at 2022-06-26 12:57:00.539694
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:57:01.136636
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:57:04.005045
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:57:09.578738
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
test_TheStarIE()

# Generated at 2022-06-26 12:57:12.530331
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE._TEST['url']

# Generated at 2022-06-26 12:57:13.453780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	thestarie = TheStarIE()

# Generated at 2022-06-26 12:57:14.573067
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    theStarIE = TheStarIE()
    theStarIE


# Generated at 2022-06-26 12:57:15.024772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-26 12:58:47.422385
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_ie = TheStarIE()
    # Tests class TheStarIE was properly initiated
    assert isinstance(the_star_ie, InfoExtractor)

# Generated at 2022-06-26 12:58:52.738734
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar = TheStarIE(None)
    assert thestar.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert thestar.IE_NAME == 'thestar'

# Generated at 2022-06-26 12:58:55.701692
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:59:00.089700
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:59:02.232879
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tstar = TheStarIE()
    assert tstar._VALID_URL  # pylint: disable=protected-access


# Generated at 2022-06-26 12:59:05.156388
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:59:06.028925
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()

# Generated at 2022-06-26 12:59:13.171674
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    downloader = TheStarIE()
    assert downloader._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:24.494068
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    IE = TheStarIE()
    assert hasattr(IE, '_DEFAULT_FORMATS'), '_DEFAULT_FORMATS is not defined'
    assert hasattr(IE, '_VALID_URL'), '_VALID_URL is not defined'
    assert hasattr(IE, '_TESTS'), '_TESTS is not defined'
    assert hasattr(IE, '_WORKING'), '_WORKING is not defined'
    assert hasattr(IE, 'BRIGHTCOVE_URL_TEMPLATE'), 'BRIGHTCOVE_URL_TEMPLATE is not defined'
    assert hasattr(IE, 'BRIGHTCOVE_URL_TEMPLATE'), 'BRIGHTCOVE_URL_TEMPLATE is not defined'

# Generated at 2022-06-26 12:59:26.627704
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(
        TheStarIE(),
        TheStarIE,
        'Unable to create an instance of the TheStarIE'
    )