

# Generated at 2022-06-26 12:51:54.782575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()


# Generated at 2022-06-26 12:52:02.185121
# Unit test for constructor of class TheStarIE
def test_TheStarIE():

    # Input: url: https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html
    # Expected result: an instance of TheStarIE
    the_star_i_e_0 = TheStarIE()
    
    # Input: url: https://www.thestar.com/news/gta/2016/02/24/post-media-readies-for-the-worst-as-it-tries-to-save-the-sun-media-chain.html
    # Expected result: an instance of TheStarIE
    the_star_i_e_1 = TheStarIE()
    



# Generated at 2022-06-26 12:52:04.932370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e is not None

# Generated at 2022-06-26 12:52:06.245408
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_1 = TheStarIE()


# Generated at 2022-06-26 12:52:07.891926
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:17.224468
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()
    assert the_star_i_e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert the_star_i_e._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:52:19.516643
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()


# Generated at 2022-06-26 12:52:20.298369
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:31.099409
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert_equals(TheStarIE.__name__, 'TheStarIE')
    assert_equals(TheStarIE._VALID_URL, r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:52:33.095592
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()



# Generated at 2022-06-26 12:52:44.524919
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie.__name__ == 'TheStar'


# Generated at 2022-06-26 12:52:48.107772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:52:51.662833
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-mens-skincare-line.html')

# Generated at 2022-06-26 12:53:00.843815
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:53:06.504090
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    Video_class = obj.ie_key()
    obj = Video_class(obj.search_regex(r'"mainartBrightcoveVideoId"\s*:\s*"(\d+)"',
                                       "<script>var mainartBrightcoveVideoId = '12345';</script>",
                                       'brightcove_id'))
    assert 12345 == obj.video_id

# Generated at 2022-06-26 12:53:10.521772
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:11.604847
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE.__name__ == 'TheStarIE'

# Generated at 2022-06-26 12:53:19.798900
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    TheStarIE._VALID_URL = r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    TheStarIE.BRIGHTCOVE_

# Generated at 2022-06-26 12:53:24.709711
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:53:29.401959
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:36.054957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Test to confirm that TheStarIE correctly returns the type of
    TheStar class
    """
    ie = TheStarIE('url')
    assert isinstance(ie, TheStarIE)

# Generated at 2022-06-26 12:53:45.968194
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	try:
		thestarie = TheStarIE('https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
	except Exception as e:
		print('TheStarIE class constructor test failed')
		print(e)
	else:
		print('TheStarIE class constructor test passed')

if __name__ == '__main__':
	test_TheStarIE()

# Generated at 2022-06-26 12:53:56.098553
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Positive test case
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)
    # Negative test case
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:54:07.562938
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Tested with 'http://www.thestar.com/life/2015/08/01/mister-serious-ten-hilarious-chris-hadfield-tweets.html'
    url = 'http://www.thestar.com/life/2015/08/01/mister-serious-ten-hilarious-chris-hadfield-tweets.html'
    ie = TheStarIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:14.167027
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    initial_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    ie = TheStarIE()
    ie = ie.extract(initial_url)
    print(ie)

# Generated at 2022-06-26 12:54:20.825164
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert TheStarIE()._downloader.params['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert TheStarIE()._downloader.params['player_id'] == '4732393888001'

# Generated at 2022-06-26 12:54:25.247095
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie

# Generated at 2022-06-26 12:54:27.533180
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test function of TheStarIE"""

    t = TheStarIE()

# Generated at 2022-06-26 12:54:36.673483
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	#Input for class constructor
	class Example:
		pass
	#Object of the class Example
	example = Example()
	#Input for the constructor
	example.url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
	#Create object of class TheStarIE
	thestare = TheStarIE(example)
	#Check if constructor is created or not
	if thestare == None:
		assert False
	else:
		assert True
	

# Generated at 2022-06-26 12:54:42.433931
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test instance creation
    obj = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    
    # Test name
    assert  obj.IE_NAME == "thestar"

# Generated at 2022-06-26 12:54:52.560804
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:54:55.724593
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie_TheStar = TheStarIE()
    brightcove_url = ie_TheStar.BRIGHTCOVE_URL_TEMPLATE
    assert brightcove_url == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:59.915453
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:04.322081
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    temp_video_result = {'id': '4732393888001',
                         'ext': 'mp4',
                         'title': 'Mankind: Why this woman started a men\'s skin care line',
                         'description': 'Robert Cribb talks to Young Lee, the founder of Uncle Peter\'s MAN.',
                         'uploader_id': '794267642001',
                         'timestamp': 1454353482,
                         'upload_date': '20160201'}
    obj = TheStarIE()
    value = obj._real_extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert value == temp_video_result

# Generated at 2022-06-26 12:55:09.235911
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:13.878306
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.download('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:55:20.058383
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    u = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    i = TheStarIE()
    assert i.match_id(u)
    u = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert i.match_id(u)


# Generated at 2022-06-26 12:55:30.673771
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE(0)

    # Check if the module is loaded properly
    assert instance.module_name == "TheStarIE"

    # Check if the URL and regex are matched properly
    URL = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert instance.match_url(URL) == "mankind-why-this-woman-started-a-men-s-skincare-line.html"
    assert "http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001" == instance.BRIGHTCOVE_URL_TEMPLATE % "4732393888001"
    assert "4732393888001"

# Generated at 2022-06-26 12:55:31.188340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:55:34.391841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie.br == 'default_default'
    assert ie.account_id == '794267642001'

# Generated at 2022-06-26 12:55:53.531803
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('')

# Generated at 2022-06-26 12:56:03.464841
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE()
    assert thestar_ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:04.500660
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test = TheStarIE("thestarIE", "thestar.com")

# Generated at 2022-06-26 12:56:05.871184
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj



# Generated at 2022-06-26 12:56:06.458733
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE()

# Generated at 2022-06-26 12:56:09.828606
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test extracting URL
    TheStarIE('https://www.thestar.com/news/canada/2016/02/13/toronto-sportswriting-revered-in-the-usa.html').get_info()

# Generated at 2022-06-26 12:56:19.413288
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """ Constructor test """
    imp.reload(TheStarIE)
    imp.reload(common)
    obj = TheStarIE(common.FakeYDL(), {}, {})
    assert obj._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:56:19.913652
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:56:23.530552
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Arguments to init are url, extra_params, expected_class_name, expected_pattern
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.__class__.__name__ == 'TheStarIE'


# Generated at 2022-06-26 12:56:27.464994
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html', 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001')


# Generated at 2022-06-26 12:57:14.282810
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit test for the class constructor.
	
    instance = TheStarIE();
    assert(instance._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html');
    assert(instance._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s');
    assert(instance._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html');

print(test_TheStarIE());

# Generated at 2022-06-26 12:57:16.910370
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.ie_key() == 'TheStar'
    assert ie.ie_name() == 'TheStar'


if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:57:23.746923
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.WEBPAGE_URL == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:57:24.495266
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE(InfoExtractor())

# Generated at 2022-06-26 12:57:31.232936
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:57:34.290561
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert ie.url_result('http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001','BrightcoveNew','4732393888001')

# Generated at 2022-06-26 12:57:34.841348
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Class constructor test"""
    TheStarIE().extract

# Generated at 2022-06-26 12:57:35.395042
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("Hello world!")

# Generated at 2022-06-26 12:57:37.790487
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE(
        'http://www.thestar.com/life/2016/02/01/'+
        'mankind-why-this-woman-started-a-men-s-skincare-line.html',
        {'skip_download': True})
    info = ie._call_routine(ie.ie_key())
    assert info.get('upload_date') == '20160201'

# Generated at 2022-06-26 12:57:39.764689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')


# Generated at 2022-06-26 12:59:04.346070
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:08.523367
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    instance = TheStarIE()

    assert(instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s")
    assert(instance._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')


# Generated at 2022-06-26 12:59:10.665216
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:59:12.614607
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.brightcove_id = '4732393888001'
    assert ie.brightcove_id == '4732393888001'


# Generated at 2022-06-26 12:59:18.831158
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:24.266458
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:25.761340
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE().extract(TheStarIE()._TEST['url'])

# Generated at 2022-06-26 12:59:26.628056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	assert TheStarIE() != None

# Generated at 2022-06-26 12:59:27.339986
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:59:36.345065
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'