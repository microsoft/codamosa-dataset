

# Generated at 2022-06-26 12:52:05.736908
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:52:07.725004
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert(test_case_0().__class__.__name__ == "TheStarIE" )


# Generated at 2022-06-26 12:52:09.632275
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

# Generated at 2022-06-26 12:52:11.630517
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e = TheStarIE()

test = TheStarIE()
test_TheStarIE()
test_case_0()

# Generated at 2022-06-26 12:52:17.877792
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  assert the_star_i_e_0._VALID_URL
  assert the_star_i_e_0._TEST
  assert the_star_i_e_0._match_id
  assert the_star_i_e_0._download_webpage
  assert the_star_i_e_0._search_regex
  assert the_star_i_e_0.url_result
  assert the_star_i_e_0._real_extract
  assert the_star_i_e_0.BRIGHTCOVE_URL_TEMPLATE

# check for test

# Generated at 2022-06-26 12:52:20.023631
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:52:20.865429
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    pass

# Generated at 2022-06-26 12:52:21.935957
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()
    assert the_star_i_e_0 is not None


# Generated at 2022-06-26 12:52:23.877575
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    the_star_i_e_0 = TheStarIE()


# Generated at 2022-06-26 12:52:26.338299
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert isinstance(the_star_i_e_0, TheStarIE)

test_case_0()

# Generated at 2022-06-26 12:52:36.306207
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    infoExtractor = TheStarIE(None)
    infoExtractor.extract_info(r'http://www.thestarkid.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE
    assert infoExtractor.brigthcove_id
    assert infoExtractor.url_result

# Generated at 2022-06-26 12:52:43.303582
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId={}'
    print(ie.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-26 12:52:55.592242
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    
    ie = TheStarIE()

# Generated at 2022-06-26 12:52:58.346160
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # If a file not found exception is thrown, the test will fail.
    ie = TheStarIE()

# Generated at 2022-06-26 12:53:03.453535
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test the constructor of TheStarIE
    ie = TheStarIE(None)
    # Test the class of this object
    assert ie.__class__ == TheStarIE
    # Test if it is an instance
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:53:06.661214
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    try:
        theStarTest = TheStarIE()
    except Exception as e:
        assert False, "Instantiation of class TheStarIE failed: " + str(e)



# Generated at 2022-06-26 12:53:15.202028
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    info = TheStarIE()._call_api(TheStarIE._TEST['url'], TheStarIE._TEST['info_dict'])
    assert info['id'] == TheStarIE._TEST['info_dict']['id']
    assert info['ext'] == TheStarIE._TEST['info_dict']['ext']
    assert info['title'] == TheStarIE._TEST['info_dict']['title']
    assert info['description'] == TheStarIE._TEST['info_dict']['description']
    assert info['uploader_id'] == TheStarIE._TEST['info_dict']['uploader_id']
    assert info['timestamp'] == TheStarIE._TEST['info_dict']['timestamp']

# Generated at 2022-06-26 12:53:18.294133
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()
    assert True

# Test constructor and extract method of class TheStarIE

# Generated at 2022-06-26 12:53:23.250238
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.extract('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:53:23.894383
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE()
    assert obj is not None

# Generated at 2022-06-26 12:53:31.365177
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-26 12:53:37.078248
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    constructor_test_class = 'TheStarIE'
    # Instantiate constructor of class TheStarIE
    # TODO: Fix this test
    # constructor_test_instance = TheStarIE(constructor_test_class)
    # Check constructor_test_instance is instance of class TheStarIE
    # assert (isinstance(constructor_test_instance, TheStarIE))

# Generated at 2022-06-26 12:53:48.702240
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_dict = {
        'title': 'BrightcoveNew',
        'uploader_id': '794267642001',
        'timestamp': 1454353482,
        'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001',
        'id': '4732393888001',
        'display_id': '4732393888001',
        'ext': 'mp4',
        'format': 'default',
        'format_id': 'default',
        'upload_date': '20160201'
    }
    thestar_ie = TheStarIE({'url': 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'})
   

# Generated at 2022-06-26 12:53:59.673938
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('foo')
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:54:02.250176
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:54:07.765197
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """
    Unit test for class TheStarIE constructor
    """
    # Unit test for extract without url
    # TheStarIE doesn't support this case
    # TheStarIE(None, None)
    # Unit test for extract without ie_key
    _ = TheStarIE(None, 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    # Unit test for extract without video id
    _ = TheStarIE(None, 'http://www.thestar.com/life.html')
    # Unit test for extract with video id which doesn't contains display id

# Generated at 2022-06-26 12:54:11.079689
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Unit tests have a fixed seed, so we can make deterministic tests
    # Here we test the constructor.
    TheStarIE().assertTrue(False)

# Generated at 2022-06-26 12:54:12.686178
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	TheStarIE('www.thestar.com')

# Generated at 2022-06-26 12:54:18.789138
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie._download_webpage("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html", "test")
    ie._real_extract("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    print("Testing complete")

test_TheStarIE()

# Generated at 2022-06-26 12:54:21.322745
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert 'thestar' in ie.IE_NAME

# Generated at 2022-06-26 12:54:39.475780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s"
    ie._VALID_URL = "https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html"

# Generated at 2022-06-26 12:54:41.889623
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    inst = TheStarIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'



# Generated at 2022-06-26 12:54:45.221823
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Example of a video URL that can be used in this test
    url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    TheStarIE()._real_extract(url)

# Generated at 2022-06-26 12:54:54.747562
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')

# Generated at 2022-06-26 12:54:57.697386
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    test_TheStarIE = TheStarIE()
    # test_TheStarIE.test_TheStarIE()

# Generated at 2022-06-26 12:55:07.114312
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-26 12:55:10.688142
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    thestar_ie = TheStarIE();
    assert thestar_ie is not None;


# Unit test to ensure the link could be parsed correctly

# Generated at 2022-06-26 12:55:14.069428
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""


if __name__ == '__main__':
    # Unit test for constructor of class TheStarIE
    test_TheStarIE()

# Generated at 2022-06-26 12:55:17.842780
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()._VALID_URL == TheStarIE._VALID_URL
    assert TheStarIE()._TEST == TheStarIE._TEST
    assert TheStarIE().BRIGHTCOVE_URL_TEMPLATE == TheStarIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:55:24.381745
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Test an invalid URL. This should fail and raise an exception
    try:
        TheStarIE("INVALID URL")
    except TypeError as e:
        assert "Invalid Constructor, Expecting a URL starting with http" in str(e)

    # Test creating a TheStarIE from a valid URL
    TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")

# Generated at 2022-06-26 12:55:53.455017
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    object = TheStarIE()
    assert object != None
    assert object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:56:02.800632
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
  
  # Let's create an instance of class TheStarIE
  thestar_ie = TheStarIE()
  print(type(thestar_ie))
  print(thestar_ie.ie_key())
  
  # Let's create an instance of class InfoExtractor
  info_extractor = InfoExtractor()
  print(type(info_extractor))
  print(info_extractor.ie_key())
  
  # Let's download an URL
  url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
  thestar_ie.extract(url)
  
  

# Generated at 2022-06-26 12:56:12.726475
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    star = TheStarIE()
    # We have a class object of TheStarIE
    assert isinstance(star, TheStarIE)
    url = "http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html"
    star._download_webpage(url, "4732393888001")
    # We have a webpage from TheStar
    assert star.webpage is not None
    # We also have a video id
    assert star.video_id == "4732393888001"
    # We have a class object of InfoExtractor
    assert isinstance(star, InfoExtractor)
    # We have a test information
    assert star._TEST['url'] == url

# Generated at 2022-06-26 12:56:21.241510
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE();
    test_url = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_display_id = 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    test_brightcove_id = '4732393888001'
    test_brightcove_url = 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=4732393888001'
    assert_equal(ie, TheStarIE())

# Generated at 2022-06-26 12:56:21.628984
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE()

# Generated at 2022-06-26 12:56:22.655484
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Expected values
    IDPI = 'thestar'
    # Instantiate the TheStarIE class
    TheStarIE()

# Generated at 2022-06-26 12:56:30.639283
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:56:33.977535
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE() 
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:56:36.157154
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    result = TheStarIE()._real_extract(TheStarIE._TEST['url'])
    assert result == TheStarIE._TEST['info_dict']

# Generated at 2022-06-26 12:56:37.198902
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE

# Generated at 2022-06-26 12:57:24.855268
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    """Unit test for constructor of class TheStarIE"""
    TheStarIE()
    print("Unit test for constructor of class TheStarIE completed")

if __name__ == '__main__':
    test_TheStarIE()

# Generated at 2022-06-26 12:57:26.526640
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    # Make sure that youtube-dl does not choke on this class.
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
    if ie != None:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-26 12:57:26.963304
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE()

# Generated at 2022-06-26 12:57:29.925056
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    obj = TheStarIE('https://www.thestar.com/')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:57:35.216874
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    tester = TheStarIE()

# Generated at 2022-06-26 12:57:36.155353
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.SUCCESS == True

# Generated at 2022-06-26 12:57:37.508033
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

# Generated at 2022-06-26 12:57:38.213446
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE.__name__ == 'TheStarIE'


# Generated at 2022-06-26 12:57:40.301554
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId={}'


# Generated at 2022-06-26 12:57:44.016572
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE("http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html")
    assert ie != None
    assert ie.get_netloc() != None
    assert ie.BRIGHTCOVE_URL_TEMPLATE != None
    assert ie.get_video_url(True) != None

# Generated at 2022-06-26 12:59:14.951436
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.extract_url("https://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html") == {"id": "4732393888001"}

# Generated at 2022-06-26 12:59:25.301993
# Unit test for constructor of class TheStarIE

# Generated at 2022-06-26 12:59:25.893384
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    return TheStarIE

# Generated at 2022-06-26 12:59:28.918996
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    assert TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html').name == 'TheStarIE'

# Generated at 2022-06-26 12:59:38.356580
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE('http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')

    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s')
    assert(ie._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html')
    assert(ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html')
   

# Generated at 2022-06-26 12:59:45.718993
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.thestar.com/life/2016/02/01/mankind-why-this-woman-started-a-men-s-skincare-line.html'
    assert ie._TEST['md5'] == '2c62dd4db2027e35579fefb97a8b6554'

# Generated at 2022-06-26 12:59:46.679035
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    assert str(ie).startswith('<TheStarIE ')

# Generated at 2022-06-26 12:59:50.073499
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    o = TheStarIE()
    assert o.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/794267642001/default_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:59:56.019498
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
	class_ = TheStarIE
	assert class_.__name__ == "TheStarIE"
	assert class_.__module__ == "youtube_dl.extractor.thestar"
	assert class_._VALID_URL == r'https?://(?:www\.)?thestar\.com/(?:[^/]+/)*(?P<id>.+)\.html'

# Generated at 2022-06-26 12:59:57.398260
# Unit test for constructor of class TheStarIE
def test_TheStarIE():
    ie = TheStarIE()
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie._VALID_URL