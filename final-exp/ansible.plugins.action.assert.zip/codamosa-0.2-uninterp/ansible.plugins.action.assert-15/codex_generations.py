

# Generated at 2022-06-17 08:38:33.033297
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:38:34.819085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:38:42.799476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:38:52.685509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet=False, success_msg='success_msg', that='that')),
                                 connection=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)

    # Test with invalid arguments

# Generated at 2022-06-17 08:39:04.133670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with fail_msg
    fail_msg = 'Assertion failed'
    task_args = {'fail_msg': fail_msg}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args
    assert action_module._task.args['fail_msg'] == fail_msg

    # test with msg
    msg = 'Assertion failed'
    task_args = {'msg': msg}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args

# Generated at 2022-06-17 08:39:16.283807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='assert',
            module_args=dict(
                that=['a == b', 'c == d'],
                msg='Assertion failed',
                fail_msg='Assertion failed',
                success_msg='All assertions passed',
                quiet=False
            )
        )
    )

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock ansible_vars
    ansible_vars = dict()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock

# Generated at 2022-06-17 08:39:30.820428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg and success_msg as string
    task_args = {'fail_msg': 'failure', 'success_msg': 'success', 'that': '1 == 1'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=None)
    assert result['msg'] == 'success'
    assert result['changed'] == False

    task_args = {'fail_msg': 'failure', 'success_msg': 'success', 'that': '1 == 2'}

# Generated at 2022-06-17 08:39:38.199116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:39:39.417779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:39:51.782267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'fail_msg': 'Assertion failed', 'that': '1 == 1'}

    # Create a mock loader
    loader = mock.Mock()

    # Create a mock templar
    templar = mock.Mock()

    # Create a mock module_utils
    module_utils = mock.Mock()

    # Create a mock connection
    connection = mock.Mock()

    # Create a mock play context
    play_context = mock.Mock()

    # Create a mock AnsibleModule
    AnsibleModule = mock.Mock()

    # Create a mock AnsibleModule.fail_json
    fail_json = mock.Mock()

    # Create a mock AnsibleModule.exit_json
    exit_json = mock.M

# Generated at 2022-06-17 08:40:10.713690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C


# Generated at 2022-06-17 08:40:13.809363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:40:20.429832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with arguments
    am = ActionModule(None, None, TRANSFERS_FILES=True, _VALID_ARGS=frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that', 'foo')))
    assert am.TRANSFERS_FILES == True
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that', 'foo'))

# Generated at 2022-06-17 08:40:27.649931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a dictionary to pass to the run method
    task_vars = dict()

    # Create a dictionary to pass to the run method
    tmp = dict()

    # Create a dictionary to pass to the run method
    task_vars = dict()

    # Create a dictionary to pass to the run method
    tmp = dict()

    # Create a dictionary to pass to the run method
    task_vars = dict()

    # Create a dictionary to pass to the run method
    tmp = dict()

    # Create a dictionary to pass to the run method
    task_vars = dict()

    # Create a dictionary to pass to the run method
    tmp = dict()

    # Create a dictionary to pass to the run method
    task_vars = dict()

    # Create

# Generated at 2022-06-17 08:40:40.661982
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:48.410270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:41:00.214128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a dict to pass to the run method
    task_vars = dict()

    # Create a dict to pass to the run method
    tmp = dict()

    # Create a dict to pass to the run method
    task_vars = dict()

    # Create a dict to pass to the run method
    tmp = dict()

    # Create a dict to pass to the run method
    task_vars = dict()

    # Create a dict to pass to the run method
    tmp = dict()

    # Create a dict to pass to the run method
    task_vars = dict()

    # Create a dict to pass to the run method
    tmp = dict()

    # Create a dict to pass to the run method
    task_vars = dict()

    # Create

# Generated at 2022-06-17 08:41:04.947082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:41:16.577471
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:30.513030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = 'assert'
    task['args'] = dict()
    task['args']['that'] = 'ansible_os_family == "RedHat"'
    task['args']['msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False

    # Create a mock task_vars
    task_vars = dict()
    task_vars['ansible_os_family'] = 'RedHat'

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock action_module
    action_

# Generated at 2022-06-17 08:41:55.975411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:41:57.234451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:42:04.839230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:42:16.404291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:42:17.998362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 08:42:28.564238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"'}

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock ActionModule
    action_module = ActionModule(task, loader, templar)

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Check the result
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:42:36.421269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:42:39.394188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:42:49.347766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    action_module = ActionModule()
    action_module._task = {'args': {'fail_msg': 'Assertion failed'}}
    action_module._task.args['that'] = '1 == 2'
    result = action_module.run()
    assert result['failed']
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'

    # Test with msg
    action_module = ActionModule()
    action_module._task = {'args': {'msg': 'Assertion failed'}}
    action_module._task.args['that'] = '1 == 2'
    result = action_module.run()
    assert result['failed']

# Generated at 2022-06-17 08:42:52.660727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:43:38.296387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule(task=dict(args=dict(that=['1==1', '2==2'], fail_msg='Assertion failed', success_msg='All assertions passed', quiet=False)), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Call method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:43:47.796849
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:43:56.973599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'that': '1 == 1'}
    task.action = 'assert'

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock play context object
    play_context = MockPlayContext()

    # Create a mock action plugin object
    action_plugin = ActionModule(task, connection, play_context, loader=loader, templar=templar, module_utils=module_utils)

    # Test the run method
    result = action_plugin.run(task_vars={})

# Generated at 2022-06-17 08:44:05.460757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'that': 'foo', 'fail_msg': 'failed'}
    task_vars = {'foo': False}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars)
    assert result['failed']
    assert result['msg'] == 'failed'

    # Test with msg
    task_args = {'that': 'foo', 'msg': 'failed'}
    task_vars = {'foo': False}

# Generated at 2022-06-17 08:44:09.707844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:44:15.920425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None, None, None, None, None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:44:25.259451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:44:33.206237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:44:35.958492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None


# Generated at 2022-06-17 08:44:47.289429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:45:48.361583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Set the module_utils.parsing.convert_bool.boolean method return value
    convert_bool.boolean.return_value = False

    # Set the module_utils.parsing.convert_bool attribute
    module_utils.parsing.convert_bool = convert_bool

    # Set the module_utils.six.string_types attribute
    module_utils.six.string_types = string_

# Generated at 2022-06-17 08:45:59.264278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:46:02.506139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:46:04.364837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:46:11.976946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock AnsibleModule
    AnsibleModule = MockAnsibleModule()
    # Create a mock AnsibleModule
    AnsibleError = MockAnsibleError()
    # Create a mock AnsibleModule
    Conditional = MockConditional()

    # Create a new instance of ActionModule

# Generated at 2022-06-17 08:46:18.389960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:46:31.532355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:46:40.333448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    # Create a task
    task = Task()
    task.action = 'fail'
    task.args

# Generated at 2022-06-17 08:46:41.173707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 08:46:52.951321
# Unit test for constructor of class ActionModule