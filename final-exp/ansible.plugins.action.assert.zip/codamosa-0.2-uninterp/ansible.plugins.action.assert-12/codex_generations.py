

# Generated at 2022-06-17 08:38:27.930878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(that=['foo', 'bar'])))
    assert action._task.args['that'] == ['foo', 'bar']

# Generated at 2022-06-17 08:38:39.932584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': 'ansible_facts["distribution"] == "Ubuntu"'}
    am = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {'ansible_facts': {'distribution': 'Ubuntu'}}
    result = am.run(task_vars=task_vars)
    assert result['failed'] is False
    assert result['msg'] == 'All assertions passed'
    assert result['evaluated_to'] is True
    assert result['assertion'] == 'ansible_facts["distribution"] == "Ubuntu"'

# Generated at 2022-06-17 08:38:47.852458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:38:48.694845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:38:56.284712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:39:05.881571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that='1 == 1',
                fail_msg='Assertion failed'
            )
        )
    )
    action = ActionModule(task, dict())
    result = action.run(None, dict())
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'

    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that='1 == 2',
                fail_msg='Assertion failed'
            )
        )
    )
    action = ActionModule(task, dict())
    result = action.run(None, dict())
    assert result['failed'] == True

# Generated at 2022-06-17 08:39:17.607236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:39:31.052204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2'], msg='test message'))))
    assert module.run() == dict(changed=False, msg='test message')

    # Test with invalid arguments
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2'], msg=['test message', 1]))))
    assert module.run()['failed']

    # Test with invalid arguments
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2'], msg=['test message', 1]))))
    assert module.run()['failed']

   

# Generated at 2022-06-17 08:39:38.334043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Test the run method
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False
    assert result['changed'] == False

# Generated at 2022-06-17 08:39:46.589084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()
    # Create a task
    task = dict(action=dict(module='assert'))
    # Create a task_vars
    task_vars = dict()
    # Create a tmp
    tmp = None
    # Create an instance of AnsibleError
    ae = AnsibleError()
    # Create an instance of Conditional
    cond = Conditional()
    # Create an instance of string_types
    st = string_types()
    # Create an instance of boolean
    bo = boolean()
    # Create an instance of AnsibleError
    ae = AnsibleError()
    # Create an instance of AnsibleError
    ae = AnsibleError()
    # Create an instance of AnsibleError
    ae = AnsibleError()
    # Create an instance of AnsibleError

# Generated at 2022-06-17 08:39:57.628328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:40:05.770996
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:16.060475
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:30.546801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import copy

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

    from ansible.plugins.action import ActionBase
    from ansible.playbook.conditional import Conditional
   

# Generated at 2022-06-17 08:40:31.875185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:40:42.864053
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:43.408091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-17 08:40:53.162573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:41:00.826170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': '{{test_var}} == "test_value"'}
    task_vars = {'test_var': 'test_value'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'
    assert result['evaluated_to'] == True
    assert result['assertion'] == '{{test_var}} == "test_value"'


# Generated at 2022-06-17 08:41:05.671710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == ' Fail with custom message '
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:41:32.966971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:41:43.070659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 08:41:55.156173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    class FakeTask:
        def __init__(self):
            self.args = dict()

    # Create a fake loader
    class FakeLoader:
        def __init__(self):
            pass

    # Create a fake templar
    class FakeTemplar:
        def __init__(self):
            pass

    # Create a fake module_utils
    class FakeModuleUtils:
        def __init__(self):
            pass

        class Parsing:
            class ConvertBool:
                def __init__(self):
                    pass

                @staticmethod
                def boolean(value, strict=False):
                    return True

    # Create a fake action base
    class FakeActionBase:
        def __init__(self):
            self._task = FakeTask()
            self._loader = FakeLoader()

# Generated at 2022-06-17 08:41:56.063223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:42:02.292862
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:42:11.172086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '{{ test_var }}'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'test_var': 'test_value'}

    # Test the run method
    result = action_module.run(task_vars=task_vars)

    # Check the result
    assert result['failed'] == False
    assert result['changed'] == False

# Generated at 2022-06-17 08:42:21.741278
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:32.255030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlaybookExecutor
    pb_executor = PlaybookExecutor()

    # Create an instance of class PlaybookCLI
    pb_cli = PlaybookCLI()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

   

# Generated at 2022-06-17 08:42:34.692620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:42:39.322454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:43:22.939719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:43:30.139084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:43:32.242087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:43:33.094483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:43:44.750089
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:43:54.288687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:43:56.366629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:44:05.185667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:44:06.559899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(that=['a', 'b'])))

# Generated at 2022-06-17 08:44:19.332605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:45:22.364965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    module = ActionModule(task=dict(args=task_args), task_vars=task_vars)
    result = module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    module = ActionModule(task=dict(args=task_args), task_vars=task_vars)
    result = module.run(task_vars=task_vars)


# Generated at 2022-06-17 08:45:23.942395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(that=['a', 'b'])))

# Generated at 2022-06-17 08:45:26.188866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:45:32.498155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar)

    # Call method run
    result = action_module.run()

    # Assert that the result is correct
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:45:44.815899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:45:57.055053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:46:06.282908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = dict(
        fail_msg='fail_msg',
        that='that',
    )
    task_vars = dict()
    tmp = None
    result = dict(
        changed=False,
        msg='fail_msg',
        assertion='that',
        evaluated_to=False,
        failed=True,
    )

    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run(tmp, task_vars) == result

    # Test with msg
    task_args = dict(
        msg='msg',
        that='that',
    )
    task_vars = dict()
    tmp = None

# Generated at 2022-06-17 08:46:10.320885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:46:18.116923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['action'] = 'assert'
    task['args'] = dict()
    task['args']['that'] = ['1 == 1', '2 == 2']
    task['args']['msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock module_utils
    module_utils = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock AnsibleModule object
    am = dict()

    # Create a mock Ans

# Generated at 2022-06-17 08:46:27.518350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = Mock()

    # Create a mock templar
    templar = Mock()

    # Create a mock module_utils
    module_utils = Mock()

    # Create a mock action_base
    action_base = Mock()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Test run method
    action_module.run()

    # Test run method with fail_msg
    task.args = {'that': '1 == 1', 'fail_msg': 'fail_msg'}
    action_module.run()

    # Test run method with success_msg
    task.args