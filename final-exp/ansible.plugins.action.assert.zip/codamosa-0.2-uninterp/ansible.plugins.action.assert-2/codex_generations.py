

# Generated at 2022-06-17 08:38:32.046955
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:38:41.312739
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:38:51.987090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'test_var': 'test_value'}
    module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'test_var': 'test_value'}

# Generated at 2022-06-17 08:39:03.891350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'test_var': 'test_value'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == None
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'test_var': 'test_value'}
   

# Generated at 2022-06-17 08:39:10.545980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None

    # Test with parameters
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert module._task == dict()
    assert module._connection == dict()
    assert module._play_context == dict()
    assert module._loader == dict()
    assert module._templar == dict()
    assert module

# Generated at 2022-06-17 08:39:21.287386
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:33.088648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars


# Generated at 2022-06-17 08:39:39.930546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import isidentifierlist
   

# Generated at 2022-06-17 08:39:52.377401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars

# Generated at 2022-06-17 08:39:53.417896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:40:04.451598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:40:15.386125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Create a dictionary containing all the parameters required for method run
    args = {'fail_msg': 'Assertion failed', 'msg': 'Assertion failed', 'quiet': False, 'success_msg': 'All assertions passed', 'that': '{{ ansible_distribution }} == "CentOS"'}
    # Create a dictionary containing all the parameters required for method run
    task_vars = {'ansible_distribution': 'CentOS'}
    # Create an instance of class Conditional
    cond = Conditional(loader=None)
    # Create an instance of class Conditional
    cond = Conditional(loader=None)
   

# Generated at 2022-06-17 08:40:25.945354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    task = dict(action=dict(module='assert', fail_msg='Assertion failed'))
    am = ActionModule(task, dict())
    assert am.run(None, None) == dict(failed=True, msg='Assertion failed', assertion=None, evaluated_to=None, _ansible_verbose_always=True)

    # Test with msg
    task = dict(action=dict(module='assert', msg='Assertion failed'))
    am = ActionModule(task, dict())
    assert am.run(None, None) == dict(failed=True, msg='Assertion failed', assertion=None, evaluated_to=None, _ansible_verbose_always=True)

    # Test with success_msg

# Generated at 2022-06-17 08:40:32.474600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:40:43.286169
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:46.694695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:40:49.925115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-17 08:41:00.327281
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:41:04.321803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action='fail', args=dict(msg='test')))
    assert action.run() == dict(failed=True, msg='test')

# Generated at 2022-06-17 08:41:08.062069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:41:35.650068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:41:45.183503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:41:50.601984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule(task=dict(action=dict(module='assert')))
    assert module is not None

    # Test with args
    module = ActionModule(task=dict(action=dict(module='assert', args=dict(msg='test message'))))
    assert module is not None

# Generated at 2022-06-17 08:41:58.542730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys

# Generated at 2022-06-17 08:42:10.461354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['that'] = '{{ foo }} == bar'
    task['args']['fail_msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock module_utils
    module_utils = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Create a mock task_vars
    task

# Generated at 2022-06-17 08:42:20.202582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'assert'
    task['action']['__ansible_arguments__'] = dict()
    task['action']['__ansible_arguments__']['fail_msg'] = 'Assertion failed'
    task['action']['__ansible_arguments__']['msg'] = 'Assertion failed'
    task['action']['__ansible_arguments__']['quiet'] = False
    task['action']['__ansible_arguments__']['success_msg'] = 'All assertions passed'
    task['action']['__ansible_arguments__']['that'] = '1 == 1'

# Generated at 2022-06-17 08:42:29.288186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = dict(action=dict(module='assert'))
    # Create a mock play context

# Generated at 2022-06-17 08:42:40.381254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase(loader, templar, module_utils)

    # Create a mock action_module
    action_module = ActionModule(task, action_base._connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)

    # Test the run method
    result = action_module.run(None, None)

# Generated at 2022-06-17 08:42:51.237301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['fail_msg'] = 'fail_msg'
    task['args']['msg'] = 'msg'
    task['args']['quiet'] = 'quiet'
    task['args']['success_msg'] = 'success_msg'
    task['args']['that'] = 'that'

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock play context
    play_context = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock new_stdin
    new_stdin = dict()

    # Create a mock module_name
    module_name = dict()

    # Create a

# Generated at 2022-06-17 08:42:59.513166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"', 'fail_msg': 'Assertion failed'}

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar)

    # Run the method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Check the result
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'

# Unit

# Generated at 2022-06-17 08:43:45.433144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:43:54.516597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:44:03.952478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1', 'msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Create a mock task_vars
    task_vars = {}

    # Create a mock result
    result = {}

    # Call the run method of the action_module

# Generated at 2022-06-17 08:44:13.608073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:44:16.936449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None