

# Generated at 2022-06-17 08:38:31.030203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "Ubuntu"', 'fail_msg': 'Assertion failed', 'quiet': 'False'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean.strict
    strict = MockStrict()



# Generated at 2022-06-17 08:38:41.063187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    action_module = ActionModule(task=dict(args=dict(that=['1 == 2'], fail_msg='fail_msg')))
    result = action_module.run(task_vars=dict())
    assert result['failed'] == True
    assert result['msg'] == 'fail_msg'

    # Test with msg
    action_module = ActionModule(task=dict(args=dict(that=['1 == 2'], msg='msg')))
    result = action_module.run(task_vars=dict())
    assert result['failed'] == True
    assert result['msg'] == 'msg'

    # Test with success_msg
    action_module = ActionModule(task=dict(args=dict(that=['1 == 1'], success_msg='success_msg')))

# Generated at 2022-06-17 08:38:51.878057
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:03.809549
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:06.215393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:39:17.730389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'that': '1 == 1', 'fail_msg': '1 != 1'}

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock action_base object
    action_base = MockActionBase()

    # Create a mock action_module object
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert the

# Generated at 2022-06-17 08:39:31.269745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars


# Generated at 2022-06-17 08:39:32.424699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:39:39.682487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:39:44.177447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:40:01.439988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:40:03.519336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 08:40:14.802855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, module_utils)

    # Run the action plugin
    result = action_plugin.run(None, None)

    # Check the result
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:40:21.402204
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:22.947740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='assert', module_args=dict(that=['1==1', '2==2']))))

# Generated at 2022-06-17 08:40:32.861244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Set the module_utils.parsing.convert_bool attribute of the module_utils
    module_utils.parsing.convert_bool = convert_bool

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Set the boolean attribute of the convert_bool
    convert_bool.boolean = boolean

    # Create an instance of the ActionModule

# Generated at 2022-06-17 08:40:42.980957
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:52.455091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 08:41:01.687713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=dict(args=dict(that=['1==1'], msg='Assertion failed')))
    # Call method run of class ActionModule
    result = action_module.run()
    # Check if the result is correct
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'
    # Create an instance of class ActionModule
    action_module = ActionModule(task=dict(args=dict(that=['1==1'], msg='Assertion failed', success_msg='All assertions passed')))
    # Call method run of class ActionModule
    result = action_module.run()
    # Check if the result is correct
    assert result['failed'] == False

# Generated at 2022-06-17 08:41:06.554095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:41:28.575596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:41:38.363926
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:40.057341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None


# Generated at 2022-06-17 08:41:43.497369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:41:55.489771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object for class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for class Conditional
    mock_Conditional = Conditional(loader=None)

    # Create a mock object for class dict
    mock_dict = dict()

    # Create a mock object for class string_types
    mock_string_types = string_types()

    # Create a mock object for class boolean
    mock_boolean = boolean(value=None, strict=False)

    # Create a mock object for class list
    mock_list = list()

    # Create a mock

# Generated at 2022-06-17 08:42:03.601063
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:11.788335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test with arguments
    action_module = ActionModule(task=1, connection=2, play_context=3, loader=4, templar=5, shared_loader_obj=6)
    assert action_module is not None
    assert action_module._task == 1

# Generated at 2022-06-17 08:42:20.411418
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:27.123891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'foo'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create

# Generated at 2022-06-17 08:42:36.313615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule(
        task=dict(action=dict(module_name='assert', module_args=dict(that=['1 == 1', '1 == 2']))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Check if the instance is created properly
    assert action_module.task == dict(action=dict(module_name='assert', module_args=dict(that=['1 == 1', '1 == 2'])))
    assert action_module.connection is None
    assert action_module.play_context is None
    assert action_module.loader is None
    assert action_module.templar is None
    assert action_module.shared_loader_obj is None

# Generated at 2022-06-17 08:43:19.192872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Test the run method
    result = action_module.run()
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'
    assert result['assertion'] == None

# Generated at 2022-06-17 08:43:32.128218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Create a temporary file
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()

    # Create a task
    task = Task()
    task._role = Role()
    task.block = Block()
    task.block.parent_block = Play()._get_parent_block()
    task.args = dict(
        fail_msg='fail_msg',
        msg='msg',
        quiet=True,
        success_msg='success_msg',
        that='that',
    )

    # Create an action
    action = ActionModule(task, tmpfile.name)

    # Test the run method
    action

# Generated at 2022-06-17 08:43:39.670162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == None

    # Test with msg
    task_args = {'msg': 'Assertion failed'}

# Generated at 2022-06-17 08:43:47.055550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['a == b', 'b == c'], fail_msg='Assertion failed', success_msg='All assertions passed'))))
    assert module._task.action['module_name'] == 'assert'
    assert module._task.action['args']['that'] == ['a == b', 'b == c']
    assert module._task.action['args']['fail_msg'] == 'Assertion failed'
    assert module._task.action['args']['success_msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:43:56.918385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task == dict(action=dict())
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test with parameters
    action_module = ActionModule(task=dict(action=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action_module is not None
    assert action

# Generated at 2022-06-17 08:44:05.436612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import ishash

# Generated at 2022-06-17 08:44:14.284922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:44:17.168205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None