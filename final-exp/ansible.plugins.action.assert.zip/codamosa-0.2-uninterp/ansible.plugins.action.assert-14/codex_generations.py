

# Generated at 2022-06-17 08:38:28.133021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:38:40.008676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:38:47.594134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:38:49.947171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:39:03.201722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:39:05.181160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:39:17.051210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(that=['a == b', 'c == d'], fail_msg='failed', success_msg='success')),
                          connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert action.run() == dict(failed=True, evaluated_to=False, assertion='a == b', msg='failed')


# Generated at 2022-06-17 08:39:25.168348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:39:34.823935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"', 'msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Test the run method

# Generated at 2022-06-17 08:39:36.846344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    module = ActionModule()
    module.run()

# Generated at 2022-06-17 08:39:57.573783
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:05.738378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "Ubuntu"'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'Ubuntu'}

    # Run the run method
    result = action_module.run(task_vars=task_vars)

    # Check the result
    assert result['failed'] == False
    assert result['changed'] == False

# Generated at 2022-06-17 08:40:16.043029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock loader object
    class MockLoader:
        def __init__(self):
            self.path_exists_map = {}

        def path_exists(self, path):
            return self.path_exists_map[path]

    # Create a mock templar object
    class MockTemplar:
        def __init__(self):
            self.template_data = {}


# Generated at 2022-06-17 08:40:30.547530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils class
    class MockModuleUtils():
        def __init__(self):
            self.boolean = boolean

    # Create a mock object for the templar class
    class MockTemplar():
        def __init__(self):
            self.template = template

    # Create a mock object for the loader class
    class MockLoader():
        def __init__(self):
            self.load_from_file = load_from_file

    # Create a mock object for the task class

# Generated at 2022-06-17 08:40:40.487553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.loader import action_loader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
   

# Generated at 2022-06-17 08:40:48.289682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(msg='test')))
    assert action.fail_msg == 'test'
    assert action.success_msg == 'All assertions passed'
    assert action.quiet is False
    assert action.thats == []

    action = ActionModule(task=dict(args=dict(fail_msg='test')))
    assert action.fail_msg == 'test'
    assert action.success_msg == 'All assertions passed'
    assert action.quiet is False
    assert action.thats == []

    action = ActionModule(task=dict(args=dict(success_msg='test')))
    assert action.fail_msg == 'Assertion failed'
    assert action.success_msg == 'test'
    assert action.quiet is False
    assert action.thats == []

    action = ActionModule

# Generated at 2022-06-17 08:41:00.214874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 08:41:08.920232
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:17.599331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-17 08:41:31.247551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Templates
    templar = Templar(loader=loader)

    # Create an instance of class TaskVars
    task_vars = dict()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Playbook
    play_book = Playbook()



# Generated at 2022-06-17 08:41:55.322674
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:56.585007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='assert')))

# Generated at 2022-06-17 08:42:04.390242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:42:16.403745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create an action module
    action_module = ActionModule(task, connection, loader=loader, templar=templar, shared_loader_obj=loader, module_loader=loader, module_name='assert', module_args=dict(that='1 == 1'))

    # Run the action module
    result = action_module.run(task_vars=dict())

    # Check the result

# Generated at 2022-06-17 08:42:23.200133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Test with no fail_msg or msg
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'
    assert result['msg'] == 'Assertion failed'

    # Test with fail_msg


# Generated at 2022-06-17 08:42:30.728673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:42:43.614471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = ActionModule(task, loader, templar, module)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Test with fail_msg
    task.args = {'that': '1 == 1', 'fail_msg': 'Assertion failed'}
    result = action_plugin.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['changed'] == False

# Generated at 2022-06-17 08:42:51.748059
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:57.785628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.action == dict()
    assert action_module._task.args == dict()
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None
    assert action_module._connection is None
    assert action_module._play_context is None

    # Test with args
    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:43:08.213271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:43:55.931189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:44:05.173741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    module = ActionModule(task=dict(args=task_args), task_vars=task_vars)
    result = module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    module = ActionModule(task=dict(args=task_args), task_vars=task_vars)
    result = module.run(task_vars=task_vars)


# Generated at 2022-06-17 08:44:14.113568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    mock_module = type('AnsibleModule', (object,), dict(
        run_command=lambda *_, **__: (0, '', ''),
        fail_json=lambda *_, **__: None,
        exit_json=lambda *_, **__: None,
        check_mode=lambda: False,
        params=dict()
    ))()

    # Create a mock object for the loader
    mock_loader = type('AnsibleLoader', (object,), dict(
        path_dwim=lambda *_: '/dev/null'
    ))()

    # Create a mock object for the templar
    mock_templar = type('AnsibleTemplar', (object,), dict(
        template=lambda *_: None
    ))()

    #

# Generated at 2022-06-17 08:44:17.399767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that='1 == 1'))))
    assert module is not None
