

# Generated at 2022-06-17 08:38:30.916618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:38:41.063091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class Conditional
    mock_Conditional = Conditional(loader=None)

    # Create a mock object of class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object of class string_types
    mock_string_types = string_types

    # Create a mock object of class boolean
    mock_boolean = boolean

    # Create a mock object of class dict
    mock_dict = dict()

    # Create a mock object of class list
    mock_list = list()

    # Create a mock object of class type

# Generated at 2022-06-17 08:38:51.877577
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:03.809408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "Ubuntu"', 'msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'Ubuntu'}

    # Call method run of class ActionModule
    action_module.run(None, task_vars)

   

# Generated at 2022-06-17 08:39:10.459984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"'}

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action plugin
    action_plugin = ActionModule(task, play_context, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Test with success_msg
    task.args['success_msg'] = 'All assertions passed'
    result = action

# Generated at 2022-06-17 08:39:21.222485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Test with fail_msg
    task.args = {'that': '1 == 1', 'fail_msg': 'Assertion failed'}
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'

    # Test

# Generated at 2022-06-17 08:39:33.002603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    task_args = {'fail_msg': 'This is a fail message'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run()['msg'] == 'This is a fail message'

    # Test with msg
    task_args = {'msg': 'This is a fail message'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run()['msg'] == 'This is a fail message'

    # Test with success_msg

# Generated at 2022-06-17 08:39:45.959900
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:00.073008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no fail_msg or msg
    action_module = ActionModule(task=dict(args=dict(that=['foo'])), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run()['msg'] == 'Assertion failed'

    # Test with fail_msg
    action_module = ActionModule(task=dict(args=dict(that=['foo'], fail_msg='fail')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run()['msg'] == 'fail'

    # Test with msg

# Generated at 2022-06-17 08:40:13.306393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import ishashable

# Generated at 2022-06-17 08:40:22.794795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')))

# Generated at 2022-06-17 08:40:24.639973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 08:40:26.768538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:40:34.114081
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:37.632352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:40:42.554222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == ' Fail with custom message '
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:40:52.385423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict()
    task.args['that'] = ['a == b', 'c == d']

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create an instance of the action plugin
    action_plugin = ActionModule(task, connection, loader=loader, templar=templar, shared_loader_obj=loader, module_executor=module)

    # Run the action plugin
    result = action_plugin.run(task_vars=dict())

    # Check the result
    assert result['failed'] == True

# Generated at 2022-06-17 08:40:53.912572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:40:57.927406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 08:41:07.601330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Set the attributes of task
    task.args = {'that': 'ansible_distribution == "Ubuntu"'}

    # Set the attributes of action_module
    action_module._task = task
    action_module._loader = None
    action_module._templar = None

    # Call method run of action_module
    result = action_module.run()

    # Check the result
    assert(result['failed'] == False)
    assert(result['msg'] == 'All assertions passed')
    assert(result['evaluated_to'] == True)
    assert(result['assertion'] == 'ansible_distribution == "Ubuntu"')

# Generated at 2022-06-17 08:41:33.907471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': '1 == 2'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=None)
    assert result['failed']
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == '1 == 2'

    # Test with fail_msg as list
    task_args = {'fail_msg': ['Assertion failed', 'Assertion failed again'], 'that': '1 == 2'}

# Generated at 2022-06-17 08:41:41.642006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:41:54.486910
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:02.752647
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:06.247504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:42:09.710303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2']))))
    assert module

# Generated at 2022-06-17 08:42:19.923173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import get_vars

# Generated at 2022-06-17 08:42:29.287578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = dict(
        fail_msg='fail_msg',
        that='1 == 1'
    )
    task_vars = dict()
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'

    task_args = dict(
        fail_msg='fail_msg',
        that='1 == 2'
    )
    task_vars = dict()

# Generated at 2022-06-17 08:42:40.380579
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:51.237525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 08:43:42.152018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:43:45.859890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:43:50.436396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:44:02.648490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a dictionary containing arguments for method run
    options = {
        'fail_msg': 'Assertion failed',
        'msg': 'Assertion failed',
        'quiet': False,
        'success_msg': 'All assertions passed',
        'that': '{{ ansible_distribution }} == "Ubuntu"',
    }

    # Create a dictionary containing the return value of method run

# Generated at 2022-06-17 08:44:13.366135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars

# Generated at 2022-06-17 08:44:24.031174
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:44:40.017285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Host
    host = Host()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class DataLoader

# Generated at 2022-06-17 08:44:41.010871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:44:42.338066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 08:44:49.756488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"'}

    # Create a mock host
    host = MockHost()
    host.get_vars.return_value = {'ansible_distribution': 'CentOS'}

    # Create a mock play context
    play_context = MockPlayContext()
    play_context.check_mode = False

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, play_context, loader=loader, templar=templar)

    # Run the method

# Generated at 2022-06-17 08:45:57.513478
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:46:06.702807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that=['foo == bar', 'foo == baz'],
                fail_msg='foo is not bar or baz',
                success_msg='foo is bar or baz',
                quiet=True
            )
        )
    )

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play context
    play_context = dict()

    # Create a mock AnsibleModule object
    am = dict()

    # Create a mock AnsibleModule object
    am = dict()

    # Create a mock AnsibleModule object
    am = dict()

    # Create a

# Generated at 2022-06-17 08:46:15.935066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool object
    convert_bool = MockConvertBool()

    # Create a mock module_utils.parsing.convert_bool.boolean object
    boolean = MockBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean object
    boolean.return_value = False

    # Create a mock module_utils.parsing.convert_bool object


# Generated at 2022-06-17 08:46:26.696536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:46:34.140814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    tmp = None
    m = ActionModule(task=dict(action=dict(fail_msg='Assertion failed'), args=task_args),
                     connection=dict(module_implementation_preferences=['shell', 'winrm', 'paramiko']),
                     task_vars=task_vars,
                     loader=dict(path_loader=None),
                     templar=dict(variables=task_vars),
                     shared_loader_obj=None)
    result = m.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with

# Generated at 2022-06-17 08:46:40.810641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-17 08:46:52.572813
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:57.471473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:47:01.146887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(module_name='assert')),
                          connection=dict(host='localhost'),
                          play_context=dict(remote_user='root'),
                          loader=dict(),
                          templar=dict(),
                          shared_loader_obj=dict())
    assert action is not None


# Generated at 2022-06-17 08:47:02.285832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)