

# Generated at 2022-06-17 08:38:40.007594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['that'] = '{{ test_var }}'
    task['args']['fail_msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False

    # Create a mock task_vars
    task_vars = dict()
    task_vars['test_var'] = True

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, action_base)

   

# Generated at 2022-06-17 08:38:51.453734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:39:03.599373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import json

    class TestCallbackModule(CallbackBase):
        """
        Test callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK

# Generated at 2022-06-17 08:39:06.793902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:39:18.860823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='assert',
            module_args=dict(
                that='{{ foo }} == "bar"',
                fail_msg='{{ foo }} is not "bar"',
                success_msg='{{ foo }} is "bar"',
                quiet=True
            )
        )
    )

    # Create a mock play context
    play_context = dict(
        check_mode=False,
        diff=False,
        basedir='/home/user/ansible'
    )

    # Create a mock loader
    loader = dict(
        basedir='/home/user/ansible',
        get_basedir=lambda x, y: '/home/user/ansible'
    )

    # Create a mock templar

# Generated at 2022-06-17 08:39:31.790587
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:39.237233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    fail_msg = 'fail_msg'
    action_module = ActionModule(task=dict(args=dict(fail_msg=fail_msg)))
    assert action_module._task.args['fail_msg'] == fail_msg

    # Test with msg
    msg = 'msg'
    action_module = ActionModule(task=dict(args=dict(msg=msg)))
    assert action_module._task.args['msg'] == msg

    # Test with success_msg
    success_msg = 'success_msg'
    action_module = ActionModule(task=dict(args=dict(success_msg=success_msg)))
    assert action_module._task.args['success_msg'] == success_msg

    # Test with quiet
    quiet = True

# Generated at 2022-06-17 08:39:46.644135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:40:00.411873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that=['ansible_distribution == "CentOS"', 'ansible_distribution == "Ubuntu"'],
                fail_msg='Assertion failed',
                success_msg='All assertions passed',
                quiet=False
            )
        ),
        register='assert_result'
    )

    # Create a fake loader
    loader = dict()

    # Create a fake templar
    templar = dict()

    # Create a fake task_vars
    task_vars = dict(
        ansible_distribution='CentOS'
    )

    # Create a fake play_context
    play_context = dict(
        check_mode=False
    )

    # Create a fake Ansible

# Generated at 2022-06-17 08:40:13.342138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task_obj = mock.Mock()
    task_obj.action = 'assert'
    task_obj.args = {'that': '1 == 1'}

    # Create a mock loader object
    loader_obj = mock.Mock()

    # Create a mock templar object
    templar_obj = mock.Mock()

    # Create a mock module_utils object
    module_utils_obj = mock.Mock()

    # Create a mock action_base object
    action_base_obj = mock.Mock()
    action_base_obj.run.return_value = {'failed': False, 'changed': False, 'msg': 'All assertions passed'}

    # Create a mock action_module object

# Generated at 2022-06-17 08:40:27.682419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            fail_msg='Assertion failed',
            that='{{ foo }} == "bar"',
        ),
        args=dict(
            fail_msg='Assertion failed',
            that='{{ foo }} == "bar"',
        ),
    )
    action = ActionModule(task, dict(foo='bar'))
    result = action.run(task_vars=dict(foo='bar'))
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'

    # Test with msg

# Generated at 2022-06-17 08:40:31.115768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:40:42.417803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'foo'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action plugin
    action_plugin = ActionModule(task, loader, templar, module_utils)

    # Create a mock result
    result = MockResult()

    # Call method run of class ActionModule
    action_plugin.run(result)

    # Check if method run of class ActionModule called method run of class ActionBase
    assert action_plugin.action_base.run.called

    # Check if method run of class ActionModule called method evaluate_conditional of class Conditional
   

# Generated at 2022-06-17 08:40:52.336214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'vagrant'
    play_context.connection

# Generated at 2022-06-17 08:41:02.974040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            fail_msg='Assertion failed',
            that='1 == 2',
        ),
    )
    task_vars = dict()
    action = ActionModule(task, task_vars)
    result = action.run(task_vars)
    assert result['failed']
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == '1 == 2'
    assert result['evaluated_to'] == False

    # Test with msg
    task = dict(
        action=dict(
            module='assert',
            msg='Assertion failed',
            that='1 == 2',
        ),
    )
    task_vars = dict()

# Generated at 2022-06-17 08:41:11.080649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:41:19.228935
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:41:33.026331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    action = ActionModule()
    action._task.args = {'fail_msg': 'fail_msg', 'that': '1 == 2'}
    result = action.run()
    assert result['failed'] == True
    assert result['msg'] == 'fail_msg'
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'

    # Test with msg
    action = ActionModule()
    action._task.args = {'msg': 'msg', 'that': '1 == 2'}
    result = action.run()
    assert result['failed'] == True
    assert result['msg'] == 'msg'
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'

    # Test with success_msg
   

# Generated at 2022-06-17 08:41:43.070231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MagicMock()
    task.args = {'that': 'ansible_distribution == "Ubuntu"'}

    # Create a mock loader
    loader = MagicMock()

    # Create a mock templar
    templar = MagicMock()

    # Create a mock module_utils
    module_utils = MagicMock()

    # Create a mock connection
    connection = MagicMock()

    # Create a mock ActionModule
    action_module = ActionModule(task, connection, loader=loader, templar=templar, module_utils=module_utils)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'Ubuntu'}

    # Test the run method

# Generated at 2022-06-17 08:41:55.157928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {}
    tmp = None
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == None

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {}
    tmp = None

# Generated at 2022-06-17 08:42:19.795975
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:21.218102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-17 08:42:32.044633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    fail_msg = 'Assertion failed'
    task = dict(action=dict(module='assert', fail_msg=fail_msg))
    action = ActionModule(task, dict())
    assert action._task.args['fail_msg'] == fail_msg

    # Test with msg
    msg = 'Assertion failed'
    task = dict(action=dict(module='assert', msg=msg))
    action = ActionModule(task, dict())
    assert action._task.args['fail_msg'] == msg

    # Test with success_msg
    success_msg = 'All assertions passed'
    task = dict(action=dict(module='assert', success_msg=success_msg))
    action = ActionModule(task, dict())
    assert action._task.args['success_msg'] == success_msg



# Generated at 2022-06-17 08:42:43.774795
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:51.811074
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:53.784195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['foo == bar', 'foo == baz']))))

# Generated at 2022-06-17 08:43:04.999167
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:43:07.476470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:43:18.604784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    module = ActionModule()

    # Create a mock object for the task
    task = mock.Mock()
    task.args = {'that': 'a == b', 'fail_msg': 'a is not equal to b'}

    # Create a mock object for the loader
    loader = mock.Mock()

    # Create a mock object for the templar
    templar = mock.Mock()

    # Create a mock object for the task_vars
    task_vars = mock.Mock()

    # Create a mock object for the conditional
    cond = mock.Mock()
    cond.when = [task.args['that']]

    # Create a mock object for the result
    result = mock.Mock()
    result.failed = False

# Generated at 2022-06-17 08:43:21.167237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:44:05.128470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import ishashable

# Generated at 2022-06-17 08:44:14.111442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:44:24.543960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    fail_msg = 'fail_msg'
    task_args = {'fail_msg': fail_msg}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args
    result = action_module.run(tmp=None, task_vars=None)
    assert result['msg'] == fail_msg
    assert result['failed'] == True

    # Test with msg
    msg = 'msg'
    task_args = {'msg': msg}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_

# Generated at 2022-06-17 08:44:34.446676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:44:36.496089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:44:48.213992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': '1 == 2'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'

    # Test with msg
    task_args = {'msg': 'Assertion failed', 'that': '1 == 2'}

# Generated at 2022-06-17 08:44:56.005399
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:44:57.644931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:45:07.789552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'test_var': 'test_value'}
    tmp = None
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == 'test_var == "test_value"'
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}

# Generated at 2022-06-17 08:45:17.470017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils.basic.AnsibleModule class
    # with default return values for all methods.
    mock_AnsibleModule = mock.Mock()
    mock_AnsibleModule.run_command = mock.Mock(return_value=(0, '', ''))
    mock_AnsibleModule.fail_json = mock.Mock(return_value=dict(failed=True))
    mock_AnsibleModule.exit_json = mock.Mock(return_value=dict(changed=True))

    # Create a mock object for the module_utils.parsing.convert_bool.boolean
    # class with default return values for all methods.
    mock_boolean = mock.Mock()
    mock_boolean.return_value = True

    # Create a mock object for the ansible

# Generated at 2022-06-17 08:46:18.308996
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:46:27.637540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for class ActionModule
    mock_ActionModule = ActionModule(None, None, None, None, None, None)

    # Create a mock object for class Conditional

# Generated at 2022-06-17 08:46:36.870851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "Ubuntu"'}
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils.parsing.convert_bool
    module_utils.parsing.convert_bool = MockConvertBool()
    # Create a mock action_base
    action_base = MockActionBase()
    # Create a mock conditional
    conditional = MockConditional()
    # Create a mock conditional.evaluate_conditional
    conditional.evaluate_conditional = MockEvaluateConditional()
    # Create an instance of ActionModule

# Generated at 2022-06-17 08:46:46.626593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['fail_msg'] = 'fail_msg'
    task['args']['msg'] = 'msg'
    task['args']['quiet'] = 'quiet'
    task['args']['success_msg'] = 'success_msg'
    task['args']['that'] = 'that'

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock ansible module
    ansible_module = dict()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = dict()

    # Create a mock result
    result = dict()

    # Create a mock action

# Generated at 2022-06-17 08:46:56.644318
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:47:08.475222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:47:15.919778
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:47:29.849400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'foo is bar', 'fail_msg': 'foo is not bar'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'foo': 'bar'}

    # Call the run method
    result = action_module.run(task_vars=task_vars)

    # Assert the result

# Generated at 2022-06-17 08:47:37.651688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class Conditional
    conditional = Conditional(loader=None)

    # Create a variable for the parameter 'tmp'
    tmp = None

    # Create a variable for the parameter 'task_vars'
    task_vars = dict()

    # Call method run of ActionModule with the parameters: tmp, task_vars
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    # Check if the result we got is equal to the result we expected
    assert result == {}

# Generated at 2022-06-17 08:47:40.985332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass