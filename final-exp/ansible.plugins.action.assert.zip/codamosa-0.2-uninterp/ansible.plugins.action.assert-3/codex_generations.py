

# Generated at 2022-06-17 08:38:39.380970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with arguments
    am = ActionModule(TRANSFERS_FILES=True, _VALID_ARGS=frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that', 'test')))
    assert am.TRANSFERS_FILES == True
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that', 'test'))

# Generated at 2022-06-17 08:38:49.163416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:38:56.358919
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:03.651858
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:16.239404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.errors import Ansible

# Generated at 2022-06-17 08:39:30.815754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:39:39.055693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1', 'fail_msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean.boolean
    boolean.boolean = MockBooleanBoolean()

    # Create a mock module_utils

# Generated at 2022-06-17 08:39:51.343315
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:02.086345
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:40:11.189395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:40:25.377910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:40:28.091125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None) is not None

# Generated at 2022-06-17 08:40:40.706336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 08:40:48.440185
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:53.638276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_os_family == "RedHat"'}

    # Create a mock host
    host = MockHost()
    host.get_vars.return_value = {'ansible_os_family': 'RedHat'}

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task result
    result = MockTaskResult()

    # Create the action plugin
    action_plugin = ActionModule(task, play_context, loader, templar, result)

    # Run the action plugin
    action_plugin.run(None, None)

    # Check the

# Generated at 2022-06-17 08:41:01.147388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['that'] = 'foo'
    task['args']['fail_msg'] = 'foo'
    task['args']['success_msg'] = 'foo'
    task['args']['quiet'] = 'foo'

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = dict()

    # Create a mock result
    result = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock action_module

# Generated at 2022-06-17 08:41:03.437893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:41:16.432413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:41:30.440813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:41:39.291972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': ['a == b', 'a == c']}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = {'a': 'b'}

    # Call the run method of the action module
    result = action_module.run(task_vars=task_vars)

    # Assert the result

# Generated at 2022-06-17 08:42:00.610606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    action_module = ActionModule()
    action_module._task = {'args': {'fail_msg': 'fail_msg', 'that': 'that'}}
    action_module._templar = {'template': 'template'}
    action_module._loader = {'load': 'load'}
    result = action_module.run()
    assert result['msg'] == 'fail_msg'
    assert result['evaluated_to'] == False
    assert result['assertion'] == 'that'

    # Test with msg
    action_module = ActionModule()
    action_module._task = {'args': {'msg': 'msg', 'that': 'that'}}
    action_module._templar = {'template': 'template'}

# Generated at 2022-06-17 08:42:11.039525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:42:16.659102
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:30.009829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import get_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 08:42:41.038184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}
    action_module = ActionModule(task=dict(args=task_args), task_vars=task_vars)
    result = action_module.run()
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == 'False'
    assert result['msg'] == 'Assertion failed'

    # test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'ansible_check_mode': False}

# Generated at 2022-06-17 08:42:51.482698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == None
    assert result['evaluated_to'] == None

    # Test with fail_msg and success_msg
    task_args = {'fail_msg': 'Assertion failed', 'success_msg': 'All assertions passed'}

# Generated at 2022-06-17 08:42:59.624248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:43:09.548617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_2 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_3 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_4 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ans

# Generated at 2022-06-17 08:43:16.219210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2']))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action is not None

# Generated at 2022-06-17 08:43:26.969141
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:44:13.326178
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:44:14.343095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:44:17.947124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False