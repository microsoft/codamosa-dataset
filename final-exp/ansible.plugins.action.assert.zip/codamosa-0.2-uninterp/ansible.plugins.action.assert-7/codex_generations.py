

# Generated at 2022-06-17 08:38:31.163934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:38:41.128111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars import Vars
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.handler_task import HandlerTask

# Generated at 2022-06-17 08:38:51.905352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None
    assert am._task is None
    assert am._connection is None
    assert am._play_context is None
    assert am._loader is None
    assert am._templar is None
    assert am._shared_loader_obj is None
    assert am._task_vars is None
    assert am._tmp is None
    assert am._result is None
    assert am._task_vars_files is None
    assert am._task_vars_file_params is None
    assert am._task_vars_file_args is None
    assert am._task_vars_file_ignore_errors is None
    assert am

# Generated at 2022-06-17 08:39:03.850148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_os_family == "RedHat"'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock host
    host = MockHost()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ans

# Generated at 2022-06-17 08:39:10.518262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:39:21.254812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:39:33.041602
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:39:37.569547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:39:46.539819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:40:00.368767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:40:09.224523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:40:19.665714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:40:26.972617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars


# Generated at 2022-06-17 08:40:40.661770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Templates
    templar = Templar(loader=loader, variables=variable_manager)

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Play

# Generated at 2022-06-17 08:40:48.411190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and a mock templar
    task = MockTask()
    templar = MockTemplar()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Test with fail_msg
    task.args = dict(that='1 == 1', fail_msg='Assertion failed')
    result = action_module.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'

    # Test with

# Generated at 2022-06-17 08:41:00.214876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Create a temporary file for test
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write(b"#!/usr/bin/python\nprint 'content'")
    tmp_file.seek(0)

    # Create a task with a temporary action
    task = Task()
    task._role = Role()
    task.action = 'core'
    task.args = {'_raw_params': 'fail', '_uses_shell': False, '_raw_file_name': tmp_file.name}
    task._block = Block(parent_block=Play()._entries)

# Generated at 2022-06-17 08:41:03.361493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:41:16.439502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()

    # create a mock play
    play = MockPlay()

    # create a mock loader
    loader = MockLoader()

    # create a mock templar
    templar = MockTemplar()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    connection = MockConnection()

    # create a mock module_utils
    shell = MockShell()

    # create a mock module_utils
    action_base = MockActionBase()

    # create a mock module_utils
    action_module = MockActionModule()

    # create a mock module_utils
    conditional = MockConditional()

    # create a mock module_utils
    ansible_error = MockAnsibleError()

    # create a mock module_utils

# Generated at 2022-06-17 08:41:17.356010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:41:30.859036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:41:56.029540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(action=dict(module='assert', fail_msg='Assertion failed'))
    task_vars = dict()
    tmp = None
    am = ActionModule(task, tmp, task_vars)
    result = am.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == None

    # Test with fail_msg and that
    task = dict(action=dict(module='assert', fail_msg='Assertion failed', that='1 == 2'))
    task_vars = dict()
    tmp = None
    am = ActionModule(task, tmp, task_vars)

# Generated at 2022-06-17 08:42:03.992595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class Conditional
    mock_Conditional = Conditional(loader=None)

    # Create a mock object of class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object of class string_types
    mock_string_types = string_types

    # Create a mock object of class boolean
    mock_boolean = boolean(value=None, strict=None)

    # Create a mock object of class dict
    mock_dict = dict()

    # Create a mock object of class list
    mock_list = list()

    # Create a mock object

# Generated at 2022-06-17 08:42:08.990503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:42:19.568309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'assert'
    task['action']['__ansible_arguments__'] = dict()
    task['action']['__ansible_arguments__']['fail_msg'] = 'Assertion failed'
    task['action']['__ansible_arguments__']['msg'] = 'Assertion failed'
    task['action']['__ansible_arguments__']['quiet'] = False
    task['action']['__ansible_arguments__']['success_msg'] = 'All assertions passed'
    task['action']['__ansible_arguments__']['that'] = ['1 == 1']

    # Create a mock task_

# Generated at 2022-06-17 08:42:31.431380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Template
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of the instance of class Task
    task.args = {'fail_msg': 'Assertion failed', 'msg': 'Assertion failed', 'quiet': False, 'success_msg': 'All assertions passed', 'that': '{{ ansible_distribution }} == "Ubuntu"'}
    task.action = 'assert'

# Generated at 2022-06-17 08:42:43.695844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class VariableManager
    variable_manager = VariableManager()
    # Create an instance of class Inventory
    inventory = Inventory()
    # Create an instance of class PlaybookExecutor
    play_book_executor = PlaybookExecutor()
    # Create an instance of class Play
    play = Play()
    # Create an instance of class Playbook
    play_book = Playbook()
    # Create an instance of class PlaybookExecutor
    play_book_executor = PlaybookExecutor()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class

# Generated at 2022-06-17 08:42:47.959368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:42:59.315354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 08:43:08.332352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:43:16.135087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the instance
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Initialize the test variables
    tmp = None
    task_vars = dict()

    # Call the method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Assert the result
    assert(result == None)

# Generated at 2022-06-17 08:44:02.609447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Test the run method
    result = action_module.run()
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:44:07.646365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:44:09.736047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:44:21.698002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Set the connection attribute of the Runner object
    runner.connection = connection

    # Set the variable_manager attribute of the Play object
    play.variable_manager = variable_manager

    # Set the host_list attribute

# Generated at 2022-06-17 08:44:35.958920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock connection plugin
    connection_plugin = MockConnectionPlugin()

    # Create a mock shell plugin
    shell_plugin = MockShellPlugin()

    # Create a mock cache plugin
    cache_plugin = MockCachePlugin()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create an instance of ActionModule

# Generated at 2022-06-17 08:44:47.289950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that='foo', msg='bar'))))
    assert action_module is not None

    # Test with invalid arguments
    try:
        action_module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that='foo', msg=['bar', 'baz']))))
        assert False
    except AnsibleError as e:
        assert 'Type of one of the elements in fail_msg or msg list is not string type' in str(e)


# Generated at 2022-06-17 08:44:55.938126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:45:06.235432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    module = ActionModule()

    # Create a mock object for the task
    task = Mock()

    # Create a mock object for the loader
    loader = Mock()

    # Create a mock object for the templar
    templar = Mock()

    # Create a mock object for the task_vars
    task_vars = Mock()

    # Create a mock object for the conditional
    cond = Mock()

    # Create a mock object for the conditional when
    cond_when = Mock()

    # Create a mock object for the conditional evaluate_conditional
    cond_evaluate_conditional = Mock()

    # Create a mock object for the conditional evaluate_conditional
    cond_evaluate_conditional = Mock()

    # Create a mock object for the conditional evaluate_conditional
    cond_evaluate_conditional = Mock

# Generated at 2022-06-17 08:45:16.218965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:45:30.582904
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:27.672943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:46:39.620790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "Ubuntu"'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader=loader, templar=templar, module_utils=module_utils)

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'Ubuntu'}

    # Test the run method

# Generated at 2022-06-17 08:46:41.501755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:46:53.241521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:47:04.611176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"', 'msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock ActionBase
    action_base = MockActionBase()

    # Create a mock ActionModule

# Generated at 2022-06-17 08:47:08.976193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:47:16.354227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:47:20.786663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Set the connection attribute of the PlayContext object
    play_context.connection = connection

    # Set the remote_addr attribute of the PlayContext object

# Generated at 2022-06-17 08:47:32.068129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._task.action == dict()
    assert am._task.args == dict()
    assert am._task.action == dict()
    assert am._task.action_args == dict()
    assert am._task.action_args.get('that') is None
    assert am._task.action_args.get('fail_msg') is None
    assert am._task.action_args.get('msg') is None
    assert am._task.action_args.get('quiet') is None
    assert am._task.action_args.get('success_msg') is None

# Generated at 2022-06-17 08:47:42.300577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {'var1': 'value1'}
    tmp = None
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._task.args = task_args
    result = action.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {'var1': 'value1'}
    tmp = None