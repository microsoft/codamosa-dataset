

# Generated at 2022-06-17 08:38:40.008331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:38:51.422967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that='ansible_distribution == "CentOS"',
                success_msg='All assertions passed',
                fail_msg='Assertion failed',
                quiet=False
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict(
        ansible_distribution='CentOS'
    )

    # Create a mock templar
    templar = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock module_utils
    module_utils = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock AnsibleModule

# Generated at 2022-06-17 08:39:01.288120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar)

    # Call the run method
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:39:13.622668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:39:15.343579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 08:39:24.238603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Template
    templar = Templar(loader=loader)

    # Create an instance of class TaskVars
    task_vars = dict()

    # Create an instance of class Connection
    connection = Connection()

    # Set the attributes of the 'task' object
    task.args = dict()
    task.action = 'assert'
    task.action_loader = ActionBase()
    task.any_errors_fatal = False
    task

# Generated at 2022-06-17 08:39:30.641467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:39:39.023963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Template
    templar = Templar(loader=loader, variables=variable_manager)

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Play

# Generated at 2022-06-17 08:39:51.263415
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:40:01.558793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:40:16.659917
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:40:22.252113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(fail_msg='msg', msg='msg', quiet=False, success_msg='msg', that='that')))
    assert action.run() == dict(changed=False, msg='msg')

# Generated at 2022-06-17 08:40:32.615027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            fail_msg='Assertion failed',
            that='{{ foo }} == "bar"',
        ),
    )
    task_vars = dict(foo='bar')
    result = ActionModule(task, task_vars).run()
    assert result['msg'] == 'Assertion failed'
    assert result['failed'] is True
    assert result['assertion'] == '{{ foo }} == "bar"'
    assert result['evaluated_to'] is False

    # Test with fail_msg as list

# Generated at 2022-06-17 08:40:42.981093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': '1 == 2'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'

    # Test with msg
    task_args = {'msg': 'Assertion failed', 'that': '1 == 2'}

# Generated at 2022-06-17 08:40:47.876262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:41:00.184192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:41:02.820247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:41:04.166106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:41:08.825247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:41:10.409721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:41:32.871639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 08:41:43.070087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Check if the result is correct
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:41:55.129378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:41:57.269752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == ' Fail with custom message '
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-17 08:41:59.411820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:42:06.367722
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:16.486381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"', 'msg': 'Assertion failed'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar)

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = {'ansible_distribution': 'CentOS'}

    # Call the run method
    action_module.run(task_vars=task_vars)

    # Assert that the result is correct
    assert result.failed == False
    assert result.changed == False

# Generated at 2022-06-17 08:42:29.938812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            fail_msg='Assertion failed',
            that='{{ 1 == 2 }}'
        )
    )
    task_vars = dict()
    result = ActionModule(task, task_vars).run(task_vars=task_vars)
    assert result['failed']
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == '{{ 1 == 2 }}'

    # Test with msg
    task = dict(
        action=dict(
            module='assert',
            msg='Assertion failed',
            that='{{ 1 == 2 }}'
        )
    )
    task_vars = dict()

# Generated at 2022-06-17 08:42:40.970361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:42:50.962938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with args
    am = ActionModule(None, None, None, None, None, None, fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:43:44.951862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:43:55.992369
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:44:04.987497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object
    mock_loader = 'mock_loader'
    mock_templar = 'mock_templar'
    mock_task = 'mock_task'
    mock_connection = 'mock_connection'
    mock_play_context = 'mock_play_context'
    mock_shared_loader_obj = 'mock_shared_loader_obj'
    mock_variable_manager = 'mock_variable_manager'

    # Create a instance of ActionModule
    action_module = ActionModule(
        mock_loader,
        mock_templar,
        mock_task,
        mock_connection,
        mock_play_context,
        mock_shared_loader_obj,
        mock_variable_manager
    )

    # Check the instance of ActionModule

# Generated at 2022-06-17 08:44:11.206915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')))
    assert action._task.args['fail_msg'] == 'fail_msg'
    assert action._task.args['msg'] == 'msg'
    assert action._task.args['quiet'] == 'quiet'
    assert action._task.args['success_msg'] == 'success_msg'
    assert action._task.args['that'] == 'that'

# Generated at 2022-06-17 08:44:22.858818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 08:44:34.518719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:44:46.577534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:44:52.785726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(action=dict(module='assert', fail_msg='Assertion failed'))
    action = ActionModule(task, dict())
    result = action.run(task_vars=dict())
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task = dict(action=dict(module='assert', msg='Assertion failed'))
    action = ActionModule(task, dict())
    result = action.run(task_vars=dict())
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with success_msg
    task = dict(action=dict(module='assert', success_msg='All assertions passed'))
    action = ActionModule(task, dict())

# Generated at 2022-06-17 08:44:56.573104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 08:45:06.607433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:46:08.504181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 08:46:18.023048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg and msg
    task = dict(action=dict(module='assert', fail_msg='fail_msg', msg='msg'))
    task_vars = dict()
    tmp = None
    m = ActionModule(task, tmp, task_vars)
    result = m.run(tmp, task_vars)
    assert result['msg'] == 'fail_msg'

    # Test with fail_msg and msg as list
    task = dict(action=dict(module='assert', fail_msg=['fail_msg1', 'fail_msg2'], msg=['msg1', 'msg2']))
    task_vars = dict()
    tmp = None
    m = ActionModule(task, tmp, task_vars)
    result = m.run(tmp, task_vars)

# Generated at 2022-06-17 08:46:27.368920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 08:46:36.838754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(that='1 == 1')))
    assert ActionModule(task=dict(args=dict(that='1 == 1', fail_msg='1 == 1')))
    assert ActionModule(task=dict(args=dict(that='1 == 1', success_msg='1 == 1')))
    assert ActionModule(task=dict(args=dict(that='1 == 1', quiet=True)))
    assert ActionModule(task=dict(args=dict(that='1 == 1', msg='1 == 1')))
    assert ActionModule(task=dict(args=dict(that='1 == 1', msg=['1 == 1'])))
    assert ActionModule(task=dict(args=dict(that='1 == 1', fail_msg=['1 == 1'])))

# Generated at 2022-06-17 08:46:46.605666
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:56.632502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {'args': {'fail_msg': 'fail', 'msg': 'fail', 'quiet': False, 'success_msg': 'success', 'that': 'that'}})
    # Create a mock loader
    mock_loader = type('MockLoader', (object,), {'get_basedir': lambda self: '/path/to/playbook'})
    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {'template': lambda self, x: x})
    # Create a mock module_utils
    mock_module_utils = type('MockModuleUtils', (object,), {'parsing.convert_bool.boolean': lambda x, y: x})
    # Create a

# Generated at 2022-06-17 08:47:04.819345
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:47:15.277985
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:47:20.123618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:47:30.891323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files