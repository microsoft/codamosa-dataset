

# Generated at 2022-06-17 08:38:33.460024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg and msg
    task_args = {'fail_msg': 'fail_msg', 'msg': 'msg', 'quiet': False, 'success_msg': 'success_msg', 'that': 'that'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args
    result = action_module.run(tmp=None, task_vars=None)
    assert result['msg'] == 'fail_msg'

    # Test with fail_msg and msg as list

# Generated at 2022-06-17 08:38:35.213652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 08:38:42.818560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed'}
    task_vars = {}
    tmp = None
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed'}
    task_vars = {}
    tmp = None

# Generated at 2022-06-17 08:38:52.734252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': ['1 == 1', '2 == 2']}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result == {'changed': False, 'msg': 'All assertions passed'}


# Generated at 2022-06-17 08:39:04.173760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.inventory.host import Host


# Generated at 2022-06-17 08:39:16.283359
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:39:30.817167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_os_family == "RedHat"'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Create a mock module_utils.parsing.convert_bool.boolean.boolean
    boolean.boolean = True

    # Create a mock module_utils.parsing.convert_bool

# Generated at 2022-06-17 08:39:32.730379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:39:33.226505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:39:40.044238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:40:00.849949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'fail_msg': 'Assertion failed', 'that': '1 == 2'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'msg': 'Assertion failed', 'that': '1 == 2'}
    action = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
   

# Generated at 2022-06-17 08:40:10.943436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    host = Host(name="testhost")
    group = Group(name="testgroup")
    group.add_host(host)
    inventory = Inventory(loader=None, variable_manager=None, host_list=[host])
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-17 08:40:14.380752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:40:17.389637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:40:28.168634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')))
    assert action._task.args['fail_msg'] == 'fail_msg'
    assert action._task.args['msg'] == 'msg'
    assert action._task.args['quiet'] == 'quiet'
    assert action._task.args['success_msg'] == 'success_msg'
    assert action._task.args['that'] == 'that'


# Generated at 2022-06-17 08:40:31.874219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='assert', args=dict(that='1 == 1'))))

# Generated at 2022-06-17 08:40:42.346189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = type('MockModule', (object,), {
        'run': ActionModule.run,
        '_task': type('MockTask', (object,), {
            'args': {
                'fail_msg': 'Assertion failed',
                'that': '{{ test_var }} == 1',
            },
        }),
        '_loader': type('MockLoader', (object,), {
            'get_basedir': lambda self: '/path/to/playbook',
        }),
        '_templar': type('MockTemplar', (object,), {
            'template': lambda self, template: template,
        }),
    })()

    # Test with a valid that value

# Generated at 2022-06-17 08:40:52.260842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = dict()
    mock_task.args['that'] = '1 == 1'

    # Create a mock loader
    mock_loader = Mock()

    # Create a mock templar
    mock_templar = Mock()

    # Create a mock module_utils
    mock_module_utils = Mock()

    # Create a mock module_utils.parsing.convert_bool
    mock_convert_bool = Mock()
    mock_convert_bool.boolean = Mock(return_value=True)
    mock_module_utils.parsing.convert_bool = mock_convert_bool

    # Create a mock module_utils.six
    mock_six = Mock()
    mock_six.string_types = string_types
   

# Generated at 2022-06-17 08:41:02.898349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2'], msg='Assertion failed'))))
    assert action_module

    # Test with invalid arguments
    try:
        action_module = ActionModule(task=dict(action=dict(module_name='assert', args=dict(that=['1 == 1', '2 == 2'], msg=['Assertion failed', 1]))))
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-17 08:41:11.079692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 08:41:36.465013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict()
    task.args['that'] = 'ansible_distribution == "CentOS"'
    task.args['fail_msg'] = 'Assertion failed'
    task.args['success_msg'] = 'All assertions passed'
    task.args['quiet'] = False

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Create a mock task_

# Generated at 2022-06-17 08:41:38.869841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 08:41:44.668654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.action == dict()
    assert action_module._task.args == dict()
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test with args
    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:41:48.786539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 08:41:58.547717
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:10.500142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'test_result'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock task_vars
    task_vars = {}

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, task_vars, action_base)

    # Create a mock conditional
    cond = MockConditional()

    # Create a mock result
    result = {}

    # Create a mock test_result
    test_

# Generated at 2022-06-17 08:42:18.224211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader=loader, templar=templar, shared_loader_obj=loader,
                                 action_loader=loader, module_loader=loader)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Test fail_msg

# Generated at 2022-06-17 08:42:30.645155
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:43.615319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:42:49.593938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet=False, success_msg='success_msg', that='that')))
    assert action._task.args['fail_msg'] == 'fail_msg'
    assert action._task.args['msg'] == 'msg'
    assert action._task.args['quiet'] == False
    assert action._task.args['success_msg'] == 'success_msg'
    assert action._task.args['that'] == 'that'


# Generated at 2022-06-17 08:43:39.185503
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:43:47.836168
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:43:56.974811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:44:05.435569
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:44:06.790753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:44:19.332625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader=loader, templar=templar, module_utils=module_utils)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Test with fail_msg

# Generated at 2022-06-17 08:44:34.450745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars


# Generated at 2022-06-17 08:44:46.538271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class Conditional
    cond = Conditional(loader=None)

    # Create a mock object of class AnsibleError
    ansible_error = AnsibleError(msg=None)

    # Create a mock object of class string_types
    string_types = string_types()

    # Create a mock object of class boolean
    boolean = boolean()

    # Create a mock object of class dict
    dict = dict()

    # Create a mock object of class list
    list = list()

    # Create a mock object of class string_types
    string_types = string_types()

    # Create a mock object

# Generated at 2022-06-17 08:44:52.983904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {})()
    mock_task.args = {'that': ['1 == 1', '2 == 2']}

    # Create a mock loader
    mock_loader = type('MockLoader', (object,), {})()

    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {})()

    # Create a mock action module
    mock_action_module = type('MockActionModule', (ActionModule,), {})()
    mock_action_module._task = mock_task
    mock_action_module._loader = mock_loader
    mock_action_module._templar = mock_templar

    # Test run method
    result = mock_action_module.run()


# Generated at 2022-06-17 08:45:00.099702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:46:03.246514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:46:15.668205
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:26.699227
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:36.805067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Set the attributes of the mock module_utils.parsing.convert_bool
    module_utils.parsing.convert_bool = convert_bool

    # Create a mock module_utils.parsing.convert_bool.boolean
    boolean = MockBoolean()

    # Set the attributes of the mock module_utils.parsing.convert_bool.boolean
    convert_bool.boolean = boolean

# Generated at 2022-06-17 08:46:46.584729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:46:56.633463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    # Test case with fail_msg
    # Expected result:
    #   - failed: True
    #   - evaluated_to: False
    #   - assertion: '1 == 2'
    #   - msg: 'Assertion failed'
    task_args = {'that': '1 == 2', 'fail_msg': 'Assertion failed'}
    task_vars = {}
    result = ActionModule(task_args, task_vars).run()
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == '1 == 2'
    assert result['msg'] == 'Assertion failed'

    # Test case 2
    # Test case with msg
    # Expected result:
    #   - failed: True
    #   -

# Generated at 2022-06-17 08:47:07.847897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with args
    am = ActionModule(None, None, None, None, None, fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:47:15.147249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task = dict(
        action=dict(
            module='assert',
            fail_msg='Assertion failed'
        ),
        args=dict(
            that='{{ test_var }} == "test_value"'
        )
    )
    task_vars = dict(
        test_var='test_value'
    )
    tmp = None
    am = ActionModule(task, tmp, task_vars)
    result = am.run(tmp, task_vars)
    assert result['msg'] == 'Assertion failed'
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == '{{ test_var }} == "test_value"'

    # Test with msg

# Generated at 2022-06-17 08:47:20.049206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='assert',
            module_args=dict(
                fail_msg='Assertion failed',
                success_msg='All assertions passed',
                quiet=False,
                that=['1 == 1', '2 == 2']
            )
        )
    )

    # Create a mock play context
    play_context = dict(
        loader=None,
        templar=None,
        shared_loader_obj=None,
        variable_manager=None,
        default_vars=None
    )

    # Create a mock connection

# Generated at 2022-06-17 08:47:31.960730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with fail_msg
    task_args = {'that': '1 == 2', 'fail_msg': 'Assertion failed'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with msg
    task_args = {'that': '1 == 2', 'msg': 'Assertion failed'}