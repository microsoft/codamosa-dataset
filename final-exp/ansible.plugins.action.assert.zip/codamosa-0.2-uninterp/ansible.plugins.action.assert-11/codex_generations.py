

# Generated at 2022-06-17 08:38:33.193377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:38:37.340861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == ' Fail with custom message '
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:38:48.110489
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:38:55.816499
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:38:58.366454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:39:01.090027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 08:39:13.573466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    action_module = ActionModule()

    # create a mock task
    task = MockTask()

    # create a mock loader
    loader = MockLoader()

    # create a mock templar
    templar = MockTemplar()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock connection
    connection = MockConnection()

    # create a mock module
    module = MockModule()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_

# Generated at 2022-06-17 08:39:22.936235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:39:33.827553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:39:34.973788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:39:52.377463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')))
    assert action._task.args['fail_msg'] == 'fail_msg'
    assert action._task.args['msg'] == 'msg'
    assert action._task.args['quiet'] == 'quiet'
    assert action._task.args['success_msg'] == 'success_msg'
    assert action._task.args['that'] == 'that'


# Generated at 2022-06-17 08:40:02.797915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:40:12.101349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task object
    task = MockTask()
    task.args = dict(that=['1 == 1', '2 == 2'])

    # create a mock action module
    action = ActionModule(task, dict())

    # run the action module
    result = action.run(None, None)

    # assert that the result is correct
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'

    # create a mock task object
    task = MockTask()
    task.args = dict(that=['1 == 1', '2 == 3'])

    # create a mock action module
    action = ActionModule(task, dict())

    # run the action module
    result = action.run(None, None)

    # assert that the result is correct
    assert result['failed'] == True

# Generated at 2022-06-17 08:40:19.829054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object
    mock_loader = Mock()
    mock_templar = Mock()
    mock_task = Mock()
    mock_task.args = {'that': '{{ test_var }}', 'fail_msg': 'Assertion failed', 'success_msg': 'All assertions passed', 'quiet': False}
    mock_task_vars = {'test_var': True}

    # Create an instance of ActionModule
    action_module = ActionModule(mock_loader, mock_templar, mock_task)

    # Call run() method
    result = action_module.run(None, mock_task_vars)

    # Check if the result is correct
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:40:26.990211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock PlayContext
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_2 = MockAnsibleModule2()

    # Create a mock AnsibleModule
    ansible_module_3 = MockAnsibleModule3()

    # Create a mock AnsibleModule
    ansible_

# Generated at 2022-06-17 08:40:40.673879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 08:40:45.770416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'test_that'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, module_utils)

    # Test with no fail_msg or msg
    result = action_plugin.run()
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with fail_msg

# Generated at 2022-06-17 08:40:48.552206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 08:40:53.704042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 08:40:55.248613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:41:20.905363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import json


# Generated at 2022-06-17 08:41:33.759795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:41:37.194307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:41:48.689840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class VariableManager
    variable_manager = VariableManager()
    # Create an instance of class Inventory
    inventory = Inventory()
    # Create an instance of class PlaybookExecutor
    loader = PlaybookExecutor()
    # Create an instance of class Options
    options = Options()
    # Create an instance of class DataLoader
    data_loader = DataLoader()
    # Create an instance of class PluginLoader
    plugin_loader = PluginLoader()
    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()
    # Create an instance of class Play
    play = Play()
   

# Generated at 2022-06-17 08:41:51.308790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for correct type of return value
    assert isinstance(ActionModule.run(ActionModule, tmp=None, task_vars=None), dict)


# Generated at 2022-06-17 08:42:00.036578
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:14.020821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['that'] = '{{ foo }}'
    task['args']['fail_msg'] = '{{ foo }}'
    task['args']['success_msg'] = '{{ foo }}'
    task['args']['quiet'] = '{{ foo }}'

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock module_utils
    module_utils = dict()

    # Create a mock module
    module = dict()

    # Create a mock task_vars
    task_vars = dict()
    task_vars['foo'] = 'bar'

    # Create a mock tmp
    tmp = dict()

    # Create a

# Generated at 2022-06-17 08:42:21.665166
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:32.203987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': ['1 == 1', '2 == 2']}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    module_utils.parsing.convert_bool = MockConvertBool()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock ActionBase
    action_base = MockActionBase()

    # Create a mock ActionModule

# Generated at 2022-06-17 08:42:43.773441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for class ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object for class Conditional
    mock_Conditional = Conditional(loader=None)

    # Create a mock object for class AnsibleError
    mock_AnsibleError = AnsibleError(msg=None)

    # Create a mock object for class string_types
    mock_string_types = string_types

    # Create a mock object for class boolean
    mock_boolean = boolean

    # Create a mock object for class dict
    mock_dict = dict()

    # Create a mock object for class frozenset
    mock_frozenset = frozenset()

    # Create a mock object for class

# Generated at 2022-06-17 08:43:31.761370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(that=['foo', 'bar'], fail_msg='failed', success_msg='success')),
                          connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert action.run() == dict(changed=False, msg='success')


# Generated at 2022-06-17 08:43:39.420792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a dictionary containing required arguments for method run
    args = {}
    args['fail_msg'] = 'Assertion failed'
    args['msg'] = 'Assertion failed'
    args['quiet'] = False
    args['success_msg'] = 'All assertions passed'
    args['that'] = ['1 == 1']

    # Call method run with required arguments
    result = action_module.run(task_vars=None, tmp=None, **args)

    # Check if result is of correct type
    assert isinstance(result, dict)

    # Check if result is as expected

# Generated at 2022-06-17 08:43:41.888751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:43:53.890703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a dictionary representing the parameters in the task's argument spec
    parameters = dict()
    parameters['fail_msg'] = 'Assertion failed'
    parameters['msg'] = 'Assertion failed'
    parameters['quiet'] = False
    parameters['success_msg'] = 'All assertions passed'
    parameters['that'] = '{{ foo }}'

    # Create a dictionary representing the parameters in the task's argument spec
    task_vars = dict()
    task_vars['foo'] = 'bar'

    # Create a dictionary representing the Ansible variables
    ansible_vars = dict()

    # Set the parameters and task_vars attributes of the ActionModule instance
    action_module.params = parameters
    action_module.task_vars = task_v

# Generated at 2022-06-17 08:44:03.476955
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:44:08.121573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None, None, None, None, None)
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:44:20.594391
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:44:40.050205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import pre

# Generated at 2022-06-17 08:44:50.176804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module object
    module = MockModule()
    # Create a mock connection object
    connection = MockConnection()

    # Create a mock play context object
    play_context = MockPlayContext()

    # Create a mock AnsibleModule object
    ansible_module = MockAnsibleModule()

    # Create a fail module object
    fail_module = ActionModule(task, connection, play_context, loader, templar, ansible_module)

    # Test case 1: Test the run method with fail_msg as string
    task.args = dict(fail_msg='fail_msg')

# Generated at 2022-06-17 08:44:53.350146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:46:01.454119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'assert'
    task['action']['__ansible_arguments__'] = dict()
    task['action']['__ansible_arguments__']['that'] = '1 == 1'
    task['action']['__ansible_arguments__']['msg'] = 'Assertion failed'
    task['action']['__ansible_arguments__']['success_msg'] = 'All assertions passed'
    task['action']['__ansible_arguments__']['quiet'] = False

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock task

# Generated at 2022-06-17 08:46:09.655701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class TemplateFile
    templar = Templar(loader=loader)

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner

# Generated at 2022-06-17 08:46:18.095444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    import os
    import json


# Generated at 2022-06-17 08:46:26.336817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet=True, success_msg='success_msg', that='that')),
                                 connection=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)

    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:46:36.772499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'foo', 'msg': 'bar'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action module
    action_module = ActionModule(task, loader, templar, module_utils)

    # Create a mock result
    result = MockResult()

    # Call method run of class ActionModule
    action_module.run(result)

    # Check if the result is correct
    assert result.failed == True
    assert result.evaluated_to == False
    assert result.assertion == 'foo'
    assert result.msg == 'bar'

# Generated at 2022-06-17 08:46:46.561835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 08:46:56.633836
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:46:57.346193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:47:05.249744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:47:11.673748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    try:
        ActionModule()
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert str(e) == 'conditional required in "that" string'

    # Test with valid args
    assert ActionModule(dict(that='1 == 1'))