

# Generated at 2022-06-17 08:38:33.503267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': 'ansible_distribution == "CentOS"', 'fail_msg': 'Assertion failed', 'success_msg': 'All assertions passed'}
    task.action = 'assert'
    task.action_plugin_name = 'assert'
    task.action_plugin_class = 'ActionModule'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsible

# Generated at 2022-06-17 08:38:37.562253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:38:48.185394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:38:55.844662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils object
    class MockModuleUtils:
        def __init__(self):
            self.boolean = boolean

    # Create a mock object for the templar object
    class MockTemplar:
        def __init__(self):
            self.template = template

    # Create a mock object for the loader object
    class MockLoader:
        def __init__(self):
            self.load_from_file = load_from_file

    # Create a mock object for the task object
    class MockTask:
        def __init__(self):
            self.args = {'that': '{{test_var}}'}

    # Create a mock object for the conditional object
    class MockConditional:
        def __init__(self, loader):
            self.when = None

# Generated at 2022-06-17 08:38:59.618411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-17 08:39:07.069165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule(None, None, None, None, None, None)

    # Create a mock object of class Conditional
    mock_Conditional = Conditional(None)

    # Create a mock object of class AnsibleError
    mock_AnsibleError = AnsibleError(None)

    # Create a mock object of class string_types
    mock_string_types = string_types

    # Create a mock object of class boolean
    mock_boolean = boolean

    # Create a mock object of class dict
    mock_dict = dict()

    # Create a mock object of class list
    mock_list = list()

    # Create a mock object of class type
    mock_type = type

    # Create a mock object of class frozenset
    mock_frozenset = frozens

# Generated at 2022-06-17 08:39:08.751044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 08:39:20.141495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    fail_msg = 'Assertion failed'
    action_module = ActionModule(task=dict(args=dict(fail_msg=fail_msg)))
    assert action_module.run()['msg'] == fail_msg

    # Test with success_msg
    success_msg = 'All assertions passed'
    action_module = ActionModule(task=dict(args=dict(success_msg=success_msg)))
    assert action_module.run()['msg'] == success_msg

    # Test with fail_msg and success_msg
    action_module = ActionModule(task=dict(args=dict(fail_msg=fail_msg, success_msg=success_msg)))
    assert action_module.run()['msg'] == fail_msg

# Generated at 2022-06-17 08:39:24.026583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 08:39:32.886167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar)

    # Create a mock result
    result = MockResult()

    # Call method run
    action_module.run(result)

    # Assert that the result is correct
    assert result.failed == False
    assert result.msg == 'All assertions passed'


# Generated at 2022-06-17 08:39:52.693497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['fail_msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False
    task['args']['that'] = ['1 == 1', '2 == 2']

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar)

    # Check the instance variables
    assert action_module._task == task
    assert action_module._loader == loader
    assert action_module._templar == templar

# Generated at 2022-06-17 08:40:03.008636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['that'] = '{{ foo }}'
    task['args']['fail_msg'] = '{{ foo }}'
    task['args']['success_msg'] = '{{ foo }}'
    task['args']['quiet'] = False

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock module_utils
    module_utils = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock task_vars
    task_vars = dict()
    task_vars['foo'] = 'bar'

    # Create a mock tmp
    tmp = dict()

    # Create a

# Generated at 2022-06-17 08:40:12.319361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    mock_module = type('', (), {})()

    # Create a mock object for the task
    mock_task = type('', (), {})()
    mock_task.args = {'that': 'ansible_distribution == "Ubuntu"'}

    # Create a mock object for the loader
    mock_loader = type('', (), {})()

    # Create a mock object for the templar
    mock_templar = type('', (), {})()

    # Create a mock object for the task_vars
    mock_task_vars = type('', (), {})()
    mock_task_vars.ansible_distribution = 'Ubuntu'

    # Create a mock object for the result
    mock_result = type('', (), {})()
    mock_result.failed = False

# Generated at 2022-06-17 08:40:20.116383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 08:40:22.751628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule()
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-17 08:40:25.098149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:40:31.701084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = 'assert'
    task['args'] = dict()
    task['args']['that'] = '1 == 1'
    task['args']['fail_msg'] = 'Assertion failed'
    task['args']['success_msg'] = 'All assertions passed'
    task['args']['quiet'] = False

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = dict()

    # Create an instance of ActionModule
    action_module = ActionModule(task, loader, templar, task_vars, tmp)

    # Call method run of class

# Generated at 2022-06-17 08:40:42.130908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:40:45.902373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:40:51.954724
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:12.639793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 08:41:19.950694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(
        task=dict(args=dict(that=['1 == 1', '2 == 2'])),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Test method run of class ActionModule
    result = action_module.run(tmp=None, task_vars=None)
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'

    # Create an instance of class ActionModule

# Generated at 2022-06-17 08:41:33.383339
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:41:43.107147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:41:55.128881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None, None, None, None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    # Test with args
    am = ActionModule(None, None, None, None, None, None, None, None, None, fail_msg='fail_msg', msg='msg', quiet=True, success_msg='success_msg', that='that')
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-17 08:41:55.831991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None) is not None

# Generated at 2022-06-17 08:42:03.865691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = dict(
        action=dict(
            module='assert',
            args=dict(
                that=['foo == bar', 'baz == qux'],
                fail_msg='foo is not bar',
                success_msg='foo is bar',
                quiet=True
            )
        )
    )

    # Create a fake loader
    loader = dict(
        get_basedir=lambda x, y: '/path/to/playbook',
        path_dwim=lambda x: x
    )

    # Create a fake templar
    templar = dict(
        template=lambda x: x
    )

    # Create a fake variable manager
    variable_manager = dict(
        get_vars=lambda x: dict(foo='bar', baz='qux')
    )

# Generated at 2022-06-17 08:42:14.317662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a dictionary representing the parameters passed to the method run
    tmp = None
    task_vars = dict()

    # Call the method run
    result = action_module.run(tmp, task_vars)

    # Check the result
    assert result == dict(
        _ansible_verbose_always=True,
        assertion='',
        changed=False,
        evaluated_to=False,
        failed=True,
        msg='Assertion failed',
    )

# Generated at 2022-06-17 08:42:18.105773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(fail_msg='test')))

# Generated at 2022-06-17 08:42:28.918040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 08:43:08.172490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    fail_msg = 'Assertion failed'
    action_module = ActionModule(task=dict(args=dict(fail_msg=fail_msg)), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.args['fail_msg'] == fail_msg

    # Test with msg
    msg = 'Assertion failed'
    action_module = ActionModule(task=dict(args=dict(msg=msg)), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.args['fail_msg'] == msg

    # Test with success_msg
    success_msg = 'All assertions passed'
    action_module = Action

# Generated at 2022-06-17 08:43:19.385402
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:43:32.176654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    # Create a temporary file
    import tempfile
    fd, temp_path = tempfile.mkstemp()

    # Create a temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Create a task
    task = Task()
    task._role = Role()
    task.block = Block()
    task.block.parent_block = Play()
    task.block.root_block = task.block

# Generated at 2022-06-17 08:43:39.732221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with fail_msg
    action_module = ActionModule(
        task=dict(
            args=dict(
                fail_msg='fail_msg',
                that='that'
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False

    # Test with msg

# Generated at 2022-06-17 08:43:47.870562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()
    task.args = dict()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = Loader()

    # Create an instance of class Templates
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of action_module
    action_module._task = task
    action_module._play_context = play_context
    action_module._loader = loader
    action_module._templar = templar
    action_module._shared_loader_obj = None

# Generated at 2022-06-17 08:43:55.686631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_2 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_3 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ansible_module_4 = MockAnsibleModule()

    # Create a mock AnsibleModule
    ans

# Generated at 2022-06-17 08:44:00.241719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 08:44:05.655854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:44:09.874311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:44:14.046127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action = ActionModule()
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:45:17.268280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'that': '1 == 1'}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, loader, templar, module_utils, action_base)

    # Test the run method
    result = action_module.run()
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-17 08:45:25.609394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(fail_msg='fail_msg', msg='msg', quiet='quiet', success_msg='success_msg', that='that')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run() == dict(changed=False, msg='success_msg')

# Generated at 2022-06-17 08:45:33.787137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    # Test case with fail_msg as string and success_msg as string
    # Expected result: success_msg
    task_vars = dict(ansible_all_ipv4_addresses=['10.0.0.1', '10.0.0.2'])
    task_vars['ansible_all_ipv4_addresses'].append('10.0.0.3')
    task_vars['ansible_all_ipv4_addresses'].append('10.0.0.4')
    task_vars['ansible_all_ipv4_addresses'].append('10.0.0.5')
    task_vars['ansible_all_ipv4_addresses'].append('10.0.0.6')

# Generated at 2022-06-17 08:45:45.085286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Set the module_utils.parsing.convert_bool.boolean to the mock
    module_utils.parsing.convert_bool.boolean = convert_bool.boolean

    # Create a mock module_utils.six
    module_utils.six = MockSix()

    # Create a mock AnsibleError
    ansible_error = MockAnsibleError()

    # Create a mock Conditional
    conditional

# Generated at 2022-06-17 08:45:57.098421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid fail_msg
    fail_msg = 'Assertion failed'
    success_msg = 'All assertions passed'
    quiet = False
    that = '{{ ansible_distribution }} == "Ubuntu"'
    args = {'fail_msg': fail_msg, 'success_msg': success_msg, 'quiet': quiet, 'that': that}
    action_module = ActionModule(None, None, args)
    assert action_module._task.args['fail_msg'] == fail_msg
    assert action_module._task.args['success_msg'] == success_msg
    assert action_module._task.args['quiet'] == quiet
    assert action_module._task.args['that'] == that

    # Test with a valid msg
    fail_msg = 'Assertion failed'

# Generated at 2022-06-17 08:46:06.321775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Loader
    loader = DataLoader()

    # Create an instance of class Template
    templar = Templar(loader=loader, variables=variable_manager)

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class PlaybookExecutor
    play_executor = PlaybookExecutor()

    # Create an instance of class Play

# Generated at 2022-06-17 08:46:08.970638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='assert', module_args=dict(that=['1 == 1', '2 == 2']))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run() == dict(
        changed=False,
        msg='All assertions passed',
        _ansible_verbose_always=True)


# Generated at 2022-06-17 08:46:18.046255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=dict(args=dict(that=['1 == 1', '2 == 2'], msg='Test message', success_msg='Test success message')))

    # Create an instance of class Conditional
    cond = Conditional(loader=None)

    # Set the value of attribute when of object cond
    cond.when = ['1 == 1', '2 == 2']

    # Set the value of attribute that of object action_module
    action_module._task.args['that'] = ['1 == 1', '2 == 2']

    # Set the value of attribute msg of object action_module
    action_module._task.args['msg'] = 'Test message'

    # Set the value of attribute success_msg of object action_module

# Generated at 2022-06-17 08:46:31.498388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:46:33.332429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None