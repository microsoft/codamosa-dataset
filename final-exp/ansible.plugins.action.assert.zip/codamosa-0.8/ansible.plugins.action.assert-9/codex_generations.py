

# Generated at 2022-06-11 11:21:25.928748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import mock
    import errno
    import random

    from ansible.utils.unicode import to_bytes
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # skip test on windows
    if os.name == 'nt':
        raise SkipTest
    # placeholder to hold the values to be used inside the mocked methods
    test_values = {}

    # initialize needed objects
    vault = VaultLib([])
    loader = DataLoader()
    templar = Templar(loader=loader, vault_secrets=vault.secrets)

    mock_task = mock.MagicMock()

# Generated at 2022-06-11 11:21:34.509812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict(that=['a.b==1'])

# Generated at 2022-06-11 11:21:44.012333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.playbook.play_context import PlayContext

    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            result = super(ActionModuleTest, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect
            return result

    loader = DataLoader()

# Generated at 2022-06-11 11:21:52.600743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Simple task initialization
    set_task_args = dict(
                          that = 'string',
                          fail_msg = 'string',
                          msg = 'string',
                          quiet = False,
                          success_msg = 'string'
                        )
    set_loader = 'loader'
    set_shared_loader_obj = 'shared_loader_obj'
    set_play_context = 'play_context'
    set_new_play = 'new_play'
    set_variable_manager = 'variable_manager'
    set_task_include = 'task_include'
    mytask = Task()
    mytask._role = None
    mytask._block = Block()
    mytask._block._role = None
   

# Generated at 2022-06-11 11:22:04.611923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task = Task()
    action = ActionModule(task, dict(a=2, b=3))
    assert not hasattr(action, '_VALID_ARGS')
    action._task.args.update(dict(a=2, b=3))
    assert action._task.args['a'] == 2
    assert action._task.args['b'] == 3

    action = ActionModule(task, dict(a=2, b=3))
    task.block = Block()
    task.block.vars.update(dict(a=2, b=3))
    assert task.args['a'] == 2
    assert task.args['b'] == 3
    assert action._task.args['a'] == 2
    assert action._

# Generated at 2022-06-11 11:22:08.771933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-11 11:22:18.454906
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class Game:
        def run(self):
            pass

    class Host:
        def __init__(self, hostname):
            self.name = hostname

    class Task:
        def __init__(self):
            self.name = ''
            self.loop_control = False
            self.args = {}
            self.action = 'test'
            self.delegate_to = False
            self.environment = dict()
            self.loop = None

    class Play:
        def __init__(self):
            self.hosts = 'all'
            self.name = ''
            self.hosts = dict()
            self.vars = dict()

        def get_variable_manager(self):
            class VariableManager:
                def get_vars(self):
                    return dict()


# Generated at 2022-06-11 11:22:30.048835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Returns:
        Returns a tuple of (success_msg, fail_msg).
        success_msg is a list of strings which hold the success messages
        fail_msg is a list of strings which hold the fail messages
    '''
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_condition': False, 'test_str': 'str_val'}

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')

    test_task = Task()

# Generated at 2022-06-11 11:22:35.788510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule.__new__(ActionModule)
    assert cls._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert 'TRANSFERS_FILES' in cls.__dict__
    assert cls.TRANSFERS_FILES is False

# Generated at 2022-06-11 11:22:38.260470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing for the constructor")
    try:
        action = ActionModule()
    except Exception as e:
        assert False, e

# Generated at 2022-06-11 11:22:56.396230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import json
    import os
    import textwrap

    from ansible.errors import AnsibleActionFail, AnsibleError
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars import DataVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import string_types

    from io import StringIO
    from unittest.case import skip

    current_dir = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-11 11:22:59.654533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    action.run()


# Generated at 2022-06-11 11:23:00.744636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-11 11:23:02.768296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, None, None)
    assert actionModule.run() == {}

# Generated at 2022-06-11 11:23:04.330632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test run method of ActionModule """
    pass


# Generated at 2022-06-11 11:23:13.774350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.conditional import Conditional

    module_args = {'fail_msg': u'failure message', 'quiet': True, 'that': ['var'], 'msg': None, 'success_msg': 'success message'}
    set_module_args(module_args)

    cond = Conditional()
    cond.when = ['var']
    test_result = cond.evaluate_conditional(templar=None, all_vars=None)


# Generated at 2022-06-11 11:23:22.177398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import imp
    import argparse

    class OptionsMock(object):
        pass

    class FileLoaderMock(object):
        pass

    class DataLoaderMock(object):
        pass

    class DisplayMock(object):
        def priv(self, text):
            print(text)

    class VariableManagerMock(object):
        def __init__(self):
            self.cwd = ""
            self.extra_vars = {}
            self.options_vars = {}
            self.inventory = None

    class RunnerMock(object):
        def __init__(self):
            self.display = DisplayMock()
            self.variable_manager = VariableManagerMock()

    class PlayMock(object):
        def __init__(self):
            self.loader = FileLoader

# Generated at 2022-06-11 11:23:22.747984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Generated at 2022-06-11 11:23:31.159880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    # Set the ActionModule to None
    result = {'assertion': None, 'changed': False, 'evaluated_to': None, 'failed': False, 'invocation': {'module_args': {}},
              'msg': 'Assertion failed', 'parsed': True, 'skipped': False, '_ansible_verbose_always': True,
              '_ansible_no_log': False}


# Generated at 2022-06-11 11:23:35.529044
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of class ActionModule
    actionModule = ActionModule()

    # Check valid arguments
    assert 'fail_msg' in actionModule._VALID_ARGS
    assert 'msg' in actionModule._VALID_ARGS
    assert 'quiet' in actionModule._VALID_ARGS
    assert 'success_msg' in actionModule._VALID_ARGS
    assert 'that' in actionModule._VALID_ARGS

# Generated at 2022-06-11 11:24:01.646386
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionBase

# Generated at 2022-06-11 11:24:06.884781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None
    assert str(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)) is not None

# Generated at 2022-06-11 11:24:18.014675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unicode import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-11 11:24:27.269915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __builtin__ as builtins
    def test_builtins(module):
        if module == '__builtin__':
            return builtins
        return None

    # base common arguments
    class Bunch(object):
        def __init__(self, **kw):
            self.__dict__.update(kw)

    mod_args = dict(
        fail_msg="Assertion failed",
        success_msg="All assertions passed",
        quiet=False,
        that=['test == true'],
    )
    tmp = Bunch(path='path')
    task_vars = dict()

    # base test
    class BaseTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(BaseTest, self).run(tmp, task_vars)

    #

# Generated at 2022-06-11 11:24:38.670224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule(
        task=dict(action=dict(module_name='assert')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # Test that status is changed to changed
    assert_result = action_module._convert_to_boolean(dict(
        changed=False, assertion='(foo == bar)', msg='Assertion failed', evaluated_to=False
    ))
    assert assert_result == dict(
        changed=False, assertion='(foo == bar)', msg='Assertion failed', evaluated_to=False
    )
    # Test that status is changed to failed
    assert_result = action_module._convert_to_boolean

# Generated at 2022-06-11 11:24:49.419481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    action = ActionModule('fail')

    action._task = Task()
    setattr(action._task, 'name', 'fail')
    action._task.action = 'fail'
    action._task.loop = None
    action._task.args = {'that': '{{ false }}'}

    # Host(

# Generated at 2022-06-11 11:24:50.936591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert boolean(True, strict=False) is True
    assert boolean(False, strict=False) is False
    assert boolean(False) is False

# Generated at 2022-06-11 11:24:56.905751
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class ActionModule(ActionModule):

        def __init__(self, *args, **kwargs):
            #print("ActionModule __init__")
            #print("args = %s" % (args,))
            #print("kwargs = %s" % (kwargs,))
            self.args = args[2]
            self.task = args[4]

        def evaluate_conditional(self, templar, all_vars):
            print("templar = %s, all_vars = %s" % (templar, all_vars))
            return True

    # Create an object of ActionModule class
    obj = ActionModule('hello-world', 'non_play_context', {'fail_msg': 'Fail', 'success_msg': 'Success'}, None, {'args': {}}, None, None)



# Generated at 2022-06-11 11:24:59.263759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    acm = ActionModule(None)
    action_name = acm.get_action_name()
    assert action_name == 'assert'
    acm.run()

# Generated at 2022-06-11 11:25:09.251987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args=dict(that=['value==True'], fail_msg='Failed', msg=['F', 'F'], quiet=True, success_msg=['All', 'passed'])))
    res = module.run(task_vars=dict(value=True))
    assert res['changed'] == False
    assert res['msg'] == ['All', 'passed']
    assert res['_ansible_verbose_always'] == False
    res = module.run(task_vars=dict(value=False))
    assert res['failed'] == True
    assert res['assertion'] == 'value==True'
    assert res['evaluated_to'] == False
    assert res['msg'] == 'Failed'
    assert res['_ansible_verbose_always'] == False

# Unit

# Generated at 2022-06-11 11:25:45.220385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:25:46.133913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-11 11:25:51.881837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
        task=dict(action='fail', fail_msg='nooooooo, assertion failed', success_msg='yesssssss, assertion passed'),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert x.run(tmp=None, task_vars={'myvar': 'myvalue'}) == {'changed': False, 'msg': 'yesssssss, assertion passed'}


# Generated at 2022-06-11 11:25:54.776110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = {'hostvars': {'my_host': 'my_host_value'}}
    action = ActionModule(None, {'when': 0}, None)
    #assert action._task.when == 0, "Did not save when"

# Generated at 2022-06-11 11:25:55.656914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-11 11:25:57.426412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:25:57.958659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:25:58.581659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:26:07.926173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Set arguments of method run

    # Create a new mock object for ansible.playbook.conditional.Conditional
    class MockConditional(object):
        def __init__(self):
            self.that = None

        def evaluate_conditional(self, templar, all_vars):
            return True
    mock_cond = MockConditional()

    # Set test values of method run's arguments
    tmp = None
    task_vars = dict()
    tmp = None
    tmp = None
    tmp = None
    tmp = None
    tmp = None
    tmp = None
    tmp = None
    tmp

# Generated at 2022-06-11 11:26:09.164840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(1,2)

# Generated at 2022-06-11 11:27:20.142464
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert test_action_module.TRANSFERS_FILES is False

# Generated at 2022-06-11 11:27:28.332594
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #creating dummny object
    class dummy_class:
        def __init__(self):
            pass

    class dummy_task:
        def __init__(self):
            self.args = {'that' : ['test_hostname == "test"', '1 != 2']}
    class dummy_loader:
        def __init__(self):
            pass
    class dummy_templar:
        def __init__(self):
            pass

    #creating instances of created dummy classes and their attributes
    obj_ActionModule_run = ActionModule(dummy_class(), dummy_task(), dummy_loader(), dummy_templar())
    obj_dummy_task = dummy_task()
    obj_dummy_loader = dummy_loader()
    obj_dummy_loader.path_dw = '.'
    obj

# Generated at 2022-06-11 11:27:37.349773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constructing a mock object
    mock_self = type('mock_self', (object,), {})
    mock_self._task = type('mock_task', (object,), {})
    mock_self._task.args ={}
    mock_self._task.args['msg'] = 'Assertion failed'
    mock_self._task.args['that']  = ['foo']
    mock_self._task.args['quiet'] = False
    mock_self._task.args['success_msg'] = None
    mock_self._task.args['fail_msg'] = None

    assert type(mock_self).run(mock_self, None, None) is not None

# Generated at 2022-06-11 11:27:47.486579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'remote_user'])
    options = Options(connection='smart', module_path=None, forks=100, become=None, become_method=None, become_user=None, check=False, diff=False, remote_user='ansible')

    task = Task()
    task._role = None

# Generated at 2022-06-11 11:27:49.650906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule("test_name")
    assert a._task.name == "test_name", "Name of the task is incorrect"

# Generated at 2022-06-11 11:27:59.586004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,host_list='localhost,')
    variable_manager.set_inventory(inventory)

    # example task
    task = Task()
    task.action = 'fail'
    task.name = 'test_name'

# Generated at 2022-06-11 11:28:09.807241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ansible_fake():
        def __init__(self, args):
            self.args = args

    class loader_fake():
        def __init__(self, *args):
            pass

    fake_loader = loader_fake('/tmp/playbook')
    fake_task = ansible_fake({'that': ['a < b', 'a != c', 'c == d'], 'fail_msg': 'failed', 'msg': 'Failed', 'quiet': 'True', 'success_msg': 'Successful'})
    action_module = ActionModule(fake_loader, fake_task, '/tmp/connection')
    action_module.task_vars = dict()
    result = action_module.run(None, None)
    assert not result['failed']
    assert result['msg'] == 'Successful'


# Generated at 2022-06-11 11:28:16.315694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    import sys
    import os
    import unittest
    from ansible.errors import AnsibleError
    from ansible.playbook import Playbook, Play
    from ansible.playbook.play_context import PlayContext, PLAY_CONTEXT_ATTRIBUTES
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-11 11:28:17.133122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-11 11:28:17.940874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action = ActionModule()