

# Generated at 2022-06-11 11:21:16.134384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO: implement your test here

# Generated at 2022-06-11 11:21:24.517810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(args=dict(that=['a == b', 'b == c'], msg='failure message')),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    result = action_module.run(
        tmp=None,
        task_vars=dict(a=1, b=2, c=2)
    )

    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'
    assert result['changed'] == False


# Generated at 2022-06-11 11:21:29.225423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fail_msg = ['This is fail msg', 'This is fail msg']
    success_msg = ['This is success msg', 'This is success msg']
    fail_msg = 'This is fail msg'
    success_msg = 'This is success msg'
    quiet = False
    assert fail_msg ==  'This is fail msg'
    assert success_msg ==  'This is success msg'
    assert quiet == False

# Generated at 2022-06-11 11:21:36.087963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    d = '''
    {
        "action": {
            "__ansible_module__": "assert", 
            "__ansible_arguments__": {
                "msg": "Assertion failed", 
                "that": [
                    "1 == 1"
                ]
            }, 
            "__ansible_verbose_always": true
        }
    }
    '''
    import json
    a = ActionModule(json.loads(d))
    assert a.__class__.__name__ == "ActionModule"



# Generated at 2022-06-11 11:21:36.619196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:21:46.378958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    class DummyModule():
        pass

    context = PlayContext()
    context._connection = DummyModule()
    context._play_context = DummyModule()
    context.in_task_include = False
    context.stdout_callback = 'dummy'

    am = ansible.plugins.action.ActionModule(task=DummyModule(), connection=DummyModule(), play_context=context, loader=DummyModule(), templar=DummyModule(), shared_loader_obj=DummyModule())
    assert isinstance(am, ActionBase)
    assert isinstance(am, object)


# Generated at 2022-06-11 11:21:53.534769
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:21:54.335584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:22:06.615952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test fails when using a dictionary
    """
    action = ActionModule(None, {'fail_msg': {'a': 'is not expected'}})
    # task_vars = {}
    action._templar = None
    action._loader = None
    try:
        action.run(None, None)
    except ValueError as e:
        assert str(e) == 'Incorrect type for fail_msg or msg, expected a string or list and got <type \'dict\'>'
    except Exception as e:
        assert False

    """
    Test fails when using a integer
    """
    action = ActionModule(None, {'fail_msg': 1 })
    # task_vars = {}
    action._templar = None
    action._loader = None

# Generated at 2022-06-11 11:22:13.458929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    task = Task()
    action = ActionModule()
    action._task = task
    task.action = "assert"
    task.args = {}

    task.args['that'] = "{{ var }}"
    action._task.vars = dict(var=None)
    assert action.run()['failed'] is True

    task.args['that'] = "{{ var }}"
    action._task.vars = dict(var=1)
    assert action.run()['failed'] is False

    task.args['that'] = "{{ var1 == var2 }}"
    action._task.vars = dict(var1=1, var2=1)
    assert action.run()['failed'] is False

    task.args['that'] = []

# Generated at 2022-06-11 11:22:32.556168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with dictionary
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='fail', args=dict(msg='{{error_msg}}'))),
        ]
    )
    play = Play().load(play_source, variable_manager={}, loader=None)

    tqm = None
    loader = None
    variable_manager = None

# Generated at 2022-06-11 11:22:44.298014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''test_ActionModule.py: Test case for ActionModule class'''

    # Test simple msg
    # Setup mocks

    # Setup class instance
    action_module = ActionModule(
        task=dict(action=dict(module_name='fail', args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())

    # Invoke method under test
    result = action_module.run(tmp=None, task_vars=None)
    assert result['changed'] is True
    assert result['msg'] == 'Assertion failed'

    # Test msg from msg
    # Setup mocks

    # Setup class instance

# Generated at 2022-06-11 11:22:44.734902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:22:55.075816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest import TestCase

    class TestActionModule(ActionModule):
        pass

    class AnsibleModuleMock:
        def __init__(self, params):
            self.args = params

    class AnsibleTaskMock:
        def __init__(self, params):
            self.args = params

    # setup arguments for initializing test object
    params = { 'fail_msg': 'Assertion failed',
               'quiet': 'False',
               'success_msg': 'All assertions passed',
               'that': [ "1 == 2",
                         "1 == 1"
               ]}

    task_vars = { 'ansible_version': { "full": "2.1.0.0" } }

    # initialize mock object
    am = TestActionModule(AnsibleModuleMock(params))

# Generated at 2022-06-11 11:22:58.650058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    task = Task()
    task.args = {'that': [], 'msg': ['foo', 'bar']}
    assert isinstance(ActionModule(task, dict()), ActionModule)

# Generated at 2022-06-11 11:23:09.371268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 11:23:18.072889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.utils.template
    import ansible.utils.unsafe_proxy
    import ansible.vars
    import ansible.inventory
    import ansible.constants as C
    import os
    import tempfile
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task
    module_loader = 'ansible.parsing.dataloader.DataLoader'
    cls = ActionModule
    tmpdir = tempfile.mkdtemp()
    host = ansible.inventory.host.Host(name="test_1")

# Generated at 2022-06-11 11:23:22.487160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    action = action_loader.get('assert', class_only=True)

    display = Display()
    play_context = dict()
    loader = None

    action = action(play_context, play_context, loader, display)

    action.run(task_vars=dict())


# Generated at 2022-06-11 11:23:30.926017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    task.args = {'that': ['True == True', 'True != False']}
    am = ActionModule(task, {})

    ans = am.run(None, None)

    assert not ans['failed']
    assert ans['msg'] == 'All assertions passed'

    task.args = {'that': ['True == True', 'True != False', 'True == False']}
    am = ActionModule(task, {})

    ans = am.run(None, None)

    assert ans['failed']
    assert ans['msg'] == 'Assertion failed'
    assert ans['evaluated_to'] == False
    assert ans['assertion'] == 'True == False'

    task.args = {'that': 'True == False'}
    am = Action

# Generated at 2022-06-11 11:23:40.054892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(action='ActionModule')
    assert module.action == 'ActionModule'
    assert module.name is None
    assert module._parent is None
    assert module._task is None
    assert module._private_data_dir is None
    assert module._shared_loader_obj is None
    assert module._connection is None
    assert module._loader is None
    assert module._templar is None
    assert module._templar_cheetah is None
    assert module._task_vars is None
    assert module._non_persistent_fact_cache is None
    assert module._play_context is None
    assert module._loaded_deps is None
    assert module._cleanup_files is None
    assert module._uses_delegate is None
    assert module.remote_user is None
    assert module.remote_pass is None

# Generated at 2022-06-11 11:23:56.291148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-11 11:24:04.742658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_instance = ActionModule(task={"action": {"__ansible_module__": "assert"}}, connection=None,
                                  play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert class_instance._task.action == 'assert'
    assert class_instance._task.delegate_to == 'localhost'
    assert class_instance._task.notify == []
    assert class_instance._task.loop == []
    assert class_instance._task.when == []
    assert class_instance._task.loop_control == {}
    assert class_instance._task.register == None
    assert class_instance._task.ignore_errors == False
    assert class_instance._task.local_action == None
    assert class_instance._task.args == {}

# Generated at 2022-06-11 11:24:16.213182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    task_args = dict(
        fail_msg='Assertion failure',
        msg='Assertion failure',
        quiet=False,
        success_msg='All assertions passed',
        that='"localhost" in groups'
    )

    action = action_loader.get('assert', task=dict(args=task_args), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 11:24:26.136075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    from ansible.vars import VariableManager

    class MockRunner:
        def __init__(self, loader, host_vars, task_vars):
            self._dump_results = {'contacted': {}}
        def get_host_vars(self, host):
            return {}
        def add_host_vars(self, host, hostvars):
            pass
        def get_inventory(self):
            return {}

    class MockModule(object):
        def __init__(self, loader=None, templar=None):
            pass
        def fail_json(self, *args, **kwargs):
            return args, kw

# Generated at 2022-06-11 11:24:37.600953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    class FakeTask:
        def __init__(self):
            self.args = dict()

    class FakePlay:
        def __init__(self):
            self.hostvars = dict()

    class FakeLoader:
        def __init__(self):
            pass

        def get_basedir(self):
            return ''

    class FakeTemplar:
        def __init__(self):
            pass

    class FakeDatastore:
        def __init__(self):
            pass

        def get_var(self, key, play=None, host=None, task=None, default=None):
            return None

    class FakeVarsModule:
        def __init__(self, data):
            self.vars = data


# Generated at 2022-06-11 11:24:48.648810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    from mock import patch
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    task = Task()
    task._role = Role()
    play_context = Mock()
    task.block = Block()
    task.block.parent_block = Mock()
    task.block.parent_block.root_block = Mock()
    task.block.parent_block.root_block.handlers = [Handler()]
    role_context = Mock()
    play = Play().load({}, loader=Mock(), variable_manager=Mock())
    task.play = play
    runner_connection = Mock()
    task._connection

# Generated at 2022-06-11 11:24:57.623517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mockTask1 = {
        'action': 'fail',
        'args': {
            'fail_msg': 'failure message',
            'msg': 'failure message',
            'quiet': 'True',
            'success_msg': 'success message',
            'that': 'test_args'
        },
        'delegate_to': 'localhost',
        'register': 'test_var1'
    }

    mockTask2 = {
        'action': 'fail',
        'args': {
            'fail_msg': 'failure message',
            'msg': 'failure message',
            'quiet': True,
            'success_msg': 'success message',
            'that': 'test_args'
        },
        'delegate_to': 'localhost',
        'register': 'test_var2'
    }



# Generated at 2022-06-11 11:25:07.554520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import module_loader
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.utils.template
    import ansible.vars.hostvars
    module_loader.add_directory('./lib')
    params = {'a': 1}
    block = ansible.playbook.block.Block()
    task = ansible.playbook.task.Task()
    task_vars = ansible.vars.hostvars.HostVars(host_name='localhost')
    tmp = 'tmp'
    action = ActionModule(task, params, tmp)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:25:14.486714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects for ActionModule.run()
    adhoc_task = DummyTask()
    adhoc_task.args = { 'that': ["'a' == 'b'", "'a' == 'a'"] }
    adhoc_task.args['msg'] = 'This is a demo message'
    adhoc_task.args['quiet'] = True

    my_action_module = ActionModule(adhoc_task, DummyPlaybookBase())
    result = my_action_module.run(tmp=None, task_vars={})
    print(result)


# Generated at 2022-06-11 11:25:18.980106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor call of ActionModule with valid and invalid arguments
    '''
    # Case1, No argument passed to constructor
    assert_raises(TypeError, ActionModule)

    # Case2, Invalid values are passed to constructor
    assert_raises(TypeError, ActionModule, [])
    assert_raises(TypeError, ActionModule, None)
    assert_raises(TypeError, ActionModule, 'test')

# Generated at 2022-06-11 11:26:01.978335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of class ActionModule """
    assert isinstance(ActionModule, object)


# Generated at 2022-06-11 11:26:12.133457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    import os

    # Create a mock task, play, and variable manager
    # to be used by the action module
    task = Task()
    task._role = Role()
    task.args = dict()

    # Test run function
    # Tests assertion failure with default fail_msg
    host = Host('localhost')

# Generated at 2022-06-11 11:26:22.248439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleError
    import ansible.constants as C
    import ansible.utils.plugin_docs as plugin_docs

    class ActionModuleMock(ActionBase):
        TRANSFERS_FILES = False


# Generated at 2022-06-11 11:26:26.174183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a constructor test for ActionModule.
    It checks if it raises AnsibleError when called without parameters.
    """
    action = None
    try:
        action = ActionModule(None, None)
    except AnsibleError:
        pass
    assert action is None

# Generated at 2022-06-11 11:26:29.871131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(play_context=dict(),
            new_stdin='new stdin', loader=dict())
    assert module.play_context == dict()
    assert module.new_stdin == 'new stdin'
    assert module.loader == dict()


# Generated at 2022-06-11 11:26:32.145719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ACTION_MODULE_SUT = ActionModule(None, None, None, None)
    assert ACTION_MODULE_SUT.run() == 'ActionModule.run method'

# Generated at 2022-06-11 11:26:41.209001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import yaml

    yaml_inventory = """
        all:
            hosts:
                localhost:
                    ansible_connection: local
                elsehost:
                    ansible_connection: local
        """

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=yaml.load(yaml_inventory))
    variable_manager = VariableManager(loader=loader, inventory=inv_manager, version_info={"check_mode": False})
    task_vars = {"ansible_check_mode": False}

# Generated at 2022-06-11 11:26:51.080248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestVars:
        def __init__(self, my_var):
            self.my_var = my_var

    role_path = 'tests/unit/plugins/action/role'
    tmp_path = 'tests/unit/plugins/action/tmp'
    test_host = '127.0.0.1'
    test_port = '22'
    test_user = 'user'
    test_pass = 'pass'
    test_pkey = 'key'
    test_playbook_path = '/path/to/play.yml'
    test_loader = 'loader'
    test_templar = 'templar'
    test_shared_loader_obj = 'shared_loader_obj'
    test_inventory = 'inventory'

    test_runner = 'runner'

# Generated at 2022-06-11 11:26:58.421743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of ActionModule class
    # This is done by calling the constructor with these arguments
    self = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # Call function run with these arguments
    tmp = None
    task_vars = None
    try:
        result = self.run(tmp=tmp, task_vars=task_vars)
        assert False
    except AnsibleError as e:
        assert 'conditional required in "that" string' in str(e)


# Generated at 2022-06-11 11:27:00.405857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object to check
    action_module = ActionModule()
    assert type(action_module == ActionModule)


# Generated at 2022-06-11 11:27:57.196449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:27:58.069371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-11 11:28:08.366907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run method without fail_msg.
    runner = ActionModule({'msg': 'Assertion failed'})
    result = runner.run()
    assert result['evaluated_to'] == False
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test run method with fail_msg.
    runner = ActionModule({'fail_msg': 'fail_msg'})
    result = runner.run()
    assert result['evaluated_to'] == False
    assert result['failed'] == True
    assert result['msg'] == 'fail_msg'
    # Test run method with msg.
    runner = ActionModule({'msg': 'msg'})
    result = runner.run()
    assert result['evaluated_to'] == False
    assert result['failed'] == True

# Generated at 2022-06-11 11:28:12.323807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_action.set_loader(loader)
    result = test_action.run(tmp=None, task_vars=None)
    assert isinstance(result, dict)

# Generated at 2022-06-11 11:28:20.043453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=no-member,protected-access
    module = ActionModule(
        task=dict(
            args=dict(
                msg='this is the message',
                quiet=True,
            ),
        ),
        connection=None,
        play_context=dict(
            check_mode=False,
        ),
    )
    result = module.run(tmp=None, task_vars={'a': 10})
    assert result.get('msg') == 'this is the message'
    assert result.get('failed') is False
    assert result.get('changed') is False


# Generated at 2022-06-11 11:28:24.517969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(action='fail'))
    result = action_module.run(None, task_vars=dict())

    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'
    assert result['evaluated_to'] == False
    assert result['assertion'] == None
    assert result['changed'] == False


# Generated at 2022-06-11 11:28:32.894158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the basic run() functionality
    task_include = dict(action=dict(module='assert', args=dict(that='1==1')))
    task_vars = dict()
    play_context = dict()
    am = ActionModule(task=task_include, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)
    results = am.run(task_vars=task_vars)
    assert results == dict(msg='All assertions passed', changed=False)

    # Test a success message
    task_include = dict(action=dict(module='assert', args=dict(that='1==1', success_msg="Test succeeded")))
    task_vars = dict()
    play_context = dict()

# Generated at 2022-06-11 11:28:40.529773
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


# Generated at 2022-06-11 11:28:46.710633
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for correct msg and method run of class ActionModule
    def get_result(task_args={}, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()


# Generated at 2022-06-11 11:28:54.011905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(loader=None, task=None, connection=None)

    # Test when fail_msg is a str and success_msg is not given
    a.task = {'args': dict(that=True, fail_msg='Some message')}
    result = a.run()

    assert result == {u'changed': False, u'msg': u'All assertions passed'}

    # Test when fail_msg is a list
    a.task = {'args': dict(that=[True, False], fail_msg=['Message 1', 'Message 2'])}
    result = a.run()
