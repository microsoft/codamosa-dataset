

# Generated at 2022-06-11 11:21:21.138961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    class ActionModule_run_Mock(ActionModule):
        def get_vars(self, load_vars=True):
            return {}
        def check_conditional(self, test_string, task_vars=None):
            return True

    mock_action = ActionModule_run_Mock(None, dict(when=False), None)

    try:
        mock_action.run(None, None)
        assert False
    except AnsibleError as e:
        assert e.message == 'conditional required in "that" string'

# Generated at 2022-06-11 11:21:22.945938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule().get_safe_args({'msg': 'abc', 'fail_msg': 'def'})


# Generated at 2022-06-11 11:21:31.101261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    module_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..')
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None
    assert action_module.loader.playbook_basedir == os.path.dirname(module_path)


# Generated at 2022-06-11 11:21:39.977327
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader

    # Initialize mocks for module parameters
    task_args = {'_ansible_selinux_special_fs': ['/var(', '/]']}

# Generated at 2022-06-11 11:21:50.156122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockModule(object):
        def __init__(self):
            self.params = {'that': 'foo: bar'}

    module = MockModule()

    action = ActionModule()
    action._task = MockModule()
    action._templar = MockModule()
    action._task.args = {'that': 'foo: bar'}
    action._loader = MockModule()
    action._ansible_version = 2.9

    # Expected result with failed assertion
    result = action.run(task_vars={'foo': 'baz'})
    assert result['changed'] is False
    assert result['failed'] is True
    assert result['evaluated_to'] is False
    assert result['assertion'] == 'foo: bar'
    assert result['msg'] == 'Assertion failed'

    # Expected result

# Generated at 2022-06-11 11:22:02.093740
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import mock
    import json
    import sys

    my_task = mock.MagicMock()
    my_task.args = {
        'fail_msg': 'Test condition failed',
        'msg': 'Test condition failed',
        'quiet': False,
        'success_msg': 'Test condition succeeded',
        'that': "['Test']"
    }

    my_task.async_val = 42

    my_task.no_log = False

    my_task.run_once = False

    my_self = mock.MagicMock()
    my_self._task = my_task
    my_self._low_level_runner_continued = False
    my_self._low_level_runner_terminated = False
    my_self._low_level_runner_noop = False
    my_self._low_

# Generated at 2022-06-11 11:22:08.242439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    new_am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert new_am.TRANSFERS_FILES == False
    assert new_am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:22:18.080761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 11:22:29.479987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import json

    from ansible.module_utils import basic
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.playbook.play_context import PlayContext

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    context = PlayContext()
    am = ActionModule(task=dict(name='test', action='assert'), play_context=context, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 11:22:41.555183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    # Create a dummy loader object
    loader_obj = action_loader._create_loader_object(class_only=True)

    # create a task dictionary
    task_vars = dict()
    test_task = dict()
    test_task['action'] = 'assert'
    test_task['args'] = dict()

    # test case 1: Fail with default message
    test_task['args']['that'] = {'a':1, 'b':2}
    action_obj = action_loader._create_action_plugin('assert', task=test_task, connection=None, play_context=None, loader=loader_obj, templar=None, shared_loader_obj=None)
    res = action_obj.run(task_vars=task_vars)


# Generated at 2022-06-11 11:22:49.652779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    print(am)

# Generated at 2022-06-11 11:22:57.359755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_task = dict(
        action=dict(
            module='assert',
            fail_msg='Fail',
            quiet=False,
            success_msg='Success',
            that=['a == b', 'True']
        )
    )

    mock_loader = None
    my_task_vars = dict()

    my_action = ActionModule(my_task, mock_loader, tmp_path='/tmp')
    my_action.prepare_task_vars(my_task_vars)

    assert my_action



# Generated at 2022-06-11 11:23:00.744560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        my_object = ActionModule(loader=None, templar=None, shared_loader_obj=None)
        assert my_object.TRANSFERS_FILES == False
    except:
        assert False

# Generated at 2022-06-11 11:23:01.385685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-11 11:23:02.018328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:23:05.396944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_ActionModule is not None

# Generated at 2022-06-11 11:23:14.620055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  t1 = {'name': 'test', 'when': ['test_condition']}
  arguments = {'fail_msg': ['test_fail_msg'], 'that': 'test_that', 'quiet': False}
  t = ActionModule(t1, arguments, [], [], [])
  assert t.run({}) == {'msg': "Assertion failed", 'assertion': 'test_that', 'failed': True, 'evaluated_to': False, '_ansible_verbose_always': True}

  t1 = {'name': 'test', 'when': ['test_condition']}
  arguments = {'msg': ['test_msg'], 'that': 'test_that', 'quiet': False}
  t = ActionModule(t1, arguments, [], [], [])

# Generated at 2022-06-11 11:23:19.984330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the class object
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check for class type
    if not isinstance(am, ActionModule):
        raise AssertionError("Could not create ActionModule object")
    # Check for class namespace
    if not hasattr(am, "run"):
        raise AssertionError("Class '%s' does not implement 'run'" % type(am))

# Generated at 2022-06-11 11:23:26.279148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #pylint: disable=too-few-public-methods
    class MockModule:
        '''Ensure our assertions are correct'''
        class FailAction:
            pass

        class SuccessAction:
            pass

        class AssertAction:
            pass

    module = ActionModule(MockModule())
    assert module.FailAction is MockModule.FailAction, "FailAction not added"
    assert module.SuccessAction is MockModule.SuccessAction, "SuccessAction not added"
    assert module.AssertAction is MockModule.AssertAction, "AssertAction not added"

# Generated at 2022-06-11 11:23:34.392953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    # setup and create an instance of ActionModule class
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    ansible_host = Host(name="test_host", port=22, groups=['test_group'], variables={'ansible_python_interpreter': '/usr/bin/python'})
    ansible_host.set_variable('ansible_connection', 'local')
    module_name = 'fail'
    module_args = dict(msg='This is a test')

# Generated at 2022-06-11 11:23:45.186220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ensure ActionModule.run() can handle failure
    # arguments: tmp, task_vars
    # Returns dict
    pass

# Generated at 2022-06-11 11:23:54.589981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # class AnsibleModule(object):
    #     pass
    import unittest

# Generated at 2022-06-11 11:24:03.029133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    :return:
    """
    # First test the case when the that parameter is not supplied

    # Construct an instance of class Task
    task = Task()

    # Construct an instance of class ActionModule
    action_module = ActionModule(task, dict())

    # Try running the 'run' method of class ActionModule
    # This is expected to raise an error because the that parameter is not supplied
    try:
        action_module.run()
    except AnsibleError as exception:
        # Verify the details of the exception
        assert exception.message == 'conditional required in "that" string', exception.message
    else:
        raise AssertionError('AnsibleError exception not raised')

    # Second test the case when the that parameter is supplied, but it is not a list

    # Construct an instance of class ActionModule

# Generated at 2022-06-11 11:24:06.101231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule({'action_plugins': ['/usr/lib/ansible/action']}, '/usr/lib/ansible/action')
    assert type(act) == ActionModule

# Generated at 2022-06-11 11:24:17.496960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.display import Display
    from ansible.utils.shlex import shlex_split
    from ansible.parsing.splitter import parse_kv
  
    task_vars = dict()
    loader = 'foo'
   
    # a mock class that deals with shlex
    class MockTask(object):
        args = dict()

        def __init__(self, args):
            self.args = args    

    # a mock class that deals with templar
    class MockTemplar(object):
        def __init__(self, loader):
            self.loader = loader
            self.templar = dict()

        def template(self, value):
            if value == '{{ansible_lsb.codename}}':
                return 'trusty'
            else:
                return value

   

# Generated at 2022-06-11 11:24:26.929133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import conditional_loader as loader
    from ansible.playbook.task import Task

    class MockModuleLoader:
        @staticmethod
        def get(templar, name):
            class MockActionModule:
                def __init__(self, templar=None, shared_loader_obj=None, action=None, play_context=None, new_stdin=None):
                    self.templar = templar

                def run(self, tmp=None, task_vars=None):
                    return (True, {})

            return MockActionModule(templar)

    # set up some dummy data
    args = {'that': 'foo.bar == 1', 'msg': 'Result of test was wrong'}
    mock_loader = MockModuleLoader()
    mock_task = Task()
    mock

# Generated at 2022-06-11 11:24:30.578887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for incorrect 'msg' argument
    # Test for incorrect success message
    # Test for incorrect fail message
    # Test for incorrect 'that' argument
    # Test for quiet mode
    # Test for pass
    # Test for fail

    return

# Generated at 2022-06-11 11:24:42.200448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    import sys
    import yaml

    class Model:

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            return 'Model(%s)' % ', '.join('%s=%r' % (k, v) for k, v in sorted(self.__dict__.items()))


# Generated at 2022-06-11 11:24:42.822128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:24:44.314578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO: Write unit test for method run of class ActionModule"

# Generated at 2022-06-11 11:25:08.841608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def assert_key_and_value_in_dict(key, value, dict):
        assert key in dict
        assert dict[key] == value

    task_args = {}
    task_vars = {}

    action = ActionModule(None, task_args, task_vars)
    try:
        action.run()
    except:
        assert False, 'ActionModule.run() raises exception'

    task_args = {}
    action = ActionModule(None, task_args, task_vars)
    task_args['that'] = 'fail==False'
    try:
        action.run()
    except:
        assert False, 'ActionModule.run() raises exception'

    task_args = {}
    action = ActionModule(None, task_args, task_vars)

# Generated at 2022-06-11 11:25:17.526984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import collections
    import ansible.plugins
    import ansible.plugins.action

# Generated at 2022-06-11 11:25:25.420765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mocks
    task_vars = dict()

    # test case
    action_module = ActionModule(None, None)
    result = action_module.run(tmp=None, task_vars=task_vars)

    # assert validation.
    assert result['failed'] == True
    assert result['assertion'] == ''
    assert result['evaluated_to'] == False
    assert result['msg'] == 'Assertion failed'


if __name__ == '__main__':
    # execute with coverage
    import coverage
    C = coverage.Coverage()
    C.start()
    test_ActionModule_run()
    C.stop()
    C.report()

# Generated at 2022-06-11 11:25:26.279085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule().run() == {}

# Generated at 2022-06-11 11:25:36.112245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    # Test 1,
    # Test description:
    # tests to make sure that when task.args contains the key 'that'
    # run method does not throw an exception.
    # Test wrong input:
    # task.args does not contain key 'that'
    # Test correct input:
    # task.args contains key 'that'
    # Test output:
    # run method does not throw an exception
    ActionModule_test1 = ActionModule()
    ActionModule_test1.task = lambda: None
    ActionModule_test1.task.when = lambda: None
    ActionModule_test1.task.when = "none"
    ActionModule_test1.task.args = lambda: None

# Generated at 2022-06-11 11:25:38.488094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action != None


# Generated at 2022-06-11 11:25:40.639868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(ActionBase())
    s = str(x)
    assert s == '<action_plugin.ActionModule object at 0x7f5c7c32afd0>'


# Generated at 2022-06-11 11:25:41.393426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass


# Generated at 2022-06-11 11:25:45.506877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    value = 'fail_msg'
    task_vars = dict()
    result = ActionModule().run(task_vars)

    assert result
    assert result.get('assertion') is None
    assert result.get('evaluated_to') is None
    assert result.get('failed') is False
    assert result.get('msg') == 'All assertions passed'
    assert result.get('changed') is False


# Generated at 2022-06-11 11:25:48.837472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.TRANSFERS_FILES is False
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:26:30.344707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    assert m._valid_args == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:26:31.882934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:26:35.046595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='assert')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert module is not None

# Generated at 2022-06-11 11:26:44.625585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test: Test when the argument fail_msg is not present and msg is present
    action_module_instance = ActionModule()
    action_module_instance._task.args['msg'] = 'A simple message'
    action_module_instance._task.args['that'] = ['A simple assertion']

    result = action_module_instance.run()

# Generated at 2022-06-11 11:26:54.467863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    # Default items of the fourth parameter, task_vars
    task_vars = dict()

    action = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.task_vars = task_vars
    action._task.args = dict()

    module_return = dict()
    module_return['_ansible_verbose_override'] = False
    module_return['_ansible_no_log'] = False
    module_return['_ansible_delegated_vars'] = dict()
    module_return['_ansible_module_name'] = ''
    module_return['_ansible_module_name'] = None

# Generated at 2022-06-11 11:27:05.005977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import imp
    
    #------import ansible source code-------------
    global_module_utils_path=os.path.join(os.getcwd(),'hacking','test_utils','module_utils')
    global_module_utils_file=os.path.join(global_module_utils_path,'__init__.py')
    if os.path.exists(global_module_utils_file):
        module_utils_path=global_module_utils_path
    else:
        module_utils_path=os.path.join(os.path.dirname(os.path.realpath(__file__)),'..','module_utils')
    
    if not module_utils_path in sys.path:
        sys.path.insert(0,module_utils_path)
    
   

# Generated at 2022-06-11 11:27:14.952200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  code_path = os.path.dirname(os.path.realpath(sys.argv[0]))
  root_dir = os.path.abspath(os.path.join(code_path, os.pardir, os.pardir, os.pardir))
  data_path = os.path.join(root_dir, 'lib', 'ansible', 'modules', 'metricbeat')
  assert os.path.isdir(data_path)
  sys.path.insert(0, data_path)
  from action_plugins.ActionModule import ActionModule
  assert ActionModule is not None

  # This is the simplest test, the test succeeds

# Generated at 2022-06-11 11:27:24.943118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    success_msg = "All assertions passed"
    fail_msg = "Assertion failed"

    assert module.run(task_vars={'test_var': [1,2]},
                      tmp={'that': 'test_var is not defined'}) == {'changed': False, 'msg': fail_msg}
    assert module.run(task_vars={'test_var': [1,2]},
                      tmp={'that': 'test_var is defined'}) == {'changed': False, 'msg': success_msg}
    assert module.run(task_vars={'test_var': [1,2]},
                      tmp={'that': 'test_var is equal to [1,2]'}) == {'changed': False, 'msg': success_msg}

# Generated at 2022-06-11 11:27:29.181152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule._task.args['fail_msg'] == None
    assert actionModule._task.args['msg'] == None
    assert actionModule._task.args['quiet'] == False
    assert actionModule._task.args['success_msg'] == None
    assert actionModule._task.args['that'] == None

# Generated at 2022-06-11 11:27:37.878938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create arguments for AnsibleModule
    module = AnsibleModule(
    )

    # Create instance of class ActionModule and execute method run
    actionmodule = ActionModule(
        module=module,
        task=dict(
            args=dict(
                fail_msg='Assertion failed',
                msg='Assertion failed',
                quiet=True,
                success_msg='All assertions passed',
                that='Test'
            )
        )
    )
    result = actionmodule.run()

    # Check result
    assert type(result) is dict
    assert result['changed'] is False
    assert result['msg'] == 'All assertions passed'


# Generated at 2022-06-11 11:28:49.251347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Constructor test
    # action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    action_module = ActionModule(dict(), dict(), dict(), dict(), dict(), dict())
    assert type(action_module) == ActionModule


# Generated at 2022-06-11 11:28:56.280913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_run_initialisation:
        def __init__(self):
            self.task = None

        def _get_vars(self):
            return {}

    actionModule_run_initialisation = ActionModule_run_initialisation()

    class ActionBase_run_initialisation:
        def __init__(self):
            self.task = None
            self.diff = None
            self.task.args = {}

        def _low_level_execute_command(self, cmd, tmp_path, sudo_user, sudoable):
            return cmd, tmp_path, sudo_user, sudoable

        def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None, persist_files=False):
            module_result = {}

# Generated at 2022-06-11 11:29:02.982455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ validate requirement for msg or fail_msg """
    test_action = ActionModule(None, None, None, None, None, None, None, None)
    assert test_action, "Expected valid action object"

    test_action._task.args = {'that': '{{false}}'}
    try:
        test_action.run(None, None)
    except AnsibleError as err:
        assert 'msg or fail_msg' in str(err), 'failed to raise AnsibleError'

    test_action._task.args['fail_msg'] = 'Incorrect msg'
    try:
        test_action.run(None, None)
    except AnsibleError as err:
        assert 'Incorrect type' in str(err), 'failed to raise AnsibleError'


# Generated at 2022-06-11 11:29:09.861493
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()
    action._templar = DictType()

    def taskDict(that):
        return {
            'name': 'test assert',
            'action': {
                'module': 'assert',
                'args': {
                    'that': that
                }
            }
        }

    def taskDictWithFailMsg(that):
        task = taskDict(that)
        task['action']['args']['fail_msg'] = ['Assertion failed']
        return task

    def taskDictWithSuccMsg(that):
        task = taskDict(that)
        task['action']['args']['success_msg'] = 'Assertions passed'
        return task

    # Test that with simple that value, the assert task succeeds

# Generated at 2022-06-11 11:29:17.724983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of AnsibleOptions
    ansible_options = AnsibleOptions(connection='conn',
                                     module_path='.',
                                     forks=10,
                                     remote_user='remote_user',
                                     private_key_file='private_key_file',
                                     ssh_common_args='ssh_common_args',
                                     ssh_extra_args='ssh_extra_args',
                                     sftp_extra_args='sftp_extra_args',
                                     scp_extra_args='scp_extra_args',
                                     become='no',
                                     become_method='sudo',
                                     become_user='root',
                                     verbosity='vvvv',
                                     check='no')

    # Create an instance of PlayContext

# Generated at 2022-06-11 11:29:19.391097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    at = ActionModule(None, None, None, None)
    assert isinstance(at, ActionModule)

# Generated at 2022-06-11 11:29:20.223481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None

# Generated at 2022-06-11 11:29:26.690908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    action_class = action_loader.get('assert', class_only=True)

    a = ActionModule(
        task=dict(args=dict(
            that='myvar == true',
            fail_msg='Message',
            success_msg='Message',
            quiet=False,
        )),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    a._templar = dict()
    a._templar['vars'] = dict()
    a._templar['vars']['myvar'] = True

    a.run()

# Generated at 2022-06-11 11:29:34.320339
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:29:36.733487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ansible.plugins.action' in str(ActionModule)
test_ActionModule.unittest = ['test_ActionModule']

if __name__ == '__main__':
    import unittest
    unittest.main(verbosity=2)