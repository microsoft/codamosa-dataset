

# Generated at 2022-06-11 11:21:19.811808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('task', 'play', False, 'my_loader', 'my_templar', {}, {}, 'localhost')
    assert action._play is not None
    assert action._task is not None
    assert action._loader is not None
    assert action._templar is not None
    assert action._shared_loader_obj is not None
    assert action._connection is not None
    assert action._play_context is not None

# Generated at 2022-06-11 11:21:26.278507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Load ActionModule
    if not ActionModule.__doc__:
        ActionModule.__doc__ = ''
    if not ActionModule.run.__doc__:
        ActionModule.run.__doc__ = ''

    # Create object
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check __doc__
    assert am.__doc__ == ActionModule.__doc__

    # Check run.__doc__
    assert am.run.__doc__ == ActionModule.run.__doc__

# Generated at 2022-06-11 11:21:35.142818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test of AnsibleModule._get_module_args() """

    class TestActionModule(ActionModule):
        ''' Custom ActionModule for test with method run '''

        def run(self, tmp=None, task_vars=None):
            ''' Run action as a test '''
            pass

    # Test implicit that
    task = dict(action=dict(module='assert', that='foo'))
    module = TestActionModule(task, dict())
    assert module._task.args['that'] == ['foo']

    # Test list that
    task = dict(action=dict(module='assert', that=['foo', 'bar']))
    module = TestActionModule(task, dict())
    assert module._task.args['that'] == ['foo', 'bar']

    # Test no that

# Generated at 2022-06-11 11:21:45.475956
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:21:52.350875
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_action = ActionModule(task=object, connection=object,
                               play_context=object, loader=object,
                               templar=object, shared_loader_obj=object)

    assert test_action.TRANSFERS_FILES == False

    test_task_args = dict()
    test_task_args['that'] = 'Hello World'

    test_action = ActionModule(task=object, connection=object,
                               play_context=object, loader=object,
                               templar=object, shared_loader_obj=object)


    assert test_action._VALID_ARGS == frozenset(['fail_msg', 'msg', 'quiet', 'success_msg', 'that'])

# Generated at 2022-06-11 11:22:04.345986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import yaml


# Generated at 2022-06-11 11:22:15.451057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    def get_vars(loader, path, play=None):
        return {}

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play_context = PlayContext()
    inventory = MockInventory()
    templar = Templar(loader=loader, variables=variable_manager)

    task = Task()
    task_vars = dict()
    block = Block()
    block._role = IncludeRole()
    task._parent = block

# Generated at 2022-06-11 11:22:21.559016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("Start test_ActionModule")
    # Check with correct arguments
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    # Check with incorrect arguments
    try:
        a = ActionModule(task=1, connection=1, play_context=1, loader=1, templar=1, shared_loader_obj=1)
    except:
        pass
    print ("End test_ActionModule")


# Generated at 2022-06-11 11:22:33.265049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup action module
    action_module = ActionModule(loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    # define task_vars
    task_vars = dict(a="a",
                     my_test=True)
    # define assertion result
    assertion_result = dict(changed=False,
                            _ansible_verbose_always=True,
                            msg = 'All assertions passed')
    # define test case 1
    tmp = None
    task_vars = task_vars
    that = "my_test"
    fail_msg = 'Assertion failed'
    success_msg = 'All assertions passed'
    quiet = False

# Generated at 2022-06-11 11:22:44.871463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a list
    result = {'failed': False, 'assertion': '2.2 == 2.2'}
    msg = 'All assertions passed'
    assert ActionModule.run(self=None, tmp=None, task_vars={}, success_msg=msg, that='2.2 == 2.2') == result

    # Test with a string
    result = {'failed': True, 'assertion': '2.2 == 2.3'}
    msg = 'Assertion failed'
    assert ActionModule.run(self=None, tmp=None, task_vars={}, fail_msg=msg, that='2.2 == 2.3') == result

    # Test with a list inside a list
    result = {'failed': False, 'assertion': '2.2 == 2.2'}

# Generated at 2022-06-11 11:22:55.795217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor of class ActionModule can be called without arguments,
    # it will set all attributes to default values
    actionModule = ActionModule()
    assert actionModule.validate_conditional() == 'that'
    assert actionModule.notify_only() == False

# Generated at 2022-06-11 11:23:06.767552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1 - Correct arguments
    assert ActionModule.run(ActionBase, tmp=None, task_vars={'test_var': 'value'}) == {'failed': True, 'assertion': 'test_var is value', 'evaluated_to': False, 'msg': 'Assertion failed'}

    # Test 2 - fail_msg and msg is a list and has one string element
    task_args = {'that': 'test_var is value', 'fail_msg': ['failure']}
    assert ActionModule.run(ActionBase, tmp=None, task_vars={'test_var': 'value'}, task_args=task_args) == {'failed': True, 'assertion': 'test_var is value', 'evaluated_to': False, 'msg': 'failure'}

# Generated at 2022-06-11 11:23:08.420817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert(isinstance(actionmodule, ActionBase))


# Generated at 2022-06-11 11:23:17.349118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    tmp = None
    task_vars = {}
    actionmod = ActionModule(None, None)
    that = 'test that'
    task_vars['test_that'] = 'test_that'
    cond = Conditional(loader=None)
    cond.when = [that]
    test_result = cond.evaluate_conditional(templar=None, all_vars=task_vars)
    test_result = True if test_result else False
    assert actionmod.run(tmp, task_vars)['evaluated_to'] == test_result
    that = 'test that'
    task_

# Generated at 2022-06-11 11:23:18.497993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    somestuff = ActionModule()
    assert somestuff is not None

# Generated at 2022-06-11 11:23:26.963187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

    if sys.version_info.major < 3:
        from mock import MagicMock, patch
    else:
        from unittest.mock import MagicMock, patch

    host_vars = {}
    task_vars = {}
    my_vars = {"ansible_show_custom_stats": True}
    task_vars.update(my_vars)

    _loader = MagicMock()
    _templar = MagicMock()

    play_context = MagicMock()
    play_context._hack_no_log = False
    play_context.connection = "local"
    play_context.port = None
    play_context.remote_addr = None
    play_context.remote_user = None
    play_context.password = None
    play_context.private_key_file

# Generated at 2022-06-11 11:23:33.298683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yml = """
    - name: fail with custom message
      fail:
        fail_msg: This task should fail
        msg: This task will always fail
        quiet: true
        success_msg: This task should not succeed
        that: This task should always fail
    """

    task_vars = dict()
    task_vars['my_var'] = 'my_value'

    action = ActionModule(yml, None, '/tmp/', task_vars=task_vars)
    action.run(task_vars=task_vars)

    # Should not throw any errors


# Generated at 2022-06-11 11:23:34.102775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()


# Generated at 2022-06-11 11:23:37.655515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    task_vars = dict()
    assert type(a.run(task_vars=task_vars)) is dict
    assert a.run(task_vars=task_vars).get('failed') == True



# Generated at 2022-06-11 11:23:41.393201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _loader = None
    _task = "fail"
    _connection = "local"
    _play_context = None
    testobj = ActionModule(_loader, _task, _connection, _play_context)

    assert testobj

# Generated at 2022-06-11 11:24:03.955656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no fail message or success message
    task_vars = {}
    that = 'my_var == some_var'
    tmp = None
    class_obj = ActionModule()
    class_obj._task.args = {'that': that}
    result = class_obj.run(tmp, task_vars)
    assert result['assertion'] == that
    assert result['evaluated_to'] == False
    assert result['failed'] == True
    assert result['msg'] == 'Assertion failed'

    # Test with fail message as string
    fail_msg = 'my fail message'
    class_obj._task.args = {'that': that, 'fail_msg': fail_msg}
    result = class_obj.run(tmp, task_vars)
    assert result['assertion'] == that
    assert result

# Generated at 2022-06-11 11:24:15.571908
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock objects
    task = type('task', (object,), {
        'args': {'that': ['foo is defined', 'foo is "bar"'], 'quiet': False},
    })

    tmp = None

    task_vars = {'foo': 'bar'}

    mock_templar = type('templar', (object,), {
        'template': lambda self, x, **kwargs: x,
    })()

    mock_loader = type('loader', (object,), {
        'load_from_file': lambda self, x: {},
    })()

    class ActionModuleExtended(ActionModule):
        def __init__(self):
            self._task = task
            self._templar = mock_templar
            self._loader = mock_loader

    action_module = ActionModuleExtended

# Generated at 2022-06-11 11:24:19.002417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation tests
    action_module = ActionModule()
    assert action_module is not None

if __name__ == '__main__':
    print('Running unit tests for action_plugin.py')
    test_ActionModule()

# Generated at 2022-06-11 11:24:19.585293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 11:24:28.290208
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test empty parameters
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

    # Test invalid parameters
    invalid_task = dict()
    invalid_connection = dict()
    invalid_play_context = dict()
    invalid_loader = dict()
    invalid_templar = dict()
    invalid_shared_loader_obj = dict()


# Generated at 2022-06-11 11:24:39.862763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    test_dir = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(test_dir + "/../../")
    from ansible.utils.display import Display
    display = Display()
    import ansible.plugins.action
    am = ansible.plugins.action.ActionModule(
        task=dict(action=dict(fail=dict())),
        connection=None,
        play_context=dict(check_mode=False, diff_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None,
)

    try:
        am.run(None, None)
        assert False
    except Exception as e:
        display.vvv(e)
        assert True

# Generated at 2022-06-11 11:24:50.325950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #########
    # constructor
    #########
    am = ActionModule()

    # Test constructor without parameters
    assert am.task_vars == {}
    assert am.tmp == {}
    assert am.task_vars == {}
    assert am.connection == {}
    assert am.runner_connection == {}
    assert am.loader == {}
    assert am.templar == {}

    # Test constructor with parameters
    am = ActionModule(task_vars={'var1': 'val1'}, tmp={'tmp1': 'temp1'}, connection={'con1': 'connection1'}, runner_connection={'run': 'runner'}, loader={'load': 'loader'}, templar={'temp': 'templar'})

    assert am.task_vars == {'var1': 'val1'}

# Generated at 2022-06-11 11:24:59.180271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'my_var': 1, 'my_cond': True}
    task_args = {'fail_msg': "{{ my_var }} is equal to {{ my_var }}", 'that': "{{ my_var == my_var }}"}

    assert ActionModule.run(tmp=None, task_vars=task_vars, task_args=task_args) == {'_ansible_parsed': True, '_ansible_verbose_always': True, 'changed': False, 'assertion': '{{ my_var == my_var }}', 'msg': 'All assertions passed'}

    task_vars = {'my_var': 1, 'my_cond': False}

# Generated at 2022-06-11 11:25:09.158730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import unittest

    ###################
    # Mocking part 1
    ###################
    class MyException(Exception):
        pass

    class RealModuleMock:
        def __init__(self, loader=None, templar=None, task_vars=None):
            self._loader = loader
            self._templar = templar
            self._task_vars = task_vars

        def run(self, tmp=None, task_vars=None):
            return dict()

    RealModule = ActionModule
    ActionModule = RealModuleMock
    ####################
    # Mocking part 1 END
    ####################

    #######################################
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task

# Generated at 2022-06-11 11:25:17.806833
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils.parsing.convert_bool import boolean
    # simplest case
    that = "a == b"
    args = {'that': that}
    task = {'args': args}
    action = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run(task_vars={"a": "b"}) == {'_ansible_verbose_always': True,
                                                'assertion': 'a == b',
                                                'changed': False,
                                                'evaluated_to': True,
                                                'failed': False,
                                                'msg': 'All assertions passed'}

    # simplest case reversed
    args = {'that': that}
   

# Generated at 2022-06-11 11:26:07.285608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.module_utils.six import string_types

    test_data = namedtuple('test_data', 'result play_context task_vars args tmp')

    test_args = dict(fail_msg='Task failed', success_msg='Task succeeded', quiet=True, that='success')
    test_data.args = dict()
    test_data.args['_ansible_debug'] = True
    test_data.args['_ansible_verbose_always'] = True
    test_data.args['_ansible_verbosity'] = 4
    test_data.args['_ansible_no_log'] = False
    test_data.args['_ansible_diff'] = False
    test_data.args.update(test_args)

    test_data.tmp = dict()


# Generated at 2022-06-11 11:26:17.450324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    AnsibleError = namedtuple('AnsibleError', ['message'])

    class FakePlugin(object):
        def __init__(self):
            pass
        def run(self, *args, **kwargs):
            return {}

    class FakeModule(object):
        def __init__(self):
            self.results = {}
        def run(self, *args, **kwargs):
            return {}


# Generated at 2022-06-11 11:26:19.774538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from task import Task

    t = Task()
    t.args['msg'] = None
    t.args['that'] = []
    m = ActionModule(task=t)
    m.run(task_vars={'a':False})
    t.args['that'] = ['a']
    m = ActionModule(task=t)
    m.run(task_vars={'a':True})
    m.run(task_vars={'a':False})

# Generated at 2022-06-11 11:26:21.016159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, "Not Implemented"


# Generated at 2022-06-11 11:26:22.235845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('setup', {'msg': 'test'})


# Generated at 2022-06-11 11:26:28.629296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = dict()
    action._task.args = dict()
    action._task.args['that'] = 'gteq(3, 2)'
    tmp = None
    task_vars = dict()
    result = action.run(tmp, task_vars)
    expected_result = dict()
    expected_result['changed'] = False
    expected_result['msg'] = 'All assertions passed'
    assert result == expected_result



# Generated at 2022-06-11 11:26:37.453398
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:26:42.761338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    action = ActionModule(
        task=dict(args=dict(fail_msg='', success_msg='')),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(action, ActionBase)


# Generated at 2022-06-11 11:26:45.803528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(runner=None, task=dict(args=dict()))
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-11 11:26:55.774088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock instance of the AnsibleTask class
    action_module = ActionModule(load_plugins=False, task_vars=dict(ansible_check_mode=False))

    # Create a mock instance of AnsibleModule
    mock_ansible_module = MagicMock(name='AnsibleModule', spec=AnsibleModule)

    # Create a dictionary representation of a task
    task_args = {
        'that': ['1 == 0', '1 == 0', '1 == 0'],
        'fail_msg': 'test fail message',
        'success_msg': 'test success message',
        'quiet': 'no'
    }

    # Create a dictionary representation of a task with a when

# Generated at 2022-06-11 11:27:53.499185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, {'action': 'assert'}, [], [])
    action.run()
    assert action.action == 'assert'

# Generated at 2022-06-11 11:28:03.449479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import getopt

    opts, args = getopt.getopt(['fail_msg=msg', 'msg=msg1', 'that=that item'], '', ['fail_msg=', 'msg=', 'that='])

    assert_result = {'changed': False, 'evaluated_to': 'test_result', 'failed': True, 'assertion': 'test_assertion'}
    assert_msg = 'msg'

    # Test for fail_msg value not in args of constructor
    assert_result['msg'] = assert_msg
    assert_result['assertion'] = None

    module = ActionModule()
    module._task.args = {'fail_msg': ['msg1', 'msg2']}
    module._templar = TestTemplar()
    module._templar.template = 'test_template'
    module

# Generated at 2022-06-11 11:28:12.660203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import shutil
    import tempfile
    import os

    # Create temp directory
    tempdir = tempfile.mkdtemp()
    # Create fake ansible path in temp directory
    os.mkdir(tempdir + '/library')
    # Create fake action plugin
    shutil.copy('../ansible/plugins/action/assert.py', tempdir + '/assert.py')
    # Create fake module
    shutil.copy('../ansible/library/set_fact.py', tempdir + '/library/set_fact.py')
    # Create fake module util
    shutil.copy('../ansible/module_utils/parsing/convert_bool.py', tempdir + '/module_utils/parsing/convert_bool.py')

    # Load fake ActionModule

# Generated at 2022-06-11 11:28:13.810259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(args=dict())
    assert ActionModule(task, dict()).run()

# Generated at 2022-06-11 11:28:21.014992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import callback_loader, action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    action_loader.add_directory('./lib/ansible/plugins/action')
    callback_loader.add_directory('./lib/ansible/plugins/callback')
    task = Task()
    task._role = None
    task._task_fields['action'] = 'assert'
    task._task_fields['_role'] = None
    task._task_fields['args'] = { 'that': 5, 'msg': 'failed', 'that': 3 }
    task._task_fields['loop'] = None
    task._task_fields['loop_args'] = None
    block = Block()
    task._block = block
    block._parent = None
    block

# Generated at 2022-06-11 11:28:30.125224
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:28:32.590634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(module_name='assert'), args=dict(msg='Assertion Failed', fail_msg='Assertion Failed')))
    assert isinstance(action, ActionModule)



# Generated at 2022-06-11 11:28:33.462583
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule is not None

# Generated at 2022-06-11 11:28:35.781625
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test -1
    action = ActionModule()

    # Test -2
    assert action.run()

    # Test -3
    assert action.run(task_vars={})

# Generated at 2022-06-11 11:28:39.085369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a =  ActionModule(loader=None, play=None)
    assert a.ACTION_VERSION == '2.0'
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))