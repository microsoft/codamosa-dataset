

# Generated at 2022-06-11 11:21:27.551454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pass1 test
    task_args = {'msg': 'Test Message', 'that': 'conditional is True'}
    module_mock = ActionModule(task=MagicMock(args=task_args))
    result = module_mock.run()
    assert result['changed'] == False
    assert result['evaluated_to'] == True
    assert result['msg'] == 'All assertions passed'

    # pass2 test
    task_args = {'fail_msg': 'Test Message', 'that': 'conditional is True'}
    module_mock = ActionModule(task=MagicMock(args=task_args))
    result = module_mock.run()
    assert result['changed'] == False
    assert result['evaluated_to'] == True
    assert result['msg'] == 'All assertions passed'

    # fail

# Generated at 2022-06-11 11:21:29.776564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod is not None

# Generated at 2022-06-11 11:21:32.895269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()

    assert mod._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert mod.TRANSFERS_FILES is False

# Generated at 2022-06-11 11:21:41.449698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    import json

    # Create an instance of Class ActionModule
    am = ActionModule(
        AnsibleModule(
            argument_spec={
                'fail_msg': {'type': 'str', 'required': True},
                'msg': {'type': 'str'},
                'quiet': {'type': 'bool', 'required': False},
                'success_msg': {'type': 'str'},
                'that': {'type': 'str', 'required': True},
            },
            supports_check_mode=False,
        )
    )

    # Test with success_msg
    am._task.args['fail_msg'] = "Failed"

# Generated at 2022-06-11 11:21:47.309839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None,
                                 templar=None)

    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-11 11:21:58.209772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    # Testing happy path
    good_msg = "All assertions passed"
    fail_msg = "Assertion failed"

    task_values_all_pass = {'ansible_facts': {'os_family': 'debian', 'ansible_os_family': 'debian'}}
    test_that_all_pass = ['ansible_facts.os_family == "debian"', 'ansible_facts.os_family != "CentOS"']

    task_values_all_fail = {'ansible_facts': {'os_family': 'CentOS', 'ansible_os_family': 'CentOS'}}
    test_that_all_fail = ['ansible_facts.os_family == "debian"', 'ansible_facts.os_family != "CentOS"']

    # Testing happy path, assert

# Generated at 2022-06-11 11:22:00.827441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context = None, loader=None, templar = None, shared_loader_obj = None)

# Generated at 2022-06-11 11:22:07.655110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class ActionModule with task and play
    action_module = ActionModule(task=dict(action=dict(), args=dict()), play=dict())
    # test run method with given args
    result = action_module.run(tmp=None, task_vars=dict())
    # assert if result is false
    print(result)
    assert result == {'failed': False, 'changed': False, 'msg': 'All assertions passed'}

# Generated at 2022-06-11 11:22:08.414144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:22:11.319305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert act is not None

# Generated at 2022-06-11 11:22:30.573548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global ActionModule_run_test_result
    ActionModule_run_test_result = None
    class ActionModule_run_task(object):
        def __init__(self):
            self.args = {}

    class ActionModule_run_module_result(object):
        def __init__(self):
            self._ansible_verbose_always = None
            self.failed = None
            self.evaluated_to = None
            self.assertion = None
            self.msg = None
            self.changed = None

    class ActionModule_run_loader(object):
        pass

    class ActionModule_run_templar(object):
        def __init__(self):
            self.vars = {}


# Generated at 2022-06-11 11:22:42.568167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config  = {
        'module_utils': 'lib/ansible/module_utils',
    }
    args    = {
        'fail_msg': 'This is a fail message',
        'success_msg': 'This is a success message',
        'quiet': True,
        'that': False
    }
    tmp     = '/tmp/ansible-tmp-1412654593.08-245359820877008/'
    task_vars = {
        'desired_var': 'ansible',
    }
    x = ActionModule(config, args, tmp)
    result = x.run(task_vars = task_vars)

    assert result['changed'] == False
    assert result['msg'] == 'This is a fail message'
    assert result['_ansible_verbose_always'] == True


# Generated at 2022-06-11 11:22:43.217379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:22:43.792913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:22:53.577684
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = {'var1': 'foo', 'var2': 'bar'}
    values = [
        ('{{ var1 }}', task_vars, True),
        ('{{ var1 }} == "foo"', task_vars, True),
        ('{{ var2 }} == "foo"', task_vars, False),
        ('{{ var1 }} is defined', task_vars, True),
        ('{{ var1 }} is undefined', task_vars, False),
        ('foo in var1', task_vars, True),
        ('foo in var2', task_vars, False)
    ]

    for that, task_vars, test_result in values:
        action_module = ActionModule(None, '/some/path', None, None)

# Generated at 2022-06-11 11:22:56.348033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_module = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    output_module = None
    assert input_module == output_module

# Generated at 2022-06-11 11:23:02.171395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of a class ActionModule
    test_instance = ActionModule()

    assert test_instance.run({}) == {'msg': 'Assertion failed', \
            'failed': True, 'evaluated_to': False, \
            'assertion': 'ansible_distribution_version == "14.04"', \
            '_ansible_verbose_always': True}

test_ActionModule_run()

# Generated at 2022-06-11 11:23:02.927216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:23:12.752313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    from ansible.module_utils.six import StringIO

    # create a mock loader
    mock_loader = type('', (), {'get_basedir': lambda self: '.'})
    mock_loader.PATH_TRANSLATION = 'none'

    # create a mock play
    mock_play = type('', (), {'basedir': lambda self: '.', 'get_loader': lambda self: mock_loader})

    # create a mock task
    mock_task = type('', (), {'args': {}})

    # create a mock inventory
    mock_inventory = type('', (), {'host_list': lambda self: [], 'get_host': lambda self, host: type('', (), {'get_vars': lambda self: {}})()})

    # create a mock variable manager
    mock_variable_manager

# Generated at 2022-06-11 11:23:19.502241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    action_module = action_loader.get('assert', play=Play().load({'name': 'test_play', 'hosts': 'all', 'gather_facts': 'no', 'tasks': []}, loader=None, variable_manager=None))
    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._parent, Task)
    assert isinstance(action_module._parent._parent, Block)



# Generated at 2022-06-11 11:23:37.429116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:23:38.051687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 11:23:41.443511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-11 11:23:51.201921
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #### test_default_fail_msg_and_success_msg_and_no_quiet_and_that_is_string ####

    task_vars = {}
    task_vars[u'debug_val'] = u"Debug value"
    task_vars[u'fail_val'] = u"Fail value"
    task_vars[u'success_val'] = u"Success value"
    task_vars[u'failed_when_result'] = False

    # ActionModule.run(task_vars=task_vars)
    loader = DictDataLoader({u'fail.yml': u'---\n# action: fail\n- action: fail\n  when: False\n  that: {{ success_val }}\n'})
    variable_manager = VariableManager()
    variable_manager

# Generated at 2022-06-11 11:23:52.142555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # Add your test here

# Generated at 2022-06-11 11:23:55.254706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)
    actionModule = ActionModule(loader=None,
                                templar=None,
                                shared_loader_obj=None)
    assert isinstance(actionModule, ActionBase)

# Generated at 2022-06-11 11:23:56.246826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-11 11:24:00.640448
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:24:12.266788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test ActionModule constructor """
    original_fail_msg = "original fail msg"
    original_quiet = True
    original_success_msg = "original success msg"
    original_that = "original that msg"
    args = dict()
    args['fail_msg'] = original_fail_msg
    args['quiet'] = original_quiet
    args['success_msg'] = original_success_msg
    args['that'] = original_that
    action = ActionModule(None, None, args)
    assert action
    assert action._task.args['fail_msg'] == original_fail_msg
    assert action._task.args['quiet'] == original_quiet
    assert action._task.args['success_msg'] == original_success_msg
    assert action._task.args['that'] == original_that

# Generated at 2022-06-11 11:24:14.423694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fail = False
    try:
        ActionModule()
    except:
        fail = True
    finally:
        assert (not fail)


# Generated at 2022-06-11 11:24:52.468128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Check for method 'run' in class 'ActionModule'
    print ('Checking action module')
    action_module = ActionModule(load_plugins=False)
    task_vars = dict()
    tmp = None
    task = dict()
    task['args'] = dict()
    task['args']['that'] = True
    task['args']['msg'] = 'test_msg'
    print ('Trying to run the action module')
    result = action_module.run(tmp, task_vars, task)
    print ('Checking if the returned message is what we expected')
    assert result['msg'] == 'test_msg'
    print ('Checking if there is no failure')
    assert result['failed'] == False
    print ('Checking if the change is actually done')
    assert result['changed'] == False

# Generated at 2022-06-11 11:24:52.928502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:25:02.588510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    results_callback = ResultsCollector()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 11:25:03.618035
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert(True)


# Generated at 2022-06-11 11:25:12.599937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Returning the result from check_conditional function call """
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    from ansible.vars import VariableManager

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run()

    assert result['failed'] == True, "Should be True"
    assert result['changed'] == False, "Should be False"
    assert result['evaluated_to'] == False, "Should be False"
    assert result['assertion'] == "test_assertion", "Should be 'test_assertion'"
    assert result['msg'] == "Assertion failed", "Should be 'Assertion failed'"


# Generated at 2022-06-11 11:25:17.923775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_loader()
    set_inventory()
    set_variables()
    set_variable_manager()

    action_module = ActionModule(
        task = set_task(), 
        connection = set_connection(), 
        play_context = set_play_context(), 
        loader = set_loader(), 
        templar = set_templar(), 
        shared_loader_obj = None
    )
    return action_module


# Generated at 2022-06-11 11:25:27.122671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _create_fake_loader():
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play_context import PlayContext

        variable_manager = VariableManager()
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources='')
        variable_manager.set_inventory(inventory)
        play_context = PlayContext()

        return loader, variable_manager, play_context

    that = 'true'
    fail_msg = 'This is a test fail message'
    success_msg = 'This is a test success message'
    quiet = True
    loader, variable_manager, play_context = _create_fake_loader()

    # using dict because dict evaluates to True

# Generated at 2022-06-11 11:25:36.901084
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create task and fake it
    task = type('MockTask', (object,), {})
    task.action = 'debug'
    task.action_plugin = 'debug'
    task.args = {}
    task.loop = 'once'
    task.loop_args = {'that': '{{ foo }}'}

    # Cache
    cache = type('MockCache', (object,), {'set': lambda *args, **kwargs: '',
                                          'get': lambda *args, **kwargs: '',
                                          'delete': lambda *args, **kwargs: ''})
    cache.set = lambda *args, **kwargs: ''
    cache.get = lambda *args, **kwargs: ''
    cache.delete = lambda *args, **kwargs: ''

    # Create ad-hoc module instance


# Generated at 2022-06-11 11:25:44.497278
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:25:52.741561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock, MagicMock
    @patch.object(ActionBase, "run")
    @patch.object(Conditional, "evaluate_conditional")
    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.am = ActionModule()
            self.am._loader = "loader"
            self.am.task = MagicMock()
            self.am._templar = "templar"


# Generated at 2022-06-11 11:27:18.865232
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # The run method of ActionModule class requires inputs not available to this test
    # Hence set these inputs as None
    tmp=None
    task_vars=None

    # Shouldn't execute this statement, since run method is not a static method.
    # Hence print statement to verify whether class initialization 
    # is called or not
    print("\nClass ActionModule is being called for testing")

    # Create class object of ActionModule
    # Since run method of ActionModule class is not static,
    # it requires the class object in order to call the method
    # Hence the below statement
    obj_obj = ActionModule()

    # Create an object of ansible.errors.AnsibleError class for testing
    obj_ansible_error = AnsibleError('conditional required in "that" string')

    # Create an object of ansible.playbook.cond

# Generated at 2022-06-11 11:27:27.553025
# Unit test for method run of class ActionModule
def test_ActionModule_run():


     module = AnsibleModule({
            '_ansible_verbose_always': True,
            'assertion': 'is not True',
            'evaluated_to': False,
            'failed': True,
            'msg': 'Assertion failed'
        }, True, True)

# Generated at 2022-06-11 11:27:37.581759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None)

    # 1. Test with msg
    action.args = {'fail_msg': 'fail'}
    action.task = {'args': action.args}
    action.task_vars = dict()
    result = action.run(None, action.task_vars)
    assert result['failed'] == True
    assert result['changed'] == False
    assert result['msg'] == 'fail'

    # 2. Test success_msg
    action.args = {'fail_msg': 'fail', 'success_msg': 'succeed',
        'quiet': False}
    action.task = {'args': action.args}
    action.task_vars = dict()
    result = action.run(None, action.task_vars)
    assert result['failed'] == False
   

# Generated at 2022-06-11 11:27:44.347847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #create object of class ActionModule
    cls = ActionModule('task')
    # check the object is of type ActionModule
    assert type(cls) == type(ActionModule('task'))
    assert set(cls._VALID_ARGS) == set(['fail_msg', 'msg', 'quiet', 'success_msg', 'that'])

    # check _VALID_ARGS type
    assert isinstance(cls._VALID_ARGS, frozenset)


# unit test for fail_msg argument

# Generated at 2022-06-11 11:27:47.897105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == "Fail with custom message"
    assert ActionModule.TRANSFERS_FILES == False
    assert set(ActionModule._VALID_ARGS) == set(['fail_msg', 'msg', 'quiet', 'success_msg', 'that'])

# Generated at 2022-06-11 11:27:51.433706
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Case 1
    module = ActionModule(
        task=dict(action=dict(fail_msg='a string')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(module, ActionModule)

    # Case 2
    module = ActionModule(
        task=dict(action=dict(fail_msg=['a string', 'another string'])),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(module, ActionModule)

    # Case 3
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.playbook.play_context import Play

# Generated at 2022-06-11 11:27:53.542936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that class ActionModule can be initialized
    assert isinstance(ActionModule, (type, object))

# Generated at 2022-06-11 11:28:03.501026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)

    play_context = PlayContext()
    play_context.check_mode = True
    play_context.remote_addr = '127.0.0.1'
    play_context.network_os = 'default'

    block_task = TaskInclude('meta')


# Generated at 2022-06-11 11:28:12.659327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #initial test to pass the incorrect class of fail_msg to raise the exception
    #that's why I have used fail_msg as int and not replaced with msg
    fail_msg=2
    #expectation is AnsibleError as fail_msg is of incorrect type
    #assertRaises is a pytest module
    with pytest.raises(AnsibleError):
        success_msg = 'All assertions passed'
        quiet = False
        thats = ['test0']
        cond = Conditional(loader=None)
        comments = 'All assertions passed'
        result = {'failed': False, 'evaluated_to': False, 'assertion': None}
        test_result = False
        result['failed'] = True
        result['evaluated_to'] = test_result
        result['assertion'] = thats[0]

# Generated at 2022-06-11 11:28:20.113076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins import action_loader, module_loader

    import ansible.constants as C
    import os

    C.HOST_KEY_CHECKING = False  # Don't load host keys
    C.DEFAULT_HOST_LIST = os.devnull  # Don't load inventory with hosts

    def reset_process_failure_queue():
        global process_failure_queue
        process_failure_queue = []

    def _queue_task_result(host, task, result, task_vars, play_context):
        process_failure