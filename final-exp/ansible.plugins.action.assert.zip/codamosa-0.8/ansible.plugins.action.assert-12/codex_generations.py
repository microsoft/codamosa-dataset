

# Generated at 2022-06-11 11:21:18.398735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    action_module = ActionModule(
        task=Task(),
        connection=None,
        play_context=play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    result = action_module._load_params()

    assert result


# Generated at 2022-06-11 11:21:21.832388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class DummyActionModule(ActionModule):
        def __init__(self):
            super(DummyActionModule, self).__init__()

    obj = DummyActionModule()
    assert obj._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:21:30.484906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 11:21:39.450587
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:21:41.149744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_action_module = ActionModule(None, None)
    assert ansible_action_module != None

test_ActionModule()

# Generated at 2022-06-11 11:21:51.207428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # pylint: disable=too-many-locals
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    m_task = Task()

# Generated at 2022-06-11 11:22:03.191426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    action_plugins/assert.py
    '''

    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, task_vars):
            pass

    class MockLoader():
        def __init__(self):
            pass

        def load_from_file(self, filename):
            pass

    class MockPlayContext():
        '''
        action_plugins/assert.py
        '''
        def __init__(self):
            self.become = None
            self.become_user = None

    class MockTask():
        '''
        action_plugins/assert.py
        '''
        def __init__(self):
            self.action = 'assert'
            self.args = dict()
            self.loop = None


# Generated at 2022-06-11 11:22:06.718332
# Unit test for constructor of class ActionModule
def test_ActionModule():
  actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  assert actionModule._task == None

# Generated at 2022-06-11 11:22:17.140344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 11:22:20.619751
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1
    module = ActionModule()
    assert module.run(task_vars={'var': 'test'})

    # Test 2
    module = ActionModule()
    assert module.run(tmp=None, task_vars={'var': 'test'})

# Generated at 2022-06-11 11:22:40.268546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Create a playbook object
    test_playbook_obj = Playbook()

    # Create a play object

# Generated at 2022-06-11 11:22:41.352456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:22:41.996769
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-11 11:22:45.500280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule")
    module_args = {}
    action_module = ActionModule(module_args)
    if isinstance(action_module, ActionModule):
        print("Test passed")
    else:
        print("Test Failed")

# Generated at 2022-06-11 11:22:56.311468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._play_context = {'play_hosts': ['testhost']}
    module.set_loader({'_host': 'testhost', '_ansible_verbosity': 1})

    # test fail_msg return
    module.set_task(dict(action='test', args=dict(that=['foo'], fail_msg='test_msg')))
    result = module.run(task_vars=dict())	
    assert result['failed'] == False

    module.set_task(dict(action='test', args=dict(that=['foo'], fail_msg='test_msg')))
    result = module.run(task_vars=dict())
    assert result['msg'] == 'test_msg'

    # test success_msg return

# Generated at 2022-06-11 11:23:04.439445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit tests for module ActionModule
    '''
    action_module_obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_path=None, templar=None, shared_loader_obj=None)
    assert action_module_obj._task.args == {'that': None}
    assert action_module_obj.TRANSFERS_FILES == False
    assert action_module_obj._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-11 11:23:13.853112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In this test, we will try to test the functionality of the method run
    # of the class ActionModule. We will be testing both the negative and
    # positive cases.

    # Testing negative case:
    # In case that is not given in the task args
    # We expect an AnsibleError
    try:
        action = ActionModule()
        action.run(task_vars={"test_var": "test_value"})
        assert False
    except AnsibleError:
        assert True

    # Testing a positive case:
    # In case that is given in the task args, doing the assertions
    # We expect the conditional to pass, as the value "test_var" 
    # is assigned as "false" in the task_vars
    action = ActionModule()

# Generated at 2022-06-11 11:23:17.102572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types

    action = ActionModule(argv=[])
    assert isinstance(action.run, types.MethodType) == True

    action = ActionModule(argv=[])
    assert isinstance(action.run, types.MethodType) == True


# Generated at 2022-06-11 11:23:25.332991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_args=None, templar=None, shared_loader_obj=None)

    # Testing msg, fail_msg and success_msg with string and list type
    test_args_success_msg_string = dict(fail_msg='Assertion failed', msg='Assertion failed', success_msg='All assertions passed', quiet=False, that=[1 == 1, 2 == 2])
    assert am.run(task_vars=dict(), tmp=None) == {'failed': False, 'changed': False, 'evaluated_to': True, 'assertion': '2 == 2', 'msg': 'All assertions passed'}

# Generated at 2022-06-11 11:23:33.821749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.insert(1, "./library")

# Generated at 2022-06-11 11:23:53.417234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:24:02.366722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""

    # Test failure on missing or non-string fail_msg argument
    action_module = ActionModule(None, {}, None, {})

    try:
        action_module.run()
    except AnsibleError as e:
        assert "conditional required in 'that' string" in e.message

    action_module = ActionModule(None, {}, None, {'that': "{{a}} and {{b}}"})

    try:
        action_module.run()
    except AnsibleError as e:
        assert "conditional required in 'that' string" in e.message

    # Test failure on non-string or non-list msg argument
    action_module = ActionModule(None, {}, None, {'that': "{{a}} and {{b}}", 'fail_msg': 1})



# Generated at 2022-06-11 11:24:12.023283
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Create a new instance of the ActionModule class that contains the methods
  # used to create the proper action plugins. 
  module = ActionModule()

  # Test that the new instance of ActionModule created is an instance
  # of the ActionModule class
  assert isinstance(ActionModule(), ActionModule) == True

  # Test the module.run() method by asserting that the returned failure message is not None
  module.run() == 'ActionModule object has no attribute run'

  # Test the module.run() method by asserting that the returned failure message is not None
  module.get_bin_path() == 'ActionModule object has no attribute get_bin_path'

# Generated at 2022-06-11 11:24:22.396004
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import sys
    import os
    import __builtin__
    module_loader = None
    class loader:
        def __init__(self):
            self.path_info = {'module_utils': ['/tmp']}
        def load_module(self, *args):
            return module_loader

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False,
                     required_if=None):
            pass


# Generated at 2022-06-11 11:24:29.536369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up global variables for test
    import sys
    import os
    task_vars = dict(
        ansible_facts=dict(
            ansible_hostname='localhost',
            ansible_system='Linux',
            ansible_distribution='Fedora',
            ansible_distribution_major_version='25',
            ansible_distribution_version='25.0.1'
        )
    )
    tmp = None
    that = 'ansible_distribution == "Fedora"'
    fail_msg = 'Assertion failed!'
    success_msg = 'All assertions passed!'

    # initialize object
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actionModule._task = dict()
   

# Generated at 2022-06-11 11:24:38.721790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    task = dict()
    task['args'] = dict()
    task['args']['that'] = ['key in val_list', 'key in val_list']
    task['args']['fail_msg'] = "Failed"
    task['args']['success_msg'] = "Passed"
    task['args']['quiet'] = True

    action = ActionModule(task, task_vars)
    result = action.run(None, None)

    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == "Passed"



# Generated at 2022-06-11 11:24:42.199037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(that=['test'], msg="test")))
    assert isinstance(action, ActionModule)
    assert isinstance(action, ActionBase)


# Generated at 2022-06-11 11:24:43.238601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:24:43.908073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:24:45.701443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test the constructor
    module = ActionModule(
        task=dict(action=dict(module='assert')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert module._task.action['module'] == 'assert'

# Generated at 2022-06-11 11:25:16.215017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # check if ActionModule object is created or not
    assert ActionModule(1,2,3,4)

# Generated at 2022-06-11 11:25:18.355571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None,None,None,None,None)
    assert len(a.VALID_ARGS) == 5
    assert a.TRANSFERS_FILES is False

# Generated at 2022-06-11 11:25:21.827709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(datastructure={},
                                 task={},
                                 connection={},
                                 play_context={},
                                 loader={},
                                 templar={},
                                 shared_loader_obj={})

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:25:24.712663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    module = None
    tmp = None
    task_vars = None

    ActionModule.run(module, tmp, task_vars)

# Generated at 2022-06-11 11:25:26.379049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, {}, {}, {})
    return a


# Generated at 2022-06-11 11:25:35.026092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Use a fake action plugin instead and mock AnsibleAction.run()
    # to check that the class is instantiated correctly and AnsibleAction.run()
    # is called.
    # NOTE: An ActionModule is also an AnsibleAction so there is no need for
    #       AnsibleAction inside AnsibleAction. However, currently
    #       AnsibleAction.run() is not defined.
    action = ActionModule()
    a = type(action)
    assert issubclass(a, ActionBase)
    assert ActionBase in a.__bases__
    assert a.__name__ == 'ActionModule'
    assert hasattr(a, 'run')
    assert callable(getattr(a, 'run', None))

# Generated at 2022-06-11 11:25:39.411312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Description: Tests whether the run method of ActionModule class works properly.
    #
    # Prerequisite: None
    # Precondition: None
    # Given: None
    # When: None
    # Then: None
    # Return: None
    # Notes: None
    #
    # Test data: None
    # Expected results: None
    #
    # Postcondition: None

    pass



# Generated at 2022-06-11 11:25:40.436229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 11:25:48.477543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    variable_manager._extra_vars = { "this": "that" }
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/test_action_module/inventory')

# Generated at 2022-06-11 11:25:56.707993
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:27:11.946383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:27:22.252950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    # Testing case 1: Quiet true and success_msg message list
    that = ['a', ['b', 'c']]
    action_args = {'that': that, 'success_msg': ['success1', 'success2'], 'quiet': True}
    action.task = action.load_task_plugins(action_args, None, None)

    template_host = object()
    tmp = object()
    task_vars = {}
    result = {'failed': True}
    cond = Conditional(loader=action._loader)

    def mock_evaluate_conditional(templar, all_vars):
        return True
    cond.evaluate_conditional = mock_evaluate_conditional


# Generated at 2022-06-11 11:27:23.193229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, {})

# Generated at 2022-06-11 11:27:29.853565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase

    def get_task_vars():
        return dict(foo=True, bar=True)

    def get_module_args():
        return dict(
            quiet=False,
            msg="Assertion failed",
            success_msg="All assertions passed",
            that="is_number(1)"
        )

    class DummyModule(object):
        def fail_json(*args, **kwargs):
            print("[FAILURE]", args, kwargs)

        def exit_json(*args, **kwargs):
            print("[SUCCESS]", args, kwargs)

    module = DummyModule()

# Generated at 2022-06-11 11:27:37.076451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=protected-access
    # Constructor ActionModule as a function
    # with no parameters, without it raising errors
    action_module = ActionModule()

    # Assert that returned object is of the correct type
    assert isinstance(action_module, ActionBase)

    # Assert that the action_module is valid
    assert action_module.VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module.NO_CLI_ARGS == False

# Generated at 2022-06-11 11:27:47.266995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    from ansible.playbook.conditional import Conditional
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean

    action_module = ActionModule()

    class MockModuleLoader:
        def get_basedir(self, path):
            return None


# Generated at 2022-06-11 11:27:57.356747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, variable_manager=None,
                                 templar=None)

    action_module._task.args = {'that': 'this is not a boolean'}
    result = action_module.run()
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['msg'] == 'Assertion failed'

    action_module._task.args = {'that': ['a == 2', 'b > 1', 'this is not a boolean']}
    result = action_module.run()
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['msg'] == 'Assertion failed'

    action_module._task.args = {'that': 'a == 2'}

# Generated at 2022-06-11 11:27:57.913147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:28:00.876669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:28:02.019409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-11 11:30:57.389701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    module = __import__(os.path.basename(__file__).rstrip('.py'))
    class_ = getattr(module, 'ActionModule')

    arun = class_()

# Generated at 2022-06-11 11:31:05.654938
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader=DataLoader()
    variable_manager=VariableManager()
    inventory=InventoryManager(loader=loader, sources=[])
    module_name='setup'

    def myfunction(self):
        raise Exception('not implemented')

    s='testline'
    task=Task(action=module_name, task_name='test', delegate_to='localhost', loop_control=dict(loop_var=s))

    task.when=['testval']

    a=ActionModule(task=task, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)

