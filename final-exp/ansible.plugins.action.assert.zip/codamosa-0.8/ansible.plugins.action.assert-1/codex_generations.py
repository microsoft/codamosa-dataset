

# Generated at 2022-06-11 11:21:25.812069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    templar = Templar(loader=None, variables={})
    # This is module which we want to test
    action_module = ActionModule({}, {}, templar=templar, loader=None, shared_loader_obj=None,
                                 task_uuid='test', action_loader=None, connection=None, play_context=None)
    # Assign values to the task argument which will be used by method run()
    action_module._task.args = {'that': [{"foo":"bar"},{"baz":"buzz"}], 'quiet': False}
    # Define the expected result
    expected_result = {'changed': False, 'msg': 'All assertions passed', 'failed': False}

    # Run method run() using the task argument 'that'

# Generated at 2022-06-11 11:21:34.705529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task=dict(action=dict(module_name="fail")), connection=None,
                                play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    actionmodule._templar = Dictable()
    actionmodule._task.args = {'that': None, 'fail_msg': None, 'quiet': False, 'success_msg': None}
    assert actionmodule.run(tmp=None, task_vars=None) == {'_ansible_verbose_always': True, 'failed': True, 'msg': 'Assertion failed'}
    actionmodule._task.args = {'that': "False", 'fail_msg': None, 'quiet': False, 'success_msg': None}

# Generated at 2022-06-11 11:21:44.311965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule - run
    """

    module = None

    # AnsibleError("Type of one of the elements in fail_msg or msg list is not string type")
    # with pytest.raises(AnsibleError) as err:
    #     module._task.args['fail_msg'] = [1, 2]
    #     module._task.args['msg'] = None
    #     module.run()
    # assert err.value.args[0] == "Type of one of the elements in fail_msg or msg list is not string type"

    # AnsibleError("Incorrect type for fail_msg or msg, expected a string or list and got <class 'dict'>")
    # with pytest.raises(AnsibleError) as err:
    #     module._task.args['fail_msg'] = {}
   

# Generated at 2022-06-11 11:21:52.758369
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def TestActionModule_run_true(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()
        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        # we don't care about the conditional here, as that is tested in the
        # conditional unit tests. Just return success now
        result['changed'] = False
        result['msg'] = 'All assertions passed'
        return result

    def TestActionModule_run_false(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()
        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer

# Generated at 2022-06-11 11:22:04.828135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import Include
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash

    # Create an instance of the action module
    action_module = ActionModule()

    # Create a fake task

# Generated at 2022-06-11 11:22:05.713491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:22:16.407466
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, [])
    playbook = PlaybookExecutor(playbooks=['play.yml'],
                                inventory=inventory,
                                variable_manager=variable_manager,
                                loader=loader,
                                passwords={})

# Generated at 2022-06-11 11:22:18.844235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(action_plugin_name='assert', task=None, connection=None, action_loader=None, play_context=None, shared_loader_obj=None, variable_manager=None)


# Generated at 2022-06-11 11:22:23.936939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task=dict(args=dict(that=False, msg='failed')))
    actionmodule._templar = dict()
    actionmodule.runner_on_ok = Mock()
    actionmodule.run(task_vars=dict())
    assert actionmodule.runner_on_ok.called


# Generated at 2022-06-11 11:22:28.420641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action='test_action', task=None, connection='local', play_context=None,
                                 loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.action == 'test_action'

# Generated at 2022-06-11 11:22:38.260541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None, None)
    assert a is not None

# Generated at 2022-06-11 11:22:46.007008
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import mock

    # input to method
    tmp = None
    task_vars = {'ansible_connection': 'local'}

    # plugins/actions/assert.py
    # Line: 73
    # class ActionModule(ActionBase):
    action_module = ActionModule(
        task=mock.Mock(),
        connection=mock.Mock(),
        play_context=mock.Mock(),
        loader=mock.Mock(),
        templar=mock.Mock(),
        shared_loader_obj=None
    )



# Generated at 2022-06-11 11:22:47.151818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test is currently a stub
    pass

# Generated at 2022-06-11 11:22:55.941678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake module that mocks the Ansible spec
    # The class's name doesn't matter
    class FakeActionModule:
        _templar = "mock_templar"
        _loader = "mock_loader"
    task = {
        'args': {
            'fail_msg': "fail_msg",
            'msg': "msg",
            'quiet': False,
            'success_msg': "success_msg",
            'that': "that"
        }
    }
    test_module = ActionModule(task, FakeActionModule())
    test_module.run()

# Generated at 2022-06-11 11:22:56.540963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:22:57.534738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)



# Generated at 2022-06-11 11:23:08.336010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    import os
    import sys
    import tempfile

    class MyActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(MyActionModule,self).run(tmp,task_vars)

    def load_fixture(name):
        path = os.path.join(os.path.dirname(__file__), 'fixtures', name)
        handle = open(path, 'rb')
        data = handle.read()
        handle.close()
        return data

    ###########################################################################
    ## that is True
    ###########################################################################

    # Prepare our own module_utils dir, so we do not depend on what is installed
    module_utils_path = tempfile.mkdtemp()

# Generated at 2022-06-11 11:23:16.946997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    loader = action_loader._create_directory_loader_mock()
    play_context = object()
    task = object()

    task.no_log = False
    task.notify = []
    task.when = []
    task.loop = None
    task.args = {'that': ['$(1 == 1)'], 'fail_msg': 'Assertion failed', 'quiet': False}
    task._role = None
    task.environment = {}

    action_module = action_loader.get('assert', play_context, loader=loader, task=task)

    assert action_module is not None
    assert action_module.run(tmp=None, task_vars=None)['msg'] == 'All assertions passed'

# Generated at 2022-06-11 11:23:25.138515
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Act and Assert
    try:
        action_module.run(task_vars=None)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert 'conditional required in "that" string' in str(e)

    # Arrange
    action_module._task.args = {'that': 'foo', 'msg': 'Error message'}

    # Act and Assert
    try:
        action_module.run(task_vars=None)
    except Exception as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-11 11:23:33.630887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    t_obj = ActionModule()
    t_obj._task = type('', (), {'args':{'fail_msg':'this should fail'}})()
    t_obj._task.args = {'fail_msg':'this should fail'}
    t_obj._task.args = {'msg':'this should fail'}
    t_obj._task.args = {'fail_msg':'this should fail', 'msg':'this should fail'}
    t_obj._task.args = {'fail_msg':['this', 'should', 'fail']}
    t_obj._task.args = {'msg':['this', 'should', 'fail']}

# Generated at 2022-06-11 11:23:52.844399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert(isinstance(a, ActionBase))


# Generated at 2022-06-11 11:24:01.136934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            args=dict(
                fail_msg='fail_msg',
                msg='msg',
                quiet=False,
                success_msg='success_msg',
                that=['that0', 'that1'],
            ),
        ),
    )
    assert module._task.args.get('fail_msg') == 'fail_msg'
    assert module._task.args.get('msg') == 'msg'
    assert module._task.args.get('quiet') == False
    assert module._task.args.get('success_msg') == 'success_msg'
    assert module._task.args.get('that') == ['that0', 'that1']

# Generated at 2022-06-11 11:24:03.976905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    ActionModule:
    """
    # constructor without any arguments
    def run():
        return ActionModule()
    result = run()
    print(result)



# Generated at 2022-06-11 11:24:04.693800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:24:10.123637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
            task=dict(action=dict(module_name='debug', module_args=dict())),
            connection=dict(),
            play_context=dict(),
            loader=None,
            templar=None,
            shared_loader_obj=None)

    assert action_module

# Generated at 2022-06-11 11:24:20.562497
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:24:25.281414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(action=dict(fail_msg="msg")))
    am._task.args = dict(fail_msg="test")
    result = am.run()
    assert result['msg'] == "test"
    am._task.args = dict(that=["test"])
    result = am.run()
    assert result['msg'] == "test"

# Generated at 2022-06-11 11:24:36.547579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	#
	# Functionality test with empty string
	#
	module_args = {}
	module_name = 'assert'
	module_result = {
		'changed': False,
		'failed': True,
		'msg': 'Assertion failed'
	}

	# Create and execute module
	action_module = ActionModule(module_name)
	action_module.set_loader(None)
	action_module.set_task(None)
	action_module.set_args(module_args)

	# Get result
	actual = action_module.run({}, {})
	print(actual)
	
	assert actual == module_result

	#
	# Functionality test with one string
	#
	module_args = { 'that':'10 == 10' }

# Generated at 2022-06-11 11:24:39.034299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    os.system('/usr/bin/python2.7 ./hacking/test-module -m ./library/assert')

# Generated at 2022-06-11 11:24:49.769242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def TestActionModule():
        action = dict(
            __ansible_module__=False,  # imported modules have this set
            fail_msg=None,
            msg=None,
            quiet=None,
            success_msg=None,
            that=''
        )
        return ActionModule(action, dict())

    # test when fail_msg is specified
    action = TestActionModule()
    action.cond = dict(failed=False)
    result = action.run(dict(), dict())
    assert result.get('msg') == 'Assertion failed', 'test_ActionModule_run_1: run() returned incorrect result'
    assert result.get('changed') is False, 'test_ActionModule_run_1: run() returned incorrect result'

# Generated at 2022-06-11 11:25:25.168446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

# Generated at 2022-06-11 11:25:34.801448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    # Loop over the test cases
    for test_case in ActionModule_run_test_cases:
        # Initialize the module
        action_module = ActionModule(
            task=dict(
                args=test_case['input']['args'],
            ),
            shared_loader_obj=None,
            # connection=None,
            # play_context=None,
            loader=None,
            templar=None,
            # task_vars=task_vars,
            # wrap_async=None,
        )

        # Call method run of class ActionModule
        result = action_module.run(
            # tmp=None,
            task_vars=task_vars,
        )

        assert result == test_case['result']

# Tests cases for method run

# Generated at 2022-06-11 11:25:42.726013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = {}
    f['msg'] = 'this is a long message!'
    f['fail_msg'] = 'this is a long message!'
    f['success_msg'] = 'this is a long message!'
    f['that'] = True
    f['quiet'] = True
    f['tags'] = ['a','b','c']
    f['when'] = True
    f['become'] = True
    f['become_user'] = True
    f['delegate_to'] = True
    f['_ansible_verbose_always'] = True
    f['_ansible_no_log'] = True
    f['_ansible_check_mode'] = True
    f['_ansible_debug'] = True
    f['_ansible_diff'] = True

# Generated at 2022-06-11 11:25:43.555119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-11 11:25:46.210190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    p = ActionModule(task=dict(action=dict(fail_msg='This is a test')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert p is not None

# Generated at 2022-06-11 11:25:54.523040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils
    import ansible.parsing.yaml
    import ansible.playbook.task
    import ansible.vars.hostvars
    ansible.utils.plugins = ansible.plugins
    ansible.parsing.yaml.plugins = ansible.plugins

    # Declare the module instance
    am = ActionModule(
        task=ansible.playbook.task.Task(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Declare test variables
    t = dict()
    t['ansible_facts'] = dict()
    t['ansible_facts']['test_var'] = "test_value"

# Generated at 2022-06-11 11:25:57.614042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task= dict(args= dict(fail_msg= ['Assertion failed 1'], that= '5 == 5', quiet= False, success_msg= ['All assertions passed'])))
    assert obj.run()['msg'] == 'Assertion failed 1'


# Generated at 2022-06-11 11:25:59.706290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(loader=None, connection=None, play_context=None)
    assert am is not None


# Generated at 2022-06-11 11:26:09.330291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader

    # Test case 1 - fail_msg is present and that is a list
    fail_msg1 = ['msg1', 'msg2']
    that1 = [False, True]
    args1 = {'fail_msg': fail_msg1, 'that': that1}
    task_vars1 = dict()
    task1 = dict(action=dict(module_name='assert', args=args1))
    tmp1 = None

    action1 = ActionModule(task1, DictDataLoader({}))
    result1 = action1.run(tmp1, task_vars1)


# Generated at 2022-06-11 11:26:19.813962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    T = Task()
    T._role = None
    T.args = {
        'that': ['foo', 'bar'],
        'fail_msg': 'test fail_msg',
        'success_msg': 'test success_msg',
        'quiet': False
    }
    assert T.args == {
        'that': ['foo', 'bar'],
        'fail_msg': 'test fail_msg',
        'success_msg': 'test success_msg',
        'quiet': False
    }
    assert T.args.get('that') == ['foo', 'bar']
    assert T.args.get('fail_msg') == 'test fail_msg'
    assert T.args.get('success_msg') == 'test success_msg'
    assert T.args.get

# Generated at 2022-06-11 11:27:28.831275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache={}, shared_loader_obj=None, variable_manager=None)

# Generated at 2022-06-11 11:27:39.104283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests when fail_msg is not specified
    print('\n## Testing run method')
    orig = [{u'assertion': 'My Ansible is not working', u'changed': True, u'evaluated_to': False, u'failed': True, u'msg': 'Assertion failed', u'_ansible_no_log': False, u'assertion_type': u'non_empty'}]
    inp = {'fail_msg': 'My Ansible is not working', 'task': {'args': {'fail_msg': 'My Ansible is not working', 'msg': 'My Ansible is not working', 'quiet': False, 'success_msg': 'All assertions passed', 'that': ['that']}}}
    task_vars = {'var': 'value'}

# Generated at 2022-06-11 11:27:48.285555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for run method of class ActionModule
    '''
    import ansible.utils.template
    module = ansible.utils.template.AnsibleModule(
        argument_spec=dict(fail_msg=dict(),
                           that=dict()
                         )
    )

    module.params = {'fail_msg': 'fail message',
                     'that': 'fail condition'
                    }
    at = ActionModule(task=module.params,
                    connection=None,
                    play_context=None,
                    loader=None,
                    templar=None,
                    shared_loader_obj=None)
    result = at.run(None, None)
    assert 'failed' in result
    assert result['failed'] == True

# Generated at 2022-06-11 11:27:49.365400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:27:53.450463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test to check the functionality of constructor of class ActionModule
    ansible_var = dict(ansible_ssh_host="10.7.7.6")
    mod = ActionModule({},ansible_var)
    assert not mod._play_context.no_log

# Generated at 2022-06-11 11:28:03.401578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()

    am._task = dict()

    # Create an instance of ActionBase
    ab = ActionBase()

    # Create an instance of AnsibleLoader
    # This is done by passing a file pointer to the file we want to load
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    passwords = dict()
    results_callback = lambda self: self
    inventory = InventoryManager(loader=loader, sources=['localhost'])


# Generated at 2022-06-11 11:28:04.558763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj is not None

# Generated at 2022-06-11 11:28:11.966209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert hasattr(module, "run")
    actionBase_namespace = vars(ActionBase)
    module_namespace = vars(module)
    for name in actionBase_namespace:
        if name.startswith("_") :
            assert name in module_namespace
    assert not hasattr(module, "_VALID_ARGS")

# fail_msg parameter has type string and value "", thus fail_msg should have type string and value "" after the test

# Generated at 2022-06-11 11:28:13.610735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    assert(x != None)


# Generated at 2022-06-11 11:28:20.843208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import TaskInclude
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    task = Task()
    play_context = dict(
        remote_addr='192.168.0.1',
        password='1b3a3f3d3e12a2a8',
        port=8888,
    )