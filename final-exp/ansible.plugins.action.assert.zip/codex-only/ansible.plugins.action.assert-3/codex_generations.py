

# Generated at 2022-06-23 07:26:45.627943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task which is used by the ActionModule
    task = mock.MagicMock()
    # Create a mock module_utils which is used by the ActionModule
    module_utils = mock.MagicMock()
    # Create a mock loader which is used by the ActionModule
    loader = mock.MagicMock()
    # Create a mock templar which is used by the ActionModule
    templar = mock.MagicMock()
    # Create the ActionModule instance
    action_module = ActionModule(task=task, connection=None, play_context=None, loader=loader, templar=templar, shared_loader_obj=None)
    # Initialize the result
    result = {'changed': True, 'msg': ''}
    # Initialize the task_vars
    task_vars = dict()
    # Create

# Generated at 2022-06-23 07:26:57.879430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for fail_msg
    task = MockTask()
    task.args = {}

    temp_var = dict()
    action = ActionModule(task, temp_var)

    result = action.run(None, temp_var)
    assert result.get('msg') == 'Assertion failed'
    assert result.get('failed')
    assert result.get('evaluated_to') == False
    assert result.get('assertion') == None

    # Test for fail_msg and quiet
    task.args['quiet'] = True
    action = ActionModule(task, temp_var)

    result = action.run(None, temp_var)
    assert result.get('msg') == 'Assertion failed'
    assert result.get('failed')
    assert result.get('evaluated_to') == False
    assert result.get

# Generated at 2022-06-23 07:27:09.775835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(test_str='test', test_int=4, test_bool=True)

    # Create an instance
    assert isinstance(ActionModule(task=dict(args=dict(fail_msg='fail_msg_string', msg='fail_msg_string', that=dict(eql=dict(test_str='test'))))), ActionModule)
    assert isinstance(ActionModule(task=dict(args=dict(fail_msg='fail_msg_list', msg='fail_msg_list', that=dict(eql=dict(test_str='test'))))), ActionModule)

# Generated at 2022-06-23 07:27:10.880977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:27:17.504788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make a mock module
    fake_task = MagicMock()
    fake_task.args = {'fail_msg': 'failed', 'that': ['a==1', 'b==2']}
    fake_task._validate_that = lambda x, y: True
    fake_task.register = lambda x: None

    fake_loader = MagicMock()
    fake_loader.get_basedir.return_value = '/fake/playbook'

    # make a mock connection
    fake_connection = MagicMock()
    # create a mock AnsibleModule instance
    fake_connection_module = MagicMock()
    fake_connection.module_implementation_preferences = ['foo']
    fake_connection.module_implementation_preferences.pop.return_value = 'foo'
    fake_connection_module.return_value

# Generated at 2022-06-23 07:27:21.520385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test basic constructor
    module = ActionModule()
    assert module

    # test constructor with data
    module2 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module2

# Generated at 2022-06-23 07:27:28.627677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test run method with no type error
    try:
        action_module.run()
    except AnsibleError as err:
        assert False

    # Test run method with success_msg
    action_module._task.args = {'that': '1 == 1'}
    action_module._task.args['success_msg'] = 'assertion passed'
    result = action_module.run()
    assert result['changed'] == False
    assert result['msg'] == 'assertion passed'

    # Test run method with fail_msg
    action_module._task.args = {'that': '1 == 2'}
    action_module._task.args['fail_msg'] = 'assertion failed'
    result = action_module.run()
    assert result['failed'] == True

# Generated at 2022-06-23 07:27:33.081397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(args=dict(test=dict(), msg="test")), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-23 07:27:44.864745
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class DummyActionModule(ActionModule):

        __good_args__ = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
        __bad_args__ = frozenset(('bad_argument'))

    def _dump(obj, indent=0):
        if isinstance(obj, dict):
            return '\n'.join([
                '{0}{1}: {2}'.format(
                  indent * '  ', _dump(k), _dump(v, indent + 1)
                )
                for k, v in obj.items()
            ])

# Generated at 2022-06-23 07:27:47.330642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module_object is not None

# Generated at 2022-06-23 07:27:56.145456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fixture
    from ansible_collections.ansible.community.tests.unit.plugins.module_utils import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        msg=dict(required=False, type='str'),
        quiet=dict(required=False, type='bool', default=False),
        success_msg=dict(required=False, type='str'),
        that=dict(required=True, type='list'),
    ))

    # test function
    print("Testing function...\n")
    result = module.run_command(['ls', '-l'], check_rc=True)
    assert result[0] == 0
    assert result[1] == 'total 0\n-rwxr-xr-x 1 root root 0 Apr 16  2019 hello\n'

# Generated at 2022-06-23 07:27:58.224345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('hello.yml', '/home/chris/ansible', 'chris')

# Generated at 2022-06-23 07:27:59.479730
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:28:00.127969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:28:00.770011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 07:28:01.477725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:28:02.021957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:28:12.280079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    task = Task()
    task._role = None
    task.args = {'fail_msg': 'Assertion error'}
    task.action = 'assert'
    am = ActionModule(task, variable_manager=variable_manager, loader=loader, templar=None)
    assert am is not None

# Generated at 2022-06-23 07:28:22.000680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.params = {}
            self.exit_args = {}
            self.add_file_common_args = add

# Generated at 2022-06-23 07:28:29.697003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            args=dict(
                fail_msg='Testing fail',
                success_msg='Testing success',
                quiet=True,
                that=['Test failed', 'Test passed'])),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    result = module.run()
    assert result['failed'] == True
    assert result['evaluated_to'] == False
    assert result['assertion'] == 'Test failed'
    assert result['msg'] == 'Testing fail'


# Generated at 2022-06-23 07:28:33.736194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(loader=None,
                shared_loader_obj=None,
                path_loader=None,
                module_loader=None,
                tmp_path=None,
                module_name=None,
                task_vars=None,
                templar=None,
                task_uuid=None,
                action_plugin=None
                )


# Generated at 2022-06-23 07:28:41.007952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader)

# Generated at 2022-06-23 07:28:49.688481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor of class ActionModule
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module._task == dict()
    assert module._connection == dict()
    assert module._play_context == dict()
    assert module._loader == dict()
    assert module._templar == dict()
    assert module._shared_loader_obj == dict()
    assert module._task.args == dict()
    assert module._task.action == 'fail'
    assert module._task.delegate_to == None
    assert module._task.delegate_facts == None
    assert module._task.deprecated == None
    assert module._task.loop == None
    assert module._task

# Generated at 2022-06-23 07:28:53.948727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    i = ActionModule()
    assert i._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-23 07:28:58.264358
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    '''
        Unit test for method run of class ActionModule
    '''

    # Arrange
    context = {
        '_ansible_no_log': False,
        '_ansible_verbose_always': False,
        '_ansible_verbosity': 0,
        '_ansible_version': '2.5.5',
        'ansible_version': {
            'full': '2.5.5',
            'major': 2,
            'minor': 5,
            'revision': 5,
            'string': '2.5.5'
        },
        'ansible_verbosity': 0,
        'ansible_verbose_always': False,
        'ansible_no_log': False
    }


    # Act

# Generated at 2022-06-23 07:29:08.936365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    condition = 'is mapping'
    method_input = {'that': condition}
    module._task.args = method_input
    module._task.action = 'assert'
    result = module.run(task_vars=task_vars)
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'
    condition = 'is file'
    method_input = {'that': condition}
    module._task.args = method_input
    module._task.action = 'assert'
    result = module.run(task_vars=task_vars)
    assert result['failed'] == True
   

# Generated at 2022-06-23 07:29:12.398749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None



# Generated at 2022-06-23 07:29:13.296223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:29:24.872398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  test_action = ActionModule()
  test_task = {'args':{'that': 'mydata.foo = 5'}}
  test_templar = {}
  test_task_vars = {'mydata':{'foo':'5'}}
  test_result = {'failed': False, 'msg':'All assertions passed', 'changed': False} 
  assert test_action.run(tmp=None, task_vars=test_task_vars, task=test_task, templar=test_templar) == test_result
  
  test_task_vars = {'mydata':{'foo':'6'}}

# Generated at 2022-06-23 07:29:34.286455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from operator import attrgetter as getter
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    args = {'fail_msg': 'fail_msg', 'quiet': False, 'that': 'that', 'msg': 'msg', 'success_msg': 'success_msg'}
    task = Task()
    task._role = None
    task.args = args
    loader = DataLoader()
    variable_manager = VariableManager()
    am = ActionModule(task, loader=loader, variable_manager=variable_manager)
    result = am.run(None, None)
    assert result['failed'] is False
    assert result['msg'] == 'success_msg'

# Generated at 2022-06-23 07:29:45.075809
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Run the assert module with no params
    result = ActionModule.run(None)

    # Check the assert failed
    assert result['failed'] == True

    assert result['msg'] == 'conditional required in "that" string'

    # Run the assert module with an incorrect type for fail_msg
    result = ActionModule.run({'fail_msg': 10})

    # Check the assert failed
    assert result['failed'] == True

    assert result['msg'] == 'Incorrect type for fail_msg or msg, expected a string or list and got <class \'int\'>'

    # Run the assert module with an incorrect type for success_msg
    result = ActionModule.run({'success_msg': 10})

    # Check the assert failed
    assert result['failed'] == True


# Generated at 2022-06-23 07:29:47.203327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myActionModule = ActionModule(runner)
    assert myActionModule is not None

# Generated at 2022-06-23 07:29:57.131704
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:30:08.324786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager

    class MockTask(Task):
        def __init__(self, args):
            self.args = args

    plugin_name = 'fail'
    action = action_loader.get(plugin_name)
    config = {}

# Generated at 2022-06-23 07:30:09.561365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:30:18.941461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import mock
    import unittest

    class AnsibleModuleMock():
        def __init__(self):
            self.params = dict()

    class AnsibleActionBase(ActionBase):
        def _shared_loader_obj(self):
            return dict()

    class AnsibleActionModule(ActionModule, AnsibleActionBase):
        def __init__(self, *args, **kwargs):
            self.result = dict()
            self._task = dict()
            self._task.args = dict()
            self._task.args['fail_msg'] = 'Assertion failed'
            self._task.args['quiet'] = False
            self._task.args['that'] = 'test'
            self._task.args['that'] = 'test'

# Generated at 2022-06-23 07:30:27.401076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Starting unit test for method run of class ActionModule")
    module_args={'msg': "Assertion failed"}
    task_vars={'item':{'var': ['one', 'two', 'three']}}

    try:
        action = ActionModule(None, None, module_args)
        result = action.run(None, task_vars)
    except AnsibleError as e:
        pass
    else:
        raise RuntimeError("AnsibleError exception expected!")
    print("\nEnding unit test for method run of class ActionModule\n")

test_ActionModule_run()

# Generated at 2022-06-23 07:30:28.683356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

test_ActionModule()

# Generated at 2022-06-23 07:30:35.139026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task.args['that'] = ['ansible_distribution == "Debian"', 'ansible_distribution == "Ubuntu"']
    action._task.args['that'] = ['ansible_distribution == "Debian"', 'ansible_distribution == "Ubuntu"']
    action._task.args['success_msg'] = 'Success'
    action._task.args['fail_msg'] = 'Fail'
    result = action.run(task_vars={'ansible_distribution': 'Debian'})

    assert result['changed'] == False
    assert result['msg'] == 'Success'


# Generated at 2022-06-23 07:30:38.057884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    print(result)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:30:39.043513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-23 07:30:40.800965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:30:49.173462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(action=dict(
        module_name='fail',
        args=dict(msg='Assertion failed', that=dict(
            "{{{'a':1}|d()|equals({'a':2})}}",
            "{{{'a':1}|d()|equals({'a':1})}}"
        ))
    )))

    result = module.run(task_vars=dict())
    assert result['msg'] == 'Assertion failed', result['msg']
    assert result['assertion'] == "{{{'a':1}|d()|equals({'a':2})}}", result['assertion']


# Generated at 2022-06-23 07:30:59.597520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    # Function1: set "_VALID_ARGS"
    # Function2: set "TRANSFERS_FILES" and "NO_TARGET" value
    # Function3: set "BYPASS_HOST_LOOP" value
    a = ActionModule()
    a._VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    a.TRANSFERS_FILES = False
    a.BYPASS_HOST_LOOP = True
    assert frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that')) == a._VALID_ARGS
    assert False == a.TRANSFERS_FILES
    assert True == a.BYPASS_HOST_LOOP

#

# Generated at 2022-06-23 07:31:02.547319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task = {
    'name' : 'test action module',
    'args': {}
  }
  tmp = None
  task_vars = {
    'ansible_verbose_always': True
  }
  module = ActionModule(task, tmp, task_vars)
  module._templar = None
  module._loader = None

# Generated at 2022-06-23 07:31:06.686118
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:31:11.220032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, 'some name', {'a': 'b'}, 'some load', 'some path')

    assert action.name == 'some name'
    assert action.module_args == {'a': 'b'}
    assert action.loader == 'some load'
    assert action.path == 'some path'

# Generated at 2022-06-23 07:31:21.317455
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # This is necessary for function call of constructor of ActionBase
    class FakePlayContext(object):
        def __init__(self):
            self.remote_addr = None
            self.remote_user = None
            self.password = None
            self.port = None
            self.private_key_file = None

    class FakeOptions(object):
        def __init__(self):
            self.connection = 'local'

    class FakeTask(object):
        def __init__(self):
            self.args = {'that': '1 == 1'}

    class FakeTaskResult(object):
        def __init__(self):
            self.failed = False
            self.changed = False
            self.assertion = False
            self.evaluated_to = False

    fake_play_context = FakePlayContext()
    fake_

# Generated at 2022-06-23 07:31:23.411897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_module_args({
        'that': '{{ansible_architecture}} == "x86_64"',
    })

# Generated at 2022-06-23 07:31:25.818470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None).run()

# Generated at 2022-06-23 07:31:36.321393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import mock
    import ansible.plugins.action

    # mock class objects and other values
    local_action = mock.MagicMock()
    local_action._task = mock.MagicMock()
    local_action._task.args = dict()
    local_action._task.args['fail_msg'] = 'fail'
    local_action._task.args['success_msg'] = 'success'
    local_action._task.args['that'] = [ True, False ]
    local_action._loader = mock.MagicMock()
    local_action._loader.load_mismatched_plugin.return_value = True
    local_action._templar = mock.MagicMock()
    local_action._templar.template.return_value = 'template'
    task_vars = dict()
   

# Generated at 2022-06-23 07:31:48.332951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    ###########################################################################
    # testing method run of class ActionModule with various
    # input strings
    ###########################################################################

    # Tests for fail_msg and msg
    for msg in ('test_msg', ['test_msg1', 'test_msg2']):
        for fail_msg in ('test_fail_msg', ['test_fail_msg1', 'test_fail_msg2']):
            module = ActionModule()
            task = type('Task', (), {})

# Generated at 2022-06-23 07:31:59.379843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test invalid parameters
    args1 = dict(msg='An invalid message')
    task1 = dict(action=dict(module='assert'))

    # Test valid parameters
    args2 = dict(that='1 > 0')
    task2 = dict(action=dict(module='assert'))
    task2['action'].update(args2)

    # Test invalid parameters
    assert_action = ActionModule(task1, args1, False, {})
    result = assert_action.run(None, None)
    assert 'error' in result
    assert result['error']['msg'] == 'that is required'

    # Test valid parameters
    assert_action = ActionModule(task2, args2, False, {})
    result = assert_action.run(None, None)
    assert 'assertion' in result

# Generated at 2022-06-23 07:32:11.297346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ansible specification (see test_model)
    class AnsibleFakeFactCollector:
        def __init__(self):
            self.facts = {}
            self.vars_cache = {}

    class AnsibleFakePlayContext:
        def __init__(self):
            self.connection = None
            self.network_os = None
            self.remote_addr = None
            self.port = None
            self.remote_user = None
            self.password = None
            self.private_key_file = None
            self.connection_user = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.become_pass = None
            self.no_log = None
            self.timeout = 10
            self.shell = None
            self.std

# Generated at 2022-06-23 07:32:24.256537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task_include as task_include
    import ansible.playbook.play_context as play_context

    class MockActionBase(ActionBase):
        def __init__(self):
            self._task = AnsibleTask()
            self._templar = Templar(loader=None, variables=dict())

    class AnsibleTask:
        def __init__(self):
            self.args = dict()
            self.when = list()
            pass

    class Templar:
        def __init__(self, loader, variables):
            self._loader = loader
            self._variables = variables

        def set_available_variables(self, variables):
            self._variables = variables


# Generated at 2022-06-23 07:32:33.930795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    module = dict()
    loader = dict()
    templar = dict()

    action_module = ActionModule(task=args, connection=module, play_context=loader, loader=loader, templar=templar)

    # call method run
    try:
        result = action_module.run(task_vars=None)
    except AnsibleError as e:
        result = e.args[0]

    assert result == 'conditional required in "that" string'

    # test with valid string
    args = dict()
    args['that'] = 'any_string'
    action_module = ActionModule(task=args, connection=module, play_context=loader, loader=loader, templar=templar)

    # call method run

# Generated at 2022-06-23 07:32:38.297905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule(cls)

    Make sure we're generating the correct type of class
    '''
    from ansible.plugins.action import ActionModule

# Generated at 2022-06-23 07:32:49.098599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test creation of action_module
    result = ActionModule(
            task=dict(action=dict(module_name='assert',module_args=dict(fail_msg='Assertion failed', that=dict(key1='value1', key2='value2'))))
            )
    assert result != None
    assert result.run(tmp=None, task_vars=dict())['changed'] == False

# Generated at 2022-06-23 07:33:00.863498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We cannot initialize the class because of the self.run() method
    # so we mock it with a Mock object
    # Construct the object
    class MockArgs:
        def __init__(self, fail_msg, that):
            self._fail_msg = fail_msg
            self._that = that

        def get(self, key, value):
            if key == 'fail_msg':
                return self._fail_msg
            elif key == 'msg':
                return self._fail_msg
            elif key == 'that':
                return self._that

    class MockTask:
        def __init__(self, fail_msg, that):
            self.args = MockArgs(fail_msg, that)


# Generated at 2022-06-23 07:33:03.321938
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructor test
    a = ActionModule()
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-23 07:33:06.550987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule

    :return:
    """
    action = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-23 07:33:13.382934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a Mock templar object
    # create a ActionModule object with the mock loader object and template
    from ansible.template import Templar
    from ansible.playbook.template import PlaybookInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.plugins.loader import action_loader, module_loader

    templar = Templar(loader=None, variables=VariableManager())
    pb_i = PlaybookInclude('localhost', 'connection=local', templar=templar)
    abyo = AnsibleBaseYAMLObject('assert', pb_i)


# Generated at 2022-06-23 07:33:18.414672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__class__.__name__
    assert 'action' == ActionModule.ACTION_TYPE
    assert 'module' == ActionModule.ACTION_TYPE
    assert 'ActionModule' == ActionModule.__name__
    assert 'ansible.plugins.action' == ActionModule.__module__

# Generated at 2022-06-23 07:33:30.686364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    # Successful case
    task_vars = dict()
    args = dict()
    args.update(fail_msg='Following assertions failed:')
    args.update(success_msg='All assertions passed')
    args.update(quiet=True)
    args.update(that=['foo', 'bar'])
    action_result = dict()
    action_result.update(failed=False)
    action_result.update(changed=False)
    action_result.update(msg='All assertions passed')
    action_result.update(failed_when_result='foo')
    action_result.update(evaluated_to='foo')
    action_result.update(assertion='foo')

    task = dict()
    task.update(args=args)
    action.set_task(task)

   

# Generated at 2022-06-23 07:33:39.321220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import bytes_type as six_bytes_type
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_bytes

    # Test empty constructor
    action_module = ActionModule()
    # Test result of empty constructor
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test constructor with non-empty arguments
    task = {}
    connection = {}
    play_context = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}

# Generated at 2022-06-23 07:33:42.382483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not am.TRANSFERS_FILES

# Generated at 2022-06-23 07:33:52.866193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method of class ActionModule.
    Following assertions are being tested:
    1. fail_msg and msg are same, check if msg is not None
    2. fail_msg and msg are same, check if msg is string type
    3. fail_msg and msg are same, check if msg is list type
    4. fail_msg and msg are same, check if msg is int type
    5. fail_msg and msg are same, check if msg is dict type
    6. success_msg is None, check if msg is not empty
    7. success_msg is None, check if msg is string type
    8. success_msg is list, check if msg is list type
    """
    from collections import namedtuple
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-23 07:33:53.902248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 07:34:03.108159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(args=dict(that=True, msg='test_message')))
    assert am.run() == dict(changed=False, msg='test_message')
    am = ActionModule(task=dict(args=dict(that=False, msg='test_message')))
    assert am.run() == dict(evaluated_to=False, assertion=False,
                            failed=True, msg='test_message')
    am = ActionModule(task=dict(args=dict(that=[True, False], msg='test_message')))
    assert am.run() == dict(evaluated_to=False, assertion=False,
                            failed=True, msg='test_message')
    am = ActionModule(task=dict(args=dict(that=[True, True], msg='test_message')))
    assert am

# Generated at 2022-06-23 07:34:11.136711
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # initialize action plugin
    action_plugin = ActionModule(
          task = dict(args = {'fail_msg': 'Test-Fail-Message', 'success_msg': 'Test-Success-Message'}),
          connection = None,
          play_context = dict(),
          loader = None,
          templar = None,
          shared_loader_obj = None,
    )

    # call run()
    action_plugin.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:34:21.047182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self.conn = None
            self.task = task
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj

    am = TestActionModule({}, {}, {}, {}, {}, {})
    assert am.task == {}
    assert am.play_context == {}
    assert am.loader == {}
    assert am.templar == {}
    assert am.shared_loader_obj == {}
   

# Generated at 2022-06-23 07:34:31.625079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 07:34:40.970138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    action_obj = action_loader.get('assert', class_only=True)
    action = action_obj()
    action.name = 'assert'
    task = dict()
    # Set the args
    task['args'] = dict()
    task['args']['msg'] = 'My assert message'
    task['args']['that'] = 'ansible_facts.python.version | version_compare("2.7","<")'
    # Set the vars
    vars = dict()
    vars['ansible_facts'] = dict()
    vars['ansible_facts']['python'] = dict()
    vars['ansible_facts']['python']['version'] = '3.7'
    action.task = task

# Generated at 2022-06-23 07:34:45.224908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor initialization test
    test_obj = ActionModule()
    assert test_obj._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert test_obj.TRANSFERS_FILES == False

# Generated at 2022-06-23 07:35:00.225458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an empty task
    task = dict()
    # Set the argument fail_msg of task to a string value
    task['args'] = dict()
    task['args']['fail_msg'] = 'Custom message for failure'
    # Set the boolean flag check_mode of task to False
    task['check_mode'] = False
    # Set the boolean flag delegate_to of task to False
    task['delegate_to'] = False
    # Set the string field module_name of task to action
    task['module_name'] = 'action'
    # Set the string field name of task to debug
    task['name'] = 'debug'
    # Set the boolean flag no_log of task to False
    task['no_log'] = False
    # Set the string field role_name of task to None

# Generated at 2022-06-23 07:35:10.490575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor


# Generated at 2022-06-23 07:35:13.578776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-23 07:35:19.872383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    in_templar = None
    in_task_vars = {'test': 'hello'}
    in_task = {'args': {'that': 'test == \'hello\'', 'fail_msg': 'Fail message', 'msg': 'Incorrect message', 'quiet': True}}
    in_tmp = 'tmp'
    action_module = ActionModule(in_task, in_templar)

    # Exercise
    result = action_module.run(in_tmp, in_task_vars)

    # Verify
    assert_message = 'Failed to verify result of run'
    assert result['msg'] == 'All assertions passed' and not result['failed'] and result['evaluated_to'] and not result['changed'], assert_message


# Generated at 2022-06-23 07:35:30.898186
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:35:41.685772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    cwd = os.path.dirname(__file__)
    sys.path.append(cwd + '/../../')

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # create a temporary file and directory
    tmpdir = tempfile.mkdtemp()
    tmpfile = tmpdir + '/' + 'test_file'
    os.mkdir(tmpdir)
    open(tmpfile, 'a').close()

    test_string = 'hello'
    test_int = '42'

# Generated at 2022-06-23 07:35:46.931320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert hasattr(test_action, 'run')
    assert hasattr(test_action, '_VALID_ARGS')
    assert hasattr(test_action, 'TRANSFERS_FILES')



# Generated at 2022-06-23 07:35:55.415276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.playbook.task import Task
    MockVars = namedtuple('MockVars', ['static', 'tasks'])
    mock_vars = MockVars({}, [Task.load(dict(name='MockTask', action=dict(module='assert')))])
    # module_utils is not used, mock it
    module_utils = dict()
    # create  a mock task dictionary
    mock_task = dict(args=dict())
    assert isinstance(ActionModule(mock_task, module_utils, mock_vars), ActionModule)

# Generated at 2022-06-23 07:36:08.024148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    mod = ActionModule()

    that = "thats=\"{{ source_interface == 'GigabitEthernet0/0/0' }}\""
    assert mod._task.args['that'] == that

    #Test for List of strings for fail_msg and success_msg
    fail_msg = ['fail message1', 'fail message2']
    assert mod._task.args['fail_msg'] == fail_msg

    success_msg = ['success message1', 'success message2']
    assert mod._task.args['success_msg'] == success_msg

    #Test for list of strings for list of thats
    thats = "thats=\"[{{ source_interface == 'GigabitEthernet0/0/0' }}, {{ source_interface == 'GigabitEthernet0/0/1' }}]\""
   

# Generated at 2022-06-23 07:36:18.399451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of ActionModule
    am = ActionModule(
            task=dict(args=dict(fail_msg=None, msg="This is a message", quiet=False, success_msg=None, that=[None])),
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None)
    # call the run method
    result = am.run()
    print(result)

    # check the output
    assert result['msg'] == "This is a message"
    assert result['changed'] == False



# Generated at 2022-06-23 07:36:26.268588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #(ActionModule):
    am = ActionModule()
    print(am)
    #fail_msg = self._task.args.get('fail_msg', self._task.args.get('msg'))
    fail_msg = {'fail_msg': 'field value is not equal to expected value', 'msg': 'field value is not equal to expected value', 'success_msg': 'All assertions passed'}
    if 'fail_msg' not in fail_msg:
        raise AnsibleError('conditional required in "that" string')

    #fail_msg = self._task.args.get('fail_msg', self._task.args.get('msg'))
    if fail_msg is None:
        fail_msg = 'Assertion failed'

# Generated at 2022-06-23 07:36:38.768943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.inventory.manager

    current_pc = ansible.playbook.play_context.PlayContext()
    current_play = ansible.playbook.play.Play().load({}, defs={'play_hosts': ['host1'], 'name': 'test-play'}, variable_manager=ansible.vars.manager.VariableManager(), loader=None)
    current_task = ansible.playbook.task.Task()