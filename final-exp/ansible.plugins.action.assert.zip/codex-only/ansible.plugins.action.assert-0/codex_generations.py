

# Generated at 2022-06-23 07:26:39.614316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ [ActionModule] Testing ActionModule run method """
    import os
    import sys

    # If module_utils/parsing/convert_bool.py exists, add it to module search path
    # This is to ensure that we can import boolean from module_utils.common.convert_bool
    # while testing this module.
    #
    # Ansible absolute_import module search path is defined in ansible.module_utils.__init__
    # The search order is defined there. That is the first path from module_utils.__init__.py
    # is checked for existence of a module, and so on.
    #
    # The value for sys.path[0] is the directory where the script is located,
    # which is known as the current working directory. (sys.path[0] = os.getcwd())
    #
   

# Generated at 2022-06-23 07:26:50.544950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First, mock the task_vars and set it as a global module
    import mock
    from ansible.utils.display import Display
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.clean import module_response_deepcopy


# Generated at 2022-06-23 07:27:00.736646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    that = 'var'
    fail_msg = 'fail'
    success_msg = 'success'
    m = ActionModule(dict(task_vars=task_vars, that=[that], fail_msg=fail_msg, success_msg=success_msg))
    assert m._execute_module()['msg'] == fail_msg

    task_vars = dict(var=False)
    that = 'var'
    fail_msg = 'fail'
    success_msg = 'success'
    m = ActionModule(dict(task_vars=task_vars, that=[that], fail_msg=fail_msg, success_msg=success_msg))
    assert m._execute_module()['msg'] == success_msg

    task_vars = dict(var=True)

# Generated at 2022-06-23 07:27:07.157251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=import-error
    # pylint: disable=protected-access
    from ansible.playbook.task import Task
    task = Task()
    action_module = ActionModule(task, None, None, None, None)
    assert action_module is not None
    action_module._templar = None
    action_module._loader = None
    action_module.run()

# Generated at 2022-06-23 07:27:15.156083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager, HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(HostVars(loader=loader, groups={}))
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote

# Generated at 2022-06-23 07:27:24.009905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import module snippets
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableList

    # Declare mock_tqm, other needed vars
    mock_tqm = object()
    mock_loader = object()
    mock_templar = object()
    task_vars = dict()
    tmp = None

    # Instantiate ActionModule

# Generated at 2022-06-23 07:27:37.134015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader

    task_vars = dict(
        a='1',
        b='2'
    )

    loader = DataLoader()
    action_name = 'assert'
    action_plugin = action_loader.get(action_name, class_only=True)
    action_plugin = action_plugin()

    test_result = action_plugin.run(None, task_vars=task_vars)

    assert '_ansible_verbose_always' in test_result
    assert test_result['_ansible_verbose_always'] is True

    assert 'failed' in test_result
    assert 'evaluated_to' in test_result
    assert 'assertion' in test_result

# Generated at 2022-06-23 07:27:43.434065
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:27:45.389869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    value = {}
    module = ActionModule(None, value)
    assert(module)

# test boolean function

# Generated at 2022-06-23 07:27:52.952673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

# Generated at 2022-06-23 07:27:57.321992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    def fake_run(tmp, task_vars):
        # unit_test_failure_message
        return None

    module.run = fake_run

    # unit_test_failure_message
    assert module.run() == None


# Generated at 2022-06-23 07:28:00.924776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-23 07:28:04.915332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert module

# Generated at 2022-06-23 07:28:13.873043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def side_effect_get(argname):
        if argname == 'fail_msg':
            return 'Fail Message'
        raise KeyError()

    fake_task = type('fake_task', (object,), {
        'name': 'fake_task_name',
        'action': 'fake_task_action',
        '_role': type('fake_role', (object,), {
            '_role_path': 'fake_task_role_path',
            'name': 'fake_task_role_name'
        }),
        'args': {
            'that': [
                {
                    'test': 'foo',
                }
            ],
        }
    })

    fake_task_vars = {
        'foo': 'bar'
    }


# Generated at 2022-06-23 07:28:19.160800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.conditional import Conditional

    AnsibleError = AnsibleError('Test case for AnsibleError')
    # Nothing to test, action module is just a wrapper around the conditional statement



# Generated at 2022-06-23 07:28:28.263080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module_path = 'library'
    test_module_name = 'action_plugin'
    test_module_args = {'fail_msg':'fail_msg', 'msg':'msg', 'quiet':'quiet', 'success_msg':'success_msg', 'that':'that'}
    test_module_result = {'msg': 'All assertions passed', 'evaluated_to': None, 'assertion': None, 'failed': False, 'changed': False}
    test_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_module.run() == test_module_result

# Generated at 2022-06-23 07:28:32.092105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Ansible version: " + ansible.__version__ + "\n")
    module = ActionModule()

# Generated at 2022-06-23 07:28:41.670165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    action2 = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    action.set_loader(None)
    action.set_loader({})
    action.set_loader({'name':'loader'})

    # Check that method run has a default value for tmp
    result = action.run()
    assert result is not None
    assert 'changed' in result.keys()
    assert 'failed' in result.keys()
    assert 'msg' in result.keys()

    # Check that method run raise a AnsibleError when that key is not in task.args
    tmp = None
    task_vars = None

# Generated at 2022-06-23 07:28:50.030661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test
    import __builtin__ as builtins
    builtins.__dict__['__salt__'] = {}
    # module our test class
    class TestAction(ActionModule):
        _VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    class Action:
        def __init__(self, args):
            self.args = args

    task = Action({'that': [{"foo": 'bar'}]})
    obj = TestAction(task, {})

    # test get_argspec
    assert(obj._get_argspec() == obj._VALID_ARGS)

    # test run

    # fail_msg with string

# Generated at 2022-06-23 07:28:55.915801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(action='test', params={'fail_msg': 'expected fail_msg', 'success_msg': 'expected success_msg',
                                              'that': 'some_condition'}, task=None)
    assert obj is not None


# Generated at 2022-06-23 07:29:07.546515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            fail_msg=dict(required=False, type='str', default='Assertion failed'),
            msg=dict(required=False, type='str', default='Assertion failed'),
            quiet=dict(required=False, type='bool', default='False'),
            success_msg=dict(required=False, type='str', default='All assertions passed'),
            that=dict(required=True, type='list', default=[]),
        ),
        supports_check_mode=True
    )
    mm = ActionModule(module, {})

    module.params['fail_msg'] = 'Assertion failed'
    module.params['msg'] = 'Assertion failed'
    module.params['quiet'] = False

# Generated at 2022-06-23 07:29:16.967021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myActionModule = ActionModule(action='debug', task_id=123, play_context={}, loader=None, templar=None, shared_loader_obj=None)
    assert myActionModule._action == 'debug', 'Expected debug, got {0}'.format(myActionModule._action)
    assert myActionModule._task_id == 123, 'Expected 123, got {0}'.format(myActionModule._task_id)
    assert myActionModule._play_context is not None, 'Expected not None, got {0}'.format(myActionModule._play_context)
    assert myActionModule._loader is None, 'Expected None, got {0}'.format(myActionModule._loader)

# Generated at 2022-06-23 07:29:27.561554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ACTION_MODULE = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ACTION_MODULE._connection = None
    ACTION_MODULE._templar = None

    test_args = {{'status': '0'}}
    ACTION_MODULE._task.args = test_args
    ACTION_MODULE._task.action = 'assert'
    ACTION_MODULE._task.args = {'msg': ['success_msg', 'success_msg_1']}
    ACTION_MODULE._task.action = 'assert'
    ACTION_MODULE._task.args = {'fail_msg': ['fail_msg', 'fail_msg_1']}
    ACTION_MODULE._task.action = 'assert'
    ACTION_MODULE._task

# Generated at 2022-06-23 07:29:31.072484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule(None, task_vars={"a":2})
    result = action_module_obj.run(task_vars=None)
    assert result == {}

# Generated at 2022-06-23 07:29:43.228320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a test ActionModule object
    am = ActionModule('')

    # test with a simple that value
    am._task.args = dict(that='true')
    assert False == 'failed' in am.run()
    assert 'All assertions passed' == am.run()['msg']

    # test with multiple that values
    am._task.args = dict(that=['true', 'true'])
    assert False == 'failed' in am.run()
    assert 'All assertions passed' == am.run()['msg']

    # test with a custom success_msg
    am._task.args = dict(that='true', success_msg='Passed')
    assert False == 'failed' in am.run()
    assert am.run()['msg'] == 'Passed'

    # test with a simple that value and a custom fail_msg

# Generated at 2022-06-23 07:29:45.832385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('/var/ansible/tmp')
    assert action._task.action == 'assert'
    assert action._task.loop == None

# Generated at 2022-06-23 07:29:53.230443
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct a dummy module_utils.basic._AnsibleModule object
    class MockAnsibleModule():
        def __init__(self):
            self.params = {'name': 'test'}

    # Construct a dummy collections.defaultdict object
    class MockDefaultDict():
        def __getitem__(self, key):
            return MockDefaultDict()

        def get(self, key, default=None):
            return default

    # Construct a dummy module_utils.parsing.convert_bool.boolean object
    class MockBoolean():
        def __init__(self, value):
            return value

    # Construct a dummy module_utils.parsing.dataloader.DataLoader object
    class MockDataLoader():
        def __init__(self):
            return None

    # Construct a dummy module_utils

# Generated at 2022-06-23 07:30:07.969331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task.args['quiet'] = False
    am._task.args['that'] = ['result.rc == 0', 'result.resources|length != 0', 'invalid_key != 0']
    am._task.args['fail_msg'] = ['A failure message', 'Failed second assertion', 'An invalid key']
    am._task.args['success_msg'] = ['A success message']
    task_vars = {'result': {'rc': 0, 'resources': [1,2]}}
    result = am.run(task_vars=task_vars)
    assert result['changed'] is False
    assert result['msg'] == ['A success message']

    task_vars['result']['resources'] = []
    result = am.run(task_vars=task_vars)

# Generated at 2022-06-23 07:30:18.306294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {'fail_msg':'failed', 'msg':'failed', 'quiet':False, 'success_msg':'success', 'that':'that'}
    dummy_class = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = dummy_class.run(tmp=None, task_vars=None)
    assert result['msg'] == 'failed'
    assert result['evaluated_to'] == False
    assert result['failed'] == True
    assert result['assertion'] == 'that'
    module_args = {'fail_msg':'failed', 'quiet':False, 'success_msg':'success', 'that':'that'}

# Generated at 2022-06-23 07:30:29.137613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    mock_loader = action_loader._create_mock_loader({'testns': {'assert': ActionModule}})
    pcontext = PlayContext()
    adhoc_task = dict(action='testns.assert', when='2>1', msg='foo')
    atask = mock_loader.load_from_task(adhoc_task, pcontext=pcontext, variable_manager=None, loader=mock_loader)
    atask.post_validate(adhoc_task, False)
    result = atask.run(task_vars={'nonsense': 'nonsense'}, loader=mock_loader)
    assert result['msg'] == 'foo'
    assert result['failed'] == False
   

# Generated at 2022-06-23 07:30:33.633069
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys

    for item in sys.modules.keys():
        if item.startswith("ansible.plugins.action."):
            del sys.modules[item]


# Generated at 2022-06-23 07:30:37.956936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = dict()
    action = ActionModule(tmp, task_vars)
    print("Create ActionModule success ! ")

# test_ActionModule()

# Generated at 2022-06-23 07:30:47.433575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        def __init__(self):
            self.args = {'that': ['foo', 'bar']}

    class MockTask(object):
        def __init__(self):
            self.action = 'assert'

    am = ActionModule()

    am.action = 'assert'
    am._task = MockTask()
    assert am.action == 'assert'
    assert am._task.action == 'assert'

    am.task_vars = {'ansible_system': 'Linux'}
    assert am.task_vars['ansible_system'] == 'Linux'

    am._templar = 'some_templar'
    assert am._templar == 'some_templar'

    am._loader = 'some_loader'
    assert am._loader == 'some_loader'

# Generated at 2022-06-23 07:30:58.515390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task_include
    import ansible.utils.template
    import ansible.parsing.yaml.objects

    import types
    import copy
    import sys

    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils.six import PY3

    from units.mock.loader import DictDataLoader

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_fail_without_args(self):
            ''' fail without args '''
            t = ansible.playbook.task.Task()

# Generated at 2022-06-23 07:31:04.045584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None)
    assert sorted(ActionModule._VALID_ARGS) == sorted(am.valid_args)

# Generated at 2022-06-23 07:31:12.271507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class PluginLoaderStub(object):
        def __init__(self):
            self.plugins = dict()
            self.all_plugin_names = dict()
            self.aliases = dict()

    class PlaybookStub(object):
        def __init__(self, variable_manager=None, loader=None):
            pass

    class RunnerStub(object):
        def __init__(self):
            self.connection = None
            self.module_name = None
            self.module_args = None
            self.forks = None
            self.timeout = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = None
            self.diff = None
            self.remote_user = None
            self.load_name = None
           

# Generated at 2022-06-23 07:31:21.410990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock some parameters
    task_vars=dict()
    task_vars['test_var']='test'
    tmp=None
    # mock a task with some args
    task=dict()
    args=dict()
    args['fail_msg']='test_fail_msg'
    args['success_msg']='test_success_msg'
    args['quiet']=True
    args['msg']='test_msg'
    args['that']='test_var'
    task['args']=args
    # create a templar
    templar=MockTemplar(vars)
    # create an action_module
    action_module=ActionModule(task, templar, task_vars=task_vars)
    # run the action module

# Generated at 2022-06-23 07:31:29.476872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    "fail" action plugin run method is used to raise a fatal error
    in a playbook. This test specifically verifies whether the
    return data structure has the correct keys set to the correct
    values.
    """
    import unittest

    class FakeTemplar(object):
        def __init__(self):
            self.template = 'test_template'

    class FakeLoader(object):
        def __init__(self):
            self.templar = FakeTemplar()

    class FakeTask(object):
        def __init__(self):
            self.args = {'that': ['test_that'], 'fail_msg': 'test_fail_msg', 'success_msg': 'test_success_msg'}

    class FakePlayContext(object):
        def __init__(self):
            self.check_

# Generated at 2022-06-23 07:31:38.078104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of class ActionModule
    """
    # Check the asserted error message when fail_msg and msg are None
    task = dict(
        args=dict(fail_msg=None, msg=None, that='foo'),
    )
    task_vars = dict()
    tempdir = 'tmpdir'
    loader = 'loader'
    templar = 'templar'
    mock_action = ActionModule(task, tempdir, loader, templar)
    with pytest.raises(AnsibleError) as excinfo:
        mock_action.run(tempdir, task_vars)
    assert 'conditional required in "that" string' in str(excinfo.value)

    # Assert error when fail_msg and msg are lists with at least one element whose type is not string

# Generated at 2022-06-23 07:31:50.223636
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up a task executor and a task that requires a custom action
    TaskExecutor = get_action_executor()
    task = TaskExecutor._task

    # set up the target object to test
    target = ActionModule()
    target._task = task
    target._loader = None
    target._connection = None
    #target._templar = None
    target._templar = MockTemplar()

    # set up test inputs
    tmp = None
    task_vars = {'foo': 'bar'}

    # set up the mocks for the target object
    ## _execute_module()
    # _execute_module() is called by get_action_executor()
    # so we do not mock it here.
    #target._execute_module = Mock()
    #target._execute_module.return_value =

# Generated at 2022-06-23 07:31:59.238647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import role

    task = Task()
    task._role = role.Role()
    task._role.name = 'test_role'
    task.task_include = 'test_include'
    task.action = 'fail'
    task.args['msg'] = 'assertion failed'
    task.when = ['1==0']
    task._role._role_path = 'test/role/path'

    play_context = {}
    loader = None
    variable_manager = None
    task_vars = {}
    play = Play()
    result = {}

    fail_obj = ActionModule(task, play_context, variable_manager, loader, play, result)

# Generated at 2022-06-23 07:32:11.210569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run = ActionModule(None, None).run
    action = dict(when=['1 == 1'])
    test_result = run(task_vars=dict(), tmp=None, task_action=action)
    assert not test_result['failed']
    assert test_result['evaluated_to']
    assert test_result['assertion'] == '1 == 1'
    assert test_result['msg'] == 'All assertions passed'

    action = dict(when=['1 == 0'])
    test_result = run(task_vars=dict(), tmp=None, task_action=action)
    assert test_result['failed']
    assert not test_result['evaluated_to']
    assert test_result['assertion'] == '1 == 0'
    assert test_result['msg'] == 'Assertion failed'

# Generated at 2022-06-23 07:32:18.705199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    actmod = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    # call method run and assert that it handled both cases properly
    try:
        actmod.run()
    except AnsibleError:
        pass

# Generated at 2022-06-23 07:32:29.094660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method ActionModule.run"""
    import sys
    import io
    import unittest
    import pprint
    import contextlib

    # Set up test environment

# Generated at 2022-06-23 07:32:41.142171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock Task
    task = Mock_Task()

    # mock Ansible
    ansible_instance = Mock_Ansible()

    # mock PlayContext
    play_context_instance = Mock_PlayContext()

    # mock ModuleLoader
    module_loader_instance = Mock_ModuleLoader()

    # mock ActionBase
    action_base_instance = Mock_ActionBase(task, ansible_instance, play_context_instance, module_loader_instance)

    # create an instance of ActionModule class
    action_module_instance = ActionModule(task, ansible_instance, play_context_instance, module_loader_instance)


    # initialize the variables used in test
    msg = action_module_instance._task.args['msg']
    fail_msg = action_module_instance._task.args['fail_msg']

# Generated at 2022-06-23 07:32:45.396433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-23 07:32:54.426098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule. '''

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # create task
    task = Task()

    # create ActionModule with that set to 'foo'
    task.args = {'that': 'foo'}
    am = ActionModule(task, None)

    # create mock task_vars and set to foo_val
    task_vars = {}
    foo_val = "bar"
    task_vars['foo'] = foo_val

    # call method run
    result = am.run(task_vars=task_vars)

    # assertions
    assert result['failed'] == False
    assert result['msg'] == 'All assertions passed'



# Generated at 2022-06-23 07:33:04.431593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts.system.core import Distro

    data_loader = DataLoader()


# Generated at 2022-06-23 07:33:07.331276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, shared_loader_obj=None, path=None,
    _task=None, connection=None, play_context=None, loader_cache=None, templar=None,
    task_vars=None, wrap_async=None)
    return action_module

# Generated at 2022-06-23 07:33:09.535935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict()) is not None

# Generated at 2022-06-23 07:33:15.463088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook, Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import Include
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueItem

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    data_loader = DictDataLoader({})

    play_context = PlayContext()
    play_context.network_os = 'ios'

    # create test object

# Generated at 2022-06-23 07:33:23.536754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    Testing with a small set of valid and invalid arguments
    """
    # Testing quiet mode
    task = dict(when='yes')
    task_vars = dict(ansible_verbose_always=True)
    tmp = None
    a = ActionModule(task, tmp, tmp, task_vars)
    task = dict(
        msg='hello',
        quiet=False
    )
    a._task = dict(args=task)
    result = a.run(tmp, task_vars)

    assert 'msg' in result
    assert result['_ansible_verbose_always']

    task = dict(
        msg='hello',
        quiet=True
    )
    a._task = dict(args=task)

# Generated at 2022-06-23 07:33:34.004780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    play_context._become = True
    play_context._become_method = 'sudo'
    play_context._become_user = 'root'
    play_context._connection = 'local'
    play_context._diff = False
    play_context._task_vars = {'hostvars': {'a.example.com': {}, 'b.example.com': {}}}
    play_context._

# Generated at 2022-06-23 07:33:41.898347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(action=dict(fail_msg="Failed")), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    result = module.run(task_vars=dict(), tmp='/tmp')
    assert result.get('failed') is True
    assert result.get('evaluated_to') is False
    assert result.get('assertion') is None
    assert result.get('msg') == "Failed"

    module = ActionModule(task=dict(action=dict(that=dict(test=False), fail_msg="Failed")), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    result = module.run(task_vars=dict(), tmp='/tmp')

# Generated at 2022-06-23 07:33:51.251469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types

    # Create an instance of class ActionModule
    tmp = None

# Generated at 2022-06-23 07:33:54.485347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Do not call the constructor but use the global instance
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:34:03.517630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-23 07:34:04.200910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:34:06.568333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_1 = ActionModule()
    assert module_1._VALID_ARGS

# Generated at 2022-06-23 07:34:17.978372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_types_instance = string_types(b'foo')
    list_instance = list((1,2))
    list_instance_string = list(('foo','bar'))
    frozenset_instance = frozenset(['foo','bar'])
    task_args_instance_msg = {'msg': 'foo'}
    task_args_instance_fail_msg = {'fail_msg': 'foo'}
    task_args_instance_success_msg = {'success_msg': 'foo'}
    task_args_instance_that = {'that': 'foo'}
    task_args_instance_quiet = {'quiet': 'foo'}
    task_args_instance_msg_fail_msg = {'msg': 'foobar', 'fail_msg': 'foo'}
    task_args_instance_msg

# Generated at 2022-06-23 07:34:19.092865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionPlugin = ActionModule()

# Generated at 2022-06-23 07:34:29.863873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    import yaml

    class TaskVars(HostVars):
        def __init__(self, t_vars):
            self._t_vars = t_vars

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self._t_vars

    class AnsibleModule(object):
        def __init__(self, template_ds):
            self

# Generated at 2022-06-23 07:34:31.031079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Check whether run method of class ActionModule returns appropriate value """
    pass

# Generated at 2022-06-23 07:34:40.612716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(that = [''])
    action = ActionModule(task = dict(args = task_args),
        connection = None, play_context = dict(), loader = None, templar = None, shared_loader_obj = None)
    with pytest.raises(AnsibleError) as execution_info:
        action.run()
    assert execution_info.value.message == 'conditional required in "that" string'

    task_args = dict(that = [])
    action = ActionModule(task = dict(args = task_args),
        connection = None, play_context = dict(), loader = None, templar = None, shared_loader_obj = None)
    with pytest.raises(AnsibleError) as execution_info:
        action.run()
    assert execution_info.value.message

# Generated at 2022-06-23 07:34:51.035703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeTask:
        def __init__(self, args={}):
            self.args = args

    class FakeModule:
        def __init__(self, task_vars={}):
            self.task_vars = task_vars

    # Check for msg
    module = ActionModule(FakeTask(), FakeModule())
    assert module._task.args.get('msg') is None
    assert module.run()['msg'] == 'Assertion failed'

    # Check for fail_msg
    module = ActionModule(FakeTask(args={'fail_msg': 'Failed'}), FakeModule())
    assert module.run()['msg'] == 'Failed'

    # Check for success_msg
    module = ActionModule(FakeTask(args={'success_msg': 'Success'}), FakeModule())
    assert module.run

# Generated at 2022-06-23 07:35:00.715919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare the test set
    task_vars = dict()
    that = 'my_assertion'
    fail_msg = 'Assertion failed'
    success_msg = 'All assertions passed'
    args = dict(that=that, fail_msg=fail_msg, success_msg=success_msg)
    task = dict(args=args)
    tmp = None

    # Prepare an instance of the class under test
    action = ActionModule()
    action._task = task
    action._loader = None
    action._templar = None

    # Unit test
    result = action.run(tmp, task_vars)

    # Result assertions
    assert result is not None
    assert result['failed'] is False
    assert result['changed'] is False
    assert result['msg'] == success_msg


# Generated at 2022-06-23 07:35:02.819902
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    myclass = ActionModule(None, {}, {})

    assert myclass.run()

# Generated at 2022-06-23 07:35:12.055620
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:35:19.021033
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:35:19.676559
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:35:21.193283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'No unit test for method run of class ActionModule'

# Generated at 2022-06-23 07:35:24.067078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None


# Generated at 2022-06-23 07:35:34.268916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = AnsibleModule(argument_spec={})
  module.check_mode = False
  module.no_log = False
  action = ActionModule()
  action._task = Task()
  action._task.args = dict()
  action._task.args['that'] = '1 = 1'
  action._loader = DataLoader()
  with pytest.raises(AnsibleError) as err:
    action.run(tmp=None, task_vars=None)
  assert 'conditional required in "that" string' in err.value.message
  action._task.args['that'] = []
  action._task.args['fail_msg'] = 'test'
  action.run(tmp=None, task_vars=None)
  action._task.args['fail_msg'] = 1

# Generated at 2022-06-23 07:35:35.072401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:35:45.174445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For Ansible version >= 2.4
    MODULE_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../')
    MODULE_PATH = os.path.normpath(MODULE_PATH)
    sys.path.append(MODULE_PATH)
    from action_plugins.assertion import ActionModule

    # Mock module_utils
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        from ansible.module_utils.basic import *
    # end of Mock module_utils

    # define a class for mock loader
    class MockLoader:

        def __init__(self):
            pass

        class LoaderModuleError(Exception):
            pass

        class AnsibleParserError(Exception):
            pass

    # define a class for

# Generated at 2022-06-23 07:35:56.768900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert 'fail_msg' in module._VALID_ARGS
    assert 'msg' in module._VALID_ARGS
    assert 'quiet' in module._VALID_ARGS
    assert 'success_msg' in module._VALID_ARGS
    assert 'that' in module._VALID_ARGS

    # Test cases for success_msg and msg
    task = dict(args=dict(msg=None, success_msg=None))
    module = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert 'Assertion failed' == module.run()['msg']

# Generated at 2022-06-23 07:35:59.275086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None, None, None, None, None)
    assert False == module.run(None, None)

# Generated at 2022-06-23 07:36:01.891822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of ActionModule class.
    """
    pass


# Generated at 2022-06-23 07:36:04.922032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict()),connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)

# Generated at 2022-06-23 07:36:06.115028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action) == ActionModule


# Generated at 2022-06-23 07:36:11.587791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = sys.modules[__name__]
    actionModule = module.ActionModule(loader=None, inventory=None, variable_manager=None, all_vars=dict(), task_vars=dict())
    assert isinstance(actionModule, module.ActionModule)


# Generated at 2022-06-23 07:36:21.960594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks
    test_action = ActionModule()
    test_action._task = Mock()
    test_action._task.args = {'fail_msg': 'Assertion failed'}
    test_action._task.action = 'Assert'
    test_action._loader = Mock()
    test_action._templar = Mock()
    test_action._connection = Mock()
    test_action._play_context = Mock()
    test_action._play_context.check_mode = False

    # Check with fail_msg
    res = test_action.run(task_vars={'var': 'value'})

# Generated at 2022-06-23 07:36:29.335685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args = {
                "that": "{{ myvar }}"
            }
        ),
        connection=None,
        play_context=dict(
            check_mode=False
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    task_vars = dict(
        myvar="my value"
    )

    # run() should return a dict with "msg"
    result = action_module.run(task_vars=task_vars)
    assert 'msg' in result

    # result["msg"] should be equal to the value of success_msg
    success_msg = action_module._task.args.get('success_msg')

# Generated at 2022-06-23 07:36:40.022856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C

    # Create a task that can be used for testing
    class TestTask:

        def __init__(self, args):
            args = args or {}
            self.args = {}