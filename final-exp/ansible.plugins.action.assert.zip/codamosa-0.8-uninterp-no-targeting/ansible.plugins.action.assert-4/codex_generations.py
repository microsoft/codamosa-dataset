

# Generated at 2022-06-21 01:45:19.414519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest.mock as mock
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase

    def test_ActionModule_args_are_None():
        actionBase = ActionBase()

# Generated at 2022-06-21 01:45:29.446056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, connection_loader

    class MockVariableManager:
        def __init__(self):
            self.extra_vars = {}
        def get_vars(self, loader, path, entities, cache=True):
            return {}

# Generated at 2022-06-21 01:45:30.771032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:45:32.804698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # TODO
    assert False

# Generated at 2022-06-21 01:45:42.016010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(
            fail_msg='fail_msg',
            msg='msg',
            quiet='quiet',
            success_msg='success_msg',
            that='that',
        )),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None,
    )

    assert 'fail_msg' == module._task.args['fail_msg']
    assert 'msg' == module._task.args['msg']
    assert 'quiet' == module._task.args['quiet']
    assert 'success_msg' == module._task.args['success_msg']
    assert 'that' == module._task.args['that']



# Generated at 2022-06-21 01:45:49.945929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    from ansible.module_utils.six import string_types

    import sys
    from io import StringIO
    import json

    # Create the objects needed to perform the testruns
    class Options:
        connection = 'local'
        module_path = None
        forks = 1
        become = None
        become_method = None
        become_

# Generated at 2022-06-21 01:45:50.922292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:45:53.616485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 01:46:03.062953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import unittest
    module = sys.modules[__name__]

    """Check that run works correctly"""

# Generated at 2022-06-21 01:46:12.878193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3

   # Create the class object
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Set needed attribs
    am.templar._available_variables = {'ansible_check_mode': True}

    am._task = Task()
    am._task.action = 'assert'
   

# Generated at 2022-06-21 01:46:24.872435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner_mock = ActionModule.run(task_vars={'test': 'false'}, task={"args":{"that":"{{ test == true }}","fail_msg":"Test failed","quiet":True}})
    print("Success", runner_mock)

# Generated at 2022-06-21 01:46:37.100952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule

    '''
    Uses mock to check correct call to Conditional class
    '''

    action = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None, files=None)

    # Tests for quiet=False
    m = Mock()
    action._templar = m
    action._loader = m

    result = {"_ansible_verbose_always": True}
    m.evaluate.return_value = True
    action._task.args = {'that': ['a < 10', 'b < 10']}
    result_from_run = action.run()
    assert (result_from_run == result)
    assert m.evaluate.call_count == 2
    assert m.evaluate.call_

# Generated at 2022-06-21 01:46:49.624695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Check that result contains expected keys when success_msg and fail_msg not included
    def run_test0():
        # Setup Arguments
        args = dict()
        args['msg'] = 'Assertion failed'
        args['quiet'] = False
        args['that'] = ['command succeeds']

        # Assign Arguments
        module._task.args = args

        # Setup Task Vars
        task_vars = dict()
        task_vars['ansible_check_mode'] = False
        task_vars['ansible_verbosity'] = 0
        task_vars['ansible_version'] = dict()
        task_vars['ansible_version']['full'] = 'v2.1.0.0-1.el7.cen7.noarch'
        task_v

# Generated at 2022-06-21 01:47:02.150799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask:
        def __init__(self, that, fail_msg, msg, quiet, success_msg):
            self.args = {
                'fail_msg': fail_msg,
                'msg': msg,
                'quiet': quiet,
                'success_msg': success_msg,
                'that': that
            }
    class MockTemplar:
        def __init__(self):
            self.result = {'msg': 'Assertion failed', 'failed': True}
        def template(self, expr):
            return self.result
    class MockVars:
        def __init__(self):
            pass
    class MockLoader:
        def __init__(self):
            pass
    class MockConditional:
        def __init__(self, loader):
            pass

# Generated at 2022-06-21 01:47:02.630239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:47:10.216679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Return code is not None and no exception raised
    return_code = ActionModule.run(ActionModule())
    assert return_code is not None

    # Return code is None and exception raised
    try:
        return_code = ActionModule.run(ActionModule(), task_vars=None)
    except Exception:
        return_code = None
        assert return_code is None
    assert return_code is None

    # Return code is None and exception raised
    try:
        return_code = ActionModule.run(ActionModule(), tmp=None)
    except Exception:
        return_code = None
        assert return_code is None
    assert return_code is None


# Generated at 2022-06-21 01:47:11.634418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(ActionModule(),{},{})

# Generated at 2022-06-21 01:47:13.533573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO: Write test"


# Generated at 2022-06-21 01:47:24.202825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This would fail at line 75 of run.  Thats no longer a conditional but
    # rather a list of strings.  Previously it was a conditional which is
    # how this error was raised.
    action_task = {
        'name': 'Test case',
        'action': 'assert',
        'args': {
            'that': [
                '\'{{ foo }}\'|length == 1',
                '\'{{ foo }}\'|length == 2',
                '\'{{ foo }}\'|length == 3',
            ],
            'success_msg': '{{ success_message }}',
            'fail_msg': '{{ failure_message }}',
            'quiet': False,
        }
    }

# Generated at 2022-06-21 01:47:32.361859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = dict(
        fail_msg='failed',
        msg='failed',
        that='ok',
        success_msg='ok',
    )
    a = ActionModule(dict(task=dict(action=dict(module_name='assert', module_args=t), args=t), task_vars=dict(ansible_verbose_always=False)))
    assert a.run() == dict(failed=True, msg='failed', assertion='ok', evaluated_to=False)

    t = dict(
        msg='failed',
        quiet=True,
        that='ok',
    )
    a = ActionModule(dict(task=dict(action=dict(module_name='assert', module_args=t), args=t), task_vars=dict(ansible_verbose_always=False)))

# Generated at 2022-06-21 01:47:53.173311
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:48:00.832855
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:48:10.053138
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:48:13.804920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(not hasattr('ActionModule', '_valid_args'))
    assert(not hasattr('ActionModule', 'TRANSFERS_FILES'))

# Generated at 2022-06-21 01:48:27.314484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .mock import patch, Mock
    import sys
    import ansible.constants as C
    import ansible.plugins
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import play_context
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    class PlaybookLoader(object):
        def __init__(self, variable_manager):
            pass


# Generated at 2022-06-21 01:48:30.666787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 01:48:40.266134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.playbook.play import Play
  # load test data
  loader = DataLoader()
  variable_manager = VariableManager()
  inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['testhost'])
  play_source = dict(name="play name", hosts='all', gather_facts='no', tasks=[])
  play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
  tqm = None
  # set task

# Generated at 2022-06-21 01:48:43.472708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert type(action_module.run(None, None)) == dict

# Generated at 2022-06-21 01:48:50.050681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make sure that both fail_msg and success_msg can accept strings and lists
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)

    result = action_module.run(None, {'test_var': 'a string', 'test_var2': 'another string'},
                               fail_msg='string message', success_msg='string message1')
    assert isinstance(result['msg'], str)

    result = action_module.run(None, {'test_var': 'a string', 'test_var2': 'another string'},
                               fail_msg=['string message', 'another string message'],
                               success_msg=['string message1', 'another string message1'])


# Generated at 2022-06-21 01:48:59.581230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run to establish locals()
    test_ActionModule_run.__code__

    # Store function locals() for use in nested functions and callbacks
    data = locals()

    # Requirements
    import os.path
    import tempfile

    # Setup test module
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    if 'inventory' not in data:
        data['inventory'] = InventoryManager(loader=DataLoader().load_from_file(os.path.join('..', '..', 'tests', 'inventory')))
    if 'basedir' not in data:
        data['basedir'] = tempfile.mkdtemp()

    # Setup test task
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play


# Generated at 2022-06-21 01:49:33.951902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m.TRANSFERS_FILES == False
    assert m._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:49:40.334442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert isinstance(action, ActionBase)
    assert isinstance(action, ActionModule)
    assert action._task is None
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert not action._connection_info

# Generated at 2022-06-21 01:49:49.146773
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:50:00.475389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    yaml_dict = {'action': {'fail_msg': 'Assertion failed', 'msg': 'Assertion failed', 'quiet': False, 'that': 'hostvars[inventory_hostname]', 'success_msg': 'All assertions passed'}, 'name': 'test'}


# Generated at 2022-06-21 01:50:01.343317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:50:11.222441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    PLAYBOOK = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {
                'action': {
                    'module': 'assert',
                    'args': {
                        'that': 'True'
                    }
                }
            }
        ]
    }, variable_manager=None, loader=None)

    def test_am(task, task_vars=dict()):
        task_copy = task.copy()

# Generated at 2022-06-21 01:50:20.898321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    # Create a task for ActionModule
    task = Task()
    task.action = 'assert'
    task.args = {'that':'isTrue'}
    action = action_loader.get('assert', task, None)

    # Test the constructor of class ActionModule
    assert isinstance(action, ActionModule), 'obj is not an instance of class ActionModule'
    assert action._task.action == 'assert', 'action not assign to _task'
    assert action._task.args == {'that':'isTrue'}, 'action not assign to _task'

# Generated at 2022-06-21 01:50:27.469252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   # Test when 'that' parameter is not present
   tmp = dict()
   task_vars = dict()
   task_vars['hostvars'] = dict()
   action_module = ActionModule()
   ansible_error = None
   try:
      action_module.run(tmp, task_vars)
   except AnsibleError as error:
      ansible_error = error
   assert ansible_error != None
   assert ansible_error.message == 'conditional required in "that" string'
   # Test when 'fail_msg' parameter is not present
   task_vars = dict()
   task_vars['hostvars'] = dict()
   args = dict()
   args['that'] = ['foo']
   args['msg'] = 'bar'
   action_module = ActionModule()
   ansible_

# Generated at 2022-06-21 01:50:36.142323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argv = ['/bin/ansible-playbook', '--check', '--diff', '-u', 'root', '-i', 'localhost,', '-c', 'local', '-e',
            'ansible_check_mode=true', 'playbook.yml']
    options = ansible.utils.cmdline.base_parser(constants.Constants.DEFAULT_MODULE_PATH,
                                                connect_opts=constants.Constants.DEFAULT_SUBPARSER_SUPPORTED_ARGUMENTS,
                                                desc="Ad-hoc command executor").parse_args(argv)
    options.listtags = options.listtasks = options.listhosts = options.syntax = options.module_paths = [
        '/path/to/mymodules']
    variable_manager = ans

# Generated at 2022-06-21 01:50:43.815937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, templar=None, shared_loader_obj=None, **{'task': {'args': {'fail_msg':'msg string', 'quiet':'True', 'success_msg':'msg string', 'that': ['that string']}}, '_ansible_no_log': False, '_ansible_verbose_always': False, '_ansible_verbosity': 2, '_ansible_debug': True})
    assert module.run() == {'changed': False, 'msg': 'All assertions passed'}

# Generated at 2022-06-21 01:52:11.641773
# Unit test for constructor of class ActionModule
def test_ActionModule():

    failure_msg = 'Assertion failed'
    success_msg = 'All assertions passed'

    assert_i_1 = ActionModule({}, {}, 'assert', {'that': [1==2]})
    assert_i_2 = ActionModule({}, {}, 'assert', {'that': [2==2]})

    assert_t_1 = ActionModule({}, {}, 'assert', {'that': ['true']})
    assert_t_2 = ActionModule({}, {}, 'assert', {'that': ['TRUE']})
    assert_f_1 = ActionModule({}, {}, 'assert', {'that': ['false']})
    assert_f_2 = ActionModule({}, {}, 'assert', {'that': ['FALSE']})


# Generated at 2022-06-21 01:52:13.607575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    test_result = am.run(None, {})
    assert test_result['failed']

# Generated at 2022-06-21 01:52:20.404238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-21 01:52:30.290473
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:52:41.204932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.task.assertion import ActionModule
    from ansible.plugins.loader import action_loader

    # This will be executed in order to load the required plugins
    action_loader.add_directory('./lib/ansible/plugins/actions')

    # Create the action plugin
    action = ActionModule(task=dict(args=None), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Set needed attributes of the action plugin
    action._task = dict(args=dict(that="{{ foo }}", msg="Failed"))
    action._task_vars = dict(foo='bar')
    action._loader = None
    action._templar = None

    # Execute the method run of the action plugin

# Generated at 2022-06-21 01:52:44.264803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This will raise an exception if the constructor of ActionModule is not defined completely
    assert(ActionModule is not None)
    # This will raise an exception if the constructor of ActionModule does not take parameters
    assert(ActionModule.__init__ is ActionBase.__init__)
    

# Generated at 2022-06-21 01:52:56.029916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target = ActionModule()
    target.fail_json = lambda msg, **kwargs: msg

    # Test with incorrect type for that
    try:
        target.run(task_vars = {'inventory_hostname': 'target'})
        assert False, 'AnsibleError not raised'
    except AnsibleError:
        pass

    # Test for incorrect type for fail_msg
    try:
        target.run(task_vars = {'inventory_hostname': 'target', 'that': 'some_var'}, fail_msg = ['string', 123])
        assert False, 'AnsibleError not raised'
    except AnsibleError:
        pass

    # Test for incorrect type for success_msg

# Generated at 2022-06-21 01:53:05.613377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(name='some-task', args=dict()),
                                 connection=dict(name='mock'),
                                 play=dict(name='some-play'))

    # test1: no 'that' param
    try:
        action_module.run(task_vars=dict())
    except AnsibleError as e:
        assert 'conditional' in e.message

    # test2: 'that' param is not a list
    action_module._task.args['that'] = "failed"
    try:
        action_module.run(task_vars=dict())
    except AnsibleError as e:
        assert 'Type of one of the elements in fail_msg or msg list is not string type' in e.message

    # test3: 'that' param is a list
    action

# Generated at 2022-06-21 01:53:16.135738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    def gv(x, d=None):
        return d

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.debug = False

    class Runner(object):
        def __init__(self):
            self.module_name = 'action_debug'
            self.module_args = 'msg="some message"'
            self.path_exists_count = 0

        def get_module_vars(self, host, task_vars):
            return task_vars

        def get_vars(self, play=None, host=None, task=None, var_options=None):
            return {}

        def path_exists(self, path):
            self.path_exists_count += 1
           

# Generated at 2022-06-21 01:53:22.437886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    action_plugin = action_loader.get('debug', class_only=True)
    assert action_plugin, "Could not find debug action plugin"
    assert issubclass(action_plugin, ActionModule),\
        "action_plugin is not of type ActionModule"