

# Generated at 2022-06-21 01:45:26.483283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' This is kind of an integration test, but it makes sure the constructor of
    our example class works as expected, which is something we can unit test. '''

    # We want to set up a mock task here, and make sure that we can create an
    # ActionModule object and use it to run the task

    module = ActionModule(
        task=dict(
            action=dict(
                module_name='debug',
                args=dict(
                    msg="Hello World"
                )
            )
        )
    )

    results = module.run()
    assert results.get('msg') == "Hello World"

# Generated at 2022-06-21 01:45:33.241208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action = ActionModule()
    action._task = Mock()

    # Act & Assert
    # Shouldn't raise any exception
    try:
        action.run()
    except Exception as e:
        assert False, 'Unexpected exception thrown, message: %s' % e.message

# Generated at 2022-06-21 01:45:34.950897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionBase)


# Generated at 2022-06-21 01:45:35.448484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1

# Generated at 2022-06-21 01:45:41.914674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule class')
    actionmodule = ActionModule(None, 'playbook_path/playbook.yml', '/path/to/ansible/module', None, None, None, None, None, 'user')
    print('Class initialization doen')


# Generated at 2022-06-21 01:45:45.067745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test loading and using the module
    '''
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-21 01:45:48.809701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule(task=None, connection=None, play_context=None, loader=None,
                            templar=None, shared_loader_obj=None)
    except:
        raise


# Generated at 2022-06-21 01:46:00.449719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for module_utils/parsing/convert_bool.boolean() and check if the
    # exception Traceback is getting displayed in verbose mode
    am = ActionModule(None, {'msg': [True], 'fail_msg': False})
    result = am.run(None, {'ansible_verbosity': 2})
    assert result['msg'] == 'Incorrect type for fail_msg or msg, expected a string or list and got <type \'bool\'>'

    # Test for module_utils/parsing/convert_bool.boolean() and check if the
    # exception Traceback is getting displayed in non-verbose mode
    am = ActionModule(None, {'msg': [True], 'fail_msg': False})
    result = am.run(None, {'ansible_verbosity': 0})

# Generated at 2022-06-21 01:46:06.402845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = {'args': {'that': ["1 == 1"]}, 'delegate_to': 'xyz'}
    _loader = None
    _templar = None
    _task_vars = None
    _tmp = None

    am = ActionModule(_task, _loader, _templar, _task_vars)
    am.run(_tmp, _task_vars)

# Generated at 2022-06-21 01:46:18.626340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook import Task
    from ansible.playbook import Role
    from ansible.playbook import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.play_context import PlayContext

    # initialize
    loader = DictDataLoader({
        "templates": {"assert.j2": "{{ is_changed }}"},
        "vars": {"a": "b"},
        "hosts": ["localhost"],
    })
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])

# Generated at 2022-06-21 01:46:38.651331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Success condition
    results = ActionModule.run(ActionModule(), tmp=None,
                               task_vars={'a': {'b': {'d': 0}}, 'some': 'success'})
    assert results is not None
    assert results['assertion'] is None
    assert results['changed'] == False
    assert results['failed'] == False
    assert results['result'] == {}
    assert results['msg'] == 'All assertions passed'

    # Failure condition
    results = ActionModule.run(ActionModule(), tmp=None,
                               task_vars={'a': {'b': {'d': 0}}, 'some': 'success'},
                               fail_msg="failure message",
                               success_msg="success message",
                               that="this.some is not defined")
    assert results is not None

# Generated at 2022-06-21 01:46:45.966772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task import Task

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.status_no_hosts = False
            self.host_ok = {}
            self.host_unreachable = {}

# Generated at 2022-06-21 01:46:51.503969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with empty args dict
    args = dict()
    assert ActionModule.run({}, args)

    # Test with 'that' defined
    args = dict(that='1')
    result = ActionModule.run({}, args)
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'

    # Test with 'that' undefined
    args = dict(that=None)

# Generated at 2022-06-21 01:47:02.797628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule
    assert hasattr(cls, '_VALID_ARGS'), 'class attributes not defined'
    assert isinstance(cls._VALID_ARGS, frozenset), 'class attributes have to be frozenset'
    assert 'fail_msg' in cls._VALID_ARGS
    assert 'msg' in cls._VALID_ARGS
    assert 'quiet' in cls._VALID_ARGS
    assert 'success_msg' in cls._VALID_ARGS
    assert 'that' in cls._VALID_ARGS
    assert 'not' not in cls._VALID_ARGS
    assert 'group_by' not in cls._VALID_ARGS

    assert not hasattr(cls, 'run'), 'action module has to have run method'

# Generated at 2022-06-21 01:47:12.791121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a dummy ActionModule class
    class DummyActionModule():
        VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self.C = shared_loader_obj

    class DummyTask():
        def __init__(self, args):
            self.args = args


    # create an instance of ActionModule
    task = DummyTask({'success_msg': "All assertions passed", 
                      'that': 'X is a dictionary'})

# Generated at 2022-06-21 01:47:23.316981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = dict()
    config['any_errors_fatal'] = dict()

    config['any_errors_fatal']['__ansible_module__'] = "setup"
    config['any_errors_fatal']['__ansible_arguments__'] = "test=test"
    config['any_errors_fatal']['__ansible_syslog_facility'] = "nil"
    config['any_errors_fatal']['__ansible_syslog_ident'] = "nil"

    config['any_errors_fatal']['assertion'] = "{'failed': False, 'evaluated_to': False, 'assertion': '1 == 2'}"

# Generated at 2022-06-21 01:47:25.516238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert  False


# Generated at 2022-06-21 01:47:29.409981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    am  = TestActionModule(task=dict())

    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:47:30.769230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Do something
    return True

# Generated at 2022-06-21 01:47:31.585565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:47:53.567261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(task=dict(args=dict(that=['some_condition', 'another_condition'])))
    cond = Conditional(loader=m._loader)
    cond.when = ['some_condition', 'another_condition']
    m._templar = cond._templar

    result = m.run(task_vars=dict())
    assert result['msg'] == 'All assertions passed'
    assert result['assertion'] == 'some_condition'
    assert result['evaluated_to'] == False

    result = m.run(task_vars=dict(some_condition=True, another_condition=True))
    assert result['msg'] == 'All assertions passed'
    assert result['assertion'] == 'some_condition'
    assert result['evaluated_to'] == True


# Generated at 2022-06-21 01:48:00.911395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # Fixed values generated by the below program
    fixed_task = {
        'args': {
            'that': [
                "ansible_os_family != 'Debian'"
            ]
        },
        '_role_names': [],
        '_role_params': {},
        'name': 'conditional . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .'
    }
   

# Generated at 2022-06-21 01:48:10.078777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='assert', args=dict(that='foo', success_msg='yes', msg='no', fail_msg='nope')))
        ]
    )
    variable_manager = VariableManager(loader=None)
    inventory = InventoryManager(loader=None, sources='localhost')

    tqm = None

# Generated at 2022-06-21 01:48:20.776022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionBase(ActionBase):
        def run(self, tmp, task_vars):
            return self._task.args['_ansible_temp_result']

    class MockConditional(object):
        def __init__(self, loader):
            self.when = []

        def evaluate_conditional(self, templar, all_vars):
            return self.when[0]

    class MockTemplar(object):
        def __init__(self):
            pass

    class MockLoader(object):
        def __init__(self):
            pass

    # Test with success_msg and fail_msg string arguments
    action_result = dict(failed=False, msg='Task OK')

# Generated at 2022-06-21 01:48:29.445156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionBase_MOCK:
        class _task_MOCK:
            args = {'fail_msg': [], 'that': []}

        def __init__(self):
            self._task = self._task_MOCK()

    class Conditional_MOCK:
        class _loader_MOCK:
            pass

        def __init__(self, loader):
            self._loader = self._loader_MOCK()
            assert loader == self._loader

        def evaluate_conditional(self, templar, all_vars):
            return False

    actionBase = ActionBase_MOCK()
    actionModule = ActionModule(task=actionBase._task, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 01:48:39.754826
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:48:45.032456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == '''' Fail with custom message '''
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:48:50.503104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 01:48:59.703532
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:49:10.057739
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:49:49.384508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest, sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 01:49:54.733660
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:50:02.298366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.context import context
    from ansible.template import Templar
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Jinja2
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli.arguments import OptionParser

    context.CLIARGS = OptionParser(["--connection=local"]).parse_args()
    # test default values

# Generated at 2022-06-21 01:50:11.555798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'ansible_version': "2.6.0",
        'ansible_python_version': "3.6.2",
        'ansible_user_dir': "/home/vagrant/.ansible",
    }
    variable_manager.options_vars = {'default_vars': {'x': 'y'}}
    variable_manager.set_inventory(Inventory(loader))

    connection = Connection()
    play_context = PlayContext()


# Generated at 2022-06-21 01:50:12.306066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None)

# Generated at 2022-06-21 01:50:25.314939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.role.include
    import ansible.executor.task_queue_manager
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars.manager

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 01:50:35.436091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    host1 = 'host1'
    host2 = 'host2'
    task = Task()
    role = Role()
    block = Block()
    am1 = ActionModule(task, host1, {}, [], False, False, False, loader=None, templar=None, shared_loader_obj=None)
    am2 = ActionModule(task, host2, {}, [], False, False, False, loader=None, templar=None, shared_loader_obj=None)
    am3 = ActionModule(task, host1, {}, [], False, False, False, loader=None, templar=None, shared_loader_obj=None)
    assert am1

# Generated at 2022-06-21 01:50:45.273286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import task

    t = task.Task()
    t.action = 'fail'

    m = ActionModule(t, {})
    assert isinstance(m, ActionModule)

    try:
        m._execute_module(tmp=None, task_vars={})
    except AnsibleError as e:
        # FIXME: insert a better error message here
        if 'conditional required in "that" string' in str(e):
            assert True
        else:
            assert False, "Did not raise AnsibleError(conditional required in 'that' string)"
    else:
        assert False, "Did not raise AnsibleError(conditional required in 'that' string)"

    t.args['that'] = '{{ 1 == 1 }}'
    m = ActionModule(t, {})


# Generated at 2022-06-21 01:50:56.774157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with 'that' keyword and string as expression
    test_args = {'that': "ansible_eth0.ipv4.address.find('{{ myip }}') == 0"}
    am = ActionModule(None, test_args, None, None)

    test_task_vars = {"myip": "192.168.1.1"}
    res = am.run(None, test_task_vars)

    assert res == {
        "changed": False,
        "evaluated_to": True,
        "msg": "All assertions passed"
    }

    # Test with 'that' keyword and a list of strings as expression

# Generated at 2022-06-21 01:51:03.042921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test
    action = ActionModule({}, {}, {},{}, {})

    # run test
    result = action.run()

    # assert test
    assert result == {'failed': True, 'msg': 'Assertion failed'}


# Generated at 2022-06-21 01:52:27.239159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert isinstance(ActionModule(Task(), dict(module_name='module_name')), ActionModule)

# Generated at 2022-06-21 01:52:39.233978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test conditions
    fail_msg = "this is fail message"
    success_msg = "this is success message"
    # test with fail_msg declared and success_msg absent in task args
    test_args = {'that': '1', 'fail_msg': fail_msg}
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['changed'] == False
    assert result['failed'] == False
    assert result['msg'] == success_msg

    # test with msg alias for fail_msg
    test_args = {'that': '1', 'msg': fail_msg}
    action_module = Action

# Generated at 2022-06-21 01:52:46.383095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test_ActionModule_run is the unit test for method run of class ActionModule'''
    # You can do more tests using the asserts provided by python unittest module
    # You can also use tbot's asserts:
    #   tbot.assert_equals(a, b)
    #   tbot.assert_true(x)
    #   tbot.assert_false(x)
    from tbot.machine import board, channel, connector
    from ansible.plugins.action import ActionModule
    from unittest.mock import Mock
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO


    b = board.Connector(connector.ParamikoConnector)
    c = channel.Channel(b)


# Generated at 2022-06-21 01:52:56.585568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Empty play_context, task_include and task_queue_manager
    tqm = TaskQueueManager()
    pcontext = PlayContext()
    tqm._unreachable_hosts = {}
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.port = 22
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'u1'
    play_context.password = 'pass'
    play_context.become = None
    play_context.become_method = 'enable'
    play

# Generated at 2022-06-21 01:53:05.825190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    action_plugin/fail_unit.py
    This is the unit test for ansible.plugins.action.fail.ActionModule class
    """

    module = ActionModule({})  # noqa
    assert module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    try:
        module.run()
        assert False
    except AnsibleError as e:
        assert 'conditional required in "that" string' in str(e)

    try:
        module.run(task_vars={'foo': 'bar'})
        assert False
    except AnsibleError as e:
        assert 'conditional required in "that" string' in str(e)


# Generated at 2022-06-21 01:53:16.541235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        def __init__(self, args):
            self.args = args

    with pytest.raises(AnsibleError) as excinfo:
        assert_that = ActionModule({'setup_cache': 'test'}, Task({}))
    assert excinfo.value.message == 'conditional required in "that" string'

    with pytest.raises(AnsibleError) as excinfo:
        assert_that = ActionModule({'setup_cache': 'test'}, Task({'that': 1}))
    assert excinfo.value.message == 'conditional required in "that" string'


# Generated at 2022-06-21 01:53:26.193897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    def load_plugins():
        return None
    def load_module_utils():
        return None

    def get_task(**kwargs):
        args = {
            'name': 'test',
            'action': 'test_module',
            'args': {},
            'module_args': {},
        }
        args.update(kwargs)
        return Task.load(args, loader=loader, task_loader=loader, play=play, variable_manager=variable_manager)


# Generated at 2022-06-21 01:53:36.603019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'testhost'
    task_vars = {
        'ansible_hostname': hostname
    }
    task_vars_in = task_vars.copy()
    task_vars_in.update({
        'ansible_facts': {
            'testfactkey': 'testfactval',
            'testfactkey2': 'testfactval2',
            'testfactkey3': 'testfactval3',
        }
    })
    tmp = 'testfile'
    assert(None is not tmp)
    args = {
        'that': ['{{ansible_facts.testfactkey}} == testfactval', '{{ansible_facts.testfactkey2}} == testfactval2',
                 '{{ansible_facts.testfactkey3}} == testfactval3'],
    }
   

# Generated at 2022-06-21 01:53:45.491286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_native
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print('run')
            return super(TestActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-21 01:53:50.018109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an object of class ActionModule
    a = ActionModule(None, None)

    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))