

# Generated at 2022-06-21 01:45:17.969818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule(None, task_vars=None)
    #
    assert isinstance(instance.TRANSFERS_FILES, bool)
    assert isinstance(instance._VALID_ARGS, frozenset)

# Generated at 2022-06-21 01:45:22.159634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert c is not None


# Generated at 2022-06-21 01:45:30.555039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = module_loader._find_plugin("fail")
    variable_manager = VariableManager()
    variable_manager._extra_vars = {u'inventory_hostname': u'jumper.novalocal'}
    variable_manager.set_inventory(None)
    variable_manager._vars_cache = {u'inventory_hostname': u'jumper.novalocal'}
    variable_manager.set_host_variable('jumper.novalocal', 'ansible_connection', 'local')
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-21 01:45:31.998964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No such test"

# Generated at 2022-06-21 01:45:37.042032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader=None
    variable_manager=None
    action=None
    task=None
    task_vars=None
    templar=None
    action=ActionModule(loader=loader, variable_manager=variable_manager, task=task, task_vars=task_vars, templar=templar)

    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:45:39.288094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor.
    test_action_module = ActionModule()


# Generated at 2022-06-21 01:45:40.182333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 01:45:40.821700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 01:45:44.995435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor without arguments
    empty_action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert empty_action is not None

# Generated at 2022-06-21 01:45:53.548062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock vars
    task_vars = dict()
    result = dict()

    # Initialize action
    action = ActionModule( {}, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    action._task = MockTask()

    # Run 'run' method and test results
    result = action.run(dict(), task_vars=task_vars)
    assert result == {'failed': True, 'evaluated_to': False, 'assertion': 'mycond'}

    # Initialize action
    action = ActionModule( {'msg':'TESTMSG'}, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    action._task = MockTask()

    # Run 'run'

# Generated at 2022-06-21 01:46:10.394791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    # Mock class for Templar
    class DummyTemplar:
        '''Dummy class for Templar'''
        def __init__(self):
            self.vars = dict()

    # Create dummy instance of class ActionModule
    action_module = ActionModule()
    action_module._loader = DummyTemplar()
    action_module._templar = DummyTemplar()

    # Create dummy arguments for task
    action_module._task.args = dict()

    # fail_msg not present in task.args
    try:
        result = action_module.run()
    except Exception as err:
        print('Caught exception when fail_msg is not present: %s (%s)' % (err, type(err)))

# Generated at 2022-06-21 01:46:19.782439
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_action = ActionModule()

    class TestTask():
        def __init__(self):
            self.args = []

    # Test 1:
    test_task = TestTask()
    test_task.args['msg'] = 'Assertion failed'
    test_action.run( {}, {'foo': 0 } )
    assert test_action.fail_json()['msg'] == 'Assertion failed'

    # Test 1.5:
    test_task = TestTask()
    test_task.args['msg'] = ['Assertion is', 'failed']
    test_action.run( {}, {'foo': 0 } )
    assert test_action.fail_json()['msg'] == ['Assertion is', 'failed']

    # Test 2:
    test_task = TestTask()

# Generated at 2022-06-21 01:46:25.963450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import os
    import tempfile

    my_vars = {'a1': True, 'a2': False}
    my_task = {'when': 'a1', 'args': {'fail_msg': 'Assertion failed', 'msg': 'Assertion failed'}}
    my_task_1 = {'when': 'a2', 'args': {'msg': 'Assertion failed'}}
    my_task_2 = {'when': 'a2', 'args': {'fail_msg': 'Assertion failed'}}
    my_task_3 = {'when': 'a2', 'args': {'fail_msg': 'Assertion failed', 'quiet': True}}

# Generated at 2022-06-21 01:46:38.445738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test class construction'''

    class AnsibleModule:
        ''' Fake AnsibleModule creation '''
        def __init__(self, *args, **kwargs):
            pass

    class ActionBase1:
        ''' Fake ActionBase creation '''
        def __init__(self, *args, **kwargs):
            self._task = {'args': {'fail_msg': 'fail', 'that': ['not foo.bar']}}

    class Conditional1:
        ''' Fake Conditional creation '''
        def __init__(self, *args, **kwargs):
            pass

    class FailModule(ActionModule):
        ''' Test class creation '''
        def __init__(self, *args, **kwargs):
            super(FailModule, self).__init__(*args, **kwargs)

        #

# Generated at 2022-06-21 01:46:50.096923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert1 = True
    assert2 = False
    assert3 = False

    action_module = ActionModule()
    result = action_module.run(tmp=None, task_vars=dict(assert1 = assert1, assert2 = assert2, assert3 = assert3))

    # All assert statements must be true for the test to pass
    assert result['failed'] == assert3
    assert result['evaluated_to'] == assert3
    assert result['assertion'] == 'assert3'
    assert result['changed'] == False
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == 'assert3'

    # test: fail_msg
    action_module = ActionModule(task=dict(args=dict(fail_msg="Failed")))

# Generated at 2022-06-21 01:47:02.391659
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:47:08.413454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up arguments
    arg_dict = {'msg': 'Assertion failed',
                'quiet': 'false',
                'that': 'item == "value"'}
    action_module = ActionModule(None, arg_dict, None, None)
    assert action_module._task.args['msg'] == 'Assertion failed', "Assert msg argument failed"
    assert action_module._task.args['quiet'] == 'false', "Assert quiet argument failed"
    assert action_module._task.args['that'] == 'item == "value"', "Assert that argument failed"


# Generated at 2022-06-21 01:47:20.794467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ansible.plugins.action.assert_module.ActionModule
    assert_module = ActionModule(
    )
    assert_module._play_context = {
        'become': None,
        'become_user': None,
        'connection': 'local',
        'diff': True,
        'forks': 5,
        'inventory': None,
        'tags': [],
        'remote_user': None,
        'remote_addr': False,
        'module_path': None,
        'private_data_dir': None,
        'verbosity': 0,
        'timeout': 10,
        'check': False,
        'only_tags': None,
        'skip_tags': None,
        'diff': True,
    }
    assert_module._task = None
    assert_module._templar

# Generated at 2022-06-21 01:47:29.989580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor with dummy data
    data = 'this is some dummy data'
    fake_loader = 'this is some fake loader'
    fake_task = 'this is some fake task'
    fake_play_context = 'this is a fake play conext'
    my_action_module = ActionModule(data, fake_loader, fake_task, fake_play_context)
    assert my_action_module.data == data
    assert my_action_module._loader == fake_loader
    assert my_action_module._task == fake_task
    assert my_action_module._play_context == fake_play_context

# Generated at 2022-06-21 01:47:42.309585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    class MockTaskQueueManager(TaskQueueManager):
        def __init__(self, *args, **kwargs):
            super(MockTaskQueueManager, self).__init__(*args, **kwargs)

        def _initialize_processes(self, num):
            pass

        def _cleanup_processes(self):
            pass

        def _queue_task(self, host, task, task_vars, play_context):
            pass



# Generated at 2022-06-21 01:48:00.841316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = {"name": "test", "args": {"test": "test"}}
    if not isinstance(ActionModule(action, None, None), ActionModule):
        fail("Cannot create ActionModule")

# Generated at 2022-06-21 01:48:02.568891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 01:48:08.220553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    old_exists = 'exists' in dir(builtins)
    if old_exists:
        old_exists_func = builtins.exists

# Generated at 2022-06-21 01:48:10.868518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test for method run of class ActionModule
    pass


# Generated at 2022-06-21 01:48:13.015840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.__class__.__name__ == 'ActionModule'
    assert a.__class__.__bases__[0].__name__ == 'ActionBase'

# Generated at 2022-06-21 01:48:16.238304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        x = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except:
        assert False
    assert True

# Generated at 2022-06-21 01:48:28.531826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test ActionModule without fail_msg
    am = ActionModule(task=dict(args=dict(that='foo bar', msg='My Message')),
                      play_context=dict(check_mode=False), loader=None,
                      templar=None, shared_loader_obj=None)
    assert am.run() == {'failed': True, 'msg': 'My Message', 'assertion': 'foo bar', 'evaluated_to': False}

    # test ActionModule with quiet=yes
    am = ActionModule(task=dict(args=dict(that='foo bar', msg='My Message', quiet=True)),
                      play_context=dict(check_mode=False), loader=None,
                      templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:48:32.030630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule with default argument
    test_instance = ActionModule()

    # Assert that the attribute TRANSFERS_FILES is of type bool
    assert isinstance(test_instance.TRANSFERS_FILES, bool)

    # Assert that the attribute _VALID_ARGS is of type frozenset
    assert isinstance(test_instance._VALID_ARGS, frozenset)


# Generated at 2022-06-21 01:48:40.634096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(loader=None, connection=None, play_context=None)
    task = {'args': {'that': ['1 > 2 | bool', '1 == 1 | bool'], 'msg': 'Assertion failed', 'success_msg': 'All assertions passed', 'quiet': True}}
    result = a.run(task_vars=None, task=task)
    assert result.get('msg') == 'All assertions passed'
    assert result.get('changed') == False
    assert result.get('failed') == False

    task = {'args': {'that': ['1 > 2 | bool', '1 == 1 | bool'], 'fail_msg': 'Assertion 1 failed', 'success_msg': 'All assertions passed', 'quiet': True}}

# Generated at 2022-06-21 01:48:49.254199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import tempfile

    ansible_loader = os.path.join(os.path.dirname(sys.executable), 'lib/python2.7/site-packages/ansible/cli/playbook.py')
    tmpdir = tempfile.mkdtemp(prefix='ansible_test_action_assert_')
    success_msg = 'success'
    fail_msg = 'fail'

# Generated at 2022-06-21 01:49:30.270584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = {'ansible_all_ipv4_addresses': ['192.168.0.1']}
    taskvars = {'hostvars': {'hostname': hostvars}}
    tmp = None
    action_module = ActionModule(None, None, None, None, {'that': 'ansible_all_ipv4_addresses | length == 1', 'quiet': 'True'}, tmp, taskvars)
    assert isinstance(action_module, ActionModule)
    task = action_module._task
    assert isinstance(task, dict)
    loader = action_module._loader
    assert isinstance(loader, object)
    templar = action_module._templar
    assert isinstance(templar, object)
    play_context = action_module._play_context

# Generated at 2022-06-21 01:49:31.135995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:49:41.428509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def execute_mock(self,tmp=None,task_vars=None):
        return 'Executed mock!'
    def run_mock(self,tmp=None,task_vars=None):
        return 'Ran mock!'

    class HostMock:
        def __init__(self):
            self.name='mock_hostname'
    hostmock = HostMock()

    action_module = ActionModule(task=dict(),connection='local')
    action_module.execute=execute_mock
    action_module.run=run_mock
    action_module.play_context=dict()

    action_module.host=hostmock


# Generated at 2022-06-21 01:49:51.565844
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:49:52.365690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:50:01.521017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ###################################################################################################################
    # Test for error scenarios
    ###################################################################################################################
    # Test for error case when "that" not present in task args
    ###################################################################################################################
    am = ActionModule(loader=None, task=None, connection=None)
    am._task.args = {}
    am._loader = None
    am._templar = None
    try:
        am.run()
        raise Exception('run with no "that" returned no exception')
    except AnsibleError as e:
        assert "Assertion failed" in str(e)
    except Exception as e:
        raise Exception('Unexpected exception occurred %s %s' % (type(e), str(e)))
    ###################################################################################################################

    ###################################################################################################################
    # Test for error case when "that" contains non string

# Generated at 2022-06-21 01:50:07.574904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert type(am.get_valid_args()) is frozenset
    #assert am.get_valid_args() == ('fail_msg', 'msg', 'quiet', 'success_msg', 'that')
    # assert am.get_valid_args() == ('fail_msg', 'msg', 'quiet', 'success_msg', 'that')

# Generated at 2022-06-21 01:50:09.059547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-21 01:50:15.770190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'msg': 'failure', 'success_msg': 'success', 'that': ['a', 'b'], 'quiet': True}
    fm = ActionModule(None, None, None, None, None)
    fm.set_task_args(args)
    # These are the cases where action module returns failures
    cases = (
        {'action': 'fail', 'task_vars': {'a': False, 'b': False}, 'expected_result': {'failed': True}},
        {'action': 'fail', 'task_vars': {'a': False, 'b': True}, 'expected_result': {'failed': True}},
        {'action': 'fail', 'task_vars': {'a': True, 'b': False}, 'expected_result': {'failed': True}},
    )

# Generated at 2022-06-21 01:50:24.137315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate class
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._task.args == {}
    #assert am._templar == None

    # Instantiate class, same as above
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, action_plugins=None)
    assert am._task.args == {}
    #assert am._templar == None

# Generated at 2022-06-21 01:51:49.083439
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.utils.template
    import ansible.vars.hostvars
    import os
    import sys

    from ansible.module_utils.six import StringIO

    # Create a safe environment for testing
    saved_environ = os.environ.copy()
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

    os.environ.clear()

# Generated at 2022-06-21 01:51:59.385697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ##########################################################################
    # Tests of that 'evaluated_to' key in dict returned by method run
    ##########################################################################

    # Test 1:
    #   that = 'true == false'
    #   fail_msg = 'that assertion failed'
    #   success_msg = 'that assertion passed'
    #
    # Expected:
    #   {
    #       "assertion": "true == false",
    #       "evaluated_to": false,
    #       "failed": true,
    #       "msg": "that assertion failed"
    #   }
    task = dict(
        action=dict(),
        args=dict(
            fail_msg='that assertion failed',
            success_msg='that assertion passed',
            that='true == false'
        )
    )

# Generated at 2022-06-21 01:52:09.747231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task

    loader_mock = mock.MagicMock()
    tmp_mock = mock.MagicMock()
    task_vars_mock = {}
    mock_config = mock.MagicMock()
    action_base_instance = ansible.plugins.action.ActionBase(task_mock, connection_mock, tmp_mock, task_vars_mock, loader_mock, mock_config)
    action_base_instance.run = mock.Mock()
    action_base_instance._templar = mock.MagicMock()

    args = {}
    action_module_instance = ansible.plugins.action.ActionModule(task_mock, connection_mock, tmp_mock, task_vars_mock, loader_mock, mock_config)
    action

# Generated at 2022-06-21 01:52:16.274187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, final_q=None, passwords=None)
    assert isinstance(mod._VALID_ARGS, frozenset)
    assert 'fail_msg' in mod._VALID_ARGS
    assert 'msg' in mod._VALID_ARGS
    assert 'quiet' in mod._VALID_ARGS
    assert 'success_msg' in mod._VALID_ARGS
    assert 'that' in mod._VALID_ARGS

# Generated at 2022-06-21 01:52:16.899432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    assert ActionModule

# Generated at 2022-06-21 01:52:28.177455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check correct parametrization
    am = ActionModule(dict(a='b'), dict(ANSIBLE_MODULE_ARGS=dict(
        fail_msg='hello',
        success_msg='goodbye',
        quiet=True,
        that='c',
    )))

    # Check that '_play_context' was correctly passed as parameter
    assert am._play_context.a == 'b'

    # Check that 'fail_msg' was correctly parametrized
    assert am._task.args['fail_msg'] == 'hello'

    # Check that 'success_msg' was correctly parametrized
    assert am._task.args['success_msg'] == 'goodbye'

    # Check that 'quiet' was correctly parametrized
    assert am._task.args['quiet'] is True

    # Check that 'that' was

# Generated at 2022-06-21 01:52:39.753974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible.plugins.action import ActionModule
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    P = Playbook()
    a = ActionModule(
        {'name': 'test', 'action': 'assert', 'when': 'action_fail==true', 'args': {'that': 'a==1', 'fail_msg': 'a should be equal to 1'}},
        load_list=[],
        task_action=dict(),
        connection='local',
        play_context=PlayContext(),
        loader=ansible.loader.DictDataLoader(),
        templar=ansible.template.Templar(),
        shared_loader_obj=ansible.loader.DictDataLoader,
    )

# Generated at 2022-06-21 01:52:45.934493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    yaml_dict = dict(
        fail_msg = "fail_msg",
        success_msg = "success_msg",
        quiet = True,
        that = "1",
    )

    task = Task()
    task._role = None
    task.args = yaml_dict

    action_module = ActionModule(task, dict())
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    assert action_module.TRANSFERS_FILES == False
    assert action_module.run() == False


# Generated at 2022-06-21 01:52:56.527343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("Running Unit Test for class: ActionModule")


# Generated at 2022-06-21 01:52:59.029423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(None, None)
    assert isinstance(test_module, ActionModule)