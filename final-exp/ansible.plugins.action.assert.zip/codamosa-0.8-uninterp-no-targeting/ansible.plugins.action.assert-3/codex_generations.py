

# Generated at 2022-06-21 01:45:13.527540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 01:45:18.880584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert not module.TRANSFERS_FILES

# Generated at 2022-06-21 01:45:23.709815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Testing with wrong value of fail_msg, msg
    # Testing with wrong type of fail_msg, msg
    # Testing with wrong type of success_msg
    # Testing with wrong type of 'that'

# Generated at 2022-06-21 01:45:31.131921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    "Test that ActionModule.run() works as expected"

    import pytest

    # Set up test
    class MockActionModule(ActionModule):
        _task = None
        _loader = None
        _templar = None
        _VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

        def __init__(self):
            self._task = mock_task
            self._loader = mock_loader
            self._templar = mock_templar
            self.connection = "local"

    def test_conditional(self, templar, all_vars):
        return Conditional(loader=self._loader).evaluate_conditional(templar, all_vars)

    class MockConditional(Conditional):
        _loader = None

       

# Generated at 2022-06-21 01:45:38.456872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mocks
    action_module = 'action_module'
    fail_msg = 'fail msg'
    success_msg = 'success msg'
    result = 'result'
    a_result = 'a result'
    tmp = 'tmp'
    task_vars = 'task vars'
    fail = 'fail'
    fail_msg = 'fail msg'
    success_msg = 'success msg'
    quiet = False
    a_result = 'a result'
    that = 'that'
    a_boolean = 'a boolean'
    a_boolean_result = 'a boolean result'
    test_result = 'test result'
    cond = 'cond'
    loader = 'loader'
    templar = 'templar'
    all_vars = 'all vars'

    # set default k

# Generated at 2022-06-21 01:45:39.200162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:45:42.261692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=dict(action=dict()), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule is not None

# Generated at 2022-06-21 01:45:53.616340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    task_vars_dict = dict()
    test_result = dict()
    test_result['failed'] = False

    am = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, strategy=None)

    result = am.run(task_vars=task_vars_dict)
    assert result == test_result
    # Sample tests
    #def test_mymethod_from_sample_file(self):
    #    # Prepare test objects
    #    task = Task()
    #    am = ActionModule(loader=None, task=task, connection=None, play_context=None, shared_loader_obj=None, variable_manager=None)
    #
    #    # Run method with test object
   

# Generated at 2022-06-21 01:45:58.698550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    loader.set_basedir(".")
    task = Task()
    task._role = None
    action = ActionModule(task=task, connection=None, play_context=play_context, loader=loader, templar=None, shared_loader_obj=None)

    assert action.run() is not None

# Generated at 2022-06-21 01:45:59.628586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:46:18.893136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    host_list = [Host('localhost')]
    inventory.add_group(hosts=host_list)
    variable_manager.set_inventory(inventory)

    task = Task()
    task._role = None
    task.args = {'that': '"foo" == "foo"'}


# Generated at 2022-06-21 01:46:25.161484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task 
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os.path
    import sys


# Generated at 2022-06-21 01:46:37.466891
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:46:41.832090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if a ActionModule object can be constructed from a valid data
    data = {}
    obj = ActionModule(data=data)
    assert(isinstance(obj, ActionModule))


# Generated at 2022-06-21 01:46:51.459819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock module and AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={
        'fail_msg': {'type': 'str'},
        'msg': {'type': 'str'},
        'quiet': {'type': 'bool', 'default': False, 'required': False},
        'success_msg': {'type': 'str'},
        'that': {'type': 'list'}
    })

# Generated at 2022-06-21 01:47:02.769787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    module = ActionModule()
    module._task = None
    module._ds = None
    module._loader = None
    tmp = None
    task_vars = None

    # Test execution of method run with fail_msg, success_msg, quiet, task_vars
    module._task = None
    module._ds = None
    module._loader = None
    tmp = None
    task_vars = {
        'test_var': 'test_value'
    }

    # Test execution with string type for fail_msg, success_msg and quiet
    module._task = {}
    module._task.args = {}
    module._task.args['fail_msg'] = 'test_fail_msg'

# Generated at 2022-06-21 01:47:12.742334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for the constructor of class ActionModule.
    """
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    fact_collector = DistributionFactCollector()
    host = Host(name="test_fail")
    host.set_variable('ansible_distribution', fact_collector.get_facts(host)['ansible_facts']['ansible_distribution'])

# Generated at 2022-06-21 01:47:25.002533
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  #1. If fail_msg or msg is not a string, it should throw an error
  args = {}
  args["fail_msg"] = "String"
  args["msg"] = 'String'
  args["quiet"] = False
  args["success_msg"] = "String"
  args["that"] = "String"
  am.set_task(args)
  try:
    am.run()
  except AnsibleError as ex:
    assert False, "test_ActionModule #1: " + ex.message
  else:
    assert True, "test_ActionModule #1: No error thrown"

  #2. If fail_msg or msg is a list, but any of its elements is not a string, it should throw an error
  args = {}

# Generated at 2022-06-21 01:47:31.873111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.loader import action_loader

    my_vars = {"a":{"a1":"{{y1}}","a2":"{{y2}}"},
             "x1":"check","x2":"check","x3":"nocheck",
             "y1":"check","y2":"check","y3":"nocheck",
             "z1":"check","z2":"nocheck","z3":"nocheck"}

    action = action_loader.get('assert', class_only=True)
    login = {'login_user': 'user', 'login_password': 'pass'}
    tmp = '/tmp'
    play_context = {'remote_user': 'user'}
    my_connection = 'ssh'

    # run1 : fail_msg, msg, that

# Generated at 2022-06-21 01:47:39.365400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiating the class will fail, because the conditional module
    # is not available.
    try:
        new_ActionModule = ActionModule(task='main', connection='local', play_context={}, loader=None, templar=None, shared_loader_obj=None)
    except:
        pass
    else:
        raise RuntimeError('ActionModule instantiation should fail without the conditional module')

# Generated at 2022-06-21 01:47:54.901795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    __action_module = ActionModule()
    assert isinstance(__action_module, ActionModule) is True

# Generated at 2022-06-21 01:48:01.690975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {
        'test1': 'test1',
        'test2': ['test2'],
        'test3': {'test3': ['test3']},
    }
    module_args = {
        'that': '{{test2}} == test2',
        'msg': '{{test1}} != test1',
        'success_msg': '{{test1}} == test1',
    }
    task_vars = {
        'hostvars': hostvars
    }
    action = ActionModule(module_args)
    action.run(task_vars=task_vars)
    assert action._task.result['msg'] == 'test1 == test1'


# Generated at 2022-06-21 01:48:10.249419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialise mock object
    action_module = ActionModule()

    # Method test: 'that' is not present
    task_vars = dict()
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == True
    assert 'that' in result['msg']

    # Method test: 'that' is present but not a list
    task_vars = dict()
    action_module._task.args['that'] = 'True'
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False
    assert 'All assertions passed' in result['msg']

    # Method test: 'that' is present but not a list
    task_vars = dict()
    action_module._task.args['that'] = 'False'


# Generated at 2022-06-21 01:48:20.893948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    action = action_loader.get('assert', class_only=True)
    action_result = action.run(
        tmp={},
        task_vars={
            'a': ['a1', 'a2'],
            'v': 'this is a value',
            'd': {'k1': 'v1', 'k2': True, 'k3': 3},
            'l': [{'lv1': 1, 'lv2': 'a'}, {'lv1': 2, 'lv2': 'b'}],
        },
        that='v == "this is a value"',
    )
    assert not action_result['failed'], 'Test case failed, should have passed'

# Generated at 2022-06-21 01:48:21.374592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1==1

# Generated at 2022-06-21 01:48:23.900457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:48:31.100961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _module_mock(module_name=None, *args, **kwargs):
        if module_name:
            return {'_ansible_module_name': module_name}
        else:
            return None

    assert _module_mock() is None
    task = {'name': 'some_task_name', 'action': 'include', 'args': {'that': 'some_variable', 'msg': 'some_message'}}
    module = ActionModule(task, _module_mock(), True, '/some/path', '/some/tmp')
    assert module._play_context.remote_addr == '127.0.0.1'
    assert module._play_context.connection == 'local'
    assert module._play_context.remote_user == 'root'
    assert module._play_context.become is False


# Generated at 2022-06-21 01:48:40.405317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct a mock loader object
    mock_loader = MockLoader({
        u'assert_defaults': {
            u'action': u'assert',
            },
        })
    # Construct a mock datastructure as object
    mock_ds = {
        u'fail_msg': u'Assertion failed',
        u'msg': u'Assertion failed',
        u'quiet': False,
        u'success_msg': u'All assertions passed',
        u'that': u'2 > 3',
        }
    # Construct a mock task object
    mock_task = MockTask(mock_ds)
    mock_task.action = u'assert'

    # Construct a mock templar object

# Generated at 2022-06-21 01:48:42.502402
# Unit test for constructor of class ActionModule
def test_ActionModule():
	a=ActionModule()
	assert isinstance(a,ActionBase)

# Generated at 2022-06-21 01:48:43.888410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 01:49:22.542582
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:49:32.611254
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Set up required fixture for method validate of class Conditional
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=[])
    play_context = PlayContext()

    # Set up required fixture for method run of class ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 01:49:33.944802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 01:49:46.289505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 1
    # no that specified, raise ansibleerror
    task_args = {}

    tmp = True
    task_vars = {}

    action_module = ActionModule(load_plugins=True, task=None, connection=None,
                                 play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test case 2
    # success_msg passed is not a list or string, raise ansibleerror
    task_args = {'that': 'a', 'success_msg': 2}

    tmp = True
    task_vars = {}

    action_module = ActionModule(load_plugins=True, task=None, connection=None,
                                 play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test case 3

# Generated at 2022-06-21 01:49:59.262760
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:50:00.613822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 01:50:01.481061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:50:03.653445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(task=dict()), ActionModule)

# Generated at 2022-06-21 01:50:05.129729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 01:50:12.126447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(args=dict(msg='FAIL')),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    with pytest.raises(AnsibleError) as err_info:
        result = action_module.run(tmp=None, task_vars=dict())
    assert err_info.value.message == 'conditional required in "that" string'
    cond = 'error'
    task_vars = dict(ansible_ssh_user='root', ansible_ssh_pass='password', ansible_check_mode=True)

# Generated at 2022-06-21 01:51:27.747902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleModuleStub(object):
        _task = object()
    class TaskStub(object):
        args = {'that': '1'}
    class AnsibleLoaderStub(object):
        pass
    class AnsibleTemplarStub(object):
        pass
    class AnsibleTaskConditionalStub(object):
        pass

    stub_module = AnsibleModuleStub()
    stub_task = TaskStub()

    action_module = ActionModule(stub_module, stub_task)

    assert action_module._task is stub_task
    assert action_module._loader is stub_module._loader
    assert action_module._templar is stub_module._templar

# Generated at 2022-06-21 01:51:36.947532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    
    module = ActionModule(
            task=None,
            connection=None,
            play_context=PlayContext(),
            loader=None,
            templar=None,
            shared_loader_obj=None)
    assert module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert module.TRANSFERS_FILES == False


# Generated at 2022-06-21 01:51:40.474201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {}
    assert action_module.run()

# Generated at 2022-06-21 01:51:41.801997
# Unit test for constructor of class ActionModule
def test_ActionModule():
  actionModule = ActionModule()
  
  return

# Generated at 2022-06-21 01:51:42.663103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    assert True

# Generated at 2022-06-21 01:51:46.916757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import yaml

    task = yaml.load("""
    - name: test_that
      fail:
        msg: "Assertion failed"
      when: 1 == 2
      """)

    # task_results = backend.run(task, task_vars=dict(ansible_user='admin', ansible_ssh_pass='password'))
    print(task)

# Generated at 2022-06-21 01:51:58.954354
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import copy
    import json
    import six
    import yaml


# Generated at 2022-06-21 01:52:00.985680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a

# Generated at 2022-06-21 01:52:11.643487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(loader=None,
                          templar=None,
                          shared_loader_obj=None)

    # Test 1. Success_msg is string
    task = {'args': {'that': '1', 'msg': 'msg', 'fail_msg': 'fail msg', 'quiet': 'True', 'success_msg': 'success_msg'}}
    result = {}
    try:
        action.run(task_vars=None, task=task, tmp=None, result=result)
    except Exception as e:
        print(e)
        assert 0
    else:
        assert result['msg'] == 'success_msg'
        assert result['failed'] == False
        assert result['changed'] == False

    # Test 2. Success_msg is list

# Generated at 2022-06-21 01:52:19.516543
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host

# Generated at 2022-06-21 01:54:49.116463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

# Generated at 2022-06-21 01:54:56.116983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # case 1
    try:
        action_module.run()
    except:
        pass
    else:
        assert False, "action module run failed to raise error"
    # case 2
    action_module.run(task_vars=dict(that=list('ab')))
    # case 3
    action_module.run(task_vars=dict(that=dict(a=1)))
    # case 4
    action_module.run(task_vars=dict(that=None))
    # case 5

# Generated at 2022-06-21 01:55:08.060154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test playbook and action plugin (ActionModule)
    # Add the action plugin to the test playbook
    # Remove the fail_msg and msg values from the test playbook
    # Test ActionModule._task.args
    # Test ActionModule.run method
    # Use fail_msg as msg
    # Use a list as fail_msg and msg
    # Test options with incorrect data type
    # Set quiet to True
    # Set quiet to False
    # Test that
    test_playbook = {'hosts': 'localhost', 'tasks': [{'action': {'module': 'assert', 'args': {'msg': None, 'that': True}}}]}
    test_action_plugin = ActionModule()

    test_playbook['tasks'][0]['action']['module'] = test_action_plugin.__class__.__name__
