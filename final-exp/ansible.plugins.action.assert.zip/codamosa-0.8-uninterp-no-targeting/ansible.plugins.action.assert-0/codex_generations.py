

# Generated at 2022-06-21 01:45:17.852034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 01:45:24.818000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test start")
    am = ActionModule()
    am.ActionModule()

    #test for msg
    print("test if msg is string")
    am._task.args['msg'] = 'abc'
    assert am.run()['msg'] == 'abc'

    print("test if msg is list")
    am._task.args['msg'] = ['a', 'b']
    assert am.run()['msg'] == ['a', 'b']

    #test for fail_msg
    print("test if fail_msg is string")
    am._task.args['fail_msg'] = 'abc'
    assert am.run()['msg'] == 'abc'

    print("test if fail_msg is list")
    am._task.args['fail_msg'] = ['a', 'b']
    assert am.run()['msg']

# Generated at 2022-06-21 01:45:32.146301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of the class 'ActionModule' """
    from ansible.plugins.action import ActionBase

    # create the instance of class ActionModule
    action_module = ActionModule(
        task=dict(
            action=dict(
                module_name='assert',
                module_args=dict(
                    fail_msg="Test fail_msg"
                )
            )
        )
    )

    # call the function 'run'
    result = action_module.run(task_vars=dict())

    # get the variable 'result' from this instance of class ActionModule
    result_from_action_module = action_module.result

    # check the result that we got from this instance of class ActionModule
    if isinstance(action_module, ActionBase):
        assert isinstance(result_from_action_module, dict)

# Generated at 2022-06-21 01:45:38.843328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Mock test to check class constructor """
    mock_result = dict(
        failed=False,
        msg='mock result msg'
    )

    mock_action_module = ActionModule(
        task=dict(action=dict(module_name='fail', module_args={'msg': 'mock result msg'})),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(
        )
    )

    mock_action_module.run = lambda: mock_result

    assert mock_action_module.run() == mock_result
    assert mock_action_module.task == dict(action=dict(module_name='fail', module_args={'msg': 'mock result msg'}))
    assert mock_action_module.connection

# Generated at 2022-06-21 01:45:42.409942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    module = ActionModule()

    # Act
    is_instance = isinstance(module, ActionModule)

    # Assert
    assert is_instance == True

# Generated at 2022-06-21 01:45:46.724643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, dict())
    assert hasattr(a, '_VALID_ARGS')
    assert a._VALID_ARGS == frozenset(['fail_msg', 'msg', 'quiet', 'success_msg', 'that'])

# Generated at 2022-06-21 01:45:51.104522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task is None
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None


# Generated at 2022-06-21 01:46:01.383334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.playbook.play_context import PlayContext

    # Create a new instance of class ActionModule
    action_module = ActionModule(
        task=dict(args=dict(
            fail_msg='msg',
            quiet='True',
            success_msg='success msg',
            that='[1, 2]',
        )),
        play_context=PlayContext(),
    )

    # Create a new instance of class AnsibleError
    ansible_error = AnsibleError('message')

    # Call method run of class ActionModule
    try:
        action_module.run()
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))
        assert(set(e.__dict__) == set(('message',)))

# Generated at 2022-06-21 01:46:03.834370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    # Act
    am = ActionModule()

    # Assert
    assert am != None

# Generated at 2022-06-21 01:46:12.491386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.modules["ansible"] = type("FakeAnsibleModule", (object,), {})

    # if we can't import modules from local ansible, it is likely that
    # we have old ansible version that doesn't have
    # sys.modules["ansible"] variable. Use the old way of importing it
    if sys.modules["ansible"] is None:
        import ansible
        sys.modules["ansible"] = ansible

    return_value = sys.modules["ansible"].ActionModule.run(ActionModule(), None, None)
    assert isinstance(return_value, dict)
    assert 'evaluated_to' in return_value
    assert 'assertion' in return_value
    assert 'msg' in return_value

# Generated at 2022-06-21 01:46:29.493370
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Clear globals
    for key in globals().copy():
        if key.startswith("_") or key in ('exit', 'quit'):
            continue
        del globals()[key]

    # Setup test environment
    set_module_args({'assert': {'that': ['5 > 3', 'a == "b"']}})
    host = MagicMock()
    set_module_args(dict(
        that = ['5 > 3', 'a == "b"'],
    ))
    my_obj = MyModule()
    my_obj.run()
    assert my_obj.run()["msg"] == "Assertion failed"

    set_module_args(dict(
        that = ['5 > 3', 'a == "b"'],
        quiet = True,
    ))
    my_obj = MyModule

# Generated at 2022-06-21 01:46:30.944201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No Test
    pass

# Generated at 2022-06-21 01:46:31.946648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-21 01:46:40.492204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class actionmodule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(actionmodule, self).run(tmp, task_vars)

    my_playbook = {}
    my_loader = {}
    my_templar = {}
    my_shared_loader_obj = {}
    my_variable_manager = {}
    my_task = {}
    my_task_vars = {}
    my_actionmodule = actionmodule(my_playbook, my_loader, my_templar,
                                   my_shared_loader_obj, my_variable_manager,
                                   my_task, my_task_vars)
    assert my_actionmodule.run(None, {})


# Generated at 2022-06-21 01:46:48.358350
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:47:01.526241
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    cond = MockConditional()
    module = ActionModule(cond)
    result = module.run(None, {'a':False, 'b':True})

    assert result['failed'] == False
    assert result['changed'] == False

    module = ActionModule(cond)
    result = module.run(None, {'a':True, 'b':True})

    assert result['failed'] == False
    assert result['changed'] == False

    module = ActionModule(cond)
    result = module.run(None, {'a':False, 'b':False})

    assert result['failed'] == True
    assert result['assertion'] == 'a and b'
    assert result['evaluated_to'] == False
    assert result['msg'] == 'Assertion failed'

    module = ActionModule(cond)

# Generated at 2022-06-21 01:47:09.983421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Create Mock objects
    tqm = TaskQueueManager()
    tqm._stdout_callback = ResultCallback()
    tqm._terminated = True

    class Host(object):
        name = '127.0.0.1'

    class Task(object):
        def __init__(self):
            self.args = {}

    class Play(object):
        def __init__(self):
            self.hosts = {}
            self._variable

# Generated at 2022-06-21 01:47:17.848205
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # importing modules that are required for initializing the class and it's methods
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # initializing required objects for the class
    variable_manager = VariableManager()
    loader = variable_manager._loader
    variable_manager._extra_vars = {'test_var': 'test_val'}

    # assigning objects to the class instance
    action_module_instance = action_loader.get('assert', variable_manager=variable_manager, loader=loader)
    action_module_instance._task = Task()

    # test case 1 - argument 'that' with value None
    arguments = {'that': None}

    # test case 1 - assert test case

# Generated at 2022-06-21 01:47:30.198484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    # Test with valid fail_msg, success_msg
    tmp = None
    task_vars = dict(test_var='')
    valid_test_args = {'fail_msg': 'failure_message',
                       'when': True,
                       'that': ['test_var == "test_value"', 'test_var == True']}
    expected_result = {'_ansible_verbose_always': True,
                       'assertion': 'test_var == "test_value"',
                       'changed': False,
                       'evaluated_to': False,
                       'failed': True,
                       'msg': 'failure_message'}

# Generated at 2022-06-21 01:47:31.582605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    print(m)

# Generated at 2022-06-21 01:47:44.421163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:47:52.688697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Base class for unit test
    class Loader:
        pass
    loader = Loader()

    # Base class for unit test
    class Runner:
        def __init__(self, task, host, task_vars, play_context):
            self._task = task
            self._host = host
            self._task_vars = task_vars
            self._play_context = play_context

    # Base class for unit test
    class Task:
        def __init__(self):
            self.args = {}

    class Host:
        def __init__(self):
            self.name = 'localhost'

    # Base class for unit test
    class PlayContext:
        def __init__(self):
            self.connection = 'local'

    # Base class for unit test

# Generated at 2022-06-21 01:47:54.872757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Generated at 2022-06-21 01:47:55.744277
# Unit test for constructor of class ActionModule
def test_ActionModule():
  obj = ActionModule()
  assert obj

# Generated at 2022-06-21 01:47:56.264538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:47:59.182024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Call its run method
    action_module.run()

# Generated at 2022-06-21 01:48:09.572998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    action_cls = action_loader.get('assert', class_only=True)
    action = action_cls()

    # We test for fail_msg first because msg is deprecated
    # Note that we have to use assertEqual rather than assertRaisesRegexp because
    # of a bug in Python 2.6 where assertRaisesRegexp doesn't take a list
    # of strings as the expected exception message
    if hasattr(action, '_task'):
        action._task.args = dict()
    try:
        action.run()
        assert False, 'assert should raise an exception when msg is not specified'
    except AnsibleError as e:
        assert e.message == ['The conditional check "that" is required in this case']


# Generated at 2022-06-21 01:48:20.390744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = u'127.0.0.1'
    dest = u'/root/.ssh/known_hosts'
    port = 22
    user = u'root'
    task_vars = dict(ansible_ssh_host=host, ansible_ssh_port=port, ansible_ssh_user=user, ansible_ssh_pass=u'password', ansible_ssh_private_key_file=u'keys/test.key')
    tmp = u'tmp'

    # Arrange
    # Define a mock task
    task = dict(action=dict(module=u'test_fail_module', fail_msg=u'FAIL_MSG'))
    # Define a mock result

# Generated at 2022-06-21 01:48:30.031968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # setup context for unit test
    context = PlayContext()
    context.become = False
    context.become_method = 'sudo'
    context.become_user = 'root'
    context.remote_addr = 'localhost'
    context.connection = 'local'


    # unit test for fail_msg specified as a string
    fail_msg_as_string = "Assertion failed"
    success_msg_as_string = "Assertion passed"
    action = ActionModule(task=Task(), connection=None, play_context=context, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:48:32.030715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'dict' == type(ActionModule._VALID_ARGS).__name__

# Generated at 2022-06-21 01:48:52.420048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:48:53.826206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)
    assert isinstance(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionModule)


# Generated at 2022-06-21 01:49:00.234983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase) is True
    assert "assert" in ActionModule.BYPASS_HOST_LOOP
    assert "assert" in ActionModule.BYPASS_HOST_LOOP_ON_FAILED_BREAKPOINTS
    assert "msg" in ActionModule._VALID_ARGS
    assert "fail_msg" in ActionModule._VALID_ARGS
    assert "success_msg" in ActionModule._VALID_ARGS
    assert "quiet" in ActionModule._VALID_ARGS
    assert "that" in ActionModule._VALID_ARGS
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase) is True
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 01:49:10.233061
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def _mocked_super_run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()
        result = {}
        result['failed'] = False
        result['changed'] = False
        result['_ansible_verbose_always'] = False
        return result

    def _mocked_evaluate_conditional(self, templar, all_vars):
        return True

    def _mocked_templar_template(self, data):
        if isinstance(data, list):
            return data
        else:
            return data

    # Test case 1: a string and a boolean: Both test should pass
    that = ["ansible_distribution == 'CentOS'", 'ansible_architecture == "x86_64"']
    task

# Generated at 2022-06-21 01:49:21.305604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    fail_msg = {'fail_msg': 'This is the fail message'}

    that = {'that': '1 == 2'}

    args = dict(fail_msg.items() + that.items())

    # Test 2
    fail_msg = 'This is the fail message'

    that = '1 == 2'

    args = dict(fail_msg=fail_msg, that=that)

    # Test 3
    fail_msg = 'This is the fail message'

    that = ['1 == 2', '2 == 3']

    args = dict(fail_msg=fail_msg, that=that)

    # Test 4
    fail_msg = 'This is the fail message'

    that = ['1 == 2', '2 == 2']


# Generated at 2022-06-21 01:49:31.604093
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # That is evaluated when fail_msg is string
    action = ActionModule()
    task = dict(
        name='test action',
        action='assert',
        args=dict(
            that=dict(
                _ansible_parsed=False,
                _ansible_no_log=False,
                _ansible_item_result=False,
                msg='Assertion failed'
            ),
            fail_msg='Testing fail_msg'
        )
    )
    action._task = task
    action._connection = 'winrm'
    action._play_context = dict()
    result = action.run(task_vars = dict(
        temp = 'temp'
    ))
    assert result["failed"] == True
    assert result["evaluated_to"] == False

# Generated at 2022-06-21 01:49:34.770402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new object of the class ActionModule
    result_object = ActionModule()

    # access the method run
    result = result_object.run()
    assert isinstance(result, dict)
    assert result is not None

# Generated at 2022-06-21 01:49:35.621583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 01:49:47.659591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    if sys.version_info < (3, 0, 0):
        return None

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    module_name = 'fail'
    args_options = dict(msg=u'assertion failed', fail_msg=u'assertion failed',
                        success_msg=u'assertion passed', quiet=u'False', that=[u'1 == 1'])

    task = Task()
    task._role = None
    task.args = args_options
    task.action = module_name

    play_context = PlayContext()
    play_context.check_mode = False


# Generated at 2022-06-21 01:49:56.083522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict())
    am = ActionModule(task=None, connection=None, play_context=play_context, loader=None, templar=templar, shared_loader_obj=None)
    print(am)

# Generated at 2022-06-21 01:50:29.680064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = None
    # Instantiation of class
    # Run method of class
    action_module = ActionModule()



# Generated at 2022-06-21 01:50:36.723359
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ######################
    # _VALID_ARGS test
    ######################
    aa = ActionModule(None, dict(a='b'), None, None, None)
    assert aa._VALID_ARGS == frozenset(('a',))
    aa = ActionModule({}, {}, {}, {}, {})
    assert aa._VALID_ARGS == frozenset(('msg', 'fail_msg', 'success_msg', 'quiet', 'that'))


    ######################
    # "that" parameter test
    ######################
    # that: var == 'test'
    # 1. Run task with "that" parameter not provided
    t = dict(a='b')
    a = ActionModule({}, t, None, None, None)

# Generated at 2022-06-21 01:50:39.013031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod


# Generated at 2022-06-21 01:50:46.190026
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:50:48.212706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 01:50:57.264769
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialization
    task_args = {'let1': [True], 'let2': [False], 'let3': [False]}
    action = ActionModule(task=dict(args=task_args))
    task_vars = {'testvar': 'testval'}


    # first test:
    # if 'that' is not in task_args, method run should raise AnsibleError

# Generated at 2022-06-21 01:51:07.364466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inject import InventoryInjector

    # Setup objects required to create an action plugin
    host = Host()
    group = Group()
    play = Play().load({'name': 'testplay', 'hosts': 'all'}, variable_manager={}, loader=None)
    play._injector = InventoryInjector(host, group)

    # Setup the action plugin
    action = {'args': dict(fail_msg='fail')}
    task = Task().load(action=action, play=play)
    task._parent = play

# Generated at 2022-06-21 01:51:08.127311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 01:51:09.816335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionBase)

# Generated at 2022-06-21 01:51:14.412759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert not am.TRANSFERS_FILES
    assert am._templar is None
    assert am._loader is None
    assert am._connection is None

# Generated at 2022-06-21 01:52:39.822874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Create object of class ActionModule
    obj = ActionModule()
    
    # Test assertions for method run
    ansible_loader = None
    ansible_templar = None
    ansible_runner_result = [{1:2, 3:4}]
    ansible_host = ''
    ansible_task = ''
    
    
    
    # Check for expected exception
    try:
        obj._task = None
        obj._task.args = None
        # Call method run
        result = obj.run(tmp=None, task_vars=None)
    except AnsibleError as e:
        assert str(e) == 'conditional required in "that" string'

        # Check for expected exception

# Generated at 2022-06-21 01:52:42.994812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("TESTING ACTIONMODULE")
    print("TESTING ACTIONMODULE constructor")
    actionModule = ActionModule(None, None, None, None, None)
    assert actionModule.TRANSFERS_FILES == False
    return

# Generated at 2022-06-21 01:52:55.576898
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Defining mock objects
    class MockTask:
        def __init__(self):
            self.args = {'fail_msg': 'fail message', 'success_msg': 'success message', 'that': ['a', 'b']}

    class MockModuleUtils:
        class Parsing:
            class ConvertBool:
                @staticmethod
                def boolean(x, strict=True):
                    return True

    class MockPlayBook:
        def __init__(self):
            self.vars = {'a': 'alpha', 'b': 'bravo'}
            self.hostvars = {'host_a': {'a': 'alpha1', 'b': 'bravo1'}}

    class MockTemplar:
        def __init__(self):
            self.vars = ['a', 'b']


# Generated at 2022-06-21 01:52:57.902379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_instance = ActionModule(
        task={
            'args': {
            }
        },
        connection={
        }
    )
    module_instance.run()
    assert module_instance.run() is not None

# Generated at 2022-06-21 01:52:58.761818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:53:02.054984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialization
    tmp = 'tmp'
    task_vars = dict()
    # validation
    module = ActionModule()
    assert module.run(tmp, task_vars)

# Generated at 2022-06-21 01:53:14.835606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import pytest

    class FakeLoader():
        pass

    class FakeInventory():
        pass

    class FakeAnsible():
        def __init__(self):
            self.loader = FakeLoader()
            self.inventory = FakeInventory()

    class FakePlay():
        def __init__(self):
            self.vars = {}

    class FakeTask():
        def __init__(self):
            self.args = {}
            self.vars = {}


# Generated at 2022-06-21 01:53:25.772877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader
    action_path = action_loader._find_plugin('assert')
    assert_action = action_loader._get_action_class(action_path)
    assert isinstance(assert_action, type)

    m = assert_action()
    m._templar = None
    m._task = None
    m._loader = None

    # Testing with quiet=False and fail_msg provided as list and not list
    task_vars = dict()
    tmp = None

# Generated at 2022-06-21 01:53:36.577186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class Mock_unsafe_text(AnsibleUnsafeText):
        def __init__(self):
            pass

        def __str__(self):
            if not hasattr(self, '_text'):
                self._text = ''
            return self._text

    class Mock_task_vars(dict):
        def __init__(self):
            self.ansible_facts_cache = {}

    class Mock_task_result(TaskResult):
        def __init__(self):
            pass


# Generated at 2022-06-21 01:53:37.985664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True
