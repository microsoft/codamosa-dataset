

# Generated at 2022-06-21 01:45:27.475010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up test variables
    fail_msg = 'Assertion failed'
    success_msg = 'All assertions passed'
    that = 'something else'
    that_array = ['something else', 'another something else']
    quiet = False
    result = None

    # Create object of class ActionModule
    action_module = ActionModule()

    # Test for 'that' not provided
    try:
        action_module.run(task_vars={})
        assert False, "Failed to raise exception"
    except AnsibleError as e:
        print(e)
        assert True

    # Test for a string type 'fail_msg' value
    result = action_module.run(task_vars={'that': that, 'fail_msg': fail_msg, 'quiet': quiet})
    assert type(result['msg']) == str

# Generated at 2022-06-21 01:45:39.156623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action_loader
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    # Load the action plugin
    action_loader.add_directory('./lib')
    variable_manager = VariableManager()

    class TestModule:
        def __init__(self):
            self.argument_spec = dict()

    class TestTask(Task):
        def __init__(self, args):
            self.args = args

    def test_module_method(*args, **kwargs):
        pass

    module = TestModule()
    task = TestTask(dict())
    module.run_command = test_module_method

    # Create an instance of the action plugin
    action = action_loader.get('assert', task, variable_manager=variable_manager, loader=None)

   

# Generated at 2022-06-21 01:45:47.574369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = {'x': '1'}
    action = ActionModule(ActionBase)
    assert isinstance(action, ActionModule)

    result = action.run(tmp=None, task_vars=t)
    assert result.get('msg') == 'All assertions passed'

    result = action.run(tmp=None, task_vars=t)
    assert result.get('msg') == 'All assertions passed'

    result = action.run(tmp=None, task_vars=t)
    assert result.get('msg') == 'All assertions passed'


# Generated at 2022-06-21 01:45:59.816695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object of class ActionModule which is being tested
    act = ActionModule()

    # Testing with a --fail_msg=[msg1, msg2] and --success_msg=[msg1, msg2]
    # --fail_msg do not have --msg preceeding it
    act._task = {
        'args': {
            'fail_msg': ['first fail msg', 'second fail msg'],
            'success_msg': ['first success msg', 'second success msg'],
            'that': '2 > 3'
        },
        'action': 'fail',
        'delegate_to': 'localhost'
    }
    tmp = None
    task_vars = {}
    try:
        act.run(tmp, task_vars)
    except:
        pass
    assert act._result['failed'] is True
   

# Generated at 2022-06-21 01:46:01.095624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 01:46:08.301403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
        Unit test for method run of class ActionModule
    '''

# Generated at 2022-06-21 01:46:16.716737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-locals

    class FakeLoader(object):
        all_vars = dict()
        def get_basedir(self, *args, **kwargs):
            ''' Fake method for get basedir'''
        def load_from_file(self, *args, **kwargs):
            ''' Fake method for loading yaml file'''

    class FakeTask(object):
        ''' Fake class for Task'''
        def __init__(self):
            self.args = dict()

    # Test with no args, expecting AnsibleError exception
    try:
        my_action = ActionModule(FakeTask(), FakeLoader())
        raise Exception("AnsibleError exception was not raised")
    except AnsibleError:
        pass

   

# Generated at 2022-06-21 01:46:20.226435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-21 01:46:27.108551
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize a systems_utils.SystemsUtils object
    systems_utils_obj = systems_utils.SystemsUtils()

    # Initialize a module.ActionBase object
    module_obj = module.ActionBase()

    # Initialize a module.ActionModule object
    action_obj = module.ActionModule()
    action_obj.run(tmp=None, task_vars = None)
# vim: set et sw=4 ts=4:

# Generated at 2022-06-21 01:46:35.816746
# Unit test for constructor of class ActionModule
def test_ActionModule():

    #test creating ActionModule object with no parameters
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    #test creating an ActionModule object with valid dict of parameters
    module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 01:46:52.437546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # construct a mock task
    mock_playbook = "playbook_name.yml"
    mock_loader = "ansible.parsing.dataloader.DataLoader"
    mock_host = "host_name"
    mock_task = "task_name"
    mock_args = {'msg': 'Assertion failed', 'that': ["v1 == v2", "v3 > v4"]}

    # construct a mock result
    mock_result = ''' {
      "changed": true,
      "assertion": "v3 > v4",
      "evaluated_to": false,
      "msg": "Assertion failed"
    } '''

    # define a mock templar

# Generated at 2022-06-21 01:47:03.099830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing test data
    ansible_options = {"forks": 10, "become": True, "become_method": "sudo", "become_user": "root", "check": False, "diff": False}
    loader = "loader"
    variable_manager = "variable_manager"
    shared_loader_obj = "shared_loader_obj"
    play = "play"
    play_context = "play_context"
    new_stdin = "new_stdin"

# Generated at 2022-06-21 01:47:08.939153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    tmp = None
    action = ActionModule(task_vars=task_vars, tmp=tmp)
    assert action.PAUSE_TIME == 2, "ActionModule.PAUSE_TIME is not 2"
    assert action.TRANSFERS_FILES == False, "ActionModule.TRANSFERS_FILES is not False"
    assert action.VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))



# Generated at 2022-06-21 01:47:09.714852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:47:11.703221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Write unit test for ActionModule
    assert False

# Generated at 2022-06-21 01:47:12.525639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-21 01:47:23.422652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class Host:
        ''' An empty placeholder for the parameters required by the method run of class ActionModule '''
        def __init__(self, tqm):
            self.tqm = tqm


# Generated at 2022-06-21 01:47:26.735816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None)
    assert module is not None

# Generated at 2022-06-21 01:47:27.255896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule())

# Generated at 2022-06-21 01:47:29.670727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(ActionBase())
    assert a._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:47:50.358030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None)
    argument_spec = dict(fail_msg=dict(), msg=dict(), quiet=dict(type='bool'), success_msg=dict())
    action_module._task = dict()
    action_module._task['args'] = dict(fail_msg='fail')
    action_module._task_vars = dict()
    action_module._task_vars['playbook_dir'] = dict()
    action_module._task_vars['playbook_dir'] = 'playbook_dir'
    action_module._task_vars['play_hosts'] = set()
    action_module._task_vars['play_hosts'].add('host1')
    action_module._task_vars['inventory_hostname'] = 'host2'
    action_module._task_v

# Generated at 2022-06-21 01:47:55.290751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for invalid_arg in ({}, {'fail_msg':[]}, {'msg':[]}, {'success_msg':[]}, {'that':[]}, {'quiet':[]}):
        try:
            ActionModule(invalid_arg)
            assert False, "ActionModule constructor should throw error when called with incorrect parameters - invalid_arg=%s" % str(invalid_arg)
        except:
            pass


# Generated at 2022-06-21 01:48:01.879832
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def assert_ActionModule_run(mocker, task_vars, quiet, success_msg, fail_msg,
                                evaluated_to, assertion, failed, msg, changed,
                                that_list, raise_error=False):

        action_module_mock = mocker.MagicMock(spec=ActionModule)
        action_module_mock._task = mocker.MagicMock()
        action_module_mock._task.args = {}

        if isinstance(that_list, string_types):
            that_list = [that_list]
        action_module_mock._task.args['that'] = that_list

        if quiet is not None:
            action_module_mock._task.args['quiet'] = quiet

        if success_msg is not None:
            action_module_mock._task.args

# Generated at 2022-06-21 01:48:10.294481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    action_module = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Test the right class is instantiated
    assert isinstance(action_module, ActionModule)
    # Test that the parent class is setup
    assert isinstance(action_module._play_context, dict)
    assert isinstance(action_module._task, Task)
    assert isinstance(action_module._loader, object)
    assert isinstance(action_module._templar, Templar)
    # assert hasattr(action_module, '_task_vars')
    # assert hasattr(action_module, '_nonpersistent_fact_cache')
    # assert hasattr

# Generated at 2022-06-21 01:48:11.635493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:48:21.272497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert action._task is None
    assert action._play_context is None
    assert action._loaded_from is None
    assert action._task_vars is None
    assert action._templated_fields is None
    assert action.VALID_ARGS == action._VALID_ARGS
    assert action.TRANSFERS_FILES == False
    # _VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-21 01:48:26.983984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task_vars = dict()
    # Fail with custom message
    task = Task()
    task._role = None
    task.args = {'that': u'var > 0', 'msg': u'All assertions passed'}
    task._block = Block()
    blocking_action = ActionModule(task, task_vars=task_vars)
    assert blocking_action._templar._available_variables == task_vars


# Generated at 2022-06-21 01:48:39.017655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModuleMock(object):
        passed = False
        def __init__(self, args, tmp, task_vars):
            self.args = args
            self.tmp = tmp
            self.task_vars = task_vars
        def run(self, *args, **kwargs):
            if self.args['that'] == "'yes' in foo":
                assert self.task_vars['foo'] == 'yes'
                return {'msg': 'Assertion passed'}
            elif self.args['that'] == "'yes' in foo and 'yes' in bar":
                assert self.task_vars['foo'] == 'yes' and self.task_vars['bar'] == 'yes'
                return {'msg': 'Assertion passed'}

# Generated at 2022-06-21 01:48:48.694892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.hosts import Host
    from ansible.playbook import PlayBook, Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager

    class ActionModule(object):
        def fail_json(self, **kwargs):
            pass

    class TaskQueueManager(object):
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = passwords
            self.stdout_callback = stdout_callback


# Generated at 2022-06-21 01:48:56.401497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(action='assert'), play_context=dict(), new_stdin='foobar')
    assert am._new_stdin == 'foobar'
    assert am._task.action == 'assert'
    assert am._play_context.new_stdin == 'foobar'
    assert am._task.no_log is False
    assert am._task == am._task_vars['ansible_task_vars']

# Generated at 2022-06-21 01:49:17.831108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: assert that the constructor does what it is supposed to
    assert True

# Generated at 2022-06-21 01:49:20.712260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myargs = dict(msg="Yes sir")
    assert ActionModule._VALID_ARGS.issubset(myargs.keys())


# Generated at 2022-06-21 01:49:26.154778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test empty constructor
    test_action_module = ActionModule()

    # Test constructor with just the task argument
    test_task = {}
    test_action_module = ActionModule(test_task)
    assert(test_task == test_action_module._task)

# Generated at 2022-06-21 01:49:26.915584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:49:28.046963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:49:33.803396
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:49:34.196913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 01:49:34.932373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement this test
    pass

# Generated at 2022-06-21 01:49:37.664965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-21 01:49:43.743912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Host()
    host.name = 'test'
    host.port = 22
    host.vars = {}
    host.groups = {}
    host.groups_d = {}

    task = Task()
    task.args = {}
    task.args['fail_msg'] = ['1', '2']
    task.args['that'] = ['3', '4']
    action_mod = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = action_mod.run(tmp=None, task_vars=None)
    assert(result != None)
    assert('failed' in result)
    assert(result['failed'] != None)
    assert(result['failed'] == True)

# Generated at 2022-06-21 01:50:19.098064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None) is not None

# Generated at 2022-06-21 01:50:26.869909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import common

    class ActionModule(common.ActionModule):
        ''' Fail with custom message '''
        def __init__(self, *args, **kwargs):
            super(ActionModule, self).__init__(*args, **kwargs)

    # Mocking module AnsibleModule
    with mock.patch('ansible.compat.six.moves.builtins.__import__', return_value=mock.MagicMock()):
        from ansible.module_utils.basic import AnsibleModule
        am = AnsibleModule({'ansible_loop_var': 'item'}, conditional='stat', fail_msg='failed', action_plugins=['asserts'])

# Generated at 2022-06-21 01:50:29.006509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = ActionModule(task=dict())
    assert isinstance(task, ActionModule)

# Generated at 2022-06-21 01:50:36.534635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='action_module', module_args=dict(that=['1 == 1', '2 == 2'])))
    )
    module_return_value = action_module.run(tmp=None, task_vars=dict())
    assert module_return_value['changed'] is False
    assert module_return_value['assertion'] is None
    assert module_return_value['evaluated_to'] is True
    assert module_return_value['failed'] is False
    assert module_return_value['msg'] == 'All assertions passed'

    action_module = ActionModule(
        task=dict(action=dict(module_name='action_module', module_args=dict(that='1 == 2')))
    )
    module_return_value = action_

# Generated at 2022-06-21 01:50:45.554963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for conditions
    # 1. that is list
    # 2. that is string
    # Test for fail_msg and success_msg

    # 1. that is list
    # fail_msg is string
    templar = MockTemplar()
    task = MockTask(templar)
    task.args = {'that': ['1==1', '2==2']}
    task._ansible_no_log = False

    a = ActionModule(task, templar, None)
    result = a.run()
    assert result['failed'] == False
    assert result['changed'] == False
    assert isinstance(result['msg'], string_types)

    # fail_msg is list

# Generated at 2022-06-21 01:50:51.941600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for class ActionModule '''
    a = ActionModule(loader=None, task=None, connection=None, play_context=None,
                     shared_loader_obj=None, templar=None, shared_lock_obj=None)
    return a

# Generated at 2022-06-21 01:50:58.254288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    t = Task()
    t._role = None
    t._block = Block()
    t._role = None
    t.role_name = "test_role"
    t._parent = Block()
    t._parent._role = None
    t._parent.role_name = "test_role"
    t._task_include = None
    t.action = "fail"
    t.args = dict(msg="This test case pass")
    host = Host('test_host')
    host.set_variable('ansible_connection', 'local')
    group = Group('test_group')
    group.add_host(host)
   

# Generated at 2022-06-21 01:51:07.650458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.connection import Connection
    from ansible.playbook_tests.test_helpers import AnsibleExitJson
    from ansible.playbook_tests.test_helpers import AnsibleFailJson
    from ansible.playbook.task import Task

    pc = PlayContext()
    test_task = Task()

    test_conn = Connection()
    test_task.args = {'msg':'This is a test', 'that': 'test_string == "This is a test"'}
    test_task.action = 'fail'

    fail_action = ActionModule(task=test_task, connection=test_conn, play_context=pc, loader=None, templar=None, shared_loader_obj=None)

    result1 = fail

# Generated at 2022-06-21 01:51:09.876636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, {}, {})
    am.run()

# Generated at 2022-06-21 01:51:13.294746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    return module

# Generated at 2022-06-21 01:52:40.253495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m != None

test_ActionModule()

# Generated at 2022-06-21 01:52:43.646132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action_module is not None

# Generated at 2022-06-21 01:52:55.924665
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:53:05.557638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins import action_loader

    action = action_loader.get('assert', class_only=True)
    assert action.STRICT_BOOLEANS == False
    assert action.RETVAL_ACTION == 'assert'
    assert action.VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    task = dict(when=['some_when'])
    action = action(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.task == task
    assert action.task_vars == {}


# Generated at 2022-06-21 01:53:16.135701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for run function of ActionModule cls'''
    result = {}
    task = {}
    tmp = None
    task_vars = {'syslog_host': '192.168.1.1'}
    loader = None
    templar = None
    task_vars_no_host = {'ansible_host': ''}
    task_vars_no_host_no_ip = {'ansible_host': '', 'ansible_ssh_host': ''}

    # Test with that value string
    task = {'args': {'that': 'syslog_host is defined'}}
    action_module = ActionModule(task, tmp, task_vars, loader, templar)
    result = action_module.run(tmp, task_vars)

# Generated at 2022-06-21 01:53:24.457430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create target class instance
    target = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create mocks
    tmp = None
    task_vars = {'a': 'b'}

    # Call method run
    result = target.run(tmp, task_vars)

    # Check expected result
    assert result['failed'] is True
    assert result['msg'] == 'Assertion failed'
    assert result['assertion'] == 'a == b'

# Generated at 2022-06-21 01:53:25.571271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:53:36.548456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    from ansible.plugins.callback import CallbackBase

    class TestCallback(CallbackBase):
        """
        This is the callback interface, which simply allows for callbacks
        from tasks to be plugged into a single class.
        """
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self._task_results = []

        def v2_runner_on_ok(self, result):
            self._task_results.append(result)


# Generated at 2022-06-21 01:53:43.430948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("test_ActionModule()")
    assert ActionModule is not None
    print ("test_ActionModule() finished")

# ====
# main
# ====
#
# Unit tests for this file is contained in this file,
# see https://stackoverflow.com/questions/228197/python-integration-test-framework
#
# This is not really a module, but a script that can be ran to
# verify that the module works in the way we expect it to.
#

# Generated at 2022-06-21 01:53:48.042766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test_ActionModule_SuccessMsg
    Check to make sure that the action is instantiated correctly.
    '''
    action = ActionModule()
    assert isinstance(action, ActionBase)