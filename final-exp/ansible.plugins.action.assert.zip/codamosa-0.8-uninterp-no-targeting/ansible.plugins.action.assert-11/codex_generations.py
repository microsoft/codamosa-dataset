

# Generated at 2022-06-21 01:45:15.033488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:45:17.483391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {})

# Generated at 2022-06-21 01:45:24.834416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self):
            self.args = {}

    def run(tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = {}
        task_vars = {}
        return {'changed': False}

    class MockLoader:
        def __init__(self):
            self.paths = []
            self.tests = {'test': 'test'}
            self.filters = {}

    class MockTemplar:
        def __init__(self):
            pass

        def template(self, data):
            return data

    mock_templar = MockTemplar()
    action_module = ActionModule(mock_templar, run, Task())
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 01:45:35.651028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ##############
    # Constructor
    ##############
    # ActionModule()
    plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert plugin._task is None
    assert plugin._connection is None
    assert plugin._play_context is None
    assert plugin._loader is None
    assert plugin._templar is None
    assert plugin._shared_loader_obj is None
    assert plugin._task_vars is None
    assert plugin._tmp is None

# Generated at 2022-06-21 01:45:48.194054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test with no task.args
    args = {}
    result = action.run(task_vars = {}, tmp = None, args = args)
    assert result['failed'] == True
    assert result['msg'] == 'conditional required in "that" string'

    # test with wrong type for task.args['that']
    args = {}
    args['that'] = 1
    result = action.run(task_vars = {}, tmp = None, args = args)
    assert result['failed'] == True
    assert result['msg'] == 'conditional required in "that" string'

    # test with success
    args = {}

# Generated at 2022-06-21 01:46:00.074502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('fail_msg', 'msg', 'quiet', 'success_msg', 'that')

    fail_msg = mod._task.args.get('fail_msg', mod._task.args.get('msg'))
    success_msg = mod._task.args.get('success_msg')
    quiet = boolean(mod._task.args.get('quiet', False), strict=False)

    # these are valid arguments to be passed to ActionModule class
    valid_args = mod._VALID_ARGS

    # this is the expected output
    expected_output = {'_ansible_verbose_always': True,
                       'assertion': 'that',
                       'changed': False,
                       'evaluated_to': False,
                       'failed': True,
                       'msg': 'Assertion failed'}


# Generated at 2022-06-21 01:46:05.636094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='assert', args=dict(
            that=dict(test='test',test1='test1')
        ))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-21 01:46:18.207217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import unittest
    from collections import namedtuple

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a mock class to use as a standin for the TaskExecutor class
    class TQMMock:
        def run(self, iterator, play_context):
            results = []
            result_fields = ('changed', 'failed', 'msg', 'assertion', 'evaluated_to')
            result = namedtuple('Result', result_fields)
            # The first result will

# Generated at 2022-06-21 01:46:27.712139
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Construct an instance of ActionModule
    action_module = ActionModule()

    # Check the validity of the _VALID_ARGS attribute
    valid_args = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert action_module._VALID_ARGS == valid_args, \
        "Incorrect attribute value: %s" % action_module._VALID_ARGS

    # Check the validity of the TRANSFERS_FILES attribute
    assert action_module.TRANSFERS_FILES == False, \
        "Incorrect attribute value: %s" % action_module.TRANSFERS_FILES

# Generated at 2022-06-21 01:46:36.805655
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:46:46.977936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 01:46:48.848699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 01:47:00.082464
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_class=None, templar=None, shared_loader_obj=None)

    try:
        result = module.run(tmp=None, task_vars=None)
        assert(False), 'Expected exception'
    except AnsibleError as e:
        assert(e.message == 'conditional required in "that" string')

    try:
        result = module.run(tmp=None, task_vars=None)
        assert(False), 'Expected exception'
    except AnsibleError as e:
        assert(e.message == 'conditional required in "that" string')

# Generated at 2022-06-21 01:47:10.767706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        _VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            if 'that' not in self._task.args:
                raise AnsibleError('conditional required in "that" string')

            fail_msg = None
            success_msg = None

            fail_msg = self._task.args.get('fail_msg', self._task.args.get('msg'))

# Generated at 2022-06-21 01:47:18.889163
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import imp
    import os
    import sys

    import unittest.mock as mock


# Generated at 2022-06-21 01:47:22.509638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict()), connection='paramiko', play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:47:30.218017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    task = action.task = dict()
    task['args'] = {'fail_msg': ['fail_msg1', 'fail_msg2'], 'that': ['a=b', 'c=d']}
    # task['args']['msg'] = ['fail_msg1', 'fail_msg2']
    result = action.run(
        tmp=None,
        task_vars=dict()
    )


# Generated at 2022-06-21 01:47:42.412261
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test initialization of object ActionModule
    test_obj = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test with no arg
    test_tmp = None
    test_task_vars = None
    test_result = None
    try:
        test_result = test_obj.run(tmp=test_tmp, task_vars=test_task_vars)
    except Exception as e:
        pass
    assert not test_result
    assert e is not None, "Error not raised"

    # test with given args
    test_tmp = None
    test_task_vars = dict()
    test_task_vars['_ansible_verbose_always'] = True

# Generated at 2022-06-21 01:47:43.078035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:47:48.041540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:48:05.935334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Unit test function for ActionModule.run

# Generated at 2022-06-21 01:48:07.764502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(runner=None, task=None)

# Generated at 2022-06-21 01:48:12.094272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ut = ActionModule()
    except Exception as e:
        print("Unable to create ActionModule object")
        print("Exception: {} ".format(e))

# Generated at 2022-06-21 01:48:13.157435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We don't run the unit test for this class
    return


# Generated at 2022-06-21 01:48:18.079211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up required arguments for method run
    tmp = None
    task_vars = None

    # Create instance of ActionModule class
    test_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test the run() method
    test_instance.run(tmp, task_vars)


# Generated at 2022-06-21 01:48:29.256586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    class ActionModuleTest(ActionModule):
        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    ##############################################
    # Test case 1
    # The assert module will return 'changed=False' when it passes.


# Generated at 2022-06-21 01:48:33.535970
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:48:41.000101
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class ActionModule_Mock:
        def __init__(self, val):
            self.when = [val]
            self.load_file = False
            self.defer_facts = False
            self.set_fact_cache = False

    class Conditional_Mock:
        def __init__(self, loader):
            self.loader = loader
            self.when = [0]

    # Test case for fail_msg as string

    # Case 1 - 'That' condition is true
    obj = ActionModule(ActionModule_Mock(0), {}, Conditional_Mock(0), 'hostname', {})
    result = obj.run()
    assert result['failed'] == False

    # Case 2 - 'That' condition is false

# Generated at 2022-06-21 01:48:46.664488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import PlayBook
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import yaml
    class TestModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
        def __call__(self, *args, **kwargs):
            return ActionModule(*args, **kwargs)


# Generated at 2022-06-21 01:48:48.501365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 01:49:32.220503
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.modules.system import ping
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from AnsibleModuleMock import AnsibleModuleMock

    task = Task()
    task.action = 'fail'
    task.args = {'that': 'true'}
    mock_module = AnsibleModuleMock(ping.AnsibleModule)

    test_host = Host(name='127.0.0.1')

# Generated at 2022-06-21 01:49:41.771360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {})()
    mock_task.args = {'fail_msg': 'mock_msg', 'that': ['a=b']}
    # Create a mock tmp
    mock_tmp = '/tmp/nop'
    # Create a mock task_vars
    mock_task_vars = {'a': 'b'}
    # Create a mock loader
    mock_loader = type('MockLoader', (object,), {})()
    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {})()
    # Create a mock action plugin
    mock_action_plugin = type('MockActionPlugin', (object,), {'_VALID_ARGS': []})()
   

# Generated at 2022-06-21 01:49:51.633212
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:49:53.001350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 01:49:54.374870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 01:49:57.493533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new instance of the error action class
    action_module = ActionModule(None, None, None, 'fail_msg', None, None, None)

    # Run the test
    action_module.run()

# Generated at 2022-06-21 01:50:03.209790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_templar = None
    fake_loader = None
    fake_task = { 'args': { 'that': 'foo' } }
    am = ActionModule(fake_templar, fake_loader, fake_task)
    assert am is not None


# Generated at 2022-06-21 01:50:04.031954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:50:06.031575
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule(name="module", task_vars={}, shared_loader_obj=None)

# Generated at 2022-06-21 01:50:07.476490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(task=dict(args=dict(that=[True, True]))) is not None)


# Generated at 2022-06-21 01:51:35.838175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Ensures that constructor of ActionModule() is working without errors.
    action_module = ActionModule('action.py', 'init', 'hostname', {}, {}, {})
    assert action_module

# Generated at 2022-06-21 01:51:46.578414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test to check run method of ActionModule class

    # Defining dict variable
    # Checking dict variable is empty or not
    assert_value = dict()
    # Return successful message
    assert_value['msg'] = 'Assertion passed'
    # Return changed to False
    assert_value['changed'] = False
    assert_value['failed'] = False
    assert_value['skipped'] = False

    # Creating object of class ActionModule
    assert_task = ActionModule()
    # Calling the method run()
    obj = assert_task.run()

    # Checking both dict objects
    for keys, value in assert_value.items():
        assert obj[keys] == value

# Generated at 2022-06-21 01:51:58.839227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    from ansible.plugins.action.assertfile import ActionModule

    # Setup the module arguments
    argument_spec = dict()
    argument_spec.update(ActionModule._VALID_ARGS)
    module = AnsibleModule(argument_spec=argument_spec)

    # Setup the module object
    setattr(module, '_ansible_no_log', True)


# Generated at 2022-06-21 01:51:59.964256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-21 01:52:01.735734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:52:12.563007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = {"action":{"__ansible_argspec":{"args":["that"],"fail_msg":"","msg":""}}}
    mock_task_vars = {"variables":{"a":"1","b":"2"}}
    # Test with out fail or success message
    a = ActionModule(mock_task, "mock_connection", "/path/to/playbooks", loader=None, templar=None, shared_loader_obj=None)
    assert a.run(mock_task_vars)["msg"] == "Assertion failed"
    assert a.run(mock_task_vars)["failed"] == True
    # Test with fail message
    task = mock_task
    task["action"]["__ansible_argspec"]["fail_msg"] = "failure message"

# Generated at 2022-06-21 01:52:14.925767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict(), dict(), dict(), dict())
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 01:52:19.838331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    task.args = {'fail_msg': 'assertion failed', 'msg': ['assertion failed', 'failed'], 'quiet': False, 'success_msg': 'assertion passed', 'that': 'test assert'}
    action = ActionModule(task, dict())
    action.run(None, dict())

# Generated at 2022-06-21 01:52:29.839287
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock loader object
    mock_loader = MagicMock()

    # Create a mock templar object
    mock_templar = MagicMock()

    # Create a mock action base object
    mock_action_base = MagicMock()
    mock_action_base._templar = mock_templar

    # Create a mock task object
    mock_task = MagicMock()
    mock_task.args = {'that': ['foo', 'bar']}

    # Create a mock module util object
    mock_module_util = MagicMock()

    # Create a mock conditional object
    mock_conditional = MagicMock()

    # Create a mock task variable object
    mock_task_vars = {'foo': 'bar'}

    # Create a new instance of the ActionModule class to test
    action_module

# Generated at 2022-06-21 01:52:31.645996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == ActionModule(None, None, None, None).supports_check_mode