

# Generated at 2022-06-21 01:45:28.169778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader

    # Test case 1: Success test with default fail_msg
    test_task = dict(
        action=dict(
            module='assert',
            args=dict(
                that=['ansible_facts["os_family"] == "RedHat"', 'ansible_facts["ansible_sysctl_args"] == ""',
                        u'ansible_facts["ansible_selinux"]["config_mode"] == "enforcing"', 'ansible_facts["ansible_swap"]["total"] >= "1024"'],
            ),
        ),
    )


# Generated at 2022-06-21 01:45:39.414154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule.'''
    a = ActionModule(
      {
        'name': 'test',
        '_ansible_no_log': False,
        '_ansible_verbosity': 2,
        '_ansible_syslog_facility': 'LOG_USER',
        '_use_unsafe_shell': False,
        '_ansible_socket': None,
        'args':
          {
            'fail_msg': 'false fail_msg',
            'quiet': False,
            'success_msg': 'false success_msg',
            'that': 'False'
          },
        'module_name': 'fail'
      },
      loader=None,
      templar=None,
      shared_loader_obj=None
    )


# Generated at 2022-06-21 01:45:40.677786
# Unit test for constructor of class ActionModule
def test_ActionModule(): 
    am = ActionModule()
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:45:43.793927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:45:49.600208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_module_instance = ActionModule(loader=None, variable_manager=None, play_context=None)
    assert ansible_module_instance is not None
    assert ansible_module_instance._task is None
    assert ansible_module_instance._loader is None
    assert ansible_module_instance._templar is None
    assert ansible_module_instance._shared_loader_obj is None

# Generated at 2022-06-21 01:45:59.322872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Function to test method run of class ActionModule '''

    my_run = ActionModule.run
    data_from_execute_module = {'failed': False, 'invocation': {'module_name': 'assert', 'module_args': {'msg': 'Assertion failed'}}}
    data = my_run(data_from_execute_module)
    assert data['invocation']['module_args']['msg'] == 'Assertion failed'
    data['failed'] = True
    del data['invocation']
    assert data == {'failed': True, 'evaluated_to': False, 'assertion': {}}

# Generated at 2022-06-21 01:46:01.847742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(fail_msg='failed msg', msg='message', quiet=False, success_msg='sccessed msg', that='this message')))
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:46:06.712805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object
    test_object = ActionModule()
    # set values to required attributes
    test_object._task = None
    test_object._templar = None
    test_object._loader = None
    # invoke method run and check the result
    pass

# Generated at 2022-06-21 01:46:18.777159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeAction:
        def __init__(self, _task):
            self._task = _task

    class FakeTask:
        def __init__(self, args):
            self.args = args

    # Test case 1
    # . msg field is mandatory
    # . msg field can have string or a list of strings
    # . fail msg should be used if fail_msg is not specified
    # . default fail msg should be used if fail_msg is not specified
    # . success msg should be used if success_msg is not specified
    # . default success msg should be used if success_msg is not specified
    # . fail msg and success msg can be list of strings
    # . fail msg and success msg should not be empty or None
    # . default fail msg should be used if empty list is specified for fail_msg
    #   or msg
   

# Generated at 2022-06-21 01:46:19.973593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Constructor of class ActionModule

# Generated at 2022-06-21 01:46:30.494124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with dict passed as an arg
    assert ActionModule(dict()) is not None

# Generated at 2022-06-21 01:46:31.316421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:46:38.995939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule - test for method run
    """
    action_module_obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_on_failed=None)

    # fail_msg not present in self._task.args, AnsibleError should be raised.
    args = {}
    that = None
    self = action_module_obj
    self._task.args = args
    try:
        action_module_obj.run(None, None)
    except AnsibleError as e:
        assert "conditional required in \"that\" string" in str(e)
    else:
        assert False, "AnsibleError not raised"

    # Test case when fail_msg present in self._task.args and is instance of string.
    # Test case when success_msg present in self._task

# Generated at 2022-06-21 01:46:50.335030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test when fail_msg is specified in args and has a string value
    fail_msg_str = 'Some Fail Msg'
    args_dict = {'fail_msg': fail_msg_str, 'quiet': 'True'}
    mock_task = {'args': args_dict}
    action_module = ActionModule(mock_task, 'test loop', 'test basedir', 'test name', 'test loader')
    assert action_module.fail_msg == fail_msg_str

    # Test when fail_msg is specified in args and has a list value
    fail_msg_list = ['Some Fail Msg1', 'Some Fail Msg2']
    args_dict = {'fail_msg': fail_msg_list, 'quiet': 'True'}
    mock_task = {'args': args_dict}
    action_module

# Generated at 2022-06-21 01:46:53.335208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #This method is not tested because it requires the remote host information and cannot be run in unit test
    pass

# Generated at 2022-06-21 01:47:03.362072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    in_var1 = 'foo'
    in_var2 = 'bar'
    in_var3 = ['foo1', 'foo2', 'foo3']
    in_var4 = ['bar1', 'bar2', 'bar3']
    in_var5 = 'baz'
    in_var6 = 'qux'
    in_var7 = 'foo  bar'
    in_var8 = 'bar  foo'
    in_var9 = 'foo  foo  foo'
    in_var10 = 'bar  bar  bar'
    in_var11 = 'foo  foo  bar'
    in_var12 = 'foo  bar  bar'
    in_var13 = 'bar  bar  foo'
    in_var14 = 'bar  foo  foo'


# Generated at 2022-06-21 01:47:09.444062
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:47:21.236536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(
        task=dict(
            args=dict(
                msg='TestMessage',
                fail_msg='OtherFailedMessage',
                success_msg='OtherSuccessMessage',
                that='true'
            )
        )
    )
    
    result = action.run(
        tmp=None,
        task_vars=dict(
            variable=42,
        )
    )
    
    assert not result['failed']
    assert not result['changed']
    assert result['msg'] == 'OtherSuccessMessage'

    action = ActionModule(
        task=dict(
            args=dict(
                msg='TestMessage',
                that='false'
            )
        )
    )
    

# Generated at 2022-06-21 01:47:29.443033
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:47:30.230924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:47:53.153423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module._templar = None
    module._task = None
    module._loader = None
    module._connection = None
    module._play_context = None
    module._shared_loader_obj = None
    module._task_vars = []
    
    # testing successful case (1 = True)
    module._task = {"args": {"that": "1 == 1", "quiet": False, "fail_msg": None}}
    
    result = module.run(task_vars=None, tmp=None)

    assert result['assertion'] is None
    assert result['changed'] is False
    assert result['evaluated_to'] is True
    assert result['failed']

# Generated at 2022-06-21 01:47:57.472862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test to validate the constructor of ActionModule class.
    '''
    main_obj = ActionBase()
    test_obj = ActionModule(main_obj._task, main_obj._connection, main_obj._play_context, main_obj._loader, main_obj._templar, main_obj._shared_loader_obj)
    assert isinstance(test_obj, ActionModule)

# Generated at 2022-06-21 01:48:08.777971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy

    def test_results(results, exp_results):
        ''' Helper function to compare all keys and values of expected results,
        with actual results. If there is a mismatch, raise an assertion error'''

# Generated at 2022-06-21 01:48:20.056110
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    class ModuleResult(object):
        ''' class to hold result of module invocation '''
        def __init__(self):
            self.result = dict()

    class TestModule(object):
        ''' class to hold metadata of module '''
        def __init__(self):
            self.params

# Generated at 2022-06-21 01:48:29.908943
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()
    task_vars['ansible_verbosity'] = 0

    # Test run function when all the conditions in "that" string are true
    action = ActionModule(load_name='fail', task=dict(args={u'that': [u'1 == 1', u'2 == 2'], u'success_msg': 'foo'}))
    action._loader.load_basedir = 'foo'
    action._loader.path_policy = 'foo'
    action._loader.set_basedir('foo')
    action._loader.set_data(dict())
    action._loader.path_exists = 'foo'
    action._loader.path_exists = 'foo'
    action._loader.is_file = 'foo'
    action._loader.get_basedir = 'foo'
    action

# Generated at 2022-06-21 01:48:30.738391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:48:31.609590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:48:40.543610
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    class AnsibleModuleMock:
        def __init__(self):
            self.params = dict()

    class AnsiblePlaybookMock:
        def __init__(self):
            self.ROOT_PATH = '/etc/ansible'
            self.variable_manager = None
            self.loader = None
            self.inventory = None
            self.basedir = ''

        def set_inventory(self, inventory):
            self.inventory = inventory


# Generated at 2022-06-21 01:48:49.208393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.playbook.task import Task

    # Test with no 'that' specified
    module = action.ActionModule(
        task=Task(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    try:
        module.run(task_vars=dict())
    except AnsibleError as e:
        assert str(e) == 'conditional required in "that" string'

    # Test with incorrect type for fail_msg and msg

# Generated at 2022-06-21 01:48:54.092591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj


# Generated at 2022-06-21 01:49:35.106521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader
    import ansible.playbook.play

    # Create stubs
    MockTask = type('MockTask', (object,), dict(args=dict(), __dict__=dict()))
    MockPlay = type('MockPlay', (object,), dict(__dict__=dict()))
    MockPlayContext = type('MockPlayContext', (object,), dict(__dict__=dict()))
    results = dict()

    # Create action module and task
    action = ansible.plugins.loader.ActionModule('action', 'path', 'args')
    task = MockTask()

    # Create play and play context
    play_context = MockPlayContext()
    play_context.remote_addr = 'localhost'
    play_context.port = 22

    play_context.become = True
    play_

# Generated at 2022-06-21 01:49:35.592343
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True

# Generated at 2022-06-21 01:49:37.510960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test method run of class ActionModule """
    pass

# Generated at 2022-06-21 01:49:48.186504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class args(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    def test_run(self, tmp=None, task_vars=None):
        ansible_result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        if 'that' not in self._task.args:
            raise AnsibleError('conditional required in "that" string')

        fail_msg = None
        success_msg = None

        fail_msg = self._task.args.get('fail_msg', self._task.args.get('msg'))
        if fail_msg is None:
            fail_msg = 'Assertion failed'

# Generated at 2022-06-21 01:49:54.923629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='assert')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 01:50:02.341515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.vars import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.errors import AnsibleError
    import types

    # Mock class to load plugins
    class ActionModuleMock(ActionBase):
        def get_task_vars(self, task_vars=dict()):
            return task_vars

        def load_module_utils(self, module_name):
            return None


# Generated at 2022-06-21 01:50:11.585792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method of ActionModule
    '''
    import json
    from ansible.plugins.action import ActionModule
    
    action_module = ActionModule(load_plugins = None, task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)

    # test with fail_msg=string
    task_args = {'fail_msg': 'test_fail_msg'}
    result = action_module._execute_module(task_args=task_args, tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['msg'] == 'All assertions passed'

    # test with success_msg=string

# Generated at 2022-06-21 01:50:12.582739
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:50:24.254476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    # Just to be sure we have the process title, initialise the config
    import ansible
    ansible.utils.plugins.action_base._config = ansible.config.loader.Config(file_name='/etc/ansible/ansible.cfg')

    # Setup a task dictionary for testing
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'assert'
    task['action']['__ansible_arguments__'] = dict()
    task['action']['__ansible_arguments__']['fail_msg'] = ['first', 'second']
    task['action']['__ansible_arguments__']['that'] = ['a == b', 'c == d']

    #

# Generated at 2022-06-21 01:50:28.594131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:51:54.483748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:51:59.964773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None
    )
    assert isinstance(action, ActionModule)
    assert action._task.args == dict()
    assert action._loader is not None
    assert action._templar is not None

# Generated at 2022-06-21 01:52:01.294998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule()
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-21 01:52:06.163769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os

    from ansible.module_utils.six import StringIO

    from ansible.plugins.action import ActionBase

# Generated at 2022-06-21 01:52:09.153673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import find_plugin
    action = find_plugin('action_plugins', 'assert')
    assert(action.ActionModule is ActionModule)

# Generated at 2022-06-21 01:52:17.894865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    mock_loader = DictDataLoader({})
    mock_play_context = PlayContext()
    mock_display = Display()
    mock_templar = Templar(
        loader=mock_loader,
        variables={}
    )

    mock_task = Task()
    mock_task.action = 'ignore'
    mock_task.args = {}


# Generated at 2022-06-21 01:52:21.509576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__module__.endswith('action')
    assert hasattr(ActionModule, '_VALID_ARGS')
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:52:31.055088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Variables for testing
    args = {
        'fail_msg': 'failed',
        'success_msg': 'passed',
        'quiet': True,
        'that': 'something'
    }

    # Mock objects
    class MockTask():
        def __init__(self):
            self.args = args
    class MockModule():
        def __init__(self):
            self.params = args
    action = ActionModule()
    action._task = MockTask()
    action._task.action = MockModule()

    # Test ActionModule.__init__
    fail_msg = action._task.action.params.get('fail_msg', action._task.action.params.get('msg'))
    success_msg = action._task.action.params.get('success_msg')

# Generated at 2022-06-21 01:52:33.604960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    import pytest
    pytest.main('-v')

# Generated at 2022-06-21 01:52:43.332550
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest
    import ansible.playbook.task
    import ansible.runner

    class MockTemplar:
        def __init__(self):
            self.fail_msg = None
            self.success_msg = None

        def template(self, fail_msg):
            self.fail_msg = fail_msg
            return fail_msg

        def template(self, success_msg):
            self.success_msg = success_msg
            return success_msg

    class MockRunner:
        def __init__(self):
            self.task_vars = dict()

    class MockTask:
        def __init__(self):
            self.args = dict()

    class MockLoader:
        def __init__(self):
            self.paths = None

    # Test if all assertions passed
    task = MockTask()