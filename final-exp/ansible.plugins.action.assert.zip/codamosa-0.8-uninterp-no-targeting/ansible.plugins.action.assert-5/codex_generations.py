

# Generated at 2022-06-21 01:45:20.461045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    itask = Task()
    itask.action = 'assert'
    itask.args = {'that':'{{ 1 == 2 }}', 'msg':'{{ 1 == 2 }} is {{ False }}'}
    c = ActionModule(loader=loader, task=itask)
    assert c is not None


# Generated at 2022-06-21 01:45:29.880717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_source =  dict(
        name = "Test Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='assert', fail_msg='Test Play Failed', success_msg='Test Play Succeeded', that=dict(static='Test Play Task') ), register="test")
        ]
    )

    from ansible.playbook.play import Play

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:45:32.147787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for the ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:45:39.404326
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestActionModule():
        def __init__(self):
            self.ansible_lib = True
            self.module_name = 'assert'
            self.action = 'fail'
            self.runner_on_failed = None
            self.runner_on_ok = None
            self.runner_on_skipped = None
            self.task_vars = {}
            self._task = None
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    from ansible.plugins.loader import connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.plugins import module_loader
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-21 01:45:50.136639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.manager import ActionModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import pytest
    import json


# Generated at 2022-06-21 01:46:00.943298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    import ansible.module_utils.parsing.convert_bool

# Generated at 2022-06-21 01:46:11.227201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object under test
    action_module = ActionModule(None, None, None, {})

    # Set up some test data
    task = {'args': {'fail_msg': 'Assertion failed', 'quiet': False, 'that': 'is_enabled_resolver_service'},
    'registered': 'is_enabled_resolver_service', 'when': [True]}

    # Test without fail_msg/msg
    task_no_fail_msg = {'args': {'quiet': False, 'that': 'is_enabled_resolver_service'},
    'registered': 'is_enabled_resolver_service', 'when': [True]}


# Generated at 2022-06-21 01:46:18.362186
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case with simple string and success
    my_task = SimpleNamespace()
    my_task.action = 'assert'
    my_task.args = {'that': '2 == 2', 'msg': 'test1', 'quiet': True}
    my_actionModule = ActionModule(my_task, {})

    result = my_actionModule.run()

    assert result == {
        'failed': False,
        'changed': False,
        'msg': 'test1'
    }

    # Test case with list and failure
    my_task = SimpleNamespace()
    my_task.action = 'assert'
    my_task.args = {'that': '2 == 3'}
    my_actionModule = ActionModule(my_task, {})

    result = my_actionModule.run()


# Generated at 2022-06-21 01:46:24.914426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task as task
    import ansible.playbook.play_context as play_context
    import ansible.utils.template as template

    module = __import__('ansible.plugins.action.assert', fromlist=['ActionModule'])
    play_context = play_context.PlayContext()
    loader = None
    templar = template.Templar(loader=loader)

    # Action module without fail_msg or msg argument
    task = task.Task(
        name='test_action_module_without_fail_msg_or_msg_argument',
        action='assert',
        args=dict(that=['1 > 5', '1 == 2', '1 == 1']),
        play_context=play_context
    )

# Generated at 2022-06-21 01:46:37.138249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock module
    mock_module = type('TestModule', (object,), {})()
    mock_module.debug = False
    mock_module.deprecated = False
    mock_module.check_mode = False

    # Mock loader
    mock_loader = type('TestLoader', (object,), {})()
    mock_loader.load_from_file = None
    # No test for loader.get_basedir. It requires mocking a host and task, which is overkill.

    # Mock templar
    mock_templar = type('TestTemplar', (object,), {})()
    mock_templar.template = None
    mock_templar.template = None

    # Mocks the task, required by AnsibleTask._get_task_vars

# Generated at 2022-06-21 01:46:52.463053
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:47:03.123154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import Facts
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-21 01:47:04.142170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(args=dict(msg='failed', that='foo')))

# Generated at 2022-06-21 01:47:11.958294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("testing ActionModule run")
    #testing fail_msg field
    fail_msg = 'assertion failed'
    success_msg = 'assertion passed'
    that = 'inventory_hostname == "localhost"'
    task_vars = {'inventory_hostname' : 'localhost'}
    action = ActionModule()
    action._task.args = {'fail_msg' : fail_msg, 'success_msg' : success_msg, 'that' : that}
    action._templar = FakeTemplar()
    action._task.action = 'assert'
    action._loader = FakeLoader()
    result = action.run(task_vars=task_vars)
    assert 'msg' in result
    assert result['msg'] == success_msg
    assert 'changed' in result
    assert result['changed'] == False

# Generated at 2022-06-21 01:47:22.941486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = {
        'action': 'assert',
        'args': {'test': 'test_assert'},
        'local_action': 'assert',
        'register': 'registered_var'
    }

    test_included_var = dict(test_var=1, ansible_facts=dict(ansible_facts1='foo', ansible_facts2='bar'))
    test_play_context = dict(play_context1='foo', play_context2='bar')
    test_task_vars = dict(task_vars1='foo', task_vars2='bar')

    test_loader = 'test_loader'
    test_templar = 'test_templar'
    test_shared_loader_obj = 'test_shared_loader_obj'

    test_ansible_module_obj

# Generated at 2022-06-21 01:47:25.006387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule and run it
    assert ActionModule().run() is not None

# Generated at 2022-06-21 01:47:31.901068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include
    import ansible.utils.template
    import ansible.playbook.role.include
    import ansible.playbook
    import ansible.vars.manager
    import ansible.playbook.play
    import ansible.inventory.manager
    import ansible.playbook.block
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    inventory = ansible.inventory.manager.Inventory(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 01:47:40.929236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
            'fail_msg',
            {
                'fail_msg': 'You shall not pass.',
                'that': ['some_var is not defined', 'some_other_var == 123'],
            },
            load_fixture('dummy_action_plugin'),
            '/my/files',
            {}
        )
    assert module.fail_msg == "You shall not pass."
    assert module.thats == ['some_var is not defined', 'some_other_var == 123']



# Generated at 2022-06-21 01:47:46.701304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor will be called by Ansible's internal API
    #import ansible.plugins.action
    #action = ansible.plugins.action.ActionModule(loader=None, task=None, connection=None)
    action = ActionModule(loader=None, task=None, connection=None)
    # TODO: Add assert tests

# Generated at 2022-06-21 01:47:53.428888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    import json

    class MockV2Task(object):
        def __init__(self, args):
            self.args = args
            self.name = 'test task'

    class MockV2Play(object):
        def __init__(self):
            self.vars = dict()
            self.options = dict()


    class MockV2VariableManager(object):
        def __init__(self):
            self.vars = dict()
            self.extra_vars = dict()
            self.host_vars = dict()


# Generated at 2022-06-21 01:48:18.738651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("started")
    tmp = None
    task_vars = None
    fail_msg = None
    msg = None
    quiet = False
    success_msg = None
    that = None

    # Test1 : fail_msg as a list
    fail_msg = ['Assertion failed', 'Assertion failed2', 'Assertion failed3']

    # Test2 : fail_msg as a string with different set of options
    #fail_msg = 'Assertion failed'

    # Test3 : fail_msg as an int
    #fail_msg = 10

    # Test4 : success_msg as a list
    #success_msg = ['Assertion passed', 'Assertion passed2', 'Assertion passed3']

    # Test5 : success_msg as a string with different set of options
    #success_msg = '

# Generated at 2022-06-21 01:48:28.106143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, path=None, play_context=None, new_stdin=None)
    # validated frozenset _VALID_ARGS
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that')), \
        'The _VALID_ARGS is not equal to the expected value.'
    # validated TRANSFERS_FILES
    assert not action_module.TRANSFERS_FILES, \
        'The \'True\' is not equal to the expected value \'False\'.'


# Generated at 2022-06-21 01:48:31.888987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    r = ActionModule()
    assert r, 'Class ActionModule construction failed'
    assert r._VALID_ARGS, 'Frozenset _VALID_ARGS construction failed'

# Generated at 2022-06-21 01:48:37.699921
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def mock_load_data(self, data):
        return 'test_data'

    class MockConditional:
        def __init__(self, loader):
            pass

        def evaluate_conditional(self, templar, all_vars):
            return 'test_result'

    class MockTemplar:
        def __init__(self, loader, variables=None):
            pass

    class MockLoader:
        pass

    m = ActionModule()
    m._connection = Mock()
    m._connection_loader = MockLoader()
    m._play_context = Mock()
    m._play_context.check_mode = False
    m._task = Mock()
    m._task.action = 'assert'

# Generated at 2022-06-21 01:48:48.376560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class dummyTask():
        pass
    class dummyPlaybook():
        pass
    class dummyCLI():
        def verbosity(self):
            return 5
    class dummyLoader():
        def load_from_file(self, filename):
            return False
    class dummyTemplar():
        def template(self, filename):
            return False
    class dummyModuleUtils():
        def _parse_params(self, params):
            return False
        def _fail_json(self, msg):
            return False
        def _handle_aliases(self, params):
            return False
        def _get_path_dist(self, distro, path_type):
            return False

    task = dummyTask()
    task.args = {'that': '1 == 1', 'msg': 'Error message'}

    playbook = dummyPlaybook()

# Generated at 2022-06-21 01:48:59.070584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import pytest

    p = PlayContext()
    p.remote_addr = '192.168.0.1'
    i = InventoryManager(loader=DataLoader(), sources='localhost,')
    h = Host(name='hostname')
    g = Group(name='groupname')
    g.add_host(h)
    i.add_group(g)


# Generated at 2022-06-21 01:49:09.819760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule(loader=None, templar=None, shared_loader_obj=None)

    test_action_module_args = dict(
        fail_msg='Assertion failed',
        msg='Assertion failed',
        quiet=False,
        success_msg='All assertions passed',
        that=['some_condition == "ok"']
        )

    task_vars = dict(some_condition='ok')

    actual_result = test_action_module._execute_module(module_name=None, module_args=test_action_module_args, task_vars=task_vars)


# Generated at 2022-06-21 01:49:21.155172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg1 = dict(fail_msg='Assertion failed')
    arg2 = dict(fail_msg=dict(test1='Assertion failed'))
    arg3 = dict(fail_msg=[dict(test1='Assertion failed')])
    arg4 = dict(fail_msg=list())

    args_list = [arg1, arg2, arg3, arg4]

    for args in args_list:
        assert not ActionModule(loader=None, task=dict(args=args)).run(tmp=None, task_vars=None)['failed']

    arg1 = dict(success_msg='All assertions passed')
    arg2 = dict(success_msg=dict(test1='All assertions passed'))
    arg3 = dict(success_msg=[dict(test1='All assertions passed')])

# Generated at 2022-06-21 01:49:31.527896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_1
    task_vars = {"a": 10, "b": 20, "c": "hello", "ansible_debug": True}
    task_args = {"msg": "Assertion failed", "that": ["a == 10", "b != 11", "c == 'hello'"]}

    test_action_module = ActionModule(task_args=task_args, task_vars=task_vars)

    test_result = test_action_module.run()
    assert test_result.get('assertion') == "a == 10"
    assert (test_result.get('evaluated_to') == "False")
    assert 'failed' in test_result

    # test_case_2
    task_vars = {"a": "A string", "b": "B string"}

# Generated at 2022-06-21 01:49:32.501632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:50:10.096781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    tqm = TaskQueueManager(
        inventory=InventoryManager(host_list='/etc/ansible/hosts'),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    play_context = PlayContext()

    task = Task()
    task.action = 'fail'
    task.args = dict(msg='Failed')

    fail_action_module = ActionModule(task, play_context, tqm)
    result = fail_action_module.run(task_vars={})
    assert result['failed']

# Generated at 2022-06-21 01:50:10.594483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:50:16.652386
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:50:21.451678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert not action.TRANSFERS_FILES
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-21 01:50:22.274581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:50:27.965010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MockActionBase(object):
        class MockData(object):
            class MockTask(object):
                args = {'that': '1'}
        def __init__(self):
            self._task_vars = {}
            self._task = self.MockData.MockTask()
            self._loader = None
            self._templar = None
            self._result = TaskResult(self._task, None)

        def run(self, *args, **kwargs):
            return self._result


# Generated at 2022-06-21 01:50:33.720699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')
    # it's okay to use None for task_vars in this test
    action = ActionModule(None, dict(msg=None), None, None, None)

    try:
        action._check_argspec()
    except:
        print('FATAL: Failed _check_argspec()!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 01:50:44.911416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, dict(),
                      { 'msg': 'Assertion failed',
                        'quiet': False,
                        'that': 'any_string',
                        'success_msg': 'All assertions passed' },
                      None)

    try:
        am.run()
        assert False
    except AnsibleError:
        pass

    am = ActionModule(None, dict(),
                      { 'msg': 'Assertion failed',
                        'quiet': False,
                        'that': [ 'any_string', 'any_other_string'],
                        'success_msg': 'All assertions passed' },
                      None)

    assert am.run() == { 'changed': False, 'msg': 'All assertions passed' }


# Generated at 2022-06-21 01:50:56.652916
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    def run(tmp=None, task_vars=None):
        return {"_ansible_verbose_always": True}

    def load_file(filepath):
        return filepath

    def templar(template,  all_vars=dict(), **kwargs):
        return "True"

    class C:
        """Simple class for mocking the Conditional class"""

        def __init__(self, **kwargs):
            self.when = "True"

        def evaluate_conditional(self, templar=None, all_vars=None):
            return "True"

    C.__name__ = "Conditional"
    C.__name__ = "Conditional"
    # Act
    action_module = ActionModule()
    action_module.run = run

# Generated at 2022-06-21 01:51:07.211801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a1 = ActionModule(None, {'_ansible_check_mode': True, '_ansible_no_log': True}, loader=None)
    assert a1 is not None
    assert a1.transfers_module is False
    assert a1.valid_args == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    assert a1.no_log == True
    assert a1.check_mode == True

    a2 = ActionModule(None, {'_ansible_check_mode': False, '_ansible_no_log': False}, loader=None)
    assert a2 is not None
    assert a2.transfers_module is False

# Generated at 2022-06-21 01:52:29.066555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for fail_msg
    fail_msg = ['test_fail_msg1', 'test_fail_msg2']
    success_msg = 'test_success_msg'
    task_vars = {'test_var': 'test_val'}
    mock_loader = None
    mock_templar = None

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=mock_loader, templar=mock_templar, shared_loader_obj=None)
    # test for fail msg - case when fail_msg is a list
    result = action_module.run(None, task_vars=task_vars, fail_msg=fail_msg, success_msg=success_msg)
    assert result['failed']
    assert result['msg'] == fail_msg



# Generated at 2022-06-21 01:52:33.195500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-21 01:52:43.065258
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class AnsibleTestModule(ActionModule):
        def __init__(self, args=dict()):
            pass

        def run(self, tmp=None, task_vars=dict()):
            self._tmp = tmp
            self._task_vars = task_vars
            return dict()
    # Instantiate class object to run tests on
    m = AnsibleTestModule()

    # positive tests

    # test that a that value is not a list and that it is evaluated as false
    task_args = dict(that=False)
    task_vars = dict()
    result = m.run(None, task_vars=task_vars)
    assert result['failed'] == True

    # test that a that value is a list of booleans and that they are all evaluated as false

# Generated at 2022-06-21 01:52:55.616240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(args=dict(that=['a == b', 'b != c'],
                                              success_msg='ok',
                                              fail_msg='fail',
                                              quiet=False)),
                          connection=None,
                          play_context=dict(check_mode=False),
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)

# Generated at 2022-06-21 01:52:56.378008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 01:53:05.743534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    module_args = {
        '_ansible_syslog_facility': 'LOG_LOCAL0',
        '_ansible_syslog_ident': 'test-action-module',
        '_ansible_no_log': False,
        '_ansible_verbose_always': True,
        'that': ["{{ foo }} == 'bar'", "{{ baz }} == 'qux'"],
        'fail_msg': 'Foo and Bar are NOT equal',
        'success_msg': 'Success'
    }

    module = AnsibleModule(argument_spec=module_args)
    action_module = ActionModule(module)

# Generated at 2022-06-21 01:53:07.087408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:53:16.992201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    assert isinstance(action.ActionModule, type)

    task = Task()
    task._role = None
    task.args = {'that':'junk'}
    task._parent = Play()
    task._role = None
    task._block = Block()

    action_module = action.ActionModule(task, dict())
    del action_module
    action_module = action.ActionModule(task, dict())
    del action_module

    # Test function run with invalid args
    task.args = {}
    action_module = action.ActionModule(task, dict())

# Generated at 2022-06-21 01:53:26.509340
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:53:36.706132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import module_loader
    module_loader.add_directory('./lib')
    module_loader.add_directory('./my_plugins/action')
    module_loader.add_directory('./my_plugins/module')
    task_vars = dict()
    g_testbed_name = 'testbed'
    g_device_name = 'test_ssh'
    g_testbed = dict()

    g_testbed = dict()
    g_testbed['name'] = g_testbed_name
    g_testbed['devices'] = dict()
    g_testbed['devices'][g_device_name] = dict()
    g_device_data = dict()
    g_device_data['host'] = 'localhost'
    g_device_data['username'] = 'root'
