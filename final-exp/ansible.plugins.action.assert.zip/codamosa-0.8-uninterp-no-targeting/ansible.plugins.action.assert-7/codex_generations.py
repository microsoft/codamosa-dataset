

# Generated at 2022-06-21 01:45:16.931746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task


    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager


    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess


    class MockDisplay:
        def display(self, msg, *args, **kwargs):
            pass

    #Execute run method of the class ActionModule and assert the output
    def test_run(self, module_name = "ansible.plugins.action.assert", module_args = '', task_vars = dict(), inject = dict()):
        # initialize needed objects
        loader = DictDataLoader({module_name: dict(path='/dev/null')})
        variable_manager = VariableManager()


# Generated at 2022-06-21 01:45:28.439195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest2 as unittest

    class TestActionModule(unittest.TestCase):

        def test_ActionModule_run_1(self):
            task_vars = dict()
            action_module = ActionModule(
                task=dict(
                    args=dict(
                        that=['that.stdout.find("100") == -1'],
                        msg=['msg val'],
                    ),
                    name='test'
                ),
                task_vars=task_vars,
            )
            action_module._templar = None

            r = action_module.run(None, None)
            self.assertTrue(r['failed'])
            self.assertFalse(r['evaluated_to'])

# Generated at 2022-06-21 01:45:39.557274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test when fail_msg is provided and assertion fails
    action = ActionModule()
    that = {"test_action": "fail"}
    fail_msg = "Assertion failed"
    args = {"fail_msg": fail_msg, "that": that, "_ansible_version": 2.5,
            "_ansible_check_mode": False, "_ansible_no_log": False, "_ansible_debug": False}
    result = action.run(tmp=None, task_vars=None, **args)
    assert result["failed"]
    assert result["msg"] == fail_msg

    # test when success_msg is provided and assertion passes
    action = ActionModule()
    that = {"test_action": "pass"}
    success_msg = "All assertions passed"

# Generated at 2022-06-21 01:45:40.063876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:45:48.194401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(task=dict(args=dict(that='{{ ansible_architecture }} == "x86_64"', fail_msg='Assertion failed', success_msg='All assertions passed')), task_vars=dict(ansible_architecture='x86_64'))
    result = m.run()
    assert result == {'assertion': '{{ ansible_architecture }} == "x86_64"',
                      'changed': False,
                      'evaluated_to': True,
                      'msg': 'All assertions passed',
                      'skipped': False}
    del m



# Generated at 2022-06-21 01:45:48.948055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:45:55.729972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None)
    res = action_module.run(task_vars={})
    assert 'changed' in res
    assert 'msg' in res
    assert 'failed' in res
    assert 'evaluated_to' in res
    assert 'assertion' in res

# Generated at 2022-06-21 01:45:57.697788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 01:46:00.766343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule != ActionBase
    assert issubclass(ActionModule, ActionBase)


# Generated at 2022-06-21 01:46:03.063040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception as e:
        print("ActionModule has error: ", e)

# Generated at 2022-06-21 01:46:11.925568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:46:20.429449
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils.six import StringIO

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor import task_queue_manager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook.block import Block

    class TestStrategy(StrategyBase):

        def run(self, iterator, play_context):
            return iterator

    class TestTask(Task):
        """ A task that tests the ability of the strategy to get
            the correct variables
        """

# Generated at 2022-06-21 01:46:29.765058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task = dict(args = {
            'fail_msg': 'This is an error message',
            'success_msg': 'This is a success message',
            'quiet': False,
            'that': 'is this a test?'
        }),
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None)

    assert isinstance(action, ActionModule)
    assert isinstance(action._task, dict)
    assert isinstance(action._task['args'], dict)
    assert action._task['args']['fail_msg'] == 'This is an error message'
    assert action._task['args']['success_msg'] == 'This is a success message'

# Generated at 2022-06-21 01:46:40.052210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 01:46:40.921051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:46:43.064690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test ActionModule """
    action = ActionModule()
    assert action._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

# Generated at 2022-06-21 01:46:50.113842
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:47:02.391491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    class MockVariable(VariableManager):
        def __init__(self):
            self.vars = dict()

        def set_variable(self, name, value):
            self.vars[name] = value

    variable_manager = MockVariable()

    loader = DataLoader()

    # if os.path.exists(os.path.join(os.path.dirname(__file__), '../../inventory')):
    #     inventory = Inventory(loader=loader, variable_manager=variable_

# Generated at 2022-06-21 01:47:11.987137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=object())

    action.task._task.args = {'fail_msg': 'Failed', 'that': ['test']}
    test_result = action.run(task_vars={'test': False})
    assert test_result['failed'] == True
    assert test_result['msg'] == 'Failed'
    assert test_result['evaluated_to'] == False
    assert test_result['assertion'] == 'test'

    action.task._task.args = {'fail_msg': ['Failed1', 'Failed2', 'Failed3'], 'that': ['test']}
    test_result = action.run(task_vars={'test': False})
    assert test_result['failed'] == True

# Generated at 2022-06-21 01:47:22.949577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import tempfile
    import textwrap
    import yaml
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    class TestPlaybookExecutor:

        def __init__(self, loader, variable_manager, host_list, play):
            self._loader = loader
            self._variable_manager = variable_manager
            self._host_list = host_list
            self._play = play
            self._tqm = None

        def run(self):
            self

# Generated at 2022-06-21 01:47:38.875515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No tests for ActionModule.run"


# Generated at 2022-06-21 01:47:50.596773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_source = dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='assert', that='foo', success_msg=['ok']), register='result')
               ]
        )
    play = Play().load(play_source, variable_manager=variables, loader=loader)

    # Patch

# Generated at 2022-06-21 01:47:59.123697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit testing for method run on class ActionModule '''

    # create test variables
    (tmp, task_vars) = (None, dict())

    # create a test ActionModule
    this_module = ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # set run return values
    this_module.run = ActionBase.run
    this_module.run.return_value = dict(failed=False, msg='')

    # set module args
    this_module._task.args = dict(msg='all assertions passed')

    # test with no 'when' argument
    try:
        this_module.run(tmp, task_vars)
    except AnsibleError:
        pass

# Generated at 2022-06-21 01:48:07.128122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict()
    result['_ansible_verbose_always'] = True
    result['failed'] = False
    result['assertion'] = '2 == 1'
    result['evaluated_to'] = False
    result['msg'] = 'Assertion failed'
    actionmodule = ActionModule()
    assert actionmodule.run(result['_ansible_verbose_always'],result['failed'],result['assertion'],result['evaluated_to'],result['msg']) == True

# Generated at 2022-06-21 01:48:18.806359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = {}
    result['evaluated_to'] = True
    result['msg'] = "All assertions passed"
    assert am.run(tmp=None, task_vars=None) == result
    
    #Result when conditional is true
    result['evaluated_to'] = False
    result['msg'] = "Assertion failed"
    result['failed'] = True
    result['assertion'] = "false"
    assert am.run(tmp=None, task_vars={"ansible_hostname":"host1","hostvars":{"host1":{"exists":"file"}}}) == result

    #Result when conditional is True and custom messages are passed

# Generated at 2022-06-21 01:48:27.258993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test variables
    ansible_vars = {}
    ansible_fail_json = {}
    ansible_play_context = {}

    # Create instance of class ActionModule
    action_module = ActionModule(
        ansible_vars,
        ansible_fail_json,
        ansible_play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Create test args for method run
    tmp = None
    task_vars = {}

    # Test 'that' not in self._task.args
    # Test that msg is 'Assertion failed'
    # Test that evaluated_to is None
    # Test that assertion is None
    # Test that failed is False
    # Test that msg is 'All assertions passed'
    # Test that changed is False


# Generated at 2022-06-21 01:48:29.453963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    print(x)

# Generated at 2022-06-21 01:48:34.888435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        x = ActionModule()
    except:
        print("Cannot initialize ActionModule class, possible reasons might be"
              " a change in constructor has been applied to the ActionModule"
              " class and hence this test needs to be updated to reflect"
              " the changes.")
        raise

# Generated at 2022-06-21 01:48:35.664793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Unit test not implemented"

# Generated at 2022-06-21 01:48:42.363192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule from the module source file
    am = ActionModule()

    # Check various properties of the instance
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))


# Generated at 2022-06-21 01:49:22.676009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy class for post_validate
    class DummyClass(object):
        pass
    # Dummy class for task
    class TaskClass(object):
        pass
    # Dummy class for result
    class ResultClass(object):
        pass
    # Dummy class for loader
    class LoaderClass(object):
        pass
    # Dummy class for templar
    class TemplarClass(object):
        pass
    # Dummy class for tmp
    class TmpClass(object):
        pass
    # Dummy class for task_vars
    class TaskVarsClass(object):
        pass

    # Constructor without argument
    fail = ActionModule()
    assert fail
    assert fail.TRANSFERS_FILES == False
    # Assign values to variables of fail
    fail.post_validate = DummyClass

# Generated at 2022-06-21 01:49:32.649940
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:49:33.510043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:49:45.475035
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import os
    import unittest
    import mock
    import StringIO

    sys.path.insert(0, os.path.dirname(__file__))
    sys.path.insert(1, os.path.dirname(os.path.dirname(__file__)))

# Generated at 2022-06-21 01:49:51.280893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    n = ActionModule('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')
    assert n._result == {}
    assert n._task.action in n._VALID_ARGS
    assert n.invalid
    assert n._task.action in n._VALID_ARGS
    assert n.invalid

# Generated at 2022-06-21 01:50:01.087901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import urlparse, urlunparse
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.utils.encrypt import do_encrypt
    from ansible.utils.encrypt import do_decrypt
    import ansible.utils.json_dict as json_dict
    import ansible.utils.template as template
    import copy
    import json
    import os


# Generated at 2022-06-21 01:50:04.983190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # See if parameter tmp is not empty
    action = ActionModule()
    assert action.tmp is None
    assert action.task_vars is None



# Generated at 2022-06-21 01:50:07.407126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule({}, {}, {}, {}, {})
    assert t._task == {}
    assert t._play_context == {}
    assert t._loader == {}
    assert t._templar == {}
    assert t._shared_loader_obj == {}

# Generated at 2022-06-21 01:50:14.195775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Play

    play_context = Play().load({}, variable_manager={}, loader=None)
    task = Task()
    block = Block()
    play_context._config_module = lambda: {'DEFAULT_DEBUG': False}
    task._block = block
    task._role = None
    task._loader = None
    task._play_context = play_context
    task.action = 'skip'

    action_module = ActionModule(task, play_context)
    task.args = {'quiet': False}

    # Run and positive test
    task.args['that'] = ['1==1', '2>1']
    assert action_module.run()['msg'] == 'All assertions passed'



# Generated at 2022-06-21 01:50:21.173831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=dict(args=dict(fail_msg='test fail msg', quiet='test quiet', success_msg='test success msg', that='test that')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert actionModule


# Generated at 2022-06-21 01:51:45.321976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:51:54.938630
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    a = ActionModule()
    temparr = [{}, {}]
    temparr[0]['myvar'] = "myvalue"
    temparr[0]['myvar2'] = "myvalue2"
    taskarr = { "when" : "myvar == myvalue and myvar2 == myvalue2" }
    print(a.run(None, temparr[0]))

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-21 01:52:01.815591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='assert',
                              local_action=dict(module_name='assert'),
                              args=dict(fail_msg='task_fail_msg', msg='task_msg',
                                        success_msg='task_success_msg', that='task_that'))),
        connection=None,
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 01:52:12.699488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    host = Host(name='test1')
    group = Group(name='all')
    group.add_host(host)

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[host])

    task = Task()
    task.name = 'fail-test'
    task.action = 'assert'

# Generated at 2022-06-21 01:52:19.989362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import inspect
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))))
    from ansible.plugins.action.assertion import ActionModule

    testobj = ActionModule(None)

    testobj._task.args['fail_msg'] = "fail message"
    testobj._task.args['that'] = [{"somekey":True}]

    result = testobj.run(None,{"somekey":True})
    assert result['failed'] == False

    testobj._task.args['that'] = [{"somekey":False}]
    result = testobj.run(None,{"somekey":True})
    assert result['failed'] == True

# Generated at 2022-06-21 01:52:29.985912
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # This is a mock object, which mocks the 'get_connection' function of the
    # ActionBase class. This is done to avoid making actual connection to remote host
    class ConnectionMock(object):

        # the connection class needs to have a run function, which executes the module
        # this is a mock function
        def run(self, module_name, module_args=None, task_vars=None):
            # the actual module execution is not performed
            return {}

        def __init__(self, runner):
            pass

    # this is a mock object, which mocks the 'ActionBase' class
    class ActionBaseMock(ActionBase):

        # the 'get_connection' function will be mocked and will return the 'ConnectionMock' object
        def get_connection(self, play_context, var_manager):
            connection_mock

# Generated at 2022-06-21 01:52:41.069232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase # Import to make ActionBase class accessible.

# Generated at 2022-06-21 01:52:44.826824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), "../"))
    import ansible.plugins

# Generated at 2022-06-21 01:52:50.935489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy class for testing, inherits from ActionBase
    class ActionModuleTest(ActionModule):
        pass

    # Test 1: check that arguments that are not valid are correctly returned
    assert(ActionModuleTest._VALID_ARGS)

# Generated at 2022-06-21 01:52:53.412001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass