

# Generated at 2022-06-21 01:45:27.181296
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Single fail message, no success message
    task = type('obj', (object,), {
        'args': {
            'fail_msg': 'This task has failed',
            'that': [
                "hostvars['test_host1']['test_var'] == 'correct_value'",
                "hostvars['test_host2']['test_var'] == 'correct_value'",
            ],
        },
        '_templar': type('obj', (object,), {
            'template': lambda x: x
        })()
        })

# Generated at 2022-06-21 01:45:39.118568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Imports
    ##########
    import pytest
    import ansible.errors as ansible_errors
    import ansible.module_utils.parsing.convert_bool as ansible_convert_bool


# Generated at 2022-06-21 01:45:43.129856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_str = """
- hosts: localhost
  gather_facts: false
  tasks:
    - name: test assert
      assert:
        that:
          - 1 == 2
"""
    am = ActionModule()
    assert am.run(yaml_str, task_vars={})['failed']

# Generated at 2022-06-21 01:45:51.587226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup and call
    task = {}
    setattr(task, 'args', {})

    # Test action module
    module = ActionModule(task, ansible_host='localhost', ansible_root='/tmp/foo',
            ansible_playbook='', ansible_connection='ssh', antible_ssh_pass='',
            ansible_ssh_port=22, ansible_user='', ansible_become='no', ansible_become_pass='',
            ansible_become_exe='', ansible_become_flags='-l')

    # Test return value
    assert isinstance(module.run(), dict)

# Generated at 2022-06-21 01:46:01.456613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test: Method run raises error if conditional is not defined in that
    #     : ArgumentError: conditional required in "that" string
    task_src = dict(action=dict(module='assert', args=dict(that='')))
    play_context = dict(become=False)
    task = AnsibleTask(task_src, play_context, loader=None, templar=None, shared_loader_obj=None)
    assert_raises(AnsibleError, ActionModule(task, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None).run)

    task_src = dict(action=dict(module='assert', args=dict(that='result.rc == 0')))
    play_context = dict(become=False)
    task = AnsibleTask

# Generated at 2022-06-21 01:46:09.396441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test ActionModule constructor'''

    # Construct a mock class representing the Ansible module utils ModuleFailJson exception.
    class ModuleFailJson(Exception):
        '''Mock class for Ansible module utils ModuleFailJson'''
        def __init__(self, *args, **kwargs):
            super(ModuleFailJson, self).__init__(*args, **kwargs)

    # Construct a mock class representing the AnsibleError exception.
    class AnsibleError(Exception):
        '''Mock class for AnsibleError'''
        def __init__(self, *args, **kwargs):
            super(AnsibleError, self).__init__(*args, **kwargs)

    # Construct a mock class representing the AnsibleModule exception.

# Generated at 2022-06-21 01:46:11.969661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action

# Generated at 2022-06-21 01:46:18.806432
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.playbook
    import ansible.utils.template
    import ansible.vars

    class FakeLoader():
        ''' This Fake Loader class is used to return a tree of AnsibleTask objects to test
            the ActionModule class.
        '''

        def __init__(self):
            pass

        def load_from_file(self, _):
            ''' we don't have a real file to parse, so just return a list of simple task objects '''

            simple_task = ansible.playbook.Task()
            simple_task._role = None
            simple_task.action = 'setup'
            simple_task.args = {}

            return [simple_task]

    class FakeVarsModule():
        ''' This Fake Variables Module class is used to return a dict for hostvars and vars '''

       

# Generated at 2022-06-21 01:46:27.713195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # idempotency test
    obj1 = ActionModule(task=dict(action=dict(module_name='assert_that')))
    obj2 = ActionModule(task=dict(action=dict(module_name='assert_that')))

    assert obj1.__reduce__() == obj2.__reduce__()

    assert isinstance(obj1, ActionModule)
    assert isinstance(obj2, ActionModule)

    #
    # Verify that the class is hashable
    #
    assert isinstance(obj1, ActionModule)
    assert isinstance(obj2, ActionModule)



# Generated at 2022-06-21 01:46:39.339110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task=Task(), connection=Connection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 01:46:51.678417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case = dict(
        fail_msg='Assertion failed',
        success_msg='All assertions passed',
        quiet=False,
        task_vars={},
    )
    # Create an instance of AnsibleModule to be able to access AnsibleModule.exit_json method inside run
    fake_ansible_module = AnsibleModule(argument_spec=dict())

    # Create an instance of ActionModule without the constructor's parameters
    test_instance = ActionModule(fake_ansible_module)
    test_instance._loader = DictDataLoader({})
    test_instance._templar = Templar(variables=dict())
    test_instance._task = Task()

# Generated at 2022-06-21 01:46:57.660313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            result = super(ActionModule, self).run(tmp, task_vars)
            return result

    action_module = TestActionModule()

    fail_msg = "Assertion failed"
    success_msg = "All assertions passed"
    test_quiet = True
    test_conditions = ["attrib1", "attrib2", "attrib3"]
    false_condition = "false_condition"
    expected_result = "msg"


# Generated at 2022-06-21 01:47:09.805251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Without fail_msg or msg keys in args dict
    assert ActionModule.run(ActionModule(), dict(), dict())['msg'] == 'Assertion failed'

    # With fail_msg key in args dict and fail_msg as a string
    assert ActionModule.run(ActionModule(), dict(), dict(), dict(args=dict(fail_msg='Custom assertion failed message')))['msg'] == 'Custom assertion failed message'

    # With fail_msg key in args dict and fail_msg as a list
    assert ActionModule.run(ActionModule(), dict(), dict(), dict(args=dict(fail_msg=['Custom assertion failed message', 'Another custom message'])))['msg'] == 'Custom assertion failed message'

    # With msg key in args dict and msg as a string

# Generated at 2022-06-21 01:47:16.271994
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Try to create a ActionModule object with required arguents
  try:
    actionModule = ActionModule(None, None, None, None, None, None)
  except:
    # Assert that the ActionModule object is not created
    assert(False)
  
  # Assert that the ActionModule object is created
  assert(True)

# Generated at 2022-06-21 01:47:20.724535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  
  # Create an instance of class ActionModule
  action_module = ActionModule()

  # Test that an error is raised when 'that' string
  # is not passed in
  try:
    action_module.run()
  except AnsibleError:
    pass
  else:
    raise Exception("Expected AnsibleError to be raised")

# Generated at 2022-06-21 01:47:29.651056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))

    test_action_module = ActionModule(loader=None,
                                      templar=None,
                                      shared_loader_obj=None)
    assert test_action_module._templar == None
    assert test_action_module._loader == None
    assert test_action_module._shared_loader_obj == None

# Generated at 2022-06-21 01:47:42.063392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'_ansible_check_mode': False, '_ansible_verbosity': 2, '_ansible_no_log': False, 'changed': False, '_ansible_item_label': 'mystring'}, {'vars': {'myvar': 'success'}}, '/path/to/myplaybook.yml')
    action._templar = None
    action._task = None
    action._loader = None
    res = action.run("tmp", {})
    assert res == {'changed': False, 'msg': 'All assertions passed', '_ansible_verbose_always': True}, "result is %s" % (res)


# Generated at 2022-06-21 01:47:43.823945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests for ActionModule.run
    pass

# Generated at 2022-06-21 01:47:52.479503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    # Create task object with variables
    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task._loader = loader
    task._variable_manager = VariableManager()
    task._templar = None
    task._task_vars = {}
    task.args = {}

    # Fail assert with message

# Generated at 2022-06-21 01:48:00.750411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import PlayBook
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a dummy task
    task = Task()
    # Set the action and args
    task.action = 'assert'
    task.args = { 'that': 'false'}
    task.args['fail_msg'] = 'False is always false'

    # Create a dummy block
    block = Block()
    # Set the task to the block
    block.task = task
    # Create a dummy play
    play = Play()
    # Set the block to the play
    play.block = block

    # Create a TaskQueueManager with a PlayBook, Inventory, and Play
   

# Generated at 2022-06-21 01:48:28.233620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Mocked variables
    class MockTemplar:
        def __init__(self, value):
            self._value = value

        def template(self, value, templar, all_vars):
            return self._value

    class MockConditional:
        def __init__(self, loader, value):
            self._value = value

        def evaluate_conditional(self, templar, all_vars):
            return self._value

    class MockTask:
        def __init__(self, ats, arg):
            self.args = arg
            self.action = ats

    class MockPlay:
        def __init__(self, play_iterator, play_context):
            self.iterator = play_iterator
            self.context = play_context


# Generated at 2022-06-21 01:48:29.637699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    print(mod.run())

# Generated at 2022-06-21 01:48:39.848370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fake the dict
    result = dict()
    result['failed'] = False
    result['changed'] = False

    # Fake the loader
    loader = dict()

    # Fake the templar
    templar = dict()

    # Fake the task
    task = dict()
    task['action'] = 'fail'
    task['args'] = dict()
    task['args']['msg'] = 'Ansible modules unit test'

    # Fake the ActionBase class
    action = dict()
    action['result'] = result
    action['_task'] = task
    action['_loader'] = loader
    action['_templar'] = templar

    # Initialize the object
    act = ActionModule()

    # Call the run method
    act.run(tmp=None, task_vars=None)

    #

# Generated at 2022-06-21 01:48:43.057028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('setup', 'localhost', 'test', 'test', dict())
    assert action is not None


# Generated at 2022-06-21 01:48:43.890738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:48:45.070123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    del action

# Generated at 2022-06-21 01:48:57.810340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.plugins.loader import action_loader

    class DataObject(AnsibleBaseYAMLObject):

        def __init__(self, data):
            super(DataObject, self).__init__()
            if isinstance(data, dict):
                self.data = data
            else:
                raise ValueError

    # Create the templar to render task.args.
    vars_manager

# Generated at 2022-06-21 01:49:00.809997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception as e:
        assert False and str(e)

# Generated at 2022-06-21 01:49:10.440603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            action=dict(
                fail_msg='Failed: %s'
            )
        )
    )
    result = module.run()
    assert result['failed'] == True
    assert result['msg'] == 'Failed: %s'

    module = ActionModule(
        task=dict(
            action=dict(
                fail_msg=['Failed', 'Failed again']
            )
        )
    )
    result = module.run()
    assert result['failed'] == True
    assert result['msg'] == 'Failed\nFailed again'

    module = ActionModule(
        task=dict(
            action=dict(
                success_msg='Success: %s',
                that='true'
            )
        )
    )

# Generated at 2022-06-21 01:49:15.042618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    # We need a task for the ActionBase constructor
    task = Task()

    # We need a dummy class with a run method
    class ActionModuleDummyClass():
        def run(self, tmp=None, task_vars=None):
            pass

    # Initialize our class
    action_module = ActionModule(ActionModuleDummyClass(), task,
                                 connection=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)

    assert type(action_module) == ActionModule
    assert type(action_module._VALID_ARGS) == frozenset



# Generated at 2022-06-21 01:49:53.506815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance for class ActionModule
    #_VALID_ARGS = frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that'))
    action = ActionModule(None)

    # call method run of class ActionModule without arguments
    # tmp and task_vars are None
    try:
        result = action.run(tmp=None, task_vars=None)
    except AnsibleError:
        result = {}
    assert 'failed' in result and result['failed'] == True

    # set arguments for method run
    action._task = {}
    action._task.args = {}
    
    # call method run with argument that
    try:
        result = action.run(tmp=None, task_vars=None)
    except AnsibleError: 
        result = {}

# Generated at 2022-06-21 01:49:54.378930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:50:02.191477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # initialize fixture
    #
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.facts.system.distribution import Distribution

    assert isinstance(ActionModule.run, object)

    #
    # parameters
    #
    tmp = None
    task_vars = {}
    Task.args = {}

    #
    # expected results
    #
    is_changed = False
    is_failed = False
    results = {}

    #
    # tests
    #

    # test_the_method_called_when_the_ssh_connection_

# Generated at 2022-06-21 01:50:11.524978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    result['assertion'] = '"a" == "a"'
    result['evaluated_to'] = True
    result['failed'] = False
    result['changed'] = False
    result['msg'] = 'All assertions passed'

    # test with a string

# Generated at 2022-06-21 01:50:23.259284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task

    def _mock_module_helper(module_name, *args, **kwargs):
        class MockModule():
            def __init__(self, *args, **kwargs):
                self.params = kwargs

        return MockModule(*args, **kwargs)

    class ActionModuleTest(ActionModule):
        def _execute_module(self, *args, **kwargs):
            return_object = _mock_module_helper(*args, **kwargs)
            return return_object

    task = Task()
    task_vars = dict(msg='Running tests')
    tmp = None

# Generated at 2022-06-21 01:50:34.210956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            args=dict(
                fail_msg="some message",
                msg="some message",
                quiet=True,
                success_msg="some message",
                that="some message",
                special_arg="some message"
            )
        )
    )
    assert('some message' == action._task.args['fail_msg'])
    assert('some message' == action._task.args['msg'])
    assert(True == action._task.args['quiet'])
    assert('some message' == action._task.args['success_msg'])
    assert('some message' == action._task.args['that'])
    assert(None == action._task.args['special_arg'])

# Generated at 2022-06-21 01:50:44.983407
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock class for ActionModule
    class ActionModuleMock(ActionModule):
        def __init__(self):
            self._task = MockTask()
            self._connection = MockConnection()
            self._loader = MockLoader()
            self._templar = MockTemplar()

        def _low_level_execute_command(self, cmd, tmp_path, sudoable=True, executable='/bin/sh', in_data=None):
        	return '', '', 0

        def _remote_expand_user(self, path):
        	return '/home/remote_user' + path

        def _check_conditional(self, conditional):
            pass


# Generated at 2022-06-21 01:50:56.677070
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #import modules that are used in the function
    import ansible.modules
    import ansible.plugins
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.utils
    import ansible.callbacks
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    #Define test data for module
    task_vars = dict()
    result = dict()
    fail_msg = 'Assertion failed'
    success_msg = 'Assertion Passed'
    orig_that = dict()
    orig_that['comparison'] = 'equal'
    orig_that['left'] = '1'
    orig_that['right'] = '1'
    tmp = None
    quiet = False

   

# Generated at 2022-06-21 01:51:07.199236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'test_module'

    def get_mock_templar(test_values):
        class MockTemplar(object):
            def __init__(self):
                self.test_values = test_values

            def template(self, value):
                return self.test_values.get(value, value)

        return MockTemplar()

    # Construct ActionModule object to test the run method.
    # We expect fail_msg or msg in the args.
    def test_run_without_fail_msg(args):
        mock_loader = create_autospec(Loader)
        action_mod = ActionModule(mock_loader)
        action_mod._task.args = args
        action_mod._task.action = module_name
        action_mod._templar = get_mock_templ

# Generated at 2022-06-21 01:51:16.255317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ##########################################
    # Create a mock object for the options class
    class Options(object):
        def __init__(self, verbosity=None, listhosts=None, listtasks=None, listtags=None, syntax=None, connection=None,
                     module_path=None, forks=None, remote_user=None, private_key_file=None, ssh_common_args=None,
                     ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=None, become_method=None,
                     become_user=None, verbosity_level=None, check=None, start_at_task=None):
            self.verbosity = verbosity
            self.listhosts = listhosts
            self.listtasks = listtasks
            self.listtags

# Generated at 2022-06-21 01:52:41.240157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._validate = lambda a, b: True
    action_module._templar = MagicMock()
    action_module._task = MagicMock()
    action_module.set_runner = MagicMock()
    action_module.runner = MagicMock()
    action_module._task.args = dict()
    result = dict()
    success_msg = "All assertions passed"
    fail_msg = "Assertion failed"

    action_module._task.args['msg'] = fail_msg
    action_module._task.args['successful_conditions'] = "None"
    action_module._task.args['failed_conditions'] = "None"
    action_module._task.args['that'] = True
    action_module.run(result)

# Generated at 2022-06-21 01:52:47.856953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'that': '{{ var }} | int == 2' }
    result = {
        'ansible_facts': {
            'var': '2',
            'var2': '1'
        }
    }

    # with success_msg and fail_msg
    module = ActionModule(task, result, '/tmp/ansible_fail_assert_result', './tests/units/ansible_modules/action/', 'ansible_fail_assert_result')
    result = module.run(task_vars={'var': '2'}, tmp='/tmp/ansible_fail_assert_result/tmp')
    assert result['assertion'] == '{{ var }} | int == 2'
    assert result['evaluated_to']
    assert result['msg'] == 'Assertion passed'

    # with success_msg
   

# Generated at 2022-06-21 01:52:57.628047
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Initialize required objects
    actionModule = ActionModule(FakeTask(), FakePlay(), FakeLoader(), FakeVariableManager())
    
    # Test with no that argument
    try:
        actionModule.run(tmp=None, task_vars=None)
    except AnsibleError as e:
        sys.stderr.write('Got Exception for no that argument: %s \n' % e)

    # Test with no success_msg argument
    actionModule = ActionModule(FakeTask(), FakePlay(), FakeLoader(), FakeVariableManager())
    task = FakeTask()
    task.args = {'that': 'hostvars[inventory_hostname] != 42'}
    actionModule._task = task
    actionModule.run(tmp=None, task_vars=None)

    # Test with no fail_msg argument

# Generated at 2022-06-21 01:52:58.467338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:53:06.471161
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Import modules needed for test
    import sys
    import os
    import numpy
    import tempfile
    import shutil

    # Save current path
    prev_sys_path = list(sys.path)

    # Change to a temp dir
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Create a temp playbook
    temp_playbook = tempfile.NamedTemporaryFile(mode='w', delete=False)

# Generated at 2022-06-21 01:53:09.125657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test constructor of class ActionModule')
    am = ActionModule()
    assert am._task.action == 'fail'

# Generated at 2022-06-21 01:53:17.606490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(loader=None,
                     templar=None,
                     shared_loader_obj=None)

    task_vars = dict()

    def _tmplar_substitute(value, variables, fail_on_undefined=True, convert_bare=True):
        return value

    def _load_name(name):
        return dict()


    a._tmplar_substitute = _tmplar_substitute
    a._load_name = _load_name

    msg = 'Assertion failed'
    success_msg = 'All assertions passed'
    that = 'ansible_distribution == "Fedora"'
    task_vars['ansible_distribution'] = 'Fedora'
    task = dict()
    task['args'] = dict()

# Generated at 2022-06-21 01:53:26.826610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize test class object
    test_module = ActionModule(None, None, None, None, None)
    test_module.name = 'test module name'
    test_module.args = {
                         'fail_msg': 'fail msg',
                         'msg': 'test msg',
                         'quiet': 'quiet',
                         'success_msg': 'success msg',
                         'that': 'test that'
                       }
    test_module.datastructure = 'module datastructure'
    test_module.play = 'test play'
    test_module.play_context = 'test play context'
    test_module.playbook = 'test playbook'
    test_module.play_path = 'test play path'

    # Assert test class object attributes
    assert test_module.name == 'test module name'
    assert test_module

# Generated at 2022-06-21 01:53:33.349254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('fail_msg', 'msg', 'quiet', 'success_msg', 'that')), \
            "Instance attribute _VALID_ARGS didn't contain expected elements"

# Generated at 2022-06-21 01:53:34.597333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO