

# Generated at 2022-06-22 14:01:45.491612
# Unit test for function fileglob
def test_fileglob():
    paths = [
        '',
        '/',
        '/foo/bar',
        './',
        './foo/bar',
        '/foo/bar',
        './foo/bar',
        'foo/bar',
        'foo/bar/',
        'foo/bar/./',
        'local/path',
    ]

    # Configure current working directory to known value
    if sys.version_info[0] < 3:
        orig_cwd = os.getcwdu()
    else:
        orig_cwd = os.getcwd()

    fixture_dir = os.path.join(os.path.dirname(__file__), 'filter_plugins', 'fixtures', 'fileglob')
    os.chdir(fixture_dir)


# Generated at 2022-06-22 14:01:49.286602
# Unit test for function ternary
def test_ternary():
    assert ternary(True, True, False, None) == True
    assert ternary(False, True, False, None) == False
    assert ternary(None, True, False, None) == None
    assert ternary(None, True, False, 'foo') == 'foo'



# Generated at 2022-06-22 14:02:02.192133
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo: bar: baz", r'bar:\s\S+') == "bar: baz"
    assert regex_search("foo: bar: baz", r'bar:\s\S+', '\\g<1>') == "baz"
    assert regex_search("foo: bar: baz", r'bar:\s(\S+)', '\\g<1>') == "baz"
    assert regex_search("foo: bar: baz", r'bar:\s(\S+)', '\\1') == 'baz'
    assert regex_search("foo: bar: baz", r'bar:\s(\S+)', '\\g<0>') == 'bar: baz'

# Generated at 2022-06-22 14:02:15.158707
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert (from_yaml_all('a: 1\nb: 2\nc: 3')) == [{u'a': 1}, {u'b': 2}, {u'c': 3}]
    assert (from_yaml_all('a: 1, b: 2, c: 3')) == [{u'a': 1, u'b': 2, u'c': 3}]
    assert (from_yaml_all('[{a: 1}, {b: 2}, {c: 3}]')) == [{u'a': 1}, {u'b': 2}, {u'c': 3}]
    assert (from_yaml_all('[a: 1, b: 2, c: 3]')) == [{u'a': 1, u'b': 2, u'c': 3}]

# Generated at 2022-06-22 14:02:24.448436
# Unit test for function ternary
def test_ternary():
    assert ternary(None, 'a', 'b') == 'b'
    assert ternary(False, 'a', 'b') == 'b'
    assert ternary('a', 'a', 'b') == 'a'
    assert ternary(True, 'a', 'b') == 'a'
    assert ternary(None, 'a', 'b', 'c') == 'c'
    assert ternary('a', 'a', 'b', 'c') == 'a'



# Generated at 2022-06-22 14:02:32.710047
# Unit test for function extract
def test_extract():
    environment = Environment()
    item = 'a'
    container = {'a': '1'}
    assert extract(environment, item, container) == '1'

    morekeys = ['b', 'c']
    container = {'a': {'b': {'c': '2'}}}
    assert extract(environment, item, container, morekeys) == '2'

    item = 'x'
    container = {'a': {'b': {'c': '3'}}}
    try:
        extract(environment, item, container, morekeys)
    except UndefinedError:
        pass
    else:
        raise AssertionError('Should raise UndefinedError.')



# Generated at 2022-06-22 14:02:44.810864
# Unit test for function regex_search
def test_regex_search():
    # Found a match
    assert regex_search('hello world', r'\s(\w+)\s', '\\g<1>') == ['world']
    assert regex_search('hello world', r'\s(\w+)\s', '\\1') == ['world']
    assert regex_search('hello world', r'\s(\w+)\s', '\\g<1>', '\\1') == ['world', 'world']

    # Not found
    assert not regex_search('hello world', r'\s(\w+)\s', '\\g<1>', '\\2') == ['world']
    assert not regex_search('hello world', r'\s(\w+)\s', '\\2') == ['world']

    # Negative numbers - Python 2 only
    if sys.version_info < (3,):
        assert regex_

# Generated at 2022-06-22 14:02:51.702546
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(42) == 42
    assert mandatory(None) == None
    assert mandatory(Undefined()) == None
    try:
        mandatory(Undefined())
    except AnsibleFilterError:
        # that is what we expect
        pass
    else:
        raise AssertionError("didn't raise AnsibleFilterError")


# Generated at 2022-06-22 14:02:52.810805
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None



# Generated at 2022-06-22 14:02:59.784521
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'abc.^$*\\') == 'abc\\.\\^\\$\\*\\\\'
    assert regex_escape(r'abc.^$*\\', re_type='posix_basic') == 'abc\\.\\^\\$\\*\\\\'
    assert regex_escape(r'abc.^$*\\', re_type='posix_extended') == 'abc\\.\\^\\$\\*\\\\'



# Generated at 2022-06-22 14:03:18.545777
# Unit test for function fileglob
def test_fileglob():
    assert ['./city.yml', './city2.yml', './test.yml'] == fileglob('./*.yml')



# Generated at 2022-06-22 14:03:27.641560
# Unit test for function subelements
def test_subelements():
    obj = [
        {"name": "alice", "groups": ["wheel", "devops"], "authorized": ["/tmp/alice/onekey.pub"]},
        {"name": "bob", "groups": ["wheel"], "authorized": ["/tmp/bob/twokey.pub", "/tmp/bob/threekey.pub"]},
        {"name": "chuck", "groups": [], "authorized": []}
    ]


# Generated at 2022-06-22 14:03:28.665189
# Unit test for function fileglob
def test_fileglob():
    # TODO: implement
    pass



# Generated at 2022-06-22 14:03:34.610401
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'c': 3, 'd': 4}, recursive=True) == dict(a=1, b=2, c=3, d=4)
    assert combine({'a': 1, 'b': 2}, {'b': 6, 'c': 3}, recursive=True) == dict(a=1, b=6, c=3)
    assert combine({'a': 1, 'b': 2}, {'a': {'b': 6}, 'c': 3}, recursive=True) == dict(a={'b': 6}, b=2, c=3)

    assert combine({'a': 1, 'b': 2}, {'c': 3, 'd': 4}, recursive=False) == dict(a=1, b=2, c=3, d=4)

# Generated at 2022-06-22 14:03:42.218126
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', second=1495439491) == '2017-05-22'
    assert strftime('%m-%d-%y', second=1495439491) == '05-22-17'
    assert strftime('%Y-%m-%d', second=1495439491.0) == '2017-05-22'
    assert strftime('%m-%d-%y', second=1495439491.0) == '05-22-17'
    assert strftime('%Y-%m-%d', second=1495439491.6436) == '2017-05-22'
    assert strftime('%m-%d-%y', second=1495439491.6436) == '05-22-17'

# Generated at 2022-06-22 14:03:53.379750
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.safe_eval import unsafe_safe_eval
    from ansible.template.vars import AnsibleJ2Vars

    env = AnsibleJ2Vars(
        loader=None,
        variables={},
        shared_loader_obj=None,
        templar=None,
        failsafe=False,
        gettext_callable=None,
    )

    # Case where the object is completely safe
    mydict = [
        {'name': 'First',
         'value': 1},
        {'name': 'Second',
         'value': 2},
        {'name': 'Third',
         'value': 2}
    ]
    result = do_groupby(env, mydict, 'value')
    parsed

# Generated at 2022-06-22 14:04:04.972041
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Template
    # This checks the jinja2 native `do_groupby` function.
    template = Template("""
{% set mydictlist = [
  { "os": "Linux", "status": "up" },
  { "os": "Linux", "status": "down" },
  { "os": "Windows", "status": "up" }
] %}

{% set mydictlist_grouped_by_os = mydictlist | groupby('os') %}""")

    # Normally, jinja2.runtime.GroupTuple is returned, which is a namedtuple that
    # breaks ansible safe_eval parse:
    #    GroupTuple(grouper='Linux', list=[{'os': 'Linux', 'status': 'up'}, {'os': 'Linux', 'status

# Generated at 2022-06-22 14:04:11.406290
# Unit test for function mandatory
def test_mandatory():
    '''
    >>> mandatory({'a': 1}, 'msg')
    {'a': 1}
    >>> mandatory(None, 'msg')
    Traceback (most recent call last):
    ...
    AnsibleFilterError: msg
    >>> mandatory([], 'msg')
    []
    >>> import jinja2
    >>> template = jinja2.Template("{{ nonexistingvar | mandatory('msg') }}")
    >>> template.render()
    Traceback (most recent call last):
    ...
    AnsibleFilterError: msg
    '''



# Generated at 2022-06-22 14:04:21.938979
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(None, 'test with None') != True
    except:
        pass

    try:
        mandatory('') != True
    except:
        pass

    try:
        mandatory(0) != True
    except:
        pass

    try:
        mandatory(False) != True
    except:
        pass

    try:
        mandatory({}) != True
    except:
        pass

    try:
        mandatory([1,2,3]) != True
    except:
        pass

    try:
        mandatory(True) == True
    except:
        pass

    try:
        mandatory(dict(a=1)) == True
    except:
        pass

    try:
        mandatory(list([1,2,3])) == True
    except:
        pass


# Generated at 2022-06-22 14:04:34.920101
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(r'foo', r'foo') == 'foo'
    assert regex_search(r'foo', r'FOO', ignorecase=True) == 'foo'
    assert regex_search(r'foo', r'foo') == 'foo'
    assert regex_search(r'foo', r'o', multiline=True) == 'oo'
    assert regex_search(r'foo', r'o', multiline=True) == 'oo'
    assert regex_search(r'foo', r'oo') == 'oo'
    assert regex_search(r'foo', r'oo') == 'oo'
    assert regex_search(r'foo', r'oo') == 'oo'
    assert regex_search(r'foo', r'oo') == 'oo'

# Generated at 2022-06-22 14:04:51.845304
# Unit test for function regex_search
def test_regex_search():
    value = 'foo123bar456baz'
    regex = r'(\d+)(bar)(\d+)'
    assert regex_search(value, regex, '\\1') == '123'
    assert regex_search(value, regex, '\\2') == 'bar'
    assert regex_search(value, regex, '\\3') == '456'
    assert regex_search(value, regex, '\\g<1>') == '123'
    assert regex_search(value, regex, '\\g<2>') == 'bar'
    assert regex_search(value, regex, '\\g<3>') == '456'

# Generated at 2022-06-22 14:04:55.982697
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(0) == 0
    try:
        mandatory(None)
        assert False
    except Exception as e:
        assert "Mandatory variable '' not defined" in to_native(e)



# Generated at 2022-06-22 14:05:01.474104
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory('a') == 'a'
    try:
        mandatory(Undefined(name='f'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'f' not defined."



# Generated at 2022-06-22 14:05:10.865440
# Unit test for function mandatory
def test_mandatory():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2.runtime import Undefined

    templar = Templar(None, loader=None, variables={})

    assert mandatory("foo") == "foo"
    assert templar.template("{{ mandatory('foo') }}") == "foo"

    assert mandatory("foo", msg="bar") == "foo"
    assert templar.template("{{ mandatory('foo', msg='bar') }}") == "foo"

    try:
        mandatory(Undefined())
        assert False, "unreachable?"
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable not defined."

# Generated at 2022-06-22 14:05:23.826370
# Unit test for function mandatory
def test_mandatory():
    from jinja2 import DictLoader, Environment
    from jinja2.exceptions import UndefinedError

    env = Environment(loader=DictLoader({'template': '{{ a }}'}))
    assert env.get_template('template').render({'a': 'b'}) == 'b'
    try:
        env.get_template('template').render()
        assert False, 'Expected UndefinedError'
    except UndefinedError as e:
        assert str(e) == 'a'
    try:
        env.get_template('template').render(a=Undefined(name='foo'))
        assert False, 'Expected AnsibleFilterError'
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable \'foo\' not defined.'

# Generated at 2022-06-22 14:05:36.690339
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/bin/ls') == ['/bin/ls']

# Generated at 2022-06-22 14:05:43.855491
# Unit test for function regex_search
def test_regex_search():
    fake = FakeVarsModule()
    fake.value = 'The quick brown fox jumps over the lazy dog'
    fake.regex = {
        'name': r'(.+) brown (\S+)'
    }
    assert regex_search(fake.value, fake.regex['name']) == 'The quick brown fox'
    assert regex_search(fake.value, fake.regex['name'], '\\g<1>') == 'The quick'
    assert regex_search(fake.value, fake.regex['name'], '\\2') == 'fox'
    assert regex_search(fake.value, fake.regex['name'], '\\g<1>', '\\g<2>') == ['The quick', 'fox']

# Generated at 2022-06-22 14:05:52.320518
# Unit test for function fileglob
def test_fileglob():
    import tempfile
    import shutil
    tmpdir = None
    try:
        tmpdir = tempfile.mkdtemp()
        f = tempfile.NamedTemporaryFile(delete=False, dir=tmpdir)
        # test with single file
        assert fileglob(f.name) == [f.name]
        f.close()
        # test with single regular expression
        assert fileglob(os.path.join(tmpdir, "*")) == [f.name]
        d = tempfile.mkdtemp(dir=tmpdir)
        # test with directory
        assert fileglob(d) == []
    finally:
        if tmpdir is not None:
            shutil.rmtree(tmpdir)


# Generated at 2022-06-22 14:06:02.584777
# Unit test for function mandatory
def test_mandatory():
    try:
        tmp = mandatory({}, "This is a dict.")
    except AnsibleFilterError as e:
        raise AnsibleFilterError("Unexpected error on dictionary. Exception: %s" % to_native(e))
    except Exception as e:
        raise AnsibleFilterError("Unexpected exception on dictionary. Exception: %s" % to_native(e))
    assert tmp == {}, "Dictionary test failed."

    try:
        tmp = mandatory([], "This is an array.")
    except AnsibleFilterError as e:
        raise AnsibleFilterError("Unexpected error on list. Exception: %s" % to_native(e))
    except Exception as e:
        raise AnsibleFilterError("Unexpected exception on list. Exception: %s" % to_native(e))
    assert tmp == [], "List test failed."


# Generated at 2022-06-22 14:06:07.627580
# Unit test for function mandatory
def test_mandatory():
    # The function should raise an exception when passed an 'Undefined' object
    assert_raises(AnsibleFilterError, mandatory, AnsibleUndefined("foo"))
    # If a msg is passed, it should be included in the filter error
    assert_raises(AnsibleFilterError, mandatory, AnsibleUndefined("foo"), msg="Message")



# Generated at 2022-06-22 14:06:17.576985
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('hello') == 'hello'
    try:
        mandatory(ansible_undefined)
        assert False
    except AnsibleFilterError:
        assert True



# Generated at 2022-06-22 14:06:24.483504
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('ABCD', 'CD') == 'CD'
    assert regex_search('ABCD', 'XD') is None
    assert regex_search('ABCD', 'C(D)', '\\g<1>') == ['D']
    assert regex_search('ABCD', 'C(D)', '\\g<2>') is None



# Generated at 2022-06-22 14:06:34.694467
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.environment import Environment
    from jinja2.runtime import Undefined
    env = Environment()
    mylist = [
        {"name": "foo", "value": 1},
        {"name": "foo", "value": 2},
        {"name": "bar", "value": 1},
        {"name": "bar", "value": 2},
    ]
    stored = do_groupby(env, mylist, "name")
    assert isinstance(stored, list)
    assert isinstance(stored[0], tuple)
    assert isinstance(stored[0][0], string_types)
    assert isinstance(stored[0][1], list)

    # now check that it fails as expected when passing an undefined value
    # to function do_groupby
    u = Undefined('test')

# Generated at 2022-06-22 14:06:36.914907
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(dict(a="foo")) == "a: foo\n"

# Generated at 2022-06-22 14:06:39.980221
# Unit test for function fileglob
def test_fileglob():
    ret = fileglob('/bin/*')
    for i in ret:
        assert os.path.isfile(i), '%s is not a file' % i



# Generated at 2022-06-22 14:06:50.487819
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool(1) is True

    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool(0) is False

    assert to_bool('garbage') is False
    assert to_bool(2) is False
    assert to_bool(2.0) is False
    assert to_bool([]) is False

    assert to_bool(None) is None
    assert to_bool('None') is False

    assert to_bool(True) is True
    assert to_bool(False) is False

# Generated at 2022-06-22 14:07:00.600250
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'outer': {'inner': 'ok'}}) == '''outer:
  inner: ok
'''

#def to_nice_json(a, indent=4):
#    '''Make verbose, human readable JSON'''
#    try:
#        return json.dumps(a, indent=indent, ensure_ascii=False)
#    except (TypeError, ValueError) as e:
#        raise AnsibleFilterError('to_nice_json error: %s' % to_native(e))


# Generated at 2022-06-22 14:07:12.544847
# Unit test for function combine
def test_combine():
    complex_data1 = {'a': 1, 'b': {'ba': 2, 'bb': 3}, 'c': [1, 2]}
    complex_data2 = {'a': 4, 'b': {'ba': 5}, 'd': 'higher_level_key'}
    complex_data3 = {'a': 7, 'b': {'bc': 8}, 'c': [3, 4]}
    assert combine(complex_data2, complex_data1, complex_data3) == {'a': 7, 'b': {'ba': 2, 'bb': 3, 'bc': 8}, 'c': [3, 4], 'd': 'higher_level_key'}

# Generated at 2022-06-22 14:07:17.567207
# Unit test for function mandatory
def test_mandatory():
    utils = AnsibleModule(argument_spec={})
    assert utils.fail_json.called is False, "no mandatory var, fail_json should not be called"
    _ = utils.mandatory({}, "myvar", "msg")
    assert utils.fail_json.called is True, "fail_json should be called"


# Generated at 2022-06-22 14:07:25.261444
# Unit test for function extract
def test_extract():
    from jinja2 import DictEnvironment
    env = DictEnvironment()
    vars = dict(
        key1='value1',
        key2=dict(key3='value3')
    )
    # Test simple key
    result = extract('key3', vars, env)
    assert result == 'value1'
    # Test list of keys
    result = extract('key3', vars, env, 'key2')
    assert result == 'value3'
    # Test string of keys
    result = extract('key3', vars, env, 'key2.key3')
    assert result == 'value3'


# Generated at 2022-06-22 14:07:38.982487
# Unit test for function do_groupby
def test_do_groupby():
    env = Environment()
    assert do_groupby(env, ['a', 'b', 'c', 'd'], 'x') == [
        ('a', []),
        ('b', []),
        ('c', []),
        ('d', []),
    ]
    assert do_groupby(env, [{'x': 'a'}, {'x': 'b'}, {'x': 'c'}, {'x': 'd'}], 'x') == [
        ('a', [{'x': 'a'}]),
        ('b', [{'x': 'b'}]),
        ('c', [{'x': 'c'}]),
        ('d', [{'x': 'd'}]),
    ]

# Generated at 2022-06-22 14:07:47.668318
# Unit test for function randomize_list

# Generated at 2022-06-22 14:07:51.011034
# Unit test for function regex_search
def test_regex_search():
    value='  "username": "ansible-user",\n  "password": "ansible",\n'
    regex = r'password": "(\S+)"'
    result = regex_search(value, regex, '\\g<1>')
    assert result == 'ansible'

# end of function test_regex_search


# Generated at 2022-06-22 14:07:56.528268
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.runtime import Undefined

    names = ["Ron", "Harry", "Hermione", "Ron", "Hermione", "Ron"]
    ages = [12, 11, 11, Undefined, Undefined, Undefined]
    groupby_names = [("Hermione", "Harry", "Ron"),
                     ("Hermione", "Ron", "Ron")]
    groupby_ages = [(11, 11, 12),
                    (11, Undefined, Undefined)]

    def test_name_grouping():

        from jinja2 import Environment
        e = Environment()
        e.filters['do_groupby'] = do_groupby
        name_groups = e.from_string("{{ names|do_groupby('upper') }}").render(names=names)
        assert name_groups == groupby_names



# Generated at 2022-06-22 14:08:05.506393
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo, bar', r'(\w+), (\w+)', '\\2') == 'bar'
    assert regex_search('foo, bar', r'(\w+), (\w+)', '\\g<1>') == 'foo'
    assert regex_search('foo, bar', r'(\w+), (\w+)', '\\g<2>') == 'bar'
    assert regex_search('foo, bar', r'(\w+), (\w+)', '\\g<2>', '\\g<1>') == ['bar', 'foo']
    assert regex_search('foo, bar', r'(\w+), (\w+)', '\\2', '\\1') == ['bar', 'foo']

# Generated at 2022-06-22 14:08:07.374606
# Unit test for function extract
def test_extract():
    env = Environment()
    env.loader = DictLoader({'tests/test.j2': '{{ extract("c",{a:{b:{c:5}}}) }}'})
    assert(5 == env.get_template('tests/test.j2').render())



# Generated at 2022-06-22 14:08:10.297774
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == """a: 1
b: 2
"""


# Generated at 2022-06-22 14:08:14.281824
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(u'abc', u'b') == u'b'
    assert regex_search(u'abc', u'b', u'\\1') == [u'b', u'b']


# Generated at 2022-06-22 14:08:19.526079
# Unit test for function extract
def test_extract():
    environment = fake_loader()
    container = dict(one=dict(two=dict(three=10)))
    assert extract(environment, 'one', container) == container['one']
    assert extract(environment, 'two', container) == dict(three=10)
    assert extract(environment, 'three', container) == 10
    assert extract(environment, 'two', container, 'three') == 10

    container = dict(one=dict(two=10))
    assert extract(environment, 'one', container, 'two') == 10

    assert extract(environment, None, container, 'two') == 10

    # container is not a dict, so fail
    assert extract(environment, 'one', 'container') is None

    # one is not a key, so fail
    assert extract(environment, 'one', container, 'two') is None

    # No more keys

# Generated at 2022-06-22 14:08:23.458424
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from . import to_nice_yaml
    data = {
        'hello': '1',
        'there': True,
        'foo': False
    }
    assert to_nice_yaml(data) == """\
hello: '1'
there: true
foo: false
"""



# Generated at 2022-06-22 14:08:41.585358
# Unit test for function randomize_list
def test_randomize_list():
    '''
    The function randomize_list takes a list and randomizes it in place
    The input list is random, but the output list is always the same when
    given the same seed
    '''
    test_list = ['test 1', 'test 2', 'test 3', 'test 4']
    test_seed = 'abc123'
    randomized_list = randomize_list(test_list, seed=test_seed)
    assert len(randomized_list) == len(test_list)
    assert randomized_list != test_list
    # the output should be the same when given the same seed
    randomized_list_again = randomize_list(test_list, seed=test_seed)
    assert len(randomized_list_again) == len(test_list)
    assert randomized_list_again != test_list
    assert randomized

# Generated at 2022-06-22 14:08:47.350744
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) != [1, 2, 3]
    randomize_list([1, 2, 3], seed='foo') == [1, 2, 3]
    randomize_list([1, 2, 3]) != randomize_list([1, 2, 3])



# Generated at 2022-06-22 14:08:58.418757
# Unit test for function subelements
def test_subelements():
    from .unicode_wrap import unicode_wrap

    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    result = subelements(obj, 'groups')
    assert result == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')], \
        unicode_wrap(result)

    obj = {"users": [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]},
                      {"name": "bob", "groups": ["admins"], "authorized": ["/tmp/bob/onekey.pub"]}]}
    result = subelements(obj, 'users.groups')

# Generated at 2022-06-22 14:09:02.709593
# Unit test for function strftime
def test_strftime():
    dt = datetime.datetime.now()
    epoch = dt.strftime('%s')
    assert strftime('%Y-%m-%d',epoch) == dt.strftime('%Y-%m-%d')



# Generated at 2022-06-22 14:09:15.400427
# Unit test for function do_groupby
def test_do_groupby():
    import os
    import tempfile
    import yaml

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    data_file = os.path.join(tmp_dir, "test_do_groupby.yml")
    file_input = os.path.join(tmp_dir, "test_do_groupby_input.j2")
    file_output = os.path.join(tmp_dir, "test_do_groupby_output")

    # Create data file

# Generated at 2022-06-22 14:09:17.980723
# Unit test for function fileglob
def test_fileglob():
    pathname="/tmp/fileglob*"
    fileglob(pathname)


# Generated at 2022-06-22 14:09:27.814241
# Unit test for function get_hash
def test_get_hash():
    # get_hash is the md5s and checksum_s functions from ansible.utils.hashing
    # converted to a jinja2 test, so we can use our jinja2 test
    # infrastructure.
    # Test against all supported hashtypes
    hashtypes = ['md5', 'sha1', 'sha256', 'sha512']
    for hashtype in hashtypes:
        assert get_hash('test', hashtype) == get_hash('test', hashtype)
        assert get_hash('test', hashtype) != get_hash('not the test', hashtype)
    # Test with characters that require encoding
    assert get_hash(u'\u2018', 'sha1') == get_hash(u'\u2018')



# Generated at 2022-06-22 14:09:36.598752
# Unit test for function extract
def test_extract():

    def test_extract_sub(container, item, morekeys):
        env = {}
        filters = {'extract': extract}

        if morekeys is None:
            return to_text(Template(
                '{{ container|extract(item) }}',
                env,
                filters=filters).render(container=container, item=item))
        else:
            return to_text(Template(
                '{{ container|extract(item, morekeys) }}',
                env,
                filters=filters).render(container=container, item=item, morekeys=morekeys))

    # dictionary
    assert test_extract_sub({'a': 1}, 'a', None) == '1'
    assert test_extract_sub({'a': 1}, 'b', None) == ''

# Generated at 2022-06-22 14:09:39.452498
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foobar", r"^\w{3}", "\\g<0>") == "foo"


# Generated at 2022-06-22 14:09:48.665972
# Unit test for function do_groupby
def test_do_groupby():
    g1 = Group(name='g1', gid=1000)
    g2 = Group(name='g2', gid=1001)
    u1 = User(name='u1', gid=1000)
    u2 = User(name='u2', gid=1000)
    u3 = User(name='u3', gid=1001)
    plain_tuple = tuple((g1.name, [u1, u2]))
    plain_tuple_with_no_users = tuple((g2.name, []))
    assert do_groupby([u1, u2, u3], 'gid') == [plain_tuple, plain_tuple_with_no_users]
# End unit test



# Generated at 2022-06-22 14:10:08.482425
# Unit test for function fileglob
def test_fileglob():
    test_dir = 'test_dir'
    file1 = 'test_file1'
    file2 = 'test_file2'
    module_utils.mkdir_safe(test_dir)
    create_file(os.path.join(test_dir, file1))
    create_file(os.path.join(test_dir, file2))
    assert ['%s/%s' % (test_dir, file1), '%s/%s' % (test_dir, file2)] == fileglob(os.path.join(test_dir, '*'))
    os.unlink(os.path.join(test_dir, file1))
    os.unlink(os.path.join(test_dir, file2))
    os.rmdir(test_dir)


# Generated at 2022-06-22 14:10:22.035757
# Unit test for function regex_search
def test_regex_search():
    # Tests for cases where xrange does not work for python 3
    for i in xrange(-100,100):
        value = 'abc'
        regex = 'abc'
        if regex_search(value, regex) != value:
            raise AssertionError("regex_search(%s,%s) should have returned '%s'" % (value, regex, value))
        if regex_search(value, regex, '\\g<0>') != [value]:
            raise AssertionError("regex_search(%s,%s) should have returned '[%s]'" % (value, regex, value))
        if regex_search(value, regex, '\\0') != value:
            raise AssertionError("regex_search(%s,%s) should have returned '%s'" % (value, regex, value))
       

# Generated at 2022-06-22 14:10:26.229608
# Unit test for function mandatory
def test_mandatory():
    print(mandatory('mandatory'))
    try:
        print(mandatory(AnsibleUndefined()))
    except AnsibleFilterError as e:
        print(e)



# Generated at 2022-06-22 14:10:37.227413
# Unit test for function comment
def test_comment():
    assert comment(text='Single line') == '# Single line'
    assert comment(text='Single line', style='erlang') == '% Single line'
    assert comment(text='Single line', style='c') == '// Single line'
    assert comment(text='Single line', style='cblock') == '/*\n * Single line */'
    assert comment(text='Single line', style='xml') == '<!--\n - Single line-->'
    assert comment(text='Multiple\nlines') == '# Multiple\n# lines'
    assert comment(text='Multiple\nlines', style='cblock') == '/*\n * Multiple\n * lines */'
    assert comment(text='Multiple\nlines', style='c', decoration='-- ') == '// -- Multiple\n// -- lines'

# Generated at 2022-06-22 14:10:50.332401
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import SafeEval
    env = {}
    safe_eval = SafeEval(env, env)
    # these first three tests should not trigger an exception
    # as would be seen in the aforementioned jinja2 issue
    safe_eval.eval(do_groupby(env, [{'a':1},{'a':2}], 'a'))
    safe_eval.eval(do_groupby(env, [{'a':1},{'a':2}], 'a'))
    safe_eval.eval(do_groupby(env, [{'a':1},{'a':2}], None))
    # these tests should trigger exceptions

# Generated at 2022-06-22 14:11:03.358988
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == u'- 1\n- 2\n- 3\n'
    assert to_yaml([1, 2, 3], default_flow_style=False) == u'- 1\n- 2\n- 3\n'
    assert to_yaml([1, 2, 3], default_flow_style=True) == u'[1, 2, 3]\n'
    assert to_yaml([1, 2, 3], indent=8, default_flow_style=False) == u'        \x2d 1\n        \x2d 2\n        \x2d 3\n'
    assert to_yaml([1, 2, 3], indent=8, default_flow_style=True) == u'        [1, 2, 3]\n'
    assert to_

# Generated at 2022-06-22 14:11:17.148908
# Unit test for function combine
def test_combine():
    """
    Test the combine function
    """
    t1 = {
        'foo': 'bar',
        'baz': 'baz',
        'faz': {
            'baz': 'baz',
            'daz': 'daz',
        },
    }
    t2 = {
        'foo': 'baz',
        'faz': ['foo'],
    }
    result = combine(t1, t2)
    result2 = combine(t2, t1)
    assert 'foo' in result
    assert result['foo'] == 'baz'
    assert result2['foo'] == 'bar'
    assert 'baz' in result['faz']
    assert result['faz']['daz'] == 'daz'
