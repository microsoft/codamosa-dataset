

# Generated at 2022-06-22 14:01:53.066082
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('<a class="bar">foo</a>',
        '(<a )(class="[^"]*")(>.*</a>)', r'\1class="bar"\3',
        ignorecase=True) == '<a class="bar">foo</a>'



# Generated at 2022-06-22 14:01:58.780861
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('[foo.bar]') == '\\[foo\\.bar\\]'
    assert regex_escape('[foo.bar]', re_type='posix_basic') == '\\[foo\\.bar\\]'
    with pytest.raises(AnsibleFilterError) as execinfo:
        regex_escape('[foo.bar]', re_type='foo')
    assert 'Invalid regex type' in to_native(execinfo.value)
    assert 'foo' in to_native(execinfo.value)



# Generated at 2022-06-22 14:02:04.509161
# Unit test for function extract
def test_extract():
    environment = DummyEnvironment()
    item = 'one'
    container = {'one': {'two': {'three': 'four'}}}
    assert True == (extract(environment, item, container) == container['one'])
    assert True == (extract(environment, item, container, 'two') == container['one']['two'])
    assert True == (extract(environment, item, container, ['two', 'three']) == container['one']['two']['three'])
    assert True == (extract(environment, item, container, 'two.three') == container['one']['two']['three'])

# Generated at 2022-06-22 14:02:09.657711
# Unit test for function regex_replace
def test_regex_replace():
    pattern = re.compile(r'\sAND\s', re.I)
    replacement = ' and '
    value = 'This is AND a sentence'
    assert regex_replace(value, pattern=pattern, replacement=replacement) == 'This is and a sentence'


# Generated at 2022-06-22 14:02:17.756214
# Unit test for function extract
def test_extract():
    env = jinja2.Environment()
    assert extract(env, 'color', {'color': 'blue', 'size': 'big'}) == 'blue'
    assert extract(env, 'color', {'color': 'blue', 'size': 'big'}, ['size']) == 'big'
    assert extract(env, 'color', {'color': 'blue', 'size': 'big'}, 'size') == 'big'

    # dict of dict whose key is a list
    assert extract(env, 'color', {'color_and_size': {
        'color': 'blue',
        'size': 'big'
    }}, ['color_and_size', 'color']) == 'blue'



# Generated at 2022-06-22 14:02:30.541162
# Unit test for function extract
def test_extract():
    # morekeys as string
    _test_extract('/config',
            {},
            ["root", "config"])
    _test_extract('/config',
            {'root': {}},
            ["root", "config"])
    _test_extract('/config',
            {'root': {'config': {}}},
            ["root", "config"])
    _test_extract('/config',
            {'root': {'config': {'path': '/config'}}},
            ["root", "config"])
    # morekeys as list
    _test_extract('/config',
            {'root': {'config': {'path': '/config'}}},
            ["root", ["config", "path"]])
    # unittest.skip fails when used as decorator
    # @unitt

# Generated at 2022-06-22 14:02:33.973122
# Unit test for function subelements
def test_subelements():
    return {
        'out': {
            'passed': subelements([{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}], 'groups') ==
                     [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
        }
    }


# Generated at 2022-06-22 14:02:40.951900
# Unit test for function extract
def test_extract():
    assert extract('key1', {'key1': 'value1'}) == 'value1'
    assert extract(['key1', 'key2'], {'key1': {'key2': 'value2'}}) == 'value2'
    assert extract([0, 0, 'key3'], [[{'key3': 'value3'}]]) == 'value3'



# Generated at 2022-06-22 14:02:51.257625
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool(1) is True
    assert to_bool('on') is True
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool('') is False
    assert to_bool([]) is False
    assert to_bool(()) is False
    assert to_bool({}) is False



# Generated at 2022-06-22 14:02:55.398360
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp/foo') == []
    assert fileglob('/tmp/*/*') == []
    assert '/tmp/a' in fileglob('/tmp/a')
    assert '/tmp/a/b' not in fileglob('/tmp/a')



# Generated at 2022-06-22 14:03:09.149792
# Unit test for function do_groupby
def test_do_groupby():
    t = Template('{% set m = [{"foo": "one", "bar": "red"}, {"foo": "two", "bar": "blue"}, {"foo": "three", "bar": "red"}] %}{{ m|groupby("bar")|list }}')
    assert t.render() == "[('red', [{'foo': 'one', 'bar': 'red'}, {'foo': 'three', 'bar': 'red'}]), ('blue', [{'foo': 'two', 'bar': 'blue'}])]"


# Generated at 2022-06-22 14:03:21.206286
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('1234', '\d+') == '1234'
    assert regex_search('foo bar', '(\w+)', '\\g<1>') == ['foo']
    assert regex_search('foo bar', '(\w+)', '\\g<1>') == ['foo']
    assert regex_search('foo bar', '(\w+)', '\\g<1>', ignorecase=True, multiline=True) == ['foo']
    assert regex_search('foo bar', '(\w+)', '\\g<1>', '\\1') == ['foo', 'foo']
    assert regex_search('foo bar', '(\w+)', '\\g<1>', '\\1', '\\g<1>') == ['foo', 'foo', 'foo']

# Generated at 2022-06-22 14:03:28.384854
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    dummy_undef = Undefined(name='test_variable', hint=None)

    ansible_undef = mandatory(dummy_undef)
    assert ansible_undef == None, "mandatory() should return None when not passed a msg argument"

    ansible_undef = mandatory(dummy_undef, msg='Testing mandatory msg')
    assert ansible_undef == None, "mandatory() should return None when passed a msg arg"

    try:
        mandatory(dummy_undef, msg='test_variable')
    except AnsibleFilterError as e:
        assert 'test_variable' in str(e)


# Unit tests for function to_uuid

# Generated at 2022-06-22 14:03:31.192630
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/dev/null') == ['/dev/null']
    assert fileglob('/nonexisting') == []



# Generated at 2022-06-22 14:03:39.720127
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('a', 'a', '\\1') == ['a']
    assert regex_search('aa', 'a', '\\1') == ['a']
    assert regex_search('ab', 'a', '\\1') == ['a']
    assert regex_search('bab', 'a', '\\1') == ['a']
    assert regex_search('baba', 'a', '\\1') == ['a']
    assert regex_search('babab', 'a', '\\1') == ['a']
    assert regex_search('bababa', 'a', '\\1') == ['a']
    assert regex_search('bababab', 'a', '\\1') == ['a']
    assert regex_search('babababa', 'a', '\\1') == ['a']

# Generated at 2022-06-22 14:03:51.662294
# Unit test for function extract
def test_extract():
    # Test S to S
    test1 = extract('a', {'a': 'b'})
    if test1 != 'b':
        raise AssertionError('not equal')

    # Test S to L
    test2 = extract('a', {'a': ['b']})
    if test2 != ['b']:
        raise AssertionError('not equal')

    # Test L to L
    test3 = extract(1, ['a', ['b']])
    if test3 != ['b']:
        raise AssertionError('not equal')

    # Test S to D
    test4 = extract('a', {'a': {'b': 'c'}})
    if test4 != {'b': 'c'}:
        raise AssertionError('not equal')

    # Test D to D

# Generated at 2022-06-22 14:04:02.850326
# Unit test for function extract
def test_extract():
    assert extract(item='a', container={'a': {'b': "c"}}) == {'b': "c"}
    assert extract(item='a', morekeys='b', container={'a': {'b': "c"}}) == "c"
    assert extract(item='a', morekeys=['b'], container={'a': {'b': "c"}}) == "c"
    assert extract(item='a', morekeys=['b', 'c'], container={'a': {'b': {'c': "d"}}}) == "d"
    try:
        assert extract(item='a', morekeys=['b', 'c'], container={'a': {'b': "c"}})
    except AnsibleUndefinedVariable:
        return
test_extract()



# Generated at 2022-06-22 14:04:04.085649
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None, msg='msg') == 'msg'



# Generated at 2022-06-22 14:04:05.208860
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('hello') == 'hello'
    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:04:13.410875
# Unit test for function regex_search
def test_regex_search():
    value = '192.168.0.1'
    regex = r'(\d+)\.(\d+)\.(\d+)\.(\d+)'
    assert regex_search(value, regex) == value
    assert regex_search(value, regex, '\\g<1>') == '192'
    assert regex_search(value, regex, '\\g<2>') == '168'
    assert regex_search(value, regex, '\\g<3>') == '0'
    assert regex_search(value, regex, '\\g<4>') == '1'
    assert regex_search(value, regex, '\\g<1>', '\\g<3>') == ['192', '0']



# Generated at 2022-06-22 14:04:25.952357
# Unit test for function mandatory
def test_mandatory():
    '''Unit test for function mandatory'''
    from jinja2.runtime import Undefined

    # test variable does not exist, no extra message
    try:
        mandatory(Undefined())
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError("Should raise AnsibleFilterError")

    # test variable does not exist, extra message
    try:
        mandatory(Undefined(), "Some message")
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError("Should raise AnsibleFilterError")

    # test variable exists, no extra message
    try:
        mandatory("Some value")
    except AnsibleFilterError:
        raise AssertionError("Should not raise AnsibleFilterError")

    # test variable exists, extra message

# Generated at 2022-06-22 14:04:38.388292
# Unit test for function randomize_list
def test_randomize_list():
    ''' Test the randomize_list filter'''
    # Test a list of integers
    assert randomize_list([0, 1, 2]) != [0, 1, 2]
    assert len(set(randomize_list([0, 1, 2]))) == 3
    # Test a list of strings
    assert randomize_list(['a', 'b', 'c']) != ['a', 'b', 'c']
    assert len(set(randomize_list(['a', 'b', 'c']))) == 3
    assert randomize_list(['a', 'a', 'a']) == ['a', 'a', 'a']
    # Test a list of integers with a seed value
    assert randomize_list([0, 1, 2], seed='seed') == [2, 1, 0]
    # Test a list of strings with a

# Generated at 2022-06-22 14:04:50.583020
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([[1, [2, 3]]]) == [1, [2, 3]]
    assert flatten([[1, [2, 3]]], levels=1) == [1, 2, 3]
    assert flatten([[1, [2, 3]]], levels=2) == [1, 2, 3]
    assert flatten([[1, [2, 3]]], levels=3) == [1, 2, 3]
    assert flatten([[1, [2, 3]]], levels=4) == [1, 2, 3]

# Generated at 2022-06-22 14:04:57.916696
# Unit test for function mandatory

# Generated at 2022-06-22 14:05:04.659874
# Unit test for function get_hash
def test_get_hash():
    # simple string
    assert get_hash("hello") == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"

    # unicode string
    assert get_hash("łóżźć") == "9d0a6bf7c6e26d6b2a0b14ca3a691298aaaf38fd"



# Generated at 2022-06-22 14:05:15.726134
# Unit test for function comment
def test_comment():
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch, mock_open


# Generated at 2022-06-22 14:05:23.897445
# Unit test for function do_groupby
def test_do_groupby():
    import random
    import string
    from collections import namedtuple

    Dummy = namedtuple('Dummy', ('foo', 'bar'))
    data = set()
    for _ in range(1000):
        foo = ''.join(random.choice(string.ascii_letters) for _ in range(10))
        bar = ''.join(random.choice(string.ascii_letters) for _ in range(10))
        data.add(Dummy(foo, bar))

    data = list(data)
    random.shuffle(data)

    expect = [tuple(d) for d in data]
    actual = do_groupby(data, 'foo')

    assert sorted(expect) == sorted(actual)


# Add filters to ansible jinja environment

# Generated at 2022-06-22 14:05:36.877811
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(42) == 42
    assert mandatory(Undefined(missing_name="foo")) == Undefined(missing_name="foo")

    # Check with custom message
    try:
        mandatory(Undefined(missing_name="foo"), msg="This is a custom message")
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "This is a custom message"

    # Check with automatic message
    try:
        mandatory(Undefined(missing_name="foo"))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."
    # without name, it's simpler
    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError as e:
        assert str

# Generated at 2022-06-22 14:05:41.539407
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('$*+?.') == r'\$\*\+\?\.'
    assert regex_escape('$*+?.', re_type='posix_basic') == r'\$\*\+\?\.'
    assert regex_escape('$*+.?^|()[]{}\\') == r'\$\*\+\.\?\^\|\(\)\[\]\{\}\\\\'



# Generated at 2022-06-22 14:05:43.168214
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory("test") == "test"
    assert mandatory(Undefined("test")) == "test"



# Generated at 2022-06-22 14:05:58.986774
# Unit test for function combine
def test_combine():
    '''Test that the combine filter works as expected'''
    # Filter combines dictionaries
    d1 = {'a':1, 'b': 2}
    d2 = {'c':3}
    assert combine(d1, d2) == {'a':1, 'b':2, 'c':3}

    # Filter combines lists
    d1 = {'a':[1,2]}
    d2 = {'a':[3]}
    assert combine(d1, d2) == {'a':[3]}

    # Filter combines lists and appends when asked
    d1 = {'a':[1,2]}
    d2 = {'a':[3]}
    assert combine(d1, d2, list_merge='append') == {'a':[1,2,3]}

    # Filter combines diction

# Generated at 2022-06-22 14:06:07.772732
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(5, "two is not a valid number") == 5
    try:
        mandatory("two")
        raise Exception("mandatory didn't raise exception")
    except Exception as e:
        assert type(e) == AnsibleFilterError
        assert str(e) == "Mandatory variable not defined."
    try:
        mandatory("two", "two is not a valid number")
        raise Exception("mandatory didn't raise exception")
    except Exception as e:
        assert type(e) == AnsibleFilterError
        assert str(e) == "two is not a valid number"



# Generated at 2022-06-22 14:06:15.237848
# Unit test for function do_groupby
def test_do_groupby():
    from .test_utils.test_data import TestData
    test_data = TestData()
    from ansible import errors
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from jinja2 import DictResourceLoader

    # Environment to load the filter
    loader = DictResourceLoader({'test.j2': "{{ data_in | groupby(attribute) }}"})
    env = Environment(loader=loader, undefined=StrictUndefined)
    env.filters['groupby'] = do_groupby

    # Prepare the data
    vars = AnsibleJ2Vars(play=test_data.play(), loader=test_data.loader())
    templar = Templar(loader=test_data.loader(), variables=vars)

    # Test data
    data

# Generated at 2022-06-22 14:06:24.414540
# Unit test for function comment
def test_comment():
    # Expected behaviour
    assert (comment('Test string', 'plain') ==
            '# Test string')
    assert (comment('Test string', 'cblock') ==
            '/*\n * Test string\n */')
    assert (comment('Test string', 'cblock', decoration=';;; ') ==
            '/*\n;;; Test string\n */')
    assert (comment('Test string', 'plain', prefix='~') ==
            '# ~\n# Test string')
    assert (comment('Test string', 'plain', prefix='~', prefix_count=2) ==
            '# ~\n# ~\n# Test string')
    assert (comment('Test string', 'cblock', beginning='BEGIN') ==
            'BEGIN\n/*\n * Test string\n */')

# Generated at 2022-06-22 14:06:30.718961
# Unit test for function regex_search
def test_regex_search():
    """Test regex_search"""
    result = regex_search("chicken", 'chicken')
    assert result == "chicken"
    result = regex_search("chicken", 'chicken')
    assert result == "chicken"
    result = regex_search("chicken", 'chicken')
    assert result == "chicken"
    result = regex_search("chicken", 'chicken')
    assert result == "chicken"


# Generated at 2022-06-22 14:06:40.461087
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', 1509553865) == '2017'
    assert strftime('%Y', '1509553865') == '2017'
    assert strftime('%Y', 1509553865.123) == '2017'
    assert strftime('%Y', 1509553865.9) == '2017'
    assert strftime('%Y', 1509553865.99) == '2017'
    assert strftime('%Y', 1509553865.999) == '2017'
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%Y', second='not') == time.strftime('%Y')



# Generated at 2022-06-22 14:06:42.321806
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("foo") == "foo"
    try:
        print(mandatory("foo", "Success"))
        assert False
    except AnsibleFilterError as e:
        assert e.message == 'Success'



# Generated at 2022-06-22 14:06:44.300715
# Unit test for function mandatory
def test_mandatory():
    try:
        data = mandatory(None, msg="ERROR")
    except AnsibleFilterError as e:
        assert e.args[0] == "ERROR"
    else:
        assert False, "Failed to throw AnsibleFilterError"



# Generated at 2022-06-22 14:06:53.110445
# Unit test for function do_groupby
def test_do_groupby():
    # pylint: disable=import-error,unused-variable
    from ansible import errors as ansible_errors
    # pylint: enable=import-error,unused-variable
    # Test setup
    value = [
        {'testing': 'foo', 'id': 1},
        {'testing': 'foo', 'id': 2},
        {'testing': 'bar', 'id': 3}
    ]
    attribute = 'testing'
    expected = [
        ('foo', [{'testing': 'foo', 'id': 1}, {'testing': 'foo', 'id': 2}]),
        ('bar', [{'testing': 'bar', 'id': 3}])
    ]
    # Test the functionality
    result = do_groupby(value, attribute)

# Generated at 2022-06-22 14:07:04.982184
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("hello", 'l', 'm') == "hemmo"
    assert regex_replace("hello", 'l', 'm', True) == "hemmo"
    assert regex_replace("hello", '[l]', 'm') == "hemmo"
    assert regex_replace("hello", '[l]', 'm', True) == "hemmo"
    assert regex_replace("hello", '[a-z]', '0', True) == "00000"
    assert regex_replace("hello", '[a-z]', '0', True) == "00000"
    assert ''.join(regex_replace(["hello", "world"], 'l', 'm', True)) == "hemmo world"



# Generated at 2022-06-22 14:07:11.069813
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined()) is Undefined
    assert mandatory(1234) == 1234



# Generated at 2022-06-22 14:07:14.640009
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined()) == None
    try:
        mandatory(Undefined('foo'))
        assert False
    except:
        pass



# Generated at 2022-06-22 14:07:17.981364
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('Hello world!') == "Hello world!"

    try:
        mandatory(None)
        assert False, 'Was expecting an exception'
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:07:26.220105
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('ansible', '[aA]') == 'nsible'
    assert regex_replace('foo', 'f', 'b', ignorecase=True) == 'boo'
    assert regex_replace('foo\nbar', 'f.', 'b', multiline=True) == 'boo\nbar'
    assert regex_replace('foo\nbar\nfoo', 'f.', 'b', multiline=True) == 'boo\nbar\nboo'
    assert regex_replace('#f', 'f', 'b', multiline=True) == '#f'
    assert regex_replace('#f', 'f', 'b', ignorecase=True, multiline=True) == '#b'


# Generated at 2022-06-22 14:07:36.722963
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'f') == 'f'
    assert regex_search('foo', 'o') == 'o'
    assert regex_search('foo', 'o', '\\g<0>') == 'oo'
    assert regex_search('foo', 'o', '\\g<0>', '\\g<0>') == ['oo', 'oo']
    assert regex_search('foo', 'o', '\\g<0>', '\\1') == ['oo', 'oo']
    assert regex_search('foo', '(?P<name>o)', '\\g<name>', '\\g<name>', '\\1', '\\g<1>') == ['oo', 'oo', 'oo', 'oo']
    assert regex_search('foo', '', '\\g<0>', '\\1') is None
   

# Generated at 2022-06-22 14:07:45.948106
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    defgroupby = getattr(_do_groupby, '__wrapped__', _do_groupby)
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['defgroupby'] = defgroupby

# Generated at 2022-06-22 14:07:47.864513
# Unit test for function fileglob
def test_fileglob():
    pathname = '/etc/*release*'
    for file in fileglob(pathname):
        print(file)
# test_fileglob()


# Generated at 2022-06-22 14:07:54.476488
# Unit test for function comment
def test_comment():
    '''
    Test case for function ``comment``.
    '''

    # Test for default parameters
    text = ('First line.'
            'Second line.')
    string = comment(text)

    assert string == ('# First line.'
                      '# Second line.')

    # Test for custom values
    text = ('First line.'
            'Second line.')
    string = comment(
        text=text,
        decoration='--',
        prefix_count=0,
        postfix_count=1,
        newline='\r\n')

    assert string == ('-- First line.\r\n'
                      '-- Second line.\r\n'
                      '-- ')

    # Test for predefined comment types
    text = ('First line.'
            'Second line.')

# Generated at 2022-06-22 14:07:57.912190
# Unit test for function regex_search
def test_regex_search():
    value = 'version: 1.9.4-1ubuntu1'
    regex = '^version: (\S+)-'
    result = regex_search(value, regex, '\\g<1>')
    assert(result == '1.9.4')

test_regex_search()



# Generated at 2022-06-22 14:08:01.037099
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(2) == 2
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False



# Generated at 2022-06-22 14:08:08.653983
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'h.*?\s(\w+)', '\\g<1>', '\\1', ignorecase=True, multiline=True) == ['world']



# Generated at 2022-06-22 14:08:21.466608
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar$') == 'foo\\.bar\\$'
    assert regex_escape('foo.bar*') == 'foo\\.bar\\*'
    assert regex_escape('foo.bar\\') == 'foo\\.bar\\\\'
    assert regex_escape('foo.bar[]') == 'foo\\.bar\\[\\]'

    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar$', re_type='posix_basic') == 'foo\\.bar\\$'
    assert regex_escape('foo.bar*', re_type='posix_basic') == 'foo\\.bar*'

# Generated at 2022-06-22 14:08:34.762939
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(to_text("test123123123test"), r"test\d+test") == "test123123123test"
    assert regex_search(to_text("test123123123test"), r"\d+") == "123123123"
    assert regex_search(to_text("test123123123test"), r"\d+", '\\g<1>') == "123123123"
    assert regex_search(to_text("test123123123test"), r"\d+test") == "123123123test"
    assert regex_search(to_text("test123123123test"), r"(\d+)(test)") == "123123123test"
    assert regex_search(to_text("test123123123test"), r"(\d+)(test)", '\\g<1>') == "123123123"

# Generated at 2022-06-22 14:08:36.709046
# Unit test for function randomize_list
def test_randomize_list():
    l = ['Apple', 'Banana', 'Orange']
    rlist = randomize_list(l)
    assert (rlist != l)
    rlist = randomize_list(l, seed='test')
    assert (rlist == l)



# Generated at 2022-06-22 14:08:49.397475
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('123', r'\d+') == '123'
    assert regex_search('1 2 3', r'\d+', '\\g<1>', '\\g<2>', '\\g<3>') == ['1', '2', '3']
    assert regex_search('1 2 3', r'(\d+) (\d+) (\d+)', '\\g<3>', '\\g<2>', '\\g<1>') == ['3', '2', '1']
    assert regex_search('input', r'(i|f)n(.+)', ignorecase=True, multiline=True) == ['i', 'n', 'put']

# Generated at 2022-06-22 14:08:56.876942
# Unit test for function mandatory
def test_mandatory():
    _ = {'missing': None, 'exists': True}

    assert mandatory(_['exists'])
    try:
        mandatory(_['missing'])
    except Exception:
        e = sys.exc_info()[1]
        assert 'not defined' in to_native(e)

        # test with missing message
        try:
            mandatory(_['missing'], msg='missing msg...')
        except Exception:
            e = sys.exc_info()[1]
            assert 'missing msg' in to_native(e)


# Generated at 2022-06-22 14:09:08.631843
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.runtime import Context
    from ansible.errors import AnsibleError
    from ansible.template.safe_eval import ansible_eval

    do_groupby_func = do_groupby
    do_groupby_func_kwargs = dict(
        environment=Context({}, None, None),
        value=[
            dict(key='a', value=1),
            dict(key='a', value=2),
            dict(key='b', value=3),
        ],
        attribute='key',
    )

    do_groupby_result = do_groupby_func(**do_groupby_func_kwargs)

    assert isinstance(do_groupby_result, list)
    assert len(do_groupby_result) == 2

# Generated at 2022-06-22 14:09:11.701677
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=dict(b='1234', c=False), e='5678')) == to_text("""{a:
  {b: '1234',
   c: False},
e: '5678'}""")


# Generated at 2022-06-22 14:09:24.778222
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foobarba", "ba") == "ba"
    assert regex_search("barbathefool", "ba") == "ba"
    assert regex_search("foobarbathefool", "ba") == "ba"
    assert regex_search("barbathefoobar", "ba") == "ba"
    assert regex_search("foobarbathefoobar", "ba") == "ba"
    assert regex_search("thefoobarbathefoobar", "ba") == "ba"

    assert regex_search("foobarbazfoo", "ba(z)") == ["z"]
    assert regex_search("barbathefool", "ba(r)") == ["r"]
    assert regex_search("foobarbathefool", "ba(.)") == ["t"]

# Generated at 2022-06-22 14:09:34.461176
# Unit test for function regex_escape
def test_regex_escape():
    # python test
    assert regex_escape('a') == r'a'
    assert regex_escape('a.b') == r'a\.b'
    assert regex_escape('[b]') == r'\[b\]'
    assert regex_escape('$b') == r'\$b'
    assert regex_escape('a{b') == r'a\{b'
    assert regex_escape('a|b') == r'a\|b'
    assert regex_escape('a(b') == r'a\(b'
    assert regex_escape('a)b') == r'a\)b'
    assert regex_escape('a+b') == r'a\+b'
    assert regex_escape('a*b') == r'a\*b'

# Generated at 2022-06-22 14:09:42.572258
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(None)
        assert False
    except Exception as e:
        assert str(e) == 'Mandatory variable  not defined.'

    try:
        mandatory(None, "my message")
        assert False
    except Exception as e:
        assert str(e) == 'my message'



# Generated at 2022-06-22 14:09:51.564435
# Unit test for function regex_search
def test_regex_search():
    ''' Test regex_search filter '''
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import distribution as distribution_interface
    from ansible.module_utils.facts.system.distribution import _linux_distribution_alias
    from ansible.module_utils.facts.system.distribution import _set_distribution
    from ansible.module_utils.facts.system.distribution import _get_distribution
    from ansible.module_utils.facts.system.distribution import _guess_distribution
    distribution_interface.CACHE = {'distribution': Distribution()}

    # returns the entire match

# Generated at 2022-06-22 14:10:00.003324
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory("a") == "a"
    assert mandatory("a", "msg") == "a"
    assert mandatory(1) == 1
    assert mandatory([1, 2, 3]) == [1, 2, 3]

    try:
        mandatory(Undefined())
        assert False, "Should have raised exception"
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        mandatory(Undefined(msg="testmsg"))
        assert False, "Should have raised exception"
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)
        assert str(e) == "testmsg", str(e)



# Generated at 2022-06-22 14:10:03.222976
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("Hello World!") == "2ef7bde608ce5404e97d5f042f95f89f1c232871"


# Generated at 2022-06-22 14:10:07.292997
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1

    try:
        mandatory()
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'a' not defined."
    else:
        assert False

    try:
        mandatory(msg='some string')
    except AnsibleFilterError as e:
        assert to_native(e) == "some string"
    else:
        assert False



# Generated at 2022-06-22 14:10:14.528314
# Unit test for function regex_search
def test_regex_search():
    ''' Test regex_search'''
    assert regex_search(value='value1', regex=r'\w+') == 'value1'
    assert regex_search(value='value1', regex=r'\w+', multiline=True) == 'value1'
    assert regex_search(value='value1', regex=r'\w+', ignorecase=True) == 'value1'
    assert regex_search(value='value1', regex=r'\w+', ignorecase=True, multiline=True) == 'value1'
    assert regex_search(value=u'val\xF8e1', regex=r'\w+') == u'val\xF8e1'

# Generated at 2022-06-22 14:10:21.933625
# Unit test for function mandatory
def test_mandatory():
    from ansible.errors import AnsibleFilterError
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == u"Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), 'test message') == u'test message'
    except AnsibleFilterError as e:
        assert to_text(e) == to_text('test message')



# Generated at 2022-06-22 14:10:27.230474
# Unit test for function regex_search
def test_regex_search():
    """Test-cases for regex_search"""
    regex = regex_search('very long string', r'\w\s+\w')
    assert regex == 'y long'

    regex = regex_search('very long string', r'\w\s+\w', '\\g<1>')
    assert regex == 'y'

    regex = regex_search('very long string', r'(\w)\s+\w', '\\g<1>')
    assert regex == 'y'

    regex = regex_search('very long string', r'(\w)\s+\w', '\\g<2>')
    assert regex == ''



# Generated at 2022-06-22 14:10:28.349602
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    dict = {'a': 1, 'b': 2, 'c': 3}
    print(to_nice_yaml(dict, indent=2))

# Generated at 2022-06-22 14:10:38.931637
# Unit test for function regex_search
def test_regex_search():
    value = 'root:x:0:0:root:/root:/bin/bash'
    assert regex_search(value, r'^root') == 'root'
    assert regex_search(value, r'^root', ignorecase=True) == 'root'
    assert regex_search(value, r'^root', '\\g<0>') == ['root', 'root']
    assert regex_search(value, r'^ro[a-z]{3}', '\\g<0>') == ['root', 'root']
    assert regex_search(value, r'^root', '\\0') == 'root'
    assert regex_search(value, r'^root', '\\1') is None
    assert regex_search(value, r'^ro([a-z]{3})', '\\0') == 'root'
   

# Generated at 2022-06-22 14:10:53.778253
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("test", r"test")
    assert regex_search("test", r"test", "\\g<0>")
    assert regex_search("test", r"test", "\\g<1>") == []
    assert regex_search("test", r"(t)", "\\g<1>") == ["t"]
    assert regex_search("test", r"(t)", "\\g<1>", "\\g<1>") == ["t", "t"]
    assert regex_search("test", r"(t)", "\\1") == ["t"]
    assert regex_search("test", r"(t)", "\\1", "\\1") == ["t", "t"]



# Generated at 2022-06-22 14:11:01.779718
# Unit test for function fileglob
def test_fileglob():
    files = ['show_version.txt', 'running-config', 'hosts.yml']
    for f in files:
        open(f, 'a').close()
    try:
        assert(fileglob("*.txt") == ["show_version.txt"])
        assert(fileglob("*") == files)
    finally:
        for f in files:
            os.remove(f)



# Generated at 2022-06-22 14:11:08.971610
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/*') == ['/bin/bash', '/bin/cat', '/bin/cp', '/bin/date', '/bin/echo', '/bin/ls', '/bin/mkdir', '/bin/mv', '/bin/rm', '/bin/rmdir', '/bin/sh']

# Generated at 2022-06-22 14:11:13.524766
# Unit test for function fileglob
def test_fileglob():
    # Create an array of files and dirs
    # then use the function to check only files
    # are returned.
    file_list = ["/tmp/ansible_test_file1", "/tmp/ansible_test_file2",
                 "/tmp/ansible_test_dir1"]
    for ifile in file_list:
        if not os.path.isdir(ifile):
            open(ifile, 'a').close()
        else:
            os.makedirs(ifile)

# Generated at 2022-06-22 14:11:24.913335
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', '^abc$') == 'abc'
    assert regex_search('abc', '^abc$', '\\g<0>') == ['abc']
    assert regex_search('abc', '^a(.*)c$', '\\g<1>') == ['b']
    assert regex_search('abc', '^a(.*)c$', '\\1') == ['b']
    assert regex_search('abc', '^a(.*)c$', '\\2') == [None]
    assert regex_search('abc', '^a(.*)c$', '\\1', '\\g<1>', '\\2') == ['b', 'b', None]