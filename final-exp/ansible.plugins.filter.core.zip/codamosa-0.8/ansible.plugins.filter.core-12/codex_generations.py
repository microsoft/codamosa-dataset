

# Generated at 2022-06-22 14:01:49.206679
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory('abc') == 'abc'
    import jinja2.runtime
    u = jinja2.runtime.Undefined('env', name='a')
    try:
        mandatory(u)
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'a' not defined."


# Generated at 2022-06-22 14:02:02.191387
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcd efgh', r'(ef|cd)', '\\g<1>', ignorecase=True) == ['cd']
    assert regex_search('abcd efgh', r'(ef|cd)', '\\g<1>', '\\1', ignorecase=True) == ['cd', 'cd']
    assert regex_search('abcd efgh', r'(ef|cd)', '\\g<1>', '\\0', ignorecase=True) == ['cd', 'cd']
    assert regex_search('abcd efgh', r'(ef|cd)', ignorecase=True) == 'cd'
    assert regex_search('abcd efgh', r'(ef|cd)', '\\1', ignorecase=True) == ['cd']

# Generated at 2022-06-22 14:02:15.157925
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', 1524941899) == time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(1524941899))
    assert strftime('%Y-%m-%d %H:%M:%S', 1524941899.752164) == time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(1524941899.752164))

# Generated at 2022-06-22 14:02:18.936727
# Unit test for function to_yaml
def test_to_yaml():
    return [
        ("{{ [1, 2, 3] | to_yaml }}", "---\n- 1\n- 2\n- 3\n"),
    ]


# Generated at 2022-06-22 14:02:30.456718
# Unit test for function do_groupby
def test_do_groupby():
    """
    Unit test for function do_groupby
    """
    from collections import namedtuple
    from ansible.template import JinjaEnvironment

    jinja_env = JinjaEnvironment()

    # Invoke the function with a named tuple
    MyTuple = namedtuple("MyTuple", "a b c")
    mytuple = MyTuple("a", "b", "c")
    data = [mytuple]
    result = do_groupby(jinja_env, data, 'a')

    # Test
    assert type(result[0]) == tuple, 'Result of do_groupby filter is not a tuple'
    assert result[0][0] == "a", 'Result of do_groupby filter is incorrect'



# Generated at 2022-06-22 14:02:42.874737
# Unit test for function mandatory
def test_mandatory():
    pass

    # Tests are commented out to avoid import errors.
    # See https://github.com/ansible/ansible/issues/14012

#     from ansible.module_utils.common.text.converters import to_text

#     jinja_env = Environment(undefined=StrictUndefined)
#     jinja_env.filters['mandatory'] = mandatory

#     template = "{{ foo | mandatory(\"msg\") }}"
#     template_obj = jinja_env.from_string(template)
#     res = template_obj.render({"foo": "bla"})
#     assert res == "bla"

#     with pytest.raises(AnsibleFilterError):
#         res = template_obj.render({})

#     template = "{{ foo |

# Generated at 2022-06-22 14:02:53.230446
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('he llo', r'[\t ]+', ' ') == 'he llo'
    assert regex_replace('he llo', r'\s+', ' ') == 'he llo'
    assert regex_replace('hello', r'([a-z])\1', '#') == 'he#lo'
    assert regex_replace('hello', r'([a-z])\1', '#', multiline=True) == 'he#lo'
    assert regex_replace('the answer is 42.', r'(\d+)', r'<\1>') == 'the answer is <42>.'



# Generated at 2022-06-22 14:03:05.044509
# Unit test for function mandatory
def test_mandatory():
    def assert_raised(e, msg=None, regex=None):
        if not regex and msg is None:
            regex = 'Mandatory variable not defined.'

        if regex:
            assert re.search(regex, to_text(e)), 'exception: %s, regex: %s' % (to_text(e), regex)
        else:
            assert msg == to_text(e), 'exception: %s, msg: %s' % (to_text(e), msg)

    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert_raised(e)

    try:
        mandatory('some_value')
    except AnsibleFilterError as e:
        assert_raised(e)


# Generated at 2022-06-22 14:03:12.426724
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.errors import AnsibleFilterError
    from ansible.template import Templar
    from ansible.template.vars import AnsibleHostVars, AnsibleGroupVars

    env = Environment()
    env.filters['groupby'] = do_groupby
    templar = Templar(env, loader=None, shared_loader_obj=None, variables=dict())

    class MyVars(AnsibleHostVars):
        def __init__(self):
            self.vars = dict()

    hostvars = MyVars()
    groups = AnsibleGroupVars()
    groups.add_group('all', dict(group_vars=dict()), dict(children=dict()))

# Generated at 2022-06-22 14:03:19.706013
# Unit test for function fileglob
def test_fileglob():
    assert ['bar'] == sorted(fileglob('b*'))
    assert ['bar', 'baz'] == sorted(fileglob('[ab]*'))
    assert ['baz'] == sorted(fileglob('[!a]*'))
    assert ['bar', 'baz'] == sorted(fileglob('[!c]*'))
    assert ['bar', 'baz'] == sorted(fileglob('[[:alpha:]]*'))



# Generated at 2022-06-22 14:03:40.395723
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(u'foo bar foobar', u'bar', u'\\g<0>') == u'bar'
    assert regex_search(u'foo bar foobar', u'bar') == u'bar'
    assert regex_search(u'foo bar foobar', u'(.)ar', u'\\g<1>') == u'b'
    assert regex_search(u'foo bar foobar', u'(.)ar', u'\\g<0>') == u'bar'
    assert regex_search(u'foo bar foobar', u'(.)ar', u'\\2') == u''
    assert regex_search(u'foo bar foobar', u'(.)ar', u'\\1') == u'b'

# Generated at 2022-06-22 14:03:46.160832
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1,2,3]) == u'[1, 2, 3]\n'
    assert to_yaml(to_text('[1,2,3]')) == u'[1, 2, 3]\n'
    assert to_yaml(to_bytes('[1,2,3]')) == u'[1, 2, 3]\n'

    # ensure that the default for default_flow_style is False, as in previous versions of Ansible.
    assert to_yaml({'foo':'bar'}) == u'{foo: bar}\n'

    # but ensure that it can be overridden
    assert to_yaml({'foo':'bar'}, default_flow_style=True) == u'{foo: bar}\n...\n'

    # ensure that unicode is allowed.


# Generated at 2022-06-22 14:03:54.446861
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foobar', 'bar') == 'bar'
    assert regex_search('foobar', 'baz') is None
    assert regex_search('foobar', 'bar', '\\g<0>') == ['bar', 'bar']
    assert regex_search('foobar', 'baz', '\\g<0>') is None
    assert regex_search('foobar', 'b(a)r', '\\g<0>', '\\g<1>') == ['bar', 'a']
    assert regex_search('foobar', 'b(a)z', '\\g<0>', '\\g<1>') is None
    assert regex_search('foobar', 'b(a)z', '\\g<0>', ) is None

# Generated at 2022-06-22 14:04:05.776858
# Unit test for function fileglob
def test_fileglob():
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:04:13.389540
# Unit test for function ternary
def test_ternary():
    assert ternary(1, 'a', 'b') == 'a'
    assert ternary(0, 'a', 'b') == 'b'
    assert ternary(1, 'a', 'b', 'c') == 'a'
    assert ternary(0, 'a', 'b', 'c') == 'b'
    assert ternary(None, 'a', 'b', 'c') == 'c'



# Generated at 2022-06-22 14:04:22.124708
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Jinja2Environment
    from ansible.template.safe_eval import unsafe_eval

    env = Environment(undefined=Exception, extensions=[Jinja2Environment])

    person = [{'name': 'john', 'age': 45}, {'name': 'jessy', 'age': 24}, {'name': 'emily', 'age': 28}]

    jinja_unsafe_output = unsafe_eval('''{% set jinja_unsafe = person | groupby('age') %}
{{ jinja_unsafe }}''', dict(person=person), undefined=Exception, extensions=[Jinja2Environment])


# Generated at 2022-06-22 14:04:35.024410
# Unit test for function comment
def test_comment():
    '''Test function comment'''
    import yaml

# Generated at 2022-06-22 14:04:41.577409
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', '^abc$') == 'abc'
    assert regex_search('abc', '^a') == 'a'
    assert regex_search('abc', '^b') == None
    assert regex_search('abc', 'a', '\\1') == 'a'
    assert regex_search('abc', 'ab(.)', '\\g<1>') == 'c'



# Generated at 2022-06-22 14:04:53.881551
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.module_utils.six import text_type
    from collections import namedtuple
    mylist = [
        namedtuple("A", ['foo', 'bar'])("aaa", 2),
        namedtuple("B", ['foo', 'bar'])("aaa", 1),
        namedtuple("C", ['foo', 'bar'])("bbb", 1),
    ]
    templar = Templar(loader=DictDataLoader({}))
    result = do_groupby(templar.environment, mylist, attribute='foo')
    # Assert the function is applied to all sublists
    for k, v in result:
        for tuple_element in v:
            assert isinstance(tuple_element, tuple)

# Generated at 2022-06-22 14:05:02.158809
# Unit test for function do_groupby
def test_do_groupby():
    fixture = [{"foo": "bar", "baz": "qux"}, {"foo": "quux", "baz": "quuz"}]

    result = _do_groupby(None, fixture, 'foo')
    assert result == {'bar': [fixture[0]], 'quux': [fixture[1]]}

    result = _do_groupby(None, fixture, 'baz')
    assert result == {'qux': [fixture[0]], 'quuz': [fixture[1]]}


# Generated at 2022-06-22 14:05:17.051409
# Unit test for function mandatory
def test_mandatory():
    '''
    Test mandatory(v, msg=None)
    '''
    from jinja2.runtime import Undefined
    from ansible.errors import AnsibleFilterError

    # Test skipping optional parameters
    try:
        assert mandatory(42) == 42
    except AssertionError:
        raise AssertionError('mandatory(42) != 42')

    # Test skipping optional parameters
    try:
        assert mandatory(None) is None
    except AssertionError:
        raise AssertionError('mandatory(None) != None')

    # Test skipping optional parameters
    try:
        assert mandatory(Undefined('foo')) == Undefined('foo')
    except AssertionError:
        raise AssertionError('mandatory(Undefined(\'foo\')) != Undefined(\'foo\')')

    # Test default value

# Generated at 2022-06-22 14:05:21.857976
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}, default_flow_style=False) == \
        '''a: 1\nb: 2\nc:\n    a: 1\n    b: 2\n'''



# Generated at 2022-06-22 14:05:27.892652
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    # Test undefined
    A = Undefined(name="A")
    assert mandatory(A) is None
    try:
        assert mandatory(A, 'test message') is None
    except AnsibleFilterError as e:
        assert "test message" in str(e)
    # Test defined
    assert mandatory(A, 'test message') is None



# Generated at 2022-06-22 14:05:30.869945
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert hasattr(f, 'filters')

# Generated at 2022-06-22 14:05:37.733345
# Unit test for function fileglob
def test_fileglob():
    ''' fileglob() return list of matched regular files for glob '''
    assert fileglob("/etc/*") == ['/etc/passwd', '/etc/group', '/etc/shadow']
    assert fileglob("/etc/not_exist_file") == []
    assert fileglob("/etc/not_exist_file1*") == []
    assert fileglob("/etc/passwd") == ['/etc/passwd']


# ---- Helper function for runner, inventory, and lookup plugins ----

# Generated at 2022-06-22 14:05:44.808808
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(1) == 1
    assert mandatory({'key': 'value'}) == {'key': 'value'}
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory(None, msg='custom error message') == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(None, msg='custom error message') == None



# Generated at 2022-06-22 14:05:47.181905
# Unit test for function do_groupby
def test_do_groupby():
    g = do_groupby([{'a': 1, 'b': 1}, {'a': 2, 'b': 2}, {'a': 1, 'b': 3}], 'a')
    assert g == [(1, [{'a': 1, 'b': 1}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 2}])]

# Generated at 2022-06-22 14:05:53.749511
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', second=1532020887.0) == '2018-07-22 18:08:07'



# Generated at 2022-06-22 14:06:03.432475
# Unit test for function to_bool
def test_to_bool():
    if to_bool(None) is not None:
        return False
    if to_bool(True) is not True:
        return False
    if to_bool(False) is not False:
        return False
    if to_bool('yes') is not True:
        return False
    if to_bool('on') is not True:
        return False
    if to_bool('1') is not True:
        return False
    if to_bool('true') is not True:
        return False
    if to_bool(1) is not True:
        return False
    if to_bool('no') is not False:
        return False
    if to_bool('off') is not False:
        return False
    if to_bool('0') is not False:
        return False

# Generated at 2022-06-22 14:06:05.780972
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("some string") == "some string"
    try:
        mandatory(None)
    except Exception:
        pass



# Generated at 2022-06-22 14:06:18.003556
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    d = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'bam': {
            'inga': 'bert',
            'oink': 'oink'
        }
    }
    assert to_nice_yaml(d) == '''bam:
  inga: bert
  oink: oink
baz:
- 1
- 2
- 3
foo: bar
'''



# Generated at 2022-06-22 14:06:24.307563
# Unit test for function mandatory
def test_mandatory():
    '''Unit test for mandatory'''
    assert mandatory('test') == 'test'
    try:
        assert mandatory('test', msg="This is a test") == 'test'
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'This is a test'



# Generated at 2022-06-22 14:06:28.288691
# Unit test for function strftime
def test_strftime():
    assert "2018-08-23" == strftime("%Y-%m-%d")
    assert "23-08-2018" == strftime("%d-%m-%Y", 1535024441.0)


# Generated at 2022-06-22 14:06:41.428513
# Unit test for function mandatory
def test_mandatory():
    env = {}
    # test with a missing key
    env['string'] = 'this is a test...'
    assert mandatory(env['string']) == 'this is a test...'

    # test with a name for that missing key
    try:
        # trying to get a nonexistent key with a name
        mandatory(env['missing_key'], 'this message should be the one from the except')
    except AnsibleFilterError as e:
        err_msg = to_text(e)
        assert err_msg == "Mandatory variable 'missing_key' not defined."
    else:
        assert False, 'No Error was raised for missing key'

    # test with a missing key and a custom message

# Generated at 2022-06-22 14:06:47.602183
# Unit test for function comment
def test_comment():
    # Test type plain
    assert comment('Hello world!') == '# Hello world!'
    assert comment('Hello world!', 'plain') == '# Hello world!'
    assert comment('Hello world!', 'plain', decoration='-- ') == '-- Hello world!'
    assert comment('Hello world!', decoration='-- ') == '-- Hello world!'
    assert comment('Hello world!', 'plain', newline='\n', decoration='-- ') == '-- Hello world!\n'
    assert comment('Hello world!', 'plain', newline='\n', decoration='-- ', prefix='-- ', prefix_count=2) == '-- Hello world!\n'

# Generated at 2022-06-22 14:06:50.842143
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("this is a test", "md5") == "08e4e8d11c47a2d0ee43c1662cdd8a90"



# Generated at 2022-06-22 14:07:04.882152
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import do_groupby

    input = [{'id': 1, 'name': 'foo'}, {'id': 1, 'name': 'bar'}, {'id': 2, 'name': 'baz'}]
    expected = [(1, [{'id': 1, 'name': 'foo'}, {'id': 1, 'name': 'bar'}]),
                (2, [{'id': 2, 'name': 'baz'}])]
    actual = do_groupby(input, 'id')
    assert list(actual) == expected, 'Error when grouping on a simple key'

    input = [{'id': 1, 'name': 'foo'}, {'id': 1, 'name': 'bar'}, {'id': 2, 'name': 'baz'}]

# Generated at 2022-06-22 14:07:13.306378
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', 'es', '\\1') == ['s']
    assert regex_search('', 'es', '\\1') is None
    assert regex_search('test', 'es', '\\g<1>') == ['s']
    assert regex_search('test', '(es)', '\\1', '\\g<1>') == ['es', 'es']
    assert regex_search('test', '(es)', '\\1', '\\g<2>') == ['es']
    assert regex_search('test TEST', '(?i)test', '\\1') == ['test']


# Generated at 2022-06-22 14:07:21.207959
# Unit test for function comment
def test_comment():
    assert (
        comment("This is the comment.", style='xml') ==
        """<!-- - This is the comment. -->"""
    )
    assert (
        comment("This is the comment.", style='cblock') ==
        """/* * This is the comment. */"""
    )
    assert (
        comment("This is the comment.", style='erlang') ==
        """% This is the comment.\n"""
    )
    assert (
        comment("This is the comment.", style='c') ==
        """// This is the comment.\n"""
    )
    assert (
        comment("This is the comment.", style='plain') ==
        """# This is the comment.\n"""
    )

    # Test style xml with options

# Generated at 2022-06-22 14:07:32.605541
# Unit test for function do_groupby
def test_do_groupby():
    items = [{"id": 1, "name": "foo"}, {"id": 2, "name": "bar"}, {"id": 1, "name": "baz"}]
    res = do_groupby(items, "id")
    assert isinstance(res, list) and isinstance(res[0][1], list) and len(res[0][1]) == 2
    assert res[0][0] == 1
    assert sorted(res[0][1], key=lambda x: x["name"]) == [{"id": 1, "name": "baz"}, {"id": 1, "name": "foo"}]
    assert res[1] == (2, [{"id": 2, "name": "bar"}])

# Generated at 2022-06-22 14:07:47.891061
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, 3], 4, 5]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, 3], [4, 5], 6]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, [2, [3, 4], 5], 6]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, [2, [3, 4], 5], 6], levels=1) == [1, 2, [3, 4], 5, 6]
    assert flatten

# Generated at 2022-06-22 14:07:55.350237
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    current_result = [{
        "k1": u"\u0418\u0432\u0430\u043d\u043e\u0432",
        "k2": u"\u0420\u043e\u0441\u0441\u0438\u044f",
        "k3": u"\u041c\u043e\u0441\u043a\u0432\u0430"
    }]

# Generated at 2022-06-22 14:08:05.054973
# Unit test for function to_yaml
def test_to_yaml():
    ex = u'\u20ac'
    test_string = u'test42' + ex
    test_dict = dict(a=42, b=dict(c='foo'), d=[1, 2, 3])
    test_dict['b']['c'] = [test_string, ex]
    test_dict['d'].append(test_string)
    assert to_yaml(test_dict) == u'a: 42\nb:\n  c:\n  - test42€\n  - €\nd:\n- 1\n- 2\n- 3\n- test42€\n'

# Generated at 2022-06-22 14:08:06.499494
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None



# Generated at 2022-06-22 14:08:19.516792
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'\*') == r'\\\*'
    assert regex_escape(r'*') == r'\*'
    assert regex_escape(r'.') == r'\.'
    assert regex_escape(r'?') == r'\?'
    assert regex_escape(r'+') == r'\+'
    assert regex_escape(r'$') == r'\$'
    assert regex_escape(r'|') == r'\|'
    assert regex_escape(r'{') == r'\{'
    assert regex_escape(r'}') == r'\}'
    assert regex_escape(r'[') == r'\['
    assert regex_escape(r']') == r'\]'
    assert regex_escape(r'(') == r'\('

# Generated at 2022-06-22 14:08:27.637268
# Unit test for function do_groupby
def test_do_groupby():
    assert do_groupby(env(), [{'foo':'bar','a':1},{'foo':'baz','a':2}], 'foo') == [
        ('bar', [{'foo':'bar','a':1}]),
        ('baz', [{'foo':'baz','a':2}])
    ]
    assert do_groupby(env(), [{'foo':'bar','a':1},{'foo':'baz','a':2}], AttributeDict(foo='foo')) == [
        ('bar', [{'foo':'bar','a':1}]),
        ('baz', [{'foo':'baz','a':2}])
    ]

# Generated at 2022-06-22 14:08:38.940243
# Unit test for function regex_search
def test_regex_search():
    '''
    Test cases for function regex_search
    '''

# Generated at 2022-06-22 14:08:52.354477
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', 't') == 't'
    assert regex_search('test', 't', '\\g<0>') == 't'
    assert regex_search('test', 't', '\\1') == 't'
    assert regex_search('test', 't', '\\g<0>', '\\1') == ['t', 't']
    assert regex_search('test', 'tes(t)', '\\1') == 't'
    assert regex_search('test', 't(es)t', '\\1') == 'es'
    assert regex_search('test', 't(es)t', '\\g<1>') == 'es'
    assert regex_search('test', 't(es)t', '\\g<1>', '\\g<0>') == ['es', 'test']

# Generated at 2022-06-22 14:09:00.291310
# Unit test for function do_groupby
def test_do_groupby():
    from ansible import constants as C

    # using a bare dict so there aren't any contrib modules loaded
    from ansible.template import Templar

    C.DEFAULT_JINJA2_NATIVE = False
    templar = Templar(loader=DictLoader(), variables={u'buildings': [
                      {u'address': u'Foo', u'name': u'Large'}, {u'address': u'Foo', u'name': u'Small'}]}, shared_loader_obj=None)
    value = templar.template('{{ buildings | groupby("address") }}',
                             preserve_trailing_newlines=True, convert_data=False)

# Generated at 2022-06-22 14:09:12.240218
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("some text", "some") == "some"
    assert regex_search("some text", "some", "\\g<1>") == ["some"]
    assert regex_search("some text", "some", "\\g<1>", "\\1") == ["some", "ome"]
    assert regex_search("some text", "some", "\\g<0>", "\\1") == ["some", ""]
    assert regex_search("some text", "some", "\\3") == [""]
    assert regex_search("some text", "some", "\\g<2>") == []
    assert regex_search("some text", "some", ignorecase=True) == "some"
    assert regex_search("some text", "SOME", ignorecase=True) == "some"

# Generated at 2022-06-22 14:09:27.309575
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.runtime import Undefined
    from jinja2.runtime import StrictUndefined
    for undefined_class in [Undefined, StrictUndefined]:
        assert do_groupby([{'a': 1, 'b': 3, 'c': 2}, {'a': 2, 'b': 1, 'c': 4}], 'b') == [
            (3, [{'a': 1, 'b': 3, 'c': 2}]),
            (1, [{'a': 2, 'b': 1, 'c': 4}])
        ]

# Generated at 2022-06-22 14:09:32.838640
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    data = {'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'hello', 'var': 'nested_data'}}]}
    result = to_nice_yaml(data)
    assert isinstance(result, text_type)
    assert 'tasks:\n' in result
    assert 'debug: {msg: hello, var: nested_data}\n' in result



# Generated at 2022-06-22 14:09:44.960400
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo","foo") == "foo"
    assert regex_search("foo bar baz","bar") == "bar"
    assert regex_search("foo bar baz","^bar") == None
    assert regex_search("foo","(o)") == ['o']
    assert regex_search("foo","(o)",1) == 'o'
    assert regex_search("foo","(.)(.)") == ['fo']
    assert regex_search("foo","(.)(.)",'\\g<1>') == 'f'
    assert regex_search("foo","(.)(.)",'\\g<2>') == 'o'
    assert regex_search("foo","(.)(.)",'\\g<1>','\\g<2>') == ['f','o']

# Generated at 2022-06-22 14:09:53.053755
# Unit test for function mandatory
def test_mandatory():
    t = {'a': 1, 'b': 2}

    try:
        ret = mandatory(t)
    except AnsibleFilterError:
        raise AssertionError('Should not fail without argument')

    try:
        ret = mandatory(t, 'incorrect')
    except AnsibleFilterError:
        raise AssertionError('Should not fail without argument')

    try:
        ret = mandatory(t['a'])
    except AnsibleFilterError:
        raise AssertionError('Should not fail with defined argument')

    try:
        ret = mandatory(t['a'], 'incorrect')
    except AnsibleFilterError:
        raise AssertionError('Should not fail with defined argument')


# Generated at 2022-06-22 14:10:05.502768
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('1 hello world', '\\d+', '\\g<0>') == ['1', 'hello world']
    assert regex_search('1 hello world', '\\d+', '\\0') == ['1', 'hello world']
    assert regex_search('1 hello world', '\\d+', '\\1') == ['1', None]
    assert regex_search('1 hello world', '\\d+', '\\g<1>') == ['1', None]
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'lmnop') == 'lmnop'



# Generated at 2022-06-22 14:10:10.175821
# Unit test for function to_yaml
def test_to_yaml():
    test_data = dict(a=1, b=2, c=3)
    result = to_yaml(test_data, default_flow_style=False)
    assert '\n' in result, \
        "to_yaml doesn't use newlines as expected. The output was: " + result



# Generated at 2022-06-22 14:10:19.685239
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(42) == 42
    assert mandatory(Undefined(name="foo")) == 'bar'

    try:
        mandatory(Undefined(), "foo")
        pytest.fail("exception was not raised")
    except AnsibleFilterError as e:
        assert "foo" in to_native(e)

    try:
        mandatory(Undefined(name="foo"))
        pytest.fail("exception was not raised")
    except AnsibleFilterError as e:
        assert "'foo' " in to_native(e)



# Generated at 2022-06-22 14:10:22.387555
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('data', 'md5') == '1bc29b36f623ba82aaf6724fd3b16718'


# Generated at 2022-06-22 14:10:33.300332
# Unit test for function mandatory
def test_mandatory():
    '''mandatory: basic tests'''
    assert mandatory(42) == 42
    assert mandatory(42, msg='mymsg') == 42
    assert mandatory(None, msg='mymsg') == None
    try:
        mandatory()
    except AnsibleFilterError as e:
        assert 'not defined' in to_native(e)
    try:
        mandatory(undefined)
    except AnsibleFilterError as e:
        assert 'not defined' in to_native(e)
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'not defined' in to_native(e)



# Generated at 2022-06-22 14:10:41.351788
# Unit test for function do_groupby
def test_do_groupby():
    # do_groupby is used in many filters and will be tested in one of them,
    # but this is a minimal test that is specific to the function itself
    assert do_groupby([{"a": 1, "b": "z"}, {"a": 1, "b": "y"}, {"a": 2, "b": "x"}], attribute='a') == [
        (1, [{"a": 1, "b": "z"}, {"a": 1, "b": "y"}]),
        (2, [{"a": 2, "b": "x"}])
    ]

# Generated at 2022-06-22 14:10:55.927437
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d') == time.strftime('%Y-%m-%d', time.localtime())
    assert strftime('%Y-%m-%d', second=1405003352.0) == '2014-07-14'
    assert strftime('%a, %d %b %Y %H:%M:%S', second=1405003352.0) == 'Mon, 14 Jul 2014 18:29:12'
    assert strftime('%Y-%m-%d', second='1398536552') == '2014-07-14'


# Generated at 2022-06-22 14:11:02.789463
# Unit test for function randomize_list
def test_randomize_list():
    my_list = ['a', 'b', 'c', 'd', 'f']
    my_list_copy = my_list[:]
    my_randomized_list = randomize_list(my_list, seed=0)
    assert(sorted(my_list_copy) == sorted(my_list))
    assert(my_randomized_list != my_list_copy)



# Generated at 2022-06-22 14:11:08.577803
# Unit test for function extract
def test_extract():
    data = {'a': {'b': 'c'}, '1': {'2': {'3': {'4': 'value'}}}}
    assert extract(data, 'a', data) == {'b': 'c'}
    assert extract(data, 'b', data['a']) == 'c'
    assert extract(data, 'a', data, 'b') == 'c'
    assert extract(data, '1', data, ['2', '3']) == {'4': 'value'}
    assert extract(data, '1', data, ['2', '3', '4']) == 'value'


# Generated at 2022-06-22 14:11:20.124332
# Unit test for function do_groupby
def test_do_groupby():
    groups = ['g1', 'g2', 'g3']
    value = ['a1', 'a2', 'a3']
    class Container(object):
        def __init__(self,group):
            self.group = group
    data = map(lambda g,v: Container(g),groups,value)
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(None)
    combined_vars = combine_vars(loader=loader, variables=dict(group='g1'))
    variable_manager.set_nonpersistent_facts(combined_vars)
    environment