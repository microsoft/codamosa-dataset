

# Generated at 2022-06-22 14:01:58.834220
# Unit test for function fileglob
def test_fileglob():
    #setup
    directory = 'tests/module/utils/module_utils/basic/'
    # test
    files = fileglob(directory+'included_vars.py')
    if not len(files) > 0:
        raise AssertionError()



# Generated at 2022-06-22 14:02:10.311830
# Unit test for function regex_search
def test_regex_search():
    # Test for str
    assert regex_search("Hello World","Hello") == "Hello"
    assert regex_search("Hello World", r"Hello\s(\w+)") == "World"
    assert regex_search("Hello World",r"(\w+)\s(\w+)","\\2") == "World"
    assert regex_search("Hello World",r"(\w+)\s(\w+)","\\1") == "Hello"
    assert regex_search("Hello World",r"(\w+)\s(\w+)","\\1","\\2") == ["Hello","World"]
    assert regex_search("Hello World",r"(\w+)\s(\w+)","\\2","\\1") == ["World","Hello"]
    # Test for int

# Generated at 2022-06-22 14:02:16.484834
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('hello', 'l', replacement='z') == 'hezzo'
    assert regex_replace('hello', 'l', replacement='z', ignorecase=True) == 'hezzo'
    assert regex_replace('hello', 'x', replacement='z', ignorecase=True) == 'hello'
    assert regex_replace('foo\nbar\r\nbaz\r\n', '\r?\n', replacement=' ', multiline=True) == 'foo bar baz '



# Generated at 2022-06-22 14:02:29.550667
# Unit test for function mandatory
def test_mandatory():

    assert mandatory(1) == 1

    try:
        assert mandatory(None) == None
    except AnsibleFilterError:
        pass

    try:
        assert mandatory(True) == True
    except AnsibleFilterError:
        pass

    try:
        assert mandatory(None, "Mandatory variable not defined.") == None
    except AnsibleFilterError:
        pass

    try:
        assert mandatory(True, "Mandatory variable not defined.") == True
    except AnsibleFilterError:
        pass

    try:
        assert mandatory(None, "Mandatory variable msg.") == None
    except AnsibleFilterError:
        pass

    try:
        assert mandatory(True, "Mandatory variable msg.") == True
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 14:02:34.535954
# Unit test for function flatten
def test_flatten():
    """Returns a tuple of success boolean and a string message.

    For behavior, see the docstring for the actual function.
    """
    data = [
      "item1",
      "item2",
      [
        ["item3-1", "item3-2"],
        "item4"
      ],
      [
        "item5",
        "item6",
        [
          "item7",
          "item8"
        ]
      ],
      "item9"
    ]

# Generated at 2022-06-22 14:02:45.422472
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'123aaaaaaaa') == '123aaaaaaaa'
    assert regex_escape(r'123aaaaaaaa', re_type='python') == '123aaaaaaaa'
    assert regex_escape(r'123a.a^$*aa', re_type='posix_basic') == r'123a\.a\^\$\*aa'
    assert regex_escape(r'123[a.a^$*aa', re_type='posix_basic') == r'123\[a\.a\^\$\*aa'
    assert regex_escape(r'123[a.a^$*aa') == r'123\[a\.a\^\$\*aa'

# Generated at 2022-06-22 14:02:49.613311
# Unit test for function flatten

# Generated at 2022-06-22 14:02:57.866465
# Unit test for function regex_replace
def test_regex_replace():
    string = 'https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html#using-filters-in-loops'
    pattern = r'https://(.*?)/'
    replacement = 'https://docs.ansible.com/ansible/'
    result = regex_replace(string, pattern, replacement)
    assert 'https://docs.ansible.com/ansible/latest/user_guide/playbooks_filters.html' in result



# Generated at 2022-06-22 14:03:05.661317
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('''line1.
line2
line3''', r'^line', r'RESULT', multiline=True) == '''RESULT1.
RESULT2
RESULT3'''
    assert regex_replace('''line1
line2
line3''', r'^line', r'RESULT', multiline=False) == '''line1
line2
line3'''
    assert regex_replace(r'one.two.three', r'\.', r'-') == 'one-two-three'



# Generated at 2022-06-22 14:03:12.990354
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=vars_manager, host_list=[])
    templar = Templar(loader=loader, variables=vars_manager)

    test_var = {'test': [
        {'a': 1, 'b': 3, 'c': 1},
        {'a': 1, 'b': 2, 'c': 2},
        {'a': 2, 'b': 4, 'c': 3},
        ]}


# Generated at 2022-06-22 14:03:30.087226
# Unit test for function fileglob
def test_fileglob():
    if 'fileglob' not in globals():
        globals()['fileglob'] = None
    globals()['fileglob'] = fileglob
    assert fileglob('/usr/share/man/man1/g?m*') == ['/usr/share/man/man1/gm4.1']



# Generated at 2022-06-22 14:03:39.437015
# Unit test for function to_yaml
def test_to_yaml():
    to_yaml(dict(a=1, b=2, c=3)) == '''{a: 1, b: 2, c: 3}\n'''
    to_yaml([1, 2, 3]) == '''[1, 2, 3]\n'''
    to_yaml([dict(a=1, b=2, c=3), dict(a=1, b=2, c=3)]) == '''[{a: 1, b: 2, c: 3}, {a: 1, b: 2, c: 3}]\n'''

# Generated at 2022-06-22 14:03:40.478374
# Unit test for function randomize_list
def test_randomize_list():
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 14:03:43.674700
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('test/*.txt') == ['test/a.txt', 'test/b.txt']



# Generated at 2022-06-22 14:03:45.491373
# Unit test for function fileglob
def test_fileglob():
    if fileglob('test/') != []:
        raise Exception("fileglob function error")



# Generated at 2022-06-22 14:03:53.110927
# Unit test for function do_groupby
def test_do_groupby():
    env = jinja2.Environment()
    env.filters['groupby'] = do_groupby
    t = jinja2.Template("""{{ [{'a': 1}, {'a': 2}, {'a': 3}]|groupby('a') }}""")
    assert t.render(env) == "[(1, [{'a': 1}]), (2, [{'a': 2}]), (3, [{'a': 3}])]"

# end unit test for function do_groupby



# Generated at 2022-06-22 14:04:04.416693
# Unit test for function strftime
def test_strftime():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            format=dict(type='str'),
            epoch=dict(type='float', default=None),
        ),
    )
    print_result = partial(display.display, module._name, color=module.color)

    def test_strftime(format, epoch, expected):
        print_result('format: "%s" epoch: %s' % (format, epoch))
        actual = strftime(format, epoch)
        print_result('  actual: "%s"' % actual)
        print_result('  expected: "%s"' % expected)
        if actual == expected:
            print_result('  PASS')
        else:
            print_result('  FAIL')
            assert False



# Generated at 2022-06-22 14:04:10.970594
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    # Test normal
    assert mandatory("123") == "123"
    assert mandatory(123) == 123
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(None) == None

    # Test undefined
    # No name
    try:
        mandatory(Undefined())
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'
    # With name
    try:
        mandatory(Undefined(name='foobar'))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foobar' not defined."
    # With custom message

# Generated at 2022-06-22 14:04:20.385238
# Unit test for function get_hash
def test_get_hash():
    assert (get_hash("123", "md5") == "202cb962ac59075b964b07152d234b70")
    assert (get_hash("123", "sha1") == "40bd001563085fc35165329ea1ff5c5ecbdbbeef")
    assert (get_hash("123", "sha224") == "dffd6021bb2bd5b0af676290809ec3a53191dd81c6f7e93b4c6107390")
    assert (get_hash("123", "sha256") == "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3")

# Generated at 2022-06-22 14:04:23.586136
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = {'one': 'two', 'three': {'four': 'five'}}
    wanted = '''
one: two
three:
    four: five
'''
    assert to_nice_yaml(a) == wanted , "Did not get correct value"



# Generated at 2022-06-22 14:04:32.337927
# Unit test for function to_yaml
def test_to_yaml():
    result = to_yaml({'a': 2, 'b': 3})
    assert result == "---\na: 2\nb: 3\n", result
    result = to_yaml({'a': 2, 'b': 3}, width=1)

# Generated at 2022-06-22 14:04:36.150655
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(1) == 1
    assert mandatory(Undefined(), msg='Foo') == 'Foo'



# Generated at 2022-06-22 14:04:40.049390
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    '''
    ansible.utils.listify: Test to_nice_yaml
    '''
    assert to_nice_yaml({"a": ["b"]}, default_flow_style=True) == u"{a: [b]}\n..."



# Generated at 2022-06-22 14:04:47.882320
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('', 'python') == ''
    assert regex_escape('', 'posix_basic') == ''
    for re_type in ('python', 'posix_basic'):
        assert regex_escape('foo', re_type) == 'foo'
        assert regex_escape('1', re_type) == '1'
        assert regex_escape('1.0', re_type) == '1\\.0'
        assert regex_escape('[1.0]', re_type) == '\\[1\\.0\\]'
        assert regex_escape('{1.0}', re_type) == '\\{1\\.0\\}'
        assert regex_escape('', re_type) == ''
        assert regex_escape('.', re_type) == '\\.'

# Generated at 2022-06-22 14:04:53.887731
# Unit test for function mandatory
def test_mandatory():
    # Test if function raises exception in case of empty string
    try:
        mandatory('')
    except AnsibleFilterError as exception:
        assert exception.args[0] == 'Mandatory variable \'\' not defined.'

    # Test if custom message is displayed instead of default one
    try:
        mandatory('', msg='Some error happened.')
    except AnsibleFilterError as exception:
        assert exception.args[0] == 'Some error happened.'



# Generated at 2022-06-22 14:05:02.895805
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'\$') == r'\\\$'
    assert regex_escape(r'\\') == r'\\\\'
    assert regex_escape(r'[a-z]+', re_type='posix_basic') == r'\[a\-z\]\+'
    assert regex_escape(r'[a-z]+', re_type='posix_extended') == r'\\[a\\-z\\]+'
    # TODO: more testing of re_types
# end of test_regex_escape()



# Generated at 2022-06-22 14:05:09.721229
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc-123/abc', 'abc', '\g<0>') == 'abc'
    assert regex_search('abc-123/abc', 'abc-(\d+)', '\g<1>') == '123'
    assert regex_search('abc-123/abc', 'abc-(?P<num>\d+)', '\g<num>') == '123'
    assert regex_search('abc-123/abc', 'abc', '\0') == 'abc'
    assert regex_search('abc-123/abc', 'abc-(\d+)', '\1') == '123'



# Generated at 2022-06-22 14:05:22.506142
# Unit test for function regex_search
def test_regex_search():
    # Test single group
    assert regex_search('one1two2three3', '(\d)') == '1'
    # Test multiple groups
    assert regex_search('one1two2three3', '(\d)', '\\g<1>', '\\g<1>') == ['1', '1']
    # Test single group N
    assert regex_search('one1two2three3', '(\d)', '\\1') == ['1']
    # Test multiple groups N
    assert regex_search('one1two2three3', '(\d)', '\\1', '\\1') == ['1', '1']
    # Test single named group
    assert regex_search('one1two2three3', '(?P<digit>\d)', '\\g<digit>') == ['1']
    # Test multiple named groups


# Generated at 2022-06-22 14:05:35.305872
# Unit test for function regex_search
def test_regex_search():

    # test list return value
    assert regex_search('blah', 'l', '\\g<2>') == ['l']

    # test single string return value
    assert regex_search('blah', 'l') == 'l'

    # test multiple return values for multiple groups
    assert regex_search('blah', 'bl(a)h', '\\g<1>', '\\g<2>', ignorecase=True) == ['a', 'h']

    # test first group return value
    assert regex_search('blah', 'l', '\\g<1>') == 'l'

    # test multiple groups
    assert regex_search('Blah', 'bl(a)h', '\\g<1>', '\\g<2>', ignorecase=True) == ['a', 'h']

    # test first group return value
   

# Generated at 2022-06-22 14:05:39.541408
# Unit test for function fileglob
def test_fileglob():
    # test with one file
    file = 'test.html'
    open(file, 'a').close()
    result = fileglob('test.*')
    assert result == [file]
    os.remove(file)

    # test with no file
    result = fileglob('test.*')
    assert result == []



# Generated at 2022-06-22 14:05:57.213612
# Unit test for function mandatory
def test_mandatory():
    for a in [None, '', ' ']:
        try:
            mandatory(a)
            assert False, "Failed to fail with input %s" % a
        except AnsibleFilterError:
            pass

    for a in [0, 1, "string"]:
        if mandatory(a) != a:
            assert False, "Failed to pass with input %s" % a

    for a in [None, '', ' ']:
        try:
            mandatory(a, msg="Failed to error with this message")
            assert False, "Failed to fail with input %s" % a
        except AnsibleFilterError as e:
            if not "Failed to error with this message" in to_native(e):
                assert False, "Failed to pass with input %s" % a



# Generated at 2022-06-22 14:06:09.235226
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2 as j2
    assert _do_groupby(None, [{'x': 1, 'y': 'a'}, {'x': 2, 'y': 'b'}, {'x': 1, 'y': 'c'}], 'x') == [
        ('a', [{'x': 1, 'y': 'a'}, {'x': 1, 'y': 'c'}]),
        ('b', [{'x': 2, 'y': 'b'}])]

# Generated at 2022-06-22 14:06:12.704377
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp') == []
    assert fileglob('/tmp/test') == []
    assert fileglob('/usr/share/dict/words') == ['/usr/share/dict/words']


# Generated at 2022-06-22 14:06:19.476979
# Unit test for function to_yaml
def test_to_yaml():
    input_string = '{"a":1424935800,"b":"2015-02-18T05:36:40Z"}'
    output_string = 'a: 1424935800\nb: 2015-02-18T05:36:40Z\n'
    assert to_yaml(input_string) == output_string



# Generated at 2022-06-22 14:06:31.513336
# Unit test for function fileglob
def test_fileglob():
    # create f1, f2, f3 and f4
    for f in ('f1', 'f2', 'f3', 'f4'):
        with open(f, 'w') as w:
            w.write('a')
    try:
        assert fileglob('*') == ['f1', 'f2', 'f3', 'f4']
        assert fileglob('f[1-3]') == ['f1', 'f2', 'f3']
        assert fileglob('f[!0-9]') == []
        assert fileglob('f1') == ['f1']
    finally:
        # remove f1, f2, f3 and f4
        for f in ('f1', 'f2', 'f3', 'f4'):
            os.remove(f)



# Generated at 2022-06-22 14:06:42.878201
# Unit test for function do_groupby
def test_do_groupby():
    a = [{'class': 'user', 'age': 28, 'sex': 'male'},
         {'class': 'user', 'age': 28, 'sex': 'female'},
         {'class': 'user', 'age': 28, 'sex': 'male'},
         {'class': 'admin', 'age': 49, 'sex': 'female'},
         {'class': 'user', 'age': 38, 'sex': 'female'},
         {'class': 'user', 'age': 28, 'sex': 'male'}]
    obj = {'a': a}
    res = do_groupby(obj, 'a', 'class')

# Generated at 2022-06-22 14:06:47.503995
# Unit test for function extract
def test_extract():
    '''
    Test for the correct extraction of elements from dictionaries,
    lists and nested versions of these.
    '''
    environments = [
        AnsibleEnvironment(),
        AnsibleEnvironment(strict=False)
    ]


# Generated at 2022-06-22 14:06:50.045980
# Unit test for function regex_replace
def test_regex_replace():
    result = regex_replace("abcdef", "ef", "xx")
    assert result == 'abcxx'



# Generated at 2022-06-22 14:06:56.486021
# Unit test for function fileglob
def test_fileglob():
    import tempfile
    import shutil
    import os.path
    assert [] == fileglob('/path/to/nowhere')
    # We want to do some testing in a temporary directory, so we make our own.
    # We use mkdtemp() to make a unique temporary directory so that concurrent
    # processes don't step on each other.
    temp_dir_name = tempfile.mkdtemp()
    # To make sure we have a reliable test, we need to start with an empty
    # directory. We don't know what might be left over from an earlier test in
    # a different process.
    for item in os.listdir(temp_dir_name):
        full_path = os.path.join(temp_dir_name, item)
        if os.path.isdir(full_path):
            shutil.rmtree

# Generated at 2022-06-22 14:06:59.802576
# Unit test for function regex_replace
def test_regex_replace():
    value = "test"
    pattern = "^test"
    replacement = "different"
    assert regex_replace(value, pattern, replacement) == "different"



# Generated at 2022-06-22 14:07:06.272851
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    #
    # Test extract
    #
    fm = FilterModule()
    value = {'key1': {'key2': 'value2'}}
    assert(fm.filters()['extract'](value, 'key1', 'outer')) == value['key1']
    assert(fm.filters()['extract'](value, 'key2', 'key1')) == 'value2'

# Generated at 2022-06-22 14:07:16.556982
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(dict(a=1)) == dict(a=1)
    assert mandatory(42) == 42
    assert mandatory(42, msg="my custom message") == 42
    try:
        mandatory(None)
    except AnsibleFilterError as e:
        assert to_text(e).startswith("Mandatory variable not defined.")
        assert to_text(e).endswith("undefined_var_name")
    try:
        mandatory(AnsibleUndefined('foo'))
    except AnsibleFilterError as e:
        assert to_text(e).startswith("Mandatory variable not defined.")
        assert to_text(e).endswith("foo")
    assert mandatory(to_native(AnsibleUndefined('foo'))) == 'foo'

# Generated at 2022-06-22 14:07:25.835485
# Unit test for function strftime
def test_strftime():
    assert strftime('%a') == 'Sat'
    assert strftime('%A') == 'Saturday'
    assert strftime('%w') == '6'
    assert strftime('%d') == '09'
    assert strftime('%b') == 'Mar'
    assert strftime('%B') == 'March'
    assert strftime('%m') == '03'
    assert strftime('%y') == '18'
    assert strftime('%Y') == '2018'
    assert strftime('%H') == '06'
    assert strftime('%I') == '06'
    assert strftime('%p') == 'AM'
    assert strftime('%M') == '38'
    assert strftime('%S') == '45'
    assert strftime('%f') == '001975'
    assert str

# Generated at 2022-06-22 14:07:31.200170
# Unit test for function mandatory
def test_mandatory():
    test_name = sys._getframe().f_code.co_name
    def _test_mandatory(a, msg=None, expected_result=None, expected_exception=None):
        if expected_exception:
            try:
                result = mandatory(a, msg=msg)
            except AnsibleFilterError as e:
                if expected_exception not in to_native(e):
                    test_error = True
                    raise AssertionError('{0}(a={1!r}, msg={2!r}): unexpected exception. got={3}, expected={4}'.format(
                        test_name, a, msg, to_native(e), expected_exception))
            else:
                test_error = True

# Generated at 2022-06-22 14:07:39.691169
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(42) == 42
    assert mandatory(Undefined(name='test_mandatory')) == Undefined
    try:
        mandatory(Undefined)
    except AnsibleFilterError as e:
        assert "Mandatory variable ''" in to_native(e)
    try:
        mandatory(Undefined(name='test_mandatory'), "custom error message")
    except AnsibleFilterError as e:
        assert "custom error message" in to_native(e)



# Generated at 2022-06-22 14:07:42.594507
# Unit test for function mandatory
def test_mandatory():
    d = dict()
    d['a'] = 'hello'
    assert mandatory(d.get('a')) is 'hello'
    assert mandatory(d.get('b'), msg="b is missing") is None



# Generated at 2022-06-22 14:07:50.434635
# Unit test for function comment
def test_comment():
    test_data = {
        'plain': 'test plain comment\n',
        'erlang': '% test erlang comment\n',
        'c': '// test c comment\n',
        'cblock': '/*\n * test cblock comment\n */',
        'xml': '<!-- \n - test xml comment\n-->'
    }

    for style in test_data:
        assert test_data[style] == comment(
            'test %s comment' % style,
            style,
            prefix_count=0
        )

    assert '# test comment\n# with two lines\n' == comment('test comment\nwith two lines', 'plain',
                                                            prefix_count=1, decoration='# ')


# Generated at 2022-06-22 14:08:03.104023
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # Prepare test data
    a = { 'a': 1, 'b': 2, 'c': 3 }
    # Test without indent
    transformed0 = to_nice_yaml(a)
    b0 = yaml.load(transformed0, Loader=yaml.BaseLoader)
    assert a == b0
    # Test with indent=4
    transformed4 = to_nice_yaml(a, indent=4)
    b4 = yaml.load(transformed4, Loader=yaml.BaseLoader)
    assert a == b4
    # Test with indent=2
    transformed2 = to_nice_yaml(a, indent=2)
    b2 = yaml.load(transformed2, Loader=yaml.BaseLoader)
    assert a == b2
    # Pretty-print the result

# Generated at 2022-06-22 14:08:08.495095
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': '1', 'b': '2'}, default_flow_style=False) == '{a: 1, b: 2}\n...\n'
    assert to_yaml({'a': '1', 'b': '2'}) == '{a: 1, b: 2}\n'


# Generated at 2022-06-22 14:08:18.356959
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('aaa', 'a{2}') == 'aa'
    assert regex_search('aaa', 'a{2}', '\\2') == 'aa'
    assert regex_search('aaa', 'a{2}', '\\g<0>') == 'aa'
    assert regex_search('aaa', 'a{2}', '\\g<1>') == 'a'
    assert regex_search('1 2 3', '(\d) (\d)', '\\g<1>', '\\g<2>') == ['1', '2']



# Generated at 2022-06-22 14:08:31.825674
# Unit test for function mandatory
def test_mandatory():
    # test with None
    try:
        mandatory(None)
    except Exception as e:
        assert type(e) is AnsibleFilterError
    # test with string
    try:
        assert mandatory("variable") == "variable"
    except Exception as e:
        assert type(e) is not AnsibleFilterError
    # test with undefined
    from jinja2.runtime import Undefined
    from ansible.template import AnsibleUndefined
    try:
        mandatory(Undefined)
    except Exception as e:
        assert type(e) is AnsibleFilterError



# Generated at 2022-06-22 14:08:37.244173
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.module_utils.jinja2 import Environment
    env = Environment(undefined=StrictUndefined)
    env.filters.update(C.filters())
    env.filters['groupby'] = do_groupby
    results = env.from_string('{{ [{ "n": "a", "x": "1"}, { "n": "a", "x": "2"}, { "n": "b", "x": "3"}] | groupby("n") | list }}').render()
    result = ast.literal_eval(results)
    assert result == [('a', [('a', '1'), ('a', '2')]), ('b', [('b', '3')])]

# END Unit test for function do_groupby


# Generated at 2022-06-22 14:08:41.641372
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('match', '(match)') == 'match'
    assert regex_search('foo , bar', '^.*?((,)|(\s))(?P<matchstring>.*)$', '\\g<matchstring>') == ['bar']
# End unit test for function regex_search


# Generated at 2022-06-22 14:08:45.192624
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == u"{\n  a: 1,\n  b: 2\n}"



# Generated at 2022-06-22 14:08:47.618986
# Unit test for function strftime
def test_strftime():
    try:
        strftime('%a')
        assert True
    except Exception:
        assert False


# Generated at 2022-06-22 14:08:58.450622
# Unit test for function mandatory
def test_mandatory():
    def run_mandatory(myvars, var, expected_result=None, expected_exception=None, msg=None):
        class TestUndefined(AnsibleUndefined):
            def __init__(self, name=None):
                self._undefined_name = name

        from jinja2.environment import Environment
        from jinja2.runtime import StrictUndefined
        env = Environment()
        env.undefined = TestUndefined
        template = env.from_string("{{ %s | mandatory(msg=%s) }}" % (var, repr(msg)))
        try:
            result = template.render(myvars)
        except Exception as e:
            result = e

# Generated at 2022-06-22 14:09:00.066294
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) is None



# Generated at 2022-06-22 14:09:08.263106
# Unit test for function randomize_list
def test_randomize_list():
    """Unit test for function randomize_list."""
    actual = randomize_list([0, 1, 2])
    # We can't assert that actual is exactly '[2, 1, 0]' or '[2, 0, 1]'
    # because it is random. However, it should be a different order. This
    # is a bit brittle, but it would likely be brittle to assert that
    # randomize_list never returns [0, 1, 2] in any case.
    assert actual != [0, 1, 2]



# Generated at 2022-06-22 14:09:11.094837
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    result = to_nice_yaml([1,"test"],default_flow_style=False)
    assert " - 1" in result
    assert " - test" in result


# Generated at 2022-06-22 14:09:24.224591
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='ansible', pattern='ansible') == 'ansible'
    assert regex_replace(value='Ansible', pattern='ansible', ignorecase=True) == 'Ansible'
    assert regex_replace(value='ansible', pattern='ansible', replacement='simple') == 'simple'
    assert regex_replace(value='ansible', pattern='n.s.', replacement='mple') == 'ample'
    assert regex_replace(value='AnsiBel', pattern='^a', replacement='mple', ignorecase=True) == 'mpleBel'
    assert regex_replace(value='ansiBel', pattern='b$', replacement='mple') == 'ansiBel'

# Generated at 2022-06-22 14:09:36.659119
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Jinja2EnvironmentPlugin

    # The issue occurs in the namedtuple repr, so capture it
    from collections import namedtuple
    old_namedtuple_repr = namedtuple('old_namedtuple_repr', []).__repr__
    check_namedtuple_repr = namedtuple('check_namedtuple_repr', []).__repr__
    # Put a replacment __repr__ in place to test the fix
    namedtuple('check_namedtuple_repr', []).__repr__ = lambda self: "<This is not parsable by safe_eval>"

    dummy_env = Environment()

# Generated at 2022-06-22 14:09:38.695870
# Unit test for function extract
def test_extract():
    env = Environment()
    assert extract(env, 'a', dict(a=1)) == 1
    assert extract(env, 'a', dict(a=dict(b=2)), 'b') == 2
    assert extract(env, 'a', dict(a=dict(b=dict(c=3))), 'b', 'c') == 3



# Generated at 2022-06-22 14:09:46.282619
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)
    else:
        assert False, "mandatory() did not raise AnsibleFilterError"

    try:
        mandatory(Undefined(), msg="bar %s")
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)
    else:
        assert False, "mandatory() did not raise AnsibleFilterError"



# Generated at 2022-06-22 14:09:51.384467
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("this is my dog", r'my (\w+)') == 'dog'
    assert regex_search("this is my dog", r'.+ (\w+)', '\\1') == ['dog']
    assert regex_search("this is my dog", r'my (\w+)', '\\g<1>') == ['dog']
    assert regex_search("this is my dog", r'.+ (\w+)', '\\1') == ['dog']


# Generated at 2022-06-22 14:10:00.577545
# Unit test for function rand
def test_rand():
    r = Random(1)
    # range
    assert rand(object(), 9) == r.randrange(9)
    assert rand(object(), 9, 1) == r.randrange(1,9)

    # sequence
    assert rand(object(), [1,2,3]) == r.choice([1,2,3])

    # exception
    try:
        rand(object(), 9, start=1, step=1)
        assert False
    except AnsibleFilterError:
        pass

    try:
        rand(object(), 9, step=1)
        assert False
    except AnsibleFilterError:
        pass

    try:
        rand(object(), 9, start=1)
        assert False
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 14:10:11.243218
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'ansible', u'ansible', u'redhat', ignorecase=True) == u'redhat'
    assert regex_replace(u'ansible', u'ansible', u'redhat', ignorecase=False) == u'redhat'
    assert regex_replace(u'ansible', u'ansible', u'redhat', ignorecase=False) == u'redhat'
    assert regex_replace(u'ansible', u'^ans.*e$', u'redhat', ignorecase=False) == u'redhat'
    assert regex_replace(u'ansible', u'^ans.*e$', u'redhat', ignorecase=False) == u'redhat'

# Generated at 2022-06-22 14:10:23.553891
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcabcabcabc', 'abc', ignorecase=True) == 'abc'
    assert regex_search('abcabcabcabc', '^abc$', ignorecase=True) is None
    assert regex_search('abcabcabcabc', '^abc', ignorecase=True) == 'abc'
    assert regex_search('abcabcabcabc', 'abc$', ignorecase=True) == 'abc'
    assert regex_search('abcabcabcabc', 'a(.+)c$', ignorecase=True) == 'abcabcabc'
    assert regex_search('abcabcabcabc', 'a(.+)c$', ignorecase=True, multiline=True) == 'abcabcabc'

# Generated at 2022-06-22 14:10:35.603001
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    # Test for all valid and invalid types.
    # Valid types should not raise an error
    valid_types = [
        [],
        [''],
        {},
        True,
        False,
        0,
        1,
        '',
        'a',
        (),
        ('a',),
        set(),
        set([1]),
        None,
        Undefined,
    ]
    for i in valid_types:
        assert mandatory(i) == i

    # Check if Undefined with name raises the right error message
    # Check if Undefined without name raises the right error message
    for i in [Undefined(name='foo'), Undefined()]:
        try:
            mandatory(i)
        except AnsibleFilterError as e:
            assert 'Mandatory variable'

# Generated at 2022-06-22 14:10:45.409604
# Unit test for function extract
def test_extract():
    environ = get_filters().get('environment')
    assert extract(environ, 'a', {'a': {'b': {'c': 'd'}}}) == {'b': {'c': 'd'}}
    assert extract(environ, 'a', {'a': {'b': {'c': 'd'}}}, 'b') == {'c': 'd'}
    assert extract(environ, 'a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'



# Generated at 2022-06-22 14:10:45.834000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-22 14:11:00.198886
# Unit test for function do_groupby
def test_do_groupby():
    # verify that the following will be parsed and can be evaluated
    # by ansible.template.safe_eval.safe_eval
    s = '([], [])'
    safe_eval(s)
    assert to_native(s) == safe_eval(s)
test_do_groupby()



# Generated at 2022-06-22 14:11:06.287958
# Unit test for function randomize_list
def test_randomize_list():
    # test with lists
    mylist = randomize_list(["q", "w"], seed=42)
    assert(mylist == ["w", "q"])
    # test with tuples
    mylist = randomize_list(("x", "y"), seed=42)
    assert(mylist == ["y", "x"])
    # test with random seed which should give a different order
    mylist = randomize_list(("x", "y"))
    assert(mylist != ["y", "x"])



# Generated at 2022-06-22 14:11:18.702573
# Unit test for function do_groupby
def test_do_groupby():
    """
    Unit test for function do_groupby.
    """
    env = Jinja2Environment()
    env.filters['groupby'] = do_groupby


# Generated at 2022-06-22 14:11:22.666116
# Unit test for function to_yaml