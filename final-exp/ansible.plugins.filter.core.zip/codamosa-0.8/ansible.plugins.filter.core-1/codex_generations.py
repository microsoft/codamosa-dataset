

# Generated at 2022-06-22 14:01:53.001194
# Unit test for function mandatory
def test_mandatory():
    assert 0 == mandatory(0, msg='0 == 0')
    assert isinstance(mandatory('', msg='empty string'), string_types)
    assert isinstance(mandatory(b'', msg='empty bytes'), string_types)
    assert isinstance(mandatory(u'', msg='empty unicode'), string_types)
    assert isinstance(mandatory(None, msg='None'), type(None))
    assert isinstance(mandatory([], msg='[]'), list)
    assert isinstance(mandatory({}, msg='{}'), dict)

    # ensure that a variable which is not defined raises an error
    try:
        mandatory('{{a variable which does not exist}}')
        assert False, "should have thrown an error"
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:01:55.176602
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) is None
    assert mandatory([]) == []
    assert mandatory('') == ''
    assert mandatory(0) == 0

# Generated at 2022-06-22 14:01:59.104029
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == fileglob('/bin/ls')
    assert fileglob('/notexists') == []
    assert fileglob('') == []



# Generated at 2022-06-22 14:02:06.105205
# Unit test for function mandatory
def test_mandatory():
    x = 1
    assert x == 1

    try:
        y
        assert False
    except NameError:
        assert True

    try:
        mandatory(y)
        assert False
    except AnsibleFilterError:
        assert True

    try:
        mandatory(y, msg="This is my message")
        assert False
    except AnsibleFilterError as e:
        assert "This is my message" in to_native(e)

    try:
        mandatory(y, msg="This is my message")
        assert False
    except AnsibleFilterError as e:
        assert "This is my message" in to_native(e)

    try:
        mandatory(y, msg=unicode('\xc3\xa9'))
        assert False
    except AnsibleFilterError as e:
        assert isinstance(e, unicode)

# Generated at 2022-06-22 14:02:16.698487
# Unit test for function mandatory
def test_mandatory():
    from jinja2 import Undefined

    assert mandatory('0') == '0'
    assert mandatory(0) == 0
    assert mandatory([]) == []

    # with complex data structure
    data = {'k1': {'k2': {'k3': 'v3'}}}
    assert mandatory(data) == data
    assert mandatory(data.get('k1')) == data.get('k1')
    assert mandatory(data.get('k2')) is None
    assert mandatory(data.get('k2'), 'custom error message') is None
    # function returns the value if it is not empty or None
    assert mandatory(data.get('k2'), 'custom error message') == data.get('k2')

    # Raises exception if variable not defined

# Generated at 2022-06-22 14:02:21.730683
# Unit test for function quote
def test_quote():
    assert quote("foo") == 'foo'
    assert quote("hello world") == 'hello\\ world'
    assert quote("hello \"world\"") == 'hello\\ \\"world\\"'



# Generated at 2022-06-22 14:02:32.170630
# Unit test for function quote
def test_quote():
    assert quote(u'spam') == u"'spam'"
    assert quote(u'spam ham') == u"'spam ham'"
    assert quote(u"spam 'ham' eggs") == u"'spam '\"'\"'ham'\"'\"' eggs'"
    assert quote(u'spam \"ham\" eggs') == u"'spam '\"'\"'ham'\"'\"' eggs'"
    assert quote(u"spam ") == u"'spam '"
    assert quote(42) == u'42'
    assert quote(42, True) == u'42'
    assert quote(u"spam", False) == u'spam'
    assert quote(42, False) == u'42'
    assert quote(u"spam", safe=False) == u'spam'

# Generated at 2022-06-22 14:02:34.905780
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    results = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups') == results



# Generated at 2022-06-22 14:02:45.453059
# Unit test for function quote
def test_quote():
    assert quote(u'') == u"''"
    assert quote(u'hello') == u'\'hello\''
    assert quote(u'hello world') == u"'hello world'"
    assert quote(u'hello\'world') == u"'hello'\\''world'"
    assert quote(u'hello "world"') == u'"hello \\"world\\""'
    assert quote(u'hello "world') == u'"hello \\"world"'
    assert quote(u'hello world"') == u'"hello world\\""'
    assert quote(u'hello world\\') == u'"hello world\\\\"'
    assert quote(u'hello; world') == u"'hello; world'"
    assert quote(u'hello&&world') == u"'hello&&world'"
    assert quote(u'hello|world') == u"'hello|world'"

# Generated at 2022-06-22 14:02:50.308506
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subele = 'groups'
    result = subelements(obj, subele)
    assert result[0][1] == 'wheel'



# Generated at 2022-06-22 14:03:03.250327
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y %z %Z %%") == "2017 +0000 EDT %"
    assert strftime("%y", second=0) == "00"
    # Check if the function raises error for incorrect arguments
    try:
        strftime("%Y", second='not-a-number')
    except AnsibleFilterError:
        pass
    else:
        assert False, "Failed to raise error for incorrect arguments"



# Generated at 2022-06-22 14:03:11.567013
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    from ansible.template.safe_eval import ansible_safe_eval

    env = jinja2.Environment()
    env.filters['groupby'] = do_groupby

    # Verify that standard jinja do_groupby works
    result = env.from_string("{{ [ {'name': 'a'}, {'name': 'a'}, {'name': 'b'} ] | groupby('name') }}").render()
    expected_result = "[('a', [{'name': 'a'}, {'name': 'a'}]), ('b', [{'name': 'b'}])]"
    assert result == expected_result

    # Evaluate and verify output can be used in a safe_eval call

# Generated at 2022-06-22 14:03:19.081060
# Unit test for function mandatory
def test_mandatory():
    from ansible.plugins.filter import core

    ret = core.mandatory(dict(a=1))
    assert ret == dict(a=1)
    ret = core.mandatory(True)
    assert ret
    try:
        ret = core.mandatory(AnsibleUndefined)
        assert False
    except:
        pass
    try:
        ret = core.mandatory(AnsibleUndefined, 'Failed')
        assert False
    except:
        pass



# Generated at 2022-06-22 14:03:27.846011
# Unit test for function regex_escape

# Generated at 2022-06-22 14:03:32.874822
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    res = subelements(obj, 'groups')
    assert res[0][1] == 'wheel', 'unexpected value for subelements'


# Generated at 2022-06-22 14:03:37.400928
# Unit test for function fileglob
def test_fileglob():
    pathname = "testfileglob.txt"
    file = open(pathname, "w+")
    file.close()

    expected = [pathname]
    actual = fileglob(pathname)

    assert actual == expected
    os.remove(pathname)



# Generated at 2022-06-22 14:03:43.383276
# Unit test for function mandatory
def test_mandatory():
    # Test with a good value
    assert 42 == mandatory(42)
    # Test with an undefined value
    try:
        mandatory(AnsibleUndefined())
    except AnsibleFilterError:
        return True
    else:
        raise Exception("Mandatory didn't raise error with undefined value")



# Generated at 2022-06-22 14:03:46.422079
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo/bar') == 'foo\\/bar'
    assert regex_escape('foo/bar', re_type='posix_basic') == 'foo\\/bar'



# Generated at 2022-06-22 14:03:54.806025
# Unit test for function get_hash
def test_get_hash():
    data = 'foo bar'
    h = get_hash(data, hashtype='md5')
    assert h == '3858f62230ac3c915f300c664312c63f'

    h = get_hash(data, hashtype='sha1')
    assert h == '8843d7f92416211de9ebb963ff4ce28125932878'

    h = get_hash(data, hashtype='sha256')
    assert h == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'

    h = get_hash(data, hashtype='sha384')

# Generated at 2022-06-22 14:03:59.925667
# Unit test for function flatten
def test_flatten():
    assert list == flatten([[1, 2, 3], 4, 5])
    assert list == flatten([[1, 2, 3], 4, 5], levels=1)
    assert [1, 2, 3, 4, 5] == flatten([[1, 2, 3], 4, 5], levels=2)
    assert [1, 2, 3, 4, 5] == flatten([[1, 2, 3], 4, 5], levels=3)

    assert [] == flatten([])
    assert [1] == flatten([1])
    assert list == flatten([[1, 2, 3], 4, 5], skip_nulls=False)
    assert [None] == flatten([None])
    assert [None] == flatten([[1, 2, 3], None, 5], skip_nulls=False)

# Generated at 2022-06-22 14:04:16.521903
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(value='foobar', regex='foo') == 'foo'
    assert regex_search(value='foobar', regex='^foo$') is None
    assert regex_search(value='foobar', regex='bar') == 'bar'

    assert regex_search(value='foobar', regex='foo', ignorecase=True) == 'foo'

    # Backref matching

# Generated at 2022-06-22 14:04:24.956319
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("abcdef", "abc", "\\0") == "abc"
    assert regex_search("abcdef", "abc", "\\g<0>") == "abc"
    assert regex_search("abcdef", "abc", "\\1") == None
    assert regex_search("abcdef", "abc", "\\g<1>") == None
    assert regex_search("abcdef", "(abc)", "\\1") == "abc"
    assert regex_search("abcdef", "(abc)", "\\g<1>") == "abc"
    assert regex_search("abcdef", "abc(def)", "\\g<1>") == "def"

# Generated at 2022-06-22 14:04:26.362337
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('0') is '0'


# Generated at 2022-06-22 14:04:38.810967
# Unit test for function comment

# Generated at 2022-06-22 14:04:51.083097
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.runtime import StrictUndefined
    from ansible.vars import sort_facts
    from ansible.compat.tests import unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestGroupby(unittest.TestCase):
        def test_group_by(self):
            # Some of our variables will be generated by jinja.  This test bascially is
            # verifying that we can convert the output to and from jinja

            # Gather the data to be used to create a jinja environment
            facts = {}

# Generated at 2022-06-22 14:05:02.643768
# Unit test for function get_hash
def test_get_hash():
    ''' This tests get_hash, using SHA256. '''
    # Test 1:
    # Initial setup.
    data = 'abcdefghijklmnopqrstuvwxyz'
    hashtype = 'sha256'
    # Expected result.
    expected = 'c3fcd3d76192e4007dfb496cca67e13b'
    # Result.
    result = get_hash(data, hashtype)
    # Test.
    assert result == expected
    # Success.
    print('Test 1 was successful.')
    # Test 2:
    # Initial setup.
    data = 'abcdefghijklmnopqrstuvwxyz12'
    hashtype = 'sha256'
    # Expected result.

# Generated at 2022-06-22 14:05:12.008929
# Unit test for function regex_search
def test_regex_search():
    ''' Unit tests for regex_search

        TODO: add unit tests for arguments:
              ignorecase=ignorecase
              multiline=multiline
    '''
    # no arguments
    noargs = regex_search('hello world')
    assert noargs is None

    # 2 arguments
    twoargs = regex_search('hello world', 'world')
    assert twoargs == 'world'

    # 3 arguments
    threeargs = regex_search('hello world', 'hello (world)', groups=1)
    assert threeargs == 'world'

    # 4 arguments
    fourargs = regex_search('hello world', 'hello (\\w+) (\\w+)', '\\g<1>', '\\g<2>')
    assert fourargs == ['hello', 'world']


#   regex_match
#   regex_match:

# Generated at 2022-06-22 14:05:13.829462
# Unit test for function mandatory
def test_mandatory():
    raise AnsibleError('test_mandatory is deprecated, use jinja2.tests.test_mandatory instead.')



# Generated at 2022-06-22 14:05:18.419040
# Unit test for function mandatory
def test_mandatory():
    # This will pass
    assert mandatory(42) == 42
    assert mandatory(0) == 0
    assert mandatory(None) is None
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory('foo') == 'foo'
    assert mandatory(u'bar') == u'bar'
    assert mandatory(b'baz') == b'baz'

    # This will fail
    try:
        mandatory('undefined_variable')
    except AnsibleFilterError:
        pass
    else:
        assert False, 'AnsibleFilterError should have been raised'



# Generated at 2022-06-22 14:05:23.983529
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 5, 'b': 6}) == "a: 5\nb: 6\n"
    assert to_yaml({'a': 5, 'b': 6}, default_flow_style=False) == "a: 5\nb: 6\n"
    assert to_yaml({'a': 5, 'b': 6}, default_flow_style=True) == "{a: 5, b: 6}"



# Generated at 2022-06-22 14:05:35.256786
# Unit test for function get_hash
def test_get_hash():
    if not get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3':
        raise AssertionError
    if not get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6':
        raise AssertionError


# Generated at 2022-06-22 14:05:44.585848
# Unit test for function get_hash
def test_get_hash():
    assert(get_hash('') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709')
    assert(get_hash('', hashtype='md5') == 'd41d8cd98f00b204e9800998ecf8427e')
    assert(get_hash('', hashtype='sha256') == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')



# Generated at 2022-06-22 14:05:53.338948
# Unit test for function regex_search
def test_regex_search():

    # match and return a full match
    assert regex_search('aabbcc', '(aabbcc)') == 'aabbcc'

    # match with specific flags
    assert regex_search('aaBBcc', '(aabbCC)', ignorecase=True) == 'aaBBcc'

    # match and return a single back reference
    assert regex_search('aaBBcc', '(bb)', '\\1') == 'bb'

    # match and return multiple back references
    assert regex_search('aaBBcc', '(aa)(bb)(CC)', '\\2', '\\3') == ['bb', 'CC']

    # match and return multiple back references
    assert regex_search('aaBBcc', '(aa)(bb)(CC)', '\\g<2>', '\\g<3>') == ['bb', 'CC']

    # test non-match


# Generated at 2022-06-22 14:06:03.198920
# Unit test for function regex_search
def test_regex_search():
    # Simple match
    assert regex_search('foo bar', 'bar') == 'bar'
    # Group match
    assert regex_search('foo bar', 'b(.)r') == 'ar'
    assert regex_search('foo bar', ['b(.)r', '\\1'], ignorecase=True) == ['ar', 'a']
    assert regex_search('foo bar', ['b(.)r', '\\g<1>'], ignorecase=True) == ['ar', 'a']
    # Missing group
    assert regex_search('foo bar', ['b(.)r', '\\2'], ignorecase=True) is None
    # Zero group
    assert regex_search('foo bar', ['b(.)r', '\\0'], ignorecase=True) == ['bar', 'bar']
    # None match

# Generated at 2022-06-22 14:06:10.735725
# Unit test for function regex_search
def test_regex_search():
    # with group
    value = 'this is a string'
    regex = r'(\S+)\s(\S+)\s(\S+)\s(\S+)'
    print(regex_search(value, regex, '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>'))
    # without group
    value = 'this is a string'
    regex = r'(\S+)\s(\S+)\s(\S+)\s(\S+)'
    print(regex_search(value, regex))



# Generated at 2022-06-22 14:06:22.612054
# Unit test for function regex_replace
def test_regex_replace():

    # Test simple match and replace
    result = regex_replace(value='abc123abc', pattern='123', replacement='456')
    assert result == 'abc456abc'

    # Test regex special character in pattern
    result = regex_replace(value='abc123abc', pattern='\d+', replacement='456')
    assert result == 'abc456abc'

    # Test regex special character in replacement
    result = regex_replace(value='abc123abc', pattern='\d+', replacement='\d-\d')
    assert result == 'abc\d-\dabc'

    # Test ignorecase
    result = regex_replace(value='abc123abc', pattern='ABC', replacement='456', ignorecase=True)
    assert result == '456123abc'

    # Test multiline

# Generated at 2022-06-22 14:06:27.656740
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    fail = True
    try:
        mandatory(Undefined("test!"))
    except AnsibleFilterError as e:
        fail = False
        assert "Mandatory variable 'test!' not defined." == e.message
    assert fail is False



# Generated at 2022-06-22 14:06:31.730659
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    subelements(obj, 'groups')


subelements.envattr = True  # ensure that the environment attribute is carried through (due to the decorator)



# Generated at 2022-06-22 14:06:43.494569
# Unit test for function do_groupby
def test_do_groupby():
    groupby_data = [
        {'key': 'a', 'value': 1},
        {'key': 'a', 'value': 2},
        {'key': 'b', 'value': 3},
    ]

    # Make a jinja2 environment, and store the original curry function
    jinja_env = jinja2.Environment()
    origin_groupby = jinja_env.filters['groupby']

    # Replace the curry function with the do_groupby function
    jinja_env.filters['groupby'] = do_groupby
    result = jinja_env.from_string('''{{ data|groupby('key')|list }}''').render(data=groupby_data)

# Generated at 2022-06-22 14:06:52.839995
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory('')
    except AnsibleFilterError as e:
        raise AssertionError('Unexpected exception for empty value: %s' % to_native(e))
    try:
        mandatory(None)
    except AnsibleFilterError as e:
        raise AssertionError('Unexpected exception for None: %s' % to_native(e))

    from jinja2.runtime import Undefined
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        if 'foo' not in to_native(e):
            raise AssertionError('Undefined name is not in exception message: %s' % to_native(e))
    else:
        raise AssertionError('No exception raised for Undefined value')


# Generated at 2022-06-22 14:07:09.586487
# Unit test for function regex_escape
def test_regex_escape():
    text_basic = r'https://en.wikibooks.org/wiki/Regular_Expressions/POSIX_Basic_Regular_Expressions'
    text_ext = r'https://remram44.github.io/regex-cheatsheet/regex.html#programs'
    assert regex_escape(text_basic, 'python') == r'https\:\/\/en\.wikibooks\.org\/wiki\/Regular\_Expressions\/POSIX\_Basic\_Regular\_Expressions'
    assert regex_escape(text_basic, 'posix_basic') == r'https\:\/\/en\.wikibooks\.org\/wiki\/Regular\_Expressions\/POSIX\_Basic\_Regular\_Expressions'

# Generated at 2022-06-22 14:07:18.715366
# Unit test for function combine
def test_combine():

    assert combine({'Y': 1, 'Z': 2}, {'X': 1, 'Y': 2}, {'X': 10}, recursive=False) == {'Y': 2, 'Z': 2, 'X': 10}
    assert combine({'X': 1, 'Y': 2}, {'Y': 1, 'Z': 2}, {'X': 10}) == {'X': 10, 'Y': 1, 'Z': 2}
    assert combine({'X': {'Y': {'Z': 1}}} , {'X': 1}, recursive=True) == {'X': 1}
    assert combine({'X': {'Y': {'Z': 1}}} , {'X': {'Y': 1}}, recursive=True) == {'X': {'Y': 1}}

# Generated at 2022-06-22 14:07:19.430417
# Unit test for function to_yaml
def test_to_yaml():
    assert not to_yaml(None)


# Generated at 2022-06-22 14:07:23.766219
# Unit test for function comment
def test_comment():
    assert comment('Comment me') == "# Comment me"
    assert comment('Comment me', style='erlang') == "% Comment me"
    assert comment('Comment me', style='c') == "// Comment me"
    assert comment('Comment me', style='cblock') == "/* * Comment me */"
    assert comment('Comment me', style='xml') == "<!-- - Comment me-->"
    assert comment('Comment me', decoration='### ') == "### Comment me"
    assert comment('Comment me', decoration='### ', prefix='###', prefix_count=2) == "###\n### Comment me"
    assert comment('Comment me', newline="\r\n") == "# Comment me"
    assert comment('Comment me', beginning='####', end='####') == "####\n# Comment me\n####"

# Generated at 2022-06-22 14:07:28.809410
# Unit test for function get_hash
def test_get_hash():
    '''
    Test word "hash"
    :return:
    '''
    value = 'hash'
    assert get_hash(value) == '6b5473c0f00950b905cd08d0e5f2ec32b064f8e9'



# Generated at 2022-06-22 14:07:38.798890
# Unit test for function get_hash

# Generated at 2022-06-22 14:07:47.206530
# Unit test for function do_groupby
def test_do_groupby():
    values = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]

    # create a fake environment to store our values in
    from jinja2 import Environment
    env = Environment()
    env.globals['do_groupby'] = do_groupby

    # run the do_groupby function
    value = env.from_string('{{ values|do_groupby("a") }}').render(values=values)
    # eval the result string to turn the string back into a data structure
    value = safe_eval(value)

    # test the results
    for item in value:
        assert isinstance(item, tuple)
        key, values = item
        for elem in values:
            assert isinstance(elem, dict)



# Generated at 2022-06-22 14:07:53.472316
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    # Use fixture from ansible/test/unit/plugin/filter/test_json.py
    fixture = dict(
        dictP=dict(
            dictQ=["a list with a dict", dict(foo="bar")],
            dictR=dict(
                dictZ=dict(
                    stringP="stringQ"
                ),
                stringX="stringY"
            )
        )
    )
    assert to_nice_yaml(fixture, width=1000) == to_text('''
dictp:
    dictq:
    - a list with a dict
    - foo: bar
    dictr:
        dictz:
            stringp: stringQ
        stringx: stringY
''').lstrip()



# Generated at 2022-06-22 14:07:57.868026
# Unit test for function mandatory
def test_mandatory():
    fed_string = 'FED'
    try:
        mandatory(fed_string)
    except AnsibleFilterError as err:
        raise AssertionError("Received unexpected unexpected error: %s" % err)


# Generated at 2022-06-22 14:08:06.127879
# Unit test for function regex_replace
def test_regex_replace():
    ''' regex_replace should perform a regex sub '''
    assert regex_replace('', pattern='\w', replacement='0') == ''
    assert regex_replace('a', pattern='\w', replacement='0') == '0'
    assert regex_replace('foo', pattern='\w', replacement='0') == '000'
    assert regex_replace('foo', pattern='\w', replacement='0', ignorecase=True) == '000'
    assert regex_replace('foo', pattern='\w', replacement='0', multiline=True) == '000'
    assert regex_replace('foo', pattern='\w', replacement='0', ignorecase=True, multiline=True) == '000'
    assert regex_replace('foo', pattern='^\w+', replacement='0') == '0'

# Generated at 2022-06-22 14:08:14.387474
# Unit test for function flatten
def test_flatten():
    assert flatten([0, 1, 2, [3, 4, 5]]) == [0, 1, 2, 3, 4, 5]
    assert flatten([0, 1, 2, [3, 4, 5]], skip_nulls=True) == [0, 1, 2, 3, 4, 5]
    assert flatten([0, 1, 2, [3, 4, 5]], skip_nulls=False) == [0, 1, 2, 3, 4, 5]
    assert flatten([0, 1, 2, [3, 4, 5, None]]) == [0, 1, 2, 3, 4, 5]
    assert flatten([0, 1, 2, [3, 4, 5, [6, 7]]], levels=1) == [0, 1, 2, 3, 4, 5, [6, 7]]

# Generated at 2022-06-22 14:08:20.430124
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = {
      'title': 'test_to_nice_yaml',
      'success': True,
      'errors': [],
      'skipped': [],
      'failures': []
    }
    b = to_yaml(a)
    c = to_nice_yaml(a)
    assert c != b # c must be more human readable than b


# Generated at 2022-06-22 14:08:28.136725
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'hello') == 'hello'
    assert regex_search('hello', '^h') == 'h'
    assert regex_search('hello world', 'hello (.+)') == ['world']
    assert regex_search('hello world', 'hello (.+)', ignorecase=True) == ['world']
    assert regex_search('hello world', 'hello (.+)', '\\g<1>') == ['world']
    assert regex_search('hello world', 'hello (.+)', '\\g<1>', ignorecase=True) == ['world']
    assert regex_search('hello world', '(.+) (.+)', '\\g<1>') == ['hello']
    assert regex_search('hello world', '(.+) (.+)', '\\g<2>') == ['world']

# Generated at 2022-06-22 14:08:30.119951
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'k': 'v'}) == u'k: v\n'



# Generated at 2022-06-22 14:08:41.155082
# Unit test for function do_groupby
def test_do_groupby():
    ev = Environment()
    res = ev.from_string("""{{ [
            {'parent': 5, 'child': 1},
            {'parent': 5, 'child': 2},
            {'parent': 6, 'child': 3},
            {'parent': 6, 'child': 4},
            {'parent': 7, 'child': 5},
            {'parent': 7, 'child': 6},
        ] | do_groupby('parent') | list }}""").render()

# Generated at 2022-06-22 14:08:51.592986
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'a') == r'a'
    assert regex_escape(r'\\') == r'\\'
    assert regex_escape(r'a[b') == r'a\[b'
    assert regex_escape(r'a.b') == r'a\.b'
    assert regex_escape(r'a^b') == r'a\^b'
    assert regex_escape(r'a$b') == r'a\$b'
    assert regex_escape(r'a*b') == r'a\*b'



# Generated at 2022-06-22 14:08:59.982663
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("1.2.3-4", r'(\d+).(\d+).(\d+)-(\d+)', '\\4', '\\g<2>', '\\2', '\\g<1>', '\\3') == ['4', '2', '2', '1', '3']
    assert regex_search("hello world", r'(\w+) (\w+)') == ['hello world']
    assert regex_search("hello world", r'(\w+) (\w+)', '\\2') == ['world']
    assert regex_search("hello world", r'(\w+) (\w+)', '\\2', '\\1') == ['world', 'hello']

# Generated at 2022-06-22 14:09:02.856086
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'foo': 'bar'}, default_flow_style=False) == 'foo: bar\n'


# Generated at 2022-06-22 14:09:15.505505
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('oh what a wonderful', '(w\w+d)') == 'wonderful'
    assert regex_search('oh what a wonderful', '(w\w+d)', ignorecase=True) == 'wonderful'
    assert regex_search('oh what a wonderful', '(w\w+d)', multiline=True) == 'wonderful'
    assert regex_search('oh what a wonderful', '(w\w+d)', multiline=False) == 'wonderful'
    assert regex_search('oh what a wonderful', '(w\w+d)', '\\g<1>') == 'wonderful'
    assert regex_search('oh what a wonderful', '(w\w+d)', '\\g<1>', ignorecase=True) == 'wonderful'

# Generated at 2022-06-22 14:09:21.342710
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("abcd", "a", "\\g<0>") == "a"
    assert regex_search("abcd", "(a)", "\\g<1>") == "a"
    assert regex_search("abcdabcabc", "(a)", "\\g<1>", "\\1") == ["a", "a", "a"]



# Generated at 2022-06-22 14:09:31.429383
# Unit test for function do_groupby
def test_do_groupby():
    environment = jinja2.Environment()
    value = ['a', 'b', 'a', 'a', 'c', 'c']
    attribute = value
    result = do_groupby(environment, value, attribute)
    expect = [('a', ['a', 'a', 'a']), ('b', ['b']), ('c', ['c', 'c'])]
    assert result == expect, 'got: %s expect: %s' % (result, expect)



# Generated at 2022-06-22 14:09:43.680423
# Unit test for function comment

# Generated at 2022-06-22 14:09:49.457461
# Unit test for function combine
def test_combine():
    d1 = {'a': 'b', 'c': 'd'}
    d2 = {'e': 'f'}
    d3 = {'g': 'h', 'b': 'c'}
    d4 = {'a': 'h'}
    assert combine(d1, d2, d3, d4) == {'a': 'h', 'e': 'f', 'g': 'h', 'b': 'c'}

# Generated at 2022-06-22 14:09:51.920875
# Unit test for function strftime
def test_strftime():
    assert strftime("%d/%m/%y %H:%M", second=1234) == "31/12/69 19:28"



# Generated at 2022-06-22 14:10:00.919270
# Unit test for function regex_search
def test_regex_search():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert regex_search(u'something', u'ing', u'\\g<0>') == u'ing'
    assert regex_search(AnsibleUnsafeText(u'something'), u'ing', u'\\g<0>') == u'ing'

# Generated at 2022-06-22 14:10:05.437988
# Unit test for function to_yaml
def test_to_yaml():
    data={'key1': 'val1', 'key2': ['val2', 'val3']}
    expected='key1: val1\nkey2:\n- val2\n- val3\n'
    yaml_data=to_yaml(data)
    assert(yaml_data==expected)
# Unit test end


# Generated at 2022-06-22 14:10:13.909621
# Unit test for function regex_search
def test_regex_search():
    ''' Unit tests for function regex_search '''
    assert regex_search("foo", r"foo", r"\g<0>") == "foo"
    assert regex_search("foobar", r"foo(bar)?") == ['bar', '']
    assert regex_search("foobar", r"foo(bar)?", r"\g<0>") == "foobar"
    assert regex_search("foo", r"[a-z]+", r"\0") == "foo"
    assert regex_search("https://example.com/index.html", r"https?://(?P<domain>[^/]+)/(?P<path>.+)", r"\g<domain>", r"\g<path>") == ["example.com", "index.html"]

# Generated at 2022-06-22 14:10:25.014570
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', 't', '\\g<0>') is None
    assert regex_search('test', 'es', '\\g<0>') == 'es'
    assert regex_search('test', 'est', '\\2') is None
    assert regex_search('test', 'est', '\\1') == 't'
    assert regex_search('test', 'T', '\\g<0>', ignorecase=True) == 'T'
    assert regex_search('test', 'T', '\\g<0>') is None
    assert regex_search('tEsT', 't.*t', '\\g<0>', ignorecase=True) == 'tEsT'
    assert regex_search('1test2', '\\d(\\w+)', '\\g<1>') == 'est'



# Generated at 2022-06-22 14:10:36.488712
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hostname: test', 'hostname:(.*)', '\\g<1>') == ' test'
    assert regex_search('hostname: test', 'hostname:(.*)', '\\1') == ' test'
    assert regex_search('hostname: test', 'hostname:(?P<name>.*)', '\\g<name>') == ' test'
    assert regex_search('hostname: test', 'hostname:(?P<name>.*)', '\\g<1>') == ' test'
    assert regex_search('hostname: test', 'hostname:(.*)', '\\g<1>', '\\g<1>') == [' test', ' test']

# Generated at 2022-06-22 14:10:50.074028
# Unit test for function combine
def test_combine():
    # Examples from Ansible documentation
    assert dict() == list(map(combine, [{}]))
    assert dict(b=2) == list(map(combine, [{'a': 1}, {'b': 2}]))
    assert dict(c=3, d=4) == list(map(combine, [{'a': 1}, {'b': 2}, {'c': 3, 'd': 4}]))
    assert dict(b=2, c=3, d=4) == list(map(combine, [{'a': 1}, {'b': 2}, {'c': 3, 'd': 4}]))

# Generated at 2022-06-22 14:11:08.950302
# Unit test for function get_hash
def test_get_hash():
    def test(data, typ, result):
        assert get_hash(data, typ) == result, "'%s' type should return '%s' but returned '%s'" % (typ, result, get_hash(data, typ))

    test("Hello world", 'md5', 'ed076287532e86365e841e92bfc50d8c')
    test("Hello world", 'sha1', '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed')
    test("Hello world", 'sha224', '4575bb4ec129df6380cedde6d71217fe0536f8ffc4e18bca530a7a1a')

# Generated at 2022-06-22 14:11:11.708869
# Unit test for function regex_search
def test_regex_search():
    string = "1234"
    regex = "^\d+"
    assert regex_search(string, regex) == "1234"



# Generated at 2022-06-22 14:11:22.722295
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', '_H(.*?)O_', '\g<1>') == 'ell'
    assert regex_search('hello', '_H(.*?)O_', '\1') == 'ell'
    assert regex_search('xabxabxabxabxabxabxabxab', '_H(.*?)O_', '\\1') == 'abxabxabxabxabxabxab'
    assert regex_search('xabxabxabxabxabxabxabxab', '_H(.*?)O_', '\\g<1>') == 'abxabxabxabxabxabxab'