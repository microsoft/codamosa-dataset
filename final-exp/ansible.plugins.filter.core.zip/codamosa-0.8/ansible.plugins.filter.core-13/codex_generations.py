

# Generated at 2022-06-22 14:02:02.148088
# Unit test for function mandatory
def test_mandatory():
    class UnitTestUndefined(dict):
        """ A class to mimic the Jinja2 undefined-type """
        _undefined_name = 'foobar'

    test_undefined = UnitTestUndefined()

    # test with message:
    try:
        mandatory(test_undefined, msg='foo')
    except AnsibleFilterError as e:
        assert str(e) == 'foo'
    else:
        assert False, 'AnsibleFilterError not raised'

    # test without message:
    try:
        mandatory(test_undefined)
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foobar' not defined."
    else:
        assert False, 'AnsibleFilterError not raised'

    # test with non-undefined variable:

# Generated at 2022-06-22 14:02:05.300725
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined



# Generated at 2022-06-22 14:02:16.548850
# Unit test for function randomize_list
def test_randomize_list():
    from ansible.compat import unittest
    import ansible.utils.unsafe_proxy

    class TestUnsafeProxy(unittest.TestCase):
        def test_string(self):
            mylist = ['one', 'two', 'three']
            self.assertNotEqual(mylist, randomize_list(mylist))
            mylist = ['one', 'two', 'three']
            r = Random(3)
            r.shuffle(mylist)
            self.assertEqual(mylist, randomize_list(mylist, seed=3))
        def test_integer(self):
            mylist = [1, 2, 3]
            self.assertNotEqual(mylist, randomize_list(mylist))
            mylist = [1, 2, 3]
            r = Random(3)
           

# Generated at 2022-06-22 14:02:29.206040
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(42)             == 42

    try:
        mandatory(Undefined(), "Failed")
        assert False, "Failed to raise exception"
    except AnsibleFilterError as e:
        assert "Failed" in e.message

    try:
        mandatory(Undefined())
        assert False, "Failed to raise exception"
    except AnsibleFilterError as e:
        assert "'undefined' " in e.message

    try:
        mandatory(Undefined(name='foo'))
        assert False, "Failed to raise exception"
    except AnsibleFilterError as e:
        assert "'foo' " in e.message



# Generated at 2022-06-22 14:02:38.367914
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("/dev/null") == ['/dev/null']
    assert fileglob("/blah/sdjkfhk_NON_EXISTENT_FILE_dsfjkh/null") == []
    assert fileglob("/dev/null*") == ['/dev/null']
    assert fileglob("/dev/urandom") == ['/dev/urandom']
    assert fileglob("/dev/*") == ['/dev/null', '/dev/urandom'] # There's more than this, but it's platform dependent


# Generated at 2022-06-22 14:02:47.032715
# Unit test for function fileglob
def test_fileglob():
    # Create a test directory
    os.mkdir('temp_dir')
    # Create a couple test files
    with open(os.path.join('temp_dir', 'file1'), 'wb') as f:
        f.write(b"Just some junk")
    with open(os.path.join('temp_dir', 'file2'), 'wb') as f:
        f.write(b"Just some junk")
    # Test the function
    result = fileglob(os.path.join('temp_dir', 'file*'))
    assert result == [os.path.join('temp_dir', 'file1'), os.path.join('temp_dir', 'file2')]
    # Clean up
    os.remove(os.path.join('temp_dir', 'file1'))

# Generated at 2022-06-22 14:02:59.837824
# Unit test for function combine
def test_combine():
    assert combine({'k1': 1}, {'k2': 2}) == {'k1': 1, 'k2': 2}, "combine dictionaries failed"
    assert combine({'k1': 1, 'k2': 2}) == {'k1': 1, 'k2': 2}, "combine same dictionaries failed"
    assert combine({'k1': 1, 'k2': 2, 'k3': {'k4': 4}}, {'k1': 3, 'k2': 4, 'k3': {'k5': 5}}) == {'k1': 3, 'k2': 4, 'k3': {'k5': 5}}, "combine dictionaries with merge failed"

# Generated at 2022-06-22 14:03:09.523300
# Unit test for function randomize_list
def test_randomize_list():
    # Test lists with integers or string
    list_int, list_str = [1, 2, 3, 4, 5], ['1', '2', '3', '4', '5']
    if not randomize_list(list_int) == randomize_list(list_int):
        raise AssertionError('randomize_list() doesn\'t randomly shuffle the list')
    else:
        if not randomize_list(list_str) == randomize_list(list_str):
            raise AssertionError('randomize_list() doesn\'t randomly shuffle the list')
        else:
            if randomize_list(list_int) == randomize_list(list_str):
                raise AssertionError('randomize_list() doesn\'t randomly shuffle the list')
    # First half of the list should be equal if the seed is the

# Generated at 2022-06-22 14:03:20.029976
# Unit test for function fileglob
def test_fileglob():
    pathname_list = ["test_fileglob.py", "test_fileglob.pyc"]
    for pathname in pathname_list:
        assert fileglob(pathname) == [pathname]

    pathname_list = ["test_fileglob.py", "test_fileglob.pyc", "Makefile"]
    for pathname in pathname_list:
        assert fileglob(pathname) == [pathname]

    assert fileglob("*.py") == ["test_fileglob.py"]
    assert fileglob("*.p*") == ["test_fileglob.py", "test_fileglob.pyc"]



# Generated at 2022-06-22 14:03:32.511781
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('', 'a') is None
    assert regex_search('a', '', ignorecase=True) is None
    assert regex_search('a', 'a') == 'a'
    assert regex_search('a', 'a', ignorecase=True) == 'a'
    assert regex_search('a', 'A') is None
    assert regex_search('a', 'A', ignorecase=True) == 'a'
    assert regex_search('a', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('a', '(a)', '\\g<1>') == ['a']
    assert regex_search('a', '(a)', '\\g<0>', '\\g<1>') == ['a', 'a']

# Generated at 2022-06-22 14:03:44.569225
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', 't.+?t') == 'test'
    assert regex_search('test', 't.+?t', ignorecase=True) == ['test']
    assert regex_search('test', 't.+?t', '\\g<0>') == 'test'
    assert regex_search('test', 't.+?t', '\\1') == ['es']



# Generated at 2022-06-22 14:03:55.433965
# Unit test for function extract
def test_extract():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-22 14:04:06.285660
# Unit test for function mandatory
def test_mandatory():
    a = 1
    b = None
    c = 'foo'
    try:
        result = mandatory(b,'test_mandatory')
    except AnsibleFilterError as e:
        result = e

    d = Undefined()
    try:
        result2 = mandatory(d)
    except AnsibleFilterError as e:
        result2 = e

    try:
        result3 = mandatory(b)
    except AnsibleFilterError as e:
        result3 = e

    assert result.args[0] == 'test_mandatory'
    assert result2.args[0] == 'Mandatory variable not defined.'
    assert result3.args[0] == 'Mandatory variable not defined.'
    assert mandatory(a) == 1
    assert mandatory(c) == 'foo'



# Generated at 2022-06-22 14:04:15.367471
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.compat.tests.mock import Mock, call, patch
    from jinja2 import Environment
    import json
    mock_environment = Mock(Environment)
    mock_environment.__getitem__.side_effect = lambda x, y: x[y]
    mock_environment.getitem.side_effect = lambda x, y: x[y]
    class Data(object):
        def __init__(self):
            self._ansible_no_log = False

    class Host(object):
        def __init__(self, name):
            self.hostname = name
            self.name = name


# Generated at 2022-06-22 14:04:27.089050
# Unit test for function regex_escape
def test_regex_escape():
    '''
    regex_escape:
      - ".": '\\\.'
      - "^/path": '\\^\\/path'
      - "^/[A-Z]+/[0-9]+$": '\\^\\/\\[A-Z\\]\\+\\/\\[0-9\\]\\+\\$'
      - "^/[A-Z]+/{PATTERN}$": '\\^\\/\\[A-Z\\]\\+\\/\\{PATTERN\\}\\$'
      - '*': '\\*'
      - '/path/here': '\\/path\\/here'
    '''
    assert regex_escape('.') == '\\.'
    assert regex_escape('/path/here') == '\\/path\\/here'

# Generated at 2022-06-22 14:04:29.499503
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == "---\n- 1\n- 2\n- 3\n"



# Generated at 2022-06-22 14:04:36.845336
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar

    # Test for groupby return value
    data = [
        {'test_attr': 'foo', 'test_item': 'bar'},
        {'test_attr': 'foo', 'test_item': 'baz'}
    ]
    template_data = {'data': data}
    template_ds = dict(template_data)
    templar = Templar(loader=None)

    # Test when jinja2>=2.9.0,<2.9.5
    class TestNamedTuple(namedtuple('TestNamedTuple', 'a')):
        """Test namedtuple for unit test."""
        def __repr__(self):
            return 'TestNamedTuple(foo=%r)' % self.a


# Generated at 2022-06-22 14:04:40.583589
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'abcdef\ghijkl') == r'abcdef\\ghijkl'
    assert regex_escape(r'abcdef\ghijkl', re_type='posix_basic') == r'abcdef\\\ghijkl'
    # FIXME: Add more unit tests for regex_escape()



# Generated at 2022-06-22 14:04:48.084569
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo[bar]') == 'foo\\[bar\\]'
    assert regex_escape('foo^bar') == 'foo\\^bar'
    assert regex_escape('foo$bar') == 'foo\\$bar'
    assert regex_escape('foo*bar') == 'foo\\*bar'
    assert regex_escape('foo?bar') == 'foo\\?bar'
    assert regex_escape('foo\\bar') == 'foo\\\\bar'
    assert regex_escape('foo\\(bar') == 'foo\\(bar'

    assert regex_escape('foo', re_type='posix_basic') == 'foo'

# Generated at 2022-06-22 14:04:50.087540
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 14:05:07.066116
# Unit test for function regex_search
def test_regex_search():
    expected = ['1', '2']
    for g in expected:
        assert ['1', '2'] == regex_search('a 1 b 2', r'\d', '\\g<1>', '\\g<2>', ignorecase=True)
    assert '1' == regex_search('a 1 b 2', r'\d', ignorecase=True)
    assert '2' == regex_search('a 1 b 2', r'\d', '\\1', ignorecase=True)
    assert ['2', '2'] == regex_search('a 1 b 2', r'\d', '\\1', '\\g<1>', ignorecase=True)



# Generated at 2022-06-22 14:05:16.090460
# Unit test for function mandatory
def test_mandatory():
    def test(a, exc=None):
        try:
            mandatory(a)
        except AnsibleFilterError as e:
            if exc is None:
                raise
            assert to_text(exc) in to_text(e)
        else:
            if exc is not None:
                assert False

    test(1)
    test(None, exc=ValueError)
    test(True)
    test(False)
    test('asdf')
    test([1,2])
    test({'a': 'b'})
    test(AnsibleUndefined(), exc=ValueError)
    test(AnsibleUndefined(name='foo'), exc='foo')
    test(AnsibleUndefined(name='foo'), msg='baz', exc='baz')

# Generated at 2022-06-22 14:05:25.151901
# Unit test for function mandatory
def test_mandatory():
    '''
    >>> a = mandatory('string')
    >>> a
    'string'
    >>> mandatory()
    Traceback (most recent call last):
    ...
    AnsibleFilterError: Mandatory variable 'Unknown' not defined.
    >>> mandatory(undefined())
    Traceback (most recent call last):
    ...
    AnsibleFilterError: 'Unknown' is undefined
    >>> mandatory(undefined(), msg='Message')
    Traceback (most recent call last):
    ...
    AnsibleFilterError: Message
    >>> mandatory(undefined(), msg='{{undefined}}')
    Traceback (most recent call last):
    ...
    AnsibleFilterError: message
    '''
    pass



# Generated at 2022-06-22 14:05:32.238207
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'a.b') == 'a\\.b'
    assert regex_escape(r'a.b', 'posix_basic') == 'a\\.b'
    # TODO: enable this test after posix_extended is implemented
    # assert regex_escape(r'a.b', 'posix_extended') == 'a\\.b'



# Generated at 2022-06-22 14:05:34.193289
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp/*') == ['/tmp/hsperfdata_root']



# Generated at 2022-06-22 14:05:41.604204
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.runtime import Context
    from jinja2.utils import contextfunction
    # Overwrite Jinja do_groupby filter
    filters['groupby'] = contextfunction(_do_groupby)
    assert do_groupby(Environment(), [{'id': 1, 'name': 'a'}, {'id': 1, 'name': 'b'}, {'id': 2, 'name': 'c'}], 'id') == [
        (1, [{'id': 1, 'name': 'a'}, {'id': 1, 'name': 'b'}]),
        (2, [{'id': 2, 'name': 'c'}])]



# Generated at 2022-06-22 14:05:45.373857
# Unit test for function mandatory
def test_mandatory():
    '''
    test_mandatory a.b = "c"
    '''
    template_args = {
        'a': {'b': 'c'},
    }
    template_output = 'c'
    assert mandatory(template_args, msg='a.b = c') == template_output



# Generated at 2022-06-22 14:05:58.034436
# Unit test for function regex_escape
def test_regex_escape():
    # List of input and expected output for each regex type
    test_data = {
        'python': [
            ['this is a test',
             'this\\ is\\ a\\ test',
             ''],
            ['Test with {regex.special} chars',
             'Test\\ with\\ \\{regex\\.special\\}\\ chars',
             ''],
        ],
        'posix_basic': [
            ['this is a test',
             'this\\ is\\ a\\ test',
             ''],
            ['Test with {regex.special} chars',
             'Test\\ with\\ \\{regex.special\\}\\ chars',
             ''],
            ['[][.^$*\\',
             '\\[\\]\\[\\.\\^\\$\\*\\\\',
             ''],
        ],
    }


# Generated at 2022-06-22 14:06:10.102172
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible import context
    from ansible.plugins.loader import filter_loader

    context.CLIARGS = ImmutableDict(tags={}, listtags=False, listtasks=False, listhosts=False, syntax=False, connection=None, module_path=None, forks=None, remote_user=None, private_key_file=None, ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=None, become_method=None, become_user=None, verbosity=None, check=None, diff=False, start_at_task=None)

    name = 'FilterModule'
    m = sys.modules['ansible.plugins.filter.%s' % name]
    fmp = filter_loader._create_filter_

# Generated at 2022-06-22 14:06:22.157856
# Unit test for function regex_search
def test_regex_search():
    assert None is regex_search('a', 'b')
    assert None is regex_search('abc', '[b]')
    assert 'a' is regex_search('abc', 'a')
    assert 'a' is regex_search('abc', 'a', '\\0')
    assert ['a'] is regex_search('abc', 'a', '\\0', '\\g<0>')
    assert 'a' is regex_search('abc', '[a]')
    assert 'a' is regex_search('abc', '[a]', '\\g<0>')
    assert 'a' is regex_search('abc', '[a]', '\\0', '\\g<0>')

# Generated at 2022-06-22 14:06:35.634717
# Unit test for function regex_search
def test_regex_search():
    str = "/system/system"
    pattern1 = r'^/system/(\S+)/'
    pattern2 = r'^/system/(\w+)/'
    pattern3 = r'^/system/([\w-]+)/'
    print(regex_search(str, pattern1, '\\g<1>'))
    print(regex_search(str, pattern2, '\\1'))
    print(regex_search(str, pattern3, '\\1'))
    print(regex_search(str, pattern3, '\\1', '\\g<1>'))
    print(regex_search(str, pattern3))
    print(regex_search(str, pattern3, ignorecase=True, multiline=True))

# Generated at 2022-06-22 14:06:37.327483
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(AnsibleUndefined("foo"),
                     msg="This is a valid test of an undefined variable") == None
    assert mandatory("this is a string") == "this is a string"



# Generated at 2022-06-22 14:06:48.597581
# Unit test for function regex_search
def test_regex_search():
    # Single backref
    assert regex_search("foo 123 bar", r'(^\w+).\s(\d+).(\w+)', '\\g<2>') == ['123']
    # Multiple backrefs
    assert regex_search("foo 123 bar", r'(^\w+).\s(\d+).(\w+)', '\\g<2>', '\\g<1>', '\\g<3>') == ['123',  'foo', 'bar']
    # Multiple backrefs with non-capturing group
    assert regex_search("foo 123 bar", r'(?:^\w+).\s(\d+).(\w+)', '\\g<2>', '\\g<1>') == ['123', 'bar']
    # Single backref with index

# Generated at 2022-06-22 14:07:01.592170
# Unit test for function randomize_list
def test_randomize_list():

    # Test that randomize_list does not shuffle items in a list
    # if no random seed is given
    items = ['item1', 'item2', 'item3']
    for i in range(3):
        # Make sure we don't get the same sequence three times
        randomized_items = randomize_list(items)
        assert items != randomized_items, "Items were not shuffled"

    # Test that randomize_list shuffle items in a list
    # with a random seed is provided
    items = ['item1', 'item2', 'item3']
    seed = 1
    randomized_items = randomize_list(items, seed)
    assert items != randomized_items, "Items were not shuffled"

    # Test that randomize_list does not shuffle items in a list
    # if the same seed is provided

# Generated at 2022-06-22 14:07:13.193863
# Unit test for function comment
def test_comment():
    assert comment('test string', decoration='') == '#test string'
    assert comment('test string', decoration=' # ') == '# test string'
    assert comment('test string', decoration=' # ', beginning='-- begin', end='-- end') == '-- begin# test string# -- end'
    assert comment('test string', decoration=' # ', prefix='XX ', postfix=' YY') == '# XX test string YY'
    assert comment('test string', decoration=' # ', prefix='XX ', postfix=' YY', prefix_count=2, postfix_count=3) == '# XX # XX test string YY YY YY'

# Generated at 2022-06-22 14:07:16.881100
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(
        [{'a': 1, 'b': 2, 'c': 3}],
        width=60,
        indent=2,
        default_flow_style=False) == to_text("""-
  a: 1
  b: 2
  c: 3
""")


# Generated at 2022-06-22 14:07:22.354920
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    f = mandatory(undefined('a'))
    assert isinstance(f, AnsibleFilterError)
    f = mandatory(undefined('a'), 'Failed to find {{ a }}')
    assert isinstance(f, AnsibleFilterError)
    assert f.message == "Failed to find {{ a }}"



# Generated at 2022-06-22 14:07:34.097251
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.template import AnsibleEnvironment
    env = AnsibleEnvironment(loader=None, extensions=[])
    y = [dict(name='dave',hostname='server1.example.org'),
         dict(name='david',hostname='server2.example.org'),
         dict(name='steve',hostname='server2.example.org'),
         dict(name='steven',hostname='server3.example.org'),
         dict(name='dave',hostname='server1.example.org'),
         dict(name='steven',hostname='server2.example.org')]

# Generated at 2022-06-22 14:07:44.307201
# Unit test for function mandatory
def test_mandatory():
    try:
        mandatory(None)
        assert False, "Should have thrown an exception."
    except AnsibleFilterError:
        pass

    try:
        mandatory(42)
        assert False, "Should have thrown an exception."
    except AnsibleFilterError:
        pass

    try:
        mandatory('pizza')
        assert False, "Should have thrown an exception."
    except AnsibleFilterError:
        pass

    try:
        mandatory(dict())
        assert False, "Should have thrown an exception."
    except AnsibleFilterError:
        pass

    assert mandatory(None, msg="Mandatory message") == "Mandatory message"
    assert mandatory(42, msg="Mandatory message") == "Mandatory message"
    assert mandatory('pizza', msg="Mandatory message") == "Mandatory message"

# Generated at 2022-06-22 14:07:51.725602
# Unit test for function mandatory
def test_mandatory():
    ''' Unit test for function mandatory '''

    # An empty string
    in_string = ''
    assert mandatory(in_string) == in_string
    assert mandatory(unicode_wrap(in_string)) == unicode_wrap(in_string)
    # A string
    in_string = 'hello world'
    assert mandatory(in_string) == in_string
    assert mandatory(unicode_wrap(in_string)) == unicode_wrap(in_string)
    # An empty list
    in_list = []
    assert mandatory(in_list) == in_list
    # A list
    in_list = [1,2,3,4]
    assert mandatory(in_list) == in_list
    # An empty dictionary
    in_dict = {}
    assert mandatory(in_dict) == in_dict
   

# Generated at 2022-06-22 14:08:05.003339
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    test_list = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    res = list_of_dict_key_value_elements_to_dict(test_list, key_name='key', value_name='value')
    assert isinstance(res, dict)
    assert res['a'] == 1
    assert res['b'] == 2
    res = list_of_dict_key_value_elements_to_dict(test_list, key_name='value', value_name='key')
    assert isinstance(res, dict)
    assert res[1] == 'a'
    assert res[2] == 'b'



# Generated at 2022-06-22 14:08:16.271895
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', '1451126570.0') == '2015-12-25'
    assert strftime('%Y-%m-%d', '1451126570') == '2015-12-25'
    assert strftime('%Y-%m-%d', '1451126570') == '2015-12-25'
    assert strftime('%Y-%m-%d', '{{ 1451126570 | float }}') == '2015-12-25'
    assert strftime('%Y-%m-%d', '{{ 1451126570 | int }}') == '2015-12-25'


# Generated at 2022-06-22 14:08:26.022739
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.jinja2 import AnsibleJ2Environment
    from ansible.plugins.loader import template_loader

    env = AnsibleJ2Environment(
        loader=template_loader,
        autoescape=False,
        undefined=jinja2.StrictUndefined,
    )
    env.filters.update(do_groupby=do_groupby)


# Generated at 2022-06-22 14:08:38.414056
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'key1', 'value': 'value1'},
                                                    {'key': 'key2', 'value': 'value2'},
                                                    {'key': 'key3', 'value': 'value3'},
                                                    {'key': 'key4', 'value': 'value4'},
                                                   ]) == {'key1': 'value1',
                                                          'key2': 'value2',
                                                          'key3': 'value3',
                                                          'key4': 'value4'}

# Generated at 2022-06-22 14:08:51.743031
# Unit test for function regex_search
def test_regex_search():
    assert [u'BAR'] == regex_search(u'FOO-BAR-BAZ', u'BAR', u'\\g<1>')
    assert u'BAR' == regex_search(u'FOO-BAR-BAZ', u'BAR', u'\\0')
    assert u'BAR' == regex_search(u'FOO-BAR-BAZ', u'BAR')
    assert [u'BAR', u'FOO'] == regex_search(u'FOO-BAR-BAZ', u'(FOO)-(BAR)', u'\\g<2>', u'\\g<1>')

# Generated at 2022-06-22 14:08:58.514545
# Unit test for function extract
def test_extract():
    env = Environment()
    d1 = {'a': 1, 'b': {'c': 2, 'd': {'e': 3}}}
    assert extract('a', d1, env) == 1
    assert extract('e', d1, env, 'd') == 3
    assert extract('e', d1, env, 'd', 'b') == 3
    assert extract('e', d1, env, morekeys=['b', 'd']) == 3
    assert extract('e', d1, env, morekeys=['b', 'd', 'a']) == 3



# Generated at 2022-06-22 14:09:05.587749
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    class TestObj(object):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b

        def __repr__(self):
            return "TEST({0},{1})".format(self.a, self.b)
    obj = TestObj(a=1, b=2)
    assert to_nice_yaml(obj) == "TEST(1,2)"



# Generated at 2022-06-22 14:09:11.729536
# Unit test for function regex_search
def test_regex_search():
    value = 'example-0001.txt'
    regex = r'example-(\d{4}).txt'

# Generated at 2022-06-22 14:09:23.246313
# Unit test for function subelements
def test_subelements():
    # This unit test uses the doctest module
    import doctest
    mydict = dict(
        authorized=['/tmp/alice/.ssh/id_rsa.pub', '/tmp/alice/.ssh/anotherkey.pub'],
        groups=['wheel'],
        name='alice'
    )
    mylist = [mydict, mydict]
    mylist[0]['name'] = 'bob'
    print(subelements(mydict, 'groups'))
    print(subelements(mylist, 'groups'))
    print(subelements(mylist, ['authorized', 'groups']))
    doctest.testmod()



# Generated at 2022-06-22 14:09:31.538242
# Unit test for function regex_search
def test_regex_search():
    ''' Test regex_search '''
    test = regex_search("1234", "(\\d{4})")
    assert test == '1234'

    test = regex_search("1234", "(\\d{4})", "\\g<1>")
    assert test == '1234'

    test = regex_search("1234", "(\\d{4})", "\\1")
    assert test == '1234'

    test = regex_search("a 1234 b", "(\\d{4})")
    assert test == '1234'

    test = regex_search("a 1234 b", "(\\d{4})", "\\g<1>")
    assert test == '1234'


# Generated at 2022-06-22 14:09:41.986772
# Unit test for function comment
def test_comment():

    # Test each style
    for key, value in comment_styles.items():

        # Generate text
        text = "comment(%s)" % (key)

        # Test on multiple set of params
        for params in [[],
                       [],
                       [],
                       [],
                       [],
                       [],
                       []]:

            # Test with and without text
            for t in [text, ""]:

                # Eventually print all the params
                if params:
                    p = ", ".join(["%s='%s'" % (k, v) for k, v in params.items()])
                    print("comment(%s, style='%s', %s)" % (t, key, p))

                # Test the function

# Generated at 2022-06-22 14:09:49.141898
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('a1b2c3', r'\d') == '1'
    assert regex_search('a1b2c3', r'\d', '\\2') == ['1', '2']
    assert regex_search('a1b2c3', r'\d', '\\g<2>') == ['1', '2']
    assert regex_search('a1b2c3', r'\d+', '\\g<0>', ignorecase=True, multiline=True) == ['1', '2', '3']



# Generated at 2022-06-22 14:09:57.030637
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence

    assert is_sequence(to_nice_yaml([1, 2, 3]))
    assert to_text(to_nice_yaml({'a': 1})) == to_text("""\
a: 1
""")
    assert to_text(to_nice_yaml({'a': {'b': 2}})) == to_text("""\
a:
    b: 2
""")



# Generated at 2022-06-22 14:10:09.059498
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>') == 'a'
    assert regex_search('abc', 'a', '\\1') == 'a'
    assert regex_search('abcd', r'(a)(b)(c)(d)', '\\g<1>') == 'a'
    assert regex_search('abcd', r'(a)(b)(c)(d)', '\\g<2>') == 'b'
    assert regex_search('abcd', r'(a)(b)(c)(d)', '\\g<3>') == 'c'
    assert regex_search('abcd', r'(a)(b)(c)(d)', '\\g<4>') == 'd'
   

# Generated at 2022-06-22 14:10:22.160725
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.vars.hostvars import HostVars
    from jinja2.environment import Environment
    from jinja2.runtime import Context
    from jinja2.exceptions import UndefinedError
    from collections import namedtuple
    test_data = [('a', 1), ('a', 2), ('a', 3), ('b', 1), ('b', 2), ('b', 3)]
    test_data_namedtuple = [('a', 1), ('a', 2), ('a', 3),
                            ('b', 1), ('b', 2), ('b', 3)]
    TestNamedTuple = namedtuple('TestNamedTuple', ['letter', 'number'])

# Generated at 2022-06-22 14:10:34.968392
# Unit test for function extract
def test_extract():
    assert extract({}, 'a', {'a': 'b'}) == 'b'
    assert extract({}, 'a', {'a': {'b': 'c'}}) == {'b': 'c'}

    assert extract({}, 'a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract({}, 'a', {'a': {'b': {'c': 'd'}}}, 'b') == {'c': 'd'}
    assert extract({}, 'a', {'a': {'b': {'c': 'd'}}}, 'b', 'c') == 'd'

    s = {'a': {'b': {'c': 'd'}}}
    assert extract({}, 'a', s, 'b', 'c') == 'd'
    assert s

# Generated at 2022-06-22 14:10:47.912805
# Unit test for function combine
def test_combine():
    dict1 = dict(A = dict(a = 1,b = 1,c = 1), B = dict(a = 1,b = 1,c = 1), C = dict(a = 1,b = 1,c = 1))
    dict2 = dict(A = dict(a = 2,b = 1,d = 1), B = dict(x = 1,y = 1,z = 1), D = dict(a = 1,b = 1,c = 1))
    dict3 = dict(A = dict(a = 2,b = 2,d = 2), B = dict(x = 2,y = 2,z = 2), Z = dict(a = 1,b = 1,c = 1))


# Generated at 2022-06-22 14:11:00.319871
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('http://www.example.com', 'http://(.+).example.com', '\\g<1>') == 'www'
    assert regex_search('http://www.example.com', 'http://(?P<wm>www).example.com', '\\g<wm>',
                        ignorecase=True) == 'www'
    assert regex_search('http://www.example.com', 'http://(?P<wm>www).example.com', '\\1',
                        ignorecase=True) == 'www'
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '(:?f)oo', r'\1') == 'f'



# Generated at 2022-06-22 14:11:08.525463
# Unit test for function do_groupby
def test_do_groupby():
    # Test to ensure that calling do_groupby returns results, and that they
    # are tuples
    test_value = [{'item': 'foo', 'nested': {'a': 'b'}},
                  {'item': 'bar', 'nested': {'a': 'b'}},
                  {'item': 'foo', 'nested': {'a': 'c'}}]
    # Test to ensure that the method returns a result, and that the results
    # are actually tuples
    results = do_groupby(test_value, attribute='item')
    if results is None:  # results should not be None
        raise AssertionError("do_groupby returned None, instead of a list of items")

# Generated at 2022-06-22 14:11:20.083938
# Unit test for function regex_search
def test_regex_search():
    match = regex_search('ansible 1.9.4', r'\d+\.\d+\.\d+')
    assert match == '1.9.4'

    match = regex_search('ansible 1.9.4', r'\d+\.\d+\.\d+', '\\g<0>')
    assert match == '1.9.4'

    match = regex_search('ansible 1.9.4', r'\d+\.\d+\.\d+', '\\1')
    assert match == '1'

    match = regex_search('ansible 1.9.4', r'\d+\.\d+\.\d+', '\\2')
    assert match == '9'
