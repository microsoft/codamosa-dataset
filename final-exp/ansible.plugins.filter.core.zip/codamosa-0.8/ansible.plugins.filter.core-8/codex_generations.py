

# Generated at 2022-06-22 14:01:48.171501
# Unit test for function fileglob
def test_fileglob():
    g = fileglob('filter_plugins/test/data/directory/*/')
    if len(g) != 3:
        raise AssertionError("Expected list of 3 elements, got %s" % repr(g))



# Generated at 2022-06-22 14:01:58.082351
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(True) is True
    try:
        mandatory(AnsibleUndefined())
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError('did not error on AnsibleUndefined')
    try:
        mandatory(AnsibleUndefined(), msg="blah")
    except AnsibleFilterError as e:
        assert 'blah' in to_text(e)
    else:
        raise AssertionError('did not error on AnsibleUndefined')
    try:
        mandatory(AnsibleUndefined(name='foo'), msg="blah")
    except AnsibleFilterError as e:
        assert 'blah' in to_text(e)
        assert 'foo' in to_text(e)
    else:
        raise AssertionError('did not error on AnsibleUndefined')

# Generated at 2022-06-22 14:02:09.207634
# Unit test for function fileglob
def test_fileglob():
    res = fileglob('/dev/t*')

# Generated at 2022-06-22 14:02:18.169724
# Unit test for function extract
def test_extract():

    # Test 1: no morekeys
    #   create the enviroment variable
    #   create the dict variable with key1 and key2
    #   create the item variable
    #   call the function extract
    #   assert the result
    environment = Environment()
    container = {'key1': 'value1', 'key2': 'value2'}
    item = 'key1'
    result = extract(environment, item, container)
    assert 'value1' == result

    # Test 2: a list morekeys
    #   create the enviroment variable
    #   create the dict variable with key1 and key2
    #   create the item variable
    #   create the morekeys variable with a list
    #   call the function extract
    #   assert the result
    environment = Environment()

# Generated at 2022-06-22 14:02:22.433597
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'



# Generated at 2022-06-22 14:02:29.005317
# Unit test for function comment
def test_comment():
    '''Test the comment function'''
    TEST_TEXT = '''\
It's a trap!
Now we are trapped!
Are you sure?'''
    TEST_PLAIN = '''\
# It's a trap!
# Now we are trapped!
# Are you sure?'''
    TEST_ERLANG = '''\
% It's a trap!
% Now we are trapped!
% Are you sure?'''
    TEST_C = '''\
// It's a trap!
// Now we are trapped!
// Are you sure?'''
    TEST_CBLOCK = '''\
/*
 * It's a trap!
 * Now we are trapped!
 * Are you sure? */'''

# Generated at 2022-06-22 14:02:36.616168
# Unit test for function strftime
def test_strftime():
    ''' strftime should return current year according to localtime '''
    c = strftime("%Y")
    if len(c) != 4 or int(c) < 1970:
        raise AssertionError("time.strftime returned an unexpected value")
    c = strftime("%s")
    if len(c) != 10 or int(c) < 0:
        raise AssertionError("time.strftime returned an unexpected value")



# Generated at 2022-06-22 14:02:46.175467
# Unit test for function regex_search

# Generated at 2022-06-22 14:02:54.400774
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello there', r'hello') == 'hello'
    assert regex_search('hello there', r'hello', '\\g<0>') == ['hello', 'hello']
    assert regex_search('hello there', r'hello', '\\1') == ['1']
    assert regex_search('hello there', r'hello', '\\2') == ['2']
    assert regex_search('hello there', r'hello', '\\g<1>', '\\2') == ['1', '2']



# Generated at 2022-06-22 14:03:05.988151
# Unit test for function mandatory
def test_mandatory():
    e = AnsibleFilterError

    # None / boolean are ok (in python)
    assert None == mandatory(None)
    assert True == mandatory(True)
    assert False == mandatory(False)
    # Strings are ok
    assert 'foo' == mandatory('foo')

    # don't know what the msg is supposed to do
    # assert 'foo' == mandatory(AnsibleUndefined(msg='foo'))
    assert 'foo' == mandatory(AnsibleUndefined(key=''))

    # Make sure we're getting the right kind of thing back
    assert isinstance(mandatory(AnsibleUndefined(key='')), string_types)

    # test the string

# Generated at 2022-06-22 14:03:10.747208
# Unit test for function regex_search
def test_regex_search():
    AnsibleFilterError('Unknown argument')



# Generated at 2022-06-22 14:03:22.519390
# Unit test for function get_hash
def test_get_hash():
    data = 'foo bar'
    assert get_hash(data, 'md5') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert get_hash(data, 'sha1') == 'b913d5bbb4824bd21145707351fc50fa8cf43ad3'
    assert get_hash(data, 'sha224') == 'd7a718f920b128023d644a15a8516b3c1f2dd8f0e959c48cfb0cdd16'

# Generated at 2022-06-22 14:03:24.076715
# Unit test for function fileglob
def test_fileglob():
    return fileglob("playbooks/files/testfiles/*")


# Generated at 2022-06-22 14:03:33.564890
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(u'aabbccdd', u'([a-z]+)[0-9]+(.*)', u'\\1\\2') == u'aabbccdd'
    assert regex_replace(u'aabbccdd', u'(a+)(b+)', u'\\1\\2a') == u'aabababccdd'
    assert regex_replace(u'aabbccdd', u'a', u'b') == u'bbbbccdd'
    assert regex_replace(u'aabbccdd', u'aa', u'b') == u'bbbccdd'



# Generated at 2022-06-22 14:03:41.546850
# Unit test for function comment
def test_comment():
    # Test plain text
    print(comment(
        "hi\nhi2\nhi3\nhi4\nhi5",
        'plain',
        newline="\n",
        decoration="# "))
    # Test C comments
    print(comment(
        "hi\nhi2\nhi3\nhi4\nhi5",
        'c',
        newline="\n"))
    # Test C block comments
    print(comment(
        "hi\nhi2\nhi3\nhi4\nhi5",
        'cblock',
        newline="\n",
        prefix="#",
        decoration="* ",
        end="*/"))
    # Test Erlang comments

# Generated at 2022-06-22 14:03:46.206798
# Unit test for function do_groupby
def test_do_groupby():
    data = [{'os': 'CentOS', 'release': '6.5', 'category': 'system'}, {'os': 'RHEL', 'release': '6.5', 'category': 'system'}, {'os': 'Ubuntu', 'release': '12.04', 'category': 'system'}, {'os': 'Debian', 'release': '7', 'category': 'system'}, {'os': 'CentOS', 'release': '6.4', 'category': 'system'}, {'os': 'RHEL', 'release': '6.4', 'category': 'system'}, {'os': 'Debian', 'release': '6', 'category': 'system'}]
    environment = Environment()

# Generated at 2022-06-22 14:03:49.128367
# Unit test for function strftime
def test_strftime():
    string_format = '%Y-%m-%d %H:%M:%S'
    second = 1343641600
    assert strftime(string_format, second) == '2012-08-07 20:00:00'



# Generated at 2022-06-22 14:04:00.588365
# Unit test for function subelements
def test_subelements():
    obj = [{'name': 'alice', 'groups': ['wheel', 'dev'], 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
           {'name': 'bob', 'groups': ['wheel'], 'authorized': ['/tmp/bob/onekey.pub']}]
    result = subelements(obj, 'groups')
    assert len(result) == 3

# Generated at 2022-06-22 14:04:07.826998
# Unit test for function do_groupby
def test_do_groupby():

    # Test that filter do_groupby is using our filter
    # This means that we are using the correct filter
    # Test with a tuple that uses namedtuple
    fake_groupby = collections.namedtuple(
        'FakeGroupby',
        ['grouper', 'list_or_itr'])

    # We're testing that something that is a namedtuple is
    # transformed into something that is a tuple
    assert isinstance(do_groupby(None, fake_groupby), tuple)



# Generated at 2022-06-22 14:04:16.928483
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('123abc456abc789abc', r'abc', '\\g<0>', '\\g<0>', '\\2') == ['abc', 'abc', '456']
    assert regex_search('123abc456abc789abc', r'abc', '\\0', '\\0', '\\2') == ['abc', 'abc', '456']
    assert regex_search('123abc456abc789abc', r'abc', '\\g<0>', '\\g<0>', '\\3') == ['abc', 'abc', '789']

# Generated at 2022-06-22 14:04:36.473348
# Unit test for function regex_search
def test_regex_search():
    string = '192.168.99.100'
    match = regex_search(string, '\d+\.\d+\.\d+\.\d+', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>')
    assert '192' == match[0]
    assert '168' == match[1]
    assert '99' == match[2]
    assert '100' == match[3]
    match = regex_search(string, '\d+\.\d+\.\d+\.\d+', '\\g<1>', '\\g<3>', '\\g<4>')
    assert '192' == match[0]
    assert '99' == match[1]
    assert '100' == match[2]
    match = regex_search

# Generated at 2022-06-22 14:04:43.323403
# Unit test for function regex_search
def test_regex_search():
    value = '''
ssssssssssss
ssssssssssss
ssssssssssss
ssssssssssss
ssssssssssss
ssssssssssss
ssssssssssss
    '''
    actual = regex_search(value, r'\n *\n')
    assert actual == '\nssssssssssss\n'
    assert regex_search(value, r'(\n *\n)', 1) == '\nssssssssssss\n'



# Generated at 2022-06-22 14:04:54.180744
# Unit test for function extract
def test_extract():
    import pytest

    item = 'item'

    # Test with strings
    container = {'container': 'string'}
    assert extract(item, container) == 'string'

    # Test with lists
    container = {'container': [1, 2, 3]}
    assert extract(item, container) == [1, 2, 3]
    assert extract('a', {'a': [1, 2, 3]}) == [1, 2, 3]
    assert extract(1, {'a': [1, 2, 3]}) == 2
    assert extract(1, [1, 2, 3]) == 2

    # Test with dicts
    container = {'container': {'child': 'string'}}
    assert extract(item, container) == {'child': 'string'}
    assert extract('child', container) == 'string'



# Generated at 2022-06-22 14:05:01.044799
# Unit test for function do_groupby
def test_do_groupby():
    input = [{'key': 'a', 'value': {'foo': 1}}, {'key': 'a', 'value': {'foo': 2}}, {'key': 'b', 'value': {'foo': 1}}]
    output = do_groupby(input, 'key')
    assert output == [('a', {'foo': 1}, {'foo': 2}), ('b', {'foo': 1})]



# Generated at 2022-06-22 14:05:05.772651
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'key': 'value'}) == 'key: value\n'
    assert to_yaml({'key': 12}) == 'key: 12\n'
    assert to_yaml(['value1', 'value2']) == '- value1\n- value2\n'


# Generated at 2022-06-22 14:05:11.011873
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape("/foo/bar/baz", re_type='python') == "\\/foo\\/bar\\/baz"
    assert regex_escape("/foo/bar/baz", re_type='posix_basic') == "\\/foo\\/bar\\/baz"
    try:
        regex_escape("/foo/bar/baz", re_type='posix_extended')
    except AnsibleFilterError:
        pass
    else:
        assert False



# Generated at 2022-06-22 14:05:23.983276
# Unit test for function do_groupby
def test_do_groupby():
    Given = namedtuple('Given', ['key', 'value'])

    def build_test_data(test_data):
        test_input = []
        for test_key, test_value in test_data.items():
            test_input.append(Given(test_key, test_value))
        return test_input

    assert do_groupby([], 'key') == []
    assert do_groupby(build_test_data({}), 'key') == []

    assert do_groupby(build_test_data({'a': 1}), 'key') == [
        ('a', [1])]
    assert do_groupby(build_test_data({'a': 2}), 'value') == [
        (2, [2])]


# Generated at 2022-06-22 14:05:36.884835
# Unit test for function randomize_list

# Generated at 2022-06-22 14:05:44.631053
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2.environment import Environment
    from jinja2 import meta

    environment = Environment()
    environment.filters.update({'groupby': do_groupby})
    ast = environment.parse('{{ [1,2,3,4] | groupby(attribute="odd") }}')
    result = meta.find_undeclared_variables(ast)
    assert result == set(), "Failed to find undeclared variables in jinja2 environment"



# Generated at 2022-06-22 14:05:53.370205
# Unit test for function do_groupby
def test_do_groupby():
    # The jinja2 groupby function returns a namedtuple, but this causes
    # issues with ansible.template.safe_eval.safe_eval, which cannot parse
    # the data.
    # Adapted from the jinja2 standard_filters.py test.
    data = [{'a': 'foo'},
            {'a': 'bar'},
            {'a': 'foo'},
            {'a': 'foo2'},
            {'a': 'bar2'}]

# Generated at 2022-06-22 14:06:06.242498
# Unit test for function regex_search

# Generated at 2022-06-22 14:06:14.536044
# Unit test for function regex_replace
def test_regex_replace():
    # A proper test unit would be nice here
    assert regex_replace('foo', 'f', 'b') == 'boo'
    assert regex_replace('foo', 'f', 'b', ignorecase=True) == 'boo'
    assert regex_replace('foo', 'f', 'b', multiline=True) == 'boo'
    assert regex_replace('foo', 'f', 'b', ignorecase=True, multiline=True) == 'boo'
    assert regex_replace('foo,bar', 'ba', 'fu', ignorecase=True, multiline=True) == 'foo,fur'
    assert regex_replace('foo,bar', 'ba', 'fu', ignorecase=False, multiline=True) == 'foo,fu'

# Generated at 2022-06-22 14:06:19.611289
# Unit test for function randomize_list
def test_randomize_list():
    """Test 'random' filter"""
    list1 = [1, 2, 3, 4, 5]
    list2 = randomize_list(list1, '123')
    assert list1 == [1, 2, 3, 4, 5]
    assert list2 != [1, 2, 3, 4, 5]



# Generated at 2022-06-22 14:06:29.027160
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = {"name": "test_to_nice_yaml", "dict": {'test': 'dict', 'test2': 'dict2'}, "list": [1, 2, 3], "tuple": (1, 2, 3)}
    assert to_nice_yaml(a) == to_text("""{name: test_to_nice_yaml,
dict:
    test2: dict2
    test: dict,
list: [1,
    2,
    3],
tuple: [1,
    2,
    3]}
""")



# Generated at 2022-06-22 14:06:37.673269
# Unit test for function to_bool
def test_to_bool():
    assert to_bool('1') is True
    assert to_bool('false') is False
    assert to_bool('False') is False
    assert to_bool(1) is True
    assert to_bool([]) is False
    assert to_bool(None) is None

#
# Make all the glob functions available without having to import them
# directly.
#


#
# Jinja2 filter functions
#


# Replace from_list and replace_list from jinja2.filters

# Generated at 2022-06-22 14:06:41.650913
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    try:
        mandatory(None)
        assert False
    except AnsibleFilterError:
        pass
    try:
        mandatory(dict())
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:06:42.974051
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('value') == 'value'



# Generated at 2022-06-22 14:06:52.981135
# Unit test for function comment
def test_comment():
    o = [
        'This is a line\n',
        'This is another line,\n',
        'This is a last line.'
    ]

    # Example different plain text comment types
    print(comment(o, 'plain', newline='\n'))
    print(comment(o, 'erlang', newline='\n'))
    print(comment(o, 'c', newline='\n'))
    print(comment(o, 'cblock', newline='\n'))
    print(comment(o, 'xml', newline='\n'))

    # Predefine style

# Generated at 2022-06-22 14:07:05.454114
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foobar', '(foo)(bar)', '\\g<1>', '\\2') == ['foo', 'bar']
    assert regex_search('FOOBAR foobar', '(foo)(bar)', '\\g<1>', '\\2', ignorecase=True) == ['FOO', 'BAR']
    assert regex_search('FOOBAR foobar\nFOOBARfoobar', '(foo)(bar)', '\\g<1>', '\\2', multiline=True) == ['FOO', 'BAR']
    assert regex_search('foobar', '(foo)(bar)', '\\g<1>', '\\2', ignorecase=True, multiline=True) == ['foo', 'bar']


# Generated at 2022-06-22 14:07:11.534730
# Unit test for function to_bool
def test_to_bool():
    ''' Test to_bool filter '''
    true_values = ['yes', 'on', '1', 'true', 1, True]
    false_values = ['no', 'off', '0', 'false', 0, False]
    for value in true_values:
        assert to_bool(value) is True
    for value in false_values:
        assert to_bool(value) is False



# Generated at 2022-06-22 14:07:25.229595
# Unit test for function do_groupby
def test_do_groupby():
    from ..plugins import filters
    from . import TestJinjaFilters

    def _check_groupby_tuple(groupby_tuple):
        for k,v in groupby_tuple:
            assert isinstance(k, string_types)
            assert isinstance(v, list)
            assert isinstance(v[0], tuple)

    collection = [
        {'a': 'a', 'b': 'b'},
        {'a': 'a', 'b': 'c'},
        {'a': 'd', 'b': 'd'},
    ]
    collection_grouped = [
        ('a', [('a', 'b'), ('a', 'c')]),
        ('d', [('d', 'd')])
    ]


# Generated at 2022-06-22 14:07:35.699090
# Unit test for function do_groupby
def test_do_groupby():
    vars = {'a': [{'key': 1}, {'key': 2}], 'b': [{'key': 5}, {'key': 3}]}
    template = Template(r"""{{ a + b | do_groupby('key') | selectattr('0', 'equalto', 2) | selectattr('1') | list }}""")
    data = [{'key': 2}]

    # Prior to fix, the jinja2 `do_groupby` command returned a namedtuple,
    # where the repr was not able to be handled by ansible.template.safe_eval.safe_eval

    # Now, the namedtuple is handled, and the repr is converted to a standard python tuple.
    assert template.render(vars) == json.dumps(data)


# Generated at 2022-06-22 14:07:43.200325
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('1234567890', r'([0-9]{3})([0-9]{3})', '\\1', '\\2') == ['345', '678']
    assert regex_search('1234567890', r'([0-9]{3})([0-9]{3})', '\\g<1>', '\\g<2>') == ['345', '678']
    assert regex_search('1234567890', r'([0-9]{3})([0-9]{3})', '\\g<1>') == ['345']



# Generated at 2022-06-22 14:07:45.903095
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(data="1", hashtype='md5') == "c4ca4238a0b923820dcc509a6f75849b"


# Generated at 2022-06-22 14:07:54.675336
# Unit test for function combine
def test_combine():
    assert {'a': 1} == combine({'a': 1})
    assert {'a': 1} == combine([{'a': 1}])
    assert {'a': 1} == combine([{'a': 2}, {'a': 1}])
    assert {'a': {'b': 2}} == combine({'a': {'c': 2}}, {'a': {'b': 2}})
    assert {'a': {'b': 2}} == combine({'a': {'c': 2}}, {'a': {'b': 2}}, recursive=True)
    assert {'a': {'b': [1, 2, 3]}} == combine([{'a': {'b': [1, 2]}}, {'a': {'b': [3]}}], recursive=True, list_merge='append')


# Generated at 2022-06-22 14:08:04.798917
# Unit test for function combine
def test_combine():
    def test(expected, *terms, **kwargs):
        actual = combine(*terms, **kwargs)
        assert expected == actual, "%r != %r" % (expected, actual)

    # simple case
    test(
        {'a': 1, 'b': 2},
        {'a': 1},
        {'b': 2},
    )

    # replace
    test(
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 'replace'},
        {'b': 2},
    )

    # merge
    test(
        {'a': {'x': 1, 'z': 3}, 'b': 2},
        {'a': {'x': 1}, 'b': 2},
        {'a': {'z': 3}},
    )

    # merge

# Generated at 2022-06-22 14:08:12.382893
# Unit test for function rand
def test_rand():
    assert isinstance(rand([1,2,3]), int)
    assert isinstance(rand(1,10), int)
    assert isinstance(rand(1,10,seed='dummy'), int)
    try:
        rand(1,2,3,4,5)
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError('Failed to raise AnsibleFilterError for too many args')



# Generated at 2022-06-22 14:08:19.628258
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    x = dict(a=5, b=dict(c=10, d=15, e=[1,2,3]), f='a string')
    assert(to_nice_yaml(x, indent=4) == "- a: 5\n  b:\n    c: 10\n    d: 15\n    e:\n    - 1\n    - 2\n    - 3\n  f: a string\n")


# Generated at 2022-06-22 14:08:27.699084
# Unit test for function combine
def test_combine():
    # Test 1: no arg
    assert combine() == {}

    # Test 2: One arg
    my_dict = {
        "foo": "bar",
        "bar": "foo",
        "nested": {
            "a": "1",
            "b": "2"
        },
        "list": [0, 1, 2],
        "list_of_dicts": [{"x": 1, "y": 2}, {"x": 10, "y": 20}],
    }
    assert combine(my_dict) == my_dict

    # Test 3: multiple dicts, no list in dicts

# Generated at 2022-06-22 14:08:33.660563
# Unit test for function do_groupby
def test_do_groupby():
    jinjagrouper = jinja2.defaults.DEFAULT_NAMESPACE['groupby']
    result = jinjagrouper(None, 'name', [{'name': 'one'}, {'name': 'two'}])
    result = list(result)
    assert isinstance(result[0], jinja2.runtime.GroupTuple)
    assert isinstance(result[1], jinja2.runtime.GroupTuple)
    assert result[0].grouper == 'one'

    result = do_groupby(None, 'name', [{'name': 'one'}, {'name': 'two'}])
    result = list(result)
    assert isinstance(result[0], tuple)
    assert isinstance(result[1], tuple)
    assert result[0].grouper

# Generated at 2022-06-22 14:08:48.852586
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    o = { 1: 'one', 2: 'two' }
    assert to_nice_yaml(o, default_flow_style=False) == '1: one\n2: two\n'
    assert to_nice_yaml(o, default_flow_style=True) == '{1: one, 2: two}\n'


# Generated at 2022-06-22 14:08:58.812923
# Unit test for function regex_search
def test_regex_search():
    test_value = u'abcdefgh'
    test_string = u'abc[def]gh'
    test_regex = r'abc(\[def\])gh'
    assert regex_search(test_value, test_regex, '\\1') == test_string
    test_regex = r'abc(\[def\])gh'
    assert regex_search(test_value, test_regex, '\\g<1>') == test_string
    test_regex = r'(a)(b)(c)(\[def\])(g)(h)'
    assert regex_search(test_value, test_regex, '\\0', '\\6') == ['abc[def]gh', u'h']
    test_regex = r'.*(.+)@(.+)\.(.+)'
    assert regex_

# Generated at 2022-06-22 14:09:10.474570
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var

    data1 = {'a': 1, 'b': 2, 'c': 3}
    data2 = {'a': 1, 'b': 2}
    data3 = {'a': 2, 'b': 8}
    data = [data1, data2, data3]

    env = {'var': wrap_var(data)}

    assert do_groupby(env, 'var', 'a') == [(1, [data1, data2]), (2, [data3])]
    assert do_groupby(env, 'var', 'b') == [(2, [data1, data2]), (8, [data3])]



# Generated at 2022-06-22 14:09:23.771091
# Unit test for function regex_search
def test_regex_search():
    '''Test regex_search'''
    assert regex_search(None, None) is None
    assert regex_search('', '') is None
    assert regex_search('aabbccdd', 'aabbccdd') == 'aabbccdd'
    assert regex_search('string1string2string3', 'string1') == 'string1'
    assert regex_search('string1string2string3', 'string2') == 'string2'
    assert regex_search('string1string2string3', 'string3') == 'string3'
    assert regex_search('string1string2string3', 'string4') is None
    assert regex_search('string1string2string3', 'string1', '\\g<1>') == ['string1']

# Generated at 2022-06-22 14:09:31.597619
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    # Ensure this works with a jinja2.Undefined value
    assert [] == do_groupby(env, Undefined(None), None)


# By default, Ansible templates have trim_blocks true and lstrip_blocks false.
# Therefore, we can't use the normal syntax ("{%- if ... -%}" or "{%- endif -%}")
# to have extra whitespace removed. We have to use "{%-" and "-%}" instead.

# Generated at 2022-06-22 14:09:43.679197
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader
    from jinja2.sandbox import SandboxedEnvironment

    env = SandboxedEnvironment(loader=DictLoader(dict(t='''
{% set list1 = [dig1, dig2, dig3] %}
{% set list2 = [dig2, dig3, dig1] %}

{%- for key, value in list1 | groupby('id') %}
- group:
  {%- for t in value %}
  - id: {{t['id']}}
    opened: {{t['opened']}}
    closed: {{t['closed']}}
  {%- endfor %}
{% endfor %}
''')))
    tmpl = env.get_template('t')

# Generated at 2022-06-22 14:09:44.412323
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-22 14:09:49.459085
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("toto", "toto") == "toto"

    assert regex_search("toto", "toto", '\\1') == ["toto"]

    assert regex_search("toto", "(o)", "\\g<1>") == ["o"]

    assert regex_search("toto", "t(o)", '\\g<1>', '\\1') == ["o", "o"]



# Generated at 2022-06-22 14:09:51.920164
# Unit test for function fileglob
def test_fileglob():
  assert fileglob('./*/*.py') == ['./ansible/modules/files/synchronize.py']


# Generated at 2022-06-22 14:10:04.985083
# Unit test for function extract
def test_extract():
    environment = DummyEnvironment()
    env = {'test': {'test2': {'test3': {'test4': 'test5'}}}}
    # test for string for item
    assert 'test5' == extract(environment, 'test4', env['test']['test2']['test3'])
    # test for string for item and string for morekeys
    assert 'test5' == extract(environment, 'test4', env['test'], 'test2')
    # test for list for morekeys
    assert 'test5' == extract(environment, 'test4', env, ['test', 'test2'])
    # test for string for item and list for morekeys
    assert 'test5' == extract(environment, 'test4', env['test'], ['test2'])
    # test for invalid morekeys type (dict)

# Generated at 2022-06-22 14:10:24.402715
# Unit test for function do_groupby
def test_do_groupby():
    from collections import namedtuple
    from jinja2.environment import Environment
    from jinja2.runtime import Context
    from jinja2.environment import StrictUndefined
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    env = Environment(undefined=StrictUndefined)
    c = Context(env, dict(dict=dict))

    t = namedtuple('t', ('a', 'b'))
    data = [(t('x', 'a'), 1), (t('x', 'b'), 2), (t('y', 'a'), 3), (t('y', 'b'), 4)]

# Generated at 2022-06-22 14:10:25.891637
# Unit test for function flatten
def test_flatten():
    mylist = [["foo", "bar"], ["baz", 42], ["qux"]]
    assert flatten(mylist, levels=1) == ['foo', 'bar', 'baz', 42, 'qux']



# Generated at 2022-06-22 14:10:32.174950
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", 1510959996.295088) == "2017-11-15 15:59:56"
    assert strftime("%Y-%m-%d %H:%M:%S", 1512468996.295088) == "2017-12-09 15:49:56"



# Generated at 2022-06-22 14:10:40.808341
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('<o>', '<o>') == '<o>'
    assert regex_search('<o>', '<(\\w)>') == 'o'
    assert regex_search('<o>', '<(\\w)>', '\\g<1>') == ['o', 'o']
    assert regex_search('<o>', '<(\\w)>', '\\g<1>', '\\1') == ['o', 'o', 'o']
    assert regex_search('[o]', r'\[(\w)\]', '\\g<1>') == ['o']
    assert regex_search('[o]', r'\[(\w)\]', '\\1') == ['o']

# Generated at 2022-06-22 14:10:53.529039
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('hello', 'md5') == '5d41402abc4b2a76b9719d911017c592'
    assert get_hash('hello', 'sha1') == 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'
    assert get_hash('hello', 'sha256') == '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'

# Generated at 2022-06-22 14:11:05.652150
# Unit test for function fileglob
def test_fileglob():
    # Create 3 test files
    file_name_1 = '/tmp/test_file_1.txt'
    file_name_2 = '/tmp/test_file_2.txt'
    file_name_3 = '/tmp/test_file_3.txt'
    with open(file_name_1, 'w+') as f:
        f.write('test file 1')
    with open(file_name_2, 'w+') as f:
        f.write('test file 2')
    with open(file_name_3, 'w+') as f:
        f.write('test file 3')

    # Create directory
    directory = '/tmp/test_dir'
    if not os.path.exists(directory):
        os.makedirs(directory)


# Generated at 2022-06-22 14:11:18.605474
# Unit test for function rand
def test_rand():
    assert rand(range(0, 21, 5), 6) % 5 == 1, 'should not return a multiple of 5'
    assert rand([0, 5, 8, 10]) in [0, 5, 8, 10], 'should return one of 0, 5, 8, 10'
    assert rand(20) < 20, 'should return a value smaller than 20'
    assert rand(20) >= 0, 'should return a value bigger than or equal to 0'
    assert rand(20, seed=None) == rand(20, seed=None), 'should return the same value for the same seed'
    assert rand(10, step=2) % 2 == 0, 'should return an even value'
    assert rand(10, step=2) in range(10), 'should return a value in range(10)'

# Generated at 2022-06-22 14:11:29.270982
# Unit test for function fileglob
def test_fileglob():
    # We "touch" a few files and check for their existance.
    import tempfile
    # create temporary directory
    tmpdir = tempfile.mkdtemp()
    # grab name of temporary directory
    tmpdirname = tmpdir.split('/')[-1]
    # set prefix of temporary file
    prefix = 'tmp_ansible_test_file'
    # create three temporary files
    testfiles = []
    for i in range(3):
        fd, fname = tempfile.mkstemp(prefix=prefix, dir=tmpdir)
        # close the file
        os.close(fd)
        # save name to list
        testfiles.append(fname.split('/')[-1])

    # create pathname and run function