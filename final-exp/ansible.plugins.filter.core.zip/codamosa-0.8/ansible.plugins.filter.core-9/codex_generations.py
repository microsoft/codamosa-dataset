

# Generated at 2022-06-22 14:01:55.357922
# Unit test for function ternary
def test_ternary():
    assert ternary(True,2,3) == 2
    assert ternary(False,2,3) == 3
    assert ternary(None,2,3,4) == 4



# Generated at 2022-06-22 14:02:02.851272
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('true') is True
    assert to_bool('False') is False
    assert to_bool('1') is True
    assert to_bool(1) is True
    assert to_bool('0') is False
    assert to_bool(0) is False
    assert to_bool('foo') is False
    assert to_bool('') is False
    assert to_bool('fAlSe') is False
    assert to_bool(['foo']) is False
    assert to_bool([]) is False



# Generated at 2022-06-22 14:02:15.737280
# Unit test for function do_groupby
def test_do_groupby():
    f = do_groupby
    # 1. Test regular jinja2 behavior with tuple
    assert f([], 'a') == []
    assert f([{'a': 1}], 'a') == [(None, [{'a': 1}])]
    assert f([{'a': 1}, {'a': 2}], 'a') == [(None, [{'a': 1}]), (None, [{'a': 2}])]
    assert f([{'a': 1}, {'a': 1}], 'a') == [(1, [{'a': 1}, {'a': 1}])]

# Generated at 2022-06-22 14:02:28.248106
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(1) is True
    assert to_bool("1") is True
    assert to_bool("True") is True
    assert to_bool("true") is True
    assert to_bool("yes") is True
    assert to_bool("on") is True
    assert to_bool("oops") is False
    assert to_bool("False") is False
    assert to_bool("false") is False
    assert to_bool("off") is False
    assert to_bool("no") is False
    assert to_bool("0") is False
    assert to_bool(0) is False
    assert to_bool("") is False
    assert to_bool(None) is None



# Generated at 2022-06-22 14:02:31.252358
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/no/such/file/**') == []
    assert fileglob('') == []



# Generated at 2022-06-22 14:02:36.385159
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp/') == []
    assert fileglob('./testfile.txt') == ['./testfile.txt']
    assert fileglob('/tmp/' + str(uuid.uuid4())) == []



# Generated at 2022-06-22 14:02:45.814692
# Unit test for function do_groupby
def test_do_groupby():
    class t():
        def __init__(self, n1, n2):
            self.n1 = n1
            self.n2 = n2

    class t2():
        def __init__(self, n1, n2):
            self.n1 = n1
            self.n2 = n2

    class t3():
        def __init__(self, n1, n2):
            self.n1 = n1
            self.n2 = n2

    class t4():
        def __init__(self, n1, n2):
            self.n1 = n1
            self.n2 = n2

    class t5():
        def __init__(self, n1, n2):
            self.n1 = n1
            self.n2 = n2


# Generated at 2022-06-22 14:02:52.623958
# Unit test for function ternary
def test_ternary():
    assert ternary(None, True, False) == False
    assert ternary(None, True, False, True) == True
    assert ternary(True, True, False) == True
    assert ternary(False, True, False) == False
    assert ternary(0, True, False) == False
    assert ternary(1, True, False) == True

# Generated at 2022-06-22 14:02:55.076961
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/*') == glob.glob('/bin/*')
    assert fileglob('invalid/pattern') == []



# Generated at 2022-06-22 14:03:06.613208
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    def _do_groupby(value, attribute):
        ''' Wrapper function to call function do_groupby so we can test them
            individually.
        '''
        return do_groupby(Environment(), value, attribute)

    assert _do_groupby([], "") == []
    assert _do_groupby([{'a':'b', 'c':'d'}], 'a') == [('b', [{'a': 'b', 'c': 'd'}])]

# Generated at 2022-06-22 14:03:14.424748
# Unit test for function subelements
def test_subelements():
    '''Test for function subelements'''
    import doctest
    doctest.testmod(globs={'subelements': subelements})


# Generated at 2022-06-22 14:03:16.968572
# Unit test for function subelements
def test_subelements():
    import doctest

    doctest.testmod()

# ---- Ansible filters ----



# Generated at 2022-06-22 14:03:26.120692
# Unit test for function comment
def test_comment():
    # Test function with no optional arguments
    test_string = "Test string"
    expected_string = "# Test string"
    if comment(test_string) != expected_string:
        raise AssertionError(
            "Test failed. Actual result: %s Expected result: %s"
            % (comment(test_string), expected_string))

    # Test function with style argument
    expected_string = "// Test string"
    if comment(test_string, 'c') != expected_string:
        raise AssertionError(
            "Test failed. Actual result: %s Expected result: %s"
            % (comment(test_string, 'c'), expected_string))

    # Test function with optional arguments with newline
    test_string = "Test string 1\nTest string 2"

# Generated at 2022-06-22 14:03:28.764886
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("some string") == "f0995c1f26416a0a2b8c2617e7d07dbe0d9f3d8a"


# Generated at 2022-06-22 14:03:34.677080
# Unit test for function regex_search

# Generated at 2022-06-22 14:03:42.218323
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    test_dict = dict(a=1, b=2, c=3)

    # check that filter works just fine when variable exists
    result = mandatory(test_dict['a'], 'my message')
    assert result == 1

    # check that filter raises proper exception when variable undefined
    try:
        mandatory(test_dict['undefined'])
    except AnsibleFilterError as e:
        assert "Mandatory variable 'undefined' not defined." in to_native(e)

    # check that filter raises proper exception when variable undefined with msg
    try:
        mandatory(test_dict['undefined'], 'my message')
    except AnsibleFilterError as e:
        assert "my message" in to_native(e)

    # check that filter raises proper exception when variable is undefined

# Generated at 2022-06-22 14:03:46.851178
# Unit test for function rand
def test_rand():
    # test without seed
    assert rand(None, 10) in range(10)
    assert rand(None, [3, 5, 7, 9]) in [3, 5, 7, 9]
    # test with start and step
    assert rand(None, 10, 2, 2) in range(2, 10, 2)
    # test with seed
    seed = 1234567
    assert rand(None, 10, seed=seed) == 5
    assert rand(None, [1, 2, 3, 4], seed=seed) == 3
    assert rand(None, 10, 2, 2, seed=seed) == 6
    # test error handling
    try:
        rand(None, 10, 1)
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-22 14:03:55.348039
# Unit test for function mandatory
def test_mandatory():
    from ansible.template import Templar
    from jinja2.runtime import Undefined

    assert mandatory('foo') == 'foo'
    assert mandatory(Undefined(name='bar')) == Undefined(name='bar')


# Generated at 2022-06-22 14:03:58.034257
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert(subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')])


# Generated at 2022-06-22 14:04:06.172656
# Unit test for function subelements
def test_subelements():
    '''
    >>> import pprint
    >>> obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    >>> pprint.pprint(subelements(obj, 'groups'))
    [({'authorized': ['/tmp/alice/onekey.pub'],
       'groups': ['wheel'],
       'name': 'alice'},
      'wheel')]
    '''
    pass



# Generated at 2022-06-22 14:04:18.493581
# Unit test for function do_groupby
def test_do_groupby():
    from .. import ansible_filters
    env = ansible_filters.AnsibleJ2TemplateEnvironment()
    list = [{'id':'x', 'value':'a', 'more':'not this'}, {'id':'x', 'value':'b', 'more':'this'}, \
            {'id':'y', 'value':'c', 'more':'not this'}, {'id':'y', 'value':'d', 'more':'this'}]
    groupby = lambda env, value, attribute: ansible_filters.do_groupby(env, value, attribute)

# Generated at 2022-06-22 14:04:21.310396
# Unit test for function mandatory
def test_mandatory():
    x = AnsibleUndefined
    y = 1234
    assert(mandatory(y) == 1234)
    try:
        mandatory(x)
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:04:22.523871
# Unit test for function comment
def test_comment():
    return comment("""This is a test
for line break""")



# Generated at 2022-06-22 14:04:24.111383
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("myvar") == "myvar"



# Generated at 2022-06-22 14:04:36.845100
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("abc", "abc", "foo") == "foo"
    assert regex_replace("abcdef", "abc(.*)", "foo\\1bar") == "foobardef"
    assert regex_replace("abcdef", "(?P<foo>abc)(?P<bar>.*)", "\\1bar\\2foo") == "abcbar\\2foo"
    assert regex_replace("abcdef", r"(?P<foo>abc)(?P<bar>.*)", r"\1bar\2foo") == "abcbar\\2foo"
    assert regex_replace("abcdef", "(?P<foo>abc)(?P<bar>.*)", "\\g<bar>\\g<foo>") == "\\g<bar>\\g<foo>"

# Generated at 2022-06-22 14:04:45.933302
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6], seed=1) == [4, 3, 6, 5, 2, 1]
    assert sorted(randomize_list([1, 2, 3, 4, 5, 6], seed=2)) == sorted([1, 2, 3, 4, 5, 6])
    assert sorted(randomize_list([1, 2, 3, 4, 5, 6], seed=3)) == sorted([6, 3, 5, 4, 1, 2])
    assert sorted(randomize_list([1, 2, 3, 4, 5, 6], seed=4)) == sorted([3, 5, 2, 4, 6, 1])

# Generated at 2022-06-22 14:04:48.227769
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Setup
    filters = FilterModule().filters()

    # Exercise/Verify
    assert 'sha1' in filters, "FilterModule().filters() returned unexpected results: %r" % filters
    assert 'mandatory' in filters, "FilterModule().filters() returned unexpected results: %r" % filters
    assert 'comment' in filters, "FilterModule().filters() returned unexpected results: %r" % filters

# Generated at 2022-06-22 14:04:56.972214
# Unit test for function flatten
def test_flatten():

    # Flatten with nulls
    assert flatten([1, 2, [3, 4, [5, 6], 7, 8], 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten([1, 2, [3, 4, [5, 6, None], 7, 8], 9]) == [1, 2, 3, 4, 5, 6, None, 7, 8, 9]
    assert flatten([1, 2, [3, 4, [5, 6], 7, 8], 9]) == flatten([1, 2, [3, 4, [5, 6], 7, 8], 9], skip_nulls=False)

# Generated at 2022-06-22 14:05:06.158718
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(["a", "b"], seed=1), ["a", "b"]
    assert randomize_list(["a", "b"], seed=1), ["b", "a"]
    assert randomize_list(["a", "b", "c"]), ["a", "b", "c"]
    assert randomize_list(["a", "b", "c"]), ["a", "c", "b"]
    assert randomize_list(["a", "b", "c"]), ["b", "a", "c"]


# Generated at 2022-06-22 14:05:10.684416
# Unit test for function extract
def test_extract():
    env = DummyEnvironment({'key1': {'key2': 'value2'}})

    assert extract(env, 'key1', env.vars) == {'key2': 'value2'}
    assert extract(env, 'key1', env.vars, 'key2') == 'value2'
    assert extract(env, 'key1', env.vars, ['key2']) == 'value2'



# Generated at 2022-06-22 14:05:20.437476
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('$()*+.?[\]^{|}') == '\\$\\(\\)\\*\\+\\.\\?\\[\\\\\\]\\^\\{\\|\\}'



# Generated at 2022-06-22 14:05:29.302088
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    bad = Undefined(None, name=None)
    good = 'ok'

    # value is defined
    assert mandatory(good) == 'ok'

    # value is None
    assert mandatory(None) is None

    # value is empty string
    assert mandatory('') == ''

    # value is an empty list
    assert mandatory([]) == []

    # value is an empty dict
    assert mandatory({}) == {}

    # value is undefind
    try:
        mandatory(bad)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in str(e)
    else:
        raise AssertionError('AnsibleFilterError not raised')

    # value is undefind and a message is passed

# Generated at 2022-06-22 14:05:40.121353
# Unit test for function do_groupby
def test_do_groupby():
    # pylint: disable=protected-access
    # not really a test, but it provides a quick way to check what get_grouped_by() will do
    # import ansible.plugins.filter.core
    # print(ansible.plugins.filter.core.do_groupby.__code__)
    if LooseVersion(jinja2.__version__) < LooseVersion('2.9.0'):
        assert(LooseVersion(jinja2.__version__) > LooseVersion('2.9.5'))
    from ansible.template.jinja2.environment import _GroupTuple
    from ansible.template.jinja2.runtime import Macro
    env = jinja2.Environment()
    macro_code = Macro.do_groupby.__func__.__code__
    from types import CodeType


# Generated at 2022-06-22 14:05:42.636963
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(AnsibleUndefined(name='hello')) is None



# Generated at 2022-06-22 14:05:52.085977
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d") == time.strftime("%Y-%m-%d")

    epoch = time.time()
    assert strftime("%Y-%m-%d", epoch) == time.strftime("%Y-%m-%d", time.localtime(epoch))

    epoch = 0
    assert strftime("%Y-%m-%d", epoch) == time.strftime("%Y-%m-%d", time.localtime(epoch))

    epoch = "0"
    assert strftime("%Y-%m-%d", epoch) == time.strftime("%Y-%m-%d", time.localtime(float(epoch)))


# Generated at 2022-06-22 14:05:54.647830
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    undef = Undefined(name='name')

    assert mandatory(undef, msg='msg')



# Generated at 2022-06-22 14:05:59.141341
# Unit test for function mandatory
def test_mandatory():
    assert(mandatory(5) == 5)
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError:
        pass
    try:
        mandatory(AnsibleUndefined, "some message")
    except AnsibleFilterError as e:
        assert e.args[0] == "some message"



# Generated at 2022-06-22 14:06:10.485470
# Unit test for function comment
def test_comment():
    import re
    assert(re.match(
        r"<!--\n - .+\n - .+-->",
        comment("a\nb", style='xml')))
    assert(re.match(
        r"<!--\n - .+\n - .+-->",
        comment("a\nb", style='xml', decoration=' - ')))
    assert(re.match(
        r"<!--\n - a\n - b-->",
        comment("a\nb", style='xml', decoration=' - ')))
    assert(re.match(
        r"<!--\n - a\n - b\n - c-->",
        comment("a\nb\nc", style='xml', decoration=' - ')))

# Generated at 2022-06-22 14:06:16.927062
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == "[1, 2, 3]\n"
    assert to_yaml({"a": ["a1", "a2"], "b": "bstring"}) == "a:\n- a1\n- a2\nb: bstring\n"


# Generated at 2022-06-22 14:06:22.317774
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("hello") == "hello"
    try:
        mandatory(None)
    except AnsibleFilterError:
        pass
    else:
        assert False, "Expected AnsibleFilterError"
    try:
        mandatory(None, msg="foo")
    except AnsibleFilterError as e:
        assert str(e) == "foo"
    else:
        assert False, "Expected AnsibleFilterError"



# Generated at 2022-06-22 14:06:35.491795
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('python') == 'python'
    assert regex_escape('python', re_type='python') == 'python'
    assert regex_escape('python', re_type='posix_basic') == 'python'
    assert regex_escape('python', re_type='posix_extended') == 'python'
    assert regex_escape(r'python[0-9]\\.*') == 'python\[0-9\]\\\\\.\*'
    assert regex_escape(r'python[0-9]\\.*', re_type='python') == 'python\[0-9\]\\\\\.\*'
    assert regex_escape(r'python[0-9]\\.*', re_type='posix_basic') == 'python\\[0-9\\]\\\\\\\\\\.\\*'

# Generated at 2022-06-22 14:06:40.410526
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo.bar') == 'foo\\.bar'
    assert regex_escape(r'foo.bar', re_type="posix_basic") == 'foo\\.bar'
    # regex_escape(r'foo.bar', re_type="posix_extended") raises filter error



# Generated at 2022-06-22 14:06:44.506959
# Unit test for function to_yaml
def test_to_yaml():
    _test = {"one": 1, "two": 2, "three": 3}
    assert to_yaml(_test) == "one: 1\ntwo: 2\nthree: 3\n"



# Generated at 2022-06-22 14:06:53.281798
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%dT%H:%M:%SZ') == '%Y-%m-%dT%H:%M:%SZ'
    assert strftime('%Y-%m-%dT%H:%M:%SZ', '2015-01-02T12:34:56+07:00') == '2015-01-02T12:34:56Z'
    assert strftime('%Y-%m-%dT%H:%M:%SZ', '2016-03-16T20:34:56Z') == '2016-03-16T20:34:56Z'

# Generated at 2022-06-22 14:07:06.364561
# Unit test for function do_groupby
def test_do_groupby():
    data = [{'name': 'foo', 'group': 'group1'}, {'name': 'bar', 'group': 'group2'}]

    # Test against jinja2 <2.9.0
    environment = _TestJinja2Environment(jinja2_version=(2, 8, 10))
    assert 'jinja2.GroupTuple' in repr(do_groupby(environment, data, 'group'))

    # Test against jinja2 >=2.9.0, <2.9.5
    environment = _TestJinja2Environment(jinja2_version=(2, 9, 2))
    assert 'jinja2.GroupTuple' in repr(do_groupby(environment, data, 'group'))

    # Test against jinja2 >=2.9.5
    environment = _TestJin

# Generated at 2022-06-22 14:07:16.681875
# Unit test for function comment
def test_comment():
    assert comment('A text', 'xml') == "<!--\n - A text\n-->\n"
    assert comment('A text', decoration=' * ') == " * A text\n"

    assert comment('A text', 'cblock', prefix_count=2) == "/**\n" \
        " * \n" \
        " * A text\n" \
        " */\n"

    assert comment('A text\nMore text', 'plain') == "# A text\n" \
        "# More text\n"

    assert comment('A text', 'plain', decoration='// ') == "// A text\n"
    assert comment('A text', 'xml', decoration='// ') == "<!--\n" \
        "// A text\n" \
        "-->\n"



# Generated at 2022-06-22 14:07:25.896583
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2

    env = jinja2.Environment()
    t = env.from_string('{% set value = [{ "a": 2, "b": 3 }, { "a": 3, "b": 2 }, { "a": 2, "b": 4 }] %}'
                        '{{ value|groupby("a")|list }}')
    if LooseVersion(jinja2.__version__) >= LooseVersion('2.9.0') and LooseVersion(jinja2.__version__) < LooseVersion('2.9.5'):
        # LooseVersion(jinja2.__version__) < LooseVersion('2.9.5')
        import decimal
        from jinja2.runtime import LoopContext
        from collections import namedtuple

# Generated at 2022-06-22 14:07:31.246110
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', '^(\w+)\s(\w+)$', '\\1') == 'hello'
    assert regex_search('hello world', '^(\w+)\s(\w+)$', '\\2') == 'world'
    assert regex_search('hello world', '^(\w+)\s(\w+)$', '\\g<1>') == 'hello'
    assert regex_search('hello world', '^(\w+)\s(\w+)$', '\\g<2>') == 'world'
    assert regex_search('hello world', '^(\w+)\s(\w+)$', '\\g<1>', '\\g<2>') == ['hello', 'world']

# Generated at 2022-06-22 14:07:37.852964
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.module_utils._text import to_bytes, to_text
    assert to_text(to_nice_yaml({u'f\xfch': {u'b\xe4r': [1, 2, 3]}})) == to_text(u'''{f\xfch: {b\xe4r: [1, 2, 3]}}
''')



# Generated at 2022-06-22 14:07:47.495580
# Unit test for function mandatory
def test_mandatory():
    ''' Unit test for function mandatory '''
    from ansible.template import Jinja2TemplateModule
    from ansible.errors import AnsibleError

    template_module = Jinja2TemplateModule()

    # Test for variable defined
    template = template_module.template_from_string("{{ variable }}")
    variable = template.render(variable="value")
    assert variable == "value"

    # Test for variable defined with msg
    template = template_module.template_from_string("{{ variable | mandatory(msg='foo') }}")
    variable = template.render(variable="value")
    assert variable == "value"

    # Test for variable undefined with msg
    template = template_module.template_from_string("{{ variable | mandatory(msg='foo') }}")

# Generated at 2022-06-22 14:08:03.899815
# Unit test for function do_groupby
def test_do_groupby():
    def make_groupby(value):
        class FakeEnv:
            def getitem(self, value, attribute):
                return value[attribute]

        return do_groupby(FakeEnv(), value, "attribute")

    input_value = [
        {'attribute': 'a', 'other': '1'},
        {'attribute': 'b', 'other': '2'},
        {'attribute': 'a', 'other': '3'},
    ]
    expected_value = [
        ('a', [{'attribute': 'a', 'other': '1'}]),
        ('b', [{'attribute': 'b', 'other': '2'}]),
        ('a', [{'attribute': 'a', 'other': '3'}]),
    ]
    actual_value = make_groupby(input_value)


# Generated at 2022-06-22 14:08:16.976907
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', time.time()) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    assert strftime('%Y-%m-%d %H:%M:%S', float(0)) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(float(0)))
    assert strftime('%Y-%m-%d %H:%M:%S', 0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))

# Generated at 2022-06-22 14:08:23.789712
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(
        'This is the 1st test',
        'This (is) (\S+)',
        '\\g<1>', '\\g<2>',
    ) == ['is', '1st']
    assert regex_search(
        'This is the 1st test',
        'This (is) (\S+)',
        '\\g<1>', '\\g<2>',
        ignorecase=True,
    ) == ['is', '1st']



# Generated at 2022-06-22 14:08:36.345128
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('te', 'te') == 'te'
    assert regex_search('hello', '\w{5}') == 'hello'
    assert regex_search('hello', '\w{5}', '\\g<0>') == ['hello', 'hello']
    assert regex_search('hello', '\w{5}', '\\0') == ['hello', 'hello']
    assert regex_search('hello', '\w{5}', '\\g<0>', '\\0') == ['hello', 'hello', 'hello', 'hello']
    assert regex_search('hello', '\w{5}', '\\1', ignorecase=True) == []
    assert regex_search('HELLO', '\w{5}', '\\1', ignorecase=True) == []



# Generated at 2022-06-22 14:08:49.019555
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('asdf', 'a', '\\1') == 'a'
    assert regex_search('asdf', 'a', '\\g<1>') == 'a'
    assert regex_search('asdf', 'a', '\\2') == None
    assert regex_search('asdf', 'a', '\\g<2>') == None
    assert regex_search('asdfasdf', 'a(sdf)a(sdf)', '\\2') == 'sdf'
    assert regex_search('asdfasdf', 'a(sdf)a(sdf)', '\\g<2>') == 'sdf'

# Generated at 2022-06-22 14:08:51.486830
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4]) != [1, 2, 3, 4]



# Generated at 2022-06-22 14:08:59.699580
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == "---\n- 1\n- 2\n- 3\n"
    assert to_yaml([1, 2, 3], default_flow_style=False) == "---\n- 1\n- 2\n- 3\n"
    assert to_yaml({"a": 1, "b": 2}) == "---\n{a: 1, b: 2}\n"
    assert to_yaml({"a": 1, "b": 2}, default_flow_style=False) == "---\n{a: 1, b: 2}\n"
    assert to_yaml({"a": 1, "b": 2}, default_flow_style=True) == "--- {a: 1, b: 2}\n"


# Generated at 2022-06-22 14:09:02.640636
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('abcd') == hashlib.sha1('abcd').hexdigest()


# Generated at 2022-06-22 14:09:15.352604
# Unit test for function subelements
def test_subelements():
    element_list = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]},
                    {"name": "carol", "groups": ["wheel", "staff"], "authorized": ["/tmp/carol/onekey.pub", "/tmp/carol/twokey.pub"]}]

# Generated at 2022-06-22 14:09:26.906486
# Unit test for function randomize_list
def test_randomize_list():
    import copy
    mylist = ['foo', 'bar', 'baz', 'qux', 'blah']
    newlist = randomize_list(mylist, 'foobar')
    assert newlist != mylist
    assert sorted(mylist) == sorted(newlist)
    assert randomize_list(mylist, 'foobar') == newlist
    assert randomize_list(mylist, 'not_foobar') != newlist
    assert randomize_list(mylist, 'not_foobar') != mylist
    newlist = randomize_list(mylist)
    assert newlist != mylist
    assert sorted(mylist) == sorted(newlist)
    assert randomize_list(mylist) != newlist
    mylist.append(True)

# Generated at 2022-06-22 14:09:35.482114
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(dict(foo=42, bar='spam')) == '{bar: spam, foo: 42}\n'
    assert to_yaml(dict(foo=42, bar='spam'), default_flow_style=False) == 'bar: spam\nfoo: 42\n'
    assert to_yaml(dict(foo=dict(bar=dict(baz=[42])))) == '{foo: {bar: {baz: [42]}}}\n'



# Generated at 2022-06-22 14:09:40.266726
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.vars import AnsibleVars

    # Test variable list with do_groupby
    variable_list = [
        (1, 2),
        (3, 4)
    ]
    # Test environment
    environment = Environment()
    environment.tests['jinja2_groupby'] = jinja2_groupby
    # Test variable object
    variable_object = AnsibleVars()
    variable_object.set_variable('groupby_list', variable_list)

    # Test namedtuple from do_groupby
    namedtuple_from_do_groupby = do_groupby(environment, variable_list, 1)
    assert isinstance(namedtuple_from_do_groupby[0], tuple)

# Generated at 2022-06-22 14:09:42.866424
# Unit test for function do_groupby
def test_do_groupby():
    environment = MagicMock()
    environment.getitem.return_value = ("foo", "bar")
    value = "some_value"
    attribute = "some_attribute"
    result = do_groupby(environment, value, attribute)
    assert [tuple(t) for t in _do_groupby(environment, value, attribute)] == result
# End unit test for function do_groupby



# Generated at 2022-06-22 14:09:51.759528
# Unit test for function get_hash
def test_get_hash():
    # test get_hash with different hash types and empty data
    assert get_hash(b'', hashtype='sha1') == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'
    assert get_hash(b'', hashtype='sha256') == 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    assert get_hash(b'', hashtype='md5') == 'd41d8cd98f00b204e9800998ecf8427e'
    # Test get_hash with sha1 and data

# Generated at 2022-06-22 14:10:04.685076
# Unit test for function extract
def test_extract():
    # Set up test environment
    env = jinja2.Environment(loader=jinja2.DictLoader({}))
    env.globals['extract'] = extract

    # Test normal usage with list
    result = env.from_string("{{ ['a', {'b': {'c': 'd'} }] | extract('b', 'c') }}")
    assert result.render() == 'd'
    # Test normal usage with dictionary
    result = env.from_string("{{ {'a': 'b', 'c': {'d': {'e': 'f'} } } | extract('c', 'd', 'e') }}")
    assert result.render() == 'f'

    # Test error handling

# Generated at 2022-06-22 14:10:06.030525
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    print(subelements(obj, 'groups'))


# Generated at 2022-06-22 14:10:14.133710
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('1.2.3', r'\.', ':') == '1:2:3'
    assert regex_replace('0a', r'[^0-9]', '1') == '01'
    assert regex_replace('00,00,00.000', r'0+', '') == ',,'
    assert regex_replace('<html><title>foo</title></html>', r'<.*?>', '') == 'foo'
    assert regex_replace('<html><title>foo</title></html>', r'<.*?>', replacement=' ') == ' foo '
    assert regex_replace('<html><title>foo</title></html>', r'<.*?>', replacement=' ', multiline=True) == '  foo  '

# Generated at 2022-06-22 14:10:25.105739
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.safe_eval import unsafe_eval
    item1 = unsafe_eval(u"dict(a='2', b='4')")
    item2 = unsafe_eval(u"dict(a='1', b='3')")

    value = [item1, item2]

    env = JinjaEnvironment()
    # This should produce no errors and should return the value we expect
    result = do_groupby(
        env,
        value,
        attribute=u'a'
    )

    assert result[0][0] == '2'
    assert result[0][1] == [item1]
    assert result[1][0] == '1'
    assert result[1][1] == [item2]



# Generated at 2022-06-22 14:10:30.632805
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([{'a': 123}]) == "[{a: 123}]\n"
    assert to_yaml({'a': 123}) == "{a: 123}\n"
    assert to_yaml([1, 2, 3]) == "- 1\n- 2\n- 3\n"


# Generated at 2022-06-22 14:10:35.062431
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1,"seven"], default_flow_style=False).splitlines() == [
        "---",
        "- 1",
        "- seven"
    ]
    assert to_yaml([1,"seven"], default_flow_style=True) == "[1, 'seven']"


# Generated at 2022-06-22 14:10:43.849448
# Unit test for function to_yaml
def test_to_yaml():
    assert isinstance(to_yaml([1, 2, 3]), string_types)
    assert to_yaml([1, 2, 3]) == "[1, 2, 3]\n"

# Generated at 2022-06-22 14:10:48.402724
# Unit test for function do_groupby
def test_do_groupby():
    import pytest
    from ansible.template.safe_eval import safe_eval
    from jinja2 import Template

    # Spot check a few hashes to make sure the filter works properly
    expected = [("first", [("a", {"k": "v"}), ("b", (1, 2))]),
                ("second", [("c", "foo"), ("d", True)])]

    # Create two lists, one with named tuples, and one without, to test
    # both jinja2<2.9.0 and jinja2>=2.9.0

# Generated at 2022-06-22 14:10:53.275110
# Unit test for function extract
def test_extract():
    getitem = lambda container, key: container[key]
    assert extract({'getitem': getitem}, 'key1', {'key1': {'key2': 'value'}}) == {'key2': 'value'}
    assert extract({'getitem': getitem}, 'key2', {'key1': {'key2': 'value'}}, 'key1') == 'value'
    assert extract({'getitem': getitem}, 'key1', {'key1': 'value'}, 'key2') == 'value'
    assert extract({'getitem': getitem}, 'key1', {'key1': 'value'}) == 'value'
    assert extract({'getitem': getitem}, 'key1', {'key2': 'value'}, ['key1', 'key2']) == 'value'

# Generated at 2022-06-22 14:11:05.471264
# Unit test for function extract

# Generated at 2022-06-22 14:11:18.557806
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    result = subelements(obj, 'groups')
    assert [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')] == result
    result = subelements([{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}], 'groups')
    assert [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')] == result