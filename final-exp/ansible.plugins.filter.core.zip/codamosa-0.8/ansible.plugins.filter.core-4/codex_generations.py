

# Generated at 2022-06-22 14:02:02.893067
# Unit test for function mandatory
def test_mandatory():
    from jinja2 import Environment, StrictUndefined

    e = Environment()
    e.filters['mandatory'] = mandatory

    template = u"{{ optional | mandatory(msg='Variable " \
               u"`optional` is not defined!') }}"

    t = e.from_string(template)
    assert t.render(optional='foo') == 'foo'

    # Make sure that a decent error message is returned, when
    # the variable is not defined.
    with pytest.raises(AnsibleFilterError) as exc:
        t.render(e)
    assert "Mandatory variable 'optional' not defined." in str(exc)

    # Make sure an error message can be set
    template = u"{{ optional | mandatory(msg='The variable " \
               u"`optional` is not defined!') }}"
   

# Generated at 2022-06-22 14:02:14.280071
# Unit test for function mandatory
def test_mandatory():
    value = AnsibleUndefined('value')
    msg = 'This is a test error message'
    try:
        mandatory(value, msg=msg)
        # The code should never reach this, because the mandatory() call should raise an exception
        assert False
    except AnsibleFilterError as e:
        assert msg == str(e)
    except AssertionError:
        # A different exception was raised. Fail the test.
        raise
    except Exception:
        # A different exception was raised. Fail the test.
        assert False


# In the future, it may be appropriate to make this a generic interface for
# arbitrary objects, but for now it is a very simple wrapper for dicts.

# Generated at 2022-06-22 14:02:15.832167
# Unit test for function mandatory
def test_mandatory():
    # This shouldn't throw an exception because the variable is defined
    assert mandatory(None) is None



# Generated at 2022-06-22 14:02:29.257844
# Unit test for function combine
def test_combine():
    assert combine({}, {}) == {}
    assert combine({'a': 'b'}, {}) == {'a': 'b'}
    assert combine({'a': 'b'}, {'a': 'c'}) == {'a': 'c'}
    assert combine({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert combine({'a': 'b'}, {'a': None}) == {'a': None}
    assert combine({'a': 'b'}, {'a': None}, {'a': 'e'}) == {'a': 'e'}

# Generated at 2022-06-22 14:02:42.064269
# Unit test for function mandatory
def test_mandatory():
    from ansible import constants as C
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    C.DEFAULT_UNDEFINED_VAR_BEHAVIOR = 'error'

    assert mandatory(42) == 42
    assert mandatory(AnsibleUnsafeText(u'foo')) == u'foo'

    try:
        mandatory(undefined('foo'))
    except AnsibleFilterError as e:
        assert "foo" in to_text(e)
        assert "Mandatory variable" in to_text(e)
    else:
        assert False, "Exception should have been raised"

    try:
        mandatory(undefined('foo'), "Foo bar")
    except AnsibleFilterError as e:
        assert "Foo bar" in to_text(e)

# Generated at 2022-06-22 14:02:54.454173
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(None, "Test message")
    assert mandatory("Hello World", "Test message")
    assert mandatory("Hello World") is not None
    try:
        # this should raise an exception
        assert mandatory({'one': {'two': {'three': Undefined('One.Two.Three')}}}, "Test message")
    except:
        error_raised = 1
    assert error_raised == 1
    try:
        # this should raise an exception, but with a different error message
        assert mandatory({'one': {'two': {'three': Undefined('One.Two.Three')}}})
    except:
        error_raised = 1
    assert error_raised == 1

# Generated at 2022-06-22 14:02:56.628016
# Unit test for function do_groupby
def test_do_groupby():
    assert isinstance(do_groupby([{'key': 'value'}], 'key'), list)



# Generated at 2022-06-22 14:03:06.956086
# Unit test for function regex_search
def test_regex_search():
    # see https://docs.python.org/3/library/re.html#re.Pattern.groups
    assert regex_search('/bar/foo.txt', r'/(\w+)/(\w+).(\w+)') == '/bar/foo.txt'
    assert regex_search('/bar/foo.txt', r'/(\w+)/(\w+).(\w+)', '\\1') == 'bar'
    assert regex_search('/bar/foo.txt', r'/(\w+)/(\w+).(\w+)', '\\g<2>') == 'foo'
    assert regex_search('/bar/foo.txt', r'/(\w+)/(\w+).(\w+)', '\\g<3>') == 'txt'



# Generated at 2022-06-22 14:03:09.296885
# Unit test for function fileglob
def test_fileglob():
    b = fileglob('/bin/*')
    assert ('/bin/sh' in b)
    assert ('/bin/bash' in b)
    assert ('/bin/grep' in b)



# Generated at 2022-06-22 14:03:13.250937
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/profile.d/*') == ['/etc/profile.d/colorls.sh',
                                           '/etc/profile.d/color_prompt'], \
        "fileglob should match files only in a given path"

    assert fileglob('/this/path/does/not/exist/*') == [], \
        "fileglob should return empty list if no match is found"



# Generated at 2022-06-22 14:03:34.633826
# Unit test for function extract
def test_extract():
    class TestDict(dict):
        pass

    test_result = TestDict()
    test_result['value1'] = 'b'
    test_result['value2'] = {'c': 'd'}

    data = TestDict()
    data['value1'] = 'a'
    data['value2'] = test_result

    # Test ansible module.String class
    assert extract('value1', data) == 'a'
    assert extract('value2', data) == test_result

    # Test key and morekeys variables
    assert extract('value1', data, 'value2') == 'b'
    assert extract(
        'value2', data, 'value2', 'value1') == test_result['value1']
    assert extract(
        'value2', data, 'value2', ['value1']) 

# Generated at 2022-06-22 14:03:47.118745
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.compat.tests.mock import patch, Mock

    test_data = ['foo', 'bar', 'baz', 'qux', 'quux']
    test_attribute = 'test'
    group_by_test_attribute_value = []
    for i in test_data:
        group_by_test_attribute_value.append((test_attribute, i))
    env = Environment()
    with patch.object(env, 'getitem', Mock(side_effect=lambda x, y: x.get(y, y))):
        with patch.object(env, 'globals') as globs:
            globs['_do_groupby'] = Mock(return_value=group_by_test_attribute_value)


# Generated at 2022-06-22 14:03:55.823577
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('A regular expression is a sequence of characters used for matching', 're\\g<1>.\\g<2>') == 'regular expression'
    assert regex_search('A regular expression is a sequence of characters used for matching', 're\\g<1>.\\g<2>', '\\g<1>') == 'regular'
    assert regex_search('A regular expression is a sequence of characters used for matching', 're\\g<1>.\\g<2>', '\\g<2>') == 'expression'
    assert regex_search('A regular expression is a sequence of characters used for matching', 're\\g<1>.\\g<2>', '\\g<3>') == []

# Generated at 2022-06-22 14:04:00.741362
# Unit test for function combine

# Generated at 2022-06-22 14:04:06.073931
# Unit test for function regex_search
def test_regex_search():
    value = "0123456789"
    regex_search(value, "\\d")
    regex_search(value, "\\d+")
    regex_search(value, "\\d", "\\g<2>")
    regex_search(value, "\\d", "\\1")
    regex_search(value, "\\d", "\\g<1>", "\\2")
    regex_search(value, "\\g<1>", "\\2")



# Generated at 2022-06-22 14:04:11.099596
# Unit test for function combine
def test_combine():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-22 14:04:16.068580
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({"key": ['value']}) == "key:\n- value\n"
    assert to_nice_yaml([{"key": 'value'}]) == "- key: value\n"
    assert to_nice_yaml({'key': {'nested-key': 'value'}}) == "key:\n  nested-key: value\n"



# Generated at 2022-06-22 14:04:27.764162
# Unit test for function comment
def test_comment():
    from jinja2 import Environment, FileSystemLoader
    from jinja2.exceptions import TemplateSyntaxError

    # Load the jinja2 templet
    jinja2_env = Environment(loader=FileSystemLoader('.'))

    # Test for error
    for text in [None, 1, 1.0, ['a', 'b']]:
        try:
            result = jinja2_env.from_string(
                '{{ %s | comment() }}' % text).render()
        except TemplateSyntaxError:
            pass
        else:
            raise AssertionError

    # Test for success

# Generated at 2022-06-22 14:04:39.885850
# Unit test for function regex_search
def test_regex_search():
    # Testing - `\\0`
    assert regex_search('example', r'ex\w+', '\\0') == 'example'
    # Testing - `\\g<NUM>`
    assert regex_search('example', r'ex\w+', '\\g<0>') == 'example'
    # Testing - `\\g<STR>`
    assert regex_search('example', r'ex(?P<word>\w+)', '\\g<word>') == 'ample'
    # Testing - `\\g<NUM>, \\g<STR>`
    assert regex_search('example', r'ex(?P<word>\w+)', '\\g<word>', '\\g<0>') == ['ample', 'example']
    # Testing - `\\1`

# Generated at 2022-06-22 14:04:47.774010
# Unit test for function get_hash
def test_get_hash():
    assert(get_hash('foo', 'md5') == 'acbd18db4cc2f85cedef654fccc4a4d8')
    assert(get_hash('foo', 'sha1') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
    assert(get_hash('foo', 'sha256') == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae')

# Generated at 2022-06-22 14:05:08.444260
# Unit test for function subelements
def test_subelements():
    '''Verify the subelements function'''
    import json
    import os
    import unittest
    import tempfile

    _ = tempfile.NamedTemporaryFile

    class TestSubelements(unittest.TestCase):
        '''Validate the subelement function'''
        def setUp(self):
            '''Create a json file with sample data'''
            self.test_data = {'foo': {'bar': {'bing': [1, 2, 3]}}}

            # create a temp test file
            self.test_fh = _(delete=False)

            # write test data to temp file
            self.test_fh.write(json.dumps(self.test_data).encode('utf-8'))
            self.test_fh.flush()


# Generated at 2022-06-22 14:05:16.894269
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'abc(\d+)') == 'abc123'
    assert regex_search('abc123', r'abc(\d+)', '\\g<1>') == '123'
    assert regex_search('abc123', r'abc(\d+)', '\\g<1>', '\\g<0>') == ['123', 'abc123']
    assert regex_search('abc123', r'abc(\d+)', '\\1') == '123'
    assert regex_search('abc123', r'abc(\d+)', '\\1', '\\0') == ['123', 'abc123']
    assert regex_search('abc123', r'abc(\d+)', '\\1', '\\0', '\\g<1>') == ['123', 'abc123', '123']

# Generated at 2022-06-22 14:05:20.614175
# Unit test for function rand
def test_rand():
    assert rand(5, 0, 1) == 1
    assert rand(10, step=2) in [0,2,4,6,8]
    assert rand([1,2,3]) in [1,2,3]
    assert rand([1,2,3], seed=1) in [1,2,3]



# Generated at 2022-06-22 14:05:29.439890
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcabcabc', 'abc', '\\g<0>') == 'abc'
    assert regex_search('abcabcabc', 'abc', '\\1') == 'abc'
    assert regex_search('abcabcabc', 'a(b)c', '\\g<1>') == 'b'
    assert regex_search('abcabcabc', 'a(b)c', '\\1') == 'b'
    assert regex_search('abcabcabc', 'a(b)c', '\\g<0>', '\\1') == ['abc', 'b']
    assert regex_search('abcabcabc', 'a(b)c', '\\g<0>', '\\2') == ['abc', None]
    assert regex_search('aaaaaaaa', 'a{2}', '\\g<0>') == 'aa'

# Generated at 2022-06-22 14:05:40.236166
# Unit test for function regex_search
def test_regex_search():
    ''' Test the regex_search function '''
    assert regex_search('bar', r'[a-z]+') == 'bar'
    assert regex_search(123, r'[a-z]+') is None
    assert regex_search('barbaz-barbaz', r'[a-z]+', '\\1') == 'baz'
    assert regex_search('barbaz-barbaz', r'[a-z]+', '\\g<1>') == 'baz'
    assert regex_search('barbaz-barbaz', r'[a-z]+', '\\1', '\\g<1>') == ['baz', 'baz']
    assert regex_search('barbaz-barbaz', r'[a-z]+', '\\2') == ''

# Generated at 2022-06-22 14:05:50.990722
# Unit test for function do_groupby
def test_do_groupby():
    assert do_groupby(range(2), 'even') == [(True, [0]), (False, [1])]

# Generated at 2022-06-22 14:05:56.652667
# Unit test for function regex_search
def test_regex_search():
    value = "foo bar"
    regex = r"\w{3}"
    assert ['foo'] == regex_search(value, regex, '\\g<0>')
    assert ['bar'] == regex_search(value, regex, '\\1')
    assert ['foo', 'bar'] == regex_search(value, regex, '\\g<0>', '\\1')



# Generated at 2022-06-22 14:06:08.571514
# Unit test for function flatten
def test_flatten():
    assert flatten(['foo', ['bar']]) == ['foo', 'bar']
    assert flatten(['foo', ['bar', ['baz']]]) == ['foo', 'bar', 'baz']
    assert flatten(['foo', ['bar', [['baz']]]]) == ['foo', 'bar', ['baz']]
    assert flatten(['foo', ['bar', [['baz']]]], levels=1) == ['foo', 'bar', ['baz']]
    assert flatten(['foo', ['bar', [['baz']]]], levels=2) == ['foo', 'bar', 'baz']
    assert flatten([['foo']], skip_nulls=False) == [None, 'foo']
    assert flatten([['foo']], skip_nulls=True) == ['foo']




# Generated at 2022-06-22 14:06:21.075565
# Unit test for function to_bool
def test_to_bool():
    # Test with a bool
    assert to_bool(True) is True
    assert to_bool(False) is False
    # Test with integers
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(42) is True
    assert to_bool(-1) is True
    # Test with strings
    assert to_bool('yes') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool('on') is True
    assert to_bool('no') is False
    assert to_bool('0') is False
    assert to_bool('false') is False
    assert to_bool('off') is False
    # Test with whitespace
    assert to_bool(' yes') is True

# Generated at 2022-06-22 14:06:32.111924
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    from jinja2.utils import Cycler, Namespace
    env = jinja2.Environment()
    env.filters['groupby'] = do_groupby
    # create cycler object
    obj = Cycler(Namespace(foo=1), Namespace(foo=2), Namespace(foo=1))
    # test with attribute name
    outer = env.from_string('{% for foo, bar in seq|groupby("foo") %}'
                            '{{ foo }}: {% for item in bar %}{{ item.foo }}'
                            '{% endfor %}{% endfor %}')
    assert outer.render(seq=obj) == '1: 1 1 2: 2'
    # test with attribute lookup

# Generated at 2022-06-22 14:06:54.358640
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(r"foo", r"(f)(o{2})") == "foo"
    assert regex_search(r"foo", r"(f)(o{2})", '\g<1>') == "f"
    assert regex_search(r"foo", r"(f)(o{2})", '\g<2>') == "oo"
    assert regex_search(r"foo", r"(f)(o{2})", '\g<1>', '\g<2>') == ["f", "oo"]
    assert regex_search(r"foo", r"(f)(o{2})", '\1') == "f"
    assert regex_search(r"foo", r"(f)(o{2})", '\2') == "oo"

# Generated at 2022-06-22 14:07:01.724447
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(
        {'foo': 'bar',
            'baz': ['one',
                    {'fish': 'two',
                     'cats': 'three'}
                    ]
        },
        default_flow_style=False
    ) == dedent("""
    foo: bar
    baz:
    - one
    - fish: two
      cats: three
    """).strip()



# Generated at 2022-06-22 14:07:04.215977
# Unit test for function to_yaml
def test_to_yaml():
    five = to_yaml(5)
    assert five == '5\n'


# Generated at 2022-06-22 14:07:13.490476
# Unit test for function flatten
def test_flatten():
    assert flatten([[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
    assert flatten([[[1, 2, 3]]]) == [[1, 2, 3]]
    assert flatten([[[[1, 2, 3]]]]) == [[[1, 2, 3]]]
    assert flatten([[[1, None, 3]]]) == [[1, None, 3]]
    assert flatten([[[1, 2, 3]]], skip_nulls=False) == [[1, 2, 3]]
    assert flatten([[[None, 2, 3]]], skip_nulls=False) == [[None, 2, 3]]



# Generated at 2022-06-22 14:07:17.764906
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', 1234567890) == "2009-02-13 23:31:30"



# Generated at 2022-06-22 14:07:26.543142
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('test', 't', 'd') == 'desd'
    assert regex_replace('test', 't', 'd', ignorecase=True) == 'desd'
    assert regex_replace('test', 'T', 'd') == 'test'
    assert regex_replace('test', 'T', 'd', ignorecase=True) == 'desd'
    assert regex_replace('test', 'T', 'd', multiline=True) == 'desd'
    assert regex_replace('teTstT', 'T', 'd', multiline=True) == 'dedsdT'
    assert regex_replace('teTstT', 'T', 'd', ignorecase=True, multiline=True) == 'desd'

# Generated at 2022-06-22 14:07:31.198727
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo/bar', 'python') == r'foo\/bar'
    assert regex_escape(r'foo/bar', 'posix_basic') == r'foo\/bar'
    assert regex_escape(r'foo[bar', 'python') == r'foo\[bar'
    assert regex_escape(r'foo[bar', 'posix_basic') == r'foo\[bar'
    assert regex_escape(r'foo.bar', 'python') == r'foo\.bar'
    assert regex_escape(r'foo.bar', 'posix_basic') == r'foo\.bar'
    assert regex_escape(r'foo$', 'python') == r'foo\$'



# Generated at 2022-06-22 14:07:42.761174
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    e = JinjaEnvironment(extensions=['jinja2.ext.do'])
    v = [{'a': 'a1', 'b': 'b1', 'c': 'c1'}, {'a': 'a1', 'b': 'b2', 'c': 'c2'}, {'a': 'a2', 'b': 'b3', 'c': 'c3'}, {'a': 'a2', 'b': 'b4', 'c': 'c4'}]
    res = e.from_string('''{%- for group in v|groupby('a') %}[{{ group.grouper }}, {{ group.list|list }}]{% endfor %}''').render(v=v, do_groupby=do_groupby)

# Generated at 2022-06-22 14:07:48.361007
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%dT%H:%M:%S') == time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime())
    assert strftime('%Y-%m-%d %H:%M:%S', 1449840000) == '2015-12-10 00:00:00'



# Generated at 2022-06-22 14:07:50.882727
# Unit test for function do_groupby
def test_do_groupby():
    assert do_groupby([1, 2, 3, 4, 5], 'odd') == [(True, [1, 3, 5]), (False, [2, 4])]
    assert do_groupby([], 'odd') == []



# Generated at 2022-06-22 14:08:02.142902
# Unit test for function regex_search
def test_regex_search():
    text = '''Hello,
world'''
    expected = ['Hello,', 'world']
    assert regex_search(text, r'(.+?)(?:\n|$)', r'\g<1>', r'\g<1>') == expected

# Generated at 2022-06-22 14:08:14.530763
# Unit test for function regex_escape
def test_regex_escape():
    v = regex_escape(r"https://www.example.com/?foo=bar&baz=qux")
    a = 'https\\:\\/\\/www.example.com\\/\\?foo\\=bar\\&baz\\=qux'
    assert v == a

    v = regex_escape(r"https://www.example.com/?foo=bar&baz=qux", 'posix_basic')
    a = 'https\\\\:\\\\/\\\\/www\\.example\\.com\\\\/\\\\?foo\\\\=bar\\\\&baz\\\\=qux'
    assert v == a

    try:
        regex_escape(r"http://www.example.com", 'foobar')
        assert False == True
    except AnsibleFilterError as e:
        assert str(e) == 'Invalid regex type (foobar)'

# Generated at 2022-06-22 14:08:25.079410
# Unit test for function regex_escape
def test_regex_escape():
    # type: () -> None
    assert regex_escape('a*b') == 'a\\*b'
    assert regex_escape('a*b', 'posix_basic') == 'a\\*b'

    assert regex_escape('a$b') == 'a\\$b'
    assert regex_escape('a$b', 'posix_basic') == 'a\\$b'

    assert regex_escape('a.b') == 'a\\.b'
    assert regex_escape('a.b', 'posix_basic') == 'a\\.b'

    assert regex_escape('a+b') == 'a\\+b'
    assert regex_escape('a+b', 'posix_basic') == 'a\\+b'

    assert regex_escape('a?b') == 'a\\?b'
    assert regex_escape

# Generated at 2022-06-22 14:08:37.599493
# Unit test for function flatten
def test_flatten():

    # generate a list of lists
    a = range(1, 11)
    b = [x + 10 for x in range(1, 11)]
    c = [x + 20 for x in range(1, 11)]
    mylist = [a, b, c]

    # test for all levels
    result = flatten(mylist)
    assert result == a + b + c

    # test for one level
    result = flatten(mylist, levels=1)
    assert result == a + b + c

    # test for zero levels
    result = flatten(mylist, levels=0)
    assert result == mylist

    # test for two levels
    result = flatten(mylist, levels=2)
    assert result == a + b + c

    # now generate a list of lists of lists

# Generated at 2022-06-22 14:08:50.954338
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.filter.core import FilterModule
    import jinja2
    from jinja2.exceptions import UndefinedError
    from jinja2.runtime import Context, Undefined
    import collections

    # Mock out class Templar
    class MockTemplar(Templar):
        def __init__(self):
            pass

        def fail_json(self, msg):
            raise AnsibleFilterError(to_text(msg))


# Generated at 2022-06-22 14:08:54.661715
# Unit test for function to_yaml
def test_to_yaml():
    INPUT = {'a': {'b': {'c': 'd'}}}
    OUTPUT = '''\
a:
  b:
    c: d
'''
    assert OUTPUT == to_yaml(INPUT)



# Generated at 2022-06-22 14:09:07.052357
# Unit test for function do_groupby
def test_do_groupby():
    """
    Test function do_groupby.
    """
    # Import needed to test the function
    from jinja2.runtime import Context
    from jinja2.runtime import Undefined

    # Set args for function
    environment = Context({})

    # Test with no morekey and no attributes
    value = [{'name':'first','key1':'value1'},
             {'name':'first','key1':'value2'},
             {'name':'second','key1':'value3'}]

    attribute = ['name']

    try:
        grouped = do_groupby(environment, value, attribute)
    except Exception as e:
        print("Got exception from do_groupby: "
              "value='%s' attribute='%s' exception='%s'" % (value,attribute,e))


# Generated at 2022-06-22 14:09:20.077127
# Unit test for function regex_search
def test_regex_search():
    '''
    Test regex_search
    '''

    test_value = '''
   {
        "name": "Karun",
        "job": "Engineer",
        "age": 25,
        "address": {
                   "city": "Bangalore",
                   "state": "Karnataka",
                   "pincode": 560076
                  }
    }
    '''

    assert regex_search(test_value, '"name": "(.*)"') == '"name": "Karun"'
    assert regex_search(test_value, '"name": "(.*)"', '\\g<1>') == ['Karun']
    assert regex_search(test_value, '"state": "(.*)"', '\\g<1>') == ['Karnataka']

# Generated at 2022-06-22 14:09:29.684458
# Unit test for function do_groupby
def test_do_groupby():
    # The following code is based on test code from jinja2 2.9.4
    # The code is covered under BSD-3-Clause license
    # Copyright (c) 2017 by the Jinja Team.
    from jinja2 import environmentfilter, StrictUndefined, UndefinedError

    class Person(object):
        def __init__(self, id, name):
            self.id = id
            self.name = name

    class Company(object):
        def __init__(self, id, name):
            self.id = id
            self.name = name

    company_data = [Company(1, 'Gnucoop'), Company(2, 'Ansible')]

# Generated at 2022-06-22 14:09:42.091758
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('world', r'world', group='\\g<0>') == 'world'
    assert regex_search('World', r'world', group=['\\g<0>', '\\g<0>'], ignorecase=True) == ['World', 'World']
    assert regex_search('Hello world', r'world', group='\\g<0>') is None
    assert regex_search('Hello\nworld', r'world', group='\\g<0>', multiline=True) == 'world'
    assert regex_search('Hello\nworld', r'world', group='\\g<0>') is None
    assert regex_search('Hello\nworld', r'world', group=['\\g<0>', '\\g<0>'], multiline=True) == ['world', 'world']

# Generated at 2022-06-22 14:09:53.727983
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == '[1, 2, 3]\n'
    assert to_yaml({'a': 2, 'b': 3}) == '{a: 2, b: 3}\n'
    assert to_yaml({'a': 2, 'b': 'value b'}) == "a: 2\nb: 'value b'\n"
    assert to_yaml(['some', {'complex': 'structure'}], default_flow_style=False) == '- some\n- complex: structure\n'
    assert to_yaml(['some', {'complex': 'structure'}], default_flow_style=True) == '[some, {complex: structure}]\n'

# Generated at 2022-06-22 14:09:59.740921
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('a1', r'\d') == '1'
    assert regex_search('a1', r'\d', '\\1') == ['1', 1]
    assert regex_search('a1', r'\d', '\\g<1>') == ['1']


# Generated at 2022-06-22 14:10:10.664623
# Unit test for function extract
def test_extract():
    assert extract("", {}, {'foo': {'bar': 'baz'}}) == {}
    assert extract("foo", {'foo': 'bar'}, {'foo': {'bar': 'baz'}}) == 'bar'
    assert extract("foo", {'foo': 'bar', 'bar': 'baz'}, {'foo': {'bar': 'baz'}}) == 'bar'
    assert extract("foo", {'foo': 'bar'}, {'foo': {'bar': 'baz'}}) == 'bar'
    assert extract("foo.bar", {'foo': {'bar': 'baz'}}) == 'baz'
    assert extract("foo.bar", {'foo': {'bar': ['bat', 'baz']}}) == ['bat', 'baz']

# Generated at 2022-06-22 14:10:12.887015
# Unit test for function extract
def test_extract():
    item = dict(
        a=dict(
            b=dict(
                c=42
            )
        )
    )
    value = extract('c', item, ['a', 'b'])
    assert value == 42



# Generated at 2022-06-22 14:10:24.792691
# Unit test for function regex_search
def test_regex_search():
    original = 'AAAABBBB'
    modified = 'AAAABBBB'
    assert regex_search(original, 'A') == 'A'
    assert regex_search(original, 'BBBB') == 'BBBB'
    assert regex_search(original, 'C') is None
    assert regex_search(original, 'A', '\\1') == 'A'
    assert regex_search(original, 'BBBB', '\\g<0>') == 'BBBB'
    assert regex_search(original, r'(BB)+', '\\g<0>') == 'BBBB'
    assert regex_search(original, 'B', '\\g<0>', '\\1') == 'B'
    assert regex_search(original, 'BBBB', '\\g<0>', '\\1') == 'BB'

# Generated at 2022-06-22 14:10:26.531414
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', 0) == '1970'

# Generated at 2022-06-22 14:10:37.332937
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    dict_data = {
        'persons': [
            {'name': 'joe',
                'phones': {
                    'home': '123-123-1234',
                    'work': '123-123-1231',
                    }},
            {'name': 'jane',
                'phones': {
                    'home': '123-123-1235',
                    'work': '123-123-1232',
                    }},
            ],
        }
    assert to_nice_yaml(dict_data) == '''persons:
- name: joe
  phones:
    home: 123-123-1234
    work: 123-123-1231
- name: jane
  phones:
    home: 123-123-1235
    work: 123-123-1232
'''



# Generated at 2022-06-22 14:10:50.436731
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo", ".*") == "foo"
    assert regex_search("foo", r".*") == "foo"
    assert regex_search("foo", r".*", r'\g<0>') == "foo"
    assert regex_search("foo", r"(.*)", r'\g<0>') == "foo"
    assert regex_search("foo", r"(.*)", r'\g<1>') == "foo"
    assert regex_search("foo", r"(?P<bar>.*)", r'\g<bar>') == "foo"
    assert regex_search("foo", r"(?P<bar>.*)", r'\g<bar>', ignorecase=True) == "foo"

# Generated at 2022-06-22 14:10:57.300022
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(u'abc', u'a') == u'a'
    assert regex_search(u'abc', u'b') == u'b'
    assert regex_search(u'abc', u'c') == u'c'
    assert regex_search(u'foo123bar', u'\d{3}') == u'123'
    assert regex_search(u'foo123bar', u'\d{4}') is None
    assert regex_search(u'abcdabcdabcd', u'abcd', '\\g<1>') == u'abcd'
    assert regex_search(u'abcdabcdabcd', u'(a)bcd', '\\g<1>') == u'a'

# Generated at 2022-06-22 14:11:04.549407
# Unit test for function comment
def test_comment():
    assert (comment('text')
            == '# text\n')
    assert (comment('text', newline='', prefix='// ')
            == '// text')
    assert (comment('text', newline='', prefix=' ')
            == ' text')
    assert (comment('text', newline='', prefix='// ')
            == '// text')
    assert (comment('text', newline='', decoration='// ')
            == '// text')
    assert (comment('text', newline='', decoration=' ', postfix='// ')
            == ' text// ')
    assert (comment('text', newline='', decoration=' ', postfix='// ', prefix='// ')
            == '// text// ')

# Generated at 2022-06-22 14:11:18.972774
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([{u'key': {u'key2': u'value2'}, u'key3': u'value3'}, {u'key4': {u'key5': {u'key6': u'value6'}}}]) == u"\n".join(["- key:", "    key2: value2", "  key3: value3", "- key4:", "    key5:", "      key6: value6"])


# Generated at 2022-06-22 14:11:23.183366
# Unit test for function extract
def test_extract():
    from jinja2 import DictLoader, Environment
