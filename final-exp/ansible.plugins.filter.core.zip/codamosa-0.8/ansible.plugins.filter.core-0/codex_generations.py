

# Generated at 2022-06-22 14:01:59.217832
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('test') == 'test'
    assert regex_escape('[test]') == '\\[test\\]'
    assert regex_escape('http://example.com/path/') == 'http://example\\.com/path/'



# Generated at 2022-06-22 14:02:10.876968
# Unit test for function to_yaml
def test_to_yaml():
    from ansible.module_utils.common.collections import ImmutableDict
    assert to_yaml({}) == u'{}\n'
    assert to_yaml({'a': [1, 2, 3]}) == u'{a: [1, 2, 3]}\n'
    assert to_yaml({'a': [1, 2, 3], 'b': {'x': 5}}, default_flow_style=True) == u'{a: [1, 2, 3], b: {x: 5}}\n'
    assert to_yaml({'a': [1, 2, 3], 'b': {'x': 5}}, default_flow_style=False) == u'''a:
- 1
- 2
- 3
b:
  x: 5
'''

# Generated at 2022-06-22 14:02:18.831953
# Unit test for function do_groupby
def test_do_groupby():
    """Test do_groupby function
    """
    from ansible.compat.tests import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class TestModule(unittest.TestCase):
        def test_do_groupby(self):
            variable_manager = VariableManager()
            loader = DataLoader()
            variable_manager.set_loader(loader)

# Generated at 2022-06-22 14:02:31.073824
# Unit test for function combine
def test_combine():
    import collections

    # It should be able to merge dicts with complex structures
    dict1 = dict(a=dict(b=1))
    dict2 = dict(a=dict(c=2))
    assert combine(dict1, dict2) == dict(a=dict(b=1, c=2))

    # It should be able to merge lists of dicts
    dict3 = dict(a=dict(b=[1]))
    dict4 = dict(a=dict(b=[2]))
    assert combine([dict3, dict4]) == dict(a=dict(b=[1, 2]))

    # It should be able to merge lists of lists of dicts
    dict5 = dict(a=dict(b=[1]))
    dict6 = dict(a=dict(b=[2]))

# Generated at 2022-06-22 14:02:35.876612
# Unit test for function flatten
def test_flatten():

    # Test normal cases
    assert [1, 2, 3, 4, 5] == flatten([1, [2, 3], [[4], 5]])
    assert [1, 2, 3, 4, 5] == flatten([1, 2, 3, 4, 5])
    assert [1] == flatten([[1]])
    assert [1, 2, 3, 4] == flatten([[1, 2], 3, [4]])
    assert [1, 2, 3, 4] == flatten([[1], 2, [3, 4]])
    assert [1, 2, 3, 4] == flatten([[1, [2, 3], 4]])
    assert [1, 2, 3, 4] == flatten([1, [[2], [3], 4]])

# Generated at 2022-06-22 14:02:45.842680
# Unit test for function regex_search
def test_regex_search():
    result = regex_search(value='Hello world', regex='Hello')
    assert result == 'Hello'
    result = regex_search(value='Hello world', regex='Hello', ignorecase=True)
    assert result == None
    result = regex_search(value='Hello world', regex='Hello', ignorecase=True, multiline=True)
    assert result == 'Hello'

# Generated at 2022-06-22 14:02:54.895861
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', 'es') == 'es'
    assert regex_search('test', 'es', '\\g<1>') is None
    assert regex_search('test', 'es', '\\1') is None
    assert regex_search('123456', '(\d{3})(\d{3})') == ['123', '456']
    assert regex_search('123456', '(?P<three>\d{3})(?P<four>\d{3})', '\\g<four>\\g<three>') == ['456123']


# Generated at 2022-06-22 14:03:04.458889
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') ==   [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'bogus') == []
    assert subelements(obj, 'bogus', True) == []
    assert subelements(obj, 'groups.0') == []

# Generated at 2022-06-22 14:03:12.167829
# Unit test for function extract
def test_extract():
    input_list_1 = list()
    input_list_1.append({'a': 'A', 'b': 'B'})
    input_list_1.append({'c': 'C', 'd': 'D'})
    input_list_1.append({'e': 'E', 'f': 'F'})
    input_list_2 = list()
    input_list_2.append({'a': 'A', 'b': 'B'})
    input_list_2.append({'c': 'C', 'd': 'D'})
    input_list_2.append({'e': 'E', 'f': 'F'})
    input_list_3 = list()
    input_list_3.append({'a': 'A', 'b': 'B'})
    input_list_3.append

# Generated at 2022-06-22 14:03:23.024784
# Unit test for function regex_search
def test_regex_search():
    data = dict()
    data['file'] = '/Users/user/test.txt'
    data['url'] = 'http://10.0.1.2:8080/aaa/bbb'
    data['user'] = 'user1'
    data['password'] = 'password1'
    data['edit_type'] = 'edit'

    # Get file name from file path
    value = regex_search(data['file'], r'([^/]+)$', "\\1")
    assert value == 'test.txt'

    # Get hostname from url
    value = regex_search(data['url'], r'^(https?://)([^:/]+)', "\\2")
    assert value == '10.0.1.2'

    # Get port from url

# Generated at 2022-06-22 14:03:44.008594
# Unit test for function fileglob
def test_fileglob():
    files = [to_text(f, errors='surrogate_or_strict') for f in ['foo.txt', 'bar.py', 'baz.pyc']]
    for f in files:
        open(f, 'w+').close()
    assert files == fileglob('*.txt') == fileglob('*.[Tt][Xx][Tt]')
    assert sorted(files) == sorted(fileglob('*.[Pp][Yy]'))
    assert files == fileglob('*.[Tt]*')
    assert [] == fileglob('*.[Jj][Pp][Gg]')
    assert [] == fileglob('*.[Jj][Pp][Gg]')



# Generated at 2022-06-22 14:03:46.613032
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == u'foo'
    assert regex_escape('foo.bar[]\\') == u'foo\\.bar\\[\\]\\\\'



# Generated at 2022-06-22 14:03:55.052023
# Unit test for function mandatory
def test_mandatory():
    import os
    import sys
    # FIXME: This should be using the jinja2 environment, so we can get the right 'undefined' type
    # Without that we can't really do much more
    undefined = AnsibleUndefined(u'ansible.vars.unsafe_proxy.AnsibleUnsafeText object')

    # No arguments
    try:
        mandatory()
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    # Undefined argument
    try:
        mandatory(undefined)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    # Defined argument
    assert mandatory('A') == 'A'

    # Error message with defined argument

# Generated at 2022-06-22 14:04:05.486561
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(1, "it's ok") == 1
    msg = ''
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        msg = to_text(e)
    assert msg != ''
    msg = ''
    try:
        mandatory(Undefined(), msg="baz is undefined")
    except AnsibleFilterError as e:
        msg = to_text(e)
    assert msg != ''
    msg = ''
    try:
        mandatory(Undefined(name='baz'), msg="baz is undefined")
    except AnsibleFilterError as e:
        msg = to_text(e)
    assert msg != ''



# Generated at 2022-06-22 14:04:17.796621
# Unit test for function extract
def test_extract():
    env = MockEnvironment()
    test_data = {'a': {'b': {'c': 'd'}}}
    assert extract(env, 'a', test_data) == {'b': {'c': 'd'}}
    assert extract(env, 'b', test_data['a']) == {'c': 'd'}
    assert extract(env, 'c', test_data['a']['b']) == 'd'
    assert extract(env, 'c', test_data['a']['b'], 'd') is None
    assert extract(env, 'c', test_data['a']['b'], ['e']) is None
    assert extract(env, 'a', test_data, 'b') == {'c': 'd'}

# Generated at 2022-06-22 14:04:20.633476
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("$ANSIBLE_FOO", "ANSIBLE_(.*)", r"\1bar") == '_FOObar'
    assert regex_replace("$ANSIBLE_FOO", "ANSIBLE_(.*)", r"\1bar", ignorecase=True) == '_FOObar'
    assert regex_replace("$ANSIBLE_FOO", "ANSIBLE_(.*)", r"\1bar", ignorecase=True, multiline=True) == '_FOObar'


# Generated at 2022-06-22 14:04:33.438584
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('hello') == 'hello'
    assert regex_escape('hello.world') == 'hello\\.world'
    assert regex_escape('hello.world', re_type='python') == 'hello\\.world'
    assert regex_escape('hello.world', re_type='posix_basic') == 'hello\\.world'
    assert regex_escape('hello.^world') == 'hello\\.\\^world'
    assert regex_escape('hello.^world', re_type='posix_basic') == 'hello\\.\\^world'
    assert regex_escape('hello.^$world*') == 'hello\\.\\^\\$world\\*'
    assert regex_escape('hello.^$world*', re_type='posix_basic') == 'hello\\.\\^\\$world\\*'
    assert regex

# Generated at 2022-06-22 14:04:44.496904
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment

    data = [{'name': 'joe', 'group': 'one'},
            {'name': 'bob', 'group': 'two'},
            {'name': 'sam', 'group': 'one'},
            {'name': 'ted', 'group': 'three'},
            {'name': 'luke', 'group': 'one'},
            {'name': 'will', 'group': 'two'},
            ]

    # expected from the `do_groupby` function from jinja2<2.9.0

# Generated at 2022-06-22 14:04:51.321668
# Unit test for function to_yaml
def test_to_yaml():
    string = "test"
    assert to_yaml(string) == "test\n"
    list = [1, 'a', {'foo': 'baz'}]
    assert to_yaml(list) == "- 1\n- a\n- foo: baz\n"
    dict = {'foo': 'bar', 'baz': 'qux'}
    assert to_yaml(dict) == "baz: qux\nfoo: bar\n"


# Generated at 2022-06-22 14:04:55.876349
# Unit test for function comment
def test_comment():
    assert comment('This is a test.') == '# This is a test.'
    assert comment('A: This is a test.', prefix='A: ') == '# A: This is a test.'
    assert comment('This is a test.\nAnd here is another line.') == '# This is a test.\n# And here is another line.'
    assert comment('This is a test.\nAnd here is another line.', decoration='> ') == '# > This is a test.\n# > And here is another line.'
    assert comment('This is a test.', decoration='// ') == '// This is a test.'
    assert comment(
        """This is a test.
And here is another line.""",
        decoration='// ') == """// This is a test.
// And here is another line."""
    assert comment

# Generated at 2022-06-22 14:05:10.758905
# Unit test for function regex_escape
def test_regex_escape():
    # Python regular expression
    assert regex_escape('(foo)') == '\\(foo\\)'
    assert regex_escape('foo') == 'foo'
    assert regex_escape('(foo') == '\\(foo'
    # POSIX basic regular expression
    assert regex_escape('(foo)', re_type='posix_basic') == '\\(foo\\)'
    assert regex_escape('foo', re_type='posix_basic') == 'foo'
    assert regex_escape('(foo', re_type='posix_basic') == '\\(foo'
    assert regex_escape('(bar|foo)', re_type='posix_basic') == '\\(bar\\|foo\\)'
    assert regex_escape('bar|foo', re_type='posix_basic') == 'bar\\|foo'
    assert regex_escape

# Generated at 2022-06-22 14:05:17.599576
# Unit test for function get_hash
def test_get_hash():
    data = 'The quick brown fox jumped over the lazy dog'
    hashtype = 'sha1'
    output = '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert get_hash(data, hashtype) == output



# Generated at 2022-06-22 14:05:27.509248
# Unit test for function do_groupby
def test_do_groupby():
    ''' Ansible jinja2 do_groupby() filter test '''
    import ansible.template.j2.tests
    from ansible.template.j2.tests import AnsibleJ2Vars

    my_vars = AnsibleJ2Vars({
        'foo': [{
            'host': 'host1',
            'foo_attr': 'bar',
        }, {
            'host': 'host2',
            'foo_attr': 'bar',
        }],
    })

    env = ansible.template.j2.environment.Environment(
        loader=ansible.template.j2.DictLoader({}),
        undefined=ansible.template.j2.Undefined,
        extensions=[ansible.template.j2.do_groupby],
    )

# Generated at 2022-06-22 14:05:39.240625
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader
    from jinja2.environment import Environment
    from collections import namedtuple

    env = Environment(loader=DictLoader({
        'index.j2': '''
            {% from _ansible_collections.ansible.community.plugins.filters import do_groupby %}
            {% for group in dicts|do_groupby('key') %}
                {{ group.grouper }}: {{ group.list|map('attribute')|list }}
            {% endfor %}
        '''
    }))

# Generated at 2022-06-22 14:05:50.068941
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': True, 'b': 'foo', 'c': 5}) == 'a: true\nb: foo\nc: 5\n'
    assert to_yaml({'a': True, 'b': 'foo', 'c': 5}, default_flow_style=False) == 'a: true\nb: foo\nc: 5\n'
    assert to_yaml({'a': True, 'b': 'foo', 'c': 5}, default_flow_style=True) == '{a: true, b: foo, c: 5}\n'
    assert to_yaml({'a': True, 'b': 'foo', 'c': 5}, default_flow_style=None) == 'a: true\nb: foo\nc: 5\n'


# Generated at 2022-06-22 14:05:54.534460
# Unit test for function comment
def test_comment():
    assert (comment(
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        style='erlang',
        decoration='%% ') ==
            '%% Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n')

    assert (comment(
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        style='c',
        decoration='* ') ==
            '// * Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n')


# Generated at 2022-06-22 14:06:02.474291
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    a = ['test']
    assert to_nice_yaml(a) == '- test\n'
    assert to_nice_yaml(a, indent=0) == '- test\n'
    assert to_nice_yaml(a, indent=2) == '-  test\n'
    assert to_nice_yaml(a, indent='  ') == '-  test\n'
    assert to_nice_yaml(a, default_flow_style=True) == '- test\n'
    assert to_nice_yaml(a, indent='  ', default_flow_style=True) == '- test\n'


# Generated at 2022-06-22 14:06:12.322763
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('my-search', r'\w+-(\w+)') == ('search',)
    assert regex_search('my-search', r'(\S+)-(\S+)') == ('my-search',)
    assert regex_search('my-search', r'\w+-(\w+)', '\\g<1>') == ('search',)
    assert regex_search('my-search', r'\w+-(\w+)', '\\1') == ('search',)
    assert regex_search('my-search', r'(\S+)-(\S+)', '\\g<1>') == ('my',)
    assert regex_search('my-search', r'(\S+)-(\S+)', '\\g<2>') == ('search',)

# Generated at 2022-06-22 14:06:23.626168
# Unit test for function regex_search
def test_regex_search():
    '''ansible.builtin.regex_search unit tests'''

    # This test case fails with the following message:
    #
    #      AssertionError: result is not None
    #
    #    assert result is not None
    #
    # This is happening because the regex expression is being treated as a string
    #   - it needs to be treated as a regex.
    '''
    pattern = "a(?P<first>\w+).*b(?P<second>\w+).*c(?P<third>\w+)"
    subject_string = "abc123"
    assert result == [None, "123", None]
    '''

    # Validate a successful match

# Generated at 2022-06-22 14:06:34.220967
# Unit test for function extract
def test_extract():
    assert extract(None, 'k2', {'k1': {'k2': 'v1'}}) == 'v1'
    assert extract(None, 'k2', {'k1': {'k2': 'v1'}}, morekeys='k1') == 'v1'
    assert extract(None, 'k2', {'k1': {'k2': 'v1'}}, morekeys=['k1']) == 'v1'

    assert extract(None, 'k2', {'k1': {'k2': 'v1'}}, morekeys='xxx') == ''
    assert extract(None, 'k2', {'k1': {'k2': 'v1'}}, morekeys=['xxx']) == ''


# Generated at 2022-06-22 14:06:44.062376
# Unit test for function flatten
def test_flatten():
    # Example from documentation
    assert flatten([1, 2, 3, [4, 5, [6, 7]], (8, 9, 10)], levels=3) == [1, 2, 3, 4, 5, 6, 7, (8, 9, 10)]
    # Example from documentation
    assert flatten([1, 2, 3, [4, 5, [6, 7]], (8, 9, 10)], levels=2) == [1, 2, 3, 4, 5, [6, 7], (8, 9, 10)]
    # Example from documentation
    assert flatten([1, 2, 3, [4, 5, [6, 7]], (8, 9, 10)], levels=1) == [1, 2, 3, 4, 5, [6, 7], 8, 9, 10]
    # Example from documentation


# Generated at 2022-06-22 14:06:52.956940
# Unit test for function get_hash
def test_get_hash():
    teststr = 'The quick brown fox jumps over the lazy dog'
    teststr_unicode = u'The quick brown fox jumps over the lazy dog'
    assert get_hash(teststr, 'md5') == '9e107d9d372bb6826bd81d3542a419d6'
    assert get_hash(teststr, 'sha1') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'
    assert get_hash(teststr_unicode, 'md5') == '9e107d9d372bb6826bd81d3542a419d6'
    assert get_hash(teststr_unicode, 'sha1') == '2fd4e1c67a2d28fced849ee1bb76e7391b93eb12'

# Generated at 2022-06-22 14:07:06.221062
# Unit test for function do_groupby
def test_do_groupby():
    import pytest
    def _check_groupby(environment, template, expected):
        assert environment.from_string(template).render(
            data=expected['data'],
            float=float,
            int=int,
            len=len,
            range=range,
            str=str,
            repr=str,
            type=str,
            zip=zip,
            do_groupby=do_groupby,
        ) == expected['result']

    # Test data

# Generated at 2022-06-22 14:07:13.350001
# Unit test for function do_groupby
def test_do_groupby():
    env = Environment(loader=DictLoader(dict()))
    do_groupby = env.filters.get('do_groupby')
    result = do_groupby([{"a": 1, "b": 1}, {"a": 1, "b": 2}, {"a": 2, "b": 1}], "a")
    assert result == [(1, [{"a": 1, "b": 1}, {"a": 1, "b": 2}]), (2, [{"a": 2, "b": 1}])], result



# Generated at 2022-06-22 14:07:23.916607
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("qwerty", "qwerty") == "qwerty"
    assert regex_search("qwerty", "^qwerty$") == "qwerty"
    assert regex_search("qwerty", "^qwerty", "\\g<1>") == "qwerty"
    assert regex_search("qwerty", "^qwerty", "\\1") == "qwerty"
    assert regex_search("qwerty", "^(qwerty)$", "\\g<1>") == "qwerty"
    assert regex_search("qwerty", "^(qwerty)$", "\\1") == "qwerty"
    assert regex_search("qwerty", "^(qwer)ty$", "\\g<1>") == "qwer"
   

# Generated at 2022-06-22 14:07:25.741581
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == u"{a: 'b'}\n"



# Generated at 2022-06-22 14:07:36.632656
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('', r'a', '\\g<0>') == ['a']
    assert regex_search('a', r'a') == 'a'
    assert regex_search('a', r'a', '\\1') == ['a']
    assert regex_search('a', r'a', '\\g<0>') == ['a']
    assert regex_search('a', r'(?P<name>a)', '\\g<name>') == ['a']
    assert regex_search('a', r'(?P<name>a)', '\\1') == ['a']
    assert regex_search('a', r'(?P<name>a)', '\\g<1>') == ['a']

# Generated at 2022-06-22 14:07:45.922924
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    # test with regular tuple
    t = (('a', 1), ('b', 2), ('c', 3))
    result = do_groupby(Environment(), t, 'key')
    assert isinstance(result, list)
    assert isinstance(result[0], tuple)
    assert result == t

    # test with namedtuple
    from collections import namedtuple
    nt = namedtuple('nt', 'key,value')
    nt_l = [nt('a', 1), nt('b', 2), nt('c', 3)]
    result = do_groupby(Environment(), nt_l, 'key')
    assert isinstance(result, list)
    assert isinstance(result[0], tuple)
    assert result == t

# Function for unit test to override the standard jin

# Generated at 2022-06-22 14:07:54.119123
# Unit test for function regex_escape
def test_regex_escape():
   assert regex_escape("a.$()*+?[^\\]{|}") == "a\\.\\$\\(\\)\\*\\+\\?\\[\\^\\\\\\]\\{\\|\\}"
   assert regex_escape("a.$()*+?[^\\]{|}", re_type='posix_basic') == "a\\.\\$\\(\\)\\*\\+\\?\\[\\^\\\\\\]\\{\\|\\}"
   # TODO: Implement regex_escape for POSIX extended regex
   # assert regex_escape("a.$()*+?[^\\]{|}", re_type='posix_extended') == "a\\.\\$\\(\\)\\*\\+\\?\\[\\^\\\\\\]\\{\\|\\}"


# Generated at 2022-06-22 14:08:04.766987
# Unit test for function do_groupby
def test_do_groupby():
    # Setup the test object
    test_object = [
        {'key1': 'value1A', 'key2': 'value2A'},
        {'key1': 'value1A', 'key2': 'value2B'},
        {'key1': 'value1B', 'key2': 'value2C'}
    ]
    # Run do_groupby on the test object
    test_groupby = do_groupby(None, test_object, 'key1')
    # Make sure we have all of the items (3)
    assert len(test_groupby) == 3
    # Make sure the first item is a tuple
    assert isinstance(test_groupby[0], tuple)
    # Make sure the type of the first tuple item is a dict

# Generated at 2022-06-22 14:08:22.801761
# Unit test for function regex_search
def test_regex_search():
    def test_regex_search(value, regex, *args, **kwargs):
        return regex_search(value, regex, *args, **kwargs)

    assert test_regex_search('Hello World', r'^(?P<greeting>\S+) (?P<audience>\S+)$',
                             '\\g<greeting>', '\\g<audience>') == ['Hello', 'World']
    assert test_regex_search('Hello World', r'^(?P<greeting>\S+) (?P<audience>\S+)$',
                             '\\g<audience>', '\\g<greeting>') == ['World', 'Hello']

# Generated at 2022-06-22 14:08:28.409269
# Unit test for function get_hash
def test_get_hash():
    if not checksum_s('hello+world', 'sha1') == '6a1a2c091e0da37e68bd3b4df4e23c0f912d75a1':
        raise AssertionError('Failed to get SHA1 hash')



# Generated at 2022-06-22 14:08:39.463441
# Unit test for function do_groupby
def test_do_groupby():
    """
    This function is an updated version of the filter. It has been tested to
    verify that it works properly with the current code base. If the code
    changes after this function is created, please update this function to
    match that code.
    """
    from jinja2.runtime import Undefined

    def _do_groupby(value, attribute):
        if isinstance(attribute, string_types):
            attribute = [attribute]
        # We can't use a dict + try/except because of unhashable objects.
        groups = {}

        def add_to_group(group, obj):
            if group is None:
                group = []
                groups[None] = group
            group.append(obj)

        for obj in value:
            groupdict = {}

# Generated at 2022-06-22 14:08:45.191929
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('Hello World', '^Hello World$') == 'Hello World'
    assert regex_search('Hello World', '^Hello (\\w+)$', '\\g<1>') == ['World']
    assert regex_search('Hello World', '^Hello (\\w+)$', '\\1') == ['World']



# Generated at 2022-06-22 14:08:55.888836
# Unit test for function regex_search
def test_regex_search():
    for expr, valid in [
      ('\\\\g<foo>', True),
      ('\\g<foo>', True),
      ('\\g<1>', True),
      ('\\\\1', True),
      ('\\1', True),
      ('\\g<foo', False),
      ('<foo>', False),
      ('foo', False),
    ]:
        try:
            regex_search('foo', 'oo', expr, multiline=False)
        except AnsibleFilterError:
            if valid:
                raise Exception('%s should have passed' % expr)
    assert regex_search('foo', 'oo', '\\g<0>') == 'oo'


# Generated at 2022-06-22 14:09:07.732655
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', '^.*?(\w+) (\w+)', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', '^.*?(\w+) (\w+)', '\\1', '\\2') == ['hello', 'world']
    assert regex_search('test1test2test3', 'test(\d)') == '1'
    assert regex_search('test1test2test3', 'test(\d)', '\\1') == '1'
    assert regex_search('test1test2test3', 'test(\d)', '\\g<1>') == '1'
    assert regex_search('test1test2test3', 'test(\d)', '\\g<1>', ignorecase=True) == '1'


# Generated at 2022-06-22 14:09:09.281255
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 14:09:16.896715
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("./test/fileglob/a") == ['./test/fileglob/a']
    assert fileglob("./test/fileglob/a.*") == ['./test/fileglob/a.1', './test/fileglob/a.2']
    assert fileglob(u"./test/fileglob/a") == ['./test/fileglob/a']



# Generated at 2022-06-22 14:09:25.566993
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('foobar', 'md5') == '3858f62230ac3c915f300c664312c63f'
    assert get_hash('foobar', 'sha1') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert get_hash('foobar', 'sha256') == '8f434346648f6b96df89dda901c5176b10a6d8387726e4febe6e846f6d5c9bf2'

# Generated at 2022-06-22 14:09:35.053423
# Unit test for function regex_search
def test_regex_search():
    cls = globals()['regex_search']
    def raiseFilterError(message): raise AnsibleFilterError(message)
    cls.__globals__['AnsibleFilterError'] = raiseFilterError

    regex = r'^a(?P<first>[b-d])c(?P<second>[b-d])(?P<third>[b-d])$'
    assert cls('abcddd', regex) == 'abcddd'
    assert cls('abcddd', regex, r'\g<second>', r'\g<first>\g<third>') == ['d', 'bdd']
    assert cls('aacddd', regex, r'\g<second>', r'\g<first>\g<third>') == ['c', 'add']

# Generated at 2022-06-22 14:09:51.818121
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template import JinjaEnvironment

    env = JinjaEnvironment(undefined=AnsibleJ2Undefined, extensions=['jinja2.ext.do'])
    env.filters.update({'groupby': do_groupby})
    test_data = [{'a': 1, 'name': 'one'},
                 {'a': 1, 'name': 'uno'},
                 {'a': 2, 'name': 'two'}]
    template = '{{ data | groupby("a") | map(attribute="g") | list }}'

# Generated at 2022-06-22 14:10:03.991883
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    env = jinja2.Environment()
    # jinja2.utils.do_groupby = do_groupby  # pylint: disable=no-member
    # pylint: disable=unused-variable,unused-argument
    def test(source, expected):
        """
        helper to test do_groupby filter
        """
        # pylint: disable=missing-docstring

        template = env.from_string(source)
        assert template.render() == expected

    test("{{ [1, 2, 3, 4, 5, 6]|groupby('even') }}", '\n{"false": [1, 3, 5], "true": [2, 4, 6]}\n')



# Generated at 2022-06-22 14:10:12.945856
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == '- 1\n- 2\n- 3\n'
    assert to_yaml({'k': 'v'}) == '{k: v}\n'
    assert to_yaml([1, 2, {'k': 'v'}]) == '- 1\n- 2\n- k: v\n'
    assert to_yaml({'k': {'k': 'v'}}) == '{k: {k: v}}\n'
    assert to_yaml({'v': None}) == "{'v': null}\n"
    assert to_yaml(None) == "null\n"
    assert to_yaml(dict(a=1, b=dict(b1=1, b2=dict(c=1)))) == '\n'.join

# Generated at 2022-06-22 14:10:21.110708
# Unit test for function fileglob
def test_fileglob():
    # Here we're testing that /usr/bin/python glob matches all files in /usr/bin
    # that start with "python"
    # Since this is a pretty common prefix in /usr/bin, we should expect this
    # to match the python binary, python-config, python2, python2.7, etc
    expected_count = len(fileglob('/usr/bin/python*'))
    assert expected_count > 5



# Generated at 2022-06-22 14:10:23.314898
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('hello world', 'md5') == '5eb63bbbe01eeed093cb22bb8f5acdc3'


# Generated at 2022-06-22 14:10:35.559906
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("hello world") == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert get_hash("hello world", hashtype='sha256') == 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'
    assert get_hash("hello world", hashtype='sha512') == '309ecc489c12d6eb4cc40f50c902f2b4d0ed77ee511a7c7a9bcd3ca86d4cd86f989dd35bc5ff499670da34255b45b0cfd830e81f605dcf7dc5542e93ae9cd76f'



# Generated at 2022-06-22 14:10:42.774016
# Unit test for function do_groupby
def test_do_groupby():
    d = dict(a=1, b=1, c=2, d=2)
    assert do_groupby(d, 'b') == [(1, [('a', 1), ('b', 1)])]
    assert do_groupby(d, 'c') == [(1, [('a', 1), ('b', 1)]), (2, [('c', 2), ('d', 2)])]


# Generated at 2022-06-22 14:10:56.649882
# Unit test for function randomize_list
def test_randomize_list():
    sample_word_list = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']
    shuffled_list = randomize_list(sample_word_list, seed=10)
    assert shuffled_list == ['eight', 'five', 'one', 'three', 'six', 'four', 'nine', 'ten', 'two', 'seven']
    # No seed given. Function call will return a different value every time
    shuffled_list = randomize_list(sample_word_list)

_password_chars = ("abcdefghijklmnopqrstuvwxyz"
                   "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                   "0123456789!@#$%^&*()_+")



# Generated at 2022-06-22 14:10:58.858059
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/home/foo/*') == ['/home/foo/bar']



# Generated at 2022-06-22 14:11:07.478975
# Unit test for function regex_escape
def test_regex_escape():
    assert 'a\.\?\+\*\|b' == regex_escape('a.?+*|b')
    assert r'a\.\?\+\*\|b' == regex_escape('a.?+*|b', re_type='posix_basic')
    # re_type='python' is the default
    assert 'a\.\?\+\*\|b' == regex_escape('a.?+*|b', re_type='python')
    assert 'a\^b' == regex_escape('a^b')
    assert 'a^b' == regex_escape('a^b', re_type='posix_basic')
    assert 'a^b' == regex_escape('a^b', re_type='python')
