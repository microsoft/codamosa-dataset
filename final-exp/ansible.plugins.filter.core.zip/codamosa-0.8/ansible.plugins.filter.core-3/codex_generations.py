

# Generated at 2022-06-22 14:01:57.348027
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('test') == 'test'
    raised = False
    try:
        msg = "Test message"
        mandatory(None, msg)
    except AnsibleFilterError as exc:
        assert exc.message == msg
        raised = True
    assert raised is True

    raised = False
    try:
        msg = "Test message"
        mandatory(None)
    except AnsibleFilterError:
        raised = True
    assert raised is True

    raised = False
    try:
        msg = "Test message"
        mandatory(None,msg)
    except AnsibleFilterError:
        raised = True
    assert raised is True


# Generated at 2022-06-22 14:02:05.387948
# Unit test for function to_bool
def test_to_bool():
    if to_bool('true') is not True:
        return False
    if to_bool('false') is not False:
        return False
    if to_bool('hello') is not False:
        return False
    if to_bool('') is not False:
        return False
    if to_bool('0') is not False:
        return False
    if to_bool(0) is not False:
        return False
    if to_bool(1):
        return False
    if not to_bool('foo'):
        return False
    if to_bool('False'):
        return False
    if not to_bool(True):
        return False
    if to_bool(False):
        return False
    if to_bool(None):
        return False
    return True

# Generated at 2022-06-22 14:02:16.353180
# Unit test for function extract
def test_extract():
    mock_value = 'mock_value'

    # Mock container for test
    class Container():
        def __init__(self, value):
            self._value = value

        def __getitem__(self, key):
            return self._value

    # Test without morekeys
    assert extract(
        'foobar',
        Container(mock_value)
    ) == mock_value

    # Test with morekeys as a list
    assert extract(
        'foo',
        Container(Container(mock_value)),
        morekeys=['bar']
    ) == mock_value

    # Test with morekeys as a string
    assert extract(
        'foo',
        Container(Container(mock_value)),
        morekeys='bar'
    ) == mock_value



# Generated at 2022-06-22 14:02:20.843983
# Unit test for function fileglob
def test_fileglob():
    assert len(fileglob('/bin')) == 0
    assert len(fileglob('/bin/c*')) > 10



# Generated at 2022-06-22 14:02:24.125647
# Unit test for function regex_escape
def test_regex_escape():
    '''Test regex_escape.py'''

    assert regex_escape('abd.*c') == 'abd\\.\\*c'
    assert regex_escape('abd.*c', re_type='posix_basic') == 'abd[.]\\[*c'



# Generated at 2022-06-22 14:02:27.572920
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(dict(a=1, b=dict(c=2, d=3))) == '{a: 1, b: {c: 2, d: 3}}\n'



# Generated at 2022-06-22 14:02:34.884478
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('abc') == 'abc'
    assert regex_escape('abc', re_type='posix_basic') == 'abc'
    assert regex_escape('abc.def$ghi^jkl') == 'abc\\.def\\$ghi\\^jkl'
    assert regex_escape('abc.def$ghi^jkl', re_type='posix_basic') == 'abc\\.def\\$ghi\\^jkl'
    assert regex_escape('', re_type='posix_basic') == ''
    assert regex_escape('abc.def$ghi^jkl', re_type='posix_extended') == 'abc.def$ghi^jkl'
    raises(AnsibleFilterError, 'regex_escape("abc", re_type="bad")')



# Generated at 2022-06-22 14:02:37.853711
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory('', 'empty') == ''
    assert mandatory('Hello World', 'msg') == 'Hello World'



# Generated at 2022-06-22 14:02:43.499591
# Unit test for function fileglob
def test_fileglob():
    # Setup
    pathname = "tests/test_fileglob"
    expected = [
        "tests/test_fileglob/1.txt",
        "tests/test_fileglob/2.txt"
    ]
    
    # Test
    result = fileglob(pathname)

    # Verify
    assert isinstance(result, list)
    assert result == expected


# Generated at 2022-06-22 14:02:49.669212
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo bar', '(?P<g1>bar)') == 'bar'
    assert regex_search('foo bar', '(?P<g1>bar)', '\\g<g1>') == ['bar', 'bar']
    assert regex_search('foo bar', '(?P<g1>bar)', '\\1') == ['bar']



# Generated at 2022-06-22 14:03:05.329839
# Unit test for function regex_search
def test_regex_search():
    test_str = '\\g<backref>'
    regex = r'(?P<backref>\w+)'
    res = regex_search(test_str, regex, test_str)
    assert res == 'backref'
    res = regex_search(test_str, regex, '\\g<backref>')
    assert res == 'backref'
    res = regex_search(test_str, regex, '\\1')
    assert res == 'backref'
    res = regex_search(test_str, regex, '\\g<backref>', '\\1')
    assert res == ['backref', 'backref']
    res = regex_search(test_str, regex, '\\g<nomatch>')
    assert res is None

# Generated at 2022-06-22 14:03:07.281301
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'K', 'value': 'v'}]) == {'K': 'v'}



# Generated at 2022-06-22 14:03:18.945483
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    template = jinja2.Template(
        "{% set test_list = [{'value': 'a', 'key': 1}, "
        "{'value': 'a', 'key': 1}, {'value': 'b', 'key': 2}, "
        "{'value': 'c', 'key': 3}] %}"
        "{{ test_list|groupby('key')|list }}"
    )
    assert template.render() == "[(1, [{'value': 'a', 'key': 1}, {'value': 'a', 'key': 1}]), " \
                                 "(2, [{'value': 'b', 'key': 2}]), " \
                                 "(3, [{'value': 'c', 'key': 3}])]"



# Generated at 2022-06-22 14:03:24.491518
# Unit test for function regex_search
def test_regex_search():
    from ansible.plugins.filter.core import regex_search
    assert regex_search("my name is Foo Bar Baz","^my name is (\\w+) (\\w+) (\\w+)$",'\\g<1>','\\g<3>') == ['Foo', 'Baz']
    assert regex_search("my name is Foo Bar Baz","^my name is (\\w+) (\\w+) (\\w+)$",'\\1','\\3') == ['Foo', 'Baz']


# Generated at 2022-06-22 14:03:36.845749
# Unit test for function subelements
def test_subelements():
    '''Unit test for function subelements.'''
    import inspect
    import doctest
    import sys
    import os

    # This module
    mod = sys.modules[__name__]

    # All members that look like unit tests
    tests = inspect.getmembers(
        mod,
        lambda x: (inspect.isfunction(x) or inspect.ismethod(x)) and \
        x.__name__.startswith('test_')
    )

    # Run all unit tests with verbose output
    failures = 0
    for (func_name, func) in tests:
        (failures, tests) = doctest.testmod(
            func,
            verbose=True,
            optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
        )

    # Produ

# Generated at 2022-06-22 14:03:39.335384
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_dict = { "a":1, "b":2 }
    res = to_nice_yaml(test_dict)
    assert res == 'a: 1\nb: 2\n'



# Generated at 2022-06-22 14:03:45.414015
# Unit test for function regex_replace
def test_regex_replace():
    ''' Test regex_replace with a few tricky cases '''
    # Basic replacement without flags
    assert regex_replace(
        value='Hello, World!',
        pattern='World',
        replacement='Galaxy'
    ) == 'Hello, Galaxy!'
    # Pattern with spaces
    assert regex_replace(
        value='Hello, World!',
        pattern='\s',
        replacement='_'
    ) == 'Hello,_World!'
    # Replacement with spaces
    assert regex_replace(
        value='Hello, World!',
        pattern=',',
        replacement=',_'
    ) == 'Hello,_ World!'
    # Pattern with quotes
    assert regex_replace(
        value='"Hello"',
        pattern='"',
        replacement='\''
    ) == '\'Hello\''
    # Replacement with quotes
   

# Generated at 2022-06-22 14:03:50.431020
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, [1, 2, 3, [4, 5]]], 1) == [1, 2, 1, 2, 3, [4, 5]]
    assert flatten([1, 2, [1, 2, 3, [4, 5]]], 2) == [1, 2, 1, 2, 3, 4, 5]
    assert flatten([1, 2, [1, 2, 3, [4, 5]]], 3) == [1, 2, 1, 2, 3, 4, 5]
    assert flatten([1, 2, [1, 2, 3, [4, 5]]], 0) == [[1, 2, [1, 2, 3, [4, 5]]]]

# Generated at 2022-06-22 14:03:53.940719
# Unit test for function combine
def test_combine():
    # TODO: more comprehensive tests, especially for the recursive merge
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine([{'a': 1}, {'b': 2}]) == {'a': 1, 'b': 2}
    assert combine([{'a': 1}, {'a': 2}], list_merge='replace') == {'a': 2}
    assert combine([{'a': 1}, {'a': 2}], list_merge='append') == {'a': [1, 2]}



# Generated at 2022-06-22 14:04:05.485989
# Unit test for function comment
def test_comment():
    assert comment('') == '\n# \n'
    assert comment('hello world') == '\n# hello world\n'
    assert comment('hello\nworld') == '\n# hello\n# world\n'
    assert comment('hello\n\nworld') == '\n# hello\n# \n# world\n'
    assert comment('', style='erlang') == '\n% \n'
    assert comment('hello world', style='erlang') == '\n% hello world\n'
    assert comment('hello\nworld', style='erlang') == '\n% hello\n% world\n'
    assert comment('hello\n\nworld', style='erlang') == '\n% hello\n% \n% world\n'

# Generated at 2022-06-22 14:04:14.701442
# Unit test for function regex_replace
def test_regex_replace():
    str = 'test-data'
    pattern = '-data'
    replacement = ''
    res = regex_replace(str, pattern, replacement)
    print(res)



# Generated at 2022-06-22 14:04:19.028252
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1,2,3]) != [1,2,3]
    mylist = ['a','b','c']
    assert randomize_list(mylist) != mylist
    assert randomize_list('hello') == ['h','e','l','l','o']
    assert randomize_list(123) == '123'



# Generated at 2022-06-22 14:04:26.898021
# Unit test for function get_hash
def test_get_hash():
    assert 'c4f1b7ffb0f4b68ff4ecd6d445304d905de4a1e4' == get_hash('some string', 'sha1')
    assert 'c4f1b7ffb0f4b68ff4ecd6d445304d905de4a1e4' == get_hash(4, 'sha1')
    assert 'c4f1b7ffb0f4b68ff4ecd6d445304d905de4a1e4' == get_hash(None, 'sha1')
    assert '5ba93c9db0cff93f52b521d7420e43f6eda2784f' == get_hash('some string', 'sha1')

# Generated at 2022-06-22 14:04:39.177416
# Unit test for function comment
def test_comment():
    text = "Test text\nand two lines"
    params = {
        'newline': '\r\n',
        'beginning': '<!--',
        'prefix': '--',
        'prefix_count': 2,
        'decoration': '=',
        'postfix': '==',
        'postfix_count': 1,
        'end': '-->'
    }
    assert comment(text, 'xml', **params) == params['beginning'] + params['newline'] + params['prefix'] + params['newline'] + params['prefix'] + params['newline'] + params['decoration'] + 'Test text' + params['newline'] + params['decoration'] + 'and two lines' + params['newline'] + params['postfix'] + params['newline'] + params['end']



# Generated at 2022-06-22 14:04:46.333320
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar

    env = Templar._get_env()
    a = [{'name': 'a', 'id': 1}, {'name': 'a', 'id': 2}, {'name': 'a', 'id': 3}, {'name': 'b', 'id': 1}]
    b = do_groupby(env, a, 'name')
    assert len(b) == 2



# Generated at 2022-06-22 14:04:55.194749
# Unit test for function regex_search
def test_regex_search():
    value="""# Test case for regex filters
    # Test case for a comment 1
    # Test case for a comment 2"""
    regex=r"""^\s+#(.*)$"""
    assert regex_search(value=value,regex=regex,multiline=True) == ' Test case for a comment 1'
    assert regex_search(value=value,regex=regex,multiline=True,ignorecase=True,*['\\g<1>']) == ' Test case for a comment 1'
    assert regex_search(value=value,regex=regex,multiline=True,*['\\g<1>']) == ' Test case for a comment 1'



# Generated at 2022-06-22 14:05:07.316385
# Unit test for function do_groupby
def test_do_groupby():
    """Test that the custom do_groupby function is used, and that it will return
    a list of tuples.

    This function is used in a unit test by calling it directly.  The jinja2
    template function is tested in tests/units/templating/test_groupby.py
    """
    from jinja2.environment import Environment
    from jinja2.runtime import StrictUndefined
    from jinja2.utils import generate_lorem_ipsum
    from jinja2.utils import Cycler
    from jinja2.filters import do_groupby
    env = Environment(undefined=StrictUndefined)

    class A(object):
        def __init__(self, b):
            self.b = b

        def __repr__(self):
            return 'A(%s)'

# Generated at 2022-06-22 14:05:19.553206
# Unit test for function extract

# Generated at 2022-06-22 14:05:23.385534
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('value') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert get_hash('value', 'md5') == '2063c1608d6e0baf80249c42e2be5804'



# Generated at 2022-06-22 14:05:36.308739
# Unit test for function combine
def test_combine():
    # default behaviour
    d1 = {'test': 1}
    d2 = {'test': 2}
    assert combine(d1, d2) == {'test': 2}

    # preserve dict order
    d1 = {'test': 1}
    d2 = {'test': 2}
    assert combine(d1, d2, recursive=True) == {'test': 2}
    # use first list if second is not a list
    d1 = {'test': 1}
    d2 = 2
    assert combine(d1, d2, recursive=True) == {'test': 1}
    assert combine(d1, d2) == {'test': 2}
    # use first dict if second is not a dict
    d1 = {'test': 1}
    d2 = 2

# Generated at 2022-06-22 14:05:50.990652
# Unit test for function to_yaml
def test_to_yaml():
    print("BEGIN test_to_yaml")
    # Should be equivalent to [1, 2, 3]
    assert to_yaml([1, 2, 3]) == "---\n- 1\n- 2\n- 3\n"
    # Should be equivalent to {'one': 1, 'two': 2, 'three': 3}
    assert to_yaml({'one': 1, 'two': 2, 'three': 3}) == "---\none: 1\nthree: 3\ntwo: 2\n"
    # Should be equivalent to {'one': {'two': [1, 2, 3]}}
    assert to_yaml({'one': {'two': [1, 2, 3]}}) == "---\none:\n  two:\n  - 1\n  - 2\n  - 3\n"


# Generated at 2022-06-22 14:05:54.393668
# Unit test for function subelements
def test_subelements():
    import pytest
    obj = [{'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]


# Generated at 2022-06-22 14:06:03.796854
# Unit test for function regex_search
def test_regex_search():
    assert '123' == regex_search('abc123', r'\d+')
    assert ['1', '2', '3'] == regex_search('abc123', r'\d+', '\\g<1>', '\\2', '\\g<0>')
    assert 'b' == regex_search('aBcaBC', r'\w')
    assert ['a', 'B', 'c'] == regex_search('aBcaBC', r'\w', '\\g<0>', '\\g<0>', '\\g<0>')
    assert ['a', 'B'] == regex_search('aBcaBC', r'\w', '\\g<0>', '\\g<0>')

# Generated at 2022-06-22 14:06:13.221944
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('hello') == 'hello'
    assert mandatory(None) == None

    try:
        mandatory('')
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        mandatory(42)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        mandatory([])
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        mandatory({})
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        mandatory(object)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)


# Generated at 2022-06-22 14:06:17.191397
# Unit test for function mandatory
def test_mandatory():
    display.display("Testing mandatory()")
    assert mandatory("foo") == "foo"
    display.display("PASSED")



# Generated at 2022-06-22 14:06:22.157800
# Unit test for function to_bool
def test_to_bool():
    ''' to_bool should return a bool '''
    assert isinstance(to_bool('yes'), bool)
    assert isinstance(to_bool('on'), bool)
    assert isinstance(to_bool('1'), bool)
    assert isinstance(to_bool('true'), bool)
    assert isinstance(to_bool(1), bool)
    assert isinstance(to_bool(None), bool)

# Generated at 2022-06-22 14:06:27.332610
# Unit test for function mandatory
def test_mandatory():
    try:
        assert mandatory('a') == 'a'
        assert mandatory(None, msg="This should be true") == None
        a = mandatory(None)
    except AssertionError:
        raise AssertionError('Mandatory function failed to assert reason: %s' % (e))



# Generated at 2022-06-22 14:06:36.074435
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    y = Undefined(name="y")
    m = partial(mandatory, msg="ERROR")

    class Foo:
        def __nonzero__(self):
            return False

    # Various data types that are not Undefined
    data = [
        's',
        123,
        Foo(),
    ]
    # Apply 'm' to each item of 'data' and verify that the result is 'a'
    # This tests that various valid data types do not raise an exception
    for d in data:
        assert(m(d) == d)

    # Various data types that raise exceptions
    # The string passed to 'msg' is not validated

# Generated at 2022-06-22 14:06:41.889805
# Unit test for function extract
def test_extract():

    env = Mock(spec=Environment)
    env.getitem.side_effect = lambda val, key: val[key]

    # pylint: disable=invalid-name
    assert extract(env, 'a', {'a': 1, 'b': 2}) == 1
    assert extract(env, 'a', {'a': 1, 'b': 2}, morekeys='c') == 1
    assert extract(env, 'a', {'a': 1, 'b': 2}, morekeys=['c']) == 1
    assert extract(env, 'a', {'a': 1, 'b': 2}, morekeys=['c', 'd']) == 1

    # Verify that the item/key lookup is done using the environment not built-ins
    assert extract(env, 'get', {'get': 1}) == 1

# Generated at 2022-06-22 14:06:48.813520
# Unit test for function mandatory
def test_mandatory():
    '''
    >>> mandatory(1)
    1
    >>> mandatory({'x':'y'})
    {'x': 'y'}
    >>> mandatory(None)
    Traceback (most recent call last):
    ...
    AnsibleFilterError: Mandatory variable not defined.
    >>> mandatory(None, msg="msg")
    Traceback (most recent call last):
    ...
    AnsibleFilterError: msg
    '''


#
# Advanced list filtering
#

# Generated at 2022-06-22 14:07:06.125161
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('This is a test', pattern='\s+', replacement=' ') == "This is a test"
    assert regex_replace('This is a test', pattern='\s+', replacement=' ') != "Thisisatest"
    assert regex_replace('This is a test', pattern='\s+', replacement=' ', ignorecase=True) == "This is a test"
    assert regex_replace('This line\ncontains multiple\nlines', pattern='^\s+', replacement='', multiline=True) == "This line\ncontains multiple\nlines"
    assert regex_replace('This line\ncontains multiple\nlines', pattern='^\s+', replacement='', multiline=True) != "Thisline\ncontainsmultiple\nlines"

# Generated at 2022-06-22 14:07:16.428772
# Unit test for function do_groupby
def test_do_groupby():
    ds = [dict(name='alice', group='one'), dict(name='bob', group='one'), dict(name='carol', group='two')]
    data = {}
    data['ds'] = ds
    data['attribute'] = 'group'
    tt = jinja2.Environment()
    tt.filters['groupby'] = do_groupby

# Generated at 2022-06-22 14:07:21.287701
# Unit test for function combine
def test_combine():
    def assert_merged_dicts_equal(merged_dict, expected_dict):
        assert merged_dict == expected_dict

    def assert_merged_dict(dict1, dict2, expected_dict):
        merged_dict = combine(dict1, dict2)
        assert_merged_dicts_equal(merged_dict, expected_dict)

    assert_merged_dict({'a': 'b'}, {}, {'a': 'b'})
    assert_merged_dict({'a': 'b'}, {'c': 'd'}, {'a': 'b', 'c': 'd'})
    assert_merged_dict({'a': 'b'}, {'a': 'd'}, {'a': 'd'})


# Generated at 2022-06-22 14:07:24.918461
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    # Test 1
    assert True == mandatory(True)
    # Test 2
    assert True == mandatory(Undefined(), msg="True")
    # Test 3
    try:
        mandatory(Undefined())
    except Exception as e:
        assert str(e) == "Mandatory variable not defined."



# Generated at 2022-06-22 14:07:36.021429
# Unit test for function regex_search
def test_regex_search():
    assert regex_search(r'/var/log/httpd/access.log-20180703', r'\b201\d{5}$') == '20180703'
    assert regex_search(r'/var/log/httpd/access.log-20180703', r'\b201\d{5}$', '\\g<0>') == '20180703'
    assert regex_search(r'/var/log/httpd/access.log-20180703', r'\b201\d{5}$', '\\g<0>', '\\2') == [u'20180703', u'07']
    assert regex_search(r'/var/log/httpd/access.log-20180703', r'\b201\d{5}$', '\\1') == ['07']
    assert regex_search

# Generated at 2022-06-22 14:07:40.401138
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', decoration='-') == '- test'
    assert comment('test', decoration='- ') == '- test'
    assert comment('test', decoration=' -') == '- test'
    assert comment('test', decoration='+ ') == '+ test'
    assert comment('test', decoration=' +') == '+ test'
    assert comment('test', decoration='  ') == '  test'
    assert comment('test', decoration='\n') == 'test'
    assert comment('test', prefix='-- ') == '-- test'
    assert comment('test', prefix='-- \n') == '-- \n-- test'
    assert comment('test', prefix='\n--\n') == '\n--\n-- test'

# Generated at 2022-06-22 14:07:48.318328
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123def', pattern=r'abc(\d+)def', group='\\1') == '123'
    assert regex_search('abc123def', pattern=r'abc(\d+)def', group='\\g<1>') == '123'
    assert regex_search('abc123def', pattern=r'abc(\d+)(def)', group1='\\1', group2='\\2') == ['123', 'def']
    assert regex_search('abc123def', pattern=r'abc(\d+)(def)', group2='\\2', group1='\\1') == ['123', 'def']



# Generated at 2022-06-22 14:07:55.611160
# Unit test for function subelements
def test_subelements():

    d = dict()

    d = {
        "users": [
            {
                "name": "alice",
                "groups": ["wheel"],
                "authorized": ["/tmp/alice/onekey.pub"]
            },
            {
                "name": "bob",
                "groups": ["users", "wheel"],
                "authorized": ["/tmp/bob/onekey.pub"]
            }
        ]
    }

    sub_elements = subelements(d, 'users.groups')

# Generated at 2022-06-22 14:08:03.814892
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2.filters
    import collections
    test_environment = jinja2.Environment()
    test_value = [
        collections.namedtuple('Person', ['name', 'age'])('John', '20'),
        collections.namedtuple('Person', ['name', 'age'])('Jane', '21'),
    ]
    # function under test
    test_attribute = 'age'
    actual = do_groupby(test_environment, test_value, test_attribute)
    expected = [('20', [('John', '20')]), ('21', [('Jane', '21')])]
    assert actual == expected



# Generated at 2022-06-22 14:08:16.923261
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader, Environment

    data = '''
---
{% set mylist = [
    {'attr1': 'a', 'attr2': 1, 'attr3': 'x'},
    {'attr1': 'b', 'attr2': 1, 'attr3': 'y'},
    {'attr1': 'b', 'attr2': 2, 'attr3': 'z'},
] %}
'''
    env = Environment(loader=DictLoader({'do_groupby.yml': data}))
    template = env.get_template('do_groupby.yml')
    vars = template.render(mylist=mylist)

    assert vars == '\n\n'
# END Unit test for function do_groupby


# Generated at 2022-06-22 14:08:28.218001
# Unit test for function regex_search
def test_regex_search():

    assert regex_search('a ab abc', 'ab') == 'ab'
    assert regex_search('a ab abc', 'b', '\\g<0>') == ['b', 'b']
    assert regex_search('a ab abc', 'b', '\\g<0>', '\\g<1>') == ['b', 'b', 'c']
    assert regex_search('a ab abc', 'b', '\\g<1>', '\\g<2>') == ['ab', 'abc']
    assert regex_search('a ab abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') is None

# Generated at 2022-06-22 14:08:32.169602
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2], 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]



# Generated at 2022-06-22 14:08:33.906051
# Unit test for function mandatory

# Generated at 2022-06-22 14:08:46.235352
# Unit test for function mandatory
def test_mandatory():
    # Mandatory
    assert mandatory("aaaa") == "aaaa"

    # No Variable
    try:
        mandatory(None)
    except AnsibleFilterError as e:
        assert "Mandatory variable not defined" in to_text(e)

    # type is AnsibleUndefined
    from ansible.template.safe_eval import AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert "Mandatory variable  not defined" in to_text(e)

    # type is jinja2.runtime.Undefined
    from jinja2.runtime import Undefined
    try:
        mandatory(Undefined)
    except AnsibleFilterError as e:
        assert "Mandatory variable  not defined" in to_text(e)

    # message

# Generated at 2022-06-22 14:08:57.576410
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b'Hello hash', 'md5') == '1fdc7a0b8dba78e72765b626fc0d7c12'
    assert get_hash('Hello hash', 'sha1') == '4d99ff52c6b0f6d906aea8381d6a7c0b3e6ab7e2'
    assert get_hash('Hello hash', 'sha256') == '3fa0b3d32b7f92ca8ad3e68ce3dc1158a96b5cadde0ef2d9e1b0a2b2c8d086f7'

# Generated at 2022-06-22 14:09:09.594757
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(u'Hello', 'md5') == u'8b1a9953c4611296a827abf8c47804d7'
    assert get_hash(u'Hello', 'sha1') == u'f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0'
    assert get_hash(u'Hello', 'sha256') == u'2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'

# Generated at 2022-06-22 14:09:11.965321
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'foo': True}, default_flow_style=False) == '{foo: true}\n'



# Generated at 2022-06-22 14:09:25.062756
# Unit test for function do_groupby
def test_do_groupby():
    from ansible import constants as C
    from ansible.template import Jinja2Template
    from ansible.vars.unsafe_proxy import UnsafeProxy

    C.DEFAULT_JINJA2_NATIVE = False

    # Create the data structure with the namedtuple
    _test_value = u'bar'
    _test_key = 'foo'
    _test_data = namedtuple(
        _test_key,
        [_test_key, 'value'])(_test_key, _test_value)

    # Create the jinja2 environment
    j2_env = Jinja2TemplateModule.environment()
    j2_env.loader = DictLoader({'data': u'{{value|do_groupby("foo")}}'})

    test_template = j2_env.get_template('data')

# Generated at 2022-06-22 14:09:34.615087
# Unit test for function mandatory
def test_mandatory():
    from jinja2.exceptions import UndefinedError

    kw = {u'foo': u'bar'}
    assert mandatory(kw[u'foo']) == u'bar'
    assert mandatory(kw, msg="This should not be raised") == {u'foo': u'bar'}
    try:
        mandatory(kw[u'baz'])
        raise AssertionError("AnsibleFilterError not raised")
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'baz' not defined."
    try:
        mandatory(kw[u'baz'], msg="This should be raised")
        raise AssertionError("AnsibleFilterError not raised")
    except AnsibleFilterError as e:
        assert to_native(e) == "This should be raised"

# Generated at 2022-06-22 14:09:46.528627
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    environment = Environment()
    templar = Templar(loader=DictLoader({}), variables={})
    attr = 'name'
    value = [{'name': 'x', 'age': 1}, {'name': 'x', 'age': 2}, {'name': 'y', 'age': 3}]

    result = do_groupby(environment, value, attr)
    assert result == [('x', [{'name': 'x', 'age': 1}, {'name': 'x', 'age': 2}]), ('y', [{'name': 'y', 'age': 3}])]

    templar.set_available_variables({'a': result})

# Generated at 2022-06-22 14:10:02.343416
# Unit test for function combine
def test_combine():
    d1 = dict(a=1, b=2, c=dict(x=1, y=2))
    d2 = dict(b=4, c=dict(x=3, y=4, z=5))
    d3 = dict(a=1, b=4, c=dict(x=3, y=4, z=5))
    assert combine(d1, d2) == d3
    assert combine() == {}
    assert combine([]) == {}

    d4 = dict(a="b")
    assert combine(d4) == d4
    assert combine(d4, None) == d4
    assert combine(None, d4) == d4
    assert combine(None, None) == {}

    d5 = dict(a=1, b=2, c=dict(x=1, y=2))

# Generated at 2022-06-22 14:10:11.958020
# Unit test for function combine

# Generated at 2022-06-22 14:10:24.120222
# Unit test for function do_groupby
def test_do_groupby():
    from ansible import template
    import jinja2

    env = jinja2.Environment()
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = template.to_json


# Generated at 2022-06-22 14:10:35.993833
# Unit test for function do_groupby
def test_do_groupby():
    """Unit test for function do_groupby"""
    env = get_empty_jinja_env()
    fake_result = [1,2,3]
    class FakeObject(object):
        def __init__(self, name):
            self.name = name
    # jinja version doesn't matter, since we are not calling into jinja2.
    expected_result = [(fake_result, [FakeObject("foo"), FakeObject("foo")]), (fake_result, [FakeObject("bar")])]
    # Ensure that we return a tuple from the namedtuple
    result = env.from_string("{{ result|groupby('name') }}").render(result=[FakeObject("foo"), FakeObject("foo"), FakeObject("bar")])
    assert safe_eval(result) == expected_result

# Note: Multiple inheritance used here as a

# Generated at 2022-06-22 14:10:43.799677
# Unit test for function mandatory
def test_mandatory():
    fails = False
    try:
        test_str = mandatory("this is defined")
    except:
        #test_str must be defined
        fails = True
    assert test_str == "this is defined"
    assert fails == False
    try:
        test_str = mandatory(None, "Test Error Message")
    except AnsibleFilterError as e:
        assert "Test Error Message" in str(e)

        return
    except:
        pass
    assert False



# Generated at 2022-06-22 14:10:56.388116
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Templar(VariableManager())
    # make sure that tuples are not converted to named tuples
    assert t.do_groupby(value=[('k1', 1), ('k2', 2), ('k2', 3)],
                        attribute='0') == [[('k1', 1)], [('k2', 2), ('k2', 3)]]
    assert t.do_groupby(value=[('k1', 1), ('k2', 2), ('k2', 3)],
                        attribute='1') == [[('k1', 1)], [('k2', 2)], [('k2', 3)]]



# Generated at 2022-06-22 14:11:06.728716
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment, DictLoader


# Generated at 2022-06-22 14:11:09.649302
# Unit test for function get_hash
def test_get_hash():
    assert 'da39a3ee5e6b4b0d3255bfef95601890afd80709' == get_hash('')



# Generated at 2022-06-22 14:11:20.744717
# Unit test for function subelements
def test_subelements():
    # Test a dict and a dict
    samples = [
        [{'user': 'alice', 'groups': ['wheel']}],
        [{'user': 'alice', 'groups': ('wheel', 'other')}],
        [{'user': 'alice', 'groups': 'wheel'}],
        [{'user': 'alice', 'groups': {'superusers': 'wheel'}}],
    ]
    funcname = 'subelements'
    results = [
        [('wheel',)],
        [('wheel',), ('other',)],
        [('wheel',)],
        [{'superusers': 'wheel'}],
    ]
    run_function_tests(funcname, samples, results)

    # Test a dict and a string