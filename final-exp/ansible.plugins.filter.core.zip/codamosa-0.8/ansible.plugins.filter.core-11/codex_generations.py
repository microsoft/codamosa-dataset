

# Generated at 2022-06-22 14:01:55.889341
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('OK') == 'OK'
    try:
        result = mandatory(AnsibleUndefined)
        assert False, "The mandatory function failed to throw a exception with an AnsibleUndefined parameter."
    except AnsibleFilterError:
        result = "OK"
    assert result == "OK"
    try:
        result = mandatory(AnsibleUndefined, "test_msg")
        assert False, "The mandatory function failed to throw a exception with an AnsibleUndefined parameter."
    except AnsibleFilterError as e:
        result = to_native(e)
    assert result == "test_msg"


# Generated at 2022-06-22 14:02:03.288670
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(42) == 42
    assert mandatory("42") == "42"
    assert not isinstance(mandatory("42"), AnsibleUndefined)

    try:
        mandatory(AnsibleUndefined("foo"))
        raise Exception("Exception not raised")
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."

    try:
        mandatory("42", "This is the error")
        raise Exception("Exception not raised")
    except AnsibleFilterError as e:
        assert to_text(e) == "This is the error"



# Generated at 2022-06-22 14:02:15.950995
# Unit test for function fileglob
def test_fileglob():
    testdir = os.path.dirname(os.path.realpath(__file__)) + "/testdir"
    if not os.path.exists(testdir):
        os.mkdir(testdir)
    if not os.path.isdir(testdir):
        print("ERROR: test_fileglob: Unable to create or access test directory %s" % testdir)
        assert False
    dirfile = testdir + "/dir"
    regularfile = testdir + "/regularfile"
    regularfile2 = testdir + "/regularfile2"
    if os.path.exists(dirfile):
        os.remove(dirfile)
    if os.path.exists(regularfile):
        os.remove(regularfile)

# Generated at 2022-06-22 14:02:21.295296
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    from ansible.template import Templar

    # normal operation, without modification
    value = [{'name': 'bob'}, {'name': 'jim'}, {'name': 'jim'}, {'name': 'will'}]
    attribute = 'name'
    env = jinja2.Environment()
    t = Templar(env, loader=None)
    result = do_groupby(t, value, attribute)
    assert result == {
        'bob': [{'name': 'bob'}],
        'jim': [{'name': 'jim'}, {'name': 'jim'}],
        'will': [{'name': 'will'}]
    }

    # with modification, using a jinja2 TemplatedEnvironment

# Generated at 2022-06-22 14:02:28.781723
# Unit test for function do_groupby
def test_do_groupby():
    # Create fake environment
    class Fake_Environment(object):
        def getitem(self, value, key):
            return value[key]

    fake_environment = Fake_Environment()
    data = [{'surname': 'Wallace', 'name': 'Gromit'}, {'surname': 'Wallace', 'name': 'Wallace'}]
    # Assert if no exception is raised
    do_groupby(fake_environment, data, 'surname')



# Generated at 2022-06-22 14:02:37.274272
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("1.2.3", r'(\d)+\.(\d)+\.(\d)+', '\\1', '\\g<2>', '\\g<3>') == ["1", "2", "3"]
    assert regex_search("[abc]", r'\[(.+)\]', '\\g<1>') == ["abc"]
    assert regex_search("[abc]", r'\[(.+)\]', '\\1') == ["abc"]



# Generated at 2022-06-22 14:02:46.499343
# Unit test for function comment
def test_comment():
    assert comment('Test') == "# Test"
    assert comment('Test', newline='\\n') == "# Test\\n"
    assert comment('Test', style='c') == "// Test"
    assert comment('Test', style='c', decoration='* ') == "/*\\n * Test\\n */"
    assert comment('Test', style='cblock') == "/*\\n * Test\\n */"
    assert comment(
        'Test', style='cblock', prefix='*') == "/*\\n* * Test\\n */"
    assert comment(
        'Test1\\nTest2', style='cblock', decoration='%') == "/*\\n% Test1\\n% Test2\\n */"
    assert comment('Test', style='xml') == "<!--\\n - Test\\n-->"



# Generated at 2022-06-22 14:02:59.254542
# Unit test for function do_groupby
def test_do_groupby():
    env = Environment()
    assert [('a', [1, 2]), ('b', [3, 4])] == env.from_string("{{ [1,2,3,4]|groupby('__key__')|list }}").render()
    assert [('a', [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])] == env.from_string("{{ [{'a':1,'b':2},{'a':3,'b':4}]|groupby('a')|list }}").render()
    assert [('a', [{'b': 1}, {'a': 3, 'b': 4}])] == env.from_string("{{ [{'b':1},{'a':3,'b':4}]|groupby('a')|list }}").render()

# Generated at 2022-06-22 14:03:09.132404
# Unit test for function get_hash
def test_get_hash():
    data = {'abc': {'def': 5}}
    assert get_hash(data, hashtype='md5') == 'ed12c27d8e2f0c3b1e01e39f6e8f0283'
    assert get_hash(data, hashtype='sha1') == 'a2a57830ce6ae848fad46947c65a97e0eae6d8af'
    assert get_hash(data, hashtype='sha256') == '9b9c3ae3c7c3d6967fa24e5c0b758465c5be5d8a534f492c13ea342f68d2c47d'

# Generated at 2022-06-22 14:03:21.207060
# Unit test for function randomize_list
def test_randomize_list():
    import copy
    import shutil
    import os
    myFile = open("/tmp/test_randomize_list.txt","w+")
    myFile.write("\n")
    myFile.close()
    mylist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    list_len = len(mylist)
    for i in range(0, list_len):
        mylist_copy = copy.deepcopy(mylist)
        mylist_randomize = randomize_list(mylist_copy, i)
        myFile = open("/tmp/test_randomize_list.txt","a")
        myFile.write("\n")
        myFile.close()

# Generated at 2022-06-22 14:03:28.337735
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo.bar', 'python') == 'foo\\.bar'
    assert regex_escape('[]', 'posix_basic') == '\\[\\]'

# Generated at 2022-06-22 14:03:40.349623
# Unit test for function comment
def test_comment():
    assert comment('lorem ipsum', 'plain') == '# lorem ipsum\n'
    assert comment('lorem ipsum', 'erlang') == '% lorem ipsum\n'
    assert comment('lorem ipsum', 'c') == '// lorem ipsum\n'
    assert comment('lorem ipsum', 'cblock') == '/*\n * lorem ipsum\n */\n'
    assert comment('lorem ipsum', 'xml') == '<!--\n - lorem ipsum\n-->\n'
    assert comment('lorem ipsum\ndolor sit', 'plain') == '# lorem ipsum\n# dolor sit\n'

# Generated at 2022-06-22 14:03:52.584643
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.template.safe_eval import unsafe_eval

    items = [{'name': 'a', 'role': 'principal'}, {'name': 'b', 'role': 'agent'}, {'name': 'c', 'role': 'principal'}]
    wrapped_items = wrap_var(items)
    res = _do_groupby(None, wrapped_items, 'role')
    assert unsafe_eval(repr(res)) == [(unsafe_eval(repr([items[0], items[2]])), 'principal'), (unsafe_eval(repr([items[1]])), 'agent')]
    res = do_groupby(None, wrapped_items, 'role')

# Generated at 2022-06-22 14:03:54.865740
# Unit test for function fileglob
def test_fileglob():
    files = fileglob('/etc/resolv.conf')
    assert isinstance(files, list)
    assert len(files) == 1



# Generated at 2022-06-22 14:04:06.134224
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test1234', '\d+') == '1234'
    assert regex_search('test1234', '\d+', '\g<1>') == ['1234', '1234']
    assert regex_search('test1234', '\d+', '\\g<1>') == ['1234', '1234']
    assert regex_search('test1234', '\d+', '\\1') == ['1234', '1234']
    assert regex_search('test1234', '\d+', '\\0') == ['1234', '1234']
    assert regex_search('test1234', '\d+', '\\g<0>') == ['1234', '1234']

# Generated at 2022-06-22 14:04:10.276662
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo','foo')
    assert regex_search('foo','o.*','\\1','\\g<1>') == ['oo','oo']
    assert regex_search('foo','o.*','\\2','\\g<1>') == ['','oo']
    assert not regex_search('foo','bar')


# Generated at 2022-06-22 14:04:19.912411
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(key1=[1, 2, 3], key2=list(range(4)), key3='value3')) == '''\
key1:
  - 1
  - 2
  - 3
key2:
  - 0
  - 1
  - 2
  - 3
key3: value3'''
    assert to_nice_yaml(dict(key1=[1, 2, 3], key2=list(range(4)), key3='value3'), indent=2) == '''\
  key1:
    - 1
    - 2
    - 3
  key2:
    - 0
    - 1
    - 2
    - 3
  key3: value3'''

# Generated at 2022-06-22 14:04:21.184244
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp/*.yml') == []



# Generated at 2022-06-22 14:04:22.364351
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('*.yaml') == [ ]



# Generated at 2022-06-22 14:04:24.540460
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(name="Joe", balance=3.50, savings=[dict(name="Checking", balance=3.60), dict(name="Savings", balance=4.00)])) == u'name: Joe\nbalance: 3.5\nsavings:\n- name: Checking\n  balance: 3.6\n- name: Savings\n  balance: 4.0\n'


# Generated at 2022-06-22 14:04:37.578288
# Unit test for function mandatory
def test_mandatory():
    import jinja2
    env = jinja2.Environment()
    assert mandatory(env.from_string('{{ foo }}').render({'foo': 'bar'})) == 'bar'
    raises(AnsibleFilterError, mandatory, env.from_string('{{ bar }}').render())
    raises(AnsibleFilterError, mandatory, env.from_string('{{ bar }}').render(), msg='fail')
    raises(AnsibleFilterError, mandatory, env.from_string('{{ undefined }}').render(), msg='defined: {{ undefined }}')



# Generated at 2022-06-22 14:04:44.072300
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'fish': [{"a": 1, "b": 2}, 3], "moos": {'nested':{'another':'here'}, 'value':'yes'}}) == '\n'.join([
        "{fish: [{a: 1, b: 2}, 3], moos: {nested: {another: here}, value: yes}}",
    ])


# Generated at 2022-06-22 14:04:54.550781
# Unit test for function do_groupby
def test_do_groupby():
    jinja2 = Jinja2Wrapper()
    def list_to_namedtuple(l):
        return namedtuple('foo', 'bar')(l[1])

    def hasattr_foo_bar(o):
        return hasattr(o, 'foo') and hasattr(o.foo, 'bar')

    mylist = [{'foo': {'bar': 0}}, {'foo': {'baz': 1}}, {'foo': {'bar': 2}}]
    expected_result = [(0, [{'foo': {'bar': 0}}]), (2, [{'foo': {'bar': 2}}])]
    result = jinja2._do_groupby(mylist, 'foo.bar')
    assert expected_result == result

    # Ensure that jinja2 2.9, 2.9

# Generated at 2022-06-22 14:05:02.214523
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('abc') == 'abc'
    assert regex_escape('a.b c$d') == 'a\\.b\\ c\\$d'
    assert regex_escape('a.b c$d', re_type='posix_basic') == 'a\\.b\\ c\\$d'
    assert regex_escape(r'a\b c\d', re_type='posix_basic') == r'a\\\b\\ c\\\d'



# Generated at 2022-06-22 14:05:10.721383
# Unit test for function extract
def test_extract():
    from jinja2 import Environment

    env = Environment()
    env.tests['extract'] = extract

    # Test extract in single step
    assert env.from_string('{{ h|extract("a") }}').render(h={'a': 3}) == '3'

    # Test extract in multiple steps
    assert env.from_string('{{ h|extract("a", "b") }}').render(h={'a': {'b': 3}}) == '3'

    # Test extract in multiple steps with a third key
    assert env.from_string('{{ h|extract("a", "b", "c") }}').render(h={'a': {'b': {'c': 3}}}) == '3'



# Generated at 2022-06-22 14:05:21.637544
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("haystack", "st", '\\1') == 'st'
    assert regex_search("haystack", "st", '\\g<1>') == 'st'
    assert regex_search("haystack", "h(\\w+)", '\\1') == 'aystack'
    assert regex_search("haystack", "h(\\w+)", '\\g<1>') == 'aystack'
    assert regex_search("haystack", "h(?P<needle>\\w+)", '\\g<needle>') == 'aystack'



# Generated at 2022-06-22 14:05:32.651045
# Unit test for function do_groupby
def test_do_groupby():
    """Tests to ensure that output of do_groupby() is the same
    as output of jinja2.filters.do_groupby() except that tuples
    are used instead of named tuples.
    """
    # Params
    test_input = [{'a': 'foo', 'b': 'bar'}, {'a': 'foo', 'b': 'baz'}]
    test_attr = 'a'
    # Test
    expected = jinja2.filters.do_groupby(test_input, test_attr)
    result = do_groupby(Jinja2TestEnvironment(), test_input, test_attr)
    assert result == expected



# Generated at 2022-06-22 14:05:40.390444
# Unit test for function fileglob
def test_fileglob():
    pathname = os.path.join(os.path.dirname(__file__), '../../')
    matches = fileglob('%s/hacking/*.py' % pathname)
    assert(len(matches) > 0)
    if os.path.isdir('%s/lib/ansible' % pathname):
        matches_2a = fileglob('%s/lib/ansible/*/__init__.py' % pathname)
        matches_2b = fileglob('%s/lib/ansible/*/__init__.py' % pathname)
        assert matches_2a == matches_2b



# Generated at 2022-06-22 14:05:51.061928
# Unit test for function fileglob
def test_fileglob():
    if sys.version_info < (2, 7):
        # Skipping test_fileglob() because `unittest.skipUnless`
        # is not available in Python 2.6
        return
    import unittest
    from ansible.errors import AnsibleFilterError
    from ansible.module_utils.parsing.convert_bool import boolean

    class testBoolean(unittest.TestCase):
        def test_to_bool(self):
            self.assertEqual(fileglob(None), [])
            self.assertEqual(fileglob([]), [])
            self.assertEqual(fileglob(''), [])
            self.assertEqual(fileglob(1), [])
            self.assertEqual(fileglob('/bin/bash'), ['/bin/bash'])



# Generated at 2022-06-22 14:05:57.103155
# Unit test for function do_groupby
def test_do_groupby():
    # Test the groupby filter with a normal data set.
    starting_data_set = [{'color': 'red', 'count': 1}, {'color': 'red', 'count': 2}, {'color': 'blue', 'count': 3}]

    env = Environment()
    env.filters.update(dict(_do_groupby=do_groupby))

    # Test to make sure it works with a straight run of jinja2's `do_groupby` function.
    test_template = '{{ starting_data_set | do_groupby(attribute="color") | list }}'
    test_template = env.from_string(test_template)
    test_result = test_template.render(starting_data_set=starting_data_set)

# Generated at 2022-06-22 14:06:11.426529
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('A:B:C:D', '^(.*):(.*):(.*):(.*)$') == 'A:B:C:D'
    assert regex_search('A:B:C:D', '^(.*):(.*):(.*):(.*)$', '\\1') == 'A'
    assert regex_search('A:B:C:D', '^(.*):(.*):(.*):(.*)$', '\\g<1>') == 'A'
    assert regex_search('A:B:C:D', '^(.*):(.*):(.*):(.*)$', '\\g<1>', '\\g<2>') == ['A', 'B']

# Generated at 2022-06-22 14:06:17.580504
# Unit test for function comment
def test_comment():
    def assertComment(text, expected, *args, **kw):
        result = to_text(comment(text, *args, **kw))
        assert result == expected, "Got %s (%s) but expected %s (%s)" \
            % (repr(result), type(result), repr(expected), type(expected))
    text = '''Hello World!
My name is Foo
and my name is also Bar
It's my endless story
'''
    expected = '''# Hello World!
# My name is Foo
# and my name is also Bar
# It's my endless story
'''
    assertComment(text, expected, 'plain')
    assertComment(text, expected, 'c')
    expected = '''# Hello World!
# My name is Foo
# and my name is also Bar
# It's my endless story
'''


# Generated at 2022-06-22 14:06:22.669684
# Unit test for function mandatory
def test_mandatory():

    # Test inputs
    cases = [
        dict(
            input=1,
            msg='msg',
            result=1,
        ),
        dict(
            input=None,
            msg=None,
            exception=True,
        ),
        dict(
            input=AnsibleUndefined(),
            msg=None,
            exception=True,
        ),
        dict(
            input=AnsibleUndefined(name='foo'),
            msg=None,
            exception=True,
        ),
        dict(
            input=AnsibleUndefined(),
            msg='foo',
            exception=True,
        ),
    ]


# Generated at 2022-06-22 14:06:33.433607
# Unit test for function randomize_list
def test_randomize_list():
    list_size = 10
    randomize_list_size = 100
    seed = 1234567890
    # test normal usage
    randomized_list = randomize_list(list(range(list_size)), seed=seed)
    # output is expected to be a list of size 'list_size'
    assert len(randomized_list) == list_size
    # output is expected to be a random sequence of list from 0 to list_size-1
    assert set(randomized_list).issuperset(set(range(list_size)))
    # check whether the sequence is deterministic
    for idx in range(randomize_list_size):
        randomized_list = randomize_list(list(range(list_size)), seed=seed)

# Generated at 2022-06-22 14:06:35.881886
# Unit test for function randomize_list
def test_randomize_list():
    result = randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed="myseed")
    assert result == [3, 4, 2, 5, 1, 8, 9, 6, 10, 7]



# Generated at 2022-06-22 14:06:40.221728
# Unit test for function get_hash
def test_get_hash():
    # Hash of the string 'Hello World!' with algorithm 'sha1'
    assert get_hash('Hello World!', 'sha1') == '0a4d55a8d778e5022fab701977c5d840bbc486d0'


# Generated at 2022-06-22 14:06:45.827607
# Unit test for function get_hash
def test_get_hash():
    assert(get_hash('mystring') == '94c9f72194a7f86c8bfdcfa04657622e763b02a8')
    assert(get_hash('mystring', hashtype='md5') == 'b026324c6904b2a9cb4b88d6d61c81d1')



# Generated at 2022-06-22 14:06:54.212678
# Unit test for function regex_escape
def test_regex_escape():
    # Initialize the class with simple test data and run the unit test
    test_data = dict(
        test_data=[
            dict(
                string=r'$var',
                escaped_string=r'\$var',
                re_type='python',
            ),
            dict(
                string=r'$var',
                escaped_string=r'\$var',
                re_type='posix_basic',
            ),
            dict(
                string=r'$var',
                escaped_string=r'\$var',
                re_type='posix_extended',
            ),
        ]
    )

    for item in test_data['test_data']:
        assert item['escaped_string'] == regex_escape(item['string'], re_type=item['re_type'])


# Generated at 2022-06-22 14:07:06.461574
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", "1484363833") == "2017-01-15 11:37:13"
    assert strftime("%Y-%m-%d %H:%M:%S", "1484363833.33") == "2017-01-15 11:37:13"
    assert strftime("%Y-%m-%d %H:%M:%S", 1484363833) == "2017-01-15 11:37:13"
    assert strftime("%Y-%m-%d %H:%M:%S", 1484363833.33) == "2017-01-15 11:37:13"
    return True



# Generated at 2022-06-22 14:07:16.721271
# Unit test for function comment
def test_comment():
    assert comment('This is a comment.') == '# This is a comment.'
    assert comment('This is a comment.', 'erlang') == '% This is a comment.'
    assert comment('This is a comment.', 'c') == '// This is a comment.'

    assert comment('This is a comment.', 'cblock') == '/*\n * This is a comment.\n */'
    assert comment('This is a comment.', 'cblock', decoration='* ') == '/*\n * This is a comment.\n */'
    assert comment('This is a comment.', 'cblock', decoration='- ') == '/*\n - This is a comment.\n */'
    assert comment('This is a comment.', 'cblock', decoration=' *') == '/*\n * This is a comment.\n */'
   

# Generated at 2022-06-22 14:07:25.778053
# Unit test for function extract
def test_extract():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2 import DictEnvironment

    env = DictEnvironment()

    assert extract(env, 'bar', {'bar': 'value'}) == 'value'
    assert extract(env, 'bar', {'foo': 'value'}) == UNDEFINED

    assert extract(env, 'foo', {'foo': {'bar': 'value'}}) == {'bar': 'value'}
    assert extract(env, 'foo', {'bar': {'bar': 'value'}}) == UNDEFINED

    assert extract(env, 'foo', {'foo': {'bar': 'value'}}, 'bar') == 'value'
    assert extract(env, 'bar', {'foo': {'bar': 'value'}}, 'bar') == UN

# Generated at 2022-06-22 14:07:31.177770
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    """
    to_nice_yaml: test_to_nice_yaml
    """
    assert to_nice_yaml({'hello': {'world': {'foo': 'bar'}}}) == """{hello: {world: {foo: bar}}}
"""



# Generated at 2022-06-22 14:07:36.163887
# Unit test for function regex_search
def test_regex_search():
    value = "Word1 Word2"
    regex = "Word(\d)"
    args = ['\\1']
    desired = ["2"]
    result = regex_search( value, regex, *args )
    assert result == desired


# Generated at 2022-06-22 14:07:40.046855
# Unit test for function regex_escape
def test_regex_escape():
    '''Test regex_escape'''
    # python regex escape
    assert 'foo\.' == regex_escape('foo.')
    # BRE posix basic regex escape
    assert 'foo\\.' == regex_escape('foo.', 'posix_basic')



# Generated at 2022-06-22 14:07:48.028965
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('this is a test', r'(test)') == 'test'
    assert regex_search('this is a test', r'(test)', '\\g<1>') == 'test'
    assert regex_search('this is a test', r'(t)(e)(s)(t)', '\\g<3>') == 's'
    assert regex_search('this is a test', r'(t)(e)(s)(t)', '\\g<3>', '\\g<1>\\g<4>') == ['s', 'tt']
    assert regex_search('this is a test', r'(t)(e)(s)(t)', '\\4', '\\g<1>\\g<4>') == ['t', 'tt']



# Generated at 2022-06-22 14:07:54.576207
# Unit test for function regex_search
def test_regex_search():
    # Check if we get correct match only
    assert regex_search('99 bottles of beer on the wall', '[0-9]+ bottles?') == '99 bottles'
    # Check if we get all groups matches
    assert regex_search('99 bottles of beer on the wall', '(\d+) bottles? of .*? on the (\w+)', '\\g<2>') == ['wall']
    assert regex_search('99 bottles of beer on the wall', '(\d+) bottles? of .*? on the (\w+)', '\\g<1>', '\\g<2>') == ['99', 'wall']
    assert regex_search('99 bottles of beer on the wall', '(\d+) bottles? of .*? on the (\w+)', '\\2') == ['wall']

# Generated at 2022-06-22 14:08:01.409652
# Unit test for function to_yaml
def test_to_yaml():
    dict1 = dict(k="v")
    dict2 = dict(v1=[1, 2, 3], v2=dict(v3=dict(v4="test")))
    str1 = to_yaml(dict1)
    str2 = to_yaml(dict2)
    dict12 = yaml_load(str1)
    dict22 = yaml_load(str2)
    assert dict1 == dict12
    assert dict2 == dict22


# Generated at 2022-06-22 14:08:05.802968
# Unit test for function regex_escape
def test_regex_escape():
    string = "0.0.0.0"
    assert regex_escape(string, re_type='python') == "0\\.0\\.0\\.0"
    assert regex_escape(string, re_type='posix_basic') == "0\\.0\\.0\\.0"



# Generated at 2022-06-22 14:08:16.105443
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("string", "str") == "str"
    assert regex_search("string", "str", "\\g<0>") == "str"
    assert regex_search("string", "str", "\\1") == None
    assert regex_search("string", "str", "\\1", "\\g<0>") == ["str"]
    assert regex_search("string", "str", "\\g<0>", "\\1") == ["str", None]
    assert regex_search("string", "str", "\\1", "\\g<1>") == ["str", None]



# Generated at 2022-06-22 14:08:25.927077
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    test_string = 'test string'
    test_list = ['test_string', dict(test_dict=dict(test_key='test_value'))]
    test_dict = dict(test_key=test_list)
    test_unicode = u'Fran\xe7ois'
    test_unsafe = AnsibleUnsafeText(test_unicode)
    assert to_nice_yaml(test_string) == "- 'test string'\n"
    assert to_nice_yaml(test_list) == "- 'test_string'\n- test_dict:\n    test_key: 'test_value'\n"

# Generated at 2022-06-22 14:08:35.323326
# Unit test for function randomize_list
def test_randomize_list():
    testlist = [1, 2, 3, 4, 5]
    randomlist = randomize_list(testlist)
    assert isinstance(randomlist, list)
    assert len(randomlist) == len(testlist)



# Generated at 2022-06-22 14:08:40.661646
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.yaml import yaml_load, yaml_load_all
    from ansible.template import recursive_check_defined
    '''Make verbose, human readable yaml'''
    data = '''{"foo": "bar", "baz": "quux", "nested": { "stuff": "thing" } }'''
    x = to_nice_yaml(data)
    print(x)
    assert x == '''
{foo: bar,
 baz: quux,
 nested:
    {stuff: thing}}
'''
    data = '''{"foo": "bar", "baz": "quux", "nested": { "stuff": ["thing", "thing2"]} }'''
    x

# Generated at 2022-06-22 14:08:54.215620
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Environment
    from jinja2.exceptions import UndefinedError
    from jinja2.runtime import Context
    from jinja2 import StrictUndefined

    env = Environment(undefined=StrictUndefined)

    try:
        do_groupby(env, [], 'foo')
        assert False, "do_groupby() should fail with an 'undefined' exception"
    except UndefinedError:
        pass

    do_groupby(env, (True, False), 'foo')

    class MyGroupBy(object):
        def __init__(self):
            self.value = None

        def groupby(self, value, attribute):
            self.value = value
            self.attribute = attribute

            if value:
                return 'something'
            else:
                return []

    my_

# Generated at 2022-06-22 14:09:05.643904
# Unit test for function do_groupby
def test_do_groupby():
    my_list = [
        {"name": "a", "type": "apple"},
        {"name": "b", "type": "apple"},
        {"name": "c", "type": "pear"},
        {"name": "d", "type": "pear"}
    ]

    my_list_grouped = [
        ('apple', [{'name': 'a', 'type': 'apple'}, {'name': 'b', 'type': 'apple'}]),
        ('pear', [{'name': 'c', 'type': 'pear'}, {'name': 'd', 'type': 'pear'}])
    ]

    assert do_groupby(my_list, 'type') == my_list_grouped


# Generated at 2022-06-22 14:09:11.239047
# Unit test for function to_yaml
def test_to_yaml():
    data = [{'a': 1, 'b': 2, 'c': 3}]
    assert to_yaml(data) == '- b: 2\n  a: 1\n  c: 3\n'
    assert to_yaml(data, default_flow_style=False) == '- a: 1\n  b: 2\n  c: 3\n'
    assert to_yaml(data, default_flow_style=True) == '- {a: 1, b: 2, c: 3}\n'
    data = {'a': 1, 'b': 2, 'c': 3}
    assert to_yaml(data) == 'a: 1\n...\n'

# Generated at 2022-06-22 14:09:18.367944
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    dictionary = {"a_key": "a value", "b_key": ["value 1", "value 2"], "c_key": "in quotes"}
    string = to_nice_yaml(dictionary)
    assert string == '''a_key: a value
b_key:
- value 1
- value 2
c_key: "in quotes"'''



# Generated at 2022-06-22 14:09:22.050856
# Unit test for function strftime
def test_strftime():
    string_format = '%Y/%m/%d'
    seconds = '1519092520'
    result = strftime(string_format, seconds)
    assert result == '2018/02/22'


# Generated at 2022-06-22 14:09:30.853078
# Unit test for function do_groupby
def test_do_groupby():
    import jinja2
    env = jinja2.Environment()
    env.filters['groupby'] = do_groupby
    # In python 2.7, namedtuples cannot be created with unicode keys.
    # In python 2.6 they can, but can't be accessed if they are.
    # Bizarrely, in Python 2.6, if an `int` is used as a key instead
    # of a `str`, it can be created and accessed on a unicode key.
    # The tuple key works everywhere.

# Generated at 2022-06-22 14:09:35.915691
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('123', hashtype='md5') == '202cb962ac59075b964b07152d234b70'
    assert get_hash('123', hashtype='sha1') == '40bd001563085fc35165329ea1ff5c5ecbdbbeef'
    assert get_hash('123', hashtype='sha224') == '7bc6c23e6bc0a4444e9b9ebba6b9d6b7e1b99a42e3ff3d2f6c05c34'
    assert get_hash('123', hashtype='sha256') == 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'
    assert get_hash

# Generated at 2022-06-22 14:09:42.183395
# Unit test for function randomize_list
def test_randomize_list():
    a = ['a', 'b', 'c', 'd', 'e', 'f']
    b = ['a', 'b', 'c', 'd', 'e', 'f']
    c = randomize_list(a)
    assert c != a
    assert c != b

    d = randomize_list(a, 1)
    assert d != a
    assert d != b
    assert d != c



# Generated at 2022-06-22 14:09:53.482377
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'f[a-z]+', '\\g<0>') == 'foo'
    assert regex_search('foo', 'f[a-z]+', '\\g<1>') == 'oo'
    assert regex_search('foo', 'f(o+)', '\\g<1>') == 'oo'
    assert regex_search('foo', 'f(o+)', '\\1') == 'oo'
    assert regex_search('foo', 'f(o+)', '\\2') is None
    assert regex_search('foo bar', 'foo (bar)') == ['bar']
    assert regex_search('foo bar', 'foo (bar)', '\\1') == 'bar'

# Generated at 2022-06-22 14:09:56.926624
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1401753885') == '2014-07-09 00:58:05'



# Generated at 2022-06-22 14:10:04.124728
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('asdf') == hashlib.new('sha1', b'asdf').hexdigest()
    assert get_hash('asdf', 'sha256') == hashlib.new('sha256', b'asdf').hexdigest()
    try:
        get_hash('asdf', 'fake_hash_type')
        raise AssertionError('Should raise a FilterError')
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 14:10:09.238519
# Unit test for function to_yaml
def test_to_yaml():
    a = {'a': 1, 'b': 2}
    r = to_yaml(a)
    assert r == '{a: 1, b: 2}\n', r
    r1 = to_yaml(a, default_flow_style=False)
    assert r1 == 'a: 1\nb: 2\n', r1


# Generated at 2022-06-22 14:10:22.205986
# Unit test for function regex_search
def test_regex_search():
   assert regex_search('abc', 'a') == 'a'
   assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
   assert regex_search('abc', 'a', '\\g<1>') == ['a', 'None']
   assert regex_search('abc', 'b', '\\g<0>', '\\g<1>') == ['b', 'b', 'c']
   assert regex_search('abc', 'b', '\\g<1>') == ['b', 'c']
   assert regex_search('abc', 'b', '\\g<1>', '\\g<0>') == ['b', 'c', 'b']

# Generated at 2022-06-22 14:10:35.015903
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert isinstance(filters, dict)
    assert "groupby" in filters
    assert "b64decode" in filters
    assert "b64encode" in filters
    assert "to_uuid" in filters
    assert "to_json" in filters
    assert "to_nice_json" in filters
    assert "from_json" in filters
    assert "to_yaml" in filters
    assert "to_nice_yaml" in filters
    assert "from_yaml" in filters
    assert "from_yaml_all" in filters
    assert "basename" in filters
    assert "dirname" in filters
    assert "expanduser" in filters
    assert "expandvars" in filters
    assert "path_join" in filters
   

# Generated at 2022-06-22 14:10:43.326470
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('') == ''
    assert mandatory(None) is None
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefinedVariable)
        assert False, "Should have thrown."
    except AnsibleFilterError:
        pass
    try:
        mandatory(AnsibleUndefinedVariable, "Test")
        assert False, "Should have thrown."
    except AnsibleFilterError as e:
        assert str(e) == "Test"



# Generated at 2022-06-22 14:10:54.938441
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y', 1488214485) == '2017'
    assert strftime('%Y', 1488214485.00087) == '2017'
    assert strftime('%Y', '1488214485') == '2017'
    assert strftime('%Y', '1488214485.00087') == '2017'
    assert strftime('%Y', 1488214485) == '2017'
    assert strftime('%Y', 1488214485.00087) == '2017'
    assert strftime('%Y', '1488214485') == '2017'
    assert strftime('%Y', '1488214485.00087') == '2017'



# Generated at 2022-06-22 14:11:06.114863
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml(dict(a=5, b=6)) == \
        '{a: 5, b: 6}\n'
    assert to_yaml(dict(a=5, b=6), default_flow_style=False) == \
        'a: 5\nb: 6\n'
    assert to_yaml(dict(a=5, b=dict(c=7, d=8))) == \
        '{a: 5, b: {c: 7, d: 8}}\n'
    assert to_yaml(dict(a=5, b=dict(c=7, d=8)), default_flow_style=False) == \
        'a: 5\nb:\n  c: 7\n  d: 8\n'

# Generated at 2022-06-22 14:11:18.696416
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves import builtins

    my_args = {'foo':'bar', 'whiz':'bang'}
    my_int = 42
    my_list = [ 'one', 'two', 'three', 'four', 'five' ]
    my_dict = { 'a':'A', 'b':'B', 'c':'C', 'd':'D', 'e':'E' }
    my_str = "Hello world"
    my_unicode = u"\u2018"

    fm = FilterModule()
    fm_filters = fm.filters()

    # Tests for fm_filters['basename']
    # test basename without path