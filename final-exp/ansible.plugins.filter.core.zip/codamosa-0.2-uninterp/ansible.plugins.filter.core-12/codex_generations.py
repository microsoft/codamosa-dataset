

# Generated at 2022-06-22 16:28:16.295519
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'

# Generated at 2022-06-22 16:28:25.921183
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory(1.0) == 1.0
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1
    assert mandatory(1.1) == 1.1

# Generated at 2022-06-22 16:28:30.514116
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/*') == ['/etc/group', '/etc/hosts', '/etc/passwd', '/etc/resolv.conf']



# Generated at 2022-06-22 16:28:40.216575
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:28:49.333061
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/hosts') == ['/etc/hosts']
    assert fileglob('/etc/hosts*') == ['/etc/hosts']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny', '/etc/hosts.equiv']

# Generated at 2022-06-22 16:28:59.036068
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def') == 'def'
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<1>') == ['def']
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<1>', '\\g<2>') == ['def', 'ghi']
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<1>', '\\g<2>', '\\g<3>') == ['def', 'ghi', 'jkl']

# Generated at 2022-06-22 16:29:11.610097
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory(dict()) == dict()
    assert mandatory(dict(a=1)) == dict(a=1)
    assert mandatory(dict(a=1, b=2)) == dict(a=1, b=2)
    assert mandatory(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
    assert mandatory(dict(a=1, b=2, c=3, d=4)) == dict(a=1, b=2, c=3, d=4)

# Generated at 2022-06-22 16:29:22.964553
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    test_list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    test_template = '{{ test_list | groupby("a") | list }}'
    test_result = env.from_string(test_template).render(test_list=test_list)

# Generated at 2022-06-22 16:29:36.502972
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar

    env = Environment()
    templar = Templar(loader=None, variables={})

    # test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    result = do_groupby(env, data, 'a')
    assert result == [((1,), [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), ((2,), [{'a': 2, 'b': 4}])]

    # test with a list of strings
    data = ['a', 'b', 'a', 'c']
    result = do_groupby(env, data, '0')

# Generated at 2022-06-22 16:29:48.110847
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:30:03.841515
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory("") == ""
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined

    try:
        mandatory(AnsibleUndefined, msg="test")
        assert False
    except AnsibleFilterError as e:
        assert e.message == "test"

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable not defined."


# Generated at 2022-06-22 16:30:08.855590
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('test', 't', 'T') == 'TesT'
    assert regex_replace('test', 't', 'T', ignorecase=True) == 'TesT'
    assert regex_replace('test', 't', 'T', multiline=True) == 'TesT'
    assert regex_replace('test', 't', 'T', ignorecase=True, multiline=True) == 'TesT'



# Generated at 2022-06-22 16:30:17.699163
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory('') == ''
    assert mandatory('hello') == 'hello'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'a': 1}) == {'a': 1}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, 'foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined, 'foo')
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'



# Generated at 2022-06-22 16:30:27.113845
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:30:36.347887
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)



# Generated at 2022-06-22 16:30:48.191786
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ') == '; ; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ', prefix_count=2) == '; ; ; text'

# Generated at 2022-06-22 16:30:54.564251
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'



# Generated at 2022-06-22 16:30:59.724869
# Unit test for function extract
def test_extract():
    from jinja2 import Environment
    env = Environment()
    assert extract(env, 'a', {'a': 1}) == 1
    assert extract(env, 'a', {'a': {'b': 2}}, 'b') == 2
    assert extract(env, 'a', {'a': {'b': {'c': 3}}}, 'b', 'c') == 3
    assert extract(env, 'a', {'a': {'b': {'c': 3}}}, ['b', 'c']) == 3



# Generated at 2022-06-22 16:31:08.570552
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', ['c']) == 'c'

# Generated at 2022-06-22 16:31:19.870273
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1500000000') == '2017-07-14 06:40:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1500000000) == '2017-07-14 06:40:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1500000000.0) == '2017-07-14 06:40:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1500000000.5) == '2017-07-14 06:40:00'

# Generated at 2022-06-22 16:31:34.409994
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [6, 2, 4, 5, 1, 9, 10, 8, 7, 3]



# Generated at 2022-06-22 16:31:37.994736
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == [2, 3, 4, 5, 1]



# Generated at 2022-06-22 16:31:46.795905
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, width=1) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, width=1) == 'a: b\n'

# Generated at 2022-06-22 16:31:52.598725
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='custom message') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'foo\' not defined.' == to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='custom message')
    except AnsibleFilterError as e:
        assert 'custom message' == to_native(e)



# Generated at 2022-06-22 16:32:04.979103
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') == [None, None]

# Generated at 2022-06-22 16:32:11.081025
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [1, 5, 7, 9, 3, 2, 6, 10, 4, 8]



# Generated at 2022-06-22 16:32:15.323048
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with a FilterModule instance
    fm = FilterModule()
    assert fm.filters()['subelements'] == subelements
    assert fm.filters()['dict2items'] == dict_to_list_of_dict_key_value_elements
    assert fm.filters()['items2dict'] == list_of_dict_key_value_elements_to_dict
    assert fm.filters()['flatten'] == flatten
    assert fm.filters()['extract'] == extract
    assert fm.filters()['combine'] == combine

# Generated at 2022-06-22 16:32:25.826042
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'


# Generated at 2022-06-22 16:32:38.611611
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:32:45.926521
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a list of dicts
    data = [
        {'a': 'b', 'c': 'd'},
        {'a': 'b', 'c': 'e'},
        {'a': 'f', 'c': 'g'},
    ]
    result = do_group

# Generated at 2022-06-22 16:32:57.993196
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'abc', '\\g<2>') == ['abc', '']
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc', 'a', '']
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>', '\\g<3>') == ['abc', 'a', '', '']

# Generated at 2022-06-22 16:33:07.990033
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is undefined') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert e.message == 'Mandatory variable \'foo\' not defined.'
    try:
        mandatory(Undefined(name='foo'), msg='foo is undefined')
    except AnsibleFilterError as e:
        assert e.message == 'foo is undefined'



# Generated at 2022-06-22 16:33:14.469267
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1, b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=10) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=5) == '''{
  a: 1,
  b: 2
}'''

# Generated at 2022-06-22 16:33:19.810419
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == None
    assert regex_search('foo', 'foo', '\\1') == None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]
    assert regex_search('foo', 'foo', '\\1', '\\g<1>') == [None, None]
    assert regex_search('foo', 'foo', '\\1', '\\2') == [None, None]
   

# Generated at 2022-06-22 16:33:28.948427
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2, c=3)) == '''\
a: 1
b: 2
c: 3
'''
    assert to_nice_yaml(dict(a=1, b=2, c=3), indent=2) == '''\
  a: 1
  b: 2
  c: 3
'''
    assert to_nice_yaml(dict(a=1, b=2, c=3), indent=2, default_flow_style=True) == '''\
a: 1
b: 2
c: 3
'''


# Generated at 2022-06-22 16:33:33.463969
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:33:42.676474
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:33:44.474023
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({"a": "b"}) == "a: b\n"



# Generated at 2022-06-22 16:33:55.831897
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)

# Generated at 2022-06-22 16:34:02.244663
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'foo': 'bar'}) == 'foo: bar\n'
    assert to_nice_yaml({'foo': 'bar', 'baz': 'qux'}) == 'foo: bar\nbaz: qux\n'
    assert to_nice_yaml({'foo': 'bar', 'baz': 'qux'}, indent=2) == '  foo: bar\n  baz: qux\n'
    assert to_nice_yaml({'foo': 'bar', 'baz': 'qux'}, indent=2, width=1) == '  foo: bar\n  baz: qux\n'

# Generated at 2022-06-22 16:34:19.511018
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == None
    assert regex_search('foo', 'foo', '\\1') == None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\1', '\\g<0>') == [None, 'foo']

# Generated at 2022-06-22 16:34:28.130797
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'b') == 'b'
    assert regex_search('abc', 'b', '\\g<0>') == ['b', 'b']
    assert regex_search('abc', 'b', '\\g<1>') == ['b', 'b']
    assert regex_search('abc', 'b', '\\g<2>') == ['b', None]
    assert regex_search('abc', 'b', '\\g<1>', '\\g<2>') == ['b', 'b', None]
    assert regex_search('abc', 'b', '\\g<1>', '\\g<2>', '\\g<3>') == ['b', 'b', None, None]

# Generated at 2022-06-22 16:34:32.630921
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:34:41.414845
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(object()) is not None
    assert mandatory(AnsibleUndefined) is not None



# Generated at 2022-06-22 16:34:53.574834
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489449600') == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489449600) == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489449600.0) == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489449600.5) == '2017-03-13 00:00:00'

# Generated at 2022-06-22 16:35:01.407186
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert e.message == "bar"
    assert mandatory('foo') == 'foo'



# Generated at 2022-06-22 16:35:12.596576
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == None
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\0', '\\0') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]

# Generated at 2022-06-22 16:35:16.783551
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', style='erlang') == '% text'
    assert comment('text', style='c') == '// text'
    assert comment('text', style='cblock') == '/*\n * text\n */'
    assert comment('text', style='xml') == '<!--\n - text\n-->'
    assert comment('text', style='plain', decoration='// ') == '// text'
    assert comment('text', style='plain', decoration='-- ') == '-- text'
    assert comment('text', style='plain', decoration='## ') == '## text'
    assert comment('text', style='plain', decoration='%% ') == '%% text'
    assert comment('text', style='plain', decoration='%% ') == '%% text'
    assert comment

# Generated at 2022-06-22 16:35:21.293567
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:35:32.555484
# Unit test for function rand
def test_rand():
    assert rand(None, 1, 0, 1) == 0
    assert rand(None, 1, 0, 1, seed=1) == 0
    assert rand(None, 1, 0, 1, seed=2) == 0
    assert rand(None, 1, 0, 1, seed=3) == 0
    assert rand(None, 1, 0, 1, seed=4) == 0
    assert rand(None, 1, 0, 1, seed=5) == 0
    assert rand(None, 1, 0, 1, seed=6) == 0
    assert rand(None, 1, 0, 1, seed=7) == 0
    assert rand(None, 1, 0, 1, seed=8) == 0
    assert rand(None, 1, 0, 1, seed=9) == 0

# Generated at 2022-06-22 16:35:46.476920
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', 0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))
    assert strftime('%Y-%m-%d %H:%M:%S', '0') == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))

# Generated at 2022-06-22 16:35:54.803965
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(True) == True
    assert mandatory(False) == False

    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_native(e)
    else:
        assert False, "Failed to raise AnsibleFilterError"


# Generated at 2022-06-22 16:36:07.027187
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None

# Generated at 2022-06-22 16:36:13.865951
# Unit test for function extract
def test_extract():
    env = Environment()
    assert extract(env, 'a', {'a': 1}) == 1
    assert extract(env, 'a', {'a': {'b': 2}}, 'b') == 2
    assert extract(env, 'a', {'a': {'b': 2}}, ['b']) == 2
    assert extract(env, 'a', {'a': {'b': 2}}, ['b', 'c']) == 2
    assert extract(env, 'a', {'a': {'b': {'c': 3}}}, ['b', 'c']) == 3
    assert extract(env, 'a', {'a': {'b': {'c': 3}}}, 'b', 'c') == 3

# Generated at 2022-06-22 16:36:25.248464
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_xml'] = to_xml
    env.filters['to_yaml'] = to_yaml

# Generated at 2022-06-22 16:36:33.395750
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:36:45.024207
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()

    try:
        mandatory(None, msg="foo")
        assert False, "Should have raised"
    except AnsibleFilterError as e:
        assert str(e) == "foo"

    try:
        mandatory(None)
        assert False, "Should have raised"
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable not defined."



# Generated at 2022-06-22 16:36:55.013922
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
a: 1
b: 2
'''



# Generated at 2022-06-22 16:37:09.053322
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1409879200') == '2014-09-05 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1409879200) == '2014-09-05 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1409879200.0) == '2014-09-05 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1409879200.1) == '2014-09-05 00:00:00'

# Generated at 2022-06-22 16:37:19.557614
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    t = env.from_string("{{ [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}] | groupby('a') | list }}")
    assert t.render() == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"



# Generated at 2022-06-22 16:37:28.486946
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory([]) == []
    assert mandatory('') == ''
    assert mandatory({}) == {}
    assert mandatory(True) == True
    assert mandatory(False) == False



# Generated at 2022-06-22 16:37:39.986162
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\2') == ['a', 'a', 'a', None]
    assert regex_search('abc', 'a', '\\1') == ['a']
    assert regex_search('abc', 'a', '\\2') == [None]