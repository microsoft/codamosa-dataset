

# Generated at 2022-06-22 16:28:12.767754
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'



# Generated at 2022-06-22 16:28:24.003940
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
{ a: 1, b: 2 }
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''\
a: 1
b: 2
'''

# Generated at 2022-06-22 16:28:33.610670
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b', 'c': 'd'}) == 'b'
    assert extract('a', {'c': 'd'}) is None
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'c') is None
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['c']) is None
    assert extract

# Generated at 2022-06-22 16:28:43.534605
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=2) == [1, 2, 3]
    assert flatten([1, [2, [3]]], levels=1) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=0) == [1, [2, [3]]]
    assert flatten([1, [2, [3]]], levels=-1) == [1, [2, [3]]]
    assert flatten([1, [2, [3]]], levels=None)

# Generated at 2022-06-22 16:28:54.475398
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('1') == '1'
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(object()) == object()
    assert mandatory(object()) == object()
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined

# Generated at 2022-06-22 16:29:00.872185
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][0-9]') == []
    assert fileglob('/etc/passwd[a-z][0-9]*') == []

# Generated at 2022-06-22 16:29:05.052445
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:29:10.863936
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:29:23.197644
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 1]
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', 1, 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 1]

# Generated at 2022-06-22 16:29:30.489985
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp/test_fileglob/*') == []
    assert fileglob('/tmp/test_fileglob/*.txt') == []
    assert fileglob('/tmp/test_fileglob/test.txt') == []
    assert fileglob('/tmp/test_fileglob/test.txt') == []
    assert fileglob('/tmp/test_fileglob/test.txt') == []
    assert fileglob('/tmp/test_fileglob/test.txt') == []
    assert fileglob('/tmp/test_fileglob/test.txt') == []



# Generated at 2022-06-22 16:29:41.550176
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Create a namedtuple
    TestNamedTuple = namedtuple('TestNamedTuple', ['a', 'b'])

    # Create a list of namedtuples
    test_list = [TestNamedTuple(a=1, b=2), TestNamedTuple(a=1, b=3), TestNamedTuple(a=2, b=4)]

    # Create a list of tuples
    test_list_tuple = [(1, 2), (1, 3), (2, 4)]

    # Test that the namedtuple

# Generated at 2022-06-22 16:29:51.251779
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-22 16:29:58.673197
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''{a: 1, b: 2}'''



# Generated at 2022-06-22 16:30:03.965435
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    assert do_groupby(templar, data, 'a') == [
        (1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 5}]),
        (3, [{'a': 3, 'b': 4}])
    ]

    # Test with a list of lists
    data = [[1, 2], [3, 4], [1, 5]]
    assert do_groupby(templar, data, 0)

# Generated at 2022-06-22 16:30:16.427202
# Unit test for function get_hash
def test_get_hash():
    assert get_hash(b'foo', 'md5') == 'acbd18db4cc2f85cedef654fccc4a4d8'
    assert get_hash(b'foo', 'sha1') == '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33'
    assert get_hash(b'foo', 'sha224') == '0808f64e60d58979fcb676c96ec938270dea42445aeefcd3a4e6f8db'
    assert get_hash(b'foo', 'sha256') == '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae'

# Generated at 2022-06-22 16:30:27.711529
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1', '\\g<0>') == ['a', 'a', 'a', 'a']

# Generated at 2022-06-22 16:30:36.048368
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg='foo') == Undefined()
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    try:
        mandatory(Undefined(), msg='foo')
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)



# Generated at 2022-06-22 16:30:47.916661
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(object()) is not None
    assert mandatory(AnsibleUndefined) is not None
    assert mandatory(AnsibleUndefined, msg='foo') is not None
    assert mandatory(AnsibleUndefined, msg='foo') is not None
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert to_native(e) == 'Mandatory variable not defined.'

# Generated at 2022-06-22 16:30:55.228278
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<0>') == ['abc']
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc']
    assert regex_search('abcdef', 'abc', '\\g<2>') == []
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc']
    assert regex_search('abcdef', 'abc', '\\g<2>', '\\g<1>') == ['abc']

# Generated at 2022-06-22 16:30:58.911063
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/*') == ['/etc/group', '/etc/passwd']



# Generated at 2022-06-22 16:31:12.438036
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'

# Generated at 2022-06-22 16:31:23.341736
# Unit test for function randomize_list
def test_randomize_list():
    # Test with a list of integers
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    # Test with a list of strings
    assert randomize_list(['a', 'b', 'c', 'd', 'e']) != ['a', 'b', 'c', 'd', 'e']
    # Test with a list of mixed types
    assert randomize_list([1, 'a', 2, 'b', 3, 'c', 4, 'd', 5, 'e']) != [1, 'a', 2, 'b', 3, 'c', 4, 'd', 5, 'e']
    # Test with a list of integers and a seed

# Generated at 2022-06-22 16:31:29.681462
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // test'

# Generated at 2022-06-22 16:31:42.341077
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']

# Generated at 2022-06-22 16:31:46.400594
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:31:59.812735
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template.safe_eval import safe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    template = '{{ data|groupby("a")|list }}'
    result = env.from_string(template).render(data=data)
    assert safe_eval(result) == [((1,), [{'a': 1, 'b': 2}]), ((3,), [{'a': 3, 'b': 4}])]

    # Test with a list of tuples
    data = [(1, 2), (3, 4)]

# Generated at 2022-06-22 16:32:11.125815
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Jinja2Environment
    from ansible.template.safe_eval import safe_eval

    env = Jinja2Environment()
    env.filters['groupby'] = do_groupby

    # Test that the filter works with a simple list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    t = env.from_string('{{ data|groupby("a") }}')
    assert safe_eval(t.render(data=data)) == [(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]

    # Test that the filter works with a list of dicts that

# Generated at 2022-06-22 16:32:19.160642
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'



# Generated at 2022-06-22 16:32:29.511257
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, width=1) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, width=1) == '{a: b}\n'

# Generated at 2022-06-22 16:32:41.562843
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', time.time()) == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', 0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))

# Generated at 2022-06-22 16:32:50.575814
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:32:57.964556
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == 'Mandatory variable not defined.'

# Generated at 2022-06-22 16:33:09.844757
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '{\n  a: b\n}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'
    assert to

# Generated at 2022-06-22 16:33:19.571582
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is not defined') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='foo is not defined')
    except AnsibleFilterError as e:
        assert to_text(e) == "foo is not defined"



# Generated at 2022-06-22 16:33:31.118774
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\1') == [1]
    assert regex_search('abc', 'a', '\\2') == []
    assert regex_search('abc', 'a', '\\g<1>') == []
    assert regex_search('abc', 'a', '\\g<a>') == []
    assert regex_search('abc', 'a', '\\g<>') == []
    assert regex_search('abc', 'a', '\\g<') == []

# Generated at 2022-06-22 16:33:38.005236
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(b'') == b''
    assert mandatory(bytearray()) == bytearray()
    assert mandatory(memoryview(b'')) == memoryview(b'')
    assert mandatory(range(0)) == range(0)
    assert mandatory(xrange(0)) == xrange(0)
    assert mandatory(iter([]))

# Generated at 2022-06-22 16:33:48.022413
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:33:50.122620
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:34:01.718855
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == '''\
a: b
'''
    assert to_nice_yaml({'a': 'b'}, indent=2) == '''\
  a: b
'''
    assert to_nice_yaml({'a': 'b'}, indent=2, default_flow_style=True) == '''\
  {a: b}
'''
    assert to_nice_yaml({'a': 'b'}, indent=2, default_flow_style=False) == '''\
  a: b
'''
    assert to_nice_yaml({'a': 'b'}, indent=2, default_flow_style=None) == '''\
  a: b
'''

# Generated at 2022-06-22 16:34:12.220357
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'

# Generated at 2022-06-22 16:34:24.869294
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=3) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:34:34.417049
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\g<1>') == ['o']

# Generated at 2022-06-22 16:34:46.650666
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1449134877') == '2015-12-10 16:41:17'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449134877) == '2015-12-10 16:41:17'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449134877.0) == '2015-12-10 16:41:17'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449134877.123) == '2015-12-10 16:41:17'

# Generated at 2022-06-22 16:34:58.707781
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-22 16:35:08.827833
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined(name='foo')) == 1
    assert mandatory(Undefined(name='foo'), msg='foo is undefined') == 1
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='foo is undefined')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "foo is undefined"



# Generated at 2022-06-22 16:35:18.893066
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'foo' in to_text(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_text(e)



# Generated at 2022-06-22 16:35:31.298931
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(42) == 42
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(b'') == b''
    assert mandatory(bytearray()) == bytearray()
    assert mandatory(memoryview(b'')) == memoryview(b'')
    assert mandatory(re.compile('')) == re.compile('')
    assert mandatory(Ellipsis) == Ellipsis

# Generated at 2022-06-22 16:35:41.610566
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}, {'a': 1, 'b': 4}]
    template = '{{ data|groupby("a")|list }}'
    assert env.from_string(template).render(data=data) == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 4}]), (2, [{'a': 2, 'b': 3}])]"

    # Test with a list of lists
    data = [[1, 2], [2, 3], [1, 4]]


# Generated at 2022-06-22 16:35:48.492539
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.safe_eval import safe_eval
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    test_data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    template = '{{ test_data | groupby("a") | list }}'
    result = env.from_string(template).render(test_data=test_data)
    assert safe_eval(result) == [[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]]



# Generated at 2022-06-22 16:35:57.031256
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\1') == ['a', 'a', None, None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\1', '\\2') == ['a', 'a', None, None, None]

# Generated at 2022-06-22 16:36:10.734699
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined, msg='foo')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."
   

# Generated at 2022-06-22 16:36:23.714362
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822

# Generated at 2022-06-22 16:36:30.087058
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'bar'
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."



# Generated at 2022-06-22 16:36:41.455518
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined



# Generated at 2022-06-22 16:36:45.621275
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:36:48.500517
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:36:59.662021
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world', 'world', None]
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world', 'world', None, None]

# Generated at 2022-06-22 16:37:10.336238
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\1') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\1') is None
    assert regex_

# Generated at 2022-06-22 16:37:23.122738
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.tests['dict'] = lambda v: isinstance(v, dict)
    env.tests['list'] = lambda v: isinstance(v, list)
    env.tests['tuple'] = lambda v: isinstance(v, tuple)
    env.tests['string'] = lambda v: isinstance(v, string_types)
    env.tests['int'] = lambda v: isinstance(v, integer_types)
    env.tests['float'] = lambda v: isinstance(v, float)
    env.tests['bool'] = lambda v: isinstance(v, bool)
    env.tests['none'] = lambda v: v is None
    env.tests['defined'] = lambda v: v is not None


# Generated at 2022-06-22 16:37:27.735313
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is not defined') == Undefined(name='foo')

