

# Generated at 2022-06-22 16:28:00.956113
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_csv'] = to_csv
    env.filters['to_nice_csv'] = to_nice_csv
    env.filters['to_ini'] = to_ini
    env.filters['to_nice_ini'] = to_nice_ini
    env.filters['to_xml'] = to_xml

# Generated at 2022-06-22 16:28:11.865608
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<2>') == ['o', None]

# Generated at 2022-06-22 16:28:23.492554
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    env.filters['map'] = map
    env.filters['zip'] = zip
    env.filters['dict'] = dict
    env.filters['list'] = list
    env.filters['tuple'] = tuple
    env.filters['set'] = set
    env.filters['reversed'] = reversed
    env.filters['sort'] = sort
    env.filters['to_json'] = to_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env

# Generated at 2022-06-22 16:28:33.325155
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}

# Generated at 2022-06-22 16:28:42.659376
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ groups | do_groupby("name") }}')))
        ]
    )



# Generated at 2022-06-22 16:28:49.112297
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*') != ['/etc/passwd', '/etc/pam.d']
    assert fileglob('/etc/p*') != ['/etc/pam.d']



# Generated at 2022-06-22 16:28:59.082788
# Unit test for function extract
def test_extract():
    from jinja2 import Environment
    env = Environment()
    assert extract(env, 'a', {'a': 1}) == 1
    assert extract(env, 'a', {'a': 1}, 'b') == 1
    assert extract(env, 'a', {'a': {'b': 1}}) == {'b': 1}
    assert extract(env, 'a', {'a': {'b': 1}}, 'b') == 1
    assert extract(env, 'a', {'a': {'b': 1}}, 'b', 'c') == 1
    assert extract(env, 'a', {'a': {'b': {'c': 1}}}, 'b', 'c') == 1

# Generated at 2022-06-22 16:29:11.646620
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dictionaries
    test_list = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    assert env.from_string('{{ test_list | groupby("a") }}').render(test_list=test_list) == \
        "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"

    # Test with a list of lists

# Generated at 2022-06-22 16:29:17.936197
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'key1', 'value': 'value1'}, {'key': 'key2', 'value': 'value2'}]
    mydict = list_of_dict_key_value_elements_to_dict(mylist)
    assert mydict == {'key1': 'value1', 'key2': 'value2'}



# Generated at 2022-06-22 16:29:26.093651
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:29:44.118394
# Unit test for function extract
def test_extract():
    assert extract('foo', {'foo': 'bar'}) == 'bar'
    assert extract('foo', {'foo': {'bar': 'baz'}}) == {'bar': 'baz'}
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar') == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar', 'baz']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar', 'baz') == 'baz'

# Generated at 2022-06-22 16:29:52.831021
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=1) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=2) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=3) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-22 16:30:04.933224
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'l') == 'l'
    assert regex_search('hello', 'l', '\\g<0>') == 'l'
    assert regex_search('hello', 'l', '\\g<1>') == 'l'
    assert regex_search('hello', 'l', '\\1') == 'l'
    assert regex_search('hello', 'l', '\\g<0>', '\\g<1>') == ['l', 'l']
    assert regex_search('hello', 'l', '\\g<0>', '\\1') == ['l', 'l']
    assert regex_search('hello', 'l', '\\1', '\\g<0>') == ['l', 'l']

# Generated at 2022-06-22 16:30:12.149022
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:30:21.898948
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:30:32.909507
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import StrictUndefined
    from collections import namedtuple

    env = Environment(undefined=StrictUndefined)
    env.filters['groupby'] = do_groupby

    # Test with a namedtuple
    TestTuple = namedtuple('TestTuple', ['a', 'b'])
    test_list = [TestTuple(1, 2), TestTuple(1, 3), TestTuple(2, 4)]
    template = env.from_string("{{ test_list | groupby('a') }}")
    assert template.render(test_list=test_list) == "[((1, 2), (1, 3)), ((2, 4),)]"

    # Test with a regular tuple

# Generated at 2022-06-22 16:30:41.092651
# Unit test for function extract
def test_extract():
    from jinja2 import Environment
    env = Environment()
    assert extract(env, 'a', {'a': 'b'}) == 'b'
    assert extract(env, 'a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract(env, 'a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract(env, 'a', {'a': {'b': 'c'}}, ['b']) == 'c'



# Generated at 2022-06-22 16:30:48.723101
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:30:56.086634
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=2) == [1, 2, 3]
    assert flatten([1, [2, [3]]], levels=1) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=0) == [1, [2, [3]]]
    assert flatten([1, [2, [3]]], levels=-1) == [1, [2, [3]]]
    assert flatten([1, [2, [3]]], levels=None)

# Generated at 2022-06-22 16:31:05.635254
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is undefined') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'foo\' not defined.' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='foo is undefined')
    except AnsibleFilterError as e:
        assert 'foo is undefined' in to_native(e)



# Generated at 2022-06-22 16:31:21.517819
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1]) == [1]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'

# Generated at 2022-06-22 16:31:28.651946
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 1}}) == {'b': 1}
    assert extract('a', {'a': {'b': 1}}, 'b') == 1
    assert extract('a', {'a': {'b': 1}}, ['b']) == 1
    assert extract('a', {'a': {'b': 1}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 1}}, 'c') == None
    assert extract('a', {'a': {'b': 1}}, ['c']) == None
    assert extract('a', {'a': {'b': 1}}, ['c', 'd']) == None

# Generated at 2022-06-22 16:31:40.865281
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', '^abc(.*)$', '\\g<1>') == '123'
    assert regex_search('abc123', '^abc(.*)$', '\\1') == '123'
    assert regex_search('abc123', '^abc(.*)$', '\\g<1>', '\\1') == ['123', '123']
    assert regex_search('abc123', '^abc(.*)$', '\\g<1>', '\\2') == ['123', None]
    assert regex_search('abc123', '^abc(.*)$', '\\g<2>') == None
    assert regex_search('abc123', '^abc(.*)$', '\\2') == None

# Generated at 2022-06-22 16:31:45.050366
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1', skip_missing=True) == []


# Generated at 2022-06-22 16:31:57.731305
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix=';; ') == ';; text'
    assert comment('text', 'plain', decoration='; ', prefix=';; ', prefix_count=2) == ';; text\n;; '

# Generated at 2022-06-22 16:32:09.587051
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:32:21.249376
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_ini'] = to_ini

# Generated at 2022-06-22 16:32:31.746919
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == u'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == u'a: 1\n  b: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=0) == u'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='-') == u'a: 1\n-b: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='ABC') == u'a: 1\nABCb: 2\n'

# Generated at 2022-06-22 16:32:41.235056
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined(name='foo')) == 1
    assert mandatory(Undefined(name='foo'), msg='bar') == 1

    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_native(e)

    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)



# Generated at 2022-06-22 16:32:54.445894
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False
    assert to_bool(None) == None
    assert to_bool('true') == True
    assert to_bool('false') == False
    assert to_bool('yes') == True
    assert to_bool('no') == False
    assert to_bool('on') == True
    assert to_bool('off') == False
    assert to_bool('1') == True
    assert to_bool('0') == False
    assert to_bool(1) == True
    assert to_bool(0) == False
    assert to_bool('foo') == False
    assert to_bool('') == False
    assert to_bool(' ') == False
    assert to_bool('  ') == False
    assert to_bool('\t') == False

# Generated at 2022-06-22 16:33:10.276316
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1', '\\2', '\\3') == ['hello', 'world', None]

# Generated at 2022-06-22 16:33:14.438689
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) != [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=42) == [2, 1, 3]



# Generated at 2022-06-22 16:33:26.271484
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == 'a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=1) == 'a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=2) == 'a: b\n  c: d\n'
    assert to_nice_yaml

# Generated at 2022-06-22 16:33:36.350360
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) == [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=1) == [3, 1, 2]
    assert randomize_list([1, 2, 3], seed=2) == [1, 3, 2]
    assert randomize_list([1, 2, 3], seed=3) == [2, 1, 3]
    assert randomize_list([1, 2, 3], seed=4) == [2, 3, 1]
    assert randomize_list([1, 2, 3], seed=5) == [3, 2, 1]
    assert randomize_list([1, 2, 3], seed=6) == [3, 1, 2]

# Generated at 2022-06-22 16:33:40.369764
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:33:52.362876
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:34:03.405094
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined

    try:
        mandatory(AnsibleUndefined, msg="This is a test")
        assert False
    except AnsibleFilterError as e:
        assert e.message == "This is a test"

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable not defined."


# Generated at 2022-06-22 16:34:12.735983
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '  a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, default_flow_style=True) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, default_flow_style=False) == 'a: b\nc: d\n'
    assert to

# Generated at 2022-06-22 16:34:23.878189
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1, b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=10) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == '''{
  a: 1,
  b: 2
}'''

# Generated at 2022-06-22 16:34:33.840949
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\1') == ['o']

# Generated at 2022-06-22 16:34:54.377156
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, 'foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined, 'foo')
        assert False
    except AnsibleFilterError:
        assert True

# Generated at 2022-06-22 16:35:03.733159
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == ['123', '123']
    assert regex_search('abc123', r'\d+', '\\1') == ['1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\1') == ['123', '123', '1']
    assert regex_search('abc123', r'\d+', '\\g<1>') == []
    assert regex_search('abc123', r'\d+', '\\2') == []
    assert regex_search('abc123', r'\d+', '\\g<1>', '\\2') == []

# Generated at 2022-06-22 16:35:13.986330
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c', 'd']) == 'c'

# Generated at 2022-06-22 16:35:22.070821
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import safe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json

    # Test with a list of dicts
    test_data = [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
        {'a': 1, 'b': 4},
    ]
    template = '{{ test_data | groupby("a") | to_json }}'
    result = env.from_string(template).render(test_data=test_data)

# Generated at 2022-06-22 16:35:31.098277
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_xml'] = to_xml
    env.filters['to_yaml'] = to_yaml

# Generated at 2022-06-22 16:35:43.403662
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f') == 'f'
    assert regex_search('foo', 'o') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', '^o') is None
    assert regex_search('foo', 'f$') is None
    assert regex_search('foo', '^foo$') == 'foo'
    assert regex_search('foo', '^fo') == 'fo'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search

# Generated at 2022-06-22 16:35:53.520302
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_

# Generated at 2022-06-22 16:35:59.316507
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test with a list of strings
    test_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    test_attribute = 'startswith'
    test_attribute_value = 'a'
    test_attribute_value_result = ['a']
    test

# Generated at 2022-06-22 16:36:09.923271
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == [3, 5, 2, 4, 1]
    assert randomize_list([1, 2, 3, 4, 5], seed=2) == [2, 3, 5, 1, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=3) == [4, 1, 3, 5, 2]
    assert randomize_list([1, 2, 3, 4, 5], seed=4) == [3, 2, 5, 1, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=5) == [3, 5, 1, 4, 2]

# Generated at 2022-06-22 16:36:23.147814
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True, multiline=True) == 'aBcd'

# Generated at 2022-06-22 16:36:44.155920
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1', '\\g<0>') == ['a', 'a', 'a', 'a']

# Generated at 2022-06-22 16:36:58.553515
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:37:05.030845
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''{a: 1, b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''{
  a: 1,
  b: 2
}
'''

# Generated at 2022-06-22 16:37:14.231192
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'd']
    assert regex_search('abcdef', 'xyz', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\1') == ['def', 'd']
    assert regex_search('abcdef', 'xyz', '\\1') is None
    assert regex_

# Generated at 2022-06-22 16:37:24.689384
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get