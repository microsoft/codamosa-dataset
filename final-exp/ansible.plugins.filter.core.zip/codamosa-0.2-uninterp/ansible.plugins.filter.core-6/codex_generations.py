

# Generated at 2022-06-22 16:27:54.916568
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441465') == '2017-03-13 15:04:25'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465) == '2017-03-13 15:04:25'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465.0) == '2017-03-13 15:04:25'



# Generated at 2022-06-22 16:28:04.917574
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert to_native(e) == 'Mandatory variable not defined.'
   

# Generated at 2022-06-22 16:28:15.485024
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'f.o') == 'foo'
    assert regex_search('foo', 'f.o', '\\g<0>') == 'foo'
    assert regex_search('foo', 'f(.)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(.)o', '\\1') == 'o'
    assert regex_search('foo', 'f(.)o', '\\g<0>', '\\1') == ['foo', 'o']

# Generated at 2022-06-22 16:28:25.571897
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', 'a(b)c', '\\1') == ['b']
    assert regex_search('abc', 'a(b)c', '\\g<1>') == ['b']
    assert regex_search('abc', 'a(b)c', '\\1', '\\g<1>') == ['b', 'b']
    assert regex_search('abc', 'a(b)c', '\\2') == []
    assert regex_search('abc', 'a(b)c', '\\g<2>') == []
    assert regex_search('abc', 'a(b)c', '\\2', '\\g<2>') == []

# Generated at 2022-06-22 16:28:32.397168
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='invalid') == 'foo\\.bar'



# Generated at 2022-06-22 16:28:42.542739
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '  a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=1) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=2) == 'a: b\nc: d\n'

# Generated at 2022-06-22 16:28:53.576000
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abc123', r'(\d+)', r'\1') == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True, multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=False) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=True) == 'abc123'

# Generated at 2022-06-22 16:29:00.771023
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abc123', r'(\d+)', r'\1') == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True, multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=False) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=True) == 'abc123'

# Generated at 2022-06-22 16:29:10.829328
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f') == 'f'
    assert regex_search('foo', 'o') == 'o'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', '^o') is None
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'f$') is None
    assert regex_search('foo', '^f$') is None
    assert regex_search('foo', '^o$') is None
    assert regex_search('foo', '^fo$') is None
    assert regex_search('foo', '^foo$') == 'foo'

# Generated at 2022-06-22 16:29:22.844485
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([1, 2, [3, 4, [5, 6]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=2) == [1, 2, 3, 4, [5, 6]]
    assert flatten([1, 2, [3, 4, [5, 6]]], levels=1) == [1, 2, 3, 4, [5, 6]]

# Generated at 2022-06-22 16:29:36.017626
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:29:47.762914
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, 3], 4]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]], 5]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, 4]], 5], levels=1) == [1, 2, [3, 4], 5]
    assert flatten([1, [2, [3, 4]], 5], levels=2) == [1, 2, 3, 4, 5]
    assert flatt

# Generated at 2022-06-22 16:29:56.637038
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '  a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=1) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=2) == 'a: b\nc: d\n'

# Generated at 2022-06-22 16:30:00.394023
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined(name='foo')) == 1
    assert mandatory(Undefined(name='foo'), msg='bar') == 1



# Generated at 2022-06-22 16:30:09.658064
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']

# Generated at 2022-06-22 16:30:18.642885
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:30:30.379454
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y') == time.strftime('%Y')
    assert strftime('%Y', second=0) == time.strftime('%Y', time.localtime(0))
    assert strftime('%Y', second=1) == time.strftime('%Y', time.localtime(1))
    assert strftime('%Y', second=1.0) == time.strftime('%Y', time.localtime(1))
    assert strftime('%Y', second=1.1) == time.strftime('%Y', time.localtime(1.1))
    assert strftime('%Y', second=1.9) == time.strftime('%Y', time.localtime(1.9))

# Generated at 2022-06-22 16:30:39.336937
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == None
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\0', '\\0') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\1') == ['foo', None]

# Generated at 2022-06-22 16:30:50.010915
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/') == []
    assert fileglob('/etc/*') == ['/etc/group', '/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny', '/etc/nsswitch.conf', '/etc/passwd', '/etc/resolv.conf', '/etc/shadow', '/etc/sudoers']
    assert fileglob('/etc/p*') == ['/etc/passwd', '/etc/pam.d']

# Generated at 2022-06-22 16:31:01.047999
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/hosts') == ['/etc/hosts']
    assert fileglob('/etc/hosts*') == ['/etc/hosts']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny']
    assert fileglob('/etc/hosts*') != ['/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny', '/etc/hosts.equiv']

# Generated at 2022-06-22 16:31:07.141811
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:31:14.796024
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:31:25.142688
# Unit test for function comment
def test_comment():
    assert comment('text', style='plain') == '# text'
    assert comment('text', style='erlang') == '% text'
    assert comment('text', style='c') == '// text'
    assert comment('text', style='cblock') == '/*\n * text\n */'
    assert comment('text', style='xml') == '<!--\n - text\n-->'
    assert comment('text', style='plain', decoration='// ') == '// text'
    assert comment('text', style='plain', decoration='// ', prefix='# ') == '# // text'
    assert comment('text', style='plain', decoration='// ', postfix='# ') == '// text# '

# Generated at 2022-06-22 16:31:38.887214
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', 1489380085) == '2017-03-13 20:01:25'
    assert strftime('%Y-%m-%d %H:%M:%S', '1489380085') == '2017-03-13 20:01:25'
    assert strftime('%Y-%m-%d %H:%M:%S', '1489380085.123456') == '2017-03-13 20:01:25'
    assert strftime('%Y-%m-%d %H:%M:%S', '1489380085.123456789') == '2017-03-13 20:01:25'

# Generated at 2022-06-22 16:31:47.568411
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]
    assert randomize_list(mylist, seed=123) == [4, 5, 1, 3, 2]

# Generated at 2022-06-22 16:32:01.737082
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ', prefix_count=2) == '; ; text'

# Generated at 2022-06-22 16:32:07.676394
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_text(e) == "bar"
    assert mandatory(None) is None
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''


# Generated at 2022-06-22 16:32:16.372983
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', None]
    assert regex_search('abc', 'a', '\\1') == ['a', None]
    assert regex_search('abc', 'a', '\\1', '\\g<1>') == ['a', None, None, None]
    assert regex_search('abc', 'a', '\\2') == ['a', None]

# Generated at 2022-06-22 16:32:22.490706
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'foo\' not defined.' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)



# Generated at 2022-06-22 16:32:29.908661
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1487269851.0') == '2017-02-16 16:30:51'
    assert strftime('%Y-%m-%d %H:%M:%S', 1487269851.0) == '2017-02-16 16:30:51'
    assert strftime('%Y-%m-%d %H:%M:%S', 1487269851) == '2017-02-16 16:30:51'
    assert strftime('%Y-%m-%d %H:%M:%S', '1487269851') == '2017-02-16 16:30:51'

# Generated at 2022-06-22 16:32:44.209720
# Unit test for function mandatory
def test_mandatory():
    # Test with a variable that is defined
    assert mandatory('foo') == 'foo'

    # Test with a variable that is not defined
    try:
        mandatory(AnsibleUndefined())
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable not defined."
    else:
        assert False, "Expected AnsibleFilterError"

    # Test with a variable that is not defined and a custom message
    try:
        mandatory(AnsibleUndefined(), msg="Custom message")
    except AnsibleFilterError as e:
        assert to_text(e) == "Custom message"
    else:
        assert False, "Expected AnsibleFilterError"

    # Test with a variable that is not defined and a custom message

# Generated at 2022-06-22 16:32:55.225158
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a single item
    template = '{{ [{ "key": "value" }] | groupby("key") | list }}'
    result = env.from_string(template).render()
    assert unsafe_eval(result) == [('value', [{'key': 'value'}])]

    # Test with multiple items
    template = '{{ [{ "key": "value" }, { "key": "value" }] | groupby("key") | list }}'
    result = env.from_string(template).render()

# Generated at 2022-06-22 16:33:07.903741
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    template = '{{ data|groupby("a")|list }}'
    result = env.from_string(template).render(data=data)
    assert result == "[((1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]),), ((2, [{'a': 2, 'b': 4}]),)]"

    # Test with a list of tuples

# Generated at 2022-06-22 16:33:18.910305
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_yaml_extended'] = to_nice_yaml_extended
    env.filters['to_nice_yaml_extended_extended'] = to_nice_yaml_extended_extended
    env.filters['to_nice_yaml_extended_extended_extended']

# Generated at 2022-06-22 16:33:30.270522
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, indent=2) == '  a: 1\n  b: 2\n'

# Generated at 2022-06-22 16:33:41.599220
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, 3]
    assert flatten([1, [2, [3, [4]]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4]]]], levels=2) == [1, 2, 3, [4]]
    assert flatten([1, [2, [3, [4]]]], levels=1) == [1, 2, [3, [4]]]

# Generated at 2022-06-22 16:33:53.255914
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:33:57.701914
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass
    try:
        mandatory(AnsibleUndefined, 'test')
        assert False
    except AnsibleFilterError as e:
        assert 'test' in str(e)



# Generated at 2022-06-22 16:34:09.027490
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_text(e)
    try:
        mandatory(AnsibleUndefined, msg='test')
        assert False
    except AnsibleFilterError as e:
        assert 'test' in to_text(e)



# Generated at 2022-06-22 16:34:15.025824
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    test_list = [
        {'name': 'foo', 'value': 1},
        {'name': 'foo', 'value': 2},
        {'name': 'bar', 'value': 3},
        {'name': 'bar', 'value': 4},
        {'name': 'bar', 'value': 5},
    ]

# Generated at 2022-06-22 16:34:28.073505
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == ['123', '123']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\1') == ['123', '123', '1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\2') == ['123', '123', None]
    assert regex_search('abc123', r'\d+', '\\g<1>') == ['123']
    assert regex_search('abc123', r'\d+', '\\1') == ['1']
    assert regex_search('abc123', r'\d+', '\\2') == [None]
   

# Generated at 2022-06-22 16:34:35.671137
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False



# Generated at 2022-06-22 16:34:48.200099
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:34:59.705177
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_

# Generated at 2022-06-22 16:35:12.254343
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'

# Generated at 2022-06-22 16:35:21.469625
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\1') == 'a'
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1', '\\g<0>') == ['a', 'a']

# Generated at 2022-06-22 16:35:32.585308
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="test") == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."
    try:
        mandatory(AnsibleUndefined, msg="test")
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "test"



# Generated at 2022-06-22 16:35:43.247375
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from collections import namedtuple

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    assert do_groupby(env, data, 'a') == [
        (1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 5}]),
        (3, [{'a': 3, 'b': 4}])
    ]

    # Test with a list of namedtuples

# Generated at 2022-06-22 16:35:53.400824
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import StrictUndefined
    from jinja2.sandbox import SandboxedEnvironment
    from ansible.template.safe_eval import unsafe_eval

    env = Environment(undefined=StrictUndefined)
    env.filters['groupby'] = do_groupby

    env_sandbox = SandboxedEnvironment(undefined=StrictUndefined)
    env_sandbox.filters['groupby'] = do_groupby

    # Test with a list of dicts

# Generated at 2022-06-22 16:36:01.407198
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined)
        assert False, 'AnsibleUndefined was not raised'
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    try:
        mandatory(AnsibleUndefined, 'foo')
        assert False, 'AnsibleUndefined was not raised'
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)



# Generated at 2022-06-22 16:36:12.498397
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c']) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c', 'd']) == 'b'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c', 'd']) == 'c'



# Generated at 2022-06-22 16:36:24.903522
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_json'] = to_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_yaml'] = to_

# Generated at 2022-06-22 16:36:30.079299
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:36:43.260035
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
{ a: 1, b: 2 }
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''\
a: 1
b: 2
'''

# Generated at 2022-06-22 16:36:49.885796
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized', skip_missing=True) == []

# Generated at 2022-06-22 16:37:00.482372
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory(0.9) == 0.9
    assert mandatory([]) == []
    assert mandatory([1]) == [1]
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'a':1}) == {'a':1}
    assert mandatory({'a':1,'b':2}) == {'a':1,'b':2}
    assert mandatory(set()) == set()

# Generated at 2022-06-22 16:37:10.912550
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == "a: b\n"
    assert to_yaml({'a': 'b'}, default_flow_style=False) == "a: b\n"
    assert to_yaml({'a': 'b'}, default_flow_style=True) == "{a: b}\n"
    assert to_yaml({'a': 'b'}, default_flow_style=None) == "a: b\n"
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == "  a: b\n"
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == "{a: b}\n"

# Generated at 2022-06-22 16:37:23.564527
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized', skip_missing=True) == []
    assert subelements(obj, 'missing') == []
    assert sube