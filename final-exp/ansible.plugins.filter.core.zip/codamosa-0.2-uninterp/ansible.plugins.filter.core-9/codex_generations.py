

# Generated at 2022-06-22 16:27:56.935026
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:28:00.922950
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == [4, 5, 1, 3, 2]



# Generated at 2022-06-22 16:28:07.794995
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:28:17.111265
# Unit test for function comment
def test_comment():
    # Test 1
    text = '''
    This is a multiline text
    with multiple lines
    '''
    assert comment(text, style='plain') == '''
    # This is a multiline text
    # with multiple lines
    '''

    # Test 2
    text = '''
    This is a multiline text
    with multiple lines
    '''
    assert comment(text, style='erlang') == '''
    % This is a multiline text
    % with multiple lines
    '''

    # Test 3
    text = '''
    This is a multiline text
    with multiple lines
    '''
    assert comment(text, style='c') == '''
    // This is a multiline text
    // with multiple lines
    '''

    # Test 4

# Generated at 2022-06-22 16:28:26.200961
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc', 'a', 'b']
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>', '\\g<3>') == ['abc', 'a', 'b', 'c']

# Generated at 2022-06-22 16:28:32.533426
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:28:42.581881
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
{ a: 1, b: 2 }
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''\
a: 1
b: 2
'''

# Generated at 2022-06-22 16:28:46.355189
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'c', 'value': 3}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-22 16:28:56.181717
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>', '\\g<2>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\1') == 'a'
    assert regex_search('abc', 'a', '\\1', '\\0') == ['a', 'a']

# Generated at 2022-06-22 16:29:08.213849
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('foo') is False
    assert to_bool('') is False



# Generated at 2022-06-22 16:29:24.128691
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='test') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), msg='test')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "test"

    try:
        mandatory(Undefined(name=None))
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."



# Generated at 2022-06-22 16:29:31.986012
# Unit test for function rand
def test_rand():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{ [1,2,3]|rand }}')))
            ]
        )


# Generated at 2022-06-22 16:29:43.992978
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'foo'

    try:
        mandatory(None)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'

   

# Generated at 2022-06-22 16:29:52.705895
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory(1.0) == 1.0
    assert mandatory(1.1) == 1.1
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert mandatory('test') == 'test'
    assert mandatory(u'test') == u

# Generated at 2022-06-22 16:30:02.904634
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is not defined') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'foo\' not defined.' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='foo is not defined')
    except AnsibleFilterError as e:
        assert 'foo is not defined' in to_native(e)



# Generated at 2022-06-22 16:30:11.426839
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(42) == 42
    assert mandatory("foo") == "foo"
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({"a": 1, "b": 2}) == {"a": 1, "b": 2}

    try:
        mandatory(None, "foo")
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "foo"

    try:
        mandatory(None)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable not defined."


# Generated at 2022-06-22 16:30:20.458499
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1
    assert ternary(False, 1, 2) == 2
    assert ternary(None, 1, 2, 3) == 3
    assert ternary(None, 1, 2) == 2
    assert ternary(0, 1, 2) == 2
    assert ternary(1, 1, 2) == 1
    assert ternary(1, 1, 2, 3) == 1
    assert ternary("", 1, 2) == 2
    assert ternary("", 1, 2, 3) == 3
    assert ternary("foo", 1, 2) == 1
    assert ternary("foo", 1, 2, 3) == 1
    assert ternary("foo", 1, 2, 3) == 1

# Generated at 2022-06-22 16:30:31.984848
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    env = Environment(loader=DictLoader({'template': '{{ foo | groupby("bar") }}'}))
    template = env.get_template('template')
    foo = [{'bar': 'baz', 'baz': 'qux'}, {'bar': 'baz', 'baz': 'quux'}]
    context = Context(environment=env, vars={'foo': foo})
    templar = Templar(loader=None, variables={})
    result = templar._do_groupby(context, template.root_render_func(context))

# Generated at 2022-06-22 16:30:41.781040
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:30:49.078613
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys='c') == 'b'
    assert extract('a', {'a': {'b': 'c'}}, morekeys='b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c']) == 'c'



# Generated at 2022-06-22 16:31:04.797742
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\0') == ['a', 'a']
    assert regex_search('abc', 'a', '\\0', '\\0') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', None]
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', None, None, None]

# Generated at 2022-06-22 16:31:13.597478
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abc123def', pattern='123', replacement='456') == 'abc456def'
    assert regex_replace(value='abc123def', pattern='123', replacement='456', ignorecase=True) == 'abc456def'
    assert regex_replace(value='abc123def', pattern='123', replacement='456', multiline=True) == 'abc456def'
    assert regex_replace(value='abc123def', pattern='123', replacement='456', ignorecase=True, multiline=True) == 'abc456def'
    assert regex_replace(value='abc123def', pattern='123', replacement='456', ignorecase=False, multiline=False) == 'abc456def'
    assert regex_replace(value='abc123def', pattern='123', replacement='456', ignorecase=False, multiline=True)

# Generated at 2022-06-22 16:31:24.459187
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='; ') == '; test'
    assert comment('test', 'plain', decoration='; ', prefix=';; ') == ';; test'
    assert comment('test', 'plain', decoration='; ', prefix=';; ', prefix_count=2) == ';; \ntest'

# Generated at 2022-06-22 16:31:38.846339
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:31:47.227851
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-22 16:31:54.045686
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c']) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c', 'd']) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c', 'd']) == 'b'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, morekeys=['b', 'c']) == 'd'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, morekeys=['b', 'c', 'd']) == 'd'

# Generated at 2022-06-22 16:31:58.347531
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''{a: 1, b: 2}
'''


# Generated at 2022-06-22 16:32:10.098478
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1') == []

# Generated at 2022-06-22 16:32:21.344712
# Unit test for function extract
def test_extract():
    assert extract('foo', {'foo': 'bar'}) == 'bar'
    assert extract('foo', {'foo': {'bar': 'baz'}}) == {'bar': 'baz'}
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar') == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar', 'baz']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar', 'baz') == 'baz'

# Generated at 2022-06-22 16:32:28.677622
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'hello') == 'hello'
    assert regex_search('hello', 'hello', '\\g<0>') == 'hello'
    assert regex_search('hello', 'hello', '\\0') == 'hello'
    assert regex_search('hello', 'hello', '\\1') == None
    assert regex_search('hello', 'hello', '\\g<1>') == None
    assert regex_search('hello', 'hello', '\\g<0>', '\\g<0>') == ['hello', 'hello']
    assert regex_search('hello', 'hello', '\\0', '\\0') == ['hello', 'hello']
    assert regex_search('hello', 'hello', '\\1', '\\1') == [None, None]

# Generated at 2022-06-22 16:32:43.542916
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-22 16:32:54.932474
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'

# Generated at 2022-06-22 16:33:00.035255
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, 3], 4]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]], 5]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, 4]], 5], levels=1) == [1, 2, [3, 4], 5]
    assert flatten([1, [2, [3, 4]], 5], levels=2) == [1, 2, 3, 4, 5]
    assert flatt

# Generated at 2022-06-22 16:33:04.977063
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1') == []

# Generated at 2022-06-22 16:33:12.995768
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'a': {'b': 2}}) == {'a': {'b': 2}}
    assert combine({'a': {'b': 2}}, {'a': 1}) == {'a': 1}
    assert combine({'a': {'b': 2}}, {'a': {'c': 3}}) == {'a': {'b': 2, 'c': 3}}
    assert combine({'a': {'b': 2}}, {'a': {'b': 3}}) == {'a': {'b': 3}}

# Generated at 2022-06-22 16:33:17.165780
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=False) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, list_merge='replace') == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-22 16:33:27.024302
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='foo is undefined') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='foo is undefined')
    except AnsibleFilterError as e:
        assert to_text(e) == "foo is undefined"



# Generated at 2022-06-22 16:33:36.993511
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\1') == ['foo', None]
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]
    assert regex_search('foo', '(?P<foo>foo)', '\\g<foo>') == 'foo'

# Generated at 2022-06-22 16:33:48.569159
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\1', '\\1') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']

# Generated at 2022-06-22 16:34:00.610125
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    test_data = [
        {'name': 'foo', 'group': 'one'},
        {'name': 'bar', 'group': 'two'},
        {'name': 'baz', 'group': 'one'},
        {'name': 'qux', 'group': 'two'},
    ]
    template = '{{ test_data | groupby("group") | list }}'
    result = env.from_string(template).render(test_data=test_data)

# Generated at 2022-06-22 16:34:22.084499
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<2>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<3>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<4>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<5>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<6>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<7>') == 'foo'

# Generated at 2022-06-22 16:34:29.424217
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\2') == ['o', None]
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<1>') == ['o', 'o']

# Generated at 2022-06-22 16:34:41.023671
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world', 'world', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world', 'world', 'world', 'world']

# Generated at 2022-06-22 16:34:52.838533
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world']

# Generated at 2022-06-22 16:34:58.960590
# Unit test for function mandatory
def test_mandatory():
    '''
    Test mandatory filter
    '''
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(None) is None
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(Undefined()) == Undefined()



# Generated at 2022-06-22 16:35:08.825587
# Unit test for function rand
def test_rand():
    assert rand(None, [1, 2, 3]) in [1, 2, 3]
    assert rand(None, 10) in range(10)
    assert rand(None, 10, step=2) in [0, 2, 4, 6, 8]
    assert rand(None, 10, start=1) in range(1, 10)
    assert rand(None, 10, start=1, step=2) in [1, 3, 5, 7, 9]
    assert rand(None, 10, seed=1) == 9
    assert rand(None, [1, 2, 3], seed=1) == 2



# Generated at 2022-06-22 16:35:20.994067
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('foo', 'foo', '\\1') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\0', '\\0') == ['foo', 'foo']

# Generated at 2022-06-22 16:35:32.523506
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/*') == ['/etc/group', '/etc/hosts', '/etc/hosts.allow', '/etc/hosts.deny', '/etc/nsswitch.conf', '/etc/passwd', '/etc/resolv.conf', '/etc/services']
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*d') == ['/etc/passwd']
    assert fileglob('/etc/p*d*') == ['/etc/passwd']
    assert fileglob('/etc/p*d*e') == []

# Generated at 2022-06-22 16:35:40.067306
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='invalid') == 'foo\\.bar'



# Generated at 2022-06-22 16:35:47.592233
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// // test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // // test'

# Generated at 2022-06-22 16:35:58.446054
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>', '\\g<2>') == ['foo', 'foo', 'foo']

# Generated at 2022-06-22 16:36:09.871327
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
        assert False, "AnsibleUndefined should raise an error"
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 16:36:19.204766
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg="foo") == Undefined()
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."
    try:
        mandatory(Undefined(), msg="foo")
    except AnsibleFilterError as e:
        assert to_native(e) == "foo"



# Generated at 2022-06-22 16:36:30.225898
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None, indent=4) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:36:43.302050
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'
    try:
        mandatory(AnsibleUndefined, msg='foo')
    except AnsibleFilterError as e:
        assert str(e) == 'foo'

# Generated at 2022-06-22 16:36:52.269019
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager(loader=None, host_vars=HostVars(loader=None, inventory=None)))

# Generated at 2022-06-22 16:37:01.660454
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') == [None, None]

# Generated at 2022-06-22 16:37:11.852128
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2, c=3)) == '''\
a: 1
b: 2
c: 3
'''
    assert to_nice_yaml(dict(a=1, b=2, c=3), indent=2) == '''\
  a: 1
  b: 2
  c: 3
'''
    assert to_nice_yaml(dict(a=1, b=2, c=3), indent=2, default_flow_style=True) == '''\
a: 1
b: 2
c: 3
'''

# Generated at 2022-06-22 16:37:20.585157
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'

# Generated at 2022-06-22 16:37:32.880941
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1') == []