

# Generated at 2022-06-22 16:28:07.282653
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}



# Generated at 2022-06-22 16:28:18.872064
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'

# Generated at 2022-06-22 16:28:29.865307
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(dict()) == dict()
    assert mandatory(list()) == list()
    assert mandatory(set()) == set()
    assert mandatory(tuple()) == tuple()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(object()) == object()
    assert mandatory(type) == type
    assert mandatory(type('a', (object,), {})) == type('a', (object,), {})

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-22 16:28:32.391970
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}



# Generated at 2022-06-22 16:28:42.542546
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == 'abc'
    assert regex_search('abcdef', 'def', '\\g<1>') == 'def'
    assert regex_search('abcdef', 'ghi', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == 'abc'
    assert regex_search('abcdef', 'def', '\\1') == 'def'
    assert regex_search('abcdef', 'ghi', '\\1') is None

# Generated at 2022-06-22 16:28:48.657477
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:28:58.174107
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    assert list_of_dict_key_value_elements_to_dict(mylist) == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict(mylist, key_name='k', value_name='v') == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict(mylist, key_name='v', value_name='k') == {1: 'a', 2: 'b'}



# Generated at 2022-06-22 16:29:11.003167
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdefgh', 'bcd') == 'bcd'
    assert regex_search('abcdefgh', 'bcd', '\\g<1>') == ['bcd', 'bcd']
    assert regex_search('abcdefgh', 'bcd', '\\1') == ['bcd', 'bcd']
    assert regex_search('abcdefgh', 'bcd', '\\2') == ['bcd', None]
    assert regex_search('abcdefgh', 'bcd', '\\g<1>', '\\g<2>') == ['bcd', 'bcd', None]
    assert regex_search('abcdefgh', 'bcd', '\\g<1>', '\\2') == ['bcd', 'bcd', None]

# Generated at 2022-06-22 16:29:22.884599
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}

# Generated at 2022-06-22 16:29:36.502577
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\0') == ['a', 'a']
    assert regex_search('abc', 'a', '\\0', '\\0') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', None]
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', None, None, None]

# Generated at 2022-06-22 16:29:50.600550
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\1', '\\0') == ['foo', 'foo']

# Generated at 2022-06-22 16:29:58.643736
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello (\w+)', '\\g<1>') == ['world']
    assert regex_search('hello world', 'hello (\w+)', '\\1') == ['world']
    assert regex_search('hello world', 'hello (\w+)', '\\g<1>', '\\1') == ['world', 'world']
    assert regex_search('hello world', 'hello (\w+)', '\\2') == []
    assert regex_search('hello world', 'hello (\w+)', '\\g<2>') == []
    assert regex_search('hello world', 'hello (\w+)', '\\g<1>', '\\g<1>') == ['world', 'world']

# Generated at 2022-06-22 16:30:03.813102
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.template.safe_eval import safe_eval

    env = Environment(loader=DictLoader({}))
    ctx = Context({}, environment=env)
    value = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    attribute = 'a'
    result = do_groupby(ctx, value, attribute)
    assert safe_eval(repr(result)) == result



# Generated at 2022-06-22 16:30:16.239568
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == u'{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == u'{a: 1,\nb: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == u'{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == u'{a: 1,\nb: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == u'{a: 1,\nb: 2}\n'


# Generated at 2022-06-22 16:30:23.210892
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass

    try:
        mandatory(AnsibleUndefined, 'foo')
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 16:30:33.350061
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from ansible.template.safe_eval import unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    test_list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    template = '{{ test_list | groupby("a") | list }}'
    result = env.from_string(template).render(test_list=test_list)
    assert unsafe_eval(result) == [[(1, 2), (1, 5)], [(3, 4)]]

    # Test with a list of lists

# Generated at 2022-06-22 16:30:39.606577
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    env = Environment()
    templar = Templar(loader=None, variables={})
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_yaml_extended'] = to_nice_yaml_extended
    env.filters['to_nice_yaml_extended_with_newlines'] = to_nice_yaml_extended_with_newlines

# Generated at 2022-06-22 16:30:49.224377
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True, multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=False, multiline=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=False, multiline=True) == 'aBcd'

# Generated at 2022-06-22 16:30:56.559956
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2, 3]]) == [1, 2, 3]
    assert flatten([[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert flatten([[1, 2, 3], [4, 5, 6], [7, 8, 9]], levels=1) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-22 16:31:03.370268
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['groupby'] == do_groupby
    assert FilterModule().filters()['b64decode'] == b64decode
    assert FilterModule().filters()['b64encode'] == b64encode
    assert FilterModule().filters()['to_uuid'] == to_uuid
    assert FilterModule().filters()['to_json'] == to_json
    assert FilterModule().filters()['to_nice_json'] == to_nice_json
    assert FilterModule().filters()['from_json'] == json.loads
    assert FilterModule().filters()['to_yaml'] == to_yaml
    assert FilterModule().filters()['to_nice_yaml'] == to_nice_yaml
    assert FilterModule().filters()['from_yaml'] == from_yaml

# Generated at 2022-06-22 16:31:18.059144
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(object()) == object()

    try:
        mandatory(AnsibleUndefined)
        assert False, "Should have raised an exception"
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 16:31:30.064631
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<2>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<2>', '\\g<1>') == ['foo', 'foo', 'foo']

# Generated at 2022-06-22 16:31:42.343529
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'hello') == 'hello'
    assert regex_search('hello', '^hello$') == 'hello'
    assert regex_search('hello', '^hello$', '\\g<0>') == 'hello'
    assert regex_search('hello', '^h(.+)$', '\\g<1>') == 'ello'
    assert regex_search('hello', '^h(.+)$', '\\1') == 'ello'
    assert regex_search('hello', '^h(.+)$', '\\g<1>', '\\1') == ['ello', 'ello']
    assert regex_search('hello', '^h(.+)$', '\\g<1>', '\\g<1>') == ['ello', 'ello']

# Generated at 2022-06-22 16:31:53.018032
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == ['/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls', '/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls', '/bin/ls', '/bin/ls']

# Generated at 2022-06-22 16:32:05.421635
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': {'c': 'd'}}}) == {'b': {'c': 'd'}}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b') == {'c': 'd'}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b', 'c') == 'd'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b', 'c', 'd') == Undefined
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b', 'c', morekeys=['d']) == Undefined

# Generated at 2022-06-22 16:32:10.381167
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:32:21.413753
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, width=1) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, width=1) == 'a: b\n'

# Generated at 2022-06-22 16:32:28.743563
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []

# Generated at 2022-06-22 16:32:40.942563
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2)) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2, width=10) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2, width=9) == '''\
  a: 1
  b: 2
'''

# Generated at 2022-06-22 16:32:51.160042
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictEnvironment
    env = DictEnvironment()
    env.filters['groupby'] = do_groupby
    # test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    assert env.from_string('{{ data|groupby("a") }}').render(data=data) == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"
    # test with a list of tuples
    data = [(1, 2), (1, 3), (2, 4)]

# Generated at 2022-06-22 16:33:02.798404
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [7, 3, 2, 5, 6, 9, 10, 4, 1, 8]



# Generated at 2022-06-22 16:33:10.497949
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}



# Generated at 2022-06-22 16:33:22.304011
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 'foo'}, {'a': 1, 'b': 'bar'}, {'a': 2, 'b': 'baz'}]
    t = env.from_string("{{ data|groupby('a')|list }}")

# Generated at 2022-06-22 16:33:33.464411
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import AnsibleUndefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
        {'a': 1, 'b': 4},
    ]
    assert env.from_string('{{ data|groupby("a")|list }}').render(data=data) == \
        "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 4}]), (2, [{'a': 2, 'b': 3}])]"

    # Test with a list of lists

# Generated at 2022-06-22 16:33:40.355889
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-22 16:33:52.362188
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('foo') is False
    assert to_bool('') is False
    assert to_bool('True') is True
    assert to_bool('False') is False
    assert to_bool('Yes') is True
   

# Generated at 2022-06-22 16:34:00.610047
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None



# Generated at 2022-06-22 16:34:11.638687
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1425016400') == '2015-03-01 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1425016400) == '2015-03-01 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1425016400.0) == '2015-03-01 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1425016400.5) == '2015-03-01 00:00:00'

# Generated at 2022-06-22 16:34:23.379711
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world']

# Generated at 2022-06-22 16:34:33.520093
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

# Generated at 2022-06-22 16:34:49.480348
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\g<2>') == ['o']

# Generated at 2022-06-22 16:35:00.547788
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<2>') == ['a', None]
    assert regex_search('abc', 'a', '\\g<1>', '\\g<2>', '\\g<3>') == ['a', None, None]

# Generated at 2022-06-22 16:35:12.485631
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory('foo') == 'foo'
    assert mandatory(u'foo') == u'foo'
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == Ans

# Generated at 2022-06-22 16:35:21.553562
# Unit test for function rand
def test_rand():
    assert rand(None, 1, 0, 1) == 0
    assert rand(None, 1, 0, 1, seed=1) == 0
    assert rand(None, 1, 0, 1, seed=2) == 0
    assert rand(None, 1, 0, 1, seed=3) == 0
    assert rand(None, 1, 0, 1, seed=4) == 0
    assert rand(None, 1, 0, 1, seed=5) == 0
    assert rand(None, 1, 0, 1, seed=6) == 0
    assert rand(None, 1, 0, 1, seed=7) == 0
    assert rand(None, 1, 0, 1, seed=8) == 0
    assert rand(None, 1, 0, 1, seed=9) == 0

# Generated at 2022-06-22 16:35:32.620396
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:35:43.277999
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', 'oo', '\\g<0>') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\1') == ['foo', 'o']
    assert regex_search('foo', 'oo', '\\g<0>', '\\1') == ['foo', 'f']
    assert regex_search('foo', 'oo', '\\2') == None
    assert regex_search

# Generated at 2022-06-22 16:35:53.465755
# Unit test for function extract
def test_extract():
    env = Environment()
    assert extract(env, 'a', {'a': 'b'}) == 'b'
    assert extract(env, 'a', {'a': 'b'}, 'c') == 'b'
    assert extract(env, 'a', {'a': 'b'}, ['c']) == 'b'
    assert extract(env, 'a', {'a': 'b'}, ['c', 'd']) == 'b'
    assert extract(env, 'a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract(env, 'a', {'a': {'b': 'c'}}, ['b']) == 'c'

# Generated at 2022-06-22 16:36:05.458985
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'abc', '\\g<2>') == ['abc', None]
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc', 'a', None]
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>', '\\g<3>') == ['abc', 'a', None, None]

# Generated at 2022-06-22 16:36:16.730643
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    # Test with a defined variable
    assert mandatory('foo') == 'foo'

    # Test with an undefined variable
    try:
        mandatory(Undefined(name='bar'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'bar' not defined."
    else:
        assert False, "Failed to raise AnsibleFilterError"

    # Test with an undefined variable and a custom message
    try:
        mandatory(Undefined(name='bar'), msg="Custom message")
    except AnsibleFilterError as e:
        assert to_native(e) == "Custom message"
    else:
        assert False, "Failed to raise AnsibleFilterError"

    # Test with an undefined variable and no name

# Generated at 2022-06-22 16:36:27.327912
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 1}) == 1
    assert extract('a', {'a': {'b': 2}}) == {'b': 2}
    assert extract('a', {'a': {'b': 2}}, 'b') == 2
    assert extract('a', {'a': {'b': 2}}, ['b']) == 2
    assert extract('a', {'a': {'b': 2}}, ['b', 'c']) == 2
    assert extract('a', {'a': {'b': {'c': 3}}}, ['b', 'c']) == 3
    assert extract('a', {'a': {'b': {'c': 3}}}, 'b', 'c') == 3

# Generated at 2022-06-22 16:36:42.261079
# Unit test for function comment
def test_comment():
    assert comment(text='This is a comment', style='plain') == '# This is a comment'
    assert comment(text='This is a comment', style='erlang') == '% This is a comment'
    assert comment(text='This is a comment', style='c') == '// This is a comment'
    assert comment(text='This is a comment', style='cblock') == '/*\n * This is a comment\n */'
    assert comment(text='This is a comment', style='xml') == '<!--\n - This is a comment\n-->'
    assert comment(text='This is a comment', style='plain', decoration='; ') == '; This is a comment'

# Generated at 2022-06-22 16:36:49.421231
# Unit test for function extract
def test_extract():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_v

# Generated at 2022-06-22 16:37:00.168268
# Unit test for function comment
def test_comment():
    assert comment('text', style='plain') == '# text'
    assert comment('text', style='erlang') == '% text'
    assert comment('text', style='c') == '// text'
    assert comment('text', style='cblock') == '/*\n * text\n */'
    assert comment('text', style='xml') == '<!--\n - text\n-->'
    assert comment('text', style='cblock', decoration='* ') == '/*\n * text\n */'
    assert comment('text', style='cblock', decoration='* ', prefix='* ') == '/*\n * text\n */'
    assert comment('text', style='cblock', decoration='* ', prefix='* ', prefix_count=2) == '/*\n * * text\n */'

# Generated at 2022-06-22 16:37:10.709573
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == [1, 3, 5, 4, 2]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != randomize_list([1, 2, 3, 4, 5], seed=2)
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == randomize_list([1, 2, 3, 4, 5], seed=1)
    assert randomize_list([1, 2, 3, 4, 5])

# Generated at 2022-06-22 16:37:23.407505
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1449121841.0') == '2015-12-10 22:30:41'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449121841.0) == '2015-12-10 22:30:41'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449121841) == '2015-12-10 22:30:41'
    assert strftime('%Y-%m-%d %H:%M:%S', '1449121841') == '2015-12-10 22:30:41'

# Generated at 2022-06-22 16:37:34.467507
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f') == 'f'
    assert regex_search('foo', 'o') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', '^o') is None
    assert regex_search('foo', 'f$') is None
    assert regex_search('foo', '^f$') is None
    assert regex_search('foo', '^foo$') == 'foo'
    assert regex_search('foo', '^fo') == 'fo'
    assert regex_search('foo', 'oo$') == 'oo'
    assert regex