

# Generated at 2022-06-22 16:27:51.775858
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/*') == ['/etc/group', '/etc/hosts', '/etc/passwd']



# Generated at 2022-06-22 16:28:03.387013
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, list_merge='append') == {'a': 1, 'b': [2, 3], 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, list_merge='append', recursive=True) == {'a': 1, 'b': [2, 3], 'c': 4}

# Generated at 2022-06-22 16:28:09.761583
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:28:14.005270
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'



# Generated at 2022-06-22 16:28:19.994442
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:28:25.941297
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:28:38.593669
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, 3]
    assert flatten([1, [2, [3, [4]]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4]]]], levels=2) == [1, 2, 3, [4]]
    assert flatten([1, [2, [3, [4]]]], levels=1) == [1, 2, [3, [4]]]

# Generated at 2022-06-22 16:28:44.525539
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'a': [2]}) == {'a': [2]}
    assert combine({'a': [1]}, {'a': [2]}) == {'a': [1, 2]}
    assert combine({'a': [1]}, {'a': [2]}, list_merge='replace') == {'a': [2]}
    assert combine({'a': [1]}, {'a': [2]}, list_merge='append') == {'a': [1, 2]}

# Generated at 2022-06-22 16:28:55.177373
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == [4, 1, 5, 3, 2]
    assert randomize_list([1, 2, 3, 4, 5], seed=2) == [2, 5, 3, 4, 1]
    assert randomize_list([1, 2, 3, 4, 5], seed=3) == [1, 4, 2, 5, 3]
    assert randomize_list([1, 2, 3, 4, 5], seed=4) == [3, 2, 5, 1, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=5) == [1, 5, 2, 3, 4]

# Generated at 2022-06-22 16:29:01.803299
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3, 4]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4, 5]]]]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, [4, [5, 6]]]]]) == [1, 2, 3, 4, 5, 6]
    assert flatten([1, [2, [3, [4, [5, [6, 7]]]]]]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-22 16:29:23.571941
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_ini'] = to_ini

# Generated at 2022-06-22 16:29:36.503327
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:29:46.676952
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'



# Generated at 2022-06-22 16:29:56.158916
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool('foo') is False
    assert to_bool('') is False
    assert to_bool([]) is False
    assert to_bool({}) is False
    assert to_bool(()) is False



# Generated at 2022-06-22 16:30:04.632478
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None



# Generated at 2022-06-22 16:30:12.753884
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 1]
    assert regex_search('abc', 'a', '\\g<1>') == ['a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') == ['a', 'a', 1, 2]

# Generated at 2022-06-22 16:30:20.658715
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False



# Generated at 2022-06-22 16:30:26.194196
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg="foo") == Undefined()
    assert mandatory(Undefined(name="bar")) == Undefined()
    assert mandatory(Undefined(name="bar"), msg="foo") == Undefined()



# Generated at 2022-06-22 16:30:32.769122
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'bar'
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."



# Generated at 2022-06-22 16:30:44.163969
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', 'b', 'b']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['b', 'b', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<1>') == ['b', 'b', 'b', 'b']
   

# Generated at 2022-06-22 16:30:53.677503
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:30:57.950850
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined)
        assert False, "Should have raised an exception"
    except AnsibleFilterError as e:
        assert "Mandatory variable not defined." in to_text(e)



# Generated at 2022-06-22 16:31:09.187469
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == '''{
  a: 1,
  b: 2
}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == '''{
  a: 1,
  b: 2
}
'''

# Generated at 2022-06-22 16:31:20.531633
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True, multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B', ignorecase=True, multiline=True) == 'abcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B', ignorecase=False, multiline=True) == 'abcd'
   

# Generated at 2022-06-22 16:31:28.042979
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, 'foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined, 'foo')
        assert False
    except AnsibleFilterError:
        assert True

# Generated at 2022-06-22 16:31:39.846424
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Jinja2Environment
    from ansible.template.safe_eval import safe_eval
    from ansible.template.vars import AnsibleJ2Vars

    env = Environment(extensions=['jinja2.ext.do'])
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json

    j2_env = Jinja2Environment(loader=None, variables=AnsibleJ2Vars(loader=None))
    j2_env.filters['groupby'] = do_groupby
    j2_env.filters['to_json'] = to_json

    # Test with jinja2>=2.9.0,<2.9.5

# Generated at 2022-06-22 16:31:46.547964
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_text(e) == "bar"



# Generated at 2022-06-22 16:31:48.689717
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == 1



# Generated at 2022-06-22 16:32:01.847032
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'abc', '\\g<2>') == ['abc', None]
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc', 'a', None]
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>', '\\g<3>') == ['abc', 'a', None, None]

# Generated at 2022-06-22 16:32:03.842440
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) != [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=42) == [3, 1, 2]



# Generated at 2022-06-22 16:32:19.160757
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}) == '''{a: 1,
b: 2,
c: 3}'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}, indent=2) == '''{
  a: 1,
  b: 2,
  c: 3
}'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}, indent=2, default_flow_style=True) == '''{a: 1, b: 2, c: 3}'''

# Generated at 2022-06-22 16:32:26.851546
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:32:39.578550
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == []
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>', '\\1') == ['a', 'a']

# Generated at 2022-06-22 16:32:42.832135
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:32:54.602696
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]

# Generated at 2022-06-22 16:33:07.507744
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '{\n  a: b\n}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'
    assert to

# Generated at 2022-06-22 16:33:18.177180
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.safe_eval import safe_eval

    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    template = '{{ data | groupby("a") | list }}'
    result = env.from_string(template).render(data=data)
    assert safe_eval(result) == [[(1, {'a': 1, 'b': 2})], [(3, {'a': 3, 'b': 4})]]

    # Test with a list of lists
    data = [[1, 2], [3, 4]]

# Generated at 2022-06-22 16:33:29.687256
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'h') == 'h'
    assert regex_search('hello', 'h', '\\g<0>') == 'h'
    assert regex_search('hello', 'h', '\\g<1>') == 'h'
    assert regex_search('hello', 'h', '\\g<0>', '\\g<1>') == ['h', 'h']
    assert regex_search('hello', 'h', '\\g<1>', '\\g<0>') == ['h', 'h']
    assert regex_search('hello', 'h', '\\1') == 'h'
    assert regex_search('hello', 'h', '\\1', '\\1') == ['h', 'h']

# Generated at 2022-06-22 16:33:40.625026
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', 'oo', '\\g<0>') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\1') == ['foo', 'o']
    assert regex_search('foo', 'oo', '\\g<0>', '\\1') == ['foo', 'f']
    assert regex_search('foo', 'oo', '\\2') == None
    assert regex_search

# Generated at 2022-06-22 16:33:49.659805
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(False) == False
    assert mandatory(True) == True
    try:
        mandatory(AnsibleUndefined)
        assert False, "Should have thrown an exception"
    except AnsibleFilterError:
        pass
    try:
        mandatory(AnsibleUndefined, "Foo")
        assert False, "Should have thrown an exception"
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 16:34:05.511214
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'def', '\\g<0>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<1>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<2>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<3>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<4>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<5>') == 'def'
    assert regex_search('abcdef', 'def', '\\g<6>') == 'def'

# Generated at 2022-06-22 16:34:17.232649
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert e.message == "bar"

    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo')

# Generated at 2022-06-22 16:34:26.895868
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '''\
{a: 1, b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
  {a: 1, b: 2}
'''

# Generated at 2022-06-22 16:34:31.072507
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'a': 2}, {'a': 3}) == {'a': 3}
    assert combine({'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}) == {'a': 4}
    assert combine({'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}, {'a': 5}) == {'a': 5}

# Generated at 2022-06-22 16:34:43.362191
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(42) == 42
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(b'') == b''
    assert mandatory(bytearray()) == bytearray()
    assert mandatory(memoryview(b'')) == memoryview(b'')
    assert mandatory(Ellipsis) == Ellipsis
    assert mandatory(NotImplemented) == NotImplemented
    assert mandatory(range(0)) == range

# Generated at 2022-06-22 16:34:55.756210
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:35:03.038764
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert str(e) == "bar"
    assert mandatory('foo') == 'foo'
    assert mandatory('foo', msg='bar') == 'foo'



# Generated at 2022-06-22 16:35:13.518520
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None, variables=HostVars(UnsafeProxy({}), 'localhost'))
    env = Environment(trim_blocks=True, lstrip_blocks=True, undefined=AnsibleUndefined)
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters

# Generated at 2022-06-22 16:35:21.972449
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') is None
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\1', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\1') is None

# Generated at 2022-06-22 16:35:29.836770
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(b'') == b''
    assert mandatory(bytearray()) == bytearray()
    assert mandatory(memoryview(b'')) == memoryview(b'')
    assert mandatory(range(0)) == range(0)
    assert mandatory(xrange(0)) == xrange(0)
    assert mandatory(iter([]))

# Generated at 2022-06-22 16:35:46.541778
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory(()) == ()
    assert mandatory({}) == {}
    assert mandatory(object()) is not None

    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    else:
        assert False, "AnsibleFilterError not raised"

    try:
        mandatory(AnsibleUndefined, msg='foo')
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)


# Generated at 2022-06-22 16:35:54.843961
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b', 'c': 'd'}) == 'b'
    assert extract('a', {'c': 'd'}) == None
    assert extract('a', {'c': 'd'}, 'e') == 'e'
    assert extract('a', {'c': 'd'}, 'e', 'f') == 'e'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'd') == 'd'
    assert extract('a', {'a': {'b': 'c'}}, 'd', 'e') == 'd'

# Generated at 2022-06-22 16:36:07.026394
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1, 2, 3]) == '- 1\n- 2\n- 3\n'
    assert to_yaml({'a': 1, 'b': 2, 'c': 3}) == 'a: 1\nb: 2\nc: 3\n'
    assert to_yaml({'a': 1, 'b': 2, 'c': 3}, default_flow_style=False) == 'a: 1\nb: 2\nc: 3\n'
    assert to_yaml({'a': 1, 'b': 2, 'c': 3}, default_flow_style=True) == '{a: 1, b: 2, c: 3}\n'

# Generated at 2022-06-22 16:36:09.182494
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for method filters of class FilterModule
    # TODO: Implement test
    pass


# Generated at 2022-06-22 16:36:13.436205
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True, list_merge='append') == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True, list_merge='append') == {'a': 1, 'b': 3, 'c': 4}
   

# Generated at 2022-06-22 16:36:24.181062
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<1>') == [1]
    assert regex_search('abc', 'a', '\\1') == [1]
    assert regex_search('abc', 'a', '\\g<0>', '\\2') == ['a', 'a', None]

# Generated at 2022-06-22 16:36:32.842577
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1485774800') == '2017-01-28 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1485774800) == '2017-01-28 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1485774800.0) == '2017-01-28 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', '1485774800.0') == '2017-01-28 00:00:00'

# Generated at 2022-06-22 16:36:44.648330
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n...\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, indent=2) == '  a: b\n  ...\n'

# Generated at 2022-06-22 16:36:58.595678
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441465') == '2017-03-13 15:24:25'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465) == '2017-03-13 15:24:25'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465.0) == '2017-03-13 15:24:25'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465.123) == '2017-03-13 15:24:25'

# Generated at 2022-06-22 16:37:04.251677
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=3) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:37:23.637985
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, width=1) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, width=1) == '{a: b}\n'

# Generated at 2022-06-22 16:37:26.999534
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:37:28.646706
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:37:40.030003
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'