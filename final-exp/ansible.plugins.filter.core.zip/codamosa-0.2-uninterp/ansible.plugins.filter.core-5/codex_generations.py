

# Generated at 2022-06-22 16:28:03.767210
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abc123', r'\d+', '456') == 'abc456'
    assert regex_replace('abc123', r'\d+', '456', ignorecase=True) == 'abc456'
    assert regex_replace('abc123', r'\d+', '456', multiline=True) == 'abc456'
    assert regex_replace('abc123', r'\d+', '456', ignorecase=True, multiline=True) == 'abc456'
    assert regex_replace('abc123', r'\d+', '456', ignorecase=False, multiline=False) == 'abc456'
    assert regex_replace('abc123', r'\d+', '456', ignorecase=False, multiline=False) == 'abc456'

# Generated at 2022-06-22 16:28:09.374731
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader, Environment
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    env = Environment(loader=DictLoader({'t': '{{ [{ "foo": "bar", "baz": "qux" }, { "foo": "bar", "baz": "quux" }] | groupby("foo") | list }}'}))
    t = Templar(loader=env)
    assert t.template('t', {}, env).data == [('bar', [{'baz': 'qux', 'foo': 'bar'}, {'baz': 'quux', 'foo': 'bar'}])]


# Generated at 2022-06-22 16:28:18.708613
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg='test') == Undefined()
    assert mandatory(Undefined(), msg='test') == Undefined()
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable  not defined."
    try:
        mandatory(Undefined(), msg='test')
    except AnsibleFilterError as e:
        assert to_native(e) == "test"



# Generated at 2022-06-22 16:28:27.299549
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('test') == '361e6d51-faec-5944-9079-341386da8e2e'
    assert to_uuid('test', '361e6d51-faec-444a-9079-341386da8e2e') == '361e6d51-faec-5944-9079-341386da8e2e'
    assert to_uuid('test', '361e6d51faec444a9079341386da8e2e') == '361e6d51-faec-5944-9079-341386da8e2e'

# Generated at 2022-06-22 16:28:39.064920
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None, variables={})
    test_data = [
        {'name': 'foo', 'group': 'one'},
        {'name': 'bar', 'group': 'two'},
        {'name': 'baz', 'group': 'one'},
        {'name': 'qux', 'group': 'two'},
    ]
    test_data_proxy = UnsafeProxy(test_data)
    test_data_proxy_grouped = do_groupby(templar, test_data_proxy, 'group')
    assert isinstance(test_data_proxy_grouped, list)
    assert isinstance(test_data_proxy_grouped[0], tuple)
   

# Generated at 2022-06-22 16:28:50.731259
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, 3], 4]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, 4]], 5]) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, 4]], 5], levels=2) == [1, 2, 3, 4, 5]
    assert flatten([1, [2, [3, 4]], 5], levels=1) == [1, 2, [3, 4], 5]
    assert flatt

# Generated at 2022-06-22 16:28:56.277015
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'a', 'b') == 'a'
    assert ternary(False, 'a', 'b') == 'b'
    assert ternary(None, 'a', 'b') == 'b'
    assert ternary(None, 'a', 'b', 'c') == 'c'



# Generated at 2022-06-22 16:29:05.335234
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='', pattern='', replacement='') == ''
    assert regex_replace(value='', pattern='', replacement='', ignorecase=True) == ''
    assert regex_replace(value='', pattern='', replacement='', multiline=True) == ''
    assert regex_replace(value='', pattern='', replacement='', ignorecase=True, multiline=True) == ''
    assert regex_replace(value='', pattern='', replacement='', ignorecase=False, multiline=False) == ''
    assert regex_replace(value='', pattern='', replacement='', ignorecase=False, multiline=True) == ''
    assert regex_replace(value='', pattern='', replacement='', ignorecase=True, multiline=False) == ''

# Generated at 2022-06-22 16:29:14.169274
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'
    assert regex_escape('foo[bar]') == 'foo\\[bar\\]'
    assert regex_escape('foo[bar]', re_type='posix_basic') == 'foo\\[bar\\]'
    assert regex_escape('foo[bar]', re_type='posix_extended') == 'foo\\[bar\\]'
    assert regex_escape('foo^bar') == 'foo\\^bar'

# Generated at 2022-06-22 16:29:24.224166
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid(u'foo') == u'361e6d51-faec-5a4a-9079-341386da8e2e'
    assert to_uuid(u'foo', u'00000000-0000-0000-0000-000000000000') == u'6bfec6e0-0dff-52f2-9079-341386da8e2e'
    assert to_uuid(u'foo', u'00000000-0000-0000-0000-000000000001') == u'6bfec6e0-0dff-52f2-9079-341386da8e2f'

# Generated at 2022-06-22 16:29:35.637034
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n...\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, indent=2) == '  a: b\n  ...\n'

# Generated at 2022-06-22 16:29:47.405486
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.0) == 0.0

# Generated at 2022-06-22 16:29:57.623505
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c']) == 'b'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c', 'd']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c', 'd', 'e']) == 'c'



# Generated at 2022-06-22 16:30:05.277231
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(object()) == object()
    assert mandatory(object) == object
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined



# Generated at 2022-06-22 16:30:16.682846
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == ['123', '123']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\1') == ['123', '123', '1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\g<1>') == ['123', '123', '1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\2') == ['123', '123', None]

# Generated at 2022-06-22 16:30:24.272492
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1479492400') == '2016-11-18 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1479492400) == '2016-11-18 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1479492400.0) == '2016-11-18 00:00:00'



# Generated at 2022-06-22 16:30:33.659058
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']

# Generated at 2022-06-22 16:30:45.282030
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // test'

# Generated at 2022-06-22 16:30:59.929294
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a']
    assert regex_search('abc', 'a', '\\1', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == []
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a']

# Generated at 2022-06-22 16:31:08.953462
# Unit test for function extract
def test_extract():
    assert extract('foo', {'foo': 'bar'}) == 'bar'
    assert extract('foo', {'foo': {'bar': 'baz'}}) == {'bar': 'baz'}
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar') == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar', 'baz']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar', 'baz') == 'baz'

# Generated at 2022-06-22 16:31:28.478522
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_json'] = to_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_yaml'] = to_

# Generated at 2022-06-22 16:31:40.800347
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("test") == "a94a8fe5ccb19ba61c4c0873d391e987982fbbd3"
    assert get_hash("test", "sha256") == "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
    assert get_hash("test", "sha512") == "ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff"
    assert get

# Generated at 2022-06-22 16:31:53.946042
# Unit test for function extract
def test_extract():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_context = PlayContext()

    env = Environment(loader=loader, variable_manager=variable_manager, inventory=inventory)

    test_dict = {
        'foo': {
            'bar': {
                'baz': 'test'
            }
        }
    }

    assert 'test' == extract(env, 'baz', test_dict, 'bar')

# Generated at 2022-06-22 16:32:03.094375
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined('foo')) == Undefined('foo')
    assert mandatory(Undefined('foo'), msg='bar') == Undefined('foo')
    try:
        mandatory(Undefined('foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined('foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:32:08.728940
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    assert randomize_list(mylist) != mylist
    assert randomize_list(mylist, seed=123) != randomize_list(mylist, seed=123)
    assert randomize_list(mylist, seed=123) == randomize_list(mylist, seed=123)



# Generated at 2022-06-22 16:32:16.897916
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'

# Generated at 2022-06-22 16:32:20.461837
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError:
        pass
    else:
        assert False, "AnsibleUndefined did not raise AnsibleFilterError"



# Generated at 2022-06-22 16:32:24.644807
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'

# Generated at 2022-06-22 16:32:28.585222
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=123) == [2, 1, 4, 5, 3]



# Generated at 2022-06-22 16:32:38.745776
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined



# Generated at 2022-06-22 16:32:58.798878
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-22 16:33:10.338829
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_ini'] = to_ini

# Generated at 2022-06-22 16:33:22.125616
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822
    env.filters['to_local']

# Generated at 2022-06-22 16:33:33.260280
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import safe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [
        {'a': 1, 'b': 'a'},
        {'a': 2, 'b': 'b'},
        {'a': 3, 'b': 'c'},
        {'a': 1, 'b': 'd'},
        {'a': 2, 'b': 'e'},
        {'a': 3, 'b': 'f'},
    ]
    template = '{{ data|groupby("a") }}'
    result = env.from_string(template).render(data=data)
   

# Generated at 2022-06-22 16:33:44.997280
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c', 'd') == 'c'

# Generated at 2022-06-22 16:33:56.257477
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    env = Environment()
    env.filters['groupby'] = do_groupby
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a list of dicts
    data = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 3},
        {'a': 2, 'b': 4},
    ]
    t = env.from_string('{{ data|groupby("a") }}')
    result = t.render(data=data)

# Generated at 2022-06-22 16:34:08.318073
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\1') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\1') is None
    assert regex_

# Generated at 2022-06-22 16:34:18.240293
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_

# Generated at 2022-06-22 16:34:28.662416
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*/') == []
    assert fileglob('/etc/p*/*') == []
    assert fileglob('/etc/p*/passwd') == []
    assert fileglob('/etc/p*/passwd*') == []
    assert fileglob('/etc/p*/passwd*') == []
    assert fileglob('/etc/p*/passwd*') == []
    assert fileglob('/etc/p*/passwd*') == []
    assert fileglob('/etc/p*/passwd*') == []
    assert fileglob

# Generated at 2022-06-22 16:34:39.969344
# Unit test for function extract
def test_extract():
    assert extract('b', {'a': {'b': 'c'}}) == 'c'
    assert extract('b', {'a': {'b': 'c'}}, 'a') == 'c'
    assert extract('b', {'a': {'b': 'c'}}, ['a']) == 'c'
    assert extract('b', {'a': {'b': 'c'}}, ['a', 'b']) == 'c'
    assert extract('b', {'a': {'b': 'c'}}, ['a', 'b']) == 'c'
    assert extract('b', {'a': {'b': 'c'}}, ['a', 'b']) == 'c'

# Generated at 2022-06-22 16:34:56.345255
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>') == 'a'
    assert regex_search('abc', 'a', '\\g<2>') == 'a'
    assert regex_search('abc', 'a', '\\g<3>') == 'a'
    assert regex_search('abc', 'a', '\\g<4>') == 'a'
    assert regex_search('abc', 'a', '\\g<5>') == 'a'
    assert regex_search('abc', 'a', '\\g<6>') == 'a'
    assert regex_search('abc', 'a', '\\g<7>') == 'a'

# Generated at 2022-06-22 16:35:03.993641
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f'}) == 'a: b\nc: d\ne: f\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}) == 'a: b\nc: d\ne: f\ng: h\n'

# Generated at 2022-06-22 16:35:14.133198
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-22 16:35:22.137881
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [1, 3, 5, 7, 9, 2, 4, 6, 8, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=2) == [1, 3, 5, 7, 9, 2, 4, 6, 8, 10]

# Generated at 2022-06-22 16:35:32.726931
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_timestamp'] = to_timestamp

# Generated at 2022-06-22 16:35:43.377515
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-22 16:35:44.692207
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod(verbose=False)


# Generated at 2022-06-22 16:35:48.267794
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:35:56.054730
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("foo bar baz", "bar") == "bar"
    assert regex_search("foo bar baz", "quux") is None
    assert regex_search("foo bar baz", "^bar") is None
    assert regex_search("foo bar baz", "bar$") is None
    assert regex_search("foo bar baz", "^bar$") is None
    assert regex_search("foo bar baz", "^foo bar baz$") == "foo bar baz"
    assert regex_search("foo bar baz", "baz$") == "baz"
    assert regex_search("foo bar baz", "^foo") == "foo"
    assert regex_search("foo bar baz", "foo") == "foo"

# Generated at 2022-06-22 16:36:08.625662
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == [3, 1, 5, 2, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) != [3, 1, 5, 2, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == randomize_list([1, 2, 3, 4, 5], seed=42)
    assert randomize_list([1, 2, 3, 4, 5], seed=42) != randomize_

# Generated at 2022-06-22 16:36:23.405667
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:36:31.506989
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="msg") == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable not defined."
    try:
        mandatory(AnsibleUndefined, msg="msg")
    except AnsibleFilterError as e:
        assert str(e) == "msg"



# Generated at 2022-06-22 16:36:44.199051
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<2>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\2') == 'foo'
    assert regex_search('foo', 'foo', '\\3') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']

# Generated at 2022-06-22 16:36:58.552742
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) is None
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
        assert False, 'AnsibleUndefined should raise an exception'
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_text(e)


# Generated at 2022-06-22 16:37:03.629135
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'foo\' not defined.' == to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' == to_native(e)



# Generated at 2022-06-22 16:37:13.208974
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'

# Generated at 2022-06-22 16:37:23.245740
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError:
        pass
    else:
        assert False, "mandatory() did not raise AnsibleFilterError"
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert str(e) == 'bar'
    else:
        assert False, "mandatory() did not raise AnsibleFilterError"

