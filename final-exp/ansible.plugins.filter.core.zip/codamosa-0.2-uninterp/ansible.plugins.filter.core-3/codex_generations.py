

# Generated at 2022-06-22 16:28:11.007079
# Unit test for function comment
def test_comment():
    assert comment('foo') == '# foo'
    assert comment('foo', style='erlang') == '% foo'
    assert comment('foo', style='c') == '// foo'
    assert comment('foo', style='cblock') == '/*\n * foo\n */'
    assert comment('foo', style='xml') == '<!--\n - foo\n-->'
    assert comment('foo', decoration='// ') == '// foo'
    assert comment('foo', decoration='// ', style='c') == '// foo'
    assert comment('foo', decoration='// ', style='cblock') == '/*\n * foo\n */'
    assert comment('foo', decoration='// ', style='xml') == '<!--\n - foo\n-->'

# Generated at 2022-06-22 16:28:18.728320
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []

# Generated at 2022-06-22 16:28:28.039669
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == '''\
a: b
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == '''\
a: b
c: d
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f'}) == '''\
a: b
c: d
e: f
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}) == '''\
a: b
c: d
e: f
g: h
'''

# Generated at 2022-06-22 16:28:34.301174
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == 'Mandatory variable \'foo\' not defined.'
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == 'bar'



# Generated at 2022-06-22 16:28:43.981559
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml(dict(a=1, b=2)) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2, width=1) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml(dict(a=1, b=2), indent=2, width=2) == '''\
  a: 1
  b: 2
'''

# Generated at 2022-06-22 16:28:54.137842
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool(None) is None
    assert to_bool([]) is False
    assert to_bool('') is False
    assert to_bool('foo') is False



# Generated at 2022-06-22 16:28:59.716971
# Unit test for function rand
def test_rand():
    assert rand(None, 1, 0, 1, seed=1) == 0
    assert rand(None, 1, 0, 1, seed=2) == 0
    assert rand(None, 1, 0, 1, seed=3) == 0
    assert rand(None, 1, 0, 1, seed=4) == 0
    assert rand(None, 1, 0, 1, seed=5) == 0
    assert rand(None, 1, 0, 1, seed=6) == 0
    assert rand(None, 1, 0, 1, seed=7) == 0
    assert rand(None, 1, 0, 1, seed=8) == 0
    assert rand(None, 1, 0, 1, seed=9) == 0
    assert rand(None, 1, 0, 1, seed=10) == 0

# Generated at 2022-06-22 16:29:04.808521
# Unit test for function comment
def test_comment():
    assert comment('text', 'plain') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='// ') == '// text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2, postfix='// ', postfix_count=2) == '// // text\n// // '

# Generated at 2022-06-22 16:29:14.029833
# Unit test for function rand
def test_rand():
    assert rand(None, 10) in range(10)
    assert rand(None, [1, 2, 3]) in [1, 2, 3]
    assert rand(None, 10, step=2) in [0, 2, 4, 6, 8]
    assert rand(None, 10, start=5) in range(5, 10)
    assert rand(None, 10, start=5, step=2) in [5, 7, 9]
    assert rand(None, 10, seed=1) == 6
    assert rand(None, 10, seed=1) == 6
    assert rand(None, 10, seed=1) == 6
    assert rand(None, 10, seed=2) == 1
    assert rand(None, 10, seed=2) == 1
    assert rand(None, 10, seed=2) == 1
    assert rand

# Generated at 2022-06-22 16:29:19.138519
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo.bar') == r'foo\.bar'
    assert regex_escape(r'foo.bar', re_type='posix_basic') == r'foo\.bar'
    assert regex_escape(r'foo.bar', re_type='posix_extended') == r'foo\.bar'



# Generated at 2022-06-22 16:29:38.812198
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None



# Generated at 2022-06-22 16:29:41.056553
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:29:50.968763
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abc123', r'(\d+)', r'\1') == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True, multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=False) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=True) == 'abc123'

# Generated at 2022-06-22 16:30:00.862909
# Unit test for function combine
def test_combine():
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True) == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True, list_merge='append') == {'a': 1, 'b': 3, 'c': 4}
    assert combine({'a': 1, 'b': 2}, {'b': 3, 'c': 4}, recursive=True, list_merge='prepend') == {'a': 1, 'b': 3, 'c': 4}


# Generated at 2022-06-22 16:30:10.136745
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:30:18.985278
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''\
a: 1
b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''\
  a: 1
  b: 2
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''\
{ a: 1, b: 2 }
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''\
a: 1
b: 2
'''

# Generated at 2022-06-22 16:30:30.779516
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p?') == []
    assert fileglob('/etc/p??') == ['/etc/pam.d']
    assert fileglob('/etc/p*d') == ['/etc/pam.d', '/etc/passwd']
    assert fileglob('/etc/p*d*') == ['/etc/pam.d', '/etc/passwd']
    assert fileglob('/etc/p*d?') == ['/etc/pam.d']

# Generated at 2022-06-22 16:30:38.621669
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_text(e) == "bar"



# Generated at 2022-06-22 16:30:49.529645
# Unit test for function extract
def test_extract():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import filter_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleError
   

# Generated at 2022-06-22 16:30:54.879999
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1') == []

# Generated at 2022-06-22 16:31:13.290454
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'abc']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'def']
    assert regex_search('abcdef', 'abc', '\\g<1>', '\\g<2>') == ['abc', 'abc', 'abc']
    assert regex_search('abcdef', 'def', '\\g<1>', '\\g<2>') == ['def', 'def', 'def']
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 1]

# Generated at 2022-06-22 16:31:24.132267
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'

# Generated at 2022-06-22 16:31:31.041265
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1487693542.0') == '2017-02-22 12:59:02'



# Generated at 2022-06-22 16:31:41.486598
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': {'c': 'd'}}}) == {'b': {'c': 'd'}}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b') == {'c': 'd'}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b', 'c') == 'd'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'

# Generated at 2022-06-22 16:31:52.808646
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', '^abc') == 'abc'
    assert regex_search('abcdef', '^def') is None
    assert regex_search('abcdef', '^def', multiline=True) == 'def'
    assert regex_search('abcdef', '^abc', ignorecase=True) == 'abc'
    assert regex_search('abcdef', '^DEF', ignorecase=True) == 'def'
    assert regex_search('abcdef', '^DEF', ignorecase=False) is None
    assert regex_search('abcdef', '^DEF', multiline=True, ignorecase=True) == 'def'

# Generated at 2022-06-22 16:32:05.224400
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'hello') == 'hello'
    assert regex_search('hello', '^h') == 'h'
    assert regex_search('hello', '^h', '\\g<0>') == ['h', 'hello']
    assert regex_search('hello', '^h', '\\g<0>', '\\g<0>') == ['h', 'hello', 'h', 'hello']
    assert regex_search('hello', '^h', '\\g<0>', '\\g<1>') == ['h', 'hello', 'e', 'ello']
    assert regex_search('hello', '^h', '\\g<0>', '\\g<1>', '\\g<2>') == ['h', 'hello', 'e', 'ello', 'l', 'llo']

# Generated at 2022-06-22 16:32:15.010158
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:32:25.593184
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.jinja2.filters import AnsibleJ2Groupby
    from jinja2.runtime import Context
    from jinja2.environment import Environment
    from jinja2.exceptions import UndefinedError
    from jinja2.utils import contextfunction

    # Create a jinja2 environment
    env = Environment()
    # Add the do_groupby function to the jinja2 environment
    env.filters['groupby'] = contextfunction(do_groupby)

    # Create a jinja2 context
    ctx = Context(env, {'value': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]})

    # Use the do_groupby function to group the data
   

# Generated at 2022-06-22 16:32:38.380671
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>') == 'f'
    assert regex_search('foo', '^f', '\\g<0>', '\\g<0>o') == ['f', 'foo']
    assert regex_search('foo', '^f', '\\g<0>', '\\g<0>o', '\\1') == ['f', 'foo']

# Generated at 2022-06-22 16:32:48.810643
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', style='erlang') == '% test'
    assert comment('test', style='c') == '// test'
    assert comment('test', style='cblock') == '/*\n * test\n */'
    assert comment('test', style='xml') == '<!--\n - test\n-->'
    assert comment('test', decoration='! ') == '! test'
    assert comment('test', newline='\r\n') == '# test'
    assert comment('test', beginning='BEGIN') == 'BEGIN\n# test'
    assert comment('test', prefix='PREFIX') == 'PREFIX\ntest'

# Generated at 2022-06-22 16:33:08.190149
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '  a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'

# Generated at 2022-06-22 16:33:19.248605
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\n  b: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == 'a: 1\nb:\n  2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=3) == 'a: 1\nb: 2\n'
    assert to_nice_y

# Generated at 2022-06-22 16:33:30.651713
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) is None
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(42) == 42
    assert mandatory(42.0) == 42.0
    assert mandatory(42j) == 42j
    assert mandatory('foo') == 'foo'
    assert mandatory(b'foo') == b'foo'
    assert mandatory(u'foo') == u'foo'
    assert mandatory(bytearray(b'foo')) == bytearray(b'foo')
    assert mandatory(u'\u1234') == u'\u1234'
    assert mandatory(u'\u1234'.encode('utf-8')) == u'\u1234'.encode('utf-8')

# Generated at 2022-06-22 16:33:41.819484
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>', '\\g<2>') == ['foo', 'foo', 'foo']

# Generated at 2022-06-22 16:33:53.440199
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:34:05.509599
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'

# Generated at 2022-06-22 16:34:17.189910
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441466') == '2017-03-13 16:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466) == '2017-03-13 16:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.0) == '2017-03-13 16:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.123) == '2017-03-13 16:51:06'

# Generated at 2022-06-22 16:34:26.932019
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// // test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // // test'

# Generated at 2022-06-22 16:34:37.231944
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:34:48.987706
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, indent=2) == '  a: 1\n  b: 2\n'

# Generated at 2022-06-22 16:35:04.751280
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=0) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='  ') == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='\t') == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:35:15.502318
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('hello world', 'md5') == '5eb63bbbe01eeed093cb22bb8f5acdc3'
    assert get_hash('hello world', 'sha1') == '2aae6c35c94fcfb415dbe95f408b9ce91ee846ed'
    assert get_hash('hello world', 'sha224') == 'c8e7b7f04a6d1cdbc9a868fbc5166a6d6b999d7a6a1c17eea9c919'
    assert get_hash('hello world', 'sha256') == 'a591a6d40bf420404a011733cfb7b190d62c65bf0bcda32b57b277d9ad9f146e'

# Generated at 2022-06-22 16:35:27.993699
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    # Test with a defined variable
    assert mandatory('test') == 'test'

    # Test with an undefined variable
    try:
        mandatory(Undefined(name='test'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'test' not defined."
    else:
        assert False

    # Test with an undefined variable and a custom message
    try:
        mandatory(Undefined(name='test'), msg='Custom message')
    except AnsibleFilterError as e:
        assert to_native(e) == "Custom message"
    else:
        assert False

    # Test with an undefined variable and no name

# Generated at 2022-06-22 16:35:39.881738
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_uuid'] = to_uuid
    env.filters['combine'] = combine
    env.filters['comment'] = comment
    env.filters['extract'] = extract
    env.filters['mandatory'] = mandatory
    env.filters['randomize_list'] = randomize_list
    env.filters['get_hash'] = get_hash
    env.filters['get_encrypted_password'] = get_encrypted_password
    env.filters['to_yaml'] = to_yaml
    env.filters['to_json'] = to_json

# Generated at 2022-06-22 16:35:50.325424
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'


# Generated at 2022-06-22 16:35:57.319394
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("abcdef", "abc") == "abc"
    assert regex_search("abcdef", "abc", "\\g<1>") == ["abc", "abc"]
    assert regex_search("abcdef", "abc", "\\1") == ["abc", "abc"]
    assert regex_search("abcdef", "abc", "\\g<1>", "\\1") == ["abc", "abc", "abc", "abc"]
    assert regex_search("abcdef", "abc", "\\g<1>", "\\2") == ["abc", "abc", None, None]
    assert regex_search("abcdef", "abc", "\\g<1>", "\\g<2>") == ["abc", "abc", None, None]

# Generated at 2022-06-22 16:36:01.871200
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y-%m-%d %H:%M:%S", "1405544146") == "2014-07-15 19:29:06"



# Generated at 2022-06-22 16:36:11.113364
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template.safe_eval import unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [
        {'name': 'foo', 'value': 1},
        {'name': 'bar', 'value': 2},
        {'name': 'foo', 'value': 3},
        {'name': 'bar', 'value': 4},
    ]
    template = '{{ data|groupby("name")|list }}'

# Generated at 2022-06-22 16:36:15.681132
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) == [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=42) == [2, 3, 1]



# Generated at 2022-06-22 16:36:26.602148
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(dict(a=1)) == dict(a=1)
    assert mandatory(dict()) == dict()
    assert mandatory(list()) == list()
    assert mandatory(list([1, 2, 3])) == list([1, 2, 3])
    assert mandatory(set()) == set()
    assert mandatory(set([1, 2, 3])) == set([1, 2, 3])
    assert mandatory(tuple()) == tuple()
    assert mandatory(tuple([1, 2, 3])) == tuple([1, 2, 3])

# Generated at 2022-06-22 16:36:43.847831
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(False) == False
    assert mandatory(True) == True

    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass

    try:
        mandatory(AnsibleUndefined, msg='foo')
        assert False
    except AnsibleFilterError as e:
        assert e.message == 'foo'


# Generated at 2022-06-22 16:36:58.552908
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1', '\\g<0>') == ['a', 'a', 'a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1', '\\g<0>', '\\2')

# Generated at 2022-06-22 16:37:05.057066
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='md5') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-22 16:37:14.261696
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import add_directory
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_

# Generated at 2022-06-22 16:37:24.718443
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == []
    assert subelements(obj, 'authorized.0', skip_missing=True) == []