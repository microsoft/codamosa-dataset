

# Generated at 2022-06-22 16:28:12.033928
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441465') == '2017-03-13 21:31:05'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465) == '2017-03-13 21:31:05'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441465.0) == '2017-03-13 21:31:05'
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441465.0') == '2017-03-13 21:31:05'

# Generated at 2022-06-22 16:28:20.829959
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg='foo') == Undefined()
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."
    try:
        mandatory(Undefined(), msg='foo')
    except AnsibleFilterError as e:
        assert to_native(e) == "foo"



# Generated at 2022-06-22 16:28:29.055467
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'



# Generated at 2022-06-22 16:28:32.031388
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:28:40.028660
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        assert True
    try:
        mandatory(AnsibleUndefined, msg='test')
        assert False
    except AnsibleFilterError:
        assert True



# Generated at 2022-06-22 16:28:49.247211
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='; ') == '; test'
    assert comment('test', 'plain', decoration='; ', prefix='; ') == '; test'
    assert comment('test', 'plain', decoration='; ', prefix='; ', prefix_count=2) == '; ; test'

# Generated at 2022-06-22 16:29:00.179286
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars

    templar = Templar(loader=None, variables={})
    templar.environment.filters['groupby'] = do_groupby

    # Test that the filter works with a normal list
    test_list = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    test_list_str = AnsibleUn

# Generated at 2022-06-22 16:29:09.860240
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml([1, 2, 3]) == '''- 1
- 2
- 3
'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}) == '''a: 1
b: 2
c: 3
'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}, indent=2) == '''  a: 1
  b: 2
  c: 3
'''
    assert to_nice_yaml({'a': 1, 'b': 2, 'c': 3}, indent=2, width=20) == '''  a: 1
  b: 2
  c: 3
'''

# Generated at 2022-06-22 16:29:16.455439
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:29:23.459265
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'bar'
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'foo' not defined."



# Generated at 2022-06-22 16:29:37.364696
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('foo', 'oo', 'ee') == 'fee'
    assert regex_replace('foo', 'oo', 'ee', ignorecase=True) == 'fee'
    assert regex_replace('foo', 'oo', 'ee', multiline=True) == 'fee'
    assert regex_replace('foo', 'oo', 'ee', ignorecase=True, multiline=True) == 'fee'
    assert regex_replace('foo', 'oo', 'ee', ignorecase=False, multiline=False) == 'fee'



# Generated at 2022-06-22 16:29:48.581896
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']

# Generated at 2022-06-22 16:29:52.778644
# Unit test for function comment

# Generated at 2022-06-22 16:29:55.788506
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-22 16:30:03.933417
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)



# Generated at 2022-06-22 16:30:16.390336
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from ansible.template.vars import AnsibleJ2Vars

    env = Environment()
    env.filters['groupby'] = do_groupby
    context = Context(environment=env, vars=AnsibleJ2Vars({}))

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    assert [('1', [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), ('2', [{'a': 2, 'b': 4}])] == env.filters['groupby'](context, data, 'a')

# Generated at 2022-06-22 16:30:27.661660
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []

# Generated at 2022-06-22 16:30:38.804796
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']

# Generated at 2022-06-22 16:30:47.676493
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(object()) == object()
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined



# Generated at 2022-06-22 16:31:00.017188
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar

    env = {'variable_manager': {'_fact_cache': {}}}
    templar = Templar(loader=None, variables=env)

    # Create a list of dicts, to be used as input for the groupby filter
    test_list = [
        {'name': 'foo', 'group': 'one'},
        {'name': 'bar', 'group': 'one'},
        {'name': 'baz', 'group': 'two'},
        {'name': 'qux', 'group': 'two'},
    ]

    # Create a list of tuples, to be used as expected output for the groupby filter

# Generated at 2022-06-22 16:31:15.674895
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// // test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // // test'

# Generated at 2022-06-22 16:31:24.614244
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"
    assert mandatory('foo') == 'foo'
    assert mandatory('foo', msg='bar') == 'foo'



# Generated at 2022-06-22 16:31:38.844273
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, width=1) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:31:52.373073
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '  a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=10) == '  a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=5) == 'a: b\nc: d\n'
    assert to_nice_yaml

# Generated at 2022-06-22 16:32:04.734562
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 1]
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', 1, 'a', 1]
    assert regex_search('abc', 'a', '\\g<1>') == ['a', 1]
    assert regex_search('abc', 'a', '\\g<1>', '\\g<1>') == ['a', 1, 'a', 1]
    assert regex

# Generated at 2022-06-22 16:32:08.407865
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined(name='foo')) == 1
    assert mandatory(Undefined(name='foo'), msg='foo is undefined') == 1



# Generated at 2022-06-22 16:32:16.723408
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg="foo") == Undefined()
    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert "Mandatory variable not defined." in to_native(e)

    try:
        mandatory(Undefined(), msg="foo")
    except AnsibleFilterError as e:
        assert "foo" in to_native(e)

    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory("") == ""
    assert mandatory("foo") == "foo"
    assert mandatory([]) == []

# Generated at 2022-06-22 16:32:24.828604
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:32:35.637310
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="test") == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert e.message == "Mandatory variable not defined."
    try:
        mandatory(AnsibleUndefined, msg="test")
    except AnsibleFilterError as e:
        assert e.message == "test"



# Generated at 2022-06-22 16:32:44.597525
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\1', '\\g<1>') == ['a', 'a', 1, 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1', '\\g<1>', '\\2') == ['a', 'a', 1, 'a', 2]

# Generated at 2022-06-22 16:32:54.028463
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}
'''


# Generated at 2022-06-22 16:33:06.855303
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') == ['a', 'a', None, None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>', '\\g<3>') == ['a', 'a', None, None, None]


# Generated at 2022-06-22 16:33:13.954745
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', second=0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))
    assert strftime('%Y-%m-%d %H:%M:%S', second=0.0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0.0))

# Generated at 2022-06-22 16:33:19.431330
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.tests['defined'] = defined
    env.tests['equalto'] = equalto
    env.tests['greaterthan'] = greaterthan
    env.tests['lessthan'] = lessthan
    env.tests['regex_match'] = regex_match
    env.tests['version_compare'] = version_compare
    env.tests['version_compare_simple'] = version_compare_simple
    env.tests['version_compare_special'] = version_compare_special
    env.tests

# Generated at 2022-06-22 16:33:30.989960
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f'}) == 'a: b\nc: d\ne: f\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}) == 'a: b\nc: d\ne: f\ng: h\n'

# Generated at 2022-06-22 16:33:42.385766
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items

    # Test with a list of dicts

# Generated at 2022-06-22 16:33:53.822033
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'

# Generated at 2022-06-22 16:34:05.946223
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables=AnsibleJ2Vars({}))
    # Test with a list of dicts
    test_list = [
        {'a': 1, 'b': 1},
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 1},
        {'a': 2, 'b': 2},
    ]
    # Test with a list of dicts

# Generated at 2022-06-22 16:34:13.754336
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:34:17.401130
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:34:34.311160
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_uuid'] = to_uuid
    env.filters['mandatory'] = mandatory
    env.filters['combine'] = combine
    env.filters['comment'] = comment
    env.filters['extract'] = extract
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml

# Generated at 2022-06-22 16:34:46.447509
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822

# Generated at 2022-06-22 16:34:58.527637
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']

# Generated at 2022-06-22 16:35:10.705154
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
        assert False, "Should have raised an exception"
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable not defined."


# Generated at 2022-06-22 16:35:17.036674
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\g<0>') == ['foo', 'f']
    assert regex_search('foo', '^f', '\\1o') == 'foo'
    assert regex_search('foo', '^f', '\\1o', '\\1') == ['foo', 'f']

# Generated at 2022-06-22 16:35:30.043455
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>') == 'f'
    assert regex_search('foo', 'o$', '\\g<0>') == 'o'
    assert regex_search('foo', 'oo', '\\g<0>') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\1') == ['foo', 'o']
    assert regex_search

# Generated at 2022-06-22 16:35:40.488301
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:35:50.438945
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable' in to_native(e)
    else:
        assert False, 'AnsibleFilterError not raised'

    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)
    else:
        assert False, 'AnsibleFilterError not raised'

    assert mandatory('foo') == 'foo'



# Generated at 2022-06-22 16:35:57.419345
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:36:09.594565
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined

# Generated at 2022-06-22 16:36:27.366386
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', '1']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', '1']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', '1']
    assert regex_search('abc', 'a', '\\1', '\\2') == ['a', '1', '2']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<2>') == ['a', '1', '2']

# Generated at 2022-06-22 16:36:43.105231
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory(['foo']) == ['foo']
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'foo'

    try:
        mandatory(None)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable 'None' not defined."



# Generated at 2022-06-22 16:36:58.552353
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello', 'l') == 'l'
    assert regex_search('hello', 'l', '\\g<0>') == 'l'
    assert regex_search('hello', 'l', '\\g<1>') == 'l'
    assert regex_search('hello', 'l', '\\1') == 'l'
    assert regex_search('hello', 'l', '\\2') == 'l'
    assert regex_search('hello', 'l', '\\g<0>', '\\g<1>') == ['l', 'l']
    assert regex_search('hello', 'l', '\\g<1>', '\\g<0>') == ['l', 'l']
    assert regex_search('hello', 'l', '\\1', '\\2') == ['l', 'l']
    assert regex_

# Generated at 2022-06-22 16:37:05.056647
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def') == 'def'
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<0>') == ['def', 'def']
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<0>', '\\g<0>') == ['def', 'def', 'def', 'def']
    assert regex_search('abcdefghijklmnopqrstuvwxyz', 'def', '\\g<0>', '\\1') == ['def', 'def', 'def', 'def']

# Generated at 2022-06-22 16:37:15.170429
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test with a list of dictionaries
    test_list = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    result = templar._do_groupby(env, test_list, 'a')
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], tuple)
    assert isinstance(result[0][0], AnsibleUnicode)

# Generated at 2022-06-22 16:37:25.077528
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '  a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'