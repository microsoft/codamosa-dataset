

# Generated at 2022-06-22 16:28:05.068844
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, indent=2) == '  a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, indent=2) == '{a: b}\n'

# Generated at 2022-06-22 16:28:16.295010
# Unit test for function comment
def test_comment():
    assert comment('Hello world') == '# Hello world'
    assert comment('Hello world', 'erlang') == '% Hello world'
    assert comment('Hello world', 'c') == '// Hello world'
    assert comment('Hello world', 'cblock') == '/*\n * Hello world\n */'
    assert comment('Hello world', 'xml') == '<!--\n - Hello world\n-->'
    assert comment('Hello world', 'xml', decoration='- ') == '<!--\n- Hello world\n-->'
    assert comment('Hello world', 'xml', decoration='- ', prefix='- ') == '<!--\n- Hello world\n-->'
    assert comment('Hello world', 'xml', decoration='- ', prefix='- ', prefix_count=2) == '<!--\n- - Hello world\n-->'
   

# Generated at 2022-06-22 16:28:26.444925
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.safe_eval import safe_eval

    env = JinjaEnvironment(undefined=StrictUndefined)
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json
    vars = AnsibleJ2Vars(loader=DictDataLoader({}))
    vars.update({'a': [{'b': 1, 'c': 'a'}, {'b': 1, 'c': 'b'}, {'b': 2, 'c': 'c'}]})


# Generated at 2022-06-22 16:28:38.453778
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:28:48.214726
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', 'a(b)c', '\\g<1>') == ['b']
    assert regex_search('abc', 'a(b)c', '\\1') == ['b']
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\1') == ['b', 'b']
    assert regex_search('abc', 'a(b)c', '\\2') == []
    assert regex_search('abc', 'a(b)c', '\\g<2>') == []
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\g<2>') == ['b']

# Generated at 2022-06-22 16:28:52.605933
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False



# Generated at 2022-06-22 16:28:54.824427
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:28:59.007191
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test with a list of namedtuples
    test_list = [
        namedtuple('Test', ['name', 'value'])(name='a', value=1),
        namedtuple('Test', ['name', 'value'])(name='a', value=2),
        namedtuple('Test', ['name', 'value'])(name='b', value=3),
    ]
    # Test with a list of tuples
    test_list_tuples = [
        ('a', 1),
        ('a', 2),
        ('b', 3),
    ]

# Generated at 2022-06-22 16:29:05.994328
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:29:14.055433
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        assert True
    try:
        mandatory(AnsibleUndefined, msg='test')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'test'



# Generated at 2022-06-22 16:29:22.594466
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:29:28.809505
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined



# Generated at 2022-06-22 16:29:38.790401
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:29:49.452449
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(42) == 42
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(b'') == b''
    assert mandatory(bytearray()) == bytearray()
    assert mandatory(memoryview(b'')) == memoryview(b'')


# Generated at 2022-06-22 16:29:57.818204
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']

# Generated at 2022-06-22 16:30:04.278387
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    template = '{{ data|groupby("a")|list }}'
    result = env.from_string(template).render(data=data)
    assert result == "[((1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]),), ((2, [{'a': 2, 'b': 4}]),)]"

    # Test with a list of lists

# Generated at 2022-06-22 16:30:16.648857
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_text(e) == "bar"

    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable not defined."


# Generated at 2022-06-22 16:30:28.076049
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*wd') == ['/etc/passwd']
    assert fileglob('/etc/p*w') == []
    assert fileglob('/etc/p*w*') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d*') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d*s') == []
    assert fileglob('/etc/p*w*d*s*') == []

# Generated at 2022-06-22 16:30:35.469585
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822

# Generated at 2022-06-22 16:30:47.451716
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == 'a: b\n  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, default_flow_style=True) == '{a: b, c: d}\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, default_flow_style=False) == 'a: b\n  c: d\n'
   

# Generated at 2022-06-22 16:31:03.362153
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'


# Generated at 2022-06-22 16:31:07.705877
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=12345) == [2, 1, 5, 3, 4]



# Generated at 2022-06-22 16:31:18.511306
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\1', '\\2') == ['hello', 'world', None]
    assert regex_

# Generated at 2022-06-22 16:31:28.440639
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == '123'
    assert regex_search('abc123', r'\d+', '\\g<1>') == '123'
    assert regex_search('abc123', r'\d+', '\\1') == '123'
    assert regex_search('abc123', r'\d+', '\\2') == None
    assert regex_search('abc123', r'(\d+)(\d+)', '\\g<1>') == '12'
    assert regex_search('abc123', r'(\d+)(\d+)', '\\g<2>') == '3'

# Generated at 2022-06-22 16:31:40.794724
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys='c') == 'b'
    assert extract('a', {'a': 'b'}, morekeys=['c']) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, morekeys='b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c']) == 'c'

# Generated at 2022-06-22 16:31:46.512659
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined(name='foo')) == 1
    assert mandatory(Undefined(name='foo'), msg='bar') == 1
    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError:
        pass
    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError:
        pass



# Generated at 2022-06-22 16:31:53.766594
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'd']
    assert regex_search('abcdef', 'xyz', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\1') == ['def', 'd']
    assert regex_search('abcdef', 'xyz', '\\1') is None
    assert regex_

# Generated at 2022-06-22 16:32:06.081945
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // test'

# Generated at 2022-06-22 16:32:16.185617
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'def', '\\g<0>') == ['def']
    assert regex_search('abcdef', 'def', '\\g<1>') == []
    assert regex_search('abcdef', 'def', '\\g<1>', '\\g<2>') == []
    assert regex_search('abcdef', 'def', '\\g<2>', '\\g<1>') == []
    assert regex_search('abcdef', 'def', '\\g<1>', '\\g<1>') == []

# Generated at 2022-06-22 16:32:24.492825
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(object()) == object()
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='test') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'
    try:
        mandatory(AnsibleUndefined, msg='test')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'test'

# Generated at 2022-06-22 16:32:30.754928
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined()) == None
    assert mandatory(Undefined(), msg='test') == None



# Generated at 2022-06-22 16:32:42.347038
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', second=0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))
    assert strftime('%Y-%m-%d %H:%M:%S', second=1234567890) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(1234567890))
    assert strftime('%Y-%m-%d %H:%M:%S', second='1234567890') == time.str

# Generated at 2022-06-22 16:32:54.530612
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_text(e)
    else:
        assert False, 'AnsibleFilterError not raised'


# Generated at 2022-06-22 16:33:07.465170
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>', '\\g<1>') == ['foo', 'foo', None]

# Generated at 2022-06-22 16:33:18.133808
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None

# Generated at 2022-06-22 16:33:29.607355
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == ['123']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\g<0>') == ['123', '123']
    assert regex_search('abc123', r'\d+', '\\1') == ['1']
    assert regex_search('abc123', r'\d+', '\\1', '\\1') == ['1', '1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\1') == ['123', '1']
    assert regex_search('abc123', r'\d+', '\\1', '\\g<0>')

# Generated at 2022-06-22 16:33:40.471039
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB') == 'ABcdef'
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB', ignorecase=True) == 'ABcdef'
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB', ignorecase=False) == 'ABcdef'
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB', multiline=True) == 'ABcdef'
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB', multiline=False) == 'ABcdef'
    assert regex_replace(value='abcdef', pattern='^ab', replacement='AB', ignorecase=True, multiline=True) == 'ABcdef'
    assert regex_

# Generated at 2022-06-22 16:33:52.465466
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix_count=2) == '; \ntext'
    assert comment('text', 'plain', decoration='; ', postfix_count=2) == '; text\n; '
    assert comment('text', 'plain', decoration='; ', prefix_count=2, postfix_count=2) == '; \ntext\n; '

# Generated at 2022-06-22 16:34:03.512532
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1', skip_missing=True) == []


# Generated at 2022-06-22 16:34:17.157376
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1405544146') == '2014-07-15 01:02:26'
    assert strftime('%Y-%m-%d %H:%M:%S', 1405544146) == '2014-07-15 01:02:26'
    assert strftime('%Y-%m-%d %H:%M:%S', 1405544146.0) == '2014-07-15 01:02:26'
    assert strftime('%Y-%m-%d %H:%M:%S', 1405544146.5) == '2014-07-15 01:02:26'

# Generated at 2022-06-22 16:34:28.664118
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == [2, 1, 5, 3, 4]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != randomize_list([1, 2, 3, 4, 5], seed=2)
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == randomize_list([1, 2, 3, 4, 5], seed=1)



# Generated at 2022-06-22 16:34:39.970195
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert to_text(e) == "bar"

    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0) == 0
    assert mandatory(1) == 1
   

# Generated at 2022-06-22 16:34:43.695824
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:34:56.077109
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1, b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=10) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=9) == '''{
  a: 1,
  b: 2
}'''

# Generated at 2022-06-22 16:35:03.862391
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.safe_eval import safe_eval

    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 1}, {'a': 2, 'b': 2}, {'a': 1, 'b': 3}]
    template = '{{ data|groupby("a")|list }}'
    result = env.from_string(template).render(data=data)
    assert safe_eval(result) == [[(1, [{'a': 1, 'b': 1}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 2}])]]

    # Test with a list of lists
    data

# Generated at 2022-06-22 16:35:14.366505
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', second=0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))
    assert strftime('%Y-%m-%d %H:%M:%S', second=0.0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))

# Generated at 2022-06-22 16:35:20.621597
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_native(e)



# Generated at 2022-06-22 16:35:32.490615
# Unit test for function comment
def test_comment():
    assert comment('text', style='plain') == '# text'
    assert comment('text', style='erlang') == '% text'
    assert comment('text', style='c') == '// text'
    assert comment('text', style='cblock') == '/*\n * text\n */'
    assert comment('text', style='xml') == '<!--\n - text\n-->'
    assert comment('text', style='plain', decoration='; ') == '; text'
    assert comment('text', style='plain', decoration='; ', newline='\r\n') == '; text'
    assert comment('text', style='plain', decoration='; ', newline='\r\n', prefix='', prefix_count=0) == '; text'

# Generated at 2022-06-22 16:35:43.139725
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == '''\
a: b
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == '''\
a: b
c: d
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '''\
  a: b
  c: d
'''
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=1) == '''\
a: b
c: d
'''

# Generated at 2022-06-22 16:35:52.305029
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', 1]
    assert regex_search('abc', 'a', '\\1', '\\1') == ['a', 1, 'a', 1]
    assert regex_search('abc', 'a', '\\g<1>') == ['a', 1]
    assert regex_search('abc', 'a', '\\g<1>', '\\g<1>') == ['a', 1, 'a', 1]
    assert regex

# Generated at 2022-06-22 16:36:08.098967
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    t = env.from_string("{{ [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}] | groupby('a') | list }}")
    assert t.render() == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"



# Generated at 2022-06-22 16:36:14.461151
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.template.safe_eval import safe_eval
    from ansible.template.vars import AnsibleJ2Vars

    # Create a jinja2 environment
    j2_env = Environment(loader=DictLoader({}), extensions=['jinja2.ext.do'])
    j2_env.filters['groupby'] = do_groupby

    # Create a jinja2 context
    j2_ctx = Context(j2_env, {}, None, AnsibleJ2Vars({}))

    # Create a list of dicts

# Generated at 2022-06-22 16:36:26.205615
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\1') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\1', '\\0') == ['foo', 'foo']

# Generated at 2022-06-22 16:36:33.787779
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json

    # Test with a list of dicts
    data = [
        {'key': 'a', 'value': 1},
        {'key': 'a', 'value': 2},
        {'key': 'b', 'value': 3},
        {'key': 'b', 'value': 4},
        {'key': 'c', 'value': 5},
        {'key': 'c', 'value': 6},
    ]
    template = '{{ data | groupby("key") | to_json }}'

# Generated at 2022-06-22 16:36:39.500006
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    try:
        mandatory(None)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    try:
        mandatory(None, msg='foo')
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)



# Generated at 2022-06-22 16:36:45.132899
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    try:
        mandatory(AnsibleUndefined, msg='foo')
    except AnsibleFilterError as e:
        assert 'foo' in to_native(e)



# Generated at 2022-06-22 16:36:51.270953
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="msg") == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="msg") == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="msg") == AnsibleUndefined



# Generated at 2022-06-22 16:36:55.274000
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:37:09.053937
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdefghi', 'def') == 'def'
    assert regex_search('abcdefghi', 'def', '\\g<0>') == ['def']
    assert regex_search('abcdefghi', 'def', '\\g<0>', '\\g<0>') == ['def', 'def']
    assert regex_search('abcdefghi', 'def', '\\g<0>', '\\2') == ['def', 'ef']
    assert regex_search('abcdefghi', 'def', '\\g<0>', '\\2', '\\g<0>') == ['def', 'ef', 'def']

# Generated at 2022-06-22 16:37:16.271893
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get