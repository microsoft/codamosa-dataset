

# Generated at 2022-06-22 16:28:06.658708
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_native(e)

# Generated at 2022-06-22 16:28:18.105956
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json

    # Test with a list of dicts
    data = [
        {'name': 'foo', 'group': 'one'},
        {'name': 'bar', 'group': 'two'},
        {'name': 'baz', 'group': 'one'},
        {'name': 'qux', 'group': 'two'},
    ]
    template = env.from_string("{{ data | groupby('group') | to_json }}")

# Generated at 2022-06-22 16:28:29.101539
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='; ') == '; test'
    assert comment('test', 'plain', decoration='; ', newline='\r\n') == '; test'
    assert comment('test', 'plain', decoration='; ', newline='\r\n', prefix='; ') == '; test'

# Generated at 2022-06-22 16:28:40.211204
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False, 'should have raised an exception'
    except AnsibleFilterError as e:
        assert str(e) == 'foo'

    try:
        mandatory(None)
        assert False, 'should have raised an exception'
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'


# Generated at 2022-06-22 16:28:49.343182
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_uuid'] = to_uuid
    env.filters['to_json'] = to_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822
    env.filters['to_timestamp'] = to_timestamp

# Generated at 2022-06-22 16:28:58.009194
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(1) == 1
    assert mandatory(Undefined()) == Undefined()
    assert mandatory(Undefined(), msg='foo') == Undefined()
    assert mandatory(Undefined(name='bar'), msg='foo') == Undefined()
    assert mandatory(Undefined(name='bar'), msg='foo') == Undefined()

    try:
        mandatory(Undefined())
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)
    else:
        assert False, 'AnsibleFilterError not raised'

    try:
        mandatory(Undefined(name='bar'))
    except AnsibleFilterError as e:
        assert 'Mandatory variable \'bar\' not defined' in to_native(e)

# Generated at 2022-06-22 16:29:10.949613
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Jinja2Environment
    env = Jinja2Environment(extensions=['jinja2.ext.do'])
    env.filters['groupby'] = do_groupby
    template = env.from_string('''
{%- set data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}] -%}
{%- for group in data | groupby('a') %}
{{ group.grouper }}: {{ group.list }}
{%- endfor %}
''')
    assert template.render() == '''
1: [{'a': 1, 'b': 2}, {'a': 1, 'b': 5}]
3: [{'a': 3, 'b': 4}]
'''

# Generated at 2022-06-22 16:29:20.259014
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert 'foo' in to_text(e)
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert 'bar' in to_text(e)



# Generated at 2022-06-22 16:29:27.190618
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups', skip_missing=True) == []
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]

# Generated at 2022-06-22 16:29:36.220531
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:29:48.132175
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    t = env.from_string("{{ [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}] | groupby('a') | list }}")
    assert t.render() == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]"



# Generated at 2022-06-22 16:29:56.921255
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style='not none') == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style='') == '{a: b}\n'

# Generated at 2022-06-22 16:30:03.478702
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('abc123', r'(\d+)', r'\1') == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=True, multiline=True) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=False) == 'abc123'
    assert regex_replace('abc123', r'(\d+)', r'\1', ignorecase=False, multiline=True) == 'abc123'

# Generated at 2022-06-22 16:30:11.802145
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None

# Generated at 2022-06-22 16:30:21.755616
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=0) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='  ') == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent='\t') == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:30:32.900874
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) is None
    assert mandatory(True) is True
    assert mandatory(False) is False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(u'foo') == u'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')


# Generated at 2022-06-22 16:30:38.430178
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='invalid') == 'foo\\.bar'



# Generated at 2022-06-22 16:30:49.366555
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:31:00.830695
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', 'a(b)c', '\\g<1>') == ['b']
    assert regex_search('abc', 'a(b)c', '\\1') == ['b']
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\1') == ['b', 'b']
    assert regex_search('abc', 'a(b)c', '\\2') == []
    assert regex_search('abc', 'a(b)c', '\\g<2>') == []
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\g<2>') == ['b']

# Generated at 2022-06-22 16:31:11.513088
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B', ignorecase=True) == 'abcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B', ignorecase=False) == 'abcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'

# Generated at 2022-06-22 16:31:26.004584
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Jinja2Environment
    from ansible.template.safe_eval import safe_eval

    env = Jinja2Environment(Environment())
    env.filters['groupby'] = do_groupby

    # Test that the filter works with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    result = env.from_string('{{ data|groupby("a") }}').render(data=data)
    assert safe_eval(result) == {1: [{'a': 1, 'b': 2}, {'a': 1, 'b': 5}], 3: [{'a': 3, 'b': 4}]}

    # Test that the filter

# Generated at 2022-06-22 16:31:31.980819
# Unit test for function comment
def test_comment():
    assert comment('text', 'plain') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='// ') == '// text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2, postfix='// ', postfix_count=2) == '// // text\n// // '

# Generated at 2022-06-22 16:31:36.105654
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictLoader
    from jinja2.environment import Environment
    from jinja2.runtime import Context
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    env = Environment(loader=DictLoader({'template': '{{ data|groupby("key") }}'}))
    template = env.get_template('template')
    data = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}, {'key': 'a', 'value': 3}]
    context = Context(environment=env, vars={'data': data})
    template.environment.filters['groupby'] = do_groupby

# Generated at 2022-06-22 16:31:44.863138
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]

# Generated at 2022-06-22 16:31:57.266756
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template.safe_eval import AnsibleUnsafe
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.safe_eval import ansible_unsafe_eval

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [
        {'a': 1, 'b': 1},
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 1},
        {'a': 2, 'b': 2},
    ]
    template = '{{ data|groupby("a")|list }}'
    result = env.from_string(template).render(data=data)
    assert ansible_safe_eval(result)

# Generated at 2022-06-22 16:32:03.873221
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', hashtype='sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'

# Generated at 2022-06-22 16:32:14.116814
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*d') == ['/etc/passwd']
    assert fileglob('/etc/p*d*') == ['/etc/passwd']
    assert fileglob('/etc/p*d*e') == []
    assert fileglob('/etc/p*d*e*') == []
    assert fileglob('/etc/p*d*e*f') == []
    assert fileglob('/etc/p*d*e*f*') == []

# Generated at 2022-06-22 16:32:24.879706
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', ['c']) == 'c'

# Generated at 2022-06-22 16:32:37.672501
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(42) == 42
    assert mandatory(42.0) == 42.0
    assert mandatory(42.0 + 0.0j) == 42.0 + 0.0j
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(b'foo') == b'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}

    try:
        mandatory(None, 'foo')
        assert False
    except AnsibleFilterError as e:
        assert str(e) == 'foo'

# Generated at 2022-06-22 16:32:41.066421
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == [2, 4, 1, 5, 3]



# Generated at 2022-06-22 16:32:55.351923
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', hashtype='sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:33:07.900459
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    try:
        mandatory(None)
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable not defined."
    try:
        mandatory(None, msg="foo")
    except AnsibleFilterError as e:
        assert to_text(e) == "foo"
    try:
        mandatory(None, msg="foo {{ bar }}")
    except AnsibleFilterError as e:
        assert to_text(e) == "foo {{ bar }}"
    try:
        mandatory(None, msg="foo {{ bar }}")
    except AnsibleFilterError as e:
        assert to_text(e) == "foo {{ bar }}"

# Generated at 2022-06-22 16:33:12.717253
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-22 16:33:23.615217
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from jinja2.runtime import Undefined
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader
    from jinja2.exceptions import UndefinedError

    env = Environment(loader=DictLoader({}))

    # Test with undefined value
    value = Undefined(name='value')
    attribute = 'foo'
    assert do_groupby(env, value, attribute) == []

    # Test with undefined attribute
    value = [{'foo': 'bar'}]
    attribute = Undefined(name='attribute')
    assert do_groupby(env, value, attribute) == []

    # Test with undefined attribute and value
    value = Undefined(name='value')

# Generated at 2022-06-22 16:33:35.193477
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1', '\\2') == ['a', 'a', 'a', 'a']

# Generated at 2022-06-22 16:33:46.601730
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:33:57.661711
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized', skip_missing=True) == []

# Generated at 2022-06-22 16:34:09.648202
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c', 'd']) == 'c'

# Generated at 2022-06-22 16:34:22.240940
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441466') == '2017-03-13 18:11:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466) == '2017-03-13 18:11:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.0) == '2017-03-13 18:11:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.123456) == '2017-03-13 18:11:06'

# Generated at 2022-06-22 16:34:32.734674
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822

# Generated at 2022-06-22 16:34:52.277518
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') is None
    assert regex_search('foo', 'f(o)o', '\\g<2>') is None
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') is None

# Generated at 2022-06-22 16:35:02.175351
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\1') == ['o']

# Generated at 2022-06-22 16:35:05.636100
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'



# Generated at 2022-06-22 16:35:10.749997
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(True) == True
    assert mandatory(False) == False



# Generated at 2022-06-22 16:35:21.056879
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:35:32.523833
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', '1']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', '1']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', '1']
    assert regex_search('abc', 'a', '\\1', '\\g<0>') == ['a', '1', 'a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a', '1', 'a']

# Generated at 2022-06-22 16:35:45.438176
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') == ['a', 'a', None, None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>', '\\g<3>') == ['a', 'a', None, None, None]


# Generated at 2022-06-22 16:35:53.874890
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:35:59.600722
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822
    env.filters['to_local']

# Generated at 2022-06-22 16:36:10.052867
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json

    # Test with a list of dicts

# Generated at 2022-06-22 16:36:30.742236
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'

    assert comment('test', 'plain', decoration='// ') == '// test'
    assert comment('test', 'plain', decoration='// ', prefix='// ') == '// // test'
    assert comment('test', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // // test'
    assert comment('test', 'plain', decoration='// ', postfix='// ', postfix_count=2) == '// test\n// //'
   

# Generated at 2022-06-22 16:36:43.712397
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3]) != [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=1) == [2, 3, 1]
    assert randomize_list([1, 2, 3], seed=2) == [3, 1, 2]
    assert randomize_list([1, 2, 3], seed=3) == [1, 2, 3]
    assert randomize_list([1, 2, 3], seed=4) == [3, 1, 2]
    assert randomize_list([1, 2, 3], seed=5) == [2, 3, 1]
    assert randomize_list([1, 2, 3], seed=6) == [1, 2, 3]

# Generated at 2022-06-22 16:36:58.552649
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('test', '^t') == 't'
    assert regex_search('test', '^t', '\\g<0>') == 't'
    assert regex_search('test', '^t', '\\g<0>', '\\g<0>') == ['t', 't']
    assert regex_search('test', '^t', '\\g<0>', '\\1') == ['t', 't']
    assert regex_search('test', '^t', '\\g<0>', '\\2') == ['t', None]
    assert regex_search('test', '^t', '\\g<0>', '\\g<0>', '\\g<0>') == ['t', 't', 't']

# Generated at 2022-06-22 16:37:05.056713
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_uuid'] = to_uuid
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_json'] = to_json
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml

# Generated at 2022-06-22 16:37:15.066395
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\g<1>') == [None]
    assert regex_search('abc', 'a', '\\g<1>', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:37:25.028945
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == 'a'
    assert regex_search('abc', 'a', '\\g<1>') == 'a'
    assert regex_search('abc', 'a', '\\g<2>') == 'a'
    assert regex_search('abc', 'a', '\\g<3>') == 'a'
    assert regex_search('abc', 'a', '\\g<4>') == 'a'
    assert regex_search('abc', 'a', '\\g<5>') == 'a'
    assert regex_search('abc', 'a', '\\g<6>') == 'a'
    assert regex_search('abc', 'a', '\\g<7>') == 'a'

# Generated at 2022-06-22 16:37:31.516984
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\g<0>') == ['foo', 'f']
    assert regex_search('foo', '^f', '\\g<0>o', '\\1') == ['foo', 'o']
    assert regex_search('foo', '^f', '\\g<0>o', '\\2') == ['foo', None]