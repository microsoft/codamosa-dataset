

# Generated at 2022-06-22 16:28:03.717758
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory(()) == ()
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert str(e) == 'Mandatory variable not defined.'

# Generated at 2022-06-22 16:28:13.255785
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool('true') is True
    assert to_bool('false') is False
    assert to_bool('yes') is True
    assert to_bool('no') is False
    assert to_bool('on') is True
    assert to_bool('off') is False
    assert to_bool('1') is True
    assert to_bool('0') is False
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool([]) is False
    assert to_bool('') is False
    assert to_bool('foo') is False



# Generated at 2022-06-22 16:28:24.469306
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract

# Generated at 2022-06-22 16:28:35.039326
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, width=1) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, width=2) == 'a: b\n'

# Generated at 2022-06-22 16:28:45.176311
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined.' in to_native(e)

# Generated at 2022-06-22 16:28:55.744623
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(()) == ()
    assert mandatory(set()) == set()
    assert mandatory(frozenset()) == frozenset()
    assert mandatory(range(0, 10)) == range(0, 10)
    assert mandatory(xrange(0, 10)) == xrange(0, 10)
    assert mandatory(bytearray(b'foo')) == bytearray(b'foo')
    assert mandatory(memoryview(b'foo')) == memoryview(b'foo')
    assert mandatory(re.compile('foo'))

# Generated at 2022-06-22 16:29:04.235514
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:29:13.904912
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:29:24.034392
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(object()) == object()
    assert mandatory(object) == object
    assert mandatory(mandatory) == mandatory
    assert mandatory(test_mandatory) == test_mandatory
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')
    assert mandatory(AnsibleUndefined('foo'), msg='foo') == AnsibleUndefined('foo')

# Generated at 2022-06-22 16:29:36.535362
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<3>')

# Generated at 2022-06-22 16:29:50.447978
# Unit test for function extract
def test_extract():
    assert extract({}, 'a', {'a': 'b'}) == 'b'
    assert extract({}, 'a', {'a': 'b'}, 'c') == 'b'
    assert extract({}, 'a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract({}, 'a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract({}, 'a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract({}, 'a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'

# Generated at 2022-06-22 16:29:58.459922
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == ''
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', '']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>', '\\g<2>') == ['foo', '', '']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>', '\\g<2>', '\\g<3>') == ['foo', '', '', '']

# Generated at 2022-06-22 16:30:04.751008
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.tests['dict'] = lambda v: isinstance(v, dict)
    template = env.from_string("""
        {% set data = [
            {'name': 'foo', 'group': 'one'},
            {'name': 'bar', 'group': 'one'},
            {'name': 'baz', 'group': 'two'},
            {'name': 'qux', 'group': 'two'},
        ] %}
        {% for group, items in data|groupby('group') %}
            {{ group }}:
            {% for item in items %}
                {{ item.name }}
            {% endfor %}
        {% endfor %}
    """)

# Generated at 2022-06-22 16:30:16.648753
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    env = Environment()
    templar = Templar(loader=None, variables={})
    value = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}]
    attribute = 'a'
    result = do_groupby(env, value, attribute)
    assert result == [
        (1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 5}]),
        (3, [{'a': 3, 'b': 4}])
    ]

    # Test that the result is safe to eval
    # This is the issue that this function is addressing


# Generated at 2022-06-22 16:30:22.230905
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['groupby'] == do_groupby
    assert fm.filters()['b64decode'] == b64decode
    assert fm.filters()['b64encode'] == b64encode
    assert fm.filters()['to_uuid'] == to_uuid
    assert fm.filters()['to_json'] == to_json
    assert fm.filters()['to_nice_json'] == to_nice_json
    assert fm.filters()['from_json'] == json.loads
    assert fm.filters()['to_yaml'] == to_yaml
    assert fm.filters()['to_nice_yaml'] == to_nice_yaml

# Generated at 2022-06-22 16:30:27.284397
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5], seed=42) == [4, 2, 5, 3, 1]



# Generated at 2022-06-22 16:30:39.466751
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=False) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True, multiline=True) == 'aBcd'

# Generated at 2022-06-22 16:30:45.376835
# Unit test for function randomize_list
def test_randomize_list():
    mylist = [1, 2, 3, 4, 5]
    assert randomize_list(mylist) != mylist
    assert randomize_list(mylist, seed=1) == [5, 1, 3, 4, 2]



# Generated at 2022-06-22 16:30:59.929395
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:31:10.771850
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'a': 2}, {'a': 3}) == {'a': 3}
    assert combine({'a': 1}, {'a': {'b': 2}}, {'a': {'c': 3}}) == {'a': {'b': 2, 'c': 3}}
    assert combine({'a': 1}, {'a': {'b': 2}}, {'a': {'b': 3}}) == {'a': {'b': 3}}

# Generated at 2022-06-22 16:31:25.043481
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 1}) == 1
    assert extract('a', {'a': {'b': 2}}) == {'b': 2}
    assert extract('a', {'a': {'b': 2}}, 'b') == 2
    assert extract('a', {'a': {'b': 2}}, ['b']) == 2
    assert extract('a', {'a': {'b': 2}}, ['b', 'c']) == 2
    assert extract('a', {'a': {'b': 2}}, ['b', 'c']) == 2
    assert extract('a', {'a': {'b': {'c': 3}}}, ['b', 'c']) == 3

# Generated at 2022-06-22 16:31:33.121402
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:31:45.252339
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489449600') == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489449600) == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489449600.0) == '2017-03-13 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', '1489449600.0') == '2017-03-13 00:00:00'

# Generated at 2022-06-22 16:31:50.251245
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == ['/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls']



# Generated at 2022-06-22 16:32:02.850381
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=2) == [1, 2, 3]
    assert flatten([1, [2, [3]]], levels=1) == [1, 2, [3]]
    assert flatten([1, [2, [3]]], levels=0) == [1, [2, [3]]]
    assert flatten([1, [2, [3]]], levels=None) == [1, 2, 3]

# Generated at 2022-06-22 16:32:13.340029
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1407441200') == '2014-08-08 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1407441200) == '2014-08-08 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1407441200.0) == '2014-08-08 00:00:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1407441200.12345) == '2014-08-08 00:00:00'

# Generated at 2022-06-22 16:32:24.035823
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S') == time.strftime('%Y-%m-%d %H:%M:%S')
    assert strftime('%Y-%m-%d %H:%M:%S', second=0) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(0))
    assert strftime('%Y-%m-%d %H:%M:%S', second=1) == time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(1))

# Generated at 2022-06-22 16:32:36.826738
# Unit test for function rand
def test_rand():
    assert rand(None, 1, 0, 1) == 0
    assert rand(None, 1, 0, 1, seed=1) == 0
    assert rand(None, 1, 0, 1, seed=2) == 0
    assert rand(None, 1, 0, 1, seed=3) == 0
    assert rand(None, 1, 0, 1, seed=4) == 0
    assert rand(None, 1, 0, 1, seed=5) == 0
    assert rand(None, 1, 0, 1, seed=6) == 0
    assert rand(None, 1, 0, 1, seed=7) == 0
    assert rand(None, 1, 0, 1, seed=8) == 0
    assert rand(None, 1, 0, 1, seed=9) == 0

# Generated at 2022-06-22 16:32:42.771966
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []
    assert fileglob('/etc/p*wd') == ['/etc/passwd']
    assert fileglob('/etc/p*w') == []



# Generated at 2022-06-22 16:32:54.600376
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1449011400') == '2015-12-10 10:30:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449011400) == '2015-12-10 10:30:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449011400.0) == '2015-12-10 10:30:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1449011400.1) == '2015-12-10 10:30:00'

# Generated at 2022-06-22 16:33:02.967692
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:33:15.145808
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'

# Generated at 2022-06-22 16:33:19.612498
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', hashtype='md5') == '098f6bcd4621d373cade4e832627b4f6'



# Generated at 2022-06-22 16:33:31.161581
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:33:38.003179
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'ghi') is None
    assert regex_search('abcdef', 'abc', '\\g<1>') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\g<1>') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\g<1>') is None
    assert regex_search('abcdef', 'abc', '\\1') == ['abc', 'a']
    assert regex_search('abcdef', 'def', '\\1') == ['def', 'd']
    assert regex_search('abcdef', 'ghi', '\\1') is None
    assert regex_

# Generated at 2022-06-22 16:33:49.439723
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False, width=1) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True, width=1) == '{a: b}\n'

# Generated at 2022-06-22 16:34:01.197945
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:34:11.919450
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'

# Generated at 2022-06-22 16:34:23.479623
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', ['c']) == 'c'

# Generated at 2022-06-22 16:34:30.326900
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [8, 9, 5, 3, 1, 6, 10, 4, 7, 2]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=2) == [4, 1, 6, 10, 9, 3, 7, 5, 8, 2]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=3) == [3, 8, 9, 2, 1, 5, 6, 10, 4, 7]

# Generated at 2022-06-22 16:34:46.597511
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"



# Generated at 2022-06-22 16:34:58.706243
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '''{a: 1, b: 2}
'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == '''{
  a: 1,
  b: 2
}
'''

# Generated at 2022-06-22 16:35:10.972894
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a', None]
    assert regex_search('abc', 'a', '\\g<1>', '\\g<0>') == ['a', None, 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', None]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') == ['a', 'a', None, None]

# Generated at 2022-06-22 16:35:17.085145
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:35:30.073196
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a', 'a']
    assert regex_search('abc', 'a', '\\1') == ['a', None]
    assert regex_search('abc', 'a', '\\1', '\\2') == ['a', None, None, None]
    assert regex_search('abc', 'a', '\\1', '\\2', '\\g<0>') == ['a', None, None, None, 'a', 'a']

# Generated at 2022-06-22 16:35:42.114652
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:35:51.872448
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import add_directory
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader

    # Load

# Generated at 2022-06-22 16:35:58.369984
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.template import Jinja2Template
    from ansible.template.safe_eval import safe_eval

    env = Environment(loader=DictLoader({'test.j2': '{{ [{ "a": 1, "b": 2 }, { "a": 1, "b": 3 }] | groupby("a") }}'}))
    template = env.get_template('test.j2')
    context = Context(environment=env, name='test.j2')
    j2_t = Jinja2Template(template)
    result = j2_t.render(context)

# Generated at 2022-06-22 16:36:09.859030
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'

    assert comment('text', 'cblock', decoration='* ') == '/*\n * text\n */'
    assert comment('text', 'cblock', decoration='* ', prefix='* ') == '/*\n * text\n */'
    assert comment('text', 'cblock', decoration='* ', prefix='* ', prefix_count=2) == '/*\n * * text\n */'

# Generated at 2022-06-22 16:36:23.138342
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c', 'd']) == 'c'

# Generated at 2022-06-22 16:36:34.172592
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 'b'}) == 'a: b\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}) == 'a: b\n' + 'c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2) == '  a: b\n' + '  c: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=1) == 'a: b\nc: d\n'
    assert to_nice_yaml({'a': 'b', 'c': 'd'}, indent=2, width=2) == 'a: b\nc: d\n'
    assert to_

# Generated at 2022-06-22 16:36:45.475839
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\1') == ['1']
    assert regex_search('abc123', r'\d+', '\\g<1>') == ['1']
    assert regex_search('abc123', r'(?P<digits>\d+)', '\\g<digits>') == ['123']
    assert regex_search('abc123', r'(?P<digits>\d+)', '\\g<digits>', '\\g<digits>') == ['123', '123']
    assert regex_search('abc123', r'(?P<digits>\d+)', '\\g<digits>', '\\2') == ['123', '123']
    assert regex_search

# Generated at 2022-06-22 16:36:52.854313
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == ''
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == ['', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>', '\\g<2>') == ['', 'foo', '']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>', '\\g<2>', '\\g<3>') == ['', 'foo', '', '']

# Generated at 2022-06-22 16:37:01.933978
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == ['/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lslk']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lslk', '/bin/lsblk']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lslk', '/bin/lsblk', '/bin/lsattr']

# Generated at 2022-06-22 16:37:09.657502
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': 'b'}, morekeys='c') == 'b'
    assert extract('a', {'a': {'b': 'c'}}, morekeys='b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, morekeys=['b', 'c']) == 'c'



# Generated at 2022-06-22 16:37:22.396963
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'