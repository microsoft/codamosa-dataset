

# Generated at 2022-06-22 16:28:09.339132
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None



# Generated at 2022-06-22 16:28:17.707205
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo') == 'foo'
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'
    assert regex_escape('foo[bar]') == 'foo\\[bar\\]'
    assert regex_escape('foo[bar]', re_type='posix_basic') == 'foo\\[bar\\]'
    assert regex_escape('foo[bar]', re_type='posix_extended') == 'foo\\[bar\\]'
    assert regex_escape('foo$bar') == 'foo\\$bar'

# Generated at 2022-06-22 16:28:30.853187
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_executor import PlayExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats

# Generated at 2022-06-22 16:28:40.441943
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/shadow') == []

# Generated at 2022-06-22 16:28:45.780945
# Unit test for function combine
def test_combine():
    assert combine({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1}, {'a': 2}, {'a': 3}) == {'a': 3}
    assert combine({'a': 1}, {'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}
    assert combine({'a': 1}, {'b': 2}, {'a': 3, 'b': 4}) == {'a': 3, 'b': 4}
    assert combine({'a': 1}, {'b': 2}, {'a': 3, 'b': 4}, {'a': 5}) == {'a': 5, 'b': 4}
   

# Generated at 2022-06-22 16:28:56.051975
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abc123def', pattern='[0-9]+', replacement='#') == 'abc#def'
    assert regex_replace(value='abc123def', pattern='[0-9]+', replacement='#', ignorecase=True) == 'abc#def'
    assert regex_replace(value='abc123def', pattern='[0-9]+', replacement='#', multiline=True) == 'abc#def'
    assert regex_replace(value='abc123def', pattern='[0-9]+', replacement='#', ignorecase=True, multiline=True) == 'abc#def'
    assert regex_replace(value='abc123def', pattern='[0-9]+', replacement='#', ignorecase=False, multiline=False) == 'abc#def'

# Generated at 2022-06-22 16:29:05.430829
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    try:
        mandatory(Undefined(name='foo'), msg='bar')
    except AnsibleFilterError as e:
        assert to_text(e) == 'bar'
    try:
        mandatory(Undefined(name='foo'))
    except AnsibleFilterError as e:
        assert to_text(e) == "Mandatory variable 'foo' not defined."



# Generated at 2022-06-22 16:29:14.211320
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=3) == 'a: 1\nb: 2\n'

# Generated at 2022-06-22 16:29:24.259198
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == ['/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lss']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lss', '/bin/lsss']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/lss', '/bin/lsss', '/bin/lssss']

# Generated at 2022-06-22 16:29:30.850574
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'



# Generated at 2022-06-22 16:29:41.581381
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template.safe_eval import safe_eval
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.utils import contextfunction

    env = Environment()
    env.filters['groupby'] = contextfunction(do_groupby)

    # Create a list of namedtuples
    from collections import namedtuple
    TestTuple = namedtuple('TestTuple', ['a', 'b'])
    test_data = [TestTuple(1, 2), TestTuple(1, 3), TestTuple(2, 4)]

    # Create a jinja2 context
    ctx = Context(env, dict(data=test_data))

    # Create a jinja2 template

# Generated at 2022-06-22 16:29:51.282613
# Unit test for function rand
def test_rand():
    assert rand(None, 10) in range(10)
    assert rand(None, 10, step=2) in range(0, 10, 2)
    assert rand(None, 10, start=2) in range(2, 10)
    assert rand(None, 10, start=2, step=2) in range(2, 10, 2)
    assert rand(None, [1, 2, 3]) in [1, 2, 3]
    assert rand(None, 'abc') in ['a', 'b', 'c']
    assert rand(None, 'abc', seed=1) == 'b'
    assert rand(None, 'abc', seed=1) == 'b'
    assert rand(None, 'abc', seed=1) == 'b'
    assert rand(None, 'abc', seed=2) == 'c'
    assert rand

# Generated at 2022-06-22 16:30:00.916565
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([1, [2, 3]]) == [1, 2, 3]
    assert flatten([1, [2, [3]]]) == [1, 2, 3]
    assert flatten([1, [2, [3, [4]]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4]]]], levels=2) == [1, 2, 3, [4]]
    assert flatten([1, [2, [3, [4]]]], levels=1) == [1, 2, [3, [4]]]

# Generated at 2022-06-22 16:30:06.672499
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_uuid'] = to_uuid
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_csv'] = to_csv
    env.filters['to_toml'] = to_toml
    env.filters['to_ini'] = to_ini
    env.filters['to_xml'] = to_xml

# Generated at 2022-06-22 16:30:20.915417
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    from ansible.template import Templar

    templar = Templar(loader=None)
    assert mandatory(templar.template('{{ foo }}', dict(foo='bar'), fail_on_undefined=True)) == 'bar'
    assert mandatory(templar.template('{{ foo }}', dict(foo=None), fail_on_undefined=True)) is None
    assert mandatory(templar.template('{{ foo }}', dict(foo=0), fail_on_undefined=True)) == 0
    assert mandatory(templar.template('{{ foo }}', dict(foo=42), fail_on_undefined=True)) == 42
    assert mandatory(templar.template('{{ foo }}', dict(foo=42.0), fail_on_undefined=True)) == 42.0


# Generated at 2022-06-22 16:30:32.272050
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == '123'
    assert regex_search('abc123', r'\d+', '\\g<1>') == '123'
    assert regex_search('abc123', r'\d+', '\\1') == '123'
    assert regex_search('abc123', r'\d+', '\\2') == None
    assert regex_search('abc123', r'(?P<digits>\d+)', '\\g<digits>') == '123'

# Generated at 2022-06-22 16:30:43.609017
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[0-9]*') == []
    assert fileglob('/etc/passwd[0-9][0-9]') == []
    assert fileglob('/etc/passwd[0-9][0-9]*') == []
    assert fileglob('/etc/passwd[0-9][0-9][0-9]') == []

# Generated at 2022-06-22 16:30:50.758061
# Unit test for function mandatory
def test_mandatory():
    assert mandatory('foo') == 'foo'
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert to_native(e) == 'Mandatory variable not defined.'
    try:
        mandatory(AnsibleUndefined, msg='foo')
    except AnsibleFilterError as e:
        assert to_native(e) == 'foo'



# Generated at 2022-06-22 16:31:00.830372
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')

    try:
        mandatory(Undefined(name='foo'))
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "Mandatory variable 'foo' not defined."

    try:
        mandatory(Undefined(name='foo'), msg='bar')
        assert False
    except AnsibleFilterError as e:
        assert to_native(e) == "bar"

    assert mandatory('foo') == 'foo'
    assert mandatory('foo', msg='bar') == 'foo'



# Generated at 2022-06-22 16:31:03.720105
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    t = Templar(loader=None, variables=AnsibleJ2Vars({'a': [{'b': 1}, {'b': 2}]}))
    assert [('1', [{'b': 1}]), ('2', [{'b': 2}])] == t.do_groupby(AnsibleUnsafeText('a'), 'b')



# Generated at 2022-06-22 16:31:18.783106
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None

# Generated at 2022-06-22 16:31:30.090395
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'sha512') == 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff'
    assert get

# Generated at 2022-06-22 16:31:34.290149
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': {'c': 'd'}}}) == {'b': {'c': 'd'}}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b') == {'c': 'd'}
    assert extract('a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'
    assert extract('a', {'a': {'b': {'c': 'd'}}}, 'b', 'c') == 'd'



# Generated at 2022-06-22 16:31:38.712906
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['groupby'] == do_groupby
    assert FilterModule().filters()['b64decode'] == b64decode
    assert FilterModule().filters()['b64encode'] == b64encode
    assert FilterModule().filters()['to_uuid'] == to_uuid
    assert FilterModule().filters()['to_json'] == to_json
    assert FilterModule().filters()['to_nice_json'] == to_nice_json
    assert FilterModule().filters()['from_json'] == json.loads
    assert FilterModule().filters()['to_yaml'] == to_yaml
    assert FilterModule().filters()['to_nice_yaml'] == to_nice_yaml
    assert FilterModule().filters()['from_yaml'] == from_yaml

# Generated at 2022-06-22 16:31:47.211545
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined



# Generated at 2022-06-22 16:31:54.026773
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdefghi', 'abc') == 'abc'
    assert regex_search('abcdefghi', 'def') == 'def'
    assert regex_search('abcdefghi', 'xyz') is None
    assert regex_search('abcdefghi', 'abc', '\\g<0>') == ['abc', 'abc']
    assert regex_search('abcdefghi', 'def', '\\g<0>') == ['def', 'def']
    assert regex_search('abcdefghi', 'xyz', '\\g<0>') is None
    assert regex_search('abcdefghi', 'abc', '\\1') is None
    assert regex_search('abcdefghi', 'def', '\\1') is None

# Generated at 2022-06-22 16:32:06.437366
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:32:15.148772
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory('') == ''
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg="test") == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        assert True
    try:
        mandatory(AnsibleUndefined, msg="test")
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "test"



# Generated at 2022-06-22 16:32:25.736451
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicates
    from ansible.utils.vars import isidentifier

# Generated at 2022-06-22 16:32:38.519533
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'bcd') == 'bcd'
    assert regex_search('abcdef', 'bcd', '\\g<1>') == ['bcd', 'bcd']
    assert regex_search('abcdef', 'bcd', '\\g<1>', '\\g<1>') == ['bcd', 'bcd', 'bcd', 'bcd']
    assert regex_search('abcdef', 'bcd', '\\g<1>', '\\g<2>') == ['bcd', 'bcd', 'cde', 'cde']
    assert regex_search('abcdef', 'bcd', '\\g<1>', '\\g<2>', '\\g<3>') == ['bcd', 'bcd', 'cde', 'cde', 'def', 'def']

# Generated at 2022-06-22 16:32:55.469512
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/') == []
    assert fileglob('/etc/p*') == ['/etc/passwd']
    assert fileglob('/etc/p*wd') == ['/etc/passwd']
    assert fileglob('/etc/p*w') == []
    assert fileglob('/etc/p*w*') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d*') == ['/etc/passwd']
    assert fileglob('/etc/p*w*d*x') == []

# Generated at 2022-06-22 16:33:08.028244
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory(0.9) == 0.9
    assert mandatory(1.0) == 1.0
    assert mandatory(1.1) == 1.1
    assert mandatory(1.9) == 1.9
    assert mandatory(2) == 2
    assert mandatory(2.0) == 2.0
    assert mandatory(2.1) == 2.1
    assert mandatory(2.9) == 2.9
    assert mandatory

# Generated at 2022-06-22 16:33:19.064998
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template.safe_eval import safe_eval
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.vars import AnsibleJ2TemplateVars
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefined
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefinedError
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefinedRecursive
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefinedRecursiveError
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefinedRecursiveFilter
    from ansible.template.vars import AnsibleJ2TemplateVarsUndefinedRecursiveFilterError

# Generated at 2022-06-22 16:33:30.453403
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template.safe_eval import AnsibleUnsafe
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test that the filter works
    data = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    result = do_groupby(env, data, 'a')
    assert result == [(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), (2, [{'a': 2, 'b': 4}])]

    # Test that the filter works with a string
   

# Generated at 2022-06-22 16:33:33.996524
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:33:45.462341
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world']

# Generated at 2022-06-22 16:33:56.790383
# Unit test for function extract
def test_extract():
    assert extract("a", {"a": "b"}) == "b"
    assert extract("a", {"a": "b"}, morekeys=["c"]) == "b"
    assert extract("a", {"a": "b"}, morekeys=["c", "d"]) == "b"
    assert extract("a", {"a": "b"}, morekeys=["c", "d", "e"]) == "b"
    assert extract("a", {"a": "b"}, morekeys=["c", "d", "e", "f"]) == "b"
    assert extract("a", {"a": "b"}, morekeys=["c", "d", "e", "f", "g"]) == "b"

# Generated at 2022-06-22 16:34:08.822486
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, indent=4) == '    a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=None, indent=4, width=1) == 'a: b\n'
    assert to_yaml

# Generated at 2022-06-22 16:34:14.926970
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/pam.d/*') == ['/etc/pam.d/other', '/etc/pam.d/system-auth']
    assert fileglob('/etc/pam.d/*.conf') == []
    assert fileglob('/etc/pam.d/*.d/*') == ['/etc/pam.d/cracklib/password-auth', '/etc/pam.d/cracklib/system-auth', '/etc/pam.d/system-auth/password-auth']
    assert fileglob('/etc/pam.d/*.d/*.conf') == []

# Generated at 2022-06-22 16:34:23.359760
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined



# Generated at 2022-06-22 16:34:37.692118
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\2') == [None, None]

# Generated at 2022-06-22 16:34:49.481846
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abcdef', 'abc') == 'abc'
    assert regex_search('abcdef', 'def') == 'def'
    assert regex_search('abcdef', 'xyz') is None
    assert regex_search('abcdef', 'abc', '\\g<0>') == ['abc']
    assert regex_search('abcdef', 'abc', '\\g<1>') == []
    assert regex_search('abcdef', '(abc)', '\\g<1>') == ['abc']
    assert regex_search('abcdef', '(abc)', '\\g<0>', '\\g<1>') == ['abc', 'abc']
    assert regex_search('abcdef', '(abc)', '\\g<0>', '\\g<2>') == ['abc']

# Generated at 2022-06-22 16:35:00.585495
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': 'b'}) == 'b'
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd') == None
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c'], 'd', 'e') == None


# Generated at 2022-06-22 16:35:12.523989
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups', skip_missing=True) == []
    assert subelements(obj, 'groups.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'groups.0', skip_missing=True) == []
    assert subelements(obj, 'groups.1') == []

# Generated at 2022-06-22 16:35:19.161724
# Unit test for function extract
def test_extract():
    assert extract('foo', {'foo': 'bar'}) == 'bar'
    assert extract('foo', {'foo': {'bar': 'baz'}}) == {'bar': 'baz'}
    assert extract('foo', {'foo': {'bar': 'baz'}}, 'bar') == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar']) == 'baz'
    assert extract('foo', {'foo': {'bar': 'baz'}}, ['bar', 'baz']) == 'baz'



# Generated at 2022-06-22 16:35:31.539280
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\g<0>') == ['a', 'a', 'a']
    assert regex_search('abc', 'a', '\\g<1>') == ['a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<1>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<1>', '\\g<2>') == ['a']

# Generated at 2022-06-22 16:35:33.677042
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')



# Generated at 2022-06-22 16:35:46.594626
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:35:56.159535
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world']

# Generated at 2022-06-22 16:36:08.799556
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('hello world', 'hello') == 'hello'
    assert regex_search('hello world', 'hello', '\\g<1>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>') == ['hello', 'world']
    assert regex_search('hello world', 'hello', '\\g<1>', '\\g<2>', '\\g<3>', '\\g<4>') == ['hello', 'world']

# Generated at 2022-06-22 16:36:26.486392
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(0) == 0
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(['foo', 'bar']) == ['foo', 'bar']
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
    except AnsibleFilterError as e:
        assert 'Mandatory variable not defined' in to_native(e)

# Generated at 2022-06-22 16:36:30.663482
# Unit test for function combine
def test_combine():
    assert combine({'a': 'b'}, {'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert combine({'a': 'b'}, {'a': 'd'}) == {'a': 'd'}
    assert combine({'a': 'b'}, {'a': 'd'}, {'a': 'e'}) == {'a': 'e'}
    assert combine({'a': 'b'}, {'c': 'd'}, {'a': 'e'}) == {'a': 'e', 'c': 'd'}
    assert combine({'a': 'b'}, {'c': 'd'}, {'a': 'e', 'c': 'f'}) == {'a': 'e', 'c': 'f'}

# Generated at 2022-06-22 16:36:43.668892
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(42) == 42
    assert mandatory("foo") == "foo"
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(42, msg="foo") == 42
    assert mandatory("foo", msg="bar") == "foo"
    assert mandatory(True, msg="baz") == True
    assert mandatory(False, msg="qux") == False
    try:
        mandatory(None)
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "Mandatory variable not defined."
    try:
        mandatory(None, msg="foo")
        assert False
    except AnsibleFilterError as e:
        assert str(e) == "foo"

# Generated at 2022-06-22 16:36:58.552413
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'abc') == 'abc'
    assert regex_search('abc', 'a(b)c', '\\g<1>') == ['b']
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\g<1>') == ['b', 'b']
    assert regex_search('abc', 'a(b)c', '\\g<1>', '\\1') == ['b', 'b']
    assert regex_search('abc', 'a(b)c', '\\1') == ['b']
    assert regex_search('abc', 'a(b)c', '\\2') == None
    assert regex_search('abc', 'a(b)c', '\\1', '\\2') == ['b', None]

# Generated at 2022-06-22 16:37:00.847922
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory(Undefined(name='foo')) == Undefined(name='foo')
    assert mandatory(Undefined(name='foo'), msg='bar') == Undefined(name='foo')



# Generated at 2022-06-22 16:37:11.189663
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    env = Environment()
    templar = Templar(loader=None, variables={})
    value = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}]
    attribute = 'a'
    result = do_groupby(env, value, attribute)
    assert result == [((1,), [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}]), ((2,), [{'a': 2, 'b': 4}])]
    result = do_groupby(env, UnsafeProxy(value), UnsafeProxy(attribute))

# Generated at 2022-06-22 16:37:23.601730
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(0.0) == 0.0
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined, msg='foo') == AnsibleUndefined
    try:
        mandatory(AnsibleUndefined)
        assert False
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 16:37:31.317541
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == "a: 1\nb: 2\n"
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == "a: 1\nb: 2\n"
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == "{a: 1, b: 2}\n"
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == "a: 1\nb: 2\n"
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, indent=4) == "a: 1\nb: 2\n"