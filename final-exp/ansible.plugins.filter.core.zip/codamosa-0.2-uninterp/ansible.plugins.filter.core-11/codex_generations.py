

# Generated at 2022-06-22 16:28:17.620744
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None) == None
    assert mandatory(True) == True
    assert mandatory(False) == False
    assert mandatory(0) == 0
    assert mandatory(1) == 1
    assert mandatory('') == ''
    assert mandatory('foo') == 'foo'
    assert mandatory(u'foo') == u'foo'
    assert mandatory([]) == []
    assert mandatory([1,2,3]) == [1,2,3]
    assert mandatory({}) == {}
    assert mandatory({'foo': 'bar'}) == {'foo': 'bar'}
    assert mandatory(AnsibleUndefined) == AnsibleUndefined
    assert mandatory(AnsibleUndefined('foo')) == AnsibleUndefined('foo')
    assert mandatory(AnsibleUndefined('foo'), msg='foo') == AnsibleUndefined('foo')
   

# Generated at 2022-06-22 16:28:26.800464
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ item }}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    t

# Generated at 2022-06-22 16:28:38.834233
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == 'a: 1\nb: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == 'a: 1\n  b: 2\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=True) == '{ a: 1, b: 2 }\n'
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, default_flow_style=False) == 'a: 1\n  b: 2\n'

# Generated at 2022-06-22 16:28:42.243979
# Unit test for function fileglob
def test_fileglob():
    assert ['/tmp/foo.txt'] == fileglob('/tmp/foo.txt')
    assert [] == fileglob('/tmp/foo.txt')



# Generated at 2022-06-22 16:28:50.206342
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from ansible.template import Jinja2Environment
    env = Jinja2Environment(Environment())
    env.filters['groupby'] = do_groupby
    env.filters['to_json'] = to_json
    env.tests['defined'] = lambda x: x is not None
    env.tests['undefined'] = lambda x: x is None
    env.tests['none'] = lambda x: x is None
    env.tests['equalto'] = lambda x, y: x == y
    env.tests['greaterthan'] = lambda x, y: x > y
    env.tests['lessthan'] = lambda x, y: x < y
    env.tests['true'] = lambda x: x is True
    env.tests['false'] = lambda x: x is False
    env.tests

# Generated at 2022-06-22 16:28:59.169997
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2}) == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2}, key_name='k', value_name='v') == [{'k': 'a', 'v': 1}, {'k': 'b', 'v': 2}]
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2}, key_name='k', value_name='k') == [{'k': 'a', 'k': 1}, {'k': 'b', 'k': 2}]
    assert dict_

# Generated at 2022-06-22 16:29:11.678956
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1) == 1
    assert mandatory(None) == None
    assert mandatory('') == ''
    assert mandatory(0) == 0
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory(0.0) == 0.0
    assert mandatory(0.1) == 0.1
    assert mandatory(0.9) == 0.9
    assert mandatory([]) == []
    assert mandatory([1, 2, 3]) == [1, 2, 3]
    assert mandatory({}) == {}
    assert mandatory({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert mandatory(()) == ()
    assert mandatory((1, 2, 3)) == (1, 2, 3)
    assert mandatory(set()) == set()

# Generated at 2022-06-22 16:29:23.080564
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.template.safe_eval import safe_eval

    env = Environment(loader=DictLoader({}))
    env.filters['groupby'] = do_groupby
    ctx = Context({}, environment=env)

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    result = env.from_string('{{ data|groupby("a") }}').render(data=data, ctx=ctx)
    assert safe_eval(result) == {1: [{'a': 1, 'b': 2}], 3: [{'a': 3, 'b': 4}]}

# Generated at 2022-06-22 16:29:31.803381
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc123', r'\d+') == '123'
    assert regex_search('abc123', r'\d+', '\\g<0>') == ['123', '123']
    assert regex_search('abc123', r'\d+', '\\1') == ['1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\1') == ['123', '123', '1']
    assert regex_search('abc123', r'\d+', '\\g<0>', '\\2') == ['123', '123', None]
    assert regex_search('abc123', r'\d+', '\\g<1>') == [None]

# Generated at 2022-06-22 16:29:43.695683
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(value='abcd', pattern='b', replacement='B') == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B', ignorecase=True) == 'abcd'
    assert regex_replace(value='abcd', pattern='B', replacement='B') == 'abcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', multiline=True) == 'aBcd'
    assert regex_replace(value='abcd', pattern='b', replacement='B', ignorecase=True, multiline=True) == 'aBcd'

# Generated at 2022-06-22 16:29:57.149264
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:30:07.697114
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/bin/ls') == ['/bin/ls']
    assert fileglob('/bin/ls*') == ['/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls', '/bin/ls']
    assert fileglob('/bin/ls*') != ['/bin/ls', '/bin/lsmod', '/bin/ls', '/bin/ls', '/bin/ls']

# Generated at 2022-06-22 16:30:20.949119
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 1, 'b': 2}) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=True) == '{a: 1, b: 2}\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=None) == 'a: 1\nb: 2\n'
    assert to_yaml({'a': 1, 'b': 2}, default_flow_style=False, indent=2) == '  a: 1\n  b: 2\n'

# Generated at 2022-06-22 16:30:32.355864
# Unit test for function rand
def test_rand():
    assert rand(None, 10) in range(0, 10)
    assert rand(None, 10, step=2) in range(0, 10, 2)
    assert rand(None, 10, start=2) in range(2, 10)
    assert rand(None, 10, start=2, step=2) in range(2, 10, 2)
    assert rand(None, [1, 2, 3]) in [1, 2, 3]
    assert rand(None, [1, 2, 3], seed=42) == 1
    assert rand(None, [1, 2, 3], seed=42) == 1
    assert rand(None, [1, 2, 3], seed=42) == 1
    assert rand(None, [1, 2, 3], seed=42) == 1

# Generated at 2022-06-22 16:30:43.964617
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>', '\\1') == ['o']


# Generated at 2022-06-22 16:30:50.416745
# Unit test for function comment
def test_comment():
    assert comment('test') == '# test'
    assert comment('test', 'erlang') == '% test'
    assert comment('test', 'c') == '// test'
    assert comment('test', 'cblock') == '/*\n * test\n */'
    assert comment('test', 'xml') == '<!--\n - test\n-->'
    assert comment('test', 'plain', decoration='- ') == '- test'
    assert comment('test', 'plain', decoration='- ', prefix='- ') == '- - test'
    assert comment('test', 'plain', decoration='- ', prefix='- ', prefix_count=2) == '- - - test'
    assert comment('test', 'plain', decoration='- ', postfix='- ', postfix_count=2) == '- test- - '
    assert comment

# Generated at 2022-06-22 16:30:55.618311
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]) == {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}
    assert list_of_dict_key_value_elements_to_dict([{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}], key_name='value', value_name='key') == {1: 'a', 2: 'b'}

# Generated at 2022-06-22 16:31:07.493081
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/etc/passwd') == ['/etc/passwd']
    assert fileglob('/etc/passwd*') == ['/etc/passwd']
    assert fileglob('/etc/passwd?') == []
    assert fileglob('/etc/passwd[0-9]') == []
    assert fileglob('/etc/passwd[a-z]') == []
    assert fileglob('/etc/passwd[a-z]*') == []
    assert fileglob('/etc/passwd[a-z]?') == []
    assert fileglob('/etc/passwd[a-z][a-z]') == []
    assert fileglob('/etc/passwd[a-z][a-z]*') == []

# Generated at 2022-06-22 16:31:18.280392
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True)
    assert to_bool(False)
    assert to_bool(None)
    assert to_bool('true')
    assert to_bool('True')
    assert to_bool('yes')
    assert to_bool('Yes')
    assert to_bool('on')
    assert to_bool('On')
    assert to_bool('1')
    assert to_bool(1)
    assert not to_bool('false')
    assert not to_bool('False')
    assert not to_bool('no')
    assert not to_bool('No')
    assert not to_bool('off')
    assert not to_bool('Off')
    assert not to_bool('0')
    assert not to_bool(0)
    assert not to_bool(2)
    assert not to_bool('2')


# Generated at 2022-06-22 16:31:26.993130
# Unit test for function comment
def test_comment():
    assert comment('text') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ') == '; text'
    assert comment('text', 'plain', decoration='; ', prefix='; ', prefix_count=2) == '; ; text'

# Generated at 2022-06-22 16:31:39.599709
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=12345) == [2, 6, 7, 9, 1, 4, 10, 3, 5, 8]



# Generated at 2022-06-22 16:31:44.738754
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) != [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=1) == [1, 5, 7, 10, 3, 2, 9, 6, 8, 4]



# Generated at 2022-06-22 16:31:53.156374
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=1) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=3)

# Generated at 2022-06-22 16:31:59.344953
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'a': 'b'}) == '{a: b}\n'
    assert to_yaml({'a': 'b'}, default_flow_style=False) == 'a: b\n'
    assert to_yaml({'a': 'b'}, default_flow_style=True) == '{a: b}\n'


# Generated at 2022-06-22 16:32:10.804668
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822

# Generated at 2022-06-22 16:32:19.303862
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, 'b', 'c') == 'c'



# Generated at 2022-06-22 16:32:29.712466
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('abc', 'a') == 'a'
    assert regex_search('abc', 'a', '\\g<0>') == ['a', 'a']
    assert regex_search('abc', 'a', '\\g<0>', '\\1') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>') == ['a', 'a', 1]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\2') == ['a', 'a', 1, 2]
    assert regex_search('abc', 'a', '\\g<0>', '\\g<1>', '\\g<2>') == ['a', 'a', 1, 2]
    assert regex_search

# Generated at 2022-06-22 16:32:35.520552
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('foo.bar') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_basic') == 'foo\\.bar'
    assert regex_escape('foo.bar', re_type='posix_extended') == 'foo\\.bar'



# Generated at 2022-06-22 16:32:39.757533
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized', skip_missing=True) == []

# Generated at 2022-06-22 16:32:50.246034
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'a.b') == r'a\.b'
    assert regex_escape(r'a.b', re_type='posix_basic') == r'a\.b'
    assert regex_escape(r'a.b', re_type='posix_extended') == r'a\.b'
    assert regex_escape(r'a[b') == r'a\[b'
    assert regex_escape(r'a[b', re_type='posix_basic') == r'a\[b'
    assert regex_escape(r'a[b', re_type='posix_extended') == r'a\[b'
    assert regex_escape(r'a$b') == r'a\$b'

# Generated at 2022-06-22 16:33:04.896955
# Unit test for function extract
def test_extract():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=None))

    assert extract(templar, 'foo', {'foo': 'bar'}) == 'bar'
    assert extract(templar, 'foo', {'foo': {'bar': 'baz'}}, 'bar') == 'baz'

# Generated at 2022-06-22 16:33:15.405776
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    from ansible.template.safe_eval import unsafe_eval

    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dictionaries
    data = [{'a': 1, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    t = env.from_string('{{ data|groupby("a")|list }}')
    assert unsafe_eval(t.render(data=data)) == [
        (1, [{'a': 1, 'b': 1}, {'a': 1, 'b': 2}]),
        (2, [{'a': 2, 'b': 3}])
    ]

    # Test with a list of lists

# Generated at 2022-06-22 16:33:23.705672
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list([1, 2, 3, 4, 5]) != [1, 2, 3, 4, 5]
    assert randomize_list([1, 2, 3, 4, 5]) != randomize_list([1, 2, 3, 4, 5])
    assert randomize_list([1, 2, 3, 4, 5], seed=1) == randomize_list([1, 2, 3, 4, 5], seed=1)
    assert randomize_list([1, 2, 3, 4, 5], seed=1) != randomize_list([1, 2, 3, 4, 5], seed=2)



# Generated at 2022-06-22 16:33:35.282584
# Unit test for function randomize_list
def test_randomize_list():
    # Test with a list of integers
    mylist = [1, 2, 3, 4, 5]
    assert randomize_list(mylist, seed=1) == [3, 2, 5, 1, 4]
    assert randomize_list(mylist, seed=1) == [3, 2, 5, 1, 4]
    assert randomize_list(mylist, seed=2) == [5, 4, 1, 3, 2]
    assert randomize_list(mylist, seed=2) == [5, 4, 1, 3, 2]
    # Test with a list of strings
    mylist = ['a', 'b', 'c', 'd', 'e']
    assert randomize_list(mylist, seed=1) == ['c', 'b', 'e', 'a', 'd']
    assert randomize_list

# Generated at 2022-06-22 16:33:41.568071
# Unit test for function extract
def test_extract():
    assert extract(None, 'a', {'a': 'b'}) == 'b'
    assert extract(None, 'a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract(None, 'a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract(None, 'a', {'a': {'b': {'c': 'd'}}}, 'b', 'c') == 'd'
    assert extract(None, 'a', {'a': {'b': {'c': 'd'}}}, ['b', 'c']) == 'd'
    assert extract(None, 'a', {'a': {'b': {'c': 'd'}}}, 'b', 'c', 'd') == 'd'


# Generated at 2022-06-22 16:33:53.210180
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1489441466') == '2017-03-13 12:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466) == '2017-03-13 12:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.0) == '2017-03-13 12:51:06'
    assert strftime('%Y-%m-%d %H:%M:%S', 1489441466.123) == '2017-03-13 12:51:06'

# Generated at 2022-06-22 16:34:05.226832
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == 'o'
    assert regex_search('foo', 'f(o)o', '\\g<1>') == 'o'
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == None
    assert regex_search('foo', 'f(o)o', '\\g<2>') == None
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') == [None, None]

# Generated at 2022-06-22 16:34:13.177572
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    env = Environment()
    env.filters['groupby'] = do_groupby

    # Test with a list of dicts
    data = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}, {'a': 1, 'b': 4}]
    template = '{{ data|groupby("a") }}'
    result = env.from_string(template).render(data=data)
    assert result == "[(1, [{'a': 1, 'b': 2}, {'a': 1, 'b': 4}]), (2, [{'a': 2, 'b': 3}])]"

    # Test with a list of lists

# Generated at 2022-06-22 16:34:24.014220
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1485129900') == '2016-12-30 15:15:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1485129900) == '2016-12-30 15:15:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1485129900.0) == '2016-12-30 15:15:00'
    assert strftime('%Y-%m-%d %H:%M:%S', 1485129900.123) == '2016-12-30 15:15:00'

# Generated at 2022-06-22 16:34:33.836985
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'
    assert get_hash('test', 'sha1') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'

# Generated at 2022-06-22 16:34:45.161954
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import JinjaEnvironment
    env = JinjaEnvironment()
    env.filters['groupby'] = do_groupby
    t = env.from_string("{{ [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}] | groupby('a') | list }}")
    assert t.render() == "[(1, [{'a': 1, 'b': 2}]), (3, [{'a': 3, 'b': 4}])]"



# Generated at 2022-06-22 16:34:57.526297
# Unit test for function comment
def test_comment():
    assert comment('text', 'plain') == '# text'
    assert comment('text', 'erlang') == '% text'
    assert comment('text', 'c') == '// text'
    assert comment('text', 'cblock') == '/*\n * text\n */'
    assert comment('text', 'xml') == '<!--\n - text\n-->'
    assert comment('text', 'plain', decoration='// ') == '// text'
    assert comment('text', 'plain', decoration='// ', prefix='// ') == '// text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2) == '// // text'
    assert comment('text', 'plain', decoration='// ', prefix='// ', prefix_count=2, postfix='// ', postfix_count=2)

# Generated at 2022-06-22 16:35:02.073667
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
    assert subelements(obj, 'authorized') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]
    assert subelements(obj, 'authorized.0') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub')]

# Generated at 2022-06-22 16:35:12.885449
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\1') is None
    assert regex_search('foo', 'foo', '\\0') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == ['foo']
    assert regex_search('foo', 'foo', '\\1', '\\0') == ['foo']


# Generated at 2022-06-22 16:35:17.600038
# Unit test for function extract
def test_extract():
    assert extract('a', {'a': {'b': 'c'}}) == {'b': 'c'}
    assert extract('a', {'a': {'b': 'c'}}, 'b') == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b']) == 'c'
    assert extract('a', {'a': {'b': 'c'}}, ['b', 'c']) == 'c'



# Generated at 2022-06-22 16:35:30.507839
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>', '\\1') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []

# Generated at 2022-06-22 16:35:40.780172
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'bar') is None
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') is None
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<0>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<0>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<0>', '\\g<1>') == ['foo', None]

# Generated at 2022-06-22 16:35:48.161969
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['from_json'] = from_json
    env.filters['to_yaml'] = to_yaml
    env.filters['from_yaml'] = from_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_iso8601'] = to_iso8601
    env.filters['to_rfc822'] = to_rfc822
    env.filters['to_local']

# Generated at 2022-06-22 16:35:57.571476
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    env = Environment()
    env.filters['groupby'] = do_groupby
    env.filters['dict2items'] = dict2items
    env.filters['to_json'] = to_json
    env.filters['to_nice_json'] = to_nice_json
    env.filters['to_yaml'] = to_yaml
    env.filters['to_nice_yaml'] = to_nice_yaml
    env.filters['to_nice_yaml_extended'] = to_nice_yaml_extended
    env.filters['to_nice_yaml_extended_with_binary'] = to_nice_yaml_extended_with_binary

# Generated at 2022-06-22 16:36:09.750028
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    from ansible.template import Templar

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Test with a list of dicts
    data = [
        {'a': 'foo', 'b': 'bar'},
        {'a': 'foo', 'b': 'baz'},
        {'a': 'foo', 'b': 'baz'},
        {'a': 'bar', 'b': 'baz'},
        {'a': 'bar', 'b': 'baz'},
        {'a': 'bar', 'b': 'baz'},
    ]

# Generated at 2022-06-22 16:36:25.209533
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash


# Generated at 2022-06-22 16:36:33.363537
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'f(o)o', '\\1') == ['o']
    assert regex_search('foo', 'f(o)o', '\\g<1>') == ['o']
    assert regex_search('foo', 'f(o)o', '\\1', '\\g<1>') == ['o', 'o']
    assert regex_search('foo', 'f(o)o', '\\2') == []
    assert regex_search('foo', 'f(o)o', '\\g<2>') == []
    assert regex_search('foo', 'f(o)o', '\\2', '\\g<2>') == []

# Generated at 2022-06-22 16:36:44.988951
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', '^f') == 'f'
    assert regex_search('foo', 'o$') == 'o'
    assert regex_search('foo', 'oo') == 'oo'
    assert regex_search('foo', '^f', '\\g<0>o') == 'foo'
    assert regex_search('foo', '^f', '\\g<0>o', '\\g<0>') == ['foo', 'f']
    assert regex_search('foo', '^f', '\\g<0>o', '\\1') == ['foo', 'o']
    assert regex_search('foo', '^f', '\\g<0>o', '\\2') == ['foo', None]

# Generated at 2022-06-22 16:36:58.640458
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    assert get_hash('test', 'sha256') == '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08'
    assert get_hash('test', 'md5') == '098f6bcd4621d373cade4e832627b4f6'

# Generated at 2022-06-22 16:37:10.041658
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'a': 1, 'b': 2}) == '''{a: 1,
b: 2}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=10) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=9) == '''{
  a: 1,
  b: 2
}'''
    assert to_nice_yaml({'a': 1, 'b': 2}, indent=2, width=8)

# Generated at 2022-06-22 16:37:22.784199
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'foo') == 'foo'
    assert regex_search('foo', 'foo', '\\g<0>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>') == 'foo'
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<1>') == ['foo', 'foo']
    assert regex_search('foo', 'foo', '\\g<1>', '\\g<2>') == ['foo', None]
    assert regex_search('foo', 'foo', '\\g<2>', '\\g<1>') == [None, 'foo']
    assert regex_search('foo', 'foo', '\\g<2>') == None

# Generated at 2022-06-22 16:37:34.436402
# Unit test for function randomize_list
def test_randomize_list():
    assert randomize_list(['a', 'b', 'c', 'd', 'e'], seed=1) == ['c', 'a', 'b', 'e', 'd']
    assert randomize_list(['a', 'b', 'c', 'd', 'e'], seed=2) == ['b', 'a', 'e', 'd', 'c']
    assert randomize_list(['a', 'b', 'c', 'd', 'e'], seed=3) == ['a', 'c', 'b', 'e', 'd']
    assert randomize_list(['a', 'b', 'c', 'd', 'e'], seed=4) == ['b', 'a', 'e', 'd', 'c']