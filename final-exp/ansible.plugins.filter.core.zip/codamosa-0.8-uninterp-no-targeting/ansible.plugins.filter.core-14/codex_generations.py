

# Generated at 2022-06-21 04:30:13.459411
# Unit test for function from_yaml
def test_from_yaml():
    # Test that from_yaml returns the passed in dict
    test_dict = dict(a=1)
    assert from_yaml(test_dict) == test_dict

    # Test that from_yaml converts a string to a dict
    test_str = '{"a": 1}'
    assert from_yaml(test_str) == json.loads(test_str)



# Generated at 2022-06-21 04:30:23.647799
# Unit test for function combine
def test_combine():
    from jinja2.runtime import Undefined

    a = {'a': 1, 'b': 2}
    b = {'b': 3, 'c': 4}
    c = [a, b]
    assert combine(c) == {'a': 1, 'b': 3, 'c': 4}
    assert combine(a, b) == {'a': 1, 'b': 3, 'c': 4}
    assert combine(b, a) == {'a': 1, 'b': 2, 'c': 4}

    assert combine(recursive=True, list_merge='replace') == {}
    assert combine(a, recursive=True, list_merge='replace') == a

# Generated at 2022-06-21 04:30:32.693873
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) == True
    assert to_bool(False) == False

    assert to_bool('true') == True
    assert to_bool('True') == True
    assert to_bool('TRUE') == True
    assert to_bool('yes') == True
    assert to_bool('YES') == True
    assert to_bool('no') == False
    assert to_bool('NO') == False
    assert to_bool('1') == True
    assert to_bool('01') == True
    assert to_bool('00') == False
    assert to_bool('2') == True
    assert to_bool([]) == False
    assert to_bool(['foo']) == True
    assert to_bool('') == False
    assert to_bool(' ') == False

    assert to_bool({}) == True


# Generated at 2022-06-21 04:30:36.816057
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(5) == 5
    try:
        mandatory(None)
    except AnsibleFilterError:
        pass
    else:
        assert False, "Should have thrown an error"
    try:
        mandatory(None, "Should have thrown an error")
    except AnsibleFilterError as e:
        assert str(e) == "Should have thrown an error", "Should have thrown a different error"
    else:
        assert False, "Should have thrown an error"

re_match = partial(re.match, re.MULTILINE)



# Generated at 2022-06-21 04:30:41.470404
# Unit test for function rand

# Generated at 2022-06-21 04:30:43.915871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:30:53.669860
# Unit test for function to_bool
def test_to_bool():
    """ Unit test for function to_bool
        :args: None
        :returns: None
    """
    # Test function without an argument
    assert to_bool() is None
    # Test function with True
    assert to_bool(True) is True
    # Test function with False
    assert to_bool(False) is False
    # Test function with any integer
    assert to_bool(1) is True
    # Test function with any string
    assert to_bool('True') is True
    # Test function with any string
    assert to_bool('yes') is True
    # Test function with any string
    assert to_bool('on') is True
    # Test function with any string
    assert to_bool('1') is True
    # Test function with any string
    assert to_bool('False') is False


# Generated at 2022-06-21 04:31:01.833669
# Unit test for function from_yaml
def test_from_yaml():
    assert yaml_load is not None
    assert from_yaml is not None
    assert yaml_load('{foo: bar}') == {'foo': 'bar'}
    assert yaml_load('---\n foo: bar') == {'foo': 'bar'}
    assert yaml_load('foo: bar') == {'foo': 'bar'}



# Generated at 2022-06-21 04:31:10.632668
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello') == 'aGVsbG8='

# Generated at 2022-06-21 04:31:16.882973
# Unit test for function to_yaml
def test_to_yaml():
      assert to_yaml({'a': 1, 'b': 2, 'c': 'three'}, default_flow_style=False) == u"{a: 1, b: 2, c: three}\n...\n"
      assert to_yaml({'a': 1, 'b': 2, 'c': 'three'}) == u"{a: 1, b: 2, c: three}\n"


# Generated at 2022-06-21 04:31:42.254985
# Unit test for function from_yaml_all
def test_from_yaml_all():
    # Test a valid document
    doc = '''
    - 1
    - 2
    '''
    assert from_yaml_all(u'{}'.format(doc)) == from_yaml(u'{}'.format(doc))

    # Test a document with a syntax error
    try:
        from_yaml(u'{}'.format("a:\n  b:\n  c:\n"))
        assert False
    except AnsibleFilterError:
        pass
    try:
        # The presence of the syntax error means that the
        # data must be returned as a string
        assert from_yaml_all(u'{}'.format("a:\n  b:\n  c:\n")) == '{}'.format("a:\n  b:\n  c:\n")
    except AnsibleFilterError:
        assert False

# Generated at 2022-06-21 04:31:49.178476
# Unit test for function to_datetime
def test_to_datetime():
    s = "2009-02-03 14:43:20"
    assert to_datetime(s) == datetime.datetime(2009, 2, 3, 14, 43, 20)
    assert to_datetime(s, "%Y-%m-%d %H:%M:%S") == datetime.datetime(2009, 2, 3, 14, 43, 20)
    assert to_datetime(s, "%Y-%m-%d") == datetime.datetime(2009, 2, 3)



# Generated at 2022-06-21 04:32:00.353765
# Unit test for function regex_findall
def test_regex_findall():
    # Test no matches
    assert regex_findall('', '^') == []
    assert regex_findall('a', '^') == []
    assert regex_findall('a', '$') == []
    assert regex_findall('a', '^a$') == []
    assert regex_findall('ab', '^a$') == []
    assert regex_findall('ab', '^b$') == []
    assert regex_findall('ab', '^c$') == []

    # Test single match
    assert regex_findall('a', '.') == ['a']
    assert regex_findall('ab', '^.') == ['a']
    assert regex_findall('ab', '^..') == ['ab']
    assert regex_findall('ab', '.$') == ['b']
    assert regex_find

# Generated at 2022-06-21 04:32:10.132983
# Unit test for function to_json
def test_to_json():
    def equal(a, b):
        e = ansible_to_json(a)
        c = to_json(a)
        assert e == c
    equal(None, None)
    equal(True, True)
    equal(3, 3)
    equal(3.14159265359, 3.14159265359)
    equal('str', 'str')
    equal({'key': 'value'}, {'key': 'value'})
    equal({'l': [1, 2, 3]}, {'l': [1, 2, 3]})
    equal({'l': [1, '2', 3]}, {'l': [1, '2', 3]})

# Generated at 2022-06-21 04:32:15.268419
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid("shell", uuid.NAMESPACE_DNS) == "0e8fcee2-9bbd-32eb-8f7b-d0e08e37d40a"



# Generated at 2022-06-21 04:32:21.235235
# Unit test for function flatten
def test_flatten():
    # There's no way to test _anything_ here, this is just a placeholder so
    # the testsuite will exercise this function.
    #
    # It is impossible to test many of the edge cases as a lot of the code
    # paths are unreachable, but we can at least ensure linear code paths are
    # hit by testing for sequences and not sequences.
    assert flatten({}) == [{}]
    assert flatten((1,)) == [1]



# Generated at 2022-06-21 04:32:26.977013
# Unit test for function to_yaml
def test_to_yaml():
    test_input = [{'a': 'b', 'c': [1,2,'3']}]
    test_output = to_yaml(test_input)
    assert test_output == "- a: b\n  c:\n  - 1\n  - 2\n  - '3'\n"


# Generated at 2022-06-21 04:32:34.931008
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json({'a': 2, 'b': 4}) == '{\n    "a": 2,\n    "b": 4\n}'
    assert to_nice_json({'a': 2, 'b': 4}, sort_keys=False) == '{\n    "a": 2,\n    "b": 4\n}'
    assert to_nice_json({'a': 2, 'b': 4}, indent=2) == '{\n  "a": 2,\n  "b": 4\n}'
    assert to_nice_json([1, 2, 3], indent=2) == '[\n  1,\n  2,\n  3\n]'



# Generated at 2022-06-21 04:32:47.368811
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys, os
    import pytest, yaml
    import testinfra.utils.ansible_runner
    testinfra_hosts = testinfra.utils.ansible_runner.AnsibleRunner(
        os.environ['MOLECULE_INVENTORY_FILE']).get_hosts('all')

    def test_groupby():
        group_by = FilterModule().filters()['groupby']
        l = [{'name': 'a', 'value': 1}, {'name': 'b', 'value': 2}, {'name': 'b', 'value': 3}, {'name': 'a', 'value': 2}]

# Generated at 2022-06-21 04:32:59.899584
# Unit test for function list_of_dict_key_value_elements_to_dict

# Generated at 2022-06-21 04:33:13.989640
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {"a":1, "b":2}
    mylist = [{"key":"a", "value":1}, {"key":"b", "value":2}]
    assert dict_to_list_of_dict_key_value_elements(mydict, "key", "value") == mylist
    assert dict_to_list_of_dict_key_value_elements(mydict) == mylist
    assert dict_to_list_of_dict_key_value_elements(mydict, key_name="key", value_name="value") == mylist
    assert dict_to_list_of_dict_key_value_elements(mydict, key_name="k", value_name="v") == [{"k":"a", "v":1}, {"k":"b", "v":2}]
    assert dict

# Generated at 2022-06-21 04:33:21.932930
# Unit test for function flatten

# Generated at 2022-06-21 04:33:33.178963
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # plaintext password
    password = 'mypassword'
    # sha512 hashed password
    hashtype = 'sha512'
    result = get_encrypted_password(password, hashtype)
    assert result == '$6$rounds=656000$6R83b6VHUxj1U7C1$6m9XoVQmfhjD3wJ3dBAKzDJc2A8xWz7JaiGnRzzXHNJnTlL1TKwztJZ1gICrxttPCrWtQy2dC.9JthcIFv.8W0'
    hashtype = 'SHA512'
    result = get_encrypted_password(password, hashtype)

# Generated at 2022-06-21 04:33:35.222789
# Unit test for function randomize_list
def test_randomize_list():
    r1 = randomize_list([1,2,3,4,5,6], seed=100)
    r2 = randomize_list([1,2,3,4,5,6], seed=100)
    assert r1 == r2



# Generated at 2022-06-21 04:33:46.770033
# Unit test for function subelements
def test_subelements():
    assert len(subelements({}, [])) == 0
    assert len(subelements([{}], [])) == 0
    assert len(subelements([{'key1': ['value1a', 'value1b']}], [])) == 0
    assert len(subelements(
        [{'key1': ['value1a', 'value1b']}],
        '')
    ) == 0
    assert len(subelements(
        [{'key1': ['value1a', 'value1b']}],
        'key1')
    ) == 2
    assert len(subelements(
        [{'key1': ['value1a', 'value1b']}],
        'key2')
    ) == 0

# Generated at 2022-06-21 04:33:54.739956
# Unit test for function comment
def test_comment():
    assert comment('Hello', style='plain') == '# Hello\n'
    assert comment('Hello', style='c') == '// Hello\n'
    assert comment('Hello', style='cblock') == '''/*
 * Hello
 */'''
    assert comment('Hello', style='xml') == '''<!--
 - Hello
-->'''

    # test with custom decorator
    assert comment('Hello', decoration='// ', style='plain') == '// Hello\n'

    # test with custom prefix/postfix
    assert comment('Hello', prefix='1.', style='plain') == '# 1.Hello\n'
    assert comment('Hello', postfix='2.', style='plain') == '# Hello\n# 2.'

    # test with multiple prefix/postfix

# Generated at 2022-06-21 04:33:56.778373
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("foo") == "foo"



# Generated at 2022-06-21 04:34:03.685388
# Unit test for function randomize_list
def test_randomize_list():
    list_in = ['a', 'b', 'c', 'd', 'e', 'f', 1, 2, 3, 4, 5]
    list_out = randomize_list(list_in)
    assert sorted(list_in) == sorted(list_out)

    list_out = randomize_list(list_in, seed=123)
    assert list_out == ['a', 2, 'e', 'f', 'd', 3, 'c', 4, 'b', 1, 5]



# Generated at 2022-06-21 04:34:14.097457
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password(b'123456', 'md5') == '$1$salt$YmTbl1dTteBl3lmD3o/d..'
    assert get_encrypted_password(b'123456', 'blowfish') == '$2b$12$salt$Ovw8mZRrHOkHo2yeepxq3ukO8uc0W0.'
    assert get_encrypted_password(b'123456', 'sha256') == '$5$rounds=80000$salt$1D0VFyzlwiqwQVcQkuo1b7VcnxFnYpYX1G6fSGdzV0'

# Generated at 2022-06-21 04:34:15.323032
# Unit test for function fileglob
def test_fileglob():
    assert fileglob("./test/test.txt") == ['./test/test.txt']



# Generated at 2022-06-21 04:34:27.462303
# Unit test for function regex_search
def test_regex_search():
    assert regex_search("Hello, world!", "^.+?,\s(.+)!$", r"\g<1>") == "world"
    # Test backrefs
    assert regex_search("Hello, world!", "^.+?,\s(.+)!$", r"\1") == "world"
    assert regex_search("Hello, world!", "^.+?,\s(.+)!$", r"\g<1>", r"\g<1>", r"\1") == ["world", "world", "world"]
    # Test ignorecase
    assert regex_search("Hello, world!", "^.+?,\s(.+)!$", r"\1", ignorecase=True) == "world"

# Generated at 2022-06-21 04:34:42.714209
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace('', '', '') == ''
    assert regex_replace('', '', '', ignorecase=True) == ''
    assert regex_replace('', '', '', multiline=True) == ''
    assert regex_replace('', '', '', ignorecase=True, multiline=True) == ''
    assert regex_replace(b'', b'', b'') == b''
    assert regex_replace(b'', b'', b'', ignorecase=True) == b''
    assert regex_replace(b'', b'', b'', multiline=True) == b''
    assert regex_replace(b'', b'', b'', ignorecase=True, multiline=True) == b''
    assert regex_replace('ab', 'a', 'c') == 'cb'
    assert regex_

# Generated at 2022-06-21 04:34:52.987494
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    test_list = [{'key': 'test1', 'value': 'abc'}, {'key': 'test2', 'value': 'def'}]
    ansible_list_of_dict_key_value_elements_to_dict = list_of_dict_key_value_elements_to_dict(test_list)
    assert ansible_list_of_dict_key_value_elements_to_dict['test1'] == 'abc'
    assert ansible_list_of_dict_key_value_elements_to_dict['test2'] == 'def'

# Generated at 2022-06-21 04:35:05.083268
# Unit test for function from_yaml_all
def test_from_yaml_all():
    assert from_yaml_all("""
---
foo:
  - a
  - 1
---
bar:
  - b
  - 2
""") == [{'foo': ['a', 1]}, {'bar': ['b', 2]}]
    assert from_yaml_all("""
- foo:
    - a
    - 1
- bar:
    - b
    - 2
""") == [{'foo': ['a', 1]}, {'bar': ['b', 2]}]
    assert from_yaml_all("""
---
foo: a
---
bar: b
---
""") == [{'foo': 'a'}, {'bar': 'b'}]
    assert from_yaml_all("") == []



# Generated at 2022-06-21 04:35:20.430758
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid("ansible", namespace=UUID_NAMESPACE_ANSIBLE) == "cef94b0f-3d3a-5642-8fab-d5cc33ed0522"
    # Test inheritance of UUID_NAMESPACE_ANSIBLE
    assert to_uuid("ansible") == "cef94b0f-3d3a-5642-8fab-d5cc33ed0522"
    assert to_uuid("ansible", namespace=uuid.UUID("00000000-0000-0000-0000-000000000000")) == "8b3c3b3d-a6c2-5944-b87c-2bf1d57cd1e8"

# Generated at 2022-06-21 04:35:27.835103
# Unit test for function regex_findall
def test_regex_findall():
    assert ["aaa", "bbb", "ccc", "ddd"] == regex_findall("aaa\nbbb\nccc\nddd", "^(\w+)$", True)
    assert ["aaa", "bbb", "ccc", "ddd"] == regex_findall("aaa\nbbb\nccc\nddd", r"^(\w+)$", True)
    assert ["aaa", "ccc", "ddd"] == regex_findall("aaa\nbbb\nccc\nddd", r"^(a|c|d)")
    assert ["aaa", "ccc", "ddd"] == regex_findall("aaa\nbbb\nccc\nddd", r"^(a|c|d)", True)

# Generated at 2022-06-21 04:35:35.206921
# Unit test for function regex_escape
def test_regex_escape():
    ''' Test regex escape functions '''
    cases = [[r'\$12', r'\\\$12', 'python'],
             [r'\$12', r'\\\$12', 'posix_basic'],
             [r'\$12', r'$12', 'posix_extended']]
    for testcase in cases:
        assert testcase[0] == regex_escape(testcase[1], testcase[2])



# Generated at 2022-06-21 04:35:39.216956
# Unit test for function strftime
def test_strftime():
    if strftime('%a', 0) != 'Thu':
        return False
    if strftime('%a', 1286208900) != 'Sat':
        return False
    return True



# Generated at 2022-06-21 04:35:49.789175
# Unit test for function quote
def test_quote():
    assert quote('''this is "a" test''') == '''"this is \\"a\\" test"'''
    assert quote('this is "a" test') == '''"this is \\"a\\" test"'''
    assert quote('this "test" is') == '''"this \\"test\\" is"'''
    assert quote(u'this "test" is') == '''"this \\"test\\" is"'''
    assert quote('this (test) is') == '''"this \\(test\\) is"'''
    assert quote('this {test} is') == '''"this \\{test\\} is"'''
    assert quote('this [test] is') == '''"this \\[test\\] is"'''

# Generated at 2022-06-21 04:35:50.814829
# Unit test for function subelements
def test_subelements():
    '''Test that function subelements works as expected.'''

    import doctest
    doctest.testmod()




# Generated at 2022-06-21 04:36:02.025419
# Unit test for function extract
def test_extract():
    assert extract('a', {'b': [{'c': 1}]}) == [{'c': 1}]
    assert extract('c', {'b': [{'c': 1}]}, 'b') == [1]
    assert extract('a', {'b': [{'c': 1}]}, 'b', 'c') == 1



# Generated at 2022-06-21 04:36:14.910092
# Unit test for function rand
def test_rand():
    from ansible.errors import AnsibleFilterError
    from ansible.module_utils.six import assertRaisesRegexp

    # Testing random number generation
    assert rand([], 1, 0, 1, seed=42) == 0
    assert rand([], 100, 0, 1, seed=42) == 37
    assert rand([], 100, 0, 2, seed=42) == 74

    # Testing random item selection
    assert rand([], [42], seed=42) == 42
    assert rand([], [1, 4, 9], seed=42) == 9

    # Testing exceptions
    assertRaisesRegexp(
        AnsibleFilterError,
        'start and step can only be used with integer values',
        rand, [], [], 1, 1, 42
    )

# Generated at 2022-06-21 04:36:22.530859
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_data = {
        'packages' : [
                    'tree',
                    'bind-utils',
                    'wget'
                ],
        'repo' : {
                    'enabled' : True,
                    'name' : 'epel',
                },
    }
    print(to_nice_yaml(test_data))


# Generated at 2022-06-21 04:36:27.160719
# Unit test for function ternary
def test_ternary():
    assert ternary([], 'foo', 'bar') == 'foo'
    assert ternary(None, 'foo', 'bar') == 'bar'
    assert ternary(None, 'foo', 'bar', 'none') == 'none'
    assert ternary(0, 'foo', 'bar') == 'bar'
    assert ternary(1.1, 'foo', 'bar') == 'foo'



# Generated at 2022-06-21 04:36:34.108802
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    '''
    Test to simulate running with -v option
    :return:
    '''
    global display

    display = Display()
    test_password = 'this is my password'
    display.display(get_encrypted_password(test_password, rounds=1))
    assert get_encrypted_password(test_password, rounds=1) != test_password



# Generated at 2022-06-21 04:36:41.167664
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'foo': 'bar'}) == [{'value': 'bar', 'key': 'foo'}]
    try:
        dict_to_list_of_dict_key_value_elements(['foo', 'bar'])
        assert False, 'Should have failed'
    except:
        pass
    assert dict_to_list_of_dict_key_value_elements({'foo': 'bar'}, 'k', 'v') == [{'v': 'bar', 'k': 'foo'}]



# Generated at 2022-06-21 04:36:51.971160
# Unit test for function to_nice_json
def test_to_nice_json():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import env_fallback
    assert to_nice_json({1: 2, 3: 4}) == '{\n    "1": 2,\n    "3": 4\n}'
    assert to_nice_json({3: [4, 5], 6: 7}) == '{\n    "3": [\n        4,\n        5\n    ],\n    "6": 7\n}'
    assert to_nice_json([1, 2, 3, {4: 5, 6: 7}]) == '[\n    1,\n    2,\n    3,\n    {\n        "4": 5,\n        "6": 7\n    }\n]'
    assert to_nice_

# Generated at 2022-06-21 04:37:05.219466
# Unit test for function subelements
def test_subelements():
    obj = [
        {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]},
        {"name": "bob", "groups": ["admin"], "authorized": ["/tmp/bob/onekey.pub", "/tmp/bob/twokey.pub", "/tmp/bob/redkey.pub", "/tmp/bob/bluekey.pub"]},
    ]

# Generated at 2022-06-21 04:37:20.779367
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('Hello World') == 'SGVsbG8gV29ybGQ='
    assert b64encode('Hello World', encoding='iso-8859-1') == 'SGVsbG8gV29ybGQ='
    assert b64encode('Hello World', encoding='utf-16') == 'AAAAAFpL6UYAAAAA'
    assert b64encode('Hello World', encoding='utf-32') == 'AAAAAAIAAABJSFsAAQAAAA=='
    with pytest.raises(AnsibleFilterError):
        b64encode(b'Hello World', encoding='utf-8')
    with pytest.raises(UnicodeEncodeError):
        b64encode(u'Hello World \u2713', encoding='iso-8859-1')



# Generated at 2022-06-21 04:37:26.169711
# Unit test for function get_hash
def test_get_hash():
    assert(get_hash('test') == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3')


# Generated at 2022-06-21 04:37:43.474339
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  f = FilterModule().filters()
  assert f["get_checksum"].__name__ == "_checksum_filters.get_checksum"
  assert f["get_encrypted_password"].__name__ == "_checksum_filters.get_encrypted_password"
  assert f["randomize_list"].__name__ == "_list_filters.randomize_list"
  assert f["cidr_merge"].__name__ == "_list_filters.cidr_merge"
  assert f["cidr_expand"].__name__ == "_list_filters.cidr_expand"
  assert f["combine"].__name__ == "combine"
  assert f["extract"].__name__ == "extract"

# Generated at 2022-06-21 04:37:45.903576
# Unit test for function to_json
def test_to_json():
    assert to_json([{'word': 'hello'}]) == '[{"word": "hello"}]' 


# Generated at 2022-06-21 04:37:50.631426
# Unit test for function ternary
def test_ternary():
    assert ternary('', 1, 2) == 1
    assert ternary(0, 1, 2) == 2
    assert ternary(None, 1, 2, 3) == 3



# Generated at 2022-06-21 04:38:01.026988
# Unit test for function quote
def test_quote():
    for s in ['hello world', 'foo " bar', 'hello\'world', 'hello*world', 'hello?world', 'hello|world',
              'hello$world', 'hello;world', 'hello&world', 'hello`world', 'hello\\world', 'hello\nworld',
              'hello\tworld', 'hello\rworld', 'hello=world', 'hello#world', 'hello~world',
              'hello%world', 'hello world']:
        assert quote(s) == shlex_quote(s)



# Generated at 2022-06-21 04:38:10.155847
# Unit test for function to_bool
def test_to_bool():
    true_input = ['true', 'True', 'yes', 'on', '1', 1, True]
    false_input = ['false', 'False', 'no', 'off', '0', 0, 0.0, False]

    for value in true_input:
        failmsg = "Expected {0} to be True.".format(repr(value))
        assert to_bool(value) is True, failmsg

    for value in false_input:
        failmsg = "Expected {0} to be False.".format(repr(value))
        assert to_bool(value) is False, failmsg



# Generated at 2022-06-21 04:38:23.662179
# Unit test for function fileglob
def test_fileglob():
    filename = "fileglob_%s" % str(time.time())
    dirname = "dir_%s" % str(time.time())
    try:
        os.makedirs(dirname)
        with open(filename, 'w') as f:
            f.write('hello')
        with open(os.path.join(dirname, filename), 'w') as f:
            f.write('world')

        assert fileglob(filename) == [filename]
        assert fileglob(dirname) == []
        assert fileglob(os.path.join(dirname, "*")) == [os.path.join(dirname, filename)]
    except Exception:
        raise
    finally:
        os.remove(filename)
        os.remove(os.path.join(dirname, filename))
        os

# Generated at 2022-06-21 04:38:31.577445
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml( { "one": "two" }, indent=4, default_flow_style=False ) == u'one: two\n'
    assert to_nice_yaml( { "one": "two" }, indent=4) == u'one: two\n'
    assert to_nice_yaml( { "one": "two" } ) == u"one: two\n"



# Generated at 2022-06-21 04:38:44.597080
# Unit test for function comment

# Generated at 2022-06-21 04:38:49.558672
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(None, "This should fail")
    try:
        mandatory(None, "This should fail")
    except Exception as e:
        assert isinstance(e, AnsibleFilterError)
        assert e.message == "This should fail"



# Generated at 2022-06-21 04:38:57.033316
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = 'password'
    hashtype = 'md5'
    salt = 'testsalt'
    salt_size = ''
    rounds = ''
    ident = ''
    checksum = get_encrypted_password(password, hashtype, salt, salt_size, rounds)
    assert len(checksum) == 34
    assert checksum == '$1$testsalt$W.9XaBVtKFRAi1nQ2fMyS/'
    checksum = get_encrypted_password(password, hashtype, salt)
    assert len(checksum) == 34
    assert checksum == '$1$testsalt$W.9XaBVtKFRAi1nQ2fMyS/'

# Generated at 2022-06-21 04:39:22.142608
# Unit test for function quote
def test_quote():
    assert quote('abc') == 'abc'
    assert quote(' abc') == "' abc'"
    assert quote('abc ') == "'abc '"
    assert quote(' abc ') == "' abc '"
    assert quote('"a"') == '\\"a\\"'
    assert quote('a\b') == "'a\\b'"
    assert quote('a\b"') == "'a\\b\\\"'"
    # Test unicode support
    assert quote(u'\u0000') == '\u0000'
    assert quote(u'\u0001') == '\u0001'
    assert quote(u'a\u0001a\u0002') == "'a\\u0001a\\u0002'"
    assert quote(u'\U00000001') == '\U00000001'

# Generated at 2022-06-21 04:39:27.060487
# Unit test for function from_yaml
def test_from_yaml():
    data = '''
    foo:
    - bar
    '''
    assert from_yaml(data) == {'foo': ['bar']}



# Generated at 2022-06-21 04:39:28.552798
# Unit test for function to_json
def test_to_json():
    assert to_json("foo") == '"foo"'



# Generated at 2022-06-21 04:39:31.049637
# Unit test for function to_datetime
def test_to_datetime():
	return datetime.datetime.strptime('2012/05/01', '%Y/%m/%d')



# Generated at 2022-06-21 04:39:41.346592
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2]) == [1, 2]
    assert flatten([1, [2]]) == [1, 2]
    assert flatten([1, 2, [3, 4]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4]]]]) == [1, 2, 3, 4]
    assert flatten([1, [2, [3, [4]]]], 2) == [1, 2, 3, [4]]
    assert flatten([1, [2, [3, [4]]]], 1) == [1, 2, 3, [4]]
    assert flatten([1, [2, [3, [4]]]], 0) == [1, [2, [3, [4]]]]

# Generated at 2022-06-21 04:39:50.219789
# Unit test for function rand
def test_rand():
    env = {'ansible_python_interpreter': sys.executable}
    failed = 0
    for x in range(0, len(test_rand_data)):
        if rand(env, test_rand_data[x][0], test_rand_data[x][1], test_rand_data[x][2], test_rand_data[x][3]) != test_rand_data[x][4]:
            failed += 1
    if failed == 0:
        print('rand: OK')
        return True
    else:
        print('rand: %d/%d failed' % (failed, len(test_rand_data)))
        return False
