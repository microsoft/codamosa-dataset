

# Generated at 2022-06-21 04:30:24.742809
# Unit test for function subelements
def test_subelements():
    from ansible.compat.tests import unittest

    class TestSubelements(unittest.TestCase):

        def setUp(self):
            self.obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]

        def test_subelements_string(self):
            actual = subelements(self.obj, 'groups')
            expected = [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]
            self.assertEqual(actual, expected)

        def test_subelements_list(self):
            actual = subelements(self.obj, ['groups'])

# Generated at 2022-06-21 04:30:32.279420
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import DictEnvironment, StrictUndefined

    env = DictEnvironment(undefined=StrictUndefined)
    items = [{'name': None, 'a': 1}, {'name': 'a', 'a': 2}, {'name': 'a', 'a': 3}]
    assert [('a', [{'name': 'a', 'a': 2}, {'name': 'a', 'a': 3}]),
            (None, [{'name': None, 'a': 1}])] == do_groupby(env, items, 'name')



# Generated at 2022-06-21 04:30:39.571079
# Unit test for function extract
def test_extract():
    assert extract({}, 'a', {'a': 'b'}) == 'b'
    assert extract({}, 'a', {'a': {'b': 1}}) == {'b': 1}
    assert extract({}, 'a', {'b': 1}, 'b') == 1
    assert extract({}, 'a', {'b': [1, 2, 3]}, 1) == 2
    assert extract({}, ['a', 'b'], {'a': {'b': 1}}) == 1
    assert extract({}, 'a', {'a': {'b': {'c': 1}}}, 'b', 'c') == 1



# Generated at 2022-06-21 04:30:49.485362
# Unit test for function flatten
def test_flatten():
    assert flatten([1]) == [1]
    assert flatten([1, 2]) == [1, 2]
    assert flatten([[1]]) == [1]
    assert flatten([1, [2]]) == [1, 2]
    assert flatten([[1], 2]) == [1, 2]
    assert flatten([1, [2]]) == [1, 2]
    assert flatten([1, [2, [3]]]) == [1, 2, 3]
    assert flatten([[1], [2, [3]]]) == [1, 2, 3]
    assert flatten([[1, 2], [3]]) == [1, 2, 3]
    assert flatten([[1], [2, 3]]) == [1, 2, 3]

# Generated at 2022-06-21 04:30:55.220707
# Unit test for function to_uuid
def test_to_uuid():
    u1 = uuid.UUID('361E6D51-FAEC-444A-9079-341386DA8E2E')
    u2 = uuid.UUID('0125E8D0-ACF9-4D46-9039-12F6FAC1E159')
    s = '636f6e7465'
    assert to_uuid(s, u1) == u2



# Generated at 2022-06-21 04:31:04.816407
# Unit test for function do_groupby
def test_do_groupby():
    # target jinja2<2.9.0,>=2.9.5
    # we will update this to test the various jinja2 versions as
    # part of issue #20098
    from jinja2 import Environment
    from jinja2 import Template
    from jinja2.runtime import Undefined
    from six import iteritems
    from test.support.script_helper import assert_python3_dedent
    from test.support.script_helper import assert_python_dedent
    from test.support.script_helper import assert_pythoneval


# Generated at 2022-06-21 04:31:19.020022
# Unit test for function fileglob
def test_fileglob():
    ''' return True if function fileglob works as expected '''
    # create tmp files to use for testing
    (fd, tmpfile) = tempfile.mkstemp(suffix='ansible-utils-tests')
    os.close(fd)
    (fd, tmpdir) = tempfile.mktemp(suffix='ansible-utils-tests')
    os.close(fd)
    os.mkdir(tmpdir)
    file_patterns = ["*.mkstem",
                     tmpfile,
                     os.path.join(os.path.dirname(tmpfile), "*"),
                     os.path.join(os.path.dirname(tmpfile), "*.mkstemp*"),
                     os.path.join(tmpdir, "*")]

# Generated at 2022-06-21 04:31:21.121866
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y") == time.strftime("%Y")



# Generated at 2022-06-21 04:31:26.736551
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'a': 1, 'b': 2, 'c': 3}
    ret = dict_to_list_of_dict_key_value_elements(mydict, key_name='key', value_name='value')
    assert all(k in ret[0] for k in ('key', 'value'))



# Generated at 2022-06-21 04:31:33.419492
# Unit test for function to_uuid
def test_to_uuid():
    string = "hello world"
    result = to_uuid(string, namespace=UUID_NAMESPACE_ANSIBLE)
    assert isinstance(result, string_types)
    assert result == "069ac6d3-e809-5b5a-9211-5d5127f10b60"


# Generated at 2022-06-21 04:31:50.459680
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test_input_yaml = \
'''
- name: Modify the APT sources list
  action: lineinfile dest=/etc/apt/sources.list regexp='^deb ' line='deb http://example.com/debian distribution main'
- name: Update APT
  action: apt upgrade=dist update_cache=yes force_apt_get=yes
- name: Install the package
  action: apt name={{ item }} update_cache=yes force_apt_get=yes
  with_items:
    - curl
    - htop
'''

# Generated at 2022-06-21 04:31:59.800721
# Unit test for function from_yaml
def test_from_yaml():
    # Test None input
    assert from_yaml(None) is None
    # Test no-op on data types that need no action
    # - bool
    assert from_yaml(True) is True
    # - string
    assert from_yaml('hello world') == 'hello world'
    # - list
    assert from_yaml([1,2,3]) == [1,2,3]
    # - dict
    assert from_yaml({'hello':'world'}) == {'hello':'world'}
    # Test yaml load for yaml data
    assert from_yaml('{hello: world}') == {'hello': 'world'}



# Generated at 2022-06-21 04:32:08.205878
# Unit test for function strftime
def test_strftime():
    assert strftime("%Y") == time.strftime("%Y")
    assert strftime("%Y", second=10) == time.strftime("%Y", time.localtime(10))
    assert strftime("%Y", second=2147483647) == time.strftime("%Y", time.localtime(2147483647))
    try:
        strftime("%Y", second="a")
    except AnsibleFilterError:
        pass
    else:
        raise Exception("Failed to catch incorrect epoch value")

# TODO: remove function?

# Generated at 2022-06-21 04:32:18.525674
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(None) is None
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool('yes') is True
    assert to_bool('on') is True
    assert to_bool('1') is True
    assert to_bool('true') is True
    assert to_bool('no') is False
    assert to_bool('off') is False
    assert to_bool('false') is False
    assert to_bool('0') is False
    assert to_bool(0) is False
    assert to_bool(1) is True
    assert to_bool('foo') is False


# Generated at 2022-06-21 04:32:30.098681
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # empty password
    assert get_encrypted_password('', 'md5') == '$1$' + ('.' * 8) + '$'
    assert get_encrypted_password('', 'sha256') == '$5$' + ('.' * 16) + '$'
    assert get_encrypted_password('', 'sha512') == '$6$' + ('.' * 16) + '$'
    # some password
    assert get_encrypted_password('some password', 'md5') == '$1$y0YdVZfz$QxwvZhWGZ8DpOe1ECDnKv0'

# Generated at 2022-06-21 04:32:33.061871
# Unit test for function rand
def test_rand():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    assert rand(templar, 1, 0) in (0, 1)



# Generated at 2022-06-21 04:32:44.697122
# Unit test for function to_bool
def test_to_bool():
    for input, output in (
            (True, True),
            (False, False),
            ('yes', True),
            ('no', False),
            ('on', True),
            ('1', True),
            ('off', False),
            (1, True),
            (0, False),
            ('true', True),
            ('false', False),
            (2, False),
            ([], False),
            (['foo'], False),
            ({}, False),
            (None, None)
    ):
        assert to_bool(input) == output



# Generated at 2022-06-21 04:32:51.330712
# Unit test for function to_datetime
def test_to_datetime():
    d1 = to_datetime("2016-01-28 10:35:53", "%Y-%m-%d %H:%M:%S")
    assert d1 == datetime.datetime(2016, 1, 28, 10, 35, 53)
    d2 = to_datetime("2016-01-28 10:35:53.123456", "%Y-%m-%d %H:%M:%S.%f")
    assert d2 == datetime.datetime(2016, 1, 28, 10, 35, 53, 123456)
test_to_datetime()



# Generated at 2022-06-21 04:33:02.939613
# Unit test for function regex_search
def test_regex_search():
    value = '''
    <html>
        <body>
            <span>
                <a href="http://www.google.com?q=test,test2">
            </span>
        </body>
    </html>
    '''
    multiline = True
    regex_url_pattern = r'href="(.+?)"'
    assert regex_search(value, regex_url_pattern, '\\g<1>', multiline=multiline) == 'http://www.google.com?q=test,test2'
    multiline = False
    assert regex_search(value, regex_url_pattern, '\\g<1>', multiline=multiline) == 'http://www.google.com?q=test,test2'
    multiline = True
    regex_url_tags

# Generated at 2022-06-21 04:33:11.681239
# Unit test for function do_groupby
def test_do_groupby():
    """Unit test for do_groupby"""
    import jinja2
    import collections
    env = jinja2.Environment()
    tmp1 = collections.namedtuple('tmp1', 'a b c')
    tmp2 = collections.namedtuple('tmp2', 'd e f')
    values = [tmp1(1,2,3), tmp2(4,5,6)]

    # we're expecting this to fail because the namedtuple repr can't
    # be parsed and eval'ed by safe_eval.
    #
    # See https://github.com/pallets/jinja/blob/master/jinja2/utils.py#L268
    # for the line which generates the namedtuple, and
    # https://github.com/pallets/jinja/commit/d65b11e27b0c42

# Generated at 2022-06-21 04:33:29.912357
# Unit test for function to_uuid
def test_to_uuid():
    ''' Test to_uuid function '''
    # Test plain string
    assert to_uuid('world') == '361e6d51-faec-544a-9079-341386da8e2e'
    # Test with namespace (UUID object)
    assert to_uuid('world', namespace=uuid.UUID('361E6D51-FAEC-444A-9079-341386DA8E2E')) == 'ab9d0586-9851-5b46-b00e-f21a0f19a1eb'
    # Test with namespace (string)

# Generated at 2022-06-21 04:33:45.082644
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2015-07-15 10:00:00") == datetime.datetime(2015,7,15,10,0,0)
    assert to_datetime("15-07-2015 10:00:00", "%d-%m-%Y %H:%M:%S") == datetime.datetime(2015,7,15,10,0,0)
    assert to_datetime("2015-07-15 10:00:00", format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2015,7,15,10,0,0)
    try:
        to_datetime("2015-33-15 10:00:00")
        assert False, "should have raised an exception"
    except:
        pass



# Generated at 2022-06-21 04:33:49.972120
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json([1,2,3]) == '[\n    1,\n    2,\n    3\n]'
    assert to_nice_json({'hello': 'world'}) == '{\n    "hello": "world"\n}'
    assert to_nice_json("hello") == '"hello"'



# Generated at 2022-06-21 04:33:54.934857
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    # Test that all the filters can be constructed without raising
    for filter_name in filters:
        filters[filter_name]



# Generated at 2022-06-21 04:33:58.104588
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    test = {"key": "value"}
    result = "key: value\n"
    assert to_nice_yaml(test) == result



# Generated at 2022-06-21 04:34:04.426473
# Unit test for function from_yaml_all
def test_from_yaml_all():
    test_data = '''---
- hosts: localhost
  gather_facts: no
  vars:
    abc: def
  tasks:
    - debug:
        msg: '{{abc}}'
- hosts: localhost
  gather_facts: no
  vars:
    abc: xyz
  tasks:
    - debug:
        msg: '{{abc}}'
'''
    assert from_yaml_all(test_data) == from_yaml(test_data)


# Generated at 2022-06-21 04:34:11.460213
# Unit test for function get_hash
def test_get_hash():
    hashtype='sha1'
    data="some data string"
    assert get_hash(data) == hashlib.new(hashtype).update(to_bytes(data, errors='surrogate_or_strict')).hexdigest()
    assert get_hash(data, hashtype='md5') == hashlib.new('md5').update(to_bytes(data, errors='surrogate_or_strict')).hexdigest()



# Generated at 2022-06-21 04:34:23.592873
# Unit test for function mandatory
def test_mandatory():
    assert mandatory({}) is not None
    assert mandatory('This is a string') is not None
    assert mandatory(['This', 'is', 'a', 'list']) is not None

    assert mandatory(None) is None

    try:
        mandatory(None, msg='This should raise an error')
        assert False
    except AnsibleFilterError:
        assert True

    try:
        mandatory(None, msg=u'This should raise an error')
        assert False
    except AnsibleFilterError:
        assert True

    try:
        mandatory(None, msg='This should raise an error')
        assert False
    except AnsibleFilterError:
        assert True

    try:
        mandatory(None, msg=123)
        assert False
    except AnsibleFilterError:
        assert True



# Generated at 2022-06-21 04:34:27.905129
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml(dict(key='value')) == dict(key='value')
    assert from_yaml('{key: value}') == dict(key='value')



# Generated at 2022-06-21 04:34:43.142355
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('mystring') == '2bf519ce-4f4b-5e4c-8429-8aa8d35d47a1'
    assert to_uuid('mystring', '361E6D51-FAEC-444A-9079-341386DA8E2E') == '2bf519ce-4f4b-5e4c-8429-8aa8d35d47a1'
    assert to_uuid('mystring', 'a1081183-c163-4e79-a1b2-b0842850e29f') == '9d4c2970-e4a0-5ecb-a1b2-b0842850e29f'

# Generated at 2022-06-21 04:34:56.408506
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2]) == [1, 2]
    assert flatten([[1, 2], 3]) == [1, 2, 3]
    assert flatten([[1, 2], [3]]) == [1, 2, 3]
    assert flatten([[1, 2], [[3]]]) == [1, 2, [3]]
    assert flatten([[1, 2], [[3]]], levels=2) == [1, 2, 3]
    assert flatten([[1, 2], [[3]]], levels=1) == [1, 2, [3]]
    assert flatten([[1, 2], [3]]) == [1, 2, 3]
    assert flatten([[1, 2], None]) == [1, 2]

# Generated at 2022-06-21 04:35:00.584323
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello world') == 'aGVsbG8gd29ybGQ='
    assert b64encode('hello world', encoding='ascii') == 'aGVsbG8gd29ybGQ='
    assert b64encode('中文') == '5Lit5paH'
    assert b64encode('안녕하세요') == '7ISc7Jq47Yq567OE7Yq4'
    assert b64encode(u'你好') == '5L2g5aW9'
    assert b64encode(u'Привет') == '0J/RgNC40LLQtdGC0YHRjA=='

# Generated at 2022-06-21 04:35:08.484477
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(r'foo', 'python') == 'foo'
    assert regex_escape(r'foo', 'posix_basic') == 'foo'
    assert regex_escape(r'foo', 'posix_extended') == 'foo'

    assert regex_escape(r'.', 'python') == '\\.'
    assert regex_escape(r'.', 'posix_basic') == '\\.'
    assert regex_escape(r'.', 'posix_extended') == '\\.'

    assert regex_escape(r'\\', 'python') == '\\\\'
    assert regex_escape(r'\\', 'posix_basic') == '\\\\'
    assert regex_escape(r'\\', 'posix_extended') == '\\\\'


# Generated at 2022-06-21 04:35:14.380588
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined

    assert mandatory("a string") == "a string"
    try:
        mandatory(Undefined())
        assert False, "mandatory() did not fail on an undefined"
    except:
        assert True

    try:
        mandatory(Undefined(), "A specific message")
        assert False, "mandatory() did not fail on an undefined with a msg"
    except:
        assert True



# Generated at 2022-06-21 04:35:22.462700
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml("yea") == "yea"
    assert from_yaml("{a: yea}") == {"a": "yea"}
    assert from_yaml("---\n- yea") == ["yea"]
    assert from_yaml(b"yea") == "yea"
    assert from_yaml(b"{a: yea}") == {"a": "yea"}
    assert from_yaml(b"---\n- yea") == ["yea"]


# Generated at 2022-06-21 04:35:29.439376
# Unit test for function rand
def test_rand():
    def _test_rand_error(end, start, step):
        try:
            filters.rand(end, start, step)
        except AnsibleFilterError:
            pass
        else:
            assert False
    filters = FilterModule()

    assert isinstance(filters.rand(5), integer_types)
    assert isinstance(filters.rand(5), integer_types)
    assert isinstance(filters.rand(1, 5), integer_types)
    assert isinstance(filters.rand(0, 15, 3), integer_types)
    assert isinstance(filters.rand(0, 15, 3, 1), integer_types)
    assert isinstance(filters.rand([1, 2, 3]), integer_types)
    assert isinstance(filters.rand((1, 2, 3)), integer_types)

    _

# Generated at 2022-06-21 04:35:30.759305
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()


# Generated at 2022-06-21 04:35:40.941876
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters["type_debug"](1) == "int"
    assert filters["type_debug"](1.0) == "float"
    assert filters["type_debug"](None) == "NoneType"
    assert filters["type_debug"](bool) == "type"
    assert filters["type_debug"](set()) == "set"
    assert filters["type_debug"](dict()) == "dict"
    assert filters["type_debug"]([]) == "list"
    assert filters["type_debug"](()) == "tuple"
    assert filters["type_debug"]("test") == "str"
    assert filters["type_debug"](b"test") == "bytes"
    assert filters["type_debug"](filter) == "builtin_function_or_method"

# Generated at 2022-06-21 04:35:43.744521
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'foo': 'bar'}) == [{u'key': u'foo', u'value': u'bar'}]



# Generated at 2022-06-21 04:35:47.801350
# Unit test for function path_join
def test_path_join():
    assert path_join(["/", "usr", "lib"]) == "/usr/lib"
    assert path_join("/usr/lib") == "/usr/lib"
    try:
        path_join([5])
    except AnsibleFilterTypeError:
        pass
    else:
        assert False



# Generated at 2022-06-21 04:36:04.283234
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json(None) == 'null'
    assert to_nice_json({'boolean_true': True, 'boolean_false': False}) == \
        '{\n    "boolean_false": false,\n    "boolean_true": true\n}'
    assert to_nice_json([1,2,3]) == '[\n    1,\n    2,\n    3\n]'
    assert to_nice_json({'list': [1,2,3], 'dict': {'key': 'value'}}) == \
        '{\n    "dict": {\n        "key": "value"\n    },\n    "list": [\n        1,\n        2,\n        3\n    ]\n}'



# Generated at 2022-06-21 04:36:11.405486
# Unit test for function to_uuid
def test_to_uuid():
    f = globals()['to_uuid']
    assert f("", uuid.UUID("361E6D51-FAEC-444A-9079-341386DA8E2E")) == uuid.UUID("0d49f646-d6d2-5740-9545-b0c4c7d3f4cb")



# Generated at 2022-06-21 04:36:25.048444
# Unit test for function regex_findall
def test_regex_findall():
    '''
    Verify regex_findall:
    - exact match string
    - sequence of values
    - when value not matched
    - when regex has no match
    '''

    from ansible.test.unit.utils.ansible_runner import AnsibleRunnerTestCase

    class TestRegexFindAll(AnsibleRunnerTestCase):
        ''' Test regex_findall '''

        runner_module = 'MockModule'
        runner_args = {
            'no_log': True
        }

        @classmethod
        def setUpClass(cls):
            cls.vars = {
                'match1': 'this is the string to match',
                'values': ['this', 'is', 'the', 'string', 'to', 'match']
            }

            cls.setup_runner()


# Generated at 2022-06-21 04:36:32.791384
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():

    assert dict_to_list_of_dict_key_value_elements({1: 1}) == [{'value': 1, 'key': 1}]
    assert dict_to_list_of_dict_key_value_elements({1: 1}, key_name='keyname', value_name='valuename') == [{'valuename': 1, 'keyname': 1}]



# Generated at 2022-06-21 04:36:41.899571
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('abc') == 'a9993e364706816aba3e25717850c26c9cd0d89d'
    assert get_hash('abc', 'sha256') == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'



# Generated at 2022-06-21 04:36:44.280504
# Unit test for function strftime
def test_strftime():
    return strftime('%Y-%m-%d %H:%M:%S', time.time())



# Generated at 2022-06-21 04:36:55.895391
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('python') == r'python'
    assert regex_escape('-[]') == r'\-\[\]'
    assert regex_escape(r'-[]\^$.*+?{}|()') == r'\-\[\]\\\^\$\.\*\+\?\{\}\|\(\)'
    assert regex_escape('-[]\^$.*+?{}|()') == r'\-\[\]\\\^\$\.\*\+\?\{\}\|\(\)'

    assert regex_escape('python', re_type='posix_basic') == r'python'
    assert regex_escape('-[]', re_type='posix_basic') == r'-\[\]'

# Generated at 2022-06-21 04:37:02.154304
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'key one': 'value one', 'key two': 'value two'}) == [
        {'key': 'key one', 'value': 'value one'}, {'key': 'key two', 'value': 'value two'}]



# Generated at 2022-06-21 04:37:04.272919
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall('a', 'a') == ['a']



# Generated at 2022-06-21 04:37:05.268737
# Unit test for function mandatory
def test_mandatory():
    return mandatory('hi')



# Generated at 2022-06-21 04:37:24.204431
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    ''' dict_to_list_of_dict_key_value_elements should return an empty list with an empty dict'''
    mydict = {}
    assert dict_to_list_of_dict_key_value_elements(mydict) == []
    ''' dict_to_list_of_dict_key_value_elements should return a list of dicts with keys and values
        centered in the input dictionary'''
    mydict = {'mykey1': 'myvalue1', 'mykey2': 'myvalue2'}
    assert dict_to_list_of_dict_key_value_elements(mydict) == [{'key': 'mykey1', 'value': 'myvalue1'}, {'key': 'mykey2', 'value': 'myvalue2'}]


# Generated at 2022-06-21 04:37:29.862719
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    filters = x.filters()
    assert filters is not None
    assert type(filters) is dict
    assert len(filters) > 0
    assert 'b64decode' in filters
    assert filters['b64decode'] is b64decode
    assert 'b64encode' in filters
    assert filters['b64encode'] is b64encode
    assert 'to_uuid' in filters
    assert filters['to_uuid'] is to_uuid

# Generated at 2022-06-21 04:37:39.240617
# Unit test for function randomize_list
def test_randomize_list():
    fail = True
    rl = randomize_list([0, 1, 2, 3, 4], 1)
    if rl != [3, 2, 0, 1, 4]:
        print("fail: list returned was: %s" % rl)
    else:
        fail = False
    if fail:
        print("test_randomize_list(): FAILED")
        sys.exit(1)
    else:
        print("test_randomize_list(): PASSED")



# Generated at 2022-06-21 04:37:47.614032
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():

    list_data = [{"key": "one", "value": 1}, {"key": "two", "value": 2}]
    test_func = list_of_dict_key_value_elements_to_dict
    expected = {"one": 1, "two": 2}
    result = test_func(list_data)
    assert result == expected, "Expected \n%s, but got \n%s" % (expected, result)



# Generated at 2022-06-21 04:37:53.766899
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2016-03-22 21:57:53') == datetime.datetime(2016, 3, 22, 21, 57, 53)
    assert to_datetime('2016-03-22 21:57:53', '%Y-%m-%d %H:%M:%S') == datetime.datetime(2016, 3, 22, 21, 57, 53)
    assert to_datetime('20161117095702', '%Y%m%d%H%M%S') == datetime.datetime(2016, 11, 17, 9, 57, 2)
    assert to_datetime('2016-11-17 09:57:02', '%Y-%m-%d %H:%M:%S') == datetime.datetime(2016, 11, 17, 9, 57, 2)
   

# Generated at 2022-06-21 04:37:55.897992
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]

    r = subelements(obj, 'groups')
    assert(r == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')])



# Generated at 2022-06-21 04:38:09.464346
# Unit test for function do_groupby
def test_do_groupby():
    """
    Test that the jinja2 2.9.0 bug is fixed in the do_groupby function
    """
    from ansible.template.safe_eval import safe_eval
    from distutils.version import LooseVersion
    import jinja2
    from jinja2.runtime import Context

    if LooseVersion(jinja2.__version__) >= LooseVersion('2.9.0') and LooseVersion(jinja2.__version__) < LooseVersion('2.9.5'):
        # Create a dict of dicts
        test_data = dict(
            test1=dict(
                key1='second',
                key2='third',
            ),
            test2=dict(
                key1='second',
                key2='third',
            ),
        )

        # Create a jin

# Generated at 2022-06-21 04:38:16.151363
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True)
    assert to_bool('true')
    assert to_bool('True')
    assert to_bool('yes')
    assert to_bool('on')
    assert to_bool('1')
    assert to_bool(1)
    assert not to_bool(False)
    assert not to_bool('False')
    assert not to_bool('false')
    assert not to_bool('no')
    assert not to_bool('off')
    assert not to_bool('0')
    assert not to_bool(0)



# Generated at 2022-06-21 04:38:20.371560
# Unit test for function path_join
def test_path_join():
    my_path = path_join(['/tmp/', 'var', 'lib'])
    assert my_path == '/tmp/var/lib'
# end of unit test


# Generated at 2022-06-21 04:38:30.639772
# Unit test for function quote
def test_quote():
    assert quote(None) == ''
    assert quote('foo') == 'foo' # no change
    assert quote('foo bar') == 'foo bar' # no change
    assert quote('foo"bar') == '\'foo"bar\''
    assert quote('foo\nbar') == '\'foo\nbar\''
    assert quote('foo\\bar') == "foo\\bar"
    assert quote('foo\\bar', protected='\\') == '\'foo\\bar\''



# Generated at 2022-06-21 04:38:42.471243
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 0) == 1
    assert ternary(False, 1, 0) == 0
    assert ternary(False, 'a', 'b') == 'b'
    assert ternary('foo', 'a', 'b') == 'a'
    assert ternary(None, 1, 0, 2) == 2
    assert ternary(None, 1, 0) == 0
    assert ternary(True, 100, 0, 2) == 100



# Generated at 2022-06-21 04:38:46.938085
# Unit test for function b64decode
def test_b64decode():
    assert b64decode(b64encode('ansible')) == 'ansible'
    assert b64decode(b64encode(u'ansible', encoding='ascii')) == u'ansible'
    assert b64decode(b64encode(u'ansible'), encoding='ascii') == u'ansible'



# Generated at 2022-06-21 04:38:56.111355
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('foo') == '61e6d512-faec-5a44-b091-8765d1333a8e'
    assert to_uuid('foo', namespace='{2f785ade-3116-11e3-a5e2-0800200c9a66}') == '6e37c9c7-6cfe-592d-b6c8-280301e5a2d0'
    assert to_uuid('foo', namespace=UUID_NAMESPACE_ANSIBLE) == '61e6d512-faec-5a44-b091-8765d1333a8e'

# Generated at 2022-06-21 04:38:59.326311
# Unit test for function quote
def test_quote():
    assert quote("abc") == u"'abc'"

# Generated at 2022-06-21 04:39:08.609614
# Unit test for function regex_findall

# Generated at 2022-06-21 04:39:09.570019
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'random' in FilterModule.filters(FilterModule())



# Generated at 2022-06-21 04:39:18.582326
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote(42) == u"42"
    assert quote('foo') == u"'foo'"
    assert quote('"foo"') == u"'\"foo\"'"
    assert quote('\\') == u"'\\\\'"
    assert quote('\n') == u"'\n'"
    assert quote('\r\n') == u"'\r\n'"
    assert quote('\n\n') == u"'\n\n'"
    assert quote('\r\n\r\n') == u"'\r\n\r\n'"
    assert quote('\t') == u"'\t'"
    assert quote(b'foo') == u"'foo'"
    assert quote(b'"foo"') == u"'\"foo\"'"
    assert quote(b'\\') == u"'\\\\'"


# Generated at 2022-06-21 04:39:27.126535
# Unit test for function flatten
def test_flatten():
    assert flatten([1, 2, 3]) == [1, 2, 3]
    assert flatten([[1, 2], 3]) == [1, 2, 3]
    assert flatten([[[1, 2], 3]], levels=1) == [[1, 2], 3]
    assert flatten([[[1, 2], 3]], levels=2) == [1, 2, 3]
    assert flatten([[[1, 2], 3]], levels=3) == [1, 2, 3]
    assert flatten([[[1, 2], 3]], levels=0) == [[[1, 2], 3]]
    assert flatten([[[1, 2], 3]], levels=3) == [1, 2, 3]
    assert flatten([[[1, 2], 3]], levels=4) == [1, 2, 3]
   

# Generated at 2022-06-21 04:39:42.852406
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    pw = ('$1$rasmusle$rISCgZzpwk3UhDidwXvin0'
          '$apr1$I9J98HHB$RM6m.L0gtOqMqJQM6/PMy/')

    assert get_encrypted_password("rasmuslerdorf", "md5") == pw
    assert get_encrypted_password("rasmuslerdorf", "md5", salt="rasmusle") == pw
    assert get_encrypted_password("rasmuslerdorf", "md5", salt="rasmusle", salt_size=8) == pw

    # Blowfish

# Generated at 2022-06-21 04:39:48.524938
# Unit test for function strftime
def test_strftime():
    result = strftime('%Y-%m-%d %H:%M:%S', 1358003195)
    assert result == '2013-01-14 20:59:55'

