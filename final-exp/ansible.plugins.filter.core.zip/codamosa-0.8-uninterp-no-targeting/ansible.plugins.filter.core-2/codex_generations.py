

# Generated at 2022-06-21 04:30:24.092615
# Unit test for function to_uuid
def test_to_uuid():
    assert to_uuid('test') == '36a8c7f2-1f17-5a0d-8ed7-a81b89a986ab'
    assert to_uuid(to_uuid('test')) == '36a8c7f2-1f17-5a0d-8ed7-a81b89a986ab'

    assert to_uuid('test', '36a8c7f2-1f17-5a0d-8ed7-a81b89a986ab') == '87f68a44-4e7e-5b0d-81fe-58e2e27d8fe8'

# Generated at 2022-06-21 04:30:35.560967
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('ANewHope', 'sha1') == '8df6db28b9f7e639d8d8a86db15f2ab49b3a3a3d'
    assert get_hash('ANewHope', 'sha256') == '0faf2ab51f2aa3d10cb43cb8b9f944f7e4b0d9230d4bdb9951e4c22b380f2c2a'
    assert get_hash('ANewHope', 'md5') == 'f5b6c5e5e5d534f0563b5e5b5c5d5f5e'

# Generated at 2022-06-21 04:30:46.858710
# Unit test for function to_uuid
def test_to_uuid():
    if sys.version_info >= (3, 0, 0):
        # Python 3 has native support for UUID namespace
        assert to_uuid('someid', 'f5b7e5e5-ee49-470b-ba36-72b35a9f9bdc') == u'a23d2a2b-832c-5c5c-9435-e3e9d9a54c1e'
    else:
        # str() is a Python 2 command
        assert to_uuid('someid', 'f5b7e5e5-ee49-470b-ba36-72b35a9f9bdc') == str('a23d2a2b-832c-5c5c-9435-e3e9d9a54c1e')


# Generated at 2022-06-21 04:30:57.052549
# Unit test for function mandatory
def test_mandatory():
    from jinja2.runtime import Undefined
    from ansible.module_utils.six import PY2

    # In PY3, testing for 'Undefined' causes a
    # 'DeprecationWarning: Using or importing the ABCs from 'collections' instead of from 'collections.abc' is deprecated'
    if not PY2:
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # the following will cause the warning to be thrown once
            isinstance(None, collections.Sequence)
    assert isinstance(mandatory(None), type(None))
    assert isinstance(mandatory(0), type(0))
    assert isinstance(mandatory(False), type(False))

# Generated at 2022-06-21 04:31:05.538419
# Unit test for function subelements
def test_subelements():
    obj1 = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    obj2 = {"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}
    obj3 = [{"name": "alice", "groups": "wheel", "authorized": ["/tmp/alice/onekey.pub"]}]
    obj4 = [{"name": "alice", "groups": None, "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj1, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]

# Generated at 2022-06-21 04:31:08.206633
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('test string') == 'dGVzdCBzdHJpbmc='



# Generated at 2022-06-21 04:31:19.090783
# Unit test for function from_yaml_all

# Generated at 2022-06-21 04:31:26.902716
# Unit test for function ternary
def test_ternary():
    res = ternary(True, 'ok', 'nope')
    assert res == 'ok'
    res = ternary(False, 'ok', 'nope')
    assert res == 'nope'
    res = ternary(None, 'ok', 'nope', none_val='nada')
    assert res == 'nada'
    res = ternary('', 'ok', 'nope', none_val='nada')
    assert res == 'nope'



# Generated at 2022-06-21 04:31:39.908144
# Unit test for function b64decode
def test_b64decode():
    assert b64decode("cGxlYXN1cmUu") == "pleasure."
    assert b64decode("cGxlYXN1cmUu", "ascii") == "pleasure."
    assert b64decode("bGVhc3VyZS4=") == "leasure."
    assert b64decode("bGVhc3VyZS4=", "ascii") == "leasure."
    assert b64decode("bG9yZW0uaXBzdW0=") == "loremipsum"
    assert b64decode("bG9yZW0uaXBzdW0=", "ascii") == "loremipsum"

# Generated at 2022-06-21 04:31:46.457965
# Unit test for function from_yaml
def test_from_yaml():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    assert from_yaml(AnsibleUnsafeText('a: 1')) == {u'a': 1}
    assert from_yaml('a: 1') == {u'a': 1}
    assert from_yaml({'a': 1}) == {u'a': 1}
    assert from_yaml('a: 1') == {u'a': 1}
    assert from_yaml([1, 2, 3]) == [1, 2, 3]
    assert from_yaml(1) == 1

    templar = Templar(loader=None)
    assert from_yaml(templar.template('a: 1')) == {u'a': 1}

# Generated at 2022-06-21 04:32:01.211964
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    result = get_encrypted_password('12345')
    assert result.startswith(u'$6$')
    result = get_encrypted_password('12345', hashtype='blowfish', salt_size=4)
    assert result.startswith(u'$2b$')
    result = get_encrypted_password('12345', hashtype='sha512', salt=b'123', rounds=20000)
    assert result.startswith(u'$6$rounds=20000$123$')
    result = get_encrypted_password('12345', hashtype='md5', ident=b'ABC')
    assert result.startswith(u'$1$ABC$')



# Generated at 2022-06-21 04:32:11.691723
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Jinja2Environment

    env = Jinja2Environment()

    # Create a list that can be iterated by the Jinja2 `groupby` function
    my_list = [{'os': 'centos', 'num': '6'},
               {'os': 'centos', 'num': '7'},
               {'os': 'ubuntu', 'num': '1604'},
               {'os': 'ubuntu', 'num': '1710'},
               {'os': 'ubuntu', 'num': '1804'},
               {'os': 'redhat', 'num': '7'}]

    # Create the args expected by the Jinja2 groupby function
    args = [my_list, 'os']

    # Call the jinja2 groupby function, and verify that all the returned namedtuples


# Generated at 2022-06-21 04:32:15.597844
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    mydict = {'one': 1, 'two': 2, 'three': 3}
    result = dict_to_list_of_dict_key_value_elements(mydict)
    assert result == [{'value': 1, 'key': 'one'}, {'value': 2, 'key': 'two'}, {'value': 3, 'key': 'three'}]
    # Test setting non-default key/value names
    result = dict_to_list_of_dict_key_value_elements(mydict, 'k', 'v')
    assert result == [{'v': 1, 'k': 'one'}, {'v': 2, 'k': 'two'}, {'v': 3, 'k': 'three'}]



# Generated at 2022-06-21 04:32:26.556188
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello') == 'aGVsbG8='
    assert b64encode('hello', encoding='utf-16') == 'CgcIGhvbG8K'
    assert b64encode('b64encode', encoding='latin-1') == 'YjY0ZW5jb2Rl'
    assert b64encode(u'\u20ac', encoding='utf-8') == '4oKs'
    assert b64encode(u'\u20ac', encoding='utf-16') == 'IMK/'


# Generated at 2022-06-21 04:32:38.143773
# Unit test for function flatten
def test_flatten():
    assert flatten([1,2,3]) == [1,2,3]
    assert flatten([[1,2,3]]) == [1,2,3]
    assert flatten([[1,2,3],[4,5,6]]) == [1,2,3,4,5,6]
    assert flatten([[1,2,3],[4,5,[6]]]) == [1,2,3,4,5,[6]]
    assert flatten([[1,2,3],[4,5,[6]]], levels=0) == [[1,2,3],[4,5,[6]]]
    assert flatten([[1,2,3],[4,5,[6]]], levels=1) == [1,2,3,4,5,[6]]

# Generated at 2022-06-21 04:32:45.029549
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 'true', 'false') == 'true'
    assert ternary(False, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false') == 'false'
    assert ternary(None, 'true', 'false', 'none') == 'none'


# Generated at 2022-06-21 04:32:46.750417
# Unit test for function fileglob
def test_fileglob():
  assert ['./test'] == fileglob('./test')
  assert [] == fileglob('test')


# Generated at 2022-06-21 04:32:54.672401
# Unit test for function path_join
def test_path_join():
    assert path_join('foo') == 'foo'
    assert path_join(['foo']) == 'foo'
    assert path_join(['foo', 'bar']) == 'foo/bar'
    assert path_join('foo', 'bar') == 'foo/bar'
    # function converts single string to list
    assert path_join('foo/bar', '/foobar') == 'foo/bar//foobar'



# Generated at 2022-06-21 04:33:03.096646
# Unit test for function to_nice_json
def test_to_nice_json():
    value = dict(a=[1,2,3], b=dict(c=['a', 'b', 'c']), d=set(['a', 'b', 'c']))
    out = to_nice_json(value)
    assert out == '{\n    "a": [\n        1,\n        2,\n        3\n    ],\n    "b": {\n        "c": [\n            "a",\n            "b",\n            "c"\n        ]\n    },\n    "d": [\n        "a",\n        "b",\n        "c"\n    ]\n}'


# Generated at 2022-06-21 04:33:10.428921
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]
    mydict = {'a': 1, 'b': 2}
    assert list_of_dict_key_value_elements_to_dict(mylist) == mydict
    assert list_of_dict_key_value_elements_to_dict(mylist, 'value', 'key') == dict((v, k) for k, v in iteritems(mydict))



# Generated at 2022-06-21 04:33:22.764711
# Unit test for function to_nice_json
def test_to_nice_json():
    """Test to make sure the function prints the expected results"""
    import json

    a = {
        "foo": "bar",
        "bar": "baz",
    }
    assert to_nice_json(a) == json.dumps(a, indent=4, sort_keys=True, separators=(',', ': '), cls=AnsibleJSONEncoder)

    b = {
        "a": 1,
        "foo": "bar",
        "bar": "baz",
    }
    assert to_nice_json(b) == json.dumps(b, indent=4, sort_keys=True, separators=(',', ': '), cls=AnsibleJSONEncoder)


# Generated at 2022-06-21 04:33:32.387464
# Unit test for function path_join
def test_path_join():
    assert path_join('/etc/') == '/etc/'
    assert path_join('/etc', 'passwd') == '/etc/passwd'
    assert path_join(['/', 'etc', 'passwd']) == '/etc/passwd'
    assert path_join('/etc', '/passwd') == '/passwd'
    assert path_join('etc', 'passwd') == 'etc/passwd'
    try:
        assert path_join(42, 'passwd') == 'etc/passwd'
    except:
        pass
    else:
        raise AssertionError("AnsibleFilterError not raised")



# Generated at 2022-06-21 04:33:35.984254
# Unit test for function to_json
def test_to_json():
    test_value = {
        "test_key": "test_value"
    }
    assert json.loads(to_json(test_value)) == test_value



# Generated at 2022-06-21 04:33:37.133059
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)
    assert callable(FilterModule)



# Generated at 2022-06-21 04:33:40.792273
# Unit test for function to_yaml
def test_to_yaml():
    """
    Test for `ansible_collections.ansible.community.plugins.filter.core.to_yaml`
    """

    assert 'a: 1\n' == to_yaml({'a': 1})



# Generated at 2022-06-21 04:33:43.413957
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(1, "msg") == 1
    #assert mandatory(Undefined) == "msg"



# Generated at 2022-06-21 04:33:44.385970
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True

# Generated at 2022-06-21 04:33:54.942928
# Unit test for function from_yaml_all
def test_from_yaml_all():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_list_of_strings(self):
            data = (
                "- 1\n"
                "- 2\n"
                "- 3\n"
            )
            expected = [1, 2, 3]
            actual = from_yaml_all(data)
            self.assertEqual(actual, expected)

        def test_list_of_dicts(self):
            data = (
                "- {key: value1}\n"
                "- {key: value2}\n"
                "- {key: value3}\n"
            )
            expected

# Generated at 2022-06-21 04:34:01.876474
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    our_dict = dict(foo=1, bar=2, baz=3)
    expected_result = [
        dict(key='foo', value=1),
        dict(key='bar', value=2),
        dict(key='baz', value=3)
    ]
    assert dict_to_list_of_dict_key_value_elements(our_dict) == expected_result



# Generated at 2022-06-21 04:34:13.519452
# Unit test for function path_join
def test_path_join():
    """ Unit tests for `path_join`."""
    basic_test = path_join(['one', 'two', 'three'])
    assert basic_test == 'one/two/three'
    basic_test = path_join('one/two/three')
    assert basic_test == 'one/two/three'
    basic_test = path_join(['one', [2, 3], 'three'])
    assert basic_test == 'one/2/3/three'
    basic_test = path_join(['one', [2, ['three', 'four'], 'five']])
    assert basic_test == 'one/2/three/four/five'
    set_test = set(['/', 'one'])
    assert path_join(set_test) == '/one'
    fdl_test = frozens

# Generated at 2022-06-21 04:34:32.796447
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('foo', 'o') == 'o'
    assert regex_search('foo', 'o', '\\g<0>') == ['o']
    assert regex_search('foo', 'o', '\\1') == []
    assert regex_search('foo', 'o', '\\g<1>') == []
    assert regex_search('foo', 'o', '\\1', '\\g<1>') == ['o']
    # invalid argument
    try:
        regex_search('foo', 'o', 'gh<0>')
        assert False
    except Exception:
        assert True



# Generated at 2022-06-21 04:34:35.804884
# Unit test for function quote
def test_quote():
    assert not to_text(quote('foo bar')) == 'foo bar' or to_text(quote('foo bar')) == '"foo bar"'


# Generated at 2022-06-21 04:34:40.988340
# Unit test for function path_join
def test_path_join():
    assert path_join(['./', 'home', 'user', 'file.txt']) == './home/user/file.txt'
    assert path_join(['./home/user/file.txt']) == './home/user/file.txt'
    assert path_join('./home/user/file.txt') == './home/user/file.txt'



# Generated at 2022-06-21 04:34:49.234763
# Unit test for function combine
def test_combine():
    assert combine() == {}
    assert combine({}, {}) == {}
    assert combine({'a': 1}, {}) == {'a': 1}
    assert combine({}, {'a': 1}) == {'a': 1}
    assert combine({'a': 1}, {'b': 1}) == {'a': 1, 'b': 1}
    assert combine({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine({'a': 1, 'b': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine({'a': [1, 2]}, {'a': [3]}) == {'a': [3]}

# Generated at 2022-06-21 04:35:03.381508
# Unit test for function to_json
def test_to_json():
    from ansible.template import TO_JSON_FILTER_PLUGIN_PATH, TO_JSON_FILTER_PLUGIN_NAME, TO_JSON_FILTER_PLUGIN_ARGS

    # FIXME(retr0h): Use json fixture
    test_dict = {
        'test_1': ['item_1', 'item_2', 'item_3'],
        'test_2': {
            'test_2_1': {'test_2_1_1': ['item_1', 'item_2', 'item_3']},
            'test_2_2': 'item_3',
            'test_2_3': 'item_1',
        }
    }

    json_test_dict = to_json(test_dict)
    assert type(json_test_dict) == str

    #

# Generated at 2022-06-21 04:35:05.998478
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml({'foo': 'bar'}) == u"{foo: bar}\n"



# Generated at 2022-06-21 04:35:14.010993
# Unit test for function to_bool
def test_to_bool():
    assert to_bool(True) is True
    assert to_bool(False) is False
    assert to_bool(None) is None
    assert to_bool(1) is True
    assert to_bool(0) is False
    assert to_bool("1") is True
    assert to_bool("0") is False
    assert to_bool("true") is True
    assert to_bool("false") is False
    assert to_bool("True") is True
    assert to_bool("False") is False
    assert to_bool("") is False



# Generated at 2022-06-21 04:35:19.180999
# Unit test for function to_yaml
def test_to_yaml():
    test_obj = {u'a': u'b', u'c': [1, 2, 3]}
    test_result = to_yaml(test_obj)
    assert test_result == u'a: b\nc:\n- 1\n- 2\n- 3\n'

    test_obj = {u'a': u'b', u'c': [1, 2, (1, 2, 3)]}
    test_result = to_yaml(test_obj)
    assert test_result == u'a: b\nc:\n- 1\n- 2\n- - 1\n  - 2\n  - 3\n'



# Generated at 2022-06-21 04:35:24.898395
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert isinstance(filters, dict), "Expected the return to be a dict, got %s" % type(filters)
    assert 'bool' in filters, "Expected the dict to contain a key 'bool', but it was missing"
    assert callable(filters['bool']), "Expected the value of key 'bool' to be callable, got %s" % type(filters['bool'])

# Generated at 2022-06-21 04:35:39.798941
# Unit test for function get_encrypted_password
def test_get_encrypted_password():


    def check(password, hashtype, salt, salt_size, rounds, ident, expected):
        assert get_encrypted_password(password, hashtype=hashtype, salt=salt, salt_size=salt_size, rounds=rounds, ident=ident) == expected

    check('some password', 'md5', 'salt', None, None, None, '$1$salt$XztWnfoBkwwokwjGZhwIq.')
    check('some password', 'blowfish', '$2a$', None, 4, None, '$2a$04$5QCmgnR5ZJGk7F.9B3U6.uU6ZXwVL/7D/aPsY4N4P4NCAC/HV7kfS')

# Generated at 2022-06-21 04:35:47.303260
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace("test\ntest2","test.*","xxx") == "xxx\nxxx"
    assert regex_replace("testtest","test.*","xxx") == "xxx"



# Generated at 2022-06-21 04:35:55.264610
# Unit test for function subelements
def test_subelements():
    ''' test subelements '''
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    ret = subelements(obj, 'groups')
    assert len(ret) == 1
    assert ret[0][0]['name'] == 'alice'
    assert ret[0][1] == 'wheel'
    assert subelements(obj, 'groups.0') == ret

    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]},
           {"name": "bob", "groups": ["admin"], "authorized": ["/tmp/bob/onekey.pub"]}]
    ret = subelements(obj, 'name')

# Generated at 2022-06-21 04:36:05.365110
# Unit test for function comment

# Generated at 2022-06-21 04:36:12.485257
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    assert to_nice_yaml({'array': ['elem1', 'elem2', {'dict': ['elem3']}], 'string': 'test'}) == u'''---
array:
- elem1
- elem2
- dict:
  - elem3
string: test
'''



# Generated at 2022-06-21 04:36:24.098958
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d %H:%M:%S', '1476986196') == '2016-10-20 15:43:16'
    assert strftime('%Y-%m-%d %H:%M:%S', 1476986196) == '2016-10-20 15:43:16'
    assert strftime('%Y-%m-%d %H:%M:%S', 1476986196.8) == '2016-10-20 15:43:16'
    assert strftime('%Y-%m-%d') == time.strftime('%Y-%m-%d')


# Generated at 2022-06-21 04:36:36.357069
# Unit test for function get_hash
def test_get_hash():
    assert get_hash('foobar') == '8843d7f92416211de9ebb963ff4ce28125932878'
    assert get_hash('foobar', 'sha256') == 'c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2'
    assert get_hash('foobar', 'sha512') == 'f7fbba6e0636f890e56fbbf3283e524c6fa3204ae298382d624741d0dc6638326e282c41be5e4254d8820772c5518a2c5a8c0c7f7eda19594a7eb539453e1ed7'
    # test unsupported hash

# Generated at 2022-06-21 04:36:38.601655
# Unit test for function b64decode
def test_b64decode():
    assert (b64decode(u'aGVsbG8gd29ybGQ=') == u'hello world' )
    assert (b64decode(b'aGVsbG8gd29ybGQ=') == u'hello world' )
    assert (b64decode('aGVsbG8gd29ybGQ=') == u'hello world' )



# Generated at 2022-06-21 04:36:42.089006
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2017-08-23 12:12:12") == datetime.datetime(2017, 8, 23, 12, 12, 12)
    assert to_datetime("2017-08-23") == datetime.datetime(2017, 8, 23, 0, 0, 0)
    try:
        to_datetime("not a real date")
        raise AssertionError("to_datetime didn't fail with a bogus date")
    except ValueError:
        pass
    try:
        to_datetime("2017-08-23", format="bad format")
        raise AssertionError("to_datetime didn't fail with a bad format")
    except ValueError:
        pass



# Generated at 2022-06-21 04:36:45.672477
# Unit test for function ternary
def test_ternary():
    assert ternary(True,'yes','no','null')=='yes'
    assert ternary(False,'yes','no','null')=='no'
    assert ternary(None,'yes','no','null')=='null'


# Generated at 2022-06-21 04:36:51.547725
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    assert dict_to_list_of_dict_key_value_elements({'a': 1, 'b': 2}) == [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]



# Generated at 2022-06-21 04:37:09.403226
# Unit test for function mandatory
def test_mandatory():
    assert mandatory("foo") == "foo"
    try:
        mandatory("foo", msg="foo")
        assert False, "Failed to fail for missing msg"
    except AnsibleFilterError:
        pass
    try:
        mandatory("foo")
        assert False, "Failed to fail for normal use"
    except AnsibleFilterError:
        pass
    try:
        mandatory({})
        assert False, "Failed to fail for dict"
    except AnsibleFilterError:
        pass
    try:
        mandatory([])
        assert False, "Failed to fail for list"
    except AnsibleFilterError:
        pass
    try:
        mandatory(None)
        assert False, "Failed to fail for None"
    except AnsibleFilterError:
        pass

# Generated at 2022-06-21 04:37:15.967583
# Unit test for function regex_replace
def test_regex_replace():
    '''
    regex_replace:
      value: This is a test string.
    '''
    assert regex_replace(value='This is a test string.', pattern='(.*?)\s(.*?)\s(.*?)$', replacement='\\3 \\2 \\1') == 'string. a is This'



# Generated at 2022-06-21 04:37:29.186952
# Unit test for function combine
def test_combine():
    # pylint: disable=redefined-outer-name
    def assertDictEquals(a, b):
        assert a == b, "expected:\n%s\ngot:\n%s" % (to_nice_yaml(a), to_nice_yaml(b))

    # Test function with no argument
    assertDictEquals(combine(), {})

    # Test function with one dict as argument
    d1 = dict(a=1, b="2", c=True)
    assertDictEquals(combine(d1), d1)

    # Test function with 2 dicts as arguments
    d1 = dict(c=1, e="2", f=True)
    d2 = dict(a=1, b="2", c=False)

# Generated at 2022-06-21 04:37:42.620929
# Unit test for function b64encode
def test_b64encode():
    assert b64encode('hello') == 'aGVsbG8='
    assert b64encode('hello', encoding='ascii') == 'aGVsbG8='
    assert b64encode('привет', encoding='utf8') == '0L/RgNC40LLQtdGC'
    assert b64encode('привет', encoding='ascii') == 'w6lyaWV0'
    assert b64encode('привет', encoding='windows-1251') == 'w6lyaWV0'
    assert b64encode('♥') == '4pyT'
    assert b64encode('♥', encoding='ascii') == '77+9'

# Generated at 2022-06-21 04:37:51.174459
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2018-04-01 00:00:00", format="%Y-%m-%d %H:%M:%S") == datetime.datetime(2018,4,1,0,0,0)
    assert to_datetime("2018-04-01", format="%Y-%m-%d") == datetime.datetime(2018,4,1,0,0,0)
    try:
        to_datetime("2018-04-01 00:00:00", format="%Y") # No Hour Minute Second
    except ValueError as e:
        assert "No Hour" in str(e)
    try:
        to_datetime("2018-04-01 00:00:00") # Invalid format
    except ValueError as e:
        assert "Invalid format" in str(e)
   

# Generated at 2022-06-21 04:38:04.237189
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    import crypt
    from passlib.hash import sha512_crypt
    from random import randint

    for hashtype in ('md5', 'blowfish', 'sha256', 'sha512'):
        for rounds in (None, 1, 2 ** randint(1, 8)):
            for salt_size in (None, 1, 2 ** randint(1, 8)):
                for ident in (None, '', '$' + '$'.join(['{}={}'.format(*r) for r in (('1', '22'), ('2', '33'), ('3', '44'), ('4', '55'), ('5', '66'))])):
                    password = 'test123'
                    salt = get_encrypted_password(password, hashtype, salt=None, salt_size=salt_size, rounds=rounds, ident=ident)

# Generated at 2022-06-21 04:38:10.539556
# Unit test for function from_yaml_all
def test_from_yaml_all():
    x = from_yaml_all("""
- one
- two
- three
""")
    assert x == ['one', 'two', 'three']
    x = from_yaml_all("""
one: 1
two: 2
three: 3
""")
    assert x == dict(one=1, two=2, three=3)



# Generated at 2022-06-21 04:38:18.284913
# Unit test for function subelements
def test_subelements():
    obj = [{"name": "alice", "groups": ["wheel"], "authorized": ["/tmp/alice/onekey.pub"]}]
    assert subelements(obj, 'groups') == [({'name': 'alice', 'groups': ['wheel'], 'authorized': ['/tmp/alice/onekey.pub']}, 'wheel')]



# Generated at 2022-06-21 04:38:29.542971
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    assert get_encrypted_password('mypassword') == '$1$Eb7hFoZH$o7Vu8WtYPH9lCMf2Cx11n1'
    assert get_encrypted_password('mypassword', salt='mysalt') == '$1$mysalt$n1cnxjKWrdja8MVpTHZTF.'
    assert get_encrypted_password('mypassword', salt='mysalt', rounds=5000) == '$1$mysalt$DZ0wzuluNpB3hj9XsYs/L1'
    assert get_encrypted_password('mypassword', hashtype='md5') == '$1$Eb7hFoZH$o7Vu8WtYPH9lCMf2Cx11n1'

# Generated at 2022-06-21 04:38:39.539482
# Unit test for function regex_search
def test_regex_search():
    assert regex_search('words, words, words.', '\\w+', '\\1', '\\g<1>') == ['words', 'words']
    assert regex_search('words, words, words.', '\\w+', '\\3') is None
    assert regex_search('words, words, words.', '\\w+', '\\g<3>') is None
    assert regex_search('words, words, words.', '\\w+', '\\2') == ['words']
    assert regex_search('words, words, words.', '\\w+', '\\g<2>') == ['words']
    assert regex_search('my password is: p@s$w0rd', 'p@s\$w0rd', ignorecase=False, multiline=False) == 'p@s$w0rd'

# Generated at 2022-06-21 04:39:19.154897
# Unit test for function regex_findall
def test_regex_findall():
    value = "foo bar baz"
    regex = "[a-z]+"
    assert regex_findall(value, regex, multiline=False, ignorecase=False) == ['foo', 'bar', 'baz']



# Generated at 2022-06-21 04:39:27.167307
# Unit test for function b64decode
def test_b64decode():
# TODO: This does not pass yet in Ansible Galaxy.  There needs to be a better way
#       to test this.
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.utils import plugin_docs

    class TestAnsibleGalaxyBase(unittest.TestCase):

        # Tests for function b64decode
        def test_b64decode_module_exists(self):
            self.assertTrue(hasattr(plugin_docs, 'b64decode'))

        def test_b64decode_passed_string(self):
            result = b64decode('dGVzdA==')
            self.assertEqual(result, 'test')


# Generated at 2022-06-21 04:39:30.609170
# Unit test for function strftime
def test_strftime():
    assert strftime('%Y-%m-%d', '1400000000.0') == '2014-01-13'
    assert strftime('%Y-%m-%d') != '2014-01-13'



# Generated at 2022-06-21 04:39:39.666476
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{'key': 'a', 'value': 'A'}, {'key': 'b', 'value': 'B'}]
    mydict = list_of_dict_key_value_elements_to_dict(mylist)
    print("dict_to_list_of_dict_key_value_elements returns %s" % mydict)



# Generated at 2022-06-21 04:39:50.027430
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape(string='\\') == '\\\\'
    assert regex_escape(string='\\\\') == '\\\\\\\\'
    assert regex_escape(string='[a-z]') == '\\[a\\-z\\]'
    assert regex_escape(string='.') == '\\.'
    assert regex_escape(string='[') == '\\['
    assert regex_escape(string=']') == '\\]'
    assert regex_escape(string='[abc]') == '\\[abc\\]'
    assert regex_escape(string='a[a-z]c') == 'a\\[a\\-z\\]c'
    assert regex_escape(string='$a') == '\\$a'
    assert regex_escape(string='a$') == 'a\\$'