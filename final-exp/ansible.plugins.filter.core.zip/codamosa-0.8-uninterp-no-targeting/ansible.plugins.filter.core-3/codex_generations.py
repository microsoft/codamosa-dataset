

# Generated at 2022-06-21 04:30:35.536317
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("hello") == "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d"
    assert get_hash("hello", "sha256") == "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
    assert get_hash("hello", "sha512") == "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043"

# Generated at 2022-06-21 04:30:46.859292
# Unit test for function comment
def test_comment():
    assert "This is a test" == comment(
        "This is a test",
        style='plain')
    assert ("\n".join([
        '/*',
        ' * This is a test',
        ' */']) == comment(
            "This is a test",
            style='cblock'))
    assert ("\n".join([
        '/*',
        ' * This is a test',
        ' */']) == comment(
            """This is a test""",
            style='cblock'))
    assert ("\n".join([
        '/*',
        ' * This is a test',
        ' */']) == comment(
            """This is
a test""",
            style='cblock'))

# Generated at 2022-06-21 04:30:49.130983
# Unit test for function ternary
def test_ternary():
    assert ternary(True, True, False)
    assert not ternary(False, True, False)
    assert ternary(None, 1, 2, 3) == 3



# Generated at 2022-06-21 04:30:55.714973
# Unit test for function ternary
def test_ternary():
    assert ternary(True, 1, 2) == 1, "ternary(True, 1, 2) == 1"
    assert ternary(False, 1, 2) == 2, "ternary(False, 1, 2) == 2"
    assert ternary(None, 1, 2) == 2, "ternary(None, 1, 2) == 2"
    assert ternary(None, 1, 2, 3) == 3, "ternary(None, 1, 2, 3) == 3"



# Generated at 2022-06-21 04:31:06.007187
# Unit test for function extract
def test_extract():
    env = jinja2.Environment()
    template = env.from_string('''
{% filter extract(item, container, morekeys) %}
{% endfilter %}
''')

    data = dict(
        container=dict(
            item=dict(
                morekeys=None,
            ),
        ),
    )
    # when morekeys is None, item is expected
    assert template.render(**data) == data['container']['item'], \
            'When "morekeys" is None, item is expected'

    data['container']['item']['morekeys'] = 'morekeys'
    # when morekeys is not None and not a list, a list with morekeys and item is expected

# Generated at 2022-06-21 04:31:13.699312
# Unit test for function extract
def test_extract():
    def t(container, item, morekeys, expected):
        result = extract(None, item, container, morekeys)
        assert result == expected

    # All types
    t({}, 'a', None, None)
    t({'a': {'b': 1}}, 'b', 'a', 1)
    t({'a': [{'b': 1}]}, 'b', ['a', 0], 1)
    t({'a': [{'b': 1}]}, 'b', ('a', 0), 1)

    # Ensure that there is no crash when we extract multiple times
    t({'a': []}, 'b', 'a', None)



# Generated at 2022-06-21 04:31:15.171419
# Unit test for function subelements
def test_subelements():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 04:31:19.562438
# Unit test for function b64encode
def test_b64encode():
    ''' Return the base64 encoding of a string. '''

    # Test for unicode.
    data = b64encode(to_text(u'\xe3\x83\x86\xe3\x82\xad\xe3\x82\xb9\xe3\x83\x88\xe3\x83\x88\xe3\x83\x88'))
    assert data == '44GK5aWz44Gv44Gr44Gv44Gv'

    # Test for ascii
    data = b64encode('test')
    assert data == 'dGVzdA=='

# Generated at 2022-06-21 04:31:26.820280
# Unit test for function to_yaml
def test_to_yaml():
    assert to_yaml([1,2,3], default_flow_style=False) == '- 1\n- 2\n- 3\n'
    assert to_yaml([1,2,3], default_flow_style=True) == '[1, 2, 3]\n'
    assert to_yaml([1,2,3], default_flow_style=None) == '- 1\n- 2\n- 3\n'


# Generated at 2022-06-21 04:31:39.907624
# Unit test for function regex_replace
def test_regex_replace():
    assert regex_replace(r'', r'^$', 'ca') == 'ca'
    assert regex_replace(r'a', r'^a$', 'ca', ignorecase=True) == 'ca'
    assert regex_replace(r'A', r'^A$', 'ca', ignorecase=True) == 'ca'
    assert regex_replace(r'A', r'^A$', 'ca', ignorecase=False) == ''
    assert regex_replace(r'A', r'^A$', 'ca') == ''
    assert regex_replace(r'', r'^$', 'caa') == 'caa'
    assert regex_replace(r'a', r'^a$', 'caa') == 'caa'

# Generated at 2022-06-21 04:31:54.810767
# Unit test for function flatten
def test_flatten():
    ret = flatten([[["test"]],['test1', ['test2'], [['test3']]], 'test4'])
    assert ret == ['test', 'test1', 'test2', 'test3', 'test4']



# Generated at 2022-06-21 04:32:08.083659
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    # test a password with a known salt
    assert get_encrypted_password('foobaz', 'sha256', salt='HfN7e/') == '$5$HfN7e/$yXhBQMozkMjbw0iSvHtOhyC.xK0e7yh4.3qH9LFoZn6'
    # test a password with an unknown salt
    assert re.match('\$5\$rounds=\d+\$[./A-Za-z0-9]{1,16}\$[./A-Za-z0-9]{53}', get_encrypted_password('foobaz', 'sha256'))

# Generated at 2022-06-21 04:32:19.923367
# Unit test for function flatten
def test_flatten():

    assert flatten(['hi']) == ['hi']
    assert flatten(['hi', 'world']) == ['hi', 'world']

    assert flatten(['hi', 'world'], skip_nulls=False) == ['hi', 'world', None]
    assert flatten(['hi', 'world', None], skip_nulls=False) == ['hi', 'world', None]

    assert flatten(['hi', ['world']]) == ['hi', 'world']
    assert flatten(['hi', ['world'], ['null']]) == ['hi', 'world', 'null']
    assert flatten(['hi', ['world'], ['null'], ['world2']]) == ['hi', 'world', 'null', 'world2']
    assert flatten(['hi', ['world'], ['null'], [None]])

# Generated at 2022-06-21 04:32:26.789562
# Unit test for function fileglob
def test_fileglob():
    import tempfile
    import os
    d = tempfile.mkdtemp()
    tempfile.mkstemp(dir=d)
    f = os.path.join(d, "foo")
    open(f, "w").close()
    assert f == fileglob(os.path.join(d, "foo"))[0]



# Generated at 2022-06-21 04:32:42.468058
# Unit test for function extract
def test_extract():
    # TEST1: item is a dictionary key, morekeys is None
    item = "dict_key"
    container = {
        "dict_key": "dict_value"
    }
    assert extract(item, container) == "dict_value"

    # TEST2: item is a dictionary key, morekeys is a list
    item = "dict_key"
    morekeys = ["sub_dict_key"]
    container = {
        "dict_key": {
            "sub_dict_key": "sub_dict_value"
        }
    }
    assert extract(item, container, morekeys) == "sub_dict_value"

    # TEST3: item is a dictionary key, morekeys is a string
    item = "dict_key"
    morekeys = "sub_dict_key"

# Generated at 2022-06-21 04:32:47.829857
# Unit test for function ternary
def test_ternary():
    assert ternary(1 == 1, true_val="true", false_val="false") == "true"
    assert ternary(1 == 0, true_val="true", false_val="false") == "false"
    expected_exception = None
    try:
        ternary(1, true_val="true", false_val="false")
    except Exception as err:
        expected_exception = err
    assert type(expected_exception) == TypeError



# Generated at 2022-06-21 04:33:02.877910
# Unit test for function regex_findall
def test_regex_findall():
    test_list = ['abc xyz', 'abc123', '123abc']
    test_value = '\n'.join(test_list)
    test_regex = '123'

    assert regex_findall(test_value, test_regex) == ['123', '123']
    assert regex_findall(test_value, '123', ignorecase=True) == ['123', '123']
    assert regex_findall(test_value, 'abc', ignorecase=True) == ['abc', 'abc']
    assert regex_findall('abc xyz', 'xyz', multiline=True) == ['xyz']
    assert regex_findall('abc_xyz', 'xyz') == ['xyz']
    assert regex_findall('abc_xyz', 'XYZ', ignorecase=True) == ['xyz']


# Generated at 2022-06-21 04:33:04.795535
# Unit test for function fileglob
def test_fileglob():
    files = fileglob('/etc/*blah*')
    assert not files



# Generated at 2022-06-21 04:33:12.221185
# Unit test for function randomize_list
def test_randomize_list():
    # Test the function with a given seed
    test_list = randomize_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], seed=10)
    # When the seed is 10, the given list will be shuffled to the following values
    expected_list = [9, 6, 7, 8, 5, 1, 2, 4, 10, 3]
    if len(test_list) != len(expected_list):
        return "Failed"
    for i in range(len(test_list)):
        if test_list[i] != expected_list[i]:
            return "Failed"

    return "Passed"


# Generated at 2022-06-21 04:33:23.885658
# Unit test for function get_encrypted_password
def test_get_encrypted_password():
    password = "test"
    result = get_encrypted_password(password, "md5")
    assert result == "$1$saltstring$MXhFVmB2hFyN99dFDQtMl1"

    result = get_encrypted_password(password, "blowfish")
    assert result == "$2b$04$saltstring$Y4Y4Y4Y4Y4Y4Y4Y4Y4Y4Y4"

    result = get_encrypted_password(password, "sha256")
    assert result == "$5$saltstring$5XeXhCc6RJeh6AWjuQYz2lZm3vqdHJGqmBs6so/9X84"

    result = get_encrypted_password(password, "sha512")

# Generated at 2022-06-21 04:33:31.664654
# Unit test for function to_nice_json
def test_to_nice_json():
    assert to_nice_json(dict(a=1, b=2)) == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-21 04:33:45.711738
# Unit test for function do_groupby
def test_do_groupby():
    from ansible.template import Jinja2Environment
    from jinja2 import DictLoader

    input_data = [
        {'foo': 'a', 'bar': 'b'},
        {'foo': 'a', 'bar': 'c'},
        {'foo': 'b', 'bar': 'c'},
        {'foo': 'c', 'bar': 'b'},
        {'foo': 'c', 'bar': 'c'},
        {'foo': 'c', 'bar': 'd'},
        {'foo': 'c', 'bar': 'e'}
    ]

# Generated at 2022-06-21 04:33:54.244875
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime('2019-03-30 12:00:00.000000', '%Y-%m-%d %H:%M:%S.%f') == datetime.datetime(2019, 3, 30, 12, 0)
    assert to_datetime('2019-03-30', '%Y-%m-%d') == datetime.datetime(2019, 3, 30, 0, 0)
    assert to_datetime('12:00:00', '%H:%M:%S') == datetime.datetime(1970, 1, 1, 12, 0)
    assert to_datetime('2019-03-30 12-00-00', '%Y-%m-%d %H-%M-%S') == datetime.datetime(1970, 1, 1, 0, 0)



# Generated at 2022-06-21 04:34:05.152972
# Unit test for function regex_search
def test_regex_search():
    ''' Test regex_search '''

    assert 0 == len(regex_search('foo', 'bar'))
    assert ['f'] == regex_search('foo', '[a-z]oo')
    assert ['f'] == regex_search('foo', '[a-z]oo', '\\g<0>')
    assert ['f', 'oo'] == regex_search('foo', '[a-z](.*)', '\\g<0>', '\\g<1>')
    assert ['f', 'o'] == regex_search('foo', '[a-z](.*)', '\\g<0>', '\\g<1>[0]')
    assert [] == regex_search('foo', '[a-z](.*)', '\\g<0>', '\\g<2>')

# Generated at 2022-06-21 04:34:16.098424
# Unit test for function fileglob
def test_fileglob():
    # Create directories and files
    os.makedirs("/tmp/test_dir/test_dir2")
    open("/tmp/test_dir/test_file1.txt", 'a').close()
    open("/tmp/test_dir/test_dir2/test_file2.txt", 'a').close()
    os.makedirs("/tmp/test_dir2")
    open("/tmp/test_file2.txt", 'a').close()
    open("/tmp/test_file3.txt", 'a').close()

    # Verify that fileglob is filtering out directories
    assert len(fileglob("/tmp/*")) == 3
    assert "/tmp/test_dir" not in fileglob("/tmp/*")
    assert "/tmp/test_dir2" not in fileglob("/tmp/*")

# Generated at 2022-06-21 04:34:20.110575
# Unit test for function rand
def test_rand():
    assert rand(None, 1) in (0, 1)
    # rand(1, 10) => randrange(1, 10, 1)
    assert rand(None, 1, 10) - 9 < 0.1
    assert rand(None, 1, 10, 2) in (1, 3, 5, 7, 9)
    # if seed is given, random.choice would return the same value
    assert rand(None, [1, 2, 3], seed=1) == 1
    assert rand(None, [1, 2, 3], seed=1) == 1
    assert rand(None, 'abc', seed=1) == 'a'
    assert rand(None, 'abc', seed=1) == 'a'



# Generated at 2022-06-21 04:34:33.141984
# Unit test for function to_datetime
def test_to_datetime():
    assert to_datetime("2016-02-24 12:30:20") == datetime.datetime(2016, 2, 24, 12, 30, 20)
    assert to_datetime("2016-02-24 12:30:20", "%Y-%m-%d %H:%M:%S") == datetime.datetime(2016, 2, 24, 12, 30, 20)
    assert to_datetime("2/24/2016 12:30:20", "%m/%d/%Y %H:%M:%S") == datetime.datetime(2016, 2, 24, 12, 30, 20)

# Generated at 2022-06-21 04:34:43.090809
# Unit test for function flatten

# Generated at 2022-06-21 04:34:54.308219
# Unit test for function regex_search
def test_regex_search():
    value = u'A B C'
    regex = u'[A-Z]'
    try:
        assert regex_search(value, regex) == u'A'
        assert regex_search(value, regex, '\\g<0>') == u'A'
        assert regex_search(value, regex, '\\g<1>') == u'A'
        assert regex_search(value, regex, '\\1') == u'A'
        assert regex_search(value, regex, '\\2') == u''
        assert regex_search(value, regex, '\\g<a>') == u''
        assert regex_search(value, regex, '\\a') == u''
    except AssertionError:
        raise AssertionError('assertion failed')



# Generated at 2022-06-21 04:35:02.626217
# Unit test for function regex_escape
def test_regex_escape():
    assert regex_escape('[foo.bar]') == '\\[foo\\.bar\\]'
    assert regex_escape('[foo.bar]', re_type='posix_basic') == '\\[foo\\.bar\\]'
    # TODO: implement posix_extended
    # assert regex_escape('[foo.bar]', re_type='posix_extended')
    assert regex_escape('[foo.bar]', re_type='invalid_re_type')



# Generated at 2022-06-21 04:35:11.187358
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
  a = {'a': 'b', 'c': 'd'}
  assert to_nice_yaml(a) == '{a: b, c: d}\n...\n'


# Generated at 2022-06-21 04:35:19.781763
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall("a1a2a3", "(a\d)") == ['a1', 'a2', 'a3']
    assert regex_findall("a1a2a3", "(a\d)", ignorecase=True) == ['a1', 'a2', 'a3']
    assert regex_findall("A1a2A3", "(a\d)", ignorecase=True) == ['a1', 'a2', 'A3']



# Generated at 2022-06-21 04:35:25.043536
# Unit test for function list_of_dict_key_value_elements_to_dict
def test_list_of_dict_key_value_elements_to_dict():
    mylist = [{"key": "a", "value": 1},
              {"key": "b", "value": 2},
              {"key": "c", "value": 3}]
    assert (list_of_dict_key_value_elements_to_dict(mylist) == {'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-21 04:35:39.953390
# Unit test for function fileglob
def test_fileglob():
    assert fileglob('/tmp') == []
    assert fileglob('/tmp/file1') == ['/tmp/file1']
    assert fileglob('/tmp/file1') != ['/tmp/file1','/tmp/file2']
    assert fileglob('/tmp/*') == fileglob('/tmp/*')
    assert fileglob('/tmp/file*') == fileglob('/tmp/file*')
    assert fileglob('/tmp/file*') != fileglob('/home/file1')
    # Test files exist and then use fileglob to assert
    if os.path.isfile('/tmp/file1'):
        assert fileglob('/tmp/file1') == ['/tmp/file1']

# Generated at 2022-06-21 04:35:50.078407
# Unit test for function to_bool
def test_to_bool():
    if not to_bool('true') or to_bool('false'):
        raise AssertionError("to_bool() failed on 'true'")
    if to_bool('bad input'):
        raise AssertionError("to_bool() failed on 'bad input'")
    if not to_bool(1):
        raise AssertionError("to_bool() failed on 1")
    if to_bool(0):
        raise AssertionError("to_bool() failed on 0")
    if to_bool(None):
        raise AssertionError("to_bool() failed on False")
    if not to_bool('1'):
        raise AssertionError("to_bool() failed on '1'")
    if to_bool('0'):
        raise AssertionError("to_bool() failed on '0'")



# Generated at 2022-06-21 04:35:55.710387
# Unit test for function to_datetime
def test_to_datetime():
    datetest = to_datetime('2012-01-01 00:00:00')
    assert isinstance(datetest, datetime.datetime)
    assert datetest == datetime.datetime(2012, 1, 1, 0, 0)



# Generated at 2022-06-21 04:35:59.558900
# Unit test for function get_hash
def test_get_hash():
    assert get_hash("data") == "bf3856b079c0849f5b5eb847cbef1d5f59741d1c"



# Generated at 2022-06-21 04:36:02.910595
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(u'Hello World!') == u'SGVsbG8gV29ybGQh'



# Generated at 2022-06-21 04:36:15.282710
# Unit test for function regex_escape
def test_regex_escape():  # pylint: disable=R0915
    assert '\\.' == regex_escape('.')
    assert '\*' == regex_escape('*')
    assert '\\^' == regex_escape('^')
    assert '\\-' == regex_escape('-')
    assert '\\[' == regex_escape('[')
    assert '\\]' == regex_escape(']')
    assert '\\+' == regex_escape('+')
    assert '\\\\' == regex_escape('\\')
    assert '\\$' == regex_escape('$')
    assert '\\{' == regex_escape('{')
    assert '\\}' == regex_escape('}')
    assert '\\(' == regex_escape('(')
    assert '\\)' == regex_escape(')')
    assert '\\?' == regex_escape('?')


# Generated at 2022-06-21 04:36:27.443056
# Unit test for function to_nice_yaml
def test_to_nice_yaml():
    from ansible.errors import AnsibleFilterError
    # Test that Ansible Undefined types do not cause errors
    try:
        a = to_nice_yaml(ansible_undefined)
        assert a == ''
    except AnsibleFilterError as e:
        raise AssertionError("Unexpected AnsibleFilterError exception raised: ", e)
    # Test string input
    try:
        a = to_nice_yaml("string")
        assert a == "- 'string'\n"
    except AnsibleFilterError as e:
        raise AssertionError("Unexpected AnsibleFilterError exception raised: ", e)
    # Test dictionary input

# Generated at 2022-06-21 04:36:36.594023
# Unit test for function mandatory
def test_mandatory():
    assert mandatory(42) == 42
    assert mandatory(None) == None
    assert mandatory(0) == 0
    assert mandatory(False) == False
    assert mandatory(True) == True
    assert mandatory([]) == []
    assert mandatory({}) == {}
    assert mandatory('') == ''
    assert mandatory('42') == '42'
    from jinja2.runtime import Undefined
    assert mandatory(Undefined) == Undefined



# Generated at 2022-06-21 04:36:38.947397
# Unit test for function regex_escape
def test_regex_escape():
    string = r'/var/log/messages.log'
    assert regex_escape(string) == r'\/var\/log\/messages\.log'
    assert regex_escape(string, re_type='posix_basic') == r'\/var\/log\/messages\.log'



# Generated at 2022-06-21 04:36:50.455076
# Unit test for function subelements
def test_subelements():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    obj = [{
        "name": "alice",
        "groups": ["wheel"],
        "authorized": [AnsibleUnsafeText("/tmp/alice/onekey.pub")]
    }, {
        "name": "bob",
        "groups": ["wheel", "dev"],
        "authorized": [AnsibleUnsafeText("/tmp/bob/id_rsa.pub")]
    }]

    group_results = subelements(obj, 'groups')
    assert len(group_results) == 3
    assert group_results[0][1] == 'wheel'
    assert group_results[1][1] == 'wheel'
    assert group_results[2][1] == 'dev'

    auth_results = sube

# Generated at 2022-06-21 04:36:56.028057
# Unit test for function randomize_list
def test_randomize_list():
    assert(randomize_list([]) == [])
    assert(randomize_list([1, 2]) != [1, 2])
    assert(randomize_list([1, 2]) != [2, 1])
    assert(randomize_list([1, 2], seed=1) == [1, 2])
    assert(randomize_list([1, 2], seed=1) != [2, 1])



# Generated at 2022-06-21 04:37:03.237544
# Unit test for function from_yaml_all
def test_from_yaml_all():
    from_yaml = from_yaml_all
    from_yaml.__name__ = 'from_yaml_all'

# Generated at 2022-06-21 04:37:15.848130
# Unit test for function extract
def test_extract():
    assert extract('a', 'a') == 'a'
    assert extract('a', 'b', {'b': 'a'}) == 'a'
    assert extract('a', 'b', {'a': 'b'}) == {'a': 'b'}
    assert extract('a', 'b', {'b': {'c': 'a'}}) == {'c': 'a'}
    assert extract('a', 'b', {'c': {'b': 'a'}}) == 'a'
    assert extract('a', 'b', {'b': {'b': 'a'}}) == {'b': 'a'}
    assert extract('a', 'b', {'c': {'d': {'b': 'a'}}}) == 'a'



# Generated at 2022-06-21 04:37:23.773370
# Unit test for function comment
def test_comment():
    test_value = 'Hello World'
    assert comment(test_value, style='plain') == '# Hello World'
    assert comment(test_value, style='c') == '// Hello World'
    assert comment(test_value, style='erlang') == '% Hello World'
    assert comment(test_value, style='cblock') == '/*\n * Hello World\n */'
    assert comment(test_value, style='xml') == '<!--\n - Hello World\n-->'
    assert comment(test_value, style='c', prefix='#', prefix_count=1, postfix='#', postfix_count=2, decoration='@ ') == '// Hello World\n# @ #'



# Generated at 2022-06-21 04:37:28.827704
# Unit test for function strftime
def test_strftime():
    time_format = '%Y-%m-%d %H:%M:%S'
    test_time = to_datetime('2008-09-03 21:53:04', time_format)
    assert strftime(time_format, test_time.timestamp()) == time.strftime(time_format, test_time.timetuple())



# Generated at 2022-06-21 04:37:32.236411
# Unit test for function b64encode
def test_b64encode():
    assert b64encode(b'Hello World') == 'SGVsbG8gV29ybGQ='



# Generated at 2022-06-21 04:37:41.736688
# Unit test for function randomize_list
def test_randomize_list():
    import random

    # a fixed seed guarantees the same results from shuffle()
    random.seed(42)
    example = ['foo', 'bar', 'baz', 'qux', 'quux']
    shuffled = randomize_list(example, seed=42)

    # also try with a different seed
    random.seed(43)
    shuffled_again = randomize_list(example, seed=43)

    assert shuffled == shuffled_again
    assert randomize_list(example) != shuffled



# Generated at 2022-06-21 04:38:03.688390
# Unit test for function flatten
def test_flatten():
    assert flatten(['a', 'b', ['c', 'd']]) == ['a', 'b', 'c', 'd']
    assert flatten([['a', 'b'], 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert flatten([['a', 'b'], [1, 2], 'c', 'd']) == ['a', 'b', 1, 2, 'c', 'd']
    assert flatten(['a', 'b', ['c', 'd'], [1, 2]]) == ['a', 'b', 'c', 'd', 1, 2]
    assert flatten(['a', [['b', 'c'], 'd'], 'e']) == ['a', 'b', 'c', 'd', 'e']



# Generated at 2022-06-21 04:38:07.942421
# Unit test for function do_groupby
def test_do_groupby():
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader("../templates"))
    env.filters.update({'do_groupby': do_groupby})
    return env.get_template("foo.j2").render({"x": [{"y": "a"}, {"y": "b"}]})



# Generated at 2022-06-21 04:38:16.760024
# Unit test for function b64decode
def test_b64decode():
    assert b64decode('YQ==') == u'a'
    assert b64decode('YWE=') == u'aa'
    assert b64decode('YWFh') == u'aaa'
    assert b64decode('YWFhYQ==') == u'aaaa'
    assert b64decode('YWFhYWE=') == u'aaaaa'
    assert b64decode('YWFhYWFh') == u'aaaaaa'



# Generated at 2022-06-21 04:38:25.258497
# Unit test for function from_yaml
def test_from_yaml():
    assert from_yaml('foo\nbar') == 'foo\nbar'
    assert from_yaml('foo\n- bar') == {'foo': ['bar']}
    assert from_yaml('foo\nbar: 1') == {'foo': 'bar: 1'}
    assert from_yaml('foo\nbar') == 'foo\nbar'
    assert from_yaml(dict(foo='bar', baz=dict(key='value'))) == dict(foo='bar', baz=dict(key='value'))
    assert from_yaml({'foo': 'bar', 'baz': {'key': 'value'}}) == {'foo': 'bar', 'baz': {'key': 'value'}}
    assert from_yaml(u'foo\nbar') == u'foo\nbar'

# Generated at 2022-06-21 04:38:30.104611
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test to verify that the method filters() return something
    # Create the instance
    myFilterModule = FilterModule()
    # Call method filters()
    myFilterModule.filters()


# Unit test of class FilterModule via its instance

# Generated at 2022-06-21 04:38:31.758869
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()
    assert True

# Generated at 2022-06-21 04:38:43.859112
# Unit test for function quote
def test_quote():
    def _test_quote(s, want):
        got = quote(s)
        if got != want:
            raise AssertionError('quote(%s) returned %s, want %s' % (s, got, want))
    _test_quote('foo bar', 'foo bar')
    _test_quote('foo bar baz', '"foo bar baz"')
    _test_quote(u'foo bar', 'foo bar')
    _test_quote(u'foo bar', 'foo bar')
    _test_quote(u'foo bar', 'foo bar')
    _test_quote(u'foo bar', 'foo bar')
    _test_quote(u'foo bar', 'foo bar')
    _test_quote(u'foo bar', 'foo bar')

# Generated at 2022-06-21 04:38:56.165169
# Unit test for function dict_to_list_of_dict_key_value_elements
def test_dict_to_list_of_dict_key_value_elements():
    d = dict(a=1, b=2)
    e = dict_to_list_of_dict_key_value_elements(d, key_name='xyz', value_name='value')
    assert e == [dict(xyz='a', value=1), dict(xyz='b', value=2)], "failed to convert a dictionary"

    assert dict_to_list_of_dict_key_value_elements(5) == 5, "5 is not a dictionary"
    assert dict_to_list_of_dict_key_value_elements([]) == [], "[] is not a dictionary"


# this is an overloaded version which allows you to have a subkey

# Generated at 2022-06-21 04:39:06.166585
# Unit test for function quote
def test_quote():
    assert quote(None) == u"''"
    assert quote("a") == u"a"
    assert quote(" a b ") == u"' a b '"
    assert quote('"') == u"\\'"
    assert quote("\\\"") == u"\\'\\\"'"
    assert quote("\\") == u"\\'"
    assert quote("a&b") == u"a\\&b"
    assert quote("a&&b") == u"a\\&\\&b"
    assert quote("a&b&c") == u"a\\&b\\&c"
    assert quote("a||b") == u"a\\|\\|b"
    assert quote(";") == u"\\;"
    assert quote(";&") == u"\\;\\&"

# Generated at 2022-06-21 04:39:06.896929
# Unit test for method filters of class FilterModule
def test_FilterModule_filters(): assert None


# Generated at 2022-06-21 04:39:23.546180
# Unit test for function extract
def test_extract():
    # Preparing test
    env = {}
    env['container'] = {
        'a': {
            'b': {
                'c': 'Hello, World!'
                }
            }
        }

    # Running tests
    assert filtered(None, 'c', env=env, container='container.a.b') == 'Hello, World!'

    assert filtered(None, 'c', env=env, container='container', morekeys=['a', 'b']) == 'Hello, World!'


# Generated at 2022-06-21 04:39:33.846965
# Unit test for function path_join
def test_path_join():
    assert path_join('/foo/bar') == '/foo/bar'
    assert path_join(['/foo', 'bar']) == '/foo/bar'
    assert path_join(['/foo', '/bar']) == '/foo/bar'
    assert path_join(['/foo/', '/bar']) == '/foo/bar'
    assert path_join(['/foo', '/bar/']) == '/foo/bar'
    assert path_join(['/foo/', '/bar/']) == '/foo/bar'
    assert path_join('/foo/', '/bar/') == '/foo/bar'
    assert path_join('/foo', '/bar') == '/foo/bar'
    assert path_join('/foo/', '/bar') == '/foo/bar'

# Generated at 2022-06-21 04:39:44.529742
# Unit test for function combine

# Generated at 2022-06-21 04:39:55.878356
# Unit test for function regex_findall
def test_regex_findall():
    assert regex_findall(
        'a.b.c',
        r'\.') == [u'.', '.']
    assert regex_findall(
        'a.b.c',
        r'\.',
        ignorecase=True) == [u'.', '.']
    assert regex_findall(
        'a.b.c',
        r'\.',
        ignorecase=True,
        multiline=True) == [u'.', '.']
    assert regex_findall(
        'a.b.c',
        r'\.',
        multiline=True) == [u'.', '.']